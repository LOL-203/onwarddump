﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020001A0 RID: 416
public static class DateTimeExtensions : Object
{
	// Token: 0x06001CAB RID: 7339 RVA: 0x00071B40 File Offset: 0x0006FD40
	[CallerCount(0)]
	public unsafe static int GetSecondsSinceEpoch()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_GetSecondsSinceEpoch_Public_Static_Int32_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CAC RID: 7340 RVA: 0x00071B84 File Offset: 0x0006FD84
	[CallerCount(0)]
	public unsafe static DateTime UnixTimestampToUniversalDateTime(int unixSecondsTimestamp)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref unixSecondsTimestamp;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_UnixTimestampToUniversalDateTime_Public_Static_DateTime_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CAD RID: 7341 RVA: 0x00071BD8 File Offset: 0x0006FDD8
	[CallerCount(0)]
	public unsafe static DateTime LongToLocalDateTime(long timestamp)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref timestamp;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_LongToLocalDateTime_Public_Static_DateTime_Int64_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CAE RID: 7342 RVA: 0x00071C2C File Offset: 0x0006FE2C
	[CallerCount(0)]
	public unsafe static long ConvertToUnixTimestamp(this DateTime dt)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_ConvertToUnixTimestamp_Public_Static_Int64_DateTime_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CAF RID: 7343 RVA: 0x00071C80 File Offset: 0x0006FE80
	[CallerCount(0)]
	public unsafe static DateTime StartTimeOfMonth(this DateTime dt)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_StartTimeOfMonth_Public_Static_DateTime_DateTime_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CB0 RID: 7344 RVA: 0x00071CD4 File Offset: 0x0006FED4
	[CallerCount(0)]
	public unsafe static double SecondsBetween(this DateTime dt, DateTime otherDate)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref otherDate;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_SecondsBetween_Public_Static_Double_DateTime_DateTime_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CB1 RID: 7345 RVA: 0x00071D3C File Offset: 0x0006FF3C
	[CallerCount(0)]
	public unsafe static DateTime NextWeekday(this DateTime dt, DayOfWeek dayOfWeek)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dayOfWeek;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_NextWeekday_Public_Static_DateTime_DateTime_DayOfWeek_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CB2 RID: 7346 RVA: 0x00071DA4 File Offset: 0x0006FFA4
	[CallerCount(0)]
	public unsafe static DateTime NthWeekdayOfMonth(this DateTime dt, int nthWeek, DayOfWeek dayOfWeek)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref nthWeek;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dayOfWeek;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DateTimeExtensions.NativeMethodInfoPtr_NthWeekdayOfMonth_Public_Static_DateTime_DateTime_Int32_DayOfWeek_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001CB3 RID: 7347 RVA: 0x00071E20 File Offset: 0x00070020
	// Note: this type is marked as 'beforefieldinit'.
	static DateTimeExtensions()
	{
		Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DateTimeExtensions");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr);
		DateTimeExtensions.NativeFieldInfoPtr_EPOCH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, "EPOCH");
		DateTimeExtensions.NativeMethodInfoPtr_GetSecondsSinceEpoch_Public_Static_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665539);
		DateTimeExtensions.NativeMethodInfoPtr_UnixTimestampToUniversalDateTime_Public_Static_DateTime_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665540);
		DateTimeExtensions.NativeMethodInfoPtr_LongToLocalDateTime_Public_Static_DateTime_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665541);
		DateTimeExtensions.NativeMethodInfoPtr_ConvertToUnixTimestamp_Public_Static_Int64_DateTime_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665542);
		DateTimeExtensions.NativeMethodInfoPtr_StartTimeOfMonth_Public_Static_DateTime_DateTime_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665543);
		DateTimeExtensions.NativeMethodInfoPtr_SecondsBetween_Public_Static_Double_DateTime_DateTime_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665544);
		DateTimeExtensions.NativeMethodInfoPtr_NextWeekday_Public_Static_DateTime_DateTime_DayOfWeek_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665545);
		DateTimeExtensions.NativeMethodInfoPtr_NthWeekdayOfMonth_Public_Static_DateTime_DateTime_Int32_DayOfWeek_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr, 100665546);
	}

	// Token: 0x06001CB4 RID: 7348 RVA: 0x00002988 File Offset: 0x00000B88
	public DateTimeExtensions(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000A04 RID: 2564
	// (get) Token: 0x06001CB5 RID: 7349 RVA: 0x00071F04 File Offset: 0x00070104
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DateTimeExtensions>.NativeClassPtr));
		}
	}

	// Token: 0x17000A05 RID: 2565
	// (get) Token: 0x06001CB6 RID: 7350 RVA: 0x00071F18 File Offset: 0x00070118
	// (set) Token: 0x06001CB7 RID: 7351 RVA: 0x00071F36 File Offset: 0x00070136
	public unsafe static DateTime EPOCH
	{
		get
		{
			DateTime result;
			IL2CPP.il2cpp_field_static_get_value(DateTimeExtensions.NativeFieldInfoPtr_EPOCH, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DateTimeExtensions.NativeFieldInfoPtr_EPOCH, (void*)(&value));
		}
	}

	// Token: 0x04001258 RID: 4696
	private static readonly IntPtr NativeFieldInfoPtr_EPOCH;

	// Token: 0x04001259 RID: 4697
	private static readonly IntPtr NativeMethodInfoPtr_GetSecondsSinceEpoch_Public_Static_Int32_0;

	// Token: 0x0400125A RID: 4698
	private static readonly IntPtr NativeMethodInfoPtr_UnixTimestampToUniversalDateTime_Public_Static_DateTime_Int32_0;

	// Token: 0x0400125B RID: 4699
	private static readonly IntPtr NativeMethodInfoPtr_LongToLocalDateTime_Public_Static_DateTime_Int64_0;

	// Token: 0x0400125C RID: 4700
	private static readonly IntPtr NativeMethodInfoPtr_ConvertToUnixTimestamp_Public_Static_Int64_DateTime_0;

	// Token: 0x0400125D RID: 4701
	private static readonly IntPtr NativeMethodInfoPtr_StartTimeOfMonth_Public_Static_DateTime_DateTime_0;

	// Token: 0x0400125E RID: 4702
	private static readonly IntPtr NativeMethodInfoPtr_SecondsBetween_Public_Static_Double_DateTime_DateTime_0;

	// Token: 0x0400125F RID: 4703
	private static readonly IntPtr NativeMethodInfoPtr_NextWeekday_Public_Static_DateTime_DateTime_DayOfWeek_0;

	// Token: 0x04001260 RID: 4704
	private static readonly IntPtr NativeMethodInfoPtr_NthWeekdayOfMonth_Public_Static_DateTime_DateTime_Int32_DayOfWeek_0;
}
