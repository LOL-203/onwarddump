﻿using System;
using AK.Wwise;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000142 RID: 322
public class CollisionSoundLibrary : MonoBehaviour
{
	// Token: 0x1700073F RID: 1855
	// (get) Token: 0x060014C5 RID: 5317 RVA: 0x000541B0 File Offset: 0x000523B0
	// (set) Token: 0x060014C6 RID: 5318 RVA: 0x000541F8 File Offset: 0x000523F8
	public unsafe static CollisionSoundLibrary Singleton
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_get_Singleton_Public_Static_get_CollisionSoundLibrary_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new CollisionSoundLibrary(intPtr2) : null;
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_CollisionSoundLibrary_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x060014C7 RID: 5319 RVA: 0x00054244 File Offset: 0x00052444
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014C8 RID: 5320 RVA: 0x00054288 File Offset: 0x00052488
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014C9 RID: 5321 RVA: 0x000542CC File Offset: 0x000524CC
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014CA RID: 5322 RVA: 0x00054310 File Offset: 0x00052510
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014CB RID: 5323 RVA: 0x00054354 File Offset: 0x00052554
	[CallerCount(0)]
	public unsafe void Initialize()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_Initialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014CC RID: 5324 RVA: 0x00054398 File Offset: 0x00052598
	[CallerCount(0)]
	public unsafe void LoadCollisionSoundsForType(SFXCollisionTypes type)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref type;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_LoadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014CD RID: 5325 RVA: 0x000543EC File Offset: 0x000525EC
	[CallerCount(0)]
	public unsafe void UnloadCollisionSoundsForType(SFXCollisionTypes type)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref type;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_UnloadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014CE RID: 5326 RVA: 0x00054440 File Offset: 0x00052640
	[CallerCount(0)]
	public unsafe AK.Wwise.Event GetCollisionSoundPlayEvent(SFXCollisionTypes type, DamageLibrary.MaterialType materialType)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref type;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref materialType;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr_GetCollisionSoundPlayEvent_Public_Event_SFXCollisionTypes_MaterialType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
	}

	// Token: 0x060014CF RID: 5327 RVA: 0x000544BC File Offset: 0x000526BC
	[CallerCount(0)]
	public unsafe CollisionSoundLibrary() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CollisionSoundLibrary.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014D0 RID: 5328 RVA: 0x00054508 File Offset: 0x00052708
	// Note: this type is marked as 'beforefieldinit'.
	static CollisionSoundLibrary()
	{
		Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CollisionSoundLibrary");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr);
		CollisionSoundLibrary.NativeFieldInfoPtr__Singleton_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "<Singleton>k__BackingField");
		CollisionSoundLibrary.NativeFieldInfoPtr_Generic = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Generic");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunGeneric = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunGeneric");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunSmall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunSmall");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunMedium = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunMedium");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunLarge = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunLarge");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunHuge = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunHuge");
		CollisionSoundLibrary.NativeFieldInfoPtr_GunSpecial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "GunSpecial");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingGeneric = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingGeneric");
		CollisionSoundLibrary.NativeFieldInfoPtr_Casing9mm = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Casing9mm");
		CollisionSoundLibrary.NativeFieldInfoPtr_Casing45 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Casing45");
		CollisionSoundLibrary.NativeFieldInfoPtr_Casing223 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Casing223");
		CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x39 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Casing762x39");
		CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x54 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Casing762x54");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingBeltLink = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingBeltLink");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingAmmoBox = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingAmmoBox");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingShotgunShell = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingShotgunShell");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingRocket = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingRocket");
		CollisionSoundLibrary.NativeFieldInfoPtr_CasingSpecial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "CasingSpecial");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineGeneric = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineGeneric");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSmall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineSmall");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineMedium = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineMedium");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineLarge = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineLarge");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineAmmoBox = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineAmmoBox");
		CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSpecial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "MagazineSpecial");
		CollisionSoundLibrary.NativeFieldInfoPtr_PropGeneric = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "PropGeneric");
		CollisionSoundLibrary.NativeFieldInfoPtr_PropBox = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "PropBox");
		CollisionSoundLibrary.NativeFieldInfoPtr_PropBottle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "PropBottle");
		CollisionSoundLibrary.NativeFieldInfoPtr_PropMetal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "PropMetal");
		CollisionSoundLibrary.NativeFieldInfoPtr_HumanGeneric = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HumanGeneric");
		CollisionSoundLibrary.NativeFieldInfoPtr_HumanWalk = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HumanWalk");
		CollisionSoundLibrary.NativeFieldInfoPtr_HumanRun = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HumanRun");
		CollisionSoundLibrary.NativeFieldInfoPtr_HumanFall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HumanFall");
		CollisionSoundLibrary.NativeFieldInfoPtr_HumanPunch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HumanPunch");
		CollisionSoundLibrary.NativeFieldInfoPtr_BallisticShield = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "BallisticShield");
		CollisionSoundLibrary.NativeFieldInfoPtr_Knife = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Knife");
		CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Spherical = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Grenade_Spherical");
		CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Cylindrical = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Grenade_Cylindrical");
		CollisionSoundLibrary.NativeFieldInfoPtr_Lighter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Lighter");
		CollisionSoundLibrary.NativeFieldInfoPtr_Tablet = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Tablet");
		CollisionSoundLibrary.NativeFieldInfoPtr_Drone = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Drone");
		CollisionSoundLibrary.NativeFieldInfoPtr_C4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "C4");
		CollisionSoundLibrary.NativeFieldInfoPtr_Syringe = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Syringe");
		CollisionSoundLibrary.NativeFieldInfoPtr_Bottle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Bottle");
		CollisionSoundLibrary.NativeFieldInfoPtr_Basketball = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "Basketball");
		CollisionSoundLibrary.NativeFieldInfoPtr_HardDrive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HardDrive");
		CollisionSoundLibrary.NativeFieldInfoPtr_HasInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "HasInitialized");
		CollisionSoundLibrary.NativeFieldInfoPtr_collisionSoundEventDict = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, "collisionSoundEventDict");
		CollisionSoundLibrary.NativeMethodInfoPtr_get_Singleton_Public_Static_get_CollisionSoundLibrary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665018);
		CollisionSoundLibrary.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_CollisionSoundLibrary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665019);
		CollisionSoundLibrary.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665020);
		CollisionSoundLibrary.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665021);
		CollisionSoundLibrary.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665022);
		CollisionSoundLibrary.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665023);
		CollisionSoundLibrary.NativeMethodInfoPtr_Initialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665024);
		CollisionSoundLibrary.NativeMethodInfoPtr_LoadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665025);
		CollisionSoundLibrary.NativeMethodInfoPtr_UnloadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665026);
		CollisionSoundLibrary.NativeMethodInfoPtr_GetCollisionSoundPlayEvent_Public_Event_SFXCollisionTypes_MaterialType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665027);
		CollisionSoundLibrary.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr, 100665028);
	}

	// Token: 0x060014D1 RID: 5329 RVA: 0x0000210C File Offset: 0x0000030C
	public CollisionSoundLibrary(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700070E RID: 1806
	// (get) Token: 0x060014D2 RID: 5330 RVA: 0x000549D4 File Offset: 0x00052BD4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CollisionSoundLibrary>.NativeClassPtr));
		}
	}

	// Token: 0x1700070F RID: 1807
	// (get) Token: 0x060014D3 RID: 5331 RVA: 0x000549E8 File Offset: 0x00052BE8
	// (set) Token: 0x060014D4 RID: 5332 RVA: 0x00054A13 File Offset: 0x00052C13
	public unsafe static CollisionSoundLibrary _Singleton_k__BackingField
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CollisionSoundLibrary.NativeFieldInfoPtr__Singleton_k__BackingField, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new CollisionSoundLibrary(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CollisionSoundLibrary.NativeFieldInfoPtr__Singleton_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000710 RID: 1808
	// (get) Token: 0x060014D5 RID: 5333 RVA: 0x00054A28 File Offset: 0x00052C28
	// (set) Token: 0x060014D6 RID: 5334 RVA: 0x00054A5C File Offset: 0x00052C5C
	public unsafe AK.Wwise.Event Generic
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Generic);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Generic), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000711 RID: 1809
	// (get) Token: 0x060014D7 RID: 5335 RVA: 0x00054A84 File Offset: 0x00052C84
	// (set) Token: 0x060014D8 RID: 5336 RVA: 0x00054AB8 File Offset: 0x00052CB8
	public unsafe AK.Wwise.Event GunGeneric
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunGeneric);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunGeneric), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000712 RID: 1810
	// (get) Token: 0x060014D9 RID: 5337 RVA: 0x00054AE0 File Offset: 0x00052CE0
	// (set) Token: 0x060014DA RID: 5338 RVA: 0x00054B14 File Offset: 0x00052D14
	public unsafe AK.Wwise.Event GunSmall
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunSmall);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunSmall), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000713 RID: 1811
	// (get) Token: 0x060014DB RID: 5339 RVA: 0x00054B3C File Offset: 0x00052D3C
	// (set) Token: 0x060014DC RID: 5340 RVA: 0x00054B70 File Offset: 0x00052D70
	public unsafe AK.Wwise.Event GunMedium
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunMedium);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunMedium), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000714 RID: 1812
	// (get) Token: 0x060014DD RID: 5341 RVA: 0x00054B98 File Offset: 0x00052D98
	// (set) Token: 0x060014DE RID: 5342 RVA: 0x00054BCC File Offset: 0x00052DCC
	public unsafe AK.Wwise.Event GunLarge
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunLarge);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunLarge), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000715 RID: 1813
	// (get) Token: 0x060014DF RID: 5343 RVA: 0x00054BF4 File Offset: 0x00052DF4
	// (set) Token: 0x060014E0 RID: 5344 RVA: 0x00054C28 File Offset: 0x00052E28
	public unsafe AK.Wwise.Event GunHuge
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunHuge);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunHuge), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000716 RID: 1814
	// (get) Token: 0x060014E1 RID: 5345 RVA: 0x00054C50 File Offset: 0x00052E50
	// (set) Token: 0x060014E2 RID: 5346 RVA: 0x00054C84 File Offset: 0x00052E84
	public unsafe AK.Wwise.Event GunSpecial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunSpecial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_GunSpecial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000717 RID: 1815
	// (get) Token: 0x060014E3 RID: 5347 RVA: 0x00054CAC File Offset: 0x00052EAC
	// (set) Token: 0x060014E4 RID: 5348 RVA: 0x00054CE0 File Offset: 0x00052EE0
	public unsafe AK.Wwise.Event CasingGeneric
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingGeneric);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingGeneric), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000718 RID: 1816
	// (get) Token: 0x060014E5 RID: 5349 RVA: 0x00054D08 File Offset: 0x00052F08
	// (set) Token: 0x060014E6 RID: 5350 RVA: 0x00054D3C File Offset: 0x00052F3C
	public unsafe AK.Wwise.Event Casing9mm
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing9mm);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing9mm), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000719 RID: 1817
	// (get) Token: 0x060014E7 RID: 5351 RVA: 0x00054D64 File Offset: 0x00052F64
	// (set) Token: 0x060014E8 RID: 5352 RVA: 0x00054D98 File Offset: 0x00052F98
	public unsafe AK.Wwise.Event Casing45
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing45);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing45), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071A RID: 1818
	// (get) Token: 0x060014E9 RID: 5353 RVA: 0x00054DC0 File Offset: 0x00052FC0
	// (set) Token: 0x060014EA RID: 5354 RVA: 0x00054DF4 File Offset: 0x00052FF4
	public unsafe AK.Wwise.Event Casing223
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing223);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing223), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071B RID: 1819
	// (get) Token: 0x060014EB RID: 5355 RVA: 0x00054E1C File Offset: 0x0005301C
	// (set) Token: 0x060014EC RID: 5356 RVA: 0x00054E50 File Offset: 0x00053050
	public unsafe AK.Wwise.Event Casing762x39
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x39);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x39), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071C RID: 1820
	// (get) Token: 0x060014ED RID: 5357 RVA: 0x00054E78 File Offset: 0x00053078
	// (set) Token: 0x060014EE RID: 5358 RVA: 0x00054EAC File Offset: 0x000530AC
	public unsafe AK.Wwise.Event Casing762x54
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x54);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Casing762x54), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071D RID: 1821
	// (get) Token: 0x060014EF RID: 5359 RVA: 0x00054ED4 File Offset: 0x000530D4
	// (set) Token: 0x060014F0 RID: 5360 RVA: 0x00054F08 File Offset: 0x00053108
	public unsafe AK.Wwise.Event CasingBeltLink
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingBeltLink);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingBeltLink), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071E RID: 1822
	// (get) Token: 0x060014F1 RID: 5361 RVA: 0x00054F30 File Offset: 0x00053130
	// (set) Token: 0x060014F2 RID: 5362 RVA: 0x00054F64 File Offset: 0x00053164
	public unsafe AK.Wwise.Event CasingAmmoBox
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingAmmoBox);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingAmmoBox), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700071F RID: 1823
	// (get) Token: 0x060014F3 RID: 5363 RVA: 0x00054F8C File Offset: 0x0005318C
	// (set) Token: 0x060014F4 RID: 5364 RVA: 0x00054FC0 File Offset: 0x000531C0
	public unsafe AK.Wwise.Event CasingShotgunShell
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingShotgunShell);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingShotgunShell), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000720 RID: 1824
	// (get) Token: 0x060014F5 RID: 5365 RVA: 0x00054FE8 File Offset: 0x000531E8
	// (set) Token: 0x060014F6 RID: 5366 RVA: 0x0005501C File Offset: 0x0005321C
	public unsafe AK.Wwise.Event CasingRocket
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingRocket);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingRocket), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000721 RID: 1825
	// (get) Token: 0x060014F7 RID: 5367 RVA: 0x00055044 File Offset: 0x00053244
	// (set) Token: 0x060014F8 RID: 5368 RVA: 0x00055078 File Offset: 0x00053278
	public unsafe AK.Wwise.Event CasingSpecial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingSpecial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_CasingSpecial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000722 RID: 1826
	// (get) Token: 0x060014F9 RID: 5369 RVA: 0x000550A0 File Offset: 0x000532A0
	// (set) Token: 0x060014FA RID: 5370 RVA: 0x000550D4 File Offset: 0x000532D4
	public unsafe AK.Wwise.Event MagazineGeneric
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineGeneric);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineGeneric), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000723 RID: 1827
	// (get) Token: 0x060014FB RID: 5371 RVA: 0x000550FC File Offset: 0x000532FC
	// (set) Token: 0x060014FC RID: 5372 RVA: 0x00055130 File Offset: 0x00053330
	public unsafe AK.Wwise.Event MagazineSmall
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSmall);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSmall), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000724 RID: 1828
	// (get) Token: 0x060014FD RID: 5373 RVA: 0x00055158 File Offset: 0x00053358
	// (set) Token: 0x060014FE RID: 5374 RVA: 0x0005518C File Offset: 0x0005338C
	public unsafe AK.Wwise.Event MagazineMedium
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineMedium);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineMedium), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000725 RID: 1829
	// (get) Token: 0x060014FF RID: 5375 RVA: 0x000551B4 File Offset: 0x000533B4
	// (set) Token: 0x06001500 RID: 5376 RVA: 0x000551E8 File Offset: 0x000533E8
	public unsafe AK.Wwise.Event MagazineLarge
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineLarge);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineLarge), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000726 RID: 1830
	// (get) Token: 0x06001501 RID: 5377 RVA: 0x00055210 File Offset: 0x00053410
	// (set) Token: 0x06001502 RID: 5378 RVA: 0x00055244 File Offset: 0x00053444
	public unsafe AK.Wwise.Event MagazineAmmoBox
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineAmmoBox);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineAmmoBox), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000727 RID: 1831
	// (get) Token: 0x06001503 RID: 5379 RVA: 0x0005526C File Offset: 0x0005346C
	// (set) Token: 0x06001504 RID: 5380 RVA: 0x000552A0 File Offset: 0x000534A0
	public unsafe AK.Wwise.Event MagazineSpecial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSpecial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_MagazineSpecial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000728 RID: 1832
	// (get) Token: 0x06001505 RID: 5381 RVA: 0x000552C8 File Offset: 0x000534C8
	// (set) Token: 0x06001506 RID: 5382 RVA: 0x000552FC File Offset: 0x000534FC
	public unsafe AK.Wwise.Event PropGeneric
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropGeneric);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropGeneric), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000729 RID: 1833
	// (get) Token: 0x06001507 RID: 5383 RVA: 0x00055324 File Offset: 0x00053524
	// (set) Token: 0x06001508 RID: 5384 RVA: 0x00055358 File Offset: 0x00053558
	public unsafe AK.Wwise.Event PropBox
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropBox);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropBox), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072A RID: 1834
	// (get) Token: 0x06001509 RID: 5385 RVA: 0x00055380 File Offset: 0x00053580
	// (set) Token: 0x0600150A RID: 5386 RVA: 0x000553B4 File Offset: 0x000535B4
	public unsafe AK.Wwise.Event PropBottle
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropBottle);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropBottle), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072B RID: 1835
	// (get) Token: 0x0600150B RID: 5387 RVA: 0x000553DC File Offset: 0x000535DC
	// (set) Token: 0x0600150C RID: 5388 RVA: 0x00055410 File Offset: 0x00053610
	public unsafe AK.Wwise.Event PropMetal
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropMetal);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_PropMetal), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072C RID: 1836
	// (get) Token: 0x0600150D RID: 5389 RVA: 0x00055438 File Offset: 0x00053638
	// (set) Token: 0x0600150E RID: 5390 RVA: 0x0005546C File Offset: 0x0005366C
	public unsafe AK.Wwise.Event HumanGeneric
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanGeneric);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanGeneric), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072D RID: 1837
	// (get) Token: 0x0600150F RID: 5391 RVA: 0x00055494 File Offset: 0x00053694
	// (set) Token: 0x06001510 RID: 5392 RVA: 0x000554C8 File Offset: 0x000536C8
	public unsafe AK.Wwise.Event HumanWalk
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanWalk);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanWalk), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072E RID: 1838
	// (get) Token: 0x06001511 RID: 5393 RVA: 0x000554F0 File Offset: 0x000536F0
	// (set) Token: 0x06001512 RID: 5394 RVA: 0x00055524 File Offset: 0x00053724
	public unsafe AK.Wwise.Event HumanRun
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanRun);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanRun), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700072F RID: 1839
	// (get) Token: 0x06001513 RID: 5395 RVA: 0x0005554C File Offset: 0x0005374C
	// (set) Token: 0x06001514 RID: 5396 RVA: 0x00055580 File Offset: 0x00053780
	public unsafe AK.Wwise.Event HumanFall
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanFall);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanFall), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000730 RID: 1840
	// (get) Token: 0x06001515 RID: 5397 RVA: 0x000555A8 File Offset: 0x000537A8
	// (set) Token: 0x06001516 RID: 5398 RVA: 0x000555DC File Offset: 0x000537DC
	public unsafe AK.Wwise.Event HumanPunch
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanPunch);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HumanPunch), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000731 RID: 1841
	// (get) Token: 0x06001517 RID: 5399 RVA: 0x00055604 File Offset: 0x00053804
	// (set) Token: 0x06001518 RID: 5400 RVA: 0x00055638 File Offset: 0x00053838
	public unsafe AK.Wwise.Event BallisticShield
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_BallisticShield);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_BallisticShield), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000732 RID: 1842
	// (get) Token: 0x06001519 RID: 5401 RVA: 0x00055660 File Offset: 0x00053860
	// (set) Token: 0x0600151A RID: 5402 RVA: 0x00055694 File Offset: 0x00053894
	public unsafe AK.Wwise.Event Knife
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Knife);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Knife), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000733 RID: 1843
	// (get) Token: 0x0600151B RID: 5403 RVA: 0x000556BC File Offset: 0x000538BC
	// (set) Token: 0x0600151C RID: 5404 RVA: 0x000556F0 File Offset: 0x000538F0
	public unsafe AK.Wwise.Event Grenade_Spherical
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Spherical);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Spherical), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000734 RID: 1844
	// (get) Token: 0x0600151D RID: 5405 RVA: 0x00055718 File Offset: 0x00053918
	// (set) Token: 0x0600151E RID: 5406 RVA: 0x0005574C File Offset: 0x0005394C
	public unsafe AK.Wwise.Event Grenade_Cylindrical
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Cylindrical);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Grenade_Cylindrical), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000735 RID: 1845
	// (get) Token: 0x0600151F RID: 5407 RVA: 0x00055774 File Offset: 0x00053974
	// (set) Token: 0x06001520 RID: 5408 RVA: 0x000557A8 File Offset: 0x000539A8
	public unsafe AK.Wwise.Event Lighter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Lighter);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Lighter), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000736 RID: 1846
	// (get) Token: 0x06001521 RID: 5409 RVA: 0x000557D0 File Offset: 0x000539D0
	// (set) Token: 0x06001522 RID: 5410 RVA: 0x00055804 File Offset: 0x00053A04
	public unsafe AK.Wwise.Event Tablet
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Tablet);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Tablet), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000737 RID: 1847
	// (get) Token: 0x06001523 RID: 5411 RVA: 0x0005582C File Offset: 0x00053A2C
	// (set) Token: 0x06001524 RID: 5412 RVA: 0x00055860 File Offset: 0x00053A60
	public unsafe AK.Wwise.Event Drone
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Drone);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Drone), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000738 RID: 1848
	// (get) Token: 0x06001525 RID: 5413 RVA: 0x00055888 File Offset: 0x00053A88
	// (set) Token: 0x06001526 RID: 5414 RVA: 0x000558BC File Offset: 0x00053ABC
	public unsafe AK.Wwise.Event C4
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_C4);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_C4), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000739 RID: 1849
	// (get) Token: 0x06001527 RID: 5415 RVA: 0x000558E4 File Offset: 0x00053AE4
	// (set) Token: 0x06001528 RID: 5416 RVA: 0x00055918 File Offset: 0x00053B18
	public unsafe AK.Wwise.Event Syringe
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Syringe);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Syringe), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700073A RID: 1850
	// (get) Token: 0x06001529 RID: 5417 RVA: 0x00055940 File Offset: 0x00053B40
	// (set) Token: 0x0600152A RID: 5418 RVA: 0x00055974 File Offset: 0x00053B74
	public unsafe AK.Wwise.Event Bottle
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Bottle);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Bottle), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700073B RID: 1851
	// (get) Token: 0x0600152B RID: 5419 RVA: 0x0005599C File Offset: 0x00053B9C
	// (set) Token: 0x0600152C RID: 5420 RVA: 0x000559D0 File Offset: 0x00053BD0
	public unsafe AK.Wwise.Event Basketball
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Basketball);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_Basketball), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700073C RID: 1852
	// (get) Token: 0x0600152D RID: 5421 RVA: 0x000559F8 File Offset: 0x00053BF8
	// (set) Token: 0x0600152E RID: 5422 RVA: 0x00055A2C File Offset: 0x00053C2C
	public unsafe AK.Wwise.Event HardDrive
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HardDrive);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HardDrive), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700073D RID: 1853
	// (get) Token: 0x0600152F RID: 5423 RVA: 0x00055A54 File Offset: 0x00053C54
	// (set) Token: 0x06001530 RID: 5424 RVA: 0x00055A7C File Offset: 0x00053C7C
	public unsafe bool HasInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HasInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_HasInitialized)) = value;
		}
	}

	// Token: 0x1700073E RID: 1854
	// (get) Token: 0x06001531 RID: 5425 RVA: 0x00055AA0 File Offset: 0x00053CA0
	// (set) Token: 0x06001532 RID: 5426 RVA: 0x00055AD4 File Offset: 0x00053CD4
	public unsafe Dictionary<SFXCollisionTypes, AK.Wwise.Event> collisionSoundEventDict
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_collisionSoundEventDict);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<SFXCollisionTypes, AK.Wwise.Event>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CollisionSoundLibrary.NativeFieldInfoPtr_collisionSoundEventDict), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000D44 RID: 3396
	private static readonly IntPtr NativeFieldInfoPtr__Singleton_k__BackingField;

	// Token: 0x04000D45 RID: 3397
	private static readonly IntPtr NativeFieldInfoPtr_Generic;

	// Token: 0x04000D46 RID: 3398
	private static readonly IntPtr NativeFieldInfoPtr_GunGeneric;

	// Token: 0x04000D47 RID: 3399
	private static readonly IntPtr NativeFieldInfoPtr_GunSmall;

	// Token: 0x04000D48 RID: 3400
	private static readonly IntPtr NativeFieldInfoPtr_GunMedium;

	// Token: 0x04000D49 RID: 3401
	private static readonly IntPtr NativeFieldInfoPtr_GunLarge;

	// Token: 0x04000D4A RID: 3402
	private static readonly IntPtr NativeFieldInfoPtr_GunHuge;

	// Token: 0x04000D4B RID: 3403
	private static readonly IntPtr NativeFieldInfoPtr_GunSpecial;

	// Token: 0x04000D4C RID: 3404
	private static readonly IntPtr NativeFieldInfoPtr_CasingGeneric;

	// Token: 0x04000D4D RID: 3405
	private static readonly IntPtr NativeFieldInfoPtr_Casing9mm;

	// Token: 0x04000D4E RID: 3406
	private static readonly IntPtr NativeFieldInfoPtr_Casing45;

	// Token: 0x04000D4F RID: 3407
	private static readonly IntPtr NativeFieldInfoPtr_Casing223;

	// Token: 0x04000D50 RID: 3408
	private static readonly IntPtr NativeFieldInfoPtr_Casing762x39;

	// Token: 0x04000D51 RID: 3409
	private static readonly IntPtr NativeFieldInfoPtr_Casing762x54;

	// Token: 0x04000D52 RID: 3410
	private static readonly IntPtr NativeFieldInfoPtr_CasingBeltLink;

	// Token: 0x04000D53 RID: 3411
	private static readonly IntPtr NativeFieldInfoPtr_CasingAmmoBox;

	// Token: 0x04000D54 RID: 3412
	private static readonly IntPtr NativeFieldInfoPtr_CasingShotgunShell;

	// Token: 0x04000D55 RID: 3413
	private static readonly IntPtr NativeFieldInfoPtr_CasingRocket;

	// Token: 0x04000D56 RID: 3414
	private static readonly IntPtr NativeFieldInfoPtr_CasingSpecial;

	// Token: 0x04000D57 RID: 3415
	private static readonly IntPtr NativeFieldInfoPtr_MagazineGeneric;

	// Token: 0x04000D58 RID: 3416
	private static readonly IntPtr NativeFieldInfoPtr_MagazineSmall;

	// Token: 0x04000D59 RID: 3417
	private static readonly IntPtr NativeFieldInfoPtr_MagazineMedium;

	// Token: 0x04000D5A RID: 3418
	private static readonly IntPtr NativeFieldInfoPtr_MagazineLarge;

	// Token: 0x04000D5B RID: 3419
	private static readonly IntPtr NativeFieldInfoPtr_MagazineAmmoBox;

	// Token: 0x04000D5C RID: 3420
	private static readonly IntPtr NativeFieldInfoPtr_MagazineSpecial;

	// Token: 0x04000D5D RID: 3421
	private static readonly IntPtr NativeFieldInfoPtr_PropGeneric;

	// Token: 0x04000D5E RID: 3422
	private static readonly IntPtr NativeFieldInfoPtr_PropBox;

	// Token: 0x04000D5F RID: 3423
	private static readonly IntPtr NativeFieldInfoPtr_PropBottle;

	// Token: 0x04000D60 RID: 3424
	private static readonly IntPtr NativeFieldInfoPtr_PropMetal;

	// Token: 0x04000D61 RID: 3425
	private static readonly IntPtr NativeFieldInfoPtr_HumanGeneric;

	// Token: 0x04000D62 RID: 3426
	private static readonly IntPtr NativeFieldInfoPtr_HumanWalk;

	// Token: 0x04000D63 RID: 3427
	private static readonly IntPtr NativeFieldInfoPtr_HumanRun;

	// Token: 0x04000D64 RID: 3428
	private static readonly IntPtr NativeFieldInfoPtr_HumanFall;

	// Token: 0x04000D65 RID: 3429
	private static readonly IntPtr NativeFieldInfoPtr_HumanPunch;

	// Token: 0x04000D66 RID: 3430
	private static readonly IntPtr NativeFieldInfoPtr_BallisticShield;

	// Token: 0x04000D67 RID: 3431
	private static readonly IntPtr NativeFieldInfoPtr_Knife;

	// Token: 0x04000D68 RID: 3432
	private static readonly IntPtr NativeFieldInfoPtr_Grenade_Spherical;

	// Token: 0x04000D69 RID: 3433
	private static readonly IntPtr NativeFieldInfoPtr_Grenade_Cylindrical;

	// Token: 0x04000D6A RID: 3434
	private static readonly IntPtr NativeFieldInfoPtr_Lighter;

	// Token: 0x04000D6B RID: 3435
	private static readonly IntPtr NativeFieldInfoPtr_Tablet;

	// Token: 0x04000D6C RID: 3436
	private static readonly IntPtr NativeFieldInfoPtr_Drone;

	// Token: 0x04000D6D RID: 3437
	private static readonly IntPtr NativeFieldInfoPtr_C4;

	// Token: 0x04000D6E RID: 3438
	private static readonly IntPtr NativeFieldInfoPtr_Syringe;

	// Token: 0x04000D6F RID: 3439
	private static readonly IntPtr NativeFieldInfoPtr_Bottle;

	// Token: 0x04000D70 RID: 3440
	private static readonly IntPtr NativeFieldInfoPtr_Basketball;

	// Token: 0x04000D71 RID: 3441
	private static readonly IntPtr NativeFieldInfoPtr_HardDrive;

	// Token: 0x04000D72 RID: 3442
	private static readonly IntPtr NativeFieldInfoPtr_HasInitialized;

	// Token: 0x04000D73 RID: 3443
	private static readonly IntPtr NativeFieldInfoPtr_collisionSoundEventDict;

	// Token: 0x04000D74 RID: 3444
	private static readonly IntPtr NativeMethodInfoPtr_get_Singleton_Public_Static_get_CollisionSoundLibrary_0;

	// Token: 0x04000D75 RID: 3445
	private static readonly IntPtr NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_CollisionSoundLibrary_0;

	// Token: 0x04000D76 RID: 3446
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04000D77 RID: 3447
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04000D78 RID: 3448
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04000D79 RID: 3449
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04000D7A RID: 3450
	private static readonly IntPtr NativeMethodInfoPtr_Initialize_Private_Void_0;

	// Token: 0x04000D7B RID: 3451
	private static readonly IntPtr NativeMethodInfoPtr_LoadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0;

	// Token: 0x04000D7C RID: 3452
	private static readonly IntPtr NativeMethodInfoPtr_UnloadCollisionSoundsForType_Public_Void_SFXCollisionTypes_0;

	// Token: 0x04000D7D RID: 3453
	private static readonly IntPtr NativeMethodInfoPtr_GetCollisionSoundPlayEvent_Public_Event_SFXCollisionTypes_MaterialType_0;

	// Token: 0x04000D7E RID: 3454
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
