﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000242 RID: 578
public class CameraDot : MonoBehaviour
{
	// Token: 0x060029A7 RID: 10663 RVA: 0x000A4F08 File Offset: 0x000A3108
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDot.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060029A8 RID: 10664 RVA: 0x000A4F4C File Offset: 0x000A314C
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDot.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060029A9 RID: 10665 RVA: 0x000A4F90 File Offset: 0x000A3190
	[CallerCount(0)]
	public unsafe CameraDot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraDot>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060029AA RID: 10666 RVA: 0x000A4FDC File Offset: 0x000A31DC
	// Note: this type is marked as 'beforefieldinit'.
	static CameraDot()
	{
		Il2CppClassPointerStore<CameraDot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraDot");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraDot>.NativeClassPtr);
		CameraDot.NativeFieldInfoPtr_tentMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "tentMap");
		CameraDot.NativeFieldInfoPtr_used = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "used");
		CameraDot.NativeFieldInfoPtr_isSavedPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "isSavedPosition");
		CameraDot.NativeFieldInfoPtr_savedPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "savedPos");
		CameraDot.NativeFieldInfoPtr_FOVlines = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "FOVlines");
		CameraDot.NativeFieldInfoPtr_camToUse = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "camToUse");
		CameraDot.NativeFieldInfoPtr_count = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "count");
		CameraDot.NativeFieldInfoPtr_image = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, "image");
		CameraDot.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, 100666511);
		CameraDot.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, 100666512);
		CameraDot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDot>.NativeClassPtr, 100666513);
	}

	// Token: 0x060029AB RID: 10667 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraDot(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000EBF RID: 3775
	// (get) Token: 0x060029AC RID: 10668 RVA: 0x000A50E8 File Offset: 0x000A32E8
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraDot>.NativeClassPtr));
		}
	}

	// Token: 0x17000EC0 RID: 3776
	// (get) Token: 0x060029AD RID: 10669 RVA: 0x000A50FC File Offset: 0x000A32FC
	// (set) Token: 0x060029AE RID: 10670 RVA: 0x000A5130 File Offset: 0x000A3330
	public unsafe TentMap tentMap
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_tentMap);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TentMap(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_tentMap), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000EC1 RID: 3777
	// (get) Token: 0x060029AF RID: 10671 RVA: 0x000A5158 File Offset: 0x000A3358
	// (set) Token: 0x060029B0 RID: 10672 RVA: 0x000A5180 File Offset: 0x000A3380
	public unsafe bool used
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_used);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_used)) = value;
		}
	}

	// Token: 0x17000EC2 RID: 3778
	// (get) Token: 0x060029B1 RID: 10673 RVA: 0x000A51A4 File Offset: 0x000A33A4
	// (set) Token: 0x060029B2 RID: 10674 RVA: 0x000A51CC File Offset: 0x000A33CC
	public unsafe bool isSavedPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_isSavedPosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_isSavedPosition)) = value;
		}
	}

	// Token: 0x17000EC3 RID: 3779
	// (get) Token: 0x060029B3 RID: 10675 RVA: 0x000A51F0 File Offset: 0x000A33F0
	// (set) Token: 0x060029B4 RID: 10676 RVA: 0x000A5224 File Offset: 0x000A3424
	public unsafe Transform savedPos
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_savedPos);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_savedPos), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000EC4 RID: 3780
	// (get) Token: 0x060029B5 RID: 10677 RVA: 0x000A524C File Offset: 0x000A344C
	// (set) Token: 0x060029B6 RID: 10678 RVA: 0x000A5280 File Offset: 0x000A3480
	public unsafe GameObject FOVlines
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_FOVlines);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_FOVlines), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000EC5 RID: 3781
	// (get) Token: 0x060029B7 RID: 10679 RVA: 0x000A52A8 File Offset: 0x000A34A8
	// (set) Token: 0x060029B8 RID: 10680 RVA: 0x000A52DC File Offset: 0x000A34DC
	public unsafe Transform camToUse
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_camToUse);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_camToUse), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000EC6 RID: 3782
	// (get) Token: 0x060029B9 RID: 10681 RVA: 0x000A5304 File Offset: 0x000A3504
	// (set) Token: 0x060029BA RID: 10682 RVA: 0x000A532C File Offset: 0x000A352C
	public unsafe int count
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_count);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_count)) = value;
		}
	}

	// Token: 0x17000EC7 RID: 3783
	// (get) Token: 0x060029BB RID: 10683 RVA: 0x000A5350 File Offset: 0x000A3550
	// (set) Token: 0x060029BC RID: 10684 RVA: 0x000A5384 File Offset: 0x000A3584
	public unsafe Image image
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_image);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Image(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDot.NativeFieldInfoPtr_image), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04001AAB RID: 6827
	private static readonly IntPtr NativeFieldInfoPtr_tentMap;

	// Token: 0x04001AAC RID: 6828
	private static readonly IntPtr NativeFieldInfoPtr_used;

	// Token: 0x04001AAD RID: 6829
	private static readonly IntPtr NativeFieldInfoPtr_isSavedPosition;

	// Token: 0x04001AAE RID: 6830
	private static readonly IntPtr NativeFieldInfoPtr_savedPos;

	// Token: 0x04001AAF RID: 6831
	private static readonly IntPtr NativeFieldInfoPtr_FOVlines;

	// Token: 0x04001AB0 RID: 6832
	private static readonly IntPtr NativeFieldInfoPtr_camToUse;

	// Token: 0x04001AB1 RID: 6833
	private static readonly IntPtr NativeFieldInfoPtr_count;

	// Token: 0x04001AB2 RID: 6834
	private static readonly IntPtr NativeFieldInfoPtr_image;

	// Token: 0x04001AB3 RID: 6835
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04001AB4 RID: 6836
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04001AB5 RID: 6837
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
