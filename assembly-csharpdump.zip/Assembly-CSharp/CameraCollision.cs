﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000172 RID: 370
public class CameraCollision : MonoBehaviour
{
	// Token: 0x17000887 RID: 2183
	// (get) Token: 0x0600188B RID: 6283 RVA: 0x0006232C File Offset: 0x0006052C
	public unsafe bool IsAnythingPotentiallyColliding
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_get_IsAnythingPotentiallyColliding_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x0600188C RID: 6284 RVA: 0x0006237C File Offset: 0x0006057C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600188D RID: 6285 RVA: 0x000623C0 File Offset: 0x000605C0
	[CallerCount(0)]
	public unsafe void Reset()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_Reset_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600188E RID: 6286 RVA: 0x00062404 File Offset: 0x00060604
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_OnEnable_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600188F RID: 6287 RVA: 0x00062448 File Offset: 0x00060648
	[CallerCount(0)]
	public unsafe IEnumerator DelayCheck()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_DelayCheck_Public_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06001890 RID: 6288 RVA: 0x000624A0 File Offset: 0x000606A0
	[CallerCount(0)]
	public unsafe void UpdateCollisionCheck()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_UpdateCollisionCheck_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001891 RID: 6289 RVA: 0x000624E4 File Offset: 0x000606E4
	[CallerCount(0)]
	public unsafe bool IsHeadInsideSomething()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_IsHeadInsideSomething_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001892 RID: 6290 RVA: 0x00062534 File Offset: 0x00060734
	[CallerCount(0)]
	public unsafe bool IsBodyInsideSomething()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_IsBodyInsideSomething_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001893 RID: 6291 RVA: 0x00062584 File Offset: 0x00060784
	[CallerCount(0)]
	public unsafe bool IsBodyTooFarFromHead()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr_IsBodyTooFarFromHead_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001894 RID: 6292 RVA: 0x000625D4 File Offset: 0x000607D4
	[CallerCount(0)]
	public unsafe CameraCollision() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001895 RID: 6293 RVA: 0x00062620 File Offset: 0x00060820
	// Note: this type is marked as 'beforefieldinit'.
	static CameraCollision()
	{
		Il2CppClassPointerStore<CameraCollision>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraCollision");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr);
		CameraCollision.NativeFieldInfoPtr_HeadOriginTransform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "HeadOriginTransform");
		CameraCollision.NativeFieldInfoPtr_MyController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "MyController");
		CameraCollision.NativeFieldInfoPtr_Wplayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "Wplayer");
		CameraCollision.NativeFieldInfoPtr_HCC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "HCC");
		CameraCollision.NativeFieldInfoPtr_DEBUG_HeadCheckLog = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "DEBUG_HeadCheckLog");
		CameraCollision.NativeFieldInfoPtr_MaxDistanceFromController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "MaxDistanceFromController");
		CameraCollision.NativeFieldInfoPtr_Sent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "Sent");
		CameraCollision.NativeFieldInfoPtr_Raycasted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "Raycasted");
		CameraCollision.NativeFieldInfoPtr_CanStartChecking = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "CanStartChecking");
		CameraCollision.NativeFieldInfoPtr_hit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "hit");
		CameraCollision.NativeFieldInfoPtr_MyLayerMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "MyLayerMask");
		CameraCollision.NativeFieldInfoPtr_MinHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "MinHeight");
		CameraCollision.NativeFieldInfoPtr_offsetCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "offsetCount");
		CameraCollision.NativeMethodInfoPtr_get_IsAnythingPotentiallyColliding_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665263);
		CameraCollision.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665264);
		CameraCollision.NativeMethodInfoPtr_Reset_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665265);
		CameraCollision.NativeMethodInfoPtr_OnEnable_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665266);
		CameraCollision.NativeMethodInfoPtr_DelayCheck_Public_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665267);
		CameraCollision.NativeMethodInfoPtr_UpdateCollisionCheck_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665268);
		CameraCollision.NativeMethodInfoPtr_IsHeadInsideSomething_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665269);
		CameraCollision.NativeMethodInfoPtr_IsBodyInsideSomething_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665270);
		CameraCollision.NativeMethodInfoPtr_IsBodyTooFarFromHead_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665271);
		CameraCollision.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, 100665272);
	}

	// Token: 0x06001896 RID: 6294 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraCollision(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000879 RID: 2169
	// (get) Token: 0x06001897 RID: 6295 RVA: 0x0006281C File Offset: 0x00060A1C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr));
		}
	}

	// Token: 0x1700087A RID: 2170
	// (get) Token: 0x06001898 RID: 6296 RVA: 0x00062830 File Offset: 0x00060A30
	// (set) Token: 0x06001899 RID: 6297 RVA: 0x00062864 File Offset: 0x00060A64
	public unsafe Transform HeadOriginTransform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_HeadOriginTransform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_HeadOriginTransform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700087B RID: 2171
	// (get) Token: 0x0600189A RID: 6298 RVA: 0x0006288C File Offset: 0x00060A8C
	// (set) Token: 0x0600189B RID: 6299 RVA: 0x000628C0 File Offset: 0x00060AC0
	public unsafe VRCharacterController MyController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MyController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new VRCharacterController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MyController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700087C RID: 2172
	// (get) Token: 0x0600189C RID: 6300 RVA: 0x000628E8 File Offset: 0x00060AE8
	// (set) Token: 0x0600189D RID: 6301 RVA: 0x0006291C File Offset: 0x00060B1C
	public unsafe WarPlayerScript Wplayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Wplayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Wplayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700087D RID: 2173
	// (get) Token: 0x0600189E RID: 6302 RVA: 0x00062944 File Offset: 0x00060B44
	// (set) Token: 0x0600189F RID: 6303 RVA: 0x00062978 File Offset: 0x00060B78
	public unsafe HeadCollisionCollider HCC
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_HCC);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new HeadCollisionCollider(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_HCC), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700087E RID: 2174
	// (get) Token: 0x060018A0 RID: 6304 RVA: 0x000629A0 File Offset: 0x00060BA0
	// (set) Token: 0x060018A1 RID: 6305 RVA: 0x000629C8 File Offset: 0x00060BC8
	public unsafe bool DEBUG_HeadCheckLog
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_DEBUG_HeadCheckLog);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_DEBUG_HeadCheckLog)) = value;
		}
	}

	// Token: 0x1700087F RID: 2175
	// (get) Token: 0x060018A2 RID: 6306 RVA: 0x000629EC File Offset: 0x00060BEC
	// (set) Token: 0x060018A3 RID: 6307 RVA: 0x00062A14 File Offset: 0x00060C14
	public unsafe float MaxDistanceFromController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MaxDistanceFromController);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MaxDistanceFromController)) = value;
		}
	}

	// Token: 0x17000880 RID: 2176
	// (get) Token: 0x060018A4 RID: 6308 RVA: 0x00062A38 File Offset: 0x00060C38
	// (set) Token: 0x060018A5 RID: 6309 RVA: 0x00062A60 File Offset: 0x00060C60
	public unsafe bool Sent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Sent);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Sent)) = value;
		}
	}

	// Token: 0x17000881 RID: 2177
	// (get) Token: 0x060018A6 RID: 6310 RVA: 0x00062A84 File Offset: 0x00060C84
	// (set) Token: 0x060018A7 RID: 6311 RVA: 0x00062AAC File Offset: 0x00060CAC
	public unsafe bool Raycasted
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Raycasted);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_Raycasted)) = value;
		}
	}

	// Token: 0x17000882 RID: 2178
	// (get) Token: 0x060018A8 RID: 6312 RVA: 0x00062AD0 File Offset: 0x00060CD0
	// (set) Token: 0x060018A9 RID: 6313 RVA: 0x00062AF8 File Offset: 0x00060CF8
	public unsafe bool CanStartChecking
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_CanStartChecking);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_CanStartChecking)) = value;
		}
	}

	// Token: 0x17000883 RID: 2179
	// (get) Token: 0x060018AA RID: 6314 RVA: 0x00062B1C File Offset: 0x00060D1C
	// (set) Token: 0x060018AB RID: 6315 RVA: 0x00062B44 File Offset: 0x00060D44
	public unsafe RaycastHit hit
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_hit);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_hit)) = value;
		}
	}

	// Token: 0x17000884 RID: 2180
	// (get) Token: 0x060018AC RID: 6316 RVA: 0x00062B68 File Offset: 0x00060D68
	// (set) Token: 0x060018AD RID: 6317 RVA: 0x00062B90 File Offset: 0x00060D90
	public unsafe LayerMask MyLayerMask
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MyLayerMask);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MyLayerMask)) = value;
		}
	}

	// Token: 0x17000885 RID: 2181
	// (get) Token: 0x060018AE RID: 6318 RVA: 0x00062BB4 File Offset: 0x00060DB4
	// (set) Token: 0x060018AF RID: 6319 RVA: 0x00062BDC File Offset: 0x00060DDC
	public unsafe float MinHeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MinHeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_MinHeight)) = value;
		}
	}

	// Token: 0x17000886 RID: 2182
	// (get) Token: 0x060018B0 RID: 6320 RVA: 0x00062C00 File Offset: 0x00060E00
	// (set) Token: 0x060018B1 RID: 6321 RVA: 0x00062C28 File Offset: 0x00060E28
	public unsafe int offsetCount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_offsetCount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision.NativeFieldInfoPtr_offsetCount)) = value;
		}
	}

	// Token: 0x04000FD7 RID: 4055
	private static readonly IntPtr NativeFieldInfoPtr_HeadOriginTransform;

	// Token: 0x04000FD8 RID: 4056
	private static readonly IntPtr NativeFieldInfoPtr_MyController;

	// Token: 0x04000FD9 RID: 4057
	private static readonly IntPtr NativeFieldInfoPtr_Wplayer;

	// Token: 0x04000FDA RID: 4058
	private static readonly IntPtr NativeFieldInfoPtr_HCC;

	// Token: 0x04000FDB RID: 4059
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_HeadCheckLog;

	// Token: 0x04000FDC RID: 4060
	private static readonly IntPtr NativeFieldInfoPtr_MaxDistanceFromController;

	// Token: 0x04000FDD RID: 4061
	private static readonly IntPtr NativeFieldInfoPtr_Sent;

	// Token: 0x04000FDE RID: 4062
	private static readonly IntPtr NativeFieldInfoPtr_Raycasted;

	// Token: 0x04000FDF RID: 4063
	private static readonly IntPtr NativeFieldInfoPtr_CanStartChecking;

	// Token: 0x04000FE0 RID: 4064
	private static readonly IntPtr NativeFieldInfoPtr_hit;

	// Token: 0x04000FE1 RID: 4065
	private static readonly IntPtr NativeFieldInfoPtr_MyLayerMask;

	// Token: 0x04000FE2 RID: 4066
	private static readonly IntPtr NativeFieldInfoPtr_MinHeight;

	// Token: 0x04000FE3 RID: 4067
	private static readonly IntPtr NativeFieldInfoPtr_offsetCount;

	// Token: 0x04000FE4 RID: 4068
	private static readonly IntPtr NativeMethodInfoPtr_get_IsAnythingPotentiallyColliding_Public_get_Boolean_0;

	// Token: 0x04000FE5 RID: 4069
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000FE6 RID: 4070
	private static readonly IntPtr NativeMethodInfoPtr_Reset_Public_Void_0;

	// Token: 0x04000FE7 RID: 4071
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Public_Void_0;

	// Token: 0x04000FE8 RID: 4072
	private static readonly IntPtr NativeMethodInfoPtr_DelayCheck_Public_IEnumerator_0;

	// Token: 0x04000FE9 RID: 4073
	private static readonly IntPtr NativeMethodInfoPtr_UpdateCollisionCheck_Public_Void_0;

	// Token: 0x04000FEA RID: 4074
	private static readonly IntPtr NativeMethodInfoPtr_IsHeadInsideSomething_Private_Boolean_0;

	// Token: 0x04000FEB RID: 4075
	private static readonly IntPtr NativeMethodInfoPtr_IsBodyInsideSomething_Private_Boolean_0;

	// Token: 0x04000FEC RID: 4076
	private static readonly IntPtr NativeMethodInfoPtr_IsBodyTooFarFromHead_Private_Boolean_0;

	// Token: 0x04000FED RID: 4077
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000173 RID: 371
	[ObfuscatedName("CameraCollision/<DelayCheck>d__18")]
	public sealed class _DelayCheck_d__18 : Il2CppSystem.Object
	{
		// Token: 0x060018B2 RID: 6322 RVA: 0x00062C4C File Offset: 0x00060E4C
		[CallerCount(0)]
		public unsafe _DelayCheck_d__18(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060018B3 RID: 6323 RVA: 0x00062CAC File Offset: 0x00060EAC
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060018B4 RID: 6324 RVA: 0x00062CF0 File Offset: 0x00060EF0
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x1700088C RID: 2188
		// (get) Token: 0x060018B5 RID: 6325 RVA: 0x00062D40 File Offset: 0x00060F40
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060018B6 RID: 6326 RVA: 0x00062D98 File Offset: 0x00060F98
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700088D RID: 2189
		// (get) Token: 0x060018B7 RID: 6327 RVA: 0x00062DDC File Offset: 0x00060FDC
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060018B8 RID: 6328 RVA: 0x00062E34 File Offset: 0x00061034
		// Note: this type is marked as 'beforefieldinit'.
		static _DelayCheck_d__18()
		{
			Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CameraCollision>.NativeClassPtr, "<DelayCheck>d__18");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr);
			CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, "<>1__state");
			CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, "<>2__current");
			CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, "<>4__this");
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665273);
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665274);
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665275);
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665276);
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665277);
			CameraCollision._DelayCheck_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr, 100665278);
		}

		// Token: 0x060018B9 RID: 6329 RVA: 0x00002988 File Offset: 0x00000B88
		public _DelayCheck_d__18(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000888 RID: 2184
		// (get) Token: 0x060018BA RID: 6330 RVA: 0x00062F13 File Offset: 0x00061113
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraCollision._DelayCheck_d__18>.NativeClassPtr));
			}
		}

		// Token: 0x17000889 RID: 2185
		// (get) Token: 0x060018BB RID: 6331 RVA: 0x00062F24 File Offset: 0x00061124
		// (set) Token: 0x060018BC RID: 6332 RVA: 0x00062F4C File Offset: 0x0006114C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700088A RID: 2186
		// (get) Token: 0x060018BD RID: 6333 RVA: 0x00062F70 File Offset: 0x00061170
		// (set) Token: 0x060018BE RID: 6334 RVA: 0x00062FA4 File Offset: 0x000611A4
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700088B RID: 2187
		// (get) Token: 0x060018BF RID: 6335 RVA: 0x00062FCC File Offset: 0x000611CC
		// (set) Token: 0x060018C0 RID: 6336 RVA: 0x00063000 File Offset: 0x00061200
		public unsafe CameraCollision __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CameraCollision(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCollision._DelayCheck_d__18.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000FEE RID: 4078
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04000FEF RID: 4079
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04000FF0 RID: 4080
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04000FF1 RID: 4081
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000FF2 RID: 4082
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000FF3 RID: 4083
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04000FF4 RID: 4084
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04000FF5 RID: 4085
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000FF6 RID: 4086
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
