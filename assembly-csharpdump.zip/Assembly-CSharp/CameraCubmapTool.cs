﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C6 RID: 198
public class CameraCubmapTool : MonoBehaviour
{
	// Token: 0x06000C62 RID: 3170 RVA: 0x00032514 File Offset: 0x00030714
	[CallerCount(0)]
	public unsafe void GetSnapshot()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCubmapTool.NativeMethodInfoPtr_GetSnapshot_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C63 RID: 3171 RVA: 0x00032558 File Offset: 0x00030758
	[CallerCount(0)]
	public unsafe void ConvertToPng(Cubemap cubemap)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(cubemap);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCubmapTool.NativeMethodInfoPtr_ConvertToPng_Private_Void_Cubemap_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C64 RID: 3172 RVA: 0x000325B4 File Offset: 0x000307B4
	[CallerCount(0)]
	public unsafe static void FlipTextureVertically(Texture2D original)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(original);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCubmapTool.NativeMethodInfoPtr_FlipTextureVertically_Public_Static_Void_Texture2D_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C65 RID: 3173 RVA: 0x00032600 File Offset: 0x00030800
	[CallerCount(0)]
	public unsafe CameraCubmapTool() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCubmapTool.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C66 RID: 3174 RVA: 0x0003264C File Offset: 0x0003084C
	// Note: this type is marked as 'beforefieldinit'.
	static CameraCubmapTool()
	{
		Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraCubmapTool");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr);
		CameraCubmapTool.NativeFieldInfoPtr_CameraReferencePosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, "CameraReferencePosition");
		CameraCubmapTool.NativeFieldInfoPtr_CubemapReference = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, "CubemapReference");
		CameraCubmapTool.NativeMethodInfoPtr_GetSnapshot_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, 100664259);
		CameraCubmapTool.NativeMethodInfoPtr_ConvertToPng_Private_Void_Cubemap_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, 100664260);
		CameraCubmapTool.NativeMethodInfoPtr_FlipTextureVertically_Public_Static_Void_Texture2D_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, 100664261);
		CameraCubmapTool.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr, 100664262);
	}

	// Token: 0x06000C67 RID: 3175 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraCubmapTool(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000445 RID: 1093
	// (get) Token: 0x06000C68 RID: 3176 RVA: 0x000326F4 File Offset: 0x000308F4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraCubmapTool>.NativeClassPtr));
		}
	}

	// Token: 0x17000446 RID: 1094
	// (get) Token: 0x06000C69 RID: 3177 RVA: 0x00032708 File Offset: 0x00030908
	// (set) Token: 0x06000C6A RID: 3178 RVA: 0x0003273C File Offset: 0x0003093C
	public unsafe Transform CameraReferencePosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCubmapTool.NativeFieldInfoPtr_CameraReferencePosition);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCubmapTool.NativeFieldInfoPtr_CameraReferencePosition), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000447 RID: 1095
	// (get) Token: 0x06000C6B RID: 3179 RVA: 0x00032764 File Offset: 0x00030964
	// (set) Token: 0x06000C6C RID: 3180 RVA: 0x00032798 File Offset: 0x00030998
	public unsafe Cubemap CubemapReference
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCubmapTool.NativeFieldInfoPtr_CubemapReference);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Cubemap(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCubmapTool.NativeFieldInfoPtr_CubemapReference), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400077C RID: 1916
	private static readonly IntPtr NativeFieldInfoPtr_CameraReferencePosition;

	// Token: 0x0400077D RID: 1917
	private static readonly IntPtr NativeFieldInfoPtr_CubemapReference;

	// Token: 0x0400077E RID: 1918
	private static readonly IntPtr NativeMethodInfoPtr_GetSnapshot_Public_Void_0;

	// Token: 0x0400077F RID: 1919
	private static readonly IntPtr NativeMethodInfoPtr_ConvertToPng_Private_Void_Cubemap_0;

	// Token: 0x04000780 RID: 1920
	private static readonly IntPtr NativeMethodInfoPtr_FlipTextureVertically_Public_Static_Void_Texture2D_0;

	// Token: 0x04000781 RID: 1921
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
