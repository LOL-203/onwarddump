﻿using System;
using Il2CppSystem;
using Onward.Pickups;
using Onward.Weapons;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004EE RID: 1262
public class BoltRotator : MonoBehaviour
{
	// Token: 0x17002479 RID: 9337
	// (get) Token: 0x060066AD RID: 26285 RVA: 0x0019C724 File Offset: 0x0019A924
	public unsafe float Rotation
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_get_Rotation_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700247A RID: 9338
	// (get) Token: 0x060066AE RID: 26286 RVA: 0x0019C774 File Offset: 0x0019A974
	public unsafe bool CanRotate
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_get_CanRotate_Private_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700247B RID: 9339
	// (get) Token: 0x060066AF RID: 26287 RVA: 0x0019C7C4 File Offset: 0x0019A9C4
	// (set) Token: 0x060066B0 RID: 26288 RVA: 0x0019C814 File Offset: 0x0019AA14
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x060066B1 RID: 26289 RVA: 0x0019C868 File Offset: 0x0019AA68
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B2 RID: 26290 RVA: 0x0019C8AC File Offset: 0x0019AAAC
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B3 RID: 26291 RVA: 0x0019C8F0 File Offset: 0x0019AAF0
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B4 RID: 26292 RVA: 0x0019C934 File Offset: 0x0019AB34
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B5 RID: 26293 RVA: 0x0019C978 File Offset: 0x0019AB78
	[CallerCount(0)]
	public unsafe void FinishClosingBolt()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_FinishClosingBolt_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B6 RID: 26294 RVA: 0x0019C9BC File Offset: 0x0019ABBC
	[CallerCount(0)]
	public unsafe static float ClampAngle(float angle, float min, float max)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref angle;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref min;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_ClampAngle_Private_Static_Single_Single_Single_Single_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060066B7 RID: 26295 RVA: 0x0019CA38 File Offset: 0x0019AC38
	[CallerCount(0)]
	public unsafe void SetHandController(HandController handController)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(handController);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_SetHandController_Private_Void_HandController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B8 RID: 26296 RVA: 0x0019CA94 File Offset: 0x0019AC94
	[CallerCount(0)]
	public unsafe void ClearHandController(HandController handController)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(handController);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr_ClearHandController_Private_Void_HandController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066B9 RID: 26297 RVA: 0x0019CAF0 File Offset: 0x0019ACF0
	[CallerCount(0)]
	public unsafe BoltRotator() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoltRotator.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066BA RID: 26298 RVA: 0x0019CB3C File Offset: 0x0019AD3C
	// Note: this type is marked as 'beforefieldinit'.
	static BoltRotator()
	{
		Il2CppClassPointerStore<BoltRotator>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BoltRotator");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr);
		BoltRotator.NativeFieldInfoPtr_weaponSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "weaponSO");
		BoltRotator.NativeFieldInfoPtr_interactableBoltActionBolt = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "interactableBoltActionBolt");
		BoltRotator.NativeFieldInfoPtr__startBoltRot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "_startBoltRot");
		BoltRotator.NativeFieldInfoPtr__lookRotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "_lookRotation");
		BoltRotator.NativeFieldInfoPtr__direction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "_direction");
		BoltRotator.NativeFieldInfoPtr__handGameObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "_handGameObject");
		BoltRotator.NativeFieldInfoPtr__transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "_transform");
		BoltRotator.NativeFieldInfoPtr_SLERP_SPEED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "SLERP_SPEED");
		BoltRotator.NativeFieldInfoPtr_RESET_ROTATION_SPEED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "RESET_ROTATION_SPEED");
		BoltRotator.NativeFieldInfoPtr_LOCAL_Y_ROTATION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "LOCAL_Y_ROTATION");
		BoltRotator.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		BoltRotator.NativeMethodInfoPtr_get_Rotation_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671458);
		BoltRotator.NativeMethodInfoPtr_get_CanRotate_Private_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671459);
		BoltRotator.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671460);
		BoltRotator.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671461);
		BoltRotator.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671462);
		BoltRotator.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671463);
		BoltRotator.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671464);
		BoltRotator.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671465);
		BoltRotator.NativeMethodInfoPtr_FinishClosingBolt_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671466);
		BoltRotator.NativeMethodInfoPtr_ClampAngle_Private_Static_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671467);
		BoltRotator.NativeMethodInfoPtr_SetHandController_Private_Void_HandController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671468);
		BoltRotator.NativeMethodInfoPtr_ClearHandController_Private_Void_HandController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671469);
		BoltRotator.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr, 100671470);
	}

	// Token: 0x060066BB RID: 26299 RVA: 0x0000210C File Offset: 0x0000030C
	public BoltRotator(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700246D RID: 9325
	// (get) Token: 0x060066BC RID: 26300 RVA: 0x0019CD4C File Offset: 0x0019AF4C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BoltRotator>.NativeClassPtr));
		}
	}

	// Token: 0x1700246E RID: 9326
	// (get) Token: 0x060066BD RID: 26301 RVA: 0x0019CD60 File Offset: 0x0019AF60
	// (set) Token: 0x060066BE RID: 26302 RVA: 0x0019CD94 File Offset: 0x0019AF94
	public unsafe WeaponSO weaponSO
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr_weaponSO);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WeaponSO(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr_weaponSO), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700246F RID: 9327
	// (get) Token: 0x060066BF RID: 26303 RVA: 0x0019CDBC File Offset: 0x0019AFBC
	// (set) Token: 0x060066C0 RID: 26304 RVA: 0x0019CDF0 File Offset: 0x0019AFF0
	public unsafe Interactable_BoltActionBolt interactableBoltActionBolt
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr_interactableBoltActionBolt);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Interactable_BoltActionBolt(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr_interactableBoltActionBolt), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002470 RID: 9328
	// (get) Token: 0x060066C1 RID: 26305 RVA: 0x0019CE18 File Offset: 0x0019B018
	// (set) Token: 0x060066C2 RID: 26306 RVA: 0x0019CE40 File Offset: 0x0019B040
	public unsafe Quaternion _startBoltRot
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__startBoltRot);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__startBoltRot)) = value;
		}
	}

	// Token: 0x17002471 RID: 9329
	// (get) Token: 0x060066C3 RID: 26307 RVA: 0x0019CE64 File Offset: 0x0019B064
	// (set) Token: 0x060066C4 RID: 26308 RVA: 0x0019CE8C File Offset: 0x0019B08C
	public unsafe Quaternion _lookRotation
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__lookRotation);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__lookRotation)) = value;
		}
	}

	// Token: 0x17002472 RID: 9330
	// (get) Token: 0x060066C5 RID: 26309 RVA: 0x0019CEB0 File Offset: 0x0019B0B0
	// (set) Token: 0x060066C6 RID: 26310 RVA: 0x0019CED8 File Offset: 0x0019B0D8
	public unsafe Vector3 _direction
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__direction);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__direction)) = value;
		}
	}

	// Token: 0x17002473 RID: 9331
	// (get) Token: 0x060066C7 RID: 26311 RVA: 0x0019CEFC File Offset: 0x0019B0FC
	// (set) Token: 0x060066C8 RID: 26312 RVA: 0x0019CF30 File Offset: 0x0019B130
	public unsafe GameObject _handGameObject
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__handGameObject);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__handGameObject), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002474 RID: 9332
	// (get) Token: 0x060066C9 RID: 26313 RVA: 0x0019CF58 File Offset: 0x0019B158
	// (set) Token: 0x060066CA RID: 26314 RVA: 0x0019CF8C File Offset: 0x0019B18C
	public unsafe Transform _transform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__transform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__transform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002475 RID: 9333
	// (get) Token: 0x060066CB RID: 26315 RVA: 0x0019CFB4 File Offset: 0x0019B1B4
	// (set) Token: 0x060066CC RID: 26316 RVA: 0x0019CFD2 File Offset: 0x0019B1D2
	public unsafe static int SLERP_SPEED
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(BoltRotator.NativeFieldInfoPtr_SLERP_SPEED, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BoltRotator.NativeFieldInfoPtr_SLERP_SPEED, (void*)(&value));
		}
	}

	// Token: 0x17002476 RID: 9334
	// (get) Token: 0x060066CD RID: 26317 RVA: 0x0019CFE4 File Offset: 0x0019B1E4
	// (set) Token: 0x060066CE RID: 26318 RVA: 0x0019D002 File Offset: 0x0019B202
	public unsafe static float RESET_ROTATION_SPEED
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(BoltRotator.NativeFieldInfoPtr_RESET_ROTATION_SPEED, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BoltRotator.NativeFieldInfoPtr_RESET_ROTATION_SPEED, (void*)(&value));
		}
	}

	// Token: 0x17002477 RID: 9335
	// (get) Token: 0x060066CF RID: 26319 RVA: 0x0019D014 File Offset: 0x0019B214
	// (set) Token: 0x060066D0 RID: 26320 RVA: 0x0019D032 File Offset: 0x0019B232
	public unsafe static float LOCAL_Y_ROTATION
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(BoltRotator.NativeFieldInfoPtr_LOCAL_Y_ROTATION, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BoltRotator.NativeFieldInfoPtr_LOCAL_Y_ROTATION, (void*)(&value));
		}
	}

	// Token: 0x17002478 RID: 9336
	// (get) Token: 0x060066D1 RID: 26321 RVA: 0x0019D044 File Offset: 0x0019B244
	// (set) Token: 0x060066D2 RID: 26322 RVA: 0x0019D06C File Offset: 0x0019B26C
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoltRotator.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x040040D4 RID: 16596
	private static readonly IntPtr NativeFieldInfoPtr_weaponSO;

	// Token: 0x040040D5 RID: 16597
	private static readonly IntPtr NativeFieldInfoPtr_interactableBoltActionBolt;

	// Token: 0x040040D6 RID: 16598
	private static readonly IntPtr NativeFieldInfoPtr__startBoltRot;

	// Token: 0x040040D7 RID: 16599
	private static readonly IntPtr NativeFieldInfoPtr__lookRotation;

	// Token: 0x040040D8 RID: 16600
	private static readonly IntPtr NativeFieldInfoPtr__direction;

	// Token: 0x040040D9 RID: 16601
	private static readonly IntPtr NativeFieldInfoPtr__handGameObject;

	// Token: 0x040040DA RID: 16602
	private static readonly IntPtr NativeFieldInfoPtr__transform;

	// Token: 0x040040DB RID: 16603
	private static readonly IntPtr NativeFieldInfoPtr_SLERP_SPEED;

	// Token: 0x040040DC RID: 16604
	private static readonly IntPtr NativeFieldInfoPtr_RESET_ROTATION_SPEED;

	// Token: 0x040040DD RID: 16605
	private static readonly IntPtr NativeFieldInfoPtr_LOCAL_Y_ROTATION;

	// Token: 0x040040DE RID: 16606
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x040040DF RID: 16607
	private static readonly IntPtr NativeMethodInfoPtr_get_Rotation_Public_get_Single_0;

	// Token: 0x040040E0 RID: 16608
	private static readonly IntPtr NativeMethodInfoPtr_get_CanRotate_Private_get_Boolean_0;

	// Token: 0x040040E1 RID: 16609
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x040040E2 RID: 16610
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x040040E3 RID: 16611
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x040040E4 RID: 16612
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x040040E5 RID: 16613
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040040E6 RID: 16614
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x040040E7 RID: 16615
	private static readonly IntPtr NativeMethodInfoPtr_FinishClosingBolt_Private_Void_0;

	// Token: 0x040040E8 RID: 16616
	private static readonly IntPtr NativeMethodInfoPtr_ClampAngle_Private_Static_Single_Single_Single_Single_0;

	// Token: 0x040040E9 RID: 16617
	private static readonly IntPtr NativeMethodInfoPtr_SetHandController_Private_Void_HandController_0;

	// Token: 0x040040EA RID: 16618
	private static readonly IntPtr NativeMethodInfoPtr_ClearHandController_Private_Void_HandController_0;

	// Token: 0x040040EB RID: 16619
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
