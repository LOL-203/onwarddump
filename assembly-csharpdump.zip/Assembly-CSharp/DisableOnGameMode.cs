﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000D2 RID: 210
public class DisableOnGameMode : MonoBehaviour
{
	// Token: 0x06000CE6 RID: 3302 RVA: 0x000343B4 File Offset: 0x000325B4
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableOnGameMode.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x000343F8 File Offset: 0x000325F8
	[CallerCount(0)]
	public unsafe DisableOnGameMode() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableOnGameMode.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CE8 RID: 3304 RVA: 0x00034444 File Offset: 0x00032644
	// Note: this type is marked as 'beforefieldinit'.
	static DisableOnGameMode()
	{
		Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DisableOnGameMode");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr);
		DisableOnGameMode.NativeFieldInfoPtr_GameModesToDisableOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr, "GameModesToDisableOn");
		DisableOnGameMode.NativeFieldInfoPtr_ToDisable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr, "ToDisable");
		DisableOnGameMode.NativeFieldInfoPtr_currentMode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr, "currentMode");
		DisableOnGameMode.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr, 100664305);
		DisableOnGameMode.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr, 100664306);
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x0000210C File Offset: 0x0000030C
	public DisableOnGameMode(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000471 RID: 1137
	// (get) Token: 0x06000CEA RID: 3306 RVA: 0x000344D8 File Offset: 0x000326D8
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DisableOnGameMode>.NativeClassPtr));
		}
	}

	// Token: 0x17000472 RID: 1138
	// (get) Token: 0x06000CEB RID: 3307 RVA: 0x000344EC File Offset: 0x000326EC
	// (set) Token: 0x06000CEC RID: 3308 RVA: 0x00034520 File Offset: 0x00032720
	public unsafe List<GameVariantTypes> GameModesToDisableOn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_GameModesToDisableOn);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameVariantTypes>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_GameModesToDisableOn), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000473 RID: 1139
	// (get) Token: 0x06000CED RID: 3309 RVA: 0x00034548 File Offset: 0x00032748
	// (set) Token: 0x06000CEE RID: 3310 RVA: 0x0003457C File Offset: 0x0003277C
	public unsafe Il2CppReferenceArray<GameObject> ToDisable
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_ToDisable);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_ToDisable), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000474 RID: 1140
	// (get) Token: 0x06000CEF RID: 3311 RVA: 0x000345A4 File Offset: 0x000327A4
	// (set) Token: 0x06000CF0 RID: 3312 RVA: 0x000345CC File Offset: 0x000327CC
	public unsafe GameVariantTypes currentMode
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_currentMode);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnGameMode.NativeFieldInfoPtr_currentMode)) = value;
		}
	}

	// Token: 0x040007CB RID: 1995
	private static readonly IntPtr NativeFieldInfoPtr_GameModesToDisableOn;

	// Token: 0x040007CC RID: 1996
	private static readonly IntPtr NativeFieldInfoPtr_ToDisable;

	// Token: 0x040007CD RID: 1997
	private static readonly IntPtr NativeFieldInfoPtr_currentMode;

	// Token: 0x040007CE RID: 1998
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x040007CF RID: 1999
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
