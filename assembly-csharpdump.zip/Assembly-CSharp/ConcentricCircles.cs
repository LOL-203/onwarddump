﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000340 RID: 832
public class ConcentricCircles : MonoBehaviour
{
	// Token: 0x060041D0 RID: 16848 RVA: 0x0010992C File Offset: 0x00107B2C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060041D1 RID: 16849 RVA: 0x00109970 File Offset: 0x00107B70
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060041D2 RID: 16850 RVA: 0x001099B4 File Offset: 0x00107BB4
	[CallerCount(0)]
	public unsafe IEnumerator stagger()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles.NativeMethodInfoPtr_stagger_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x060041D3 RID: 16851 RVA: 0x00109A0C File Offset: 0x00107C0C
	[CallerCount(0)]
	public unsafe IEnumerator expand(Transform circle)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(circle);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles.NativeMethodInfoPtr_expand_Private_IEnumerator_Transform_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x060041D4 RID: 16852 RVA: 0x00109A7C File Offset: 0x00107C7C
	[CallerCount(0)]
	public unsafe ConcentricCircles() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060041D5 RID: 16853 RVA: 0x00109AC8 File Offset: 0x00107CC8
	// Note: this type is marked as 'beforefieldinit'.
	static ConcentricCircles()
	{
		Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConcentricCircles");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr);
		ConcentricCircles.NativeFieldInfoPtr_circles = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, "circles");
		ConcentricCircles.NativeFieldInfoPtr_scale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, "scale");
		ConcentricCircles.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, 100668557);
		ConcentricCircles.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, 100668558);
		ConcentricCircles.NativeMethodInfoPtr_stagger_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, 100668559);
		ConcentricCircles.NativeMethodInfoPtr_expand_Private_IEnumerator_Transform_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, 100668560);
		ConcentricCircles.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, 100668561);
	}

	// Token: 0x060041D6 RID: 16854 RVA: 0x0000210C File Offset: 0x0000030C
	public ConcentricCircles(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001752 RID: 5970
	// (get) Token: 0x060041D7 RID: 16855 RVA: 0x00109B84 File Offset: 0x00107D84
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr));
		}
	}

	// Token: 0x17001753 RID: 5971
	// (get) Token: 0x060041D8 RID: 16856 RVA: 0x00109B98 File Offset: 0x00107D98
	// (set) Token: 0x060041D9 RID: 16857 RVA: 0x00109BCC File Offset: 0x00107DCC
	public unsafe List<Transform> circles
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles.NativeFieldInfoPtr_circles);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Transform>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles.NativeFieldInfoPtr_circles), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001754 RID: 5972
	// (get) Token: 0x060041DA RID: 16858 RVA: 0x00109BF4 File Offset: 0x00107DF4
	// (set) Token: 0x060041DB RID: 16859 RVA: 0x00109C1C File Offset: 0x00107E1C
	public unsafe Vector3 scale
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles.NativeFieldInfoPtr_scale);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles.NativeFieldInfoPtr_scale)) = value;
		}
	}

	// Token: 0x04002A44 RID: 10820
	private static readonly IntPtr NativeFieldInfoPtr_circles;

	// Token: 0x04002A45 RID: 10821
	private static readonly IntPtr NativeFieldInfoPtr_scale;

	// Token: 0x04002A46 RID: 10822
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04002A47 RID: 10823
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04002A48 RID: 10824
	private static readonly IntPtr NativeMethodInfoPtr_stagger_Private_IEnumerator_0;

	// Token: 0x04002A49 RID: 10825
	private static readonly IntPtr NativeMethodInfoPtr_expand_Private_IEnumerator_Transform_0;

	// Token: 0x04002A4A RID: 10826
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000341 RID: 833
	[ObfuscatedName("ConcentricCircles/<stagger>d__4")]
	public sealed class _stagger_d__4 : Il2CppSystem.Object
	{
		// Token: 0x060041DC RID: 16860 RVA: 0x00109C40 File Offset: 0x00107E40
		[CallerCount(0)]
		public unsafe _stagger_d__4(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060041DD RID: 16861 RVA: 0x00109CA0 File Offset: 0x00107EA0
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060041DE RID: 16862 RVA: 0x00109CE4 File Offset: 0x00107EE4
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060041DF RID: 16863 RVA: 0x00109D34 File Offset: 0x00107F34
		[CallerCount(0)]
		public unsafe void __m__Finally1()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr___m__Finally1_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700175A RID: 5978
		// (get) Token: 0x060041E0 RID: 16864 RVA: 0x00109D78 File Offset: 0x00107F78
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060041E1 RID: 16865 RVA: 0x00109DD0 File Offset: 0x00107FD0
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700175B RID: 5979
		// (get) Token: 0x060041E2 RID: 16866 RVA: 0x00109E14 File Offset: 0x00108014
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060041E3 RID: 16867 RVA: 0x00109E6C File Offset: 0x0010806C
		// Note: this type is marked as 'beforefieldinit'.
		static _stagger_d__4()
		{
			Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, "<stagger>d__4");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr);
			ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, "<>1__state");
			ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, "<>2__current");
			ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, "<>4__this");
			ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___7__wrap1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, "<>7__wrap1");
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668562);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668563);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668564);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr___m__Finally1_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668565);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668566);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668567);
			ConcentricCircles._stagger_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr, 100668568);
		}

		// Token: 0x060041E4 RID: 16868 RVA: 0x00002988 File Offset: 0x00000B88
		public _stagger_d__4(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001755 RID: 5973
		// (get) Token: 0x060041E5 RID: 16869 RVA: 0x00109F73 File Offset: 0x00108173
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcentricCircles._stagger_d__4>.NativeClassPtr));
			}
		}

		// Token: 0x17001756 RID: 5974
		// (get) Token: 0x060041E6 RID: 16870 RVA: 0x00109F84 File Offset: 0x00108184
		// (set) Token: 0x060041E7 RID: 16871 RVA: 0x00109FAC File Offset: 0x001081AC
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001757 RID: 5975
		// (get) Token: 0x060041E8 RID: 16872 RVA: 0x00109FD0 File Offset: 0x001081D0
		// (set) Token: 0x060041E9 RID: 16873 RVA: 0x0010A004 File Offset: 0x00108204
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001758 RID: 5976
		// (get) Token: 0x060041EA RID: 16874 RVA: 0x0010A02C File Offset: 0x0010822C
		// (set) Token: 0x060041EB RID: 16875 RVA: 0x0010A060 File Offset: 0x00108260
		public unsafe ConcentricCircles __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ConcentricCircles(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001759 RID: 5977
		// (get) Token: 0x060041EC RID: 16876 RVA: 0x0010A088 File Offset: 0x00108288
		// (set) Token: 0x060041ED RID: 16877 RVA: 0x0010A0BA File Offset: 0x001082BA
		public List<Transform>.Enumerator __7__wrap1
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___7__wrap1);
				return new List<Transform>.Enumerator(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<List<Transform>.Enumerator>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._stagger_d__4.NativeFieldInfoPtr___7__wrap1), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<List<Transform>.Enumerator>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x04002A4B RID: 10827
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04002A4C RID: 10828
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04002A4D RID: 10829
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04002A4E RID: 10830
		private static readonly IntPtr NativeFieldInfoPtr___7__wrap1;

		// Token: 0x04002A4F RID: 10831
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04002A50 RID: 10832
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A51 RID: 10833
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04002A52 RID: 10834
		private static readonly IntPtr NativeMethodInfoPtr___m__Finally1_Private_Void_0;

		// Token: 0x04002A53 RID: 10835
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04002A54 RID: 10836
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A55 RID: 10837
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x02000342 RID: 834
	[ObfuscatedName("ConcentricCircles/<expand>d__5")]
	public sealed class _expand_d__5 : Il2CppSystem.Object
	{
		// Token: 0x060041EE RID: 16878 RVA: 0x0010A0F0 File Offset: 0x001082F0
		[CallerCount(0)]
		public unsafe _expand_d__5(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060041EF RID: 16879 RVA: 0x0010A150 File Offset: 0x00108350
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060041F0 RID: 16880 RVA: 0x0010A194 File Offset: 0x00108394
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001765 RID: 5989
		// (get) Token: 0x060041F1 RID: 16881 RVA: 0x0010A1E4 File Offset: 0x001083E4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060041F2 RID: 16882 RVA: 0x0010A23C File Offset: 0x0010843C
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001766 RID: 5990
		// (get) Token: 0x060041F3 RID: 16883 RVA: 0x0010A280 File Offset: 0x00108480
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060041F4 RID: 16884 RVA: 0x0010A2D8 File Offset: 0x001084D8
		// Note: this type is marked as 'beforefieldinit'.
		static _expand_d__5()
		{
			Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcentricCircles>.NativeClassPtr, "<expand>d__5");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr);
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<>1__state");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<>2__current");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr_circle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "circle");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<>4__this");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr__circleCanvas_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<circleCanvas>5__2");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr__time_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<time>5__3");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr__originalTime_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<originalTime>5__4");
			ConcentricCircles._expand_d__5.NativeFieldInfoPtr__newScale_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, "<newScale>5__5");
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668569);
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668570);
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668571);
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668572);
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668573);
			ConcentricCircles._expand_d__5.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr, 100668574);
		}

		// Token: 0x060041F5 RID: 16885 RVA: 0x00002988 File Offset: 0x00000B88
		public _expand_d__5(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700175C RID: 5980
		// (get) Token: 0x060041F6 RID: 16886 RVA: 0x0010A41B File Offset: 0x0010861B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcentricCircles._expand_d__5>.NativeClassPtr));
			}
		}

		// Token: 0x1700175D RID: 5981
		// (get) Token: 0x060041F7 RID: 16887 RVA: 0x0010A42C File Offset: 0x0010862C
		// (set) Token: 0x060041F8 RID: 16888 RVA: 0x0010A454 File Offset: 0x00108654
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700175E RID: 5982
		// (get) Token: 0x060041F9 RID: 16889 RVA: 0x0010A478 File Offset: 0x00108678
		// (set) Token: 0x060041FA RID: 16890 RVA: 0x0010A4AC File Offset: 0x001086AC
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700175F RID: 5983
		// (get) Token: 0x060041FB RID: 16891 RVA: 0x0010A4D4 File Offset: 0x001086D4
		// (set) Token: 0x060041FC RID: 16892 RVA: 0x0010A508 File Offset: 0x00108708
		public unsafe Transform circle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr_circle);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr_circle), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001760 RID: 5984
		// (get) Token: 0x060041FD RID: 16893 RVA: 0x0010A530 File Offset: 0x00108730
		// (set) Token: 0x060041FE RID: 16894 RVA: 0x0010A564 File Offset: 0x00108764
		public unsafe ConcentricCircles __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ConcentricCircles(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001761 RID: 5985
		// (get) Token: 0x060041FF RID: 16895 RVA: 0x0010A58C File Offset: 0x0010878C
		// (set) Token: 0x06004200 RID: 16896 RVA: 0x0010A5C0 File Offset: 0x001087C0
		public unsafe CanvasGroup _circleCanvas_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__circleCanvas_5__2);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CanvasGroup(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__circleCanvas_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001762 RID: 5986
		// (get) Token: 0x06004201 RID: 16897 RVA: 0x0010A5E8 File Offset: 0x001087E8
		// (set) Token: 0x06004202 RID: 16898 RVA: 0x0010A610 File Offset: 0x00108810
		public unsafe float _time_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__time_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__time_5__3)) = value;
			}
		}

		// Token: 0x17001763 RID: 5987
		// (get) Token: 0x06004203 RID: 16899 RVA: 0x0010A634 File Offset: 0x00108834
		// (set) Token: 0x06004204 RID: 16900 RVA: 0x0010A65C File Offset: 0x0010885C
		public unsafe float _originalTime_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__originalTime_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__originalTime_5__4)) = value;
			}
		}

		// Token: 0x17001764 RID: 5988
		// (get) Token: 0x06004205 RID: 16901 RVA: 0x0010A680 File Offset: 0x00108880
		// (set) Token: 0x06004206 RID: 16902 RVA: 0x0010A6A8 File Offset: 0x001088A8
		public unsafe Vector3 _newScale_5__5
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__newScale_5__5);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcentricCircles._expand_d__5.NativeFieldInfoPtr__newScale_5__5)) = value;
			}
		}

		// Token: 0x04002A56 RID: 10838
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04002A57 RID: 10839
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04002A58 RID: 10840
		private static readonly IntPtr NativeFieldInfoPtr_circle;

		// Token: 0x04002A59 RID: 10841
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04002A5A RID: 10842
		private static readonly IntPtr NativeFieldInfoPtr__circleCanvas_5__2;

		// Token: 0x04002A5B RID: 10843
		private static readonly IntPtr NativeFieldInfoPtr__time_5__3;

		// Token: 0x04002A5C RID: 10844
		private static readonly IntPtr NativeFieldInfoPtr__originalTime_5__4;

		// Token: 0x04002A5D RID: 10845
		private static readonly IntPtr NativeFieldInfoPtr__newScale_5__5;

		// Token: 0x04002A5E RID: 10846
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04002A5F RID: 10847
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A60 RID: 10848
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04002A61 RID: 10849
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04002A62 RID: 10850
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A63 RID: 10851
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
