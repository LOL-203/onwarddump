﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AC RID: 2220
	public class LayoutObject : Object
	{
		// Token: 0x170040F2 RID: 16626
		// (get) Token: 0x0600B611 RID: 46609 RVA: 0x002E8E60 File Offset: 0x002E7060
		// (set) Token: 0x0600B612 RID: 46610 RVA: 0x002E8EB0 File Offset: 0x002E70B0
		public unsafe int Index
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_get_Index_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040F3 RID: 16627
		// (get) Token: 0x0600B613 RID: 46611 RVA: 0x002E8F04 File Offset: 0x002E7104
		// (set) Token: 0x0600B614 RID: 46612 RVA: 0x002E8F54 File Offset: 0x002E7154
		public unsafe float X
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_get_X_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_set_X_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040F4 RID: 16628
		// (get) Token: 0x0600B615 RID: 46613 RVA: 0x002E8FA8 File Offset: 0x002E71A8
		// (set) Token: 0x0600B616 RID: 46614 RVA: 0x002E8FF8 File Offset: 0x002E71F8
		public unsafe float Y
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_get_Y_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B617 RID: 46615 RVA: 0x002E904C File Offset: 0x002E724C
		[CallerCount(0)]
		public unsafe static LayoutObject ToLayoutObject(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_ToLayoutObject_Internal_Static_LayoutObject_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new LayoutObject(intPtr2) : null;
		}

		// Token: 0x0600B618 RID: 46616 RVA: 0x002E90AC File Offset: 0x002E72AC
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B619 RID: 46617 RVA: 0x002E9104 File Offset: 0x002E7304
		[CallerCount(0)]
		public unsafe LayoutObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LayoutObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B61A RID: 46618 RVA: 0x002E9150 File Offset: 0x002E7350
		// Note: this type is marked as 'beforefieldinit'.
		static LayoutObject()
		{
			Il2CppClassPointerStore<LayoutObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "LayoutObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr);
			LayoutObject.NativeFieldInfoPtr__Index_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, "<Index>k__BackingField");
			LayoutObject.NativeFieldInfoPtr__X_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, "<X>k__BackingField");
			LayoutObject.NativeFieldInfoPtr__Y_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, "<Y>k__BackingField");
			LayoutObject.NativeMethodInfoPtr_get_Index_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678074);
			LayoutObject.NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678075);
			LayoutObject.NativeMethodInfoPtr_get_X_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678076);
			LayoutObject.NativeMethodInfoPtr_set_X_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678077);
			LayoutObject.NativeMethodInfoPtr_get_Y_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678078);
			LayoutObject.NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678079);
			LayoutObject.NativeMethodInfoPtr_ToLayoutObject_Internal_Static_LayoutObject_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678080);
			LayoutObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678081);
			LayoutObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr, 100678082);
		}

		// Token: 0x0600B61B RID: 46619 RVA: 0x00002988 File Offset: 0x00000B88
		public LayoutObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040EE RID: 16622
		// (get) Token: 0x0600B61C RID: 46620 RVA: 0x002E9270 File Offset: 0x002E7470
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<LayoutObject>.NativeClassPtr));
			}
		}

		// Token: 0x170040EF RID: 16623
		// (get) Token: 0x0600B61D RID: 46621 RVA: 0x002E9284 File Offset: 0x002E7484
		// (set) Token: 0x0600B61E RID: 46622 RVA: 0x002E92AC File Offset: 0x002E74AC
		public unsafe int _Index_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__Index_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__Index_k__BackingField)) = value;
			}
		}

		// Token: 0x170040F0 RID: 16624
		// (get) Token: 0x0600B61F RID: 46623 RVA: 0x002E92D0 File Offset: 0x002E74D0
		// (set) Token: 0x0600B620 RID: 46624 RVA: 0x002E92F8 File Offset: 0x002E74F8
		public unsafe float _X_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__X_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__X_k__BackingField)) = value;
			}
		}

		// Token: 0x170040F1 RID: 16625
		// (get) Token: 0x0600B621 RID: 46625 RVA: 0x002E931C File Offset: 0x002E751C
		// (set) Token: 0x0600B622 RID: 46626 RVA: 0x002E9344 File Offset: 0x002E7544
		public unsafe float _Y_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__Y_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LayoutObject.NativeFieldInfoPtr__Y_k__BackingField)) = value;
			}
		}

		// Token: 0x040074A4 RID: 29860
		private static readonly IntPtr NativeFieldInfoPtr__Index_k__BackingField;

		// Token: 0x040074A5 RID: 29861
		private static readonly IntPtr NativeFieldInfoPtr__X_k__BackingField;

		// Token: 0x040074A6 RID: 29862
		private static readonly IntPtr NativeFieldInfoPtr__Y_k__BackingField;

		// Token: 0x040074A7 RID: 29863
		private static readonly IntPtr NativeMethodInfoPtr_get_Index_Public_get_Int32_0;

		// Token: 0x040074A8 RID: 29864
		private static readonly IntPtr NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0;

		// Token: 0x040074A9 RID: 29865
		private static readonly IntPtr NativeMethodInfoPtr_get_X_Public_get_Single_0;

		// Token: 0x040074AA RID: 29866
		private static readonly IntPtr NativeMethodInfoPtr_set_X_Public_set_Void_Single_0;

		// Token: 0x040074AB RID: 29867
		private static readonly IntPtr NativeMethodInfoPtr_get_Y_Public_get_Single_0;

		// Token: 0x040074AC RID: 29868
		private static readonly IntPtr NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0;

		// Token: 0x040074AD RID: 29869
		private static readonly IntPtr NativeMethodInfoPtr_ToLayoutObject_Internal_Static_LayoutObject_JSONObject_0;

		// Token: 0x040074AE RID: 29870
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074AF RID: 29871
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
