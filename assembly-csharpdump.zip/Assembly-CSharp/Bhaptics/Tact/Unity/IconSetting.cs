﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A1 RID: 2209
	[Serializable]
	public class IconSetting : Object
	{
		// Token: 0x0600B518 RID: 46360 RVA: 0x002E4AC4 File Offset: 0x002E2CC4
		[CallerCount(0)]
		public unsafe IconSetting() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<IconSetting>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IconSetting.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B519 RID: 46361 RVA: 0x002E4B10 File Offset: 0x002E2D10
		// Note: this type is marked as 'beforefieldinit'.
		static IconSetting()
		{
			Il2CppClassPointerStore<IconSetting>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "IconSetting");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<IconSetting>.NativeClassPtr);
			IconSetting.NativeFieldInfoPtr_Vest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "Vest");
			IconSetting.NativeFieldInfoPtr_Head = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "Head");
			IconSetting.NativeFieldInfoPtr_Arm = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "Arm");
			IconSetting.NativeFieldInfoPtr_Foot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "Foot");
			IconSetting.NativeFieldInfoPtr_Hand = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "Hand");
			IconSetting.NativeFieldInfoPtr_GloveL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "GloveL");
			IconSetting.NativeFieldInfoPtr_GloveR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, "GloveR");
			IconSetting.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IconSetting>.NativeClassPtr, 100677974);
		}

		// Token: 0x0600B51A RID: 46362 RVA: 0x00002988 File Offset: 0x00000B88
		public IconSetting(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040A0 RID: 16544
		// (get) Token: 0x0600B51B RID: 46363 RVA: 0x002E4BE0 File Offset: 0x002E2DE0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<IconSetting>.NativeClassPtr));
			}
		}

		// Token: 0x170040A1 RID: 16545
		// (get) Token: 0x0600B51C RID: 46364 RVA: 0x002E4BF4 File Offset: 0x002E2DF4
		// (set) Token: 0x0600B51D RID: 46365 RVA: 0x002E4C28 File Offset: 0x002E2E28
		public unsafe PositonIconSetting Vest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Vest);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Vest), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A2 RID: 16546
		// (get) Token: 0x0600B51E RID: 46366 RVA: 0x002E4C50 File Offset: 0x002E2E50
		// (set) Token: 0x0600B51F RID: 46367 RVA: 0x002E4C84 File Offset: 0x002E2E84
		public unsafe PositonIconSetting Head
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Head);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Head), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A3 RID: 16547
		// (get) Token: 0x0600B520 RID: 46368 RVA: 0x002E4CAC File Offset: 0x002E2EAC
		// (set) Token: 0x0600B521 RID: 46369 RVA: 0x002E4CE0 File Offset: 0x002E2EE0
		public unsafe PositonIconSetting Arm
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Arm);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Arm), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A4 RID: 16548
		// (get) Token: 0x0600B522 RID: 46370 RVA: 0x002E4D08 File Offset: 0x002E2F08
		// (set) Token: 0x0600B523 RID: 46371 RVA: 0x002E4D3C File Offset: 0x002E2F3C
		public unsafe PositonIconSetting Foot
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Foot);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Foot), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A5 RID: 16549
		// (get) Token: 0x0600B524 RID: 46372 RVA: 0x002E4D64 File Offset: 0x002E2F64
		// (set) Token: 0x0600B525 RID: 46373 RVA: 0x002E4D98 File Offset: 0x002E2F98
		public unsafe PositonIconSetting Hand
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Hand);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_Hand), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A6 RID: 16550
		// (get) Token: 0x0600B526 RID: 46374 RVA: 0x002E4DC0 File Offset: 0x002E2FC0
		// (set) Token: 0x0600B527 RID: 46375 RVA: 0x002E4DF4 File Offset: 0x002E2FF4
		public unsafe PositonIconSetting GloveL
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_GloveL);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_GloveL), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040A7 RID: 16551
		// (get) Token: 0x0600B528 RID: 46376 RVA: 0x002E4E1C File Offset: 0x002E301C
		// (set) Token: 0x0600B529 RID: 46377 RVA: 0x002E4E50 File Offset: 0x002E3050
		public unsafe PositonIconSetting GloveR
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_GloveR);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PositonIconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(IconSetting.NativeFieldInfoPtr_GloveR), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007407 RID: 29703
		private static readonly IntPtr NativeFieldInfoPtr_Vest;

		// Token: 0x04007408 RID: 29704
		private static readonly IntPtr NativeFieldInfoPtr_Head;

		// Token: 0x04007409 RID: 29705
		private static readonly IntPtr NativeFieldInfoPtr_Arm;

		// Token: 0x0400740A RID: 29706
		private static readonly IntPtr NativeFieldInfoPtr_Foot;

		// Token: 0x0400740B RID: 29707
		private static readonly IntPtr NativeFieldInfoPtr_Hand;

		// Token: 0x0400740C RID: 29708
		private static readonly IntPtr NativeFieldInfoPtr_GloveL;

		// Token: 0x0400740D RID: 29709
		private static readonly IntPtr NativeFieldInfoPtr_GloveR;

		// Token: 0x0400740E RID: 29710
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
