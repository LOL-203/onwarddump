﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A7 RID: 2215
	public class BhapticsProject : Object
	{
		// Token: 0x170040DB RID: 16603
		// (get) Token: 0x0600B5D0 RID: 46544 RVA: 0x002E7BE8 File Offset: 0x002E5DE8
		// (set) Token: 0x0600B5D1 RID: 46545 RVA: 0x002E7C40 File Offset: 0x002E5E40
		public unsafe Il2CppReferenceArray<Track> Tracks
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_get_Tracks_Public_get_ArrayOf_Track_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Track>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_set_Tracks_Public_set_Void_ArrayOf_Track_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040DC RID: 16604
		// (get) Token: 0x0600B5D2 RID: 46546 RVA: 0x002E7C9C File Offset: 0x002E5E9C
		// (set) Token: 0x0600B5D3 RID: 46547 RVA: 0x002E7CF4 File Offset: 0x002E5EF4
		public unsafe Layout Layout
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_get_Layout_Public_get_Layout_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Layout(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_set_Layout_Public_set_Void_Layout_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B5D4 RID: 46548 RVA: 0x002E7D50 File Offset: 0x002E5F50
		[CallerCount(0)]
		public unsafe static BhapticsProject ToProject(JSONObject jsonObject)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObject);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_ToProject_Public_Static_BhapticsProject_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new BhapticsProject(intPtr2) : null;
		}

		// Token: 0x0600B5D5 RID: 46549 RVA: 0x002E7DB0 File Offset: 0x002E5FB0
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr_ToJsonObject_Public_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B5D6 RID: 46550 RVA: 0x002E7E08 File Offset: 0x002E6008
		[CallerCount(0)]
		public unsafe BhapticsProject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsProject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5D7 RID: 46551 RVA: 0x002E7E54 File Offset: 0x002E6054
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsProject()
		{
			Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "BhapticsProject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr);
			BhapticsProject.NativeFieldInfoPtr__Tracks_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, "<Tracks>k__BackingField");
			BhapticsProject.NativeFieldInfoPtr__Layout_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, "<Layout>k__BackingField");
			BhapticsProject.NativeMethodInfoPtr_get_Tracks_Public_get_ArrayOf_Track_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678042);
			BhapticsProject.NativeMethodInfoPtr_set_Tracks_Public_set_Void_ArrayOf_Track_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678043);
			BhapticsProject.NativeMethodInfoPtr_get_Layout_Public_get_Layout_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678044);
			BhapticsProject.NativeMethodInfoPtr_set_Layout_Public_set_Void_Layout_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678045);
			BhapticsProject.NativeMethodInfoPtr_ToProject_Public_Static_BhapticsProject_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678046);
			BhapticsProject.NativeMethodInfoPtr_ToJsonObject_Public_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678047);
			BhapticsProject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr, 100678048);
		}

		// Token: 0x0600B5D8 RID: 46552 RVA: 0x00002988 File Offset: 0x00000B88
		public BhapticsProject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040D8 RID: 16600
		// (get) Token: 0x0600B5D9 RID: 46553 RVA: 0x002E7F38 File Offset: 0x002E6138
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsProject>.NativeClassPtr));
			}
		}

		// Token: 0x170040D9 RID: 16601
		// (get) Token: 0x0600B5DA RID: 46554 RVA: 0x002E7F4C File Offset: 0x002E614C
		// (set) Token: 0x0600B5DB RID: 46555 RVA: 0x002E7F80 File Offset: 0x002E6180
		public unsafe Il2CppReferenceArray<Track> _Tracks_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsProject.NativeFieldInfoPtr__Tracks_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Track>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsProject.NativeFieldInfoPtr__Tracks_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040DA RID: 16602
		// (get) Token: 0x0600B5DC RID: 46556 RVA: 0x002E7FA8 File Offset: 0x002E61A8
		// (set) Token: 0x0600B5DD RID: 46557 RVA: 0x002E7FDC File Offset: 0x002E61DC
		public unsafe Layout _Layout_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsProject.NativeFieldInfoPtr__Layout_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Layout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsProject.NativeFieldInfoPtr__Layout_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400747B RID: 29819
		private static readonly IntPtr NativeFieldInfoPtr__Tracks_k__BackingField;

		// Token: 0x0400747C RID: 29820
		private static readonly IntPtr NativeFieldInfoPtr__Layout_k__BackingField;

		// Token: 0x0400747D RID: 29821
		private static readonly IntPtr NativeMethodInfoPtr_get_Tracks_Public_get_ArrayOf_Track_0;

		// Token: 0x0400747E RID: 29822
		private static readonly IntPtr NativeMethodInfoPtr_set_Tracks_Public_set_Void_ArrayOf_Track_0;

		// Token: 0x0400747F RID: 29823
		private static readonly IntPtr NativeMethodInfoPtr_get_Layout_Public_get_Layout_0;

		// Token: 0x04007480 RID: 29824
		private static readonly IntPtr NativeMethodInfoPtr_set_Layout_Public_set_Void_Layout_0;

		// Token: 0x04007481 RID: 29825
		private static readonly IntPtr NativeMethodInfoPtr_ToProject_Public_Static_BhapticsProject_JSONObject_0;

		// Token: 0x04007482 RID: 29826
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Public_JSONObject_0;

		// Token: 0x04007483 RID: 29827
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
