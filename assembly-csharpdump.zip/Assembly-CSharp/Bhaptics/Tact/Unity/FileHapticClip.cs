﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B8 RID: 2232
	public class FileHapticClip : HapticClip
	{
		// Token: 0x17004133 RID: 16691
		// (get) Token: 0x0600B6C2 RID: 46786 RVA: 0x002EBD80 File Offset: 0x002E9F80
		public unsafe int ClipDurationTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(FileHapticClip.NativeMethodInfoPtr_get_ClipDurationTime_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600B6C3 RID: 46787 RVA: 0x002EBDD0 File Offset: 0x002E9FD0
		[CallerCount(0)]
		public new unsafe void Play()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C4 RID: 46788 RVA: 0x002EBE20 File Offset: 0x002EA020
		[CallerCount(0)]
		public new unsafe void Play(string identifier)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C5 RID: 46789 RVA: 0x002EBE84 File Offset: 0x002EA084
		[CallerCount(0)]
		public new unsafe void Play(float intensity, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C6 RID: 46790 RVA: 0x002EBEFC File Offset: 0x002EA0FC
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C7 RID: 46791 RVA: 0x002EBF88 File Offset: 0x002EA188
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C8 RID: 46792 RVA: 0x002EC028 File Offset: 0x002EA228
		[CallerCount(0)]
		public new unsafe void Play(Vector3 contactPos, Collider targetCollider, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref contactPos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(targetCollider);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Collider_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6C9 RID: 46793 RVA: 0x002EC0B8 File Offset: 0x002EA2B8
		[CallerCount(0)]
		public new unsafe void Play(Vector3 contactPos, Vector3 targetPos, Vector3 targetForward, float targetHeight, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref contactPos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetForward;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetHeight;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Vector3_Vector3_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6CA RID: 46794 RVA: 0x002EC168 File Offset: 0x002EA368
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, float vestRotationOffsetY, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationOffsetY;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6CB RID: 46795 RVA: 0x002EC218 File Offset: 0x002EA418
		[CallerCount(0)]
		public new unsafe void ResetValues()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), FileHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6CC RID: 46796 RVA: 0x002EC268 File Offset: 0x002EA468
		[CallerCount(0)]
		public unsafe int CalculateClipDutationTime(HapticFeedbackFile hapticFeedbackFile)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(hapticFeedbackFile);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(FileHapticClip.NativeMethodInfoPtr_CalculateClipDutationTime_Private_Int32_HapticFeedbackFile_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B6CD RID: 46797 RVA: 0x002EC2D0 File Offset: 0x002EA4D0
		[CallerCount(0)]
		public unsafe FileHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(FileHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6CE RID: 46798 RVA: 0x002EC31C File Offset: 0x002EA51C
		// Note: this type is marked as 'beforefieldinit'.
		static FileHapticClip()
		{
			Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "FileHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr);
			FileHapticClip.NativeFieldInfoPtr_Intensity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, "Intensity");
			FileHapticClip.NativeFieldInfoPtr_Duration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, "Duration");
			FileHapticClip.NativeFieldInfoPtr_ClipType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, "ClipType");
			FileHapticClip.NativeFieldInfoPtr_JsonValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, "JsonValue");
			FileHapticClip.NativeFieldInfoPtr__clipDurationTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, "_clipDurationTime");
			FileHapticClip.NativeMethodInfoPtr_get_ClipDurationTime_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678151);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678152);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678153);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678154);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678155);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678156);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Collider_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678157);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Vector3_Vector3_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678158);
			FileHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678159);
			FileHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678160);
			FileHapticClip.NativeMethodInfoPtr_CalculateClipDutationTime_Private_Int32_HapticFeedbackFile_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678161);
			FileHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr, 100678162);
		}

		// Token: 0x0600B6CF RID: 46799 RVA: 0x002EC4A0 File Offset: 0x002EA6A0
		public FileHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700412D RID: 16685
		// (get) Token: 0x0600B6D0 RID: 46800 RVA: 0x002EC4A9 File Offset: 0x002EA6A9
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<FileHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x1700412E RID: 16686
		// (get) Token: 0x0600B6D1 RID: 46801 RVA: 0x002EC4BC File Offset: 0x002EA6BC
		// (set) Token: 0x0600B6D2 RID: 46802 RVA: 0x002EC4E4 File Offset: 0x002EA6E4
		public unsafe float Intensity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_Intensity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_Intensity)) = value;
			}
		}

		// Token: 0x1700412F RID: 16687
		// (get) Token: 0x0600B6D3 RID: 46803 RVA: 0x002EC508 File Offset: 0x002EA708
		// (set) Token: 0x0600B6D4 RID: 46804 RVA: 0x002EC530 File Offset: 0x002EA730
		public unsafe float Duration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_Duration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_Duration)) = value;
			}
		}

		// Token: 0x17004130 RID: 16688
		// (get) Token: 0x0600B6D5 RID: 46805 RVA: 0x002EC554 File Offset: 0x002EA754
		// (set) Token: 0x0600B6D6 RID: 46806 RVA: 0x002EC57C File Offset: 0x002EA77C
		public unsafe HapticDeviceType ClipType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_ClipType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_ClipType)) = value;
			}
		}

		// Token: 0x17004131 RID: 16689
		// (get) Token: 0x0600B6D7 RID: 46807 RVA: 0x002EC5A0 File Offset: 0x002EA7A0
		// (set) Token: 0x0600B6D8 RID: 46808 RVA: 0x002EC5C9 File Offset: 0x002EA7C9
		public unsafe string JsonValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_JsonValue);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr_JsonValue), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004132 RID: 16690
		// (get) Token: 0x0600B6D9 RID: 46809 RVA: 0x002EC5F0 File Offset: 0x002EA7F0
		// (set) Token: 0x0600B6DA RID: 46810 RVA: 0x002EC618 File Offset: 0x002EA818
		public unsafe int _clipDurationTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr__clipDurationTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(FileHapticClip.NativeFieldInfoPtr__clipDurationTime)) = value;
			}
		}

		// Token: 0x04007513 RID: 29971
		private static readonly IntPtr NativeFieldInfoPtr_Intensity;

		// Token: 0x04007514 RID: 29972
		private static readonly IntPtr NativeFieldInfoPtr_Duration;

		// Token: 0x04007515 RID: 29973
		private static readonly IntPtr NativeFieldInfoPtr_ClipType;

		// Token: 0x04007516 RID: 29974
		private static readonly IntPtr NativeFieldInfoPtr_JsonValue;

		// Token: 0x04007517 RID: 29975
		private static readonly IntPtr NativeFieldInfoPtr__clipDurationTime;

		// Token: 0x04007518 RID: 29976
		private static readonly IntPtr NativeMethodInfoPtr_get_ClipDurationTime_Public_get_Int32_0;

		// Token: 0x04007519 RID: 29977
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_0;

		// Token: 0x0400751A RID: 29978
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0;

		// Token: 0x0400751B RID: 29979
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0;

		// Token: 0x0400751C RID: 29980
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0;

		// Token: 0x0400751D RID: 29981
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0;

		// Token: 0x0400751E RID: 29982
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Collider_String_0;

		// Token: 0x0400751F RID: 29983
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Vector3_Vector3_Vector3_Single_String_0;

		// Token: 0x04007520 RID: 29984
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0;

		// Token: 0x04007521 RID: 29985
		private static readonly IntPtr NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0;

		// Token: 0x04007522 RID: 29986
		private static readonly IntPtr NativeMethodInfoPtr_CalculateClipDutationTime_Private_Int32_HapticFeedbackFile_0;

		// Token: 0x04007523 RID: 29987
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
