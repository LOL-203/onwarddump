﻿using System;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008BC RID: 2236
	[Serializable]
	public enum HapticClipPositionType
	{
		// Token: 0x0400752F RID: 29999
		VestFront,
		// Token: 0x04007530 RID: 30000
		VestBack,
		// Token: 0x04007531 RID: 30001
		Head,
		// Token: 0x04007532 RID: 30002
		RightForearm,
		// Token: 0x04007533 RID: 30003
		LeftForearm,
		// Token: 0x04007534 RID: 30004
		LeftHand,
		// Token: 0x04007535 RID: 30005
		RightHand,
		// Token: 0x04007536 RID: 30006
		LeftFoot,
		// Token: 0x04007537 RID: 30007
		RightFoot,
		// Token: 0x04007538 RID: 30008
		LeftGlove,
		// Token: 0x04007539 RID: 30009
		RightGlove
	}
}
