﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AF RID: 2223
	public class DotModeObjectCollection : Object
	{
		// Token: 0x17004106 RID: 16646
		// (get) Token: 0x0600B643 RID: 46659 RVA: 0x002E9CAC File Offset: 0x002E7EAC
		// (set) Token: 0x0600B644 RID: 46660 RVA: 0x002E9CFC File Offset: 0x002E7EFC
		public unsafe int StartTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17004107 RID: 16647
		// (get) Token: 0x0600B645 RID: 46661 RVA: 0x002E9D50 File Offset: 0x002E7F50
		// (set) Token: 0x0600B646 RID: 46662 RVA: 0x002E9DA0 File Offset: 0x002E7FA0
		public unsafe int EndTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_get_EndTime_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_set_EndTime_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17004108 RID: 16648
		// (get) Token: 0x0600B647 RID: 46663 RVA: 0x002E9DF4 File Offset: 0x002E7FF4
		// (set) Token: 0x0600B648 RID: 46664 RVA: 0x002E9E4C File Offset: 0x002E804C
		public unsafe Il2CppReferenceArray<DotModeObject> PointList
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_DotModeObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<DotModeObject>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_DotModeObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B649 RID: 46665 RVA: 0x002E9EA8 File Offset: 0x002E80A8
		[CallerCount(0)]
		public unsafe static DotModeObjectCollection ToObject(JSONObject val)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(val);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObjectCollection_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DotModeObjectCollection(intPtr2) : null;
		}

		// Token: 0x0600B64A RID: 46666 RVA: 0x002E9F08 File Offset: 0x002E8108
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B64B RID: 46667 RVA: 0x002E9F60 File Offset: 0x002E8160
		[CallerCount(0)]
		public unsafe DotModeObjectCollection() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObjectCollection.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B64C RID: 46668 RVA: 0x002E9FAC File Offset: 0x002E81AC
		// Note: this type is marked as 'beforefieldinit'.
		static DotModeObjectCollection()
		{
			Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "DotModeObjectCollection");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr);
			DotModeObjectCollection.NativeFieldInfoPtr__StartTime_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, "<StartTime>k__BackingField");
			DotModeObjectCollection.NativeFieldInfoPtr__EndTime_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, "<EndTime>k__BackingField");
			DotModeObjectCollection.NativeFieldInfoPtr_PlaybackType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, "PlaybackType");
			DotModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, "<PointList>k__BackingField");
			DotModeObjectCollection.NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678099);
			DotModeObjectCollection.NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678100);
			DotModeObjectCollection.NativeMethodInfoPtr_get_EndTime_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678101);
			DotModeObjectCollection.NativeMethodInfoPtr_set_EndTime_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678102);
			DotModeObjectCollection.NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_DotModeObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678103);
			DotModeObjectCollection.NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_DotModeObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678104);
			DotModeObjectCollection.NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObjectCollection_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678105);
			DotModeObjectCollection.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678106);
			DotModeObjectCollection.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr, 100678107);
		}

		// Token: 0x0600B64D RID: 46669 RVA: 0x00002988 File Offset: 0x00000B88
		public DotModeObjectCollection(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004101 RID: 16641
		// (get) Token: 0x0600B64E RID: 46670 RVA: 0x002EA0E0 File Offset: 0x002E82E0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DotModeObjectCollection>.NativeClassPtr));
			}
		}

		// Token: 0x17004102 RID: 16642
		// (get) Token: 0x0600B64F RID: 46671 RVA: 0x002EA0F4 File Offset: 0x002E82F4
		// (set) Token: 0x0600B650 RID: 46672 RVA: 0x002EA11C File Offset: 0x002E831C
		public unsafe int _StartTime_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__StartTime_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__StartTime_k__BackingField)) = value;
			}
		}

		// Token: 0x17004103 RID: 16643
		// (get) Token: 0x0600B651 RID: 46673 RVA: 0x002EA140 File Offset: 0x002E8340
		// (set) Token: 0x0600B652 RID: 46674 RVA: 0x002EA168 File Offset: 0x002E8368
		public unsafe int _EndTime_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__EndTime_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__EndTime_k__BackingField)) = value;
			}
		}

		// Token: 0x17004104 RID: 16644
		// (get) Token: 0x0600B653 RID: 46675 RVA: 0x002EA18C File Offset: 0x002E838C
		// (set) Token: 0x0600B654 RID: 46676 RVA: 0x002EA1B4 File Offset: 0x002E83B4
		public unsafe PlaybackType PlaybackType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr_PlaybackType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr_PlaybackType)) = value;
			}
		}

		// Token: 0x17004105 RID: 16645
		// (get) Token: 0x0600B655 RID: 46677 RVA: 0x002EA1D8 File Offset: 0x002E83D8
		// (set) Token: 0x0600B656 RID: 46678 RVA: 0x002EA20C File Offset: 0x002E840C
		public unsafe Il2CppReferenceArray<DotModeObject> _PointList_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<DotModeObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040074C5 RID: 29893
		private static readonly IntPtr NativeFieldInfoPtr__StartTime_k__BackingField;

		// Token: 0x040074C6 RID: 29894
		private static readonly IntPtr NativeFieldInfoPtr__EndTime_k__BackingField;

		// Token: 0x040074C7 RID: 29895
		private static readonly IntPtr NativeFieldInfoPtr_PlaybackType;

		// Token: 0x040074C8 RID: 29896
		private static readonly IntPtr NativeFieldInfoPtr__PointList_k__BackingField;

		// Token: 0x040074C9 RID: 29897
		private static readonly IntPtr NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0;

		// Token: 0x040074CA RID: 29898
		private static readonly IntPtr NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0;

		// Token: 0x040074CB RID: 29899
		private static readonly IntPtr NativeMethodInfoPtr_get_EndTime_Public_get_Int32_0;

		// Token: 0x040074CC RID: 29900
		private static readonly IntPtr NativeMethodInfoPtr_set_EndTime_Public_set_Void_Int32_0;

		// Token: 0x040074CD RID: 29901
		private static readonly IntPtr NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_DotModeObject_0;

		// Token: 0x040074CE RID: 29902
		private static readonly IntPtr NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_DotModeObject_0;

		// Token: 0x040074CF RID: 29903
		private static readonly IntPtr NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObjectCollection_JSONObject_0;

		// Token: 0x040074D0 RID: 29904
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074D1 RID: 29905
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
