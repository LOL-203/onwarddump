﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AB RID: 2219
	public class Layout : Object
	{
		// Token: 0x170040EC RID: 16620
		// (get) Token: 0x0600B603 RID: 46595 RVA: 0x002E8A5C File Offset: 0x002E6C5C
		// (set) Token: 0x0600B604 RID: 46596 RVA: 0x002E8AA8 File Offset: 0x002E6CA8
		public unsafe string Type
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_get_Type_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_set_Type_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040ED RID: 16621
		// (get) Token: 0x0600B605 RID: 46597 RVA: 0x002E8B04 File Offset: 0x002E6D04
		// (set) Token: 0x0600B606 RID: 46598 RVA: 0x002E8B5C File Offset: 0x002E6D5C
		public unsafe Dictionary<string, Il2CppReferenceArray<LayoutObject>> Layouts
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_get_Layouts_Public_get_Dictionary_2_String_ArrayOf_LayoutObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, Il2CppReferenceArray<LayoutObject>>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_set_Layouts_Public_set_Void_Dictionary_2_String_ArrayOf_LayoutObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B607 RID: 46599 RVA: 0x002E8BB8 File Offset: 0x002E6DB8
		[CallerCount(0)]
		public unsafe static Layout ToLayout(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_ToLayout_Internal_Static_Layout_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Layout(intPtr2) : null;
		}

		// Token: 0x0600B608 RID: 46600 RVA: 0x002E8C18 File Offset: 0x002E6E18
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B609 RID: 46601 RVA: 0x002E8C70 File Offset: 0x002E6E70
		[CallerCount(0)]
		public unsafe Layout() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Layout>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Layout.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B60A RID: 46602 RVA: 0x002E8CBC File Offset: 0x002E6EBC
		// Note: this type is marked as 'beforefieldinit'.
		static Layout()
		{
			Il2CppClassPointerStore<Layout>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "Layout");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Layout>.NativeClassPtr);
			Layout.NativeFieldInfoPtr__Type_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Layout>.NativeClassPtr, "<Type>k__BackingField");
			Layout.NativeFieldInfoPtr__Layouts_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Layout>.NativeClassPtr, "<Layouts>k__BackingField");
			Layout.NativeMethodInfoPtr_get_Type_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678067);
			Layout.NativeMethodInfoPtr_set_Type_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678068);
			Layout.NativeMethodInfoPtr_get_Layouts_Public_get_Dictionary_2_String_ArrayOf_LayoutObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678069);
			Layout.NativeMethodInfoPtr_set_Layouts_Public_set_Void_Dictionary_2_String_ArrayOf_LayoutObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678070);
			Layout.NativeMethodInfoPtr_ToLayout_Internal_Static_Layout_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678071);
			Layout.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678072);
			Layout.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Layout>.NativeClassPtr, 100678073);
		}

		// Token: 0x0600B60B RID: 46603 RVA: 0x00002988 File Offset: 0x00000B88
		public Layout(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040E9 RID: 16617
		// (get) Token: 0x0600B60C RID: 46604 RVA: 0x002E8DA0 File Offset: 0x002E6FA0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Layout>.NativeClassPtr));
			}
		}

		// Token: 0x170040EA RID: 16618
		// (get) Token: 0x0600B60D RID: 46605 RVA: 0x002E8DB4 File Offset: 0x002E6FB4
		// (set) Token: 0x0600B60E RID: 46606 RVA: 0x002E8DDD File Offset: 0x002E6FDD
		public unsafe string _Type_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Layout.NativeFieldInfoPtr__Type_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Layout.NativeFieldInfoPtr__Type_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170040EB RID: 16619
		// (get) Token: 0x0600B60F RID: 46607 RVA: 0x002E8E04 File Offset: 0x002E7004
		// (set) Token: 0x0600B610 RID: 46608 RVA: 0x002E8E38 File Offset: 0x002E7038
		public unsafe Dictionary<string, Il2CppReferenceArray<LayoutObject>> _Layouts_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Layout.NativeFieldInfoPtr__Layouts_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, Il2CppReferenceArray<LayoutObject>>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Layout.NativeFieldInfoPtr__Layouts_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400749B RID: 29851
		private static readonly IntPtr NativeFieldInfoPtr__Type_k__BackingField;

		// Token: 0x0400749C RID: 29852
		private static readonly IntPtr NativeFieldInfoPtr__Layouts_k__BackingField;

		// Token: 0x0400749D RID: 29853
		private static readonly IntPtr NativeMethodInfoPtr_get_Type_Public_get_String_0;

		// Token: 0x0400749E RID: 29854
		private static readonly IntPtr NativeMethodInfoPtr_set_Type_Public_set_Void_String_0;

		// Token: 0x0400749F RID: 29855
		private static readonly IntPtr NativeMethodInfoPtr_get_Layouts_Public_get_Dictionary_2_String_ArrayOf_LayoutObject_0;

		// Token: 0x040074A0 RID: 29856
		private static readonly IntPtr NativeMethodInfoPtr_set_Layouts_Public_set_Void_Dictionary_2_String_ArrayOf_LayoutObject_0;

		// Token: 0x040074A1 RID: 29857
		private static readonly IntPtr NativeMethodInfoPtr_ToLayout_Internal_Static_Layout_JSONObject_0;

		// Token: 0x040074A2 RID: 29858
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074A3 RID: 29859
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
