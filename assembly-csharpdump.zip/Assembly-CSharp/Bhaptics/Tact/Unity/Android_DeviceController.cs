﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A2 RID: 2210
	public class Android_DeviceController : MonoBehaviour
	{
		// Token: 0x0600B52A RID: 46378 RVA: 0x002E4E78 File Offset: 0x002E3078
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B52B RID: 46379 RVA: 0x002E4EBC File Offset: 0x002E30BC
		[CallerCount(0)]
		public unsafe void RefreshDevice(HapticDevice d)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(d);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_RefreshDevice_Public_Void_HapticDevice_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B52C RID: 46380 RVA: 0x002E4F18 File Offset: 0x002E3118
		[CallerCount(0)]
		public unsafe void RenderConnectMenu()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_RenderConnectMenu_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B52D RID: 46381 RVA: 0x002E4F5C File Offset: 0x002E315C
		[CallerCount(0)]
		public unsafe void RenderDisconnectMenu()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_RenderDisconnectMenu_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B52E RID: 46382 RVA: 0x002E4FA0 File Offset: 0x002E31A0
		[CallerCount(0)]
		public unsafe void UpdateButtons()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_UpdateButtons_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B52F RID: 46383 RVA: 0x002E4FE4 File Offset: 0x002E31E4
		[CallerCount(0)]
		public unsafe void UpdateIcon(HapticDevice d)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(d);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_UpdateIcon_Private_Void_HapticDevice_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B530 RID: 46384 RVA: 0x002E5040 File Offset: 0x002E3240
		[CallerCount(0)]
		public unsafe Sprite GetSprite(PositonIconSetting icon, bool connected)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(icon);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref connected;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_GetSprite_Private_Sprite_PositonIconSetting_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Sprite(intPtr2) : null;
		}

		// Token: 0x0600B531 RID: 46385 RVA: 0x002E50C0 File Offset: 0x002E32C0
		[CallerCount(0)]
		public unsafe void Ping()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_Ping_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B532 RID: 46386 RVA: 0x002E5104 File Offset: 0x002E3304
		[CallerCount(0)]
		public unsafe void ToLeft()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_ToLeft_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B533 RID: 46387 RVA: 0x002E5148 File Offset: 0x002E3348
		[CallerCount(0)]
		public unsafe void ToRight()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_ToRight_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B534 RID: 46388 RVA: 0x002E518C File Offset: 0x002E338C
		[CallerCount(0)]
		public unsafe Color ToColor(string hex)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(hex);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_ToColor_Private_Color_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B535 RID: 46389 RVA: 0x002E51F4 File Offset: 0x002E33F4
		[CallerCount(0)]
		public unsafe void ChangeButtonColor(Button targetButton, bool isSelect)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(targetButton);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isSelect;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_ChangeButtonColor_Private_Void_Button_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B536 RID: 46390 RVA: 0x002E5260 File Offset: 0x002E3460
		[CallerCount(0)]
		public unsafe static bool IsLeft(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_IsLeft_Private_Static_Boolean_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B537 RID: 46391 RVA: 0x002E52B4 File Offset: 0x002E34B4
		[CallerCount(0)]
		public unsafe static bool IsRight(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr_IsRight_Private_Static_Boolean_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B538 RID: 46392 RVA: 0x002E5308 File Offset: 0x002E3508
		[CallerCount(0)]
		public unsafe Android_DeviceController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_DeviceController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B539 RID: 46393 RVA: 0x002E5354 File Offset: 0x002E3554
		// Note: this type is marked as 'beforefieldinit'.
		static Android_DeviceController()
		{
			Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "Android_DeviceController");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr);
			Android_DeviceController.NativeFieldInfoPtr_icon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "icon");
			Android_DeviceController.NativeFieldInfoPtr_widgetSetting = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "widgetSetting");
			Android_DeviceController.NativeFieldInfoPtr_TactsuitWiredIcon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "TactsuitWiredIcon");
			Android_DeviceController.NativeFieldInfoPtr_batteryLowImage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "batteryLowImage");
			Android_DeviceController.NativeFieldInfoPtr_ConnectMenu = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "ConnectMenu");
			Android_DeviceController.NativeFieldInfoPtr_pingButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "pingButton");
			Android_DeviceController.NativeFieldInfoPtr_lButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "lButton");
			Android_DeviceController.NativeFieldInfoPtr_rButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "rButton");
			Android_DeviceController.NativeFieldInfoPtr_wiredNotification = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "wiredNotification");
			Android_DeviceController.NativeFieldInfoPtr_DisconnectMenu = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "DisconnectMenu");
			Android_DeviceController.NativeFieldInfoPtr_SelectHexColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "SelectHexColor");
			Android_DeviceController.NativeFieldInfoPtr_SelectHoverHexColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "SelectHoverHexColor");
			Android_DeviceController.NativeFieldInfoPtr_DisableHexColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "DisableHexColor");
			Android_DeviceController.NativeFieldInfoPtr_DisableHoverHexColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "DisableHoverHexColor");
			Android_DeviceController.NativeFieldInfoPtr_device = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, "device");
			Android_DeviceController.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677975);
			Android_DeviceController.NativeMethodInfoPtr_RefreshDevice_Public_Void_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677976);
			Android_DeviceController.NativeMethodInfoPtr_RenderConnectMenu_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677977);
			Android_DeviceController.NativeMethodInfoPtr_RenderDisconnectMenu_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677978);
			Android_DeviceController.NativeMethodInfoPtr_UpdateButtons_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677979);
			Android_DeviceController.NativeMethodInfoPtr_UpdateIcon_Private_Void_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677980);
			Android_DeviceController.NativeMethodInfoPtr_GetSprite_Private_Sprite_PositonIconSetting_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677981);
			Android_DeviceController.NativeMethodInfoPtr_Ping_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677982);
			Android_DeviceController.NativeMethodInfoPtr_ToLeft_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677983);
			Android_DeviceController.NativeMethodInfoPtr_ToRight_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677984);
			Android_DeviceController.NativeMethodInfoPtr_ToColor_Private_Color_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677985);
			Android_DeviceController.NativeMethodInfoPtr_ChangeButtonColor_Private_Void_Button_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677986);
			Android_DeviceController.NativeMethodInfoPtr_IsLeft_Private_Static_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677987);
			Android_DeviceController.NativeMethodInfoPtr_IsRight_Private_Static_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677988);
			Android_DeviceController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr, 100677989);
		}

		// Token: 0x0600B53A RID: 46394 RVA: 0x0000210C File Offset: 0x0000030C
		public Android_DeviceController(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040A8 RID: 16552
		// (get) Token: 0x0600B53B RID: 46395 RVA: 0x002E55DC File Offset: 0x002E37DC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Android_DeviceController>.NativeClassPtr));
			}
		}

		// Token: 0x170040A9 RID: 16553
		// (get) Token: 0x0600B53C RID: 46396 RVA: 0x002E55F0 File Offset: 0x002E37F0
		// (set) Token: 0x0600B53D RID: 46397 RVA: 0x002E5624 File Offset: 0x002E3824
		public unsafe Image icon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_icon);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Image(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_icon), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AA RID: 16554
		// (get) Token: 0x0600B53E RID: 46398 RVA: 0x002E564C File Offset: 0x002E384C
		// (set) Token: 0x0600B53F RID: 46399 RVA: 0x002E5680 File Offset: 0x002E3880
		public unsafe IconSetting widgetSetting
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_widgetSetting);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new IconSetting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_widgetSetting), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AB RID: 16555
		// (get) Token: 0x0600B540 RID: 46400 RVA: 0x002E56A8 File Offset: 0x002E38A8
		// (set) Token: 0x0600B541 RID: 46401 RVA: 0x002E56DC File Offset: 0x002E38DC
		public unsafe Sprite TactsuitWiredIcon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_TactsuitWiredIcon);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Sprite(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_TactsuitWiredIcon), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AC RID: 16556
		// (get) Token: 0x0600B542 RID: 46402 RVA: 0x002E5704 File Offset: 0x002E3904
		// (set) Token: 0x0600B543 RID: 46403 RVA: 0x002E5738 File Offset: 0x002E3938
		public unsafe Image batteryLowImage
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_batteryLowImage);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Image(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_batteryLowImage), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AD RID: 16557
		// (get) Token: 0x0600B544 RID: 46404 RVA: 0x002E5760 File Offset: 0x002E3960
		// (set) Token: 0x0600B545 RID: 46405 RVA: 0x002E5794 File Offset: 0x002E3994
		public unsafe GameObject ConnectMenu
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_ConnectMenu);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_ConnectMenu), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AE RID: 16558
		// (get) Token: 0x0600B546 RID: 46406 RVA: 0x002E57BC File Offset: 0x002E39BC
		// (set) Token: 0x0600B547 RID: 46407 RVA: 0x002E57F0 File Offset: 0x002E39F0
		public unsafe Button pingButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_pingButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_pingButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040AF RID: 16559
		// (get) Token: 0x0600B548 RID: 46408 RVA: 0x002E5818 File Offset: 0x002E3A18
		// (set) Token: 0x0600B549 RID: 46409 RVA: 0x002E584C File Offset: 0x002E3A4C
		public unsafe Button lButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_lButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_lButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040B0 RID: 16560
		// (get) Token: 0x0600B54A RID: 46410 RVA: 0x002E5874 File Offset: 0x002E3A74
		// (set) Token: 0x0600B54B RID: 46411 RVA: 0x002E58A8 File Offset: 0x002E3AA8
		public unsafe Button rButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_rButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_rButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040B1 RID: 16561
		// (get) Token: 0x0600B54C RID: 46412 RVA: 0x002E58D0 File Offset: 0x002E3AD0
		// (set) Token: 0x0600B54D RID: 46413 RVA: 0x002E5904 File Offset: 0x002E3B04
		public unsafe GameObject wiredNotification
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_wiredNotification);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_wiredNotification), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040B2 RID: 16562
		// (get) Token: 0x0600B54E RID: 46414 RVA: 0x002E592C File Offset: 0x002E3B2C
		// (set) Token: 0x0600B54F RID: 46415 RVA: 0x002E5960 File Offset: 0x002E3B60
		public unsafe GameObject DisconnectMenu
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_DisconnectMenu);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_DisconnectMenu), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040B3 RID: 16563
		// (get) Token: 0x0600B550 RID: 46416 RVA: 0x002E5988 File Offset: 0x002E3B88
		// (set) Token: 0x0600B551 RID: 46417 RVA: 0x002E59A8 File Offset: 0x002E3BA8
		public unsafe static string SelectHexColor
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(Android_DeviceController.NativeFieldInfoPtr_SelectHexColor, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Android_DeviceController.NativeFieldInfoPtr_SelectHexColor, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170040B4 RID: 16564
		// (get) Token: 0x0600B552 RID: 46418 RVA: 0x002E59C0 File Offset: 0x002E3BC0
		// (set) Token: 0x0600B553 RID: 46419 RVA: 0x002E59E0 File Offset: 0x002E3BE0
		public unsafe static string SelectHoverHexColor
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(Android_DeviceController.NativeFieldInfoPtr_SelectHoverHexColor, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Android_DeviceController.NativeFieldInfoPtr_SelectHoverHexColor, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170040B5 RID: 16565
		// (get) Token: 0x0600B554 RID: 46420 RVA: 0x002E59F8 File Offset: 0x002E3BF8
		// (set) Token: 0x0600B555 RID: 46421 RVA: 0x002E5A18 File Offset: 0x002E3C18
		public unsafe static string DisableHexColor
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(Android_DeviceController.NativeFieldInfoPtr_DisableHexColor, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Android_DeviceController.NativeFieldInfoPtr_DisableHexColor, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170040B6 RID: 16566
		// (get) Token: 0x0600B556 RID: 46422 RVA: 0x002E5A30 File Offset: 0x002E3C30
		// (set) Token: 0x0600B557 RID: 46423 RVA: 0x002E5A50 File Offset: 0x002E3C50
		public unsafe static string DisableHoverHexColor
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(Android_DeviceController.NativeFieldInfoPtr_DisableHoverHexColor, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Android_DeviceController.NativeFieldInfoPtr_DisableHoverHexColor, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170040B7 RID: 16567
		// (get) Token: 0x0600B558 RID: 46424 RVA: 0x002E5A68 File Offset: 0x002E3C68
		// (set) Token: 0x0600B559 RID: 46425 RVA: 0x002E5A9C File Offset: 0x002E3C9C
		public unsafe HapticDevice device
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_device);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HapticDevice(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_DeviceController.NativeFieldInfoPtr_device), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400740F RID: 29711
		private static readonly IntPtr NativeFieldInfoPtr_icon;

		// Token: 0x04007410 RID: 29712
		private static readonly IntPtr NativeFieldInfoPtr_widgetSetting;

		// Token: 0x04007411 RID: 29713
		private static readonly IntPtr NativeFieldInfoPtr_TactsuitWiredIcon;

		// Token: 0x04007412 RID: 29714
		private static readonly IntPtr NativeFieldInfoPtr_batteryLowImage;

		// Token: 0x04007413 RID: 29715
		private static readonly IntPtr NativeFieldInfoPtr_ConnectMenu;

		// Token: 0x04007414 RID: 29716
		private static readonly IntPtr NativeFieldInfoPtr_pingButton;

		// Token: 0x04007415 RID: 29717
		private static readonly IntPtr NativeFieldInfoPtr_lButton;

		// Token: 0x04007416 RID: 29718
		private static readonly IntPtr NativeFieldInfoPtr_rButton;

		// Token: 0x04007417 RID: 29719
		private static readonly IntPtr NativeFieldInfoPtr_wiredNotification;

		// Token: 0x04007418 RID: 29720
		private static readonly IntPtr NativeFieldInfoPtr_DisconnectMenu;

		// Token: 0x04007419 RID: 29721
		private static readonly IntPtr NativeFieldInfoPtr_SelectHexColor;

		// Token: 0x0400741A RID: 29722
		private static readonly IntPtr NativeFieldInfoPtr_SelectHoverHexColor;

		// Token: 0x0400741B RID: 29723
		private static readonly IntPtr NativeFieldInfoPtr_DisableHexColor;

		// Token: 0x0400741C RID: 29724
		private static readonly IntPtr NativeFieldInfoPtr_DisableHoverHexColor;

		// Token: 0x0400741D RID: 29725
		private static readonly IntPtr NativeFieldInfoPtr_device;

		// Token: 0x0400741E RID: 29726
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400741F RID: 29727
		private static readonly IntPtr NativeMethodInfoPtr_RefreshDevice_Public_Void_HapticDevice_0;

		// Token: 0x04007420 RID: 29728
		private static readonly IntPtr NativeMethodInfoPtr_RenderConnectMenu_Private_Void_0;

		// Token: 0x04007421 RID: 29729
		private static readonly IntPtr NativeMethodInfoPtr_RenderDisconnectMenu_Private_Void_0;

		// Token: 0x04007422 RID: 29730
		private static readonly IntPtr NativeMethodInfoPtr_UpdateButtons_Private_Void_0;

		// Token: 0x04007423 RID: 29731
		private static readonly IntPtr NativeMethodInfoPtr_UpdateIcon_Private_Void_HapticDevice_0;

		// Token: 0x04007424 RID: 29732
		private static readonly IntPtr NativeMethodInfoPtr_GetSprite_Private_Sprite_PositonIconSetting_Boolean_0;

		// Token: 0x04007425 RID: 29733
		private static readonly IntPtr NativeMethodInfoPtr_Ping_Private_Void_0;

		// Token: 0x04007426 RID: 29734
		private static readonly IntPtr NativeMethodInfoPtr_ToLeft_Private_Void_0;

		// Token: 0x04007427 RID: 29735
		private static readonly IntPtr NativeMethodInfoPtr_ToRight_Private_Void_0;

		// Token: 0x04007428 RID: 29736
		private static readonly IntPtr NativeMethodInfoPtr_ToColor_Private_Color_String_0;

		// Token: 0x04007429 RID: 29737
		private static readonly IntPtr NativeMethodInfoPtr_ChangeButtonColor_Private_Void_Button_Boolean_0;

		// Token: 0x0400742A RID: 29738
		private static readonly IntPtr NativeMethodInfoPtr_IsLeft_Private_Static_Boolean_PositionType_0;

		// Token: 0x0400742B RID: 29739
		private static readonly IntPtr NativeMethodInfoPtr_IsRight_Private_Static_Boolean_PositionType_0;

		// Token: 0x0400742C RID: 29740
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
