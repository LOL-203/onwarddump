﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C5 RID: 2245
	public class IHaptic : Il2CppObjectBase
	{
		// Token: 0x0600B766 RID: 46950 RVA: 0x002EEC64 File Offset: 0x002ECE64
		[CallerCount(0)]
		public unsafe bool IsConnect(PositionType type)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_PositionType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B767 RID: 46951 RVA: 0x002EECD4 File Offset: 0x002ECED4
		[CallerCount(0)]
		public unsafe bool IsConnect(HapticDeviceType type, bool isLeft = true)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isLeft;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_HapticDeviceType_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B768 RID: 46952 RVA: 0x002EED54 File Offset: 0x002ECF54
		[CallerCount(0)]
		public unsafe bool IsPlaying(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B769 RID: 46953 RVA: 0x002EEDC8 File Offset: 0x002ECFC8
		[CallerCount(0)]
		public unsafe bool IsFeedbackRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Abstract_Virtual_New_Boolean_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B76A RID: 46954 RVA: 0x002EEE3C File Offset: 0x002ED03C
		[CallerCount(0)]
		public unsafe bool IsPlaying()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B76B RID: 46955 RVA: 0x002EEE98 File Offset: 0x002ED098
		[CallerCount(0)]
		public unsafe void RegisterTactFileStr(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Abstract_Virtual_New_Void_String_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B76C RID: 46956 RVA: 0x002EEF14 File Offset: 0x002ED114
		[CallerCount(0)]
		public unsafe void RegisterTactFileStrReflected(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Abstract_Virtual_New_Void_String_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B76D RID: 46957 RVA: 0x002EEF90 File Offset: 0x002ED190
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<DotPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_DotPoint_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B76E RID: 46958 RVA: 0x002EF034 File Offset: 0x002ED234
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<PathPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_PathPoint_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B76F RID: 46959 RVA: 0x002EF0D8 File Offset: 0x002ED2D8
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, ScaleOption option)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(option);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_ScaleOption_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B770 RID: 46960 RVA: 0x002EF16C File Offset: 0x002ED36C
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, RotationOption rOption, ScaleOption sOption)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(rOption);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(sOption);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_RotationOption_ScaleOption_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B771 RID: 46961 RVA: 0x002EF218 File Offset: 0x002ED418
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B772 RID: 46962 RVA: 0x002EF27C File Offset: 0x002ED47C
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, int startTimeMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref startTimeMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B773 RID: 46963 RVA: 0x002EF2F4 File Offset: 0x002ED4F4
		[CallerCount(0)]
		public unsafe void TurnOff(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B774 RID: 46964 RVA: 0x002EF358 File Offset: 0x002ED558
		[CallerCount(0)]
		public unsafe void TurnOff()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B775 RID: 46965 RVA: 0x002EF3A8 File Offset: 0x002ED5A8
		[CallerCount(0)]
		public unsafe void Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_Dispose_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B776 RID: 46966 RVA: 0x002EF3F8 File Offset: 0x002ED5F8
		[CallerCount(0)]
		public unsafe Il2CppStructArray<int> GetCurrentFeedback(PositionType pos)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Abstract_Virtual_New_ArrayOf_Int32_PositionType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}

		// Token: 0x0600B777 RID: 46967 RVA: 0x002EF46C File Offset: 0x002ED66C
		// Note: this type is marked as 'beforefieldinit'.
		static IHaptic()
		{
			Il2CppClassPointerStore<IHaptic>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "IHaptic");
			IHaptic.NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678219);
			IHaptic.NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_HapticDeviceType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678220);
			IHaptic.NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678221);
			IHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Abstract_Virtual_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678222);
			IHaptic.NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678223);
			IHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Abstract_Virtual_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678224);
			IHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Abstract_Virtual_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678225);
			IHaptic.NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_DotPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678226);
			IHaptic.NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_PathPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678227);
			IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678228);
			IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_RotationOption_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678229);
			IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678230);
			IHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678231);
			IHaptic.NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678232);
			IHaptic.NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678233);
			IHaptic.NativeMethodInfoPtr_Dispose_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678234);
			IHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Abstract_Virtual_New_ArrayOf_Int32_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IHaptic>.NativeClassPtr, 100678235);
		}

		// Token: 0x0600B778 RID: 46968 RVA: 0x0000206B File Offset: 0x0000026B
		public IHaptic(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700415D RID: 16733
		// (get) Token: 0x0600B779 RID: 46969 RVA: 0x002EF5E6 File Offset: 0x002ED7E6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<IHaptic>.NativeClassPtr));
			}
		}

		// Token: 0x0400758F RID: 30095
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_PositionType_0;

		// Token: 0x04007590 RID: 30096
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Abstract_Virtual_New_Boolean_HapticDeviceType_Boolean_0;

		// Token: 0x04007591 RID: 30097
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_String_0;

		// Token: 0x04007592 RID: 30098
		private static readonly IntPtr NativeMethodInfoPtr_IsFeedbackRegistered_Public_Abstract_Virtual_New_Boolean_String_0;

		// Token: 0x04007593 RID: 30099
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Abstract_Virtual_New_Boolean_0;

		// Token: 0x04007594 RID: 30100
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStr_Public_Abstract_Virtual_New_Void_String_String_0;

		// Token: 0x04007595 RID: 30101
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Abstract_Virtual_New_Void_String_String_0;

		// Token: 0x04007596 RID: 30102
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_DotPoint_Int32_0;

		// Token: 0x04007597 RID: 30103
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Abstract_Virtual_New_Void_String_PositionType_List_1_PathPoint_Int32_0;

		// Token: 0x04007598 RID: 30104
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_ScaleOption_0;

		// Token: 0x04007599 RID: 30105
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_String_RotationOption_ScaleOption_0;

		// Token: 0x0400759A RID: 30106
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_0;

		// Token: 0x0400759B RID: 30107
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Abstract_Virtual_New_Void_String_Int32_0;

		// Token: 0x0400759C RID: 30108
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_String_0;

		// Token: 0x0400759D RID: 30109
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Abstract_Virtual_New_Void_0;

		// Token: 0x0400759E RID: 30110
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Abstract_Virtual_New_Void_0;

		// Token: 0x0400759F RID: 30111
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentFeedback_Public_Abstract_Virtual_New_ArrayOf_Int32_PositionType_0;
	}
}
