﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AE RID: 2222
	public class DotMode : Object
	{
		// Token: 0x170040FF RID: 16639
		// (get) Token: 0x0600B635 RID: 46645 RVA: 0x002E98B0 File Offset: 0x002E7AB0
		// (set) Token: 0x0600B636 RID: 46646 RVA: 0x002E9900 File Offset: 0x002E7B00
		public unsafe bool DotConnected
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_get_DotConnected_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_set_DotConnected_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17004100 RID: 16640
		// (get) Token: 0x0600B637 RID: 46647 RVA: 0x002E9954 File Offset: 0x002E7B54
		// (set) Token: 0x0600B638 RID: 46648 RVA: 0x002E99AC File Offset: 0x002E7BAC
		public unsafe Il2CppReferenceArray<DotModeObjectCollection> Feedback
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_DotModeObjectCollection_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<DotModeObjectCollection>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_DotModeObjectCollection_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B639 RID: 46649 RVA: 0x002E9A08 File Offset: 0x002E7C08
		[CallerCount(0)]
		public unsafe static DotMode ToDotMode(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_ToDotMode_Internal_Static_DotMode_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DotMode(intPtr2) : null;
		}

		// Token: 0x0600B63A RID: 46650 RVA: 0x002E9A68 File Offset: 0x002E7C68
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B63B RID: 46651 RVA: 0x002E9AC0 File Offset: 0x002E7CC0
		[CallerCount(0)]
		public unsafe DotMode() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DotMode>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotMode.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B63C RID: 46652 RVA: 0x002E9B0C File Offset: 0x002E7D0C
		// Note: this type is marked as 'beforefieldinit'.
		static DotMode()
		{
			Il2CppClassPointerStore<DotMode>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "DotMode");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DotMode>.NativeClassPtr);
			DotMode.NativeFieldInfoPtr__DotConnected_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotMode>.NativeClassPtr, "<DotConnected>k__BackingField");
			DotMode.NativeFieldInfoPtr__Feedback_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotMode>.NativeClassPtr, "<Feedback>k__BackingField");
			DotMode.NativeMethodInfoPtr_get_DotConnected_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678092);
			DotMode.NativeMethodInfoPtr_set_DotConnected_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678093);
			DotMode.NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_DotModeObjectCollection_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678094);
			DotMode.NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_DotModeObjectCollection_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678095);
			DotMode.NativeMethodInfoPtr_ToDotMode_Internal_Static_DotMode_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678096);
			DotMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678097);
			DotMode.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotMode>.NativeClassPtr, 100678098);
		}

		// Token: 0x0600B63D RID: 46653 RVA: 0x00002988 File Offset: 0x00000B88
		public DotMode(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040FC RID: 16636
		// (get) Token: 0x0600B63E RID: 46654 RVA: 0x002E9BF0 File Offset: 0x002E7DF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DotMode>.NativeClassPtr));
			}
		}

		// Token: 0x170040FD RID: 16637
		// (get) Token: 0x0600B63F RID: 46655 RVA: 0x002E9C04 File Offset: 0x002E7E04
		// (set) Token: 0x0600B640 RID: 46656 RVA: 0x002E9C2C File Offset: 0x002E7E2C
		public unsafe bool _DotConnected_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotMode.NativeFieldInfoPtr__DotConnected_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotMode.NativeFieldInfoPtr__DotConnected_k__BackingField)) = value;
			}
		}

		// Token: 0x170040FE RID: 16638
		// (get) Token: 0x0600B641 RID: 46657 RVA: 0x002E9C50 File Offset: 0x002E7E50
		// (set) Token: 0x0600B642 RID: 46658 RVA: 0x002E9C84 File Offset: 0x002E7E84
		public unsafe Il2CppReferenceArray<DotModeObjectCollection> _Feedback_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotMode.NativeFieldInfoPtr__Feedback_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<DotModeObjectCollection>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotMode.NativeFieldInfoPtr__Feedback_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040074BC RID: 29884
		private static readonly IntPtr NativeFieldInfoPtr__DotConnected_k__BackingField;

		// Token: 0x040074BD RID: 29885
		private static readonly IntPtr NativeFieldInfoPtr__Feedback_k__BackingField;

		// Token: 0x040074BE RID: 29886
		private static readonly IntPtr NativeMethodInfoPtr_get_DotConnected_Public_get_Boolean_0;

		// Token: 0x040074BF RID: 29887
		private static readonly IntPtr NativeMethodInfoPtr_set_DotConnected_Public_set_Void_Boolean_0;

		// Token: 0x040074C0 RID: 29888
		private static readonly IntPtr NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_DotModeObjectCollection_0;

		// Token: 0x040074C1 RID: 29889
		private static readonly IntPtr NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_DotModeObjectCollection_0;

		// Token: 0x040074C2 RID: 29890
		private static readonly IntPtr NativeMethodInfoPtr_ToDotMode_Internal_Static_DotMode_JSONObject_0;

		// Token: 0x040074C3 RID: 29891
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074C4 RID: 29892
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
