﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008CA RID: 2250
	public class VisualFeedback : MonoBehaviour
	{
		// Token: 0x0600B7AB RID: 47019 RVA: 0x002F02FC File Offset: 0x002EE4FC
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualFeedback.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B7AC RID: 47020 RVA: 0x002F0340 File Offset: 0x002EE540
		[CallerCount(0)]
		public unsafe void UpdateFeedback(HapticFeedback feedback)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(feedback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualFeedback.NativeMethodInfoPtr_UpdateFeedback_Public_Void_HapticFeedback_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B7AD RID: 47021 RVA: 0x002F039C File Offset: 0x002EE59C
		[CallerCount(0)]
		public unsafe void UpdateFeedback(Il2CppStructArray<int> feedbackValues)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(feedbackValues);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualFeedback.NativeMethodInfoPtr_UpdateFeedback_Public_Void_ArrayOf_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B7AE RID: 47022 RVA: 0x002F03F8 File Offset: 0x002EE5F8
		[CallerCount(0)]
		public unsafe VisualFeedback() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualFeedback.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B7AF RID: 47023 RVA: 0x002F0444 File Offset: 0x002EE644
		// Note: this type is marked as 'beforefieldinit'.
		static VisualFeedback()
		{
			Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "VisualFeedback");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr);
			VisualFeedback.NativeFieldInfoPtr_devicePos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, "devicePos");
			VisualFeedback.NativeFieldInfoPtr_motorContainer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, "motorContainer");
			VisualFeedback.NativeFieldInfoPtr_motorFeedbackGradient = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, "motorFeedbackGradient");
			VisualFeedback.NativeFieldInfoPtr_motors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, "motors");
			VisualFeedback.NativeFieldInfoPtr_motorScaleOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, "motorScaleOffset");
			VisualFeedback.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, 100678250);
			VisualFeedback.NativeMethodInfoPtr_UpdateFeedback_Public_Void_HapticFeedback_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, 100678251);
			VisualFeedback.NativeMethodInfoPtr_UpdateFeedback_Public_Void_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, 100678252);
			VisualFeedback.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr, 100678253);
		}

		// Token: 0x0600B7B0 RID: 47024 RVA: 0x0000210C File Offset: 0x0000030C
		public VisualFeedback(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700416E RID: 16750
		// (get) Token: 0x0600B7B1 RID: 47025 RVA: 0x002F0528 File Offset: 0x002EE728
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisualFeedback>.NativeClassPtr));
			}
		}

		// Token: 0x1700416F RID: 16751
		// (get) Token: 0x0600B7B2 RID: 47026 RVA: 0x002F053C File Offset: 0x002EE73C
		// (set) Token: 0x0600B7B3 RID: 47027 RVA: 0x002F0564 File Offset: 0x002EE764
		public unsafe HapticClipPositionType devicePos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_devicePos);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_devicePos)) = value;
			}
		}

		// Token: 0x17004170 RID: 16752
		// (get) Token: 0x0600B7B4 RID: 47028 RVA: 0x002F0588 File Offset: 0x002EE788
		// (set) Token: 0x0600B7B5 RID: 47029 RVA: 0x002F05BC File Offset: 0x002EE7BC
		public unsafe Transform motorContainer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorContainer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorContainer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004171 RID: 16753
		// (get) Token: 0x0600B7B6 RID: 47030 RVA: 0x002F05E4 File Offset: 0x002EE7E4
		// (set) Token: 0x0600B7B7 RID: 47031 RVA: 0x002F0618 File Offset: 0x002EE818
		public unsafe Gradient motorFeedbackGradient
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorFeedbackGradient);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Gradient(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorFeedbackGradient), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004172 RID: 16754
		// (get) Token: 0x0600B7B8 RID: 47032 RVA: 0x002F0640 File Offset: 0x002EE840
		// (set) Token: 0x0600B7B9 RID: 47033 RVA: 0x002F0674 File Offset: 0x002EE874
		public unsafe Il2CppReferenceArray<Transform> motors
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motors);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Transform>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motors), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004173 RID: 16755
		// (get) Token: 0x0600B7BA RID: 47034 RVA: 0x002F069C File Offset: 0x002EE89C
		// (set) Token: 0x0600B7BB RID: 47035 RVA: 0x002F06C4 File Offset: 0x002EE8C4
		public unsafe float motorScaleOffset
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorScaleOffset);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisualFeedback.NativeFieldInfoPtr_motorScaleOffset)) = value;
			}
		}

		// Token: 0x040075BD RID: 30141
		private static readonly IntPtr NativeFieldInfoPtr_devicePos;

		// Token: 0x040075BE RID: 30142
		private static readonly IntPtr NativeFieldInfoPtr_motorContainer;

		// Token: 0x040075BF RID: 30143
		private static readonly IntPtr NativeFieldInfoPtr_motorFeedbackGradient;

		// Token: 0x040075C0 RID: 30144
		private static readonly IntPtr NativeFieldInfoPtr_motors;

		// Token: 0x040075C1 RID: 30145
		private static readonly IntPtr NativeFieldInfoPtr_motorScaleOffset;

		// Token: 0x040075C2 RID: 30146
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x040075C3 RID: 30147
		private static readonly IntPtr NativeMethodInfoPtr_UpdateFeedback_Public_Void_HapticFeedback_0;

		// Token: 0x040075C4 RID: 30148
		private static readonly IntPtr NativeMethodInfoPtr_UpdateFeedback_Public_Void_ArrayOf_Int32_0;

		// Token: 0x040075C5 RID: 30149
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
