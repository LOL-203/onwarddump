﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C9 RID: 2249
	public class VestHapticClip : FileHapticClip
	{
		// Token: 0x0600B798 RID: 47000 RVA: 0x002EFCD4 File Offset: 0x002EDED4
		[CallerCount(0)]
		public new unsafe void Play()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B799 RID: 47001 RVA: 0x002EFD24 File Offset: 0x002EDF24
		[CallerCount(0)]
		public new unsafe void Play(string identifier)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79A RID: 47002 RVA: 0x002EFD88 File Offset: 0x002EDF88
		[CallerCount(0)]
		public new unsafe void Play(float intensity, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79B RID: 47003 RVA: 0x002EFE00 File Offset: 0x002EE000
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79C RID: 47004 RVA: 0x002EFE8C File Offset: 0x002EE08C
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79D RID: 47005 RVA: 0x002EFF2C File Offset: 0x002EE12C
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, float vestRotationOffsetY, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationOffsetY;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79E RID: 47006 RVA: 0x002EFFDC File Offset: 0x002EE1DC
		[CallerCount(0)]
		public new unsafe void ResetValues()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VestHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B79F RID: 47007 RVA: 0x002F002C File Offset: 0x002EE22C
		[CallerCount(0)]
		public unsafe VestHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VestHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B7A0 RID: 47008 RVA: 0x002F0078 File Offset: 0x002EE278
		// Note: this type is marked as 'beforefieldinit'.
		static VestHapticClip()
		{
			Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "VestHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr);
			VestHapticClip.NativeFieldInfoPtr_TactFileAngleX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, "TactFileAngleX");
			VestHapticClip.NativeFieldInfoPtr_TactFileOffsetY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, "TactFileOffsetY");
			VestHapticClip.NativeFieldInfoPtr__rotationOption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, "_rotationOption");
			VestHapticClip.NativeFieldInfoPtr__scaleOption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, "_scaleOption");
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678242);
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678243);
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678244);
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678245);
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678246);
			VestHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678247);
			VestHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678248);
			VestHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr, 100678249);
		}

		// Token: 0x0600B7A1 RID: 47009 RVA: 0x002E7230 File Offset: 0x002E5430
		public VestHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004169 RID: 16745
		// (get) Token: 0x0600B7A2 RID: 47010 RVA: 0x002F0198 File Offset: 0x002EE398
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VestHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x1700416A RID: 16746
		// (get) Token: 0x0600B7A3 RID: 47011 RVA: 0x002F01AC File Offset: 0x002EE3AC
		// (set) Token: 0x0600B7A4 RID: 47012 RVA: 0x002F01D4 File Offset: 0x002EE3D4
		public unsafe float TactFileAngleX
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr_TactFileAngleX);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr_TactFileAngleX)) = value;
			}
		}

		// Token: 0x1700416B RID: 16747
		// (get) Token: 0x0600B7A5 RID: 47013 RVA: 0x002F01F8 File Offset: 0x002EE3F8
		// (set) Token: 0x0600B7A6 RID: 47014 RVA: 0x002F0220 File Offset: 0x002EE420
		public unsafe float TactFileOffsetY
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr_TactFileOffsetY);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr_TactFileOffsetY)) = value;
			}
		}

		// Token: 0x1700416C RID: 16748
		// (get) Token: 0x0600B7A7 RID: 47015 RVA: 0x002F0244 File Offset: 0x002EE444
		// (set) Token: 0x0600B7A8 RID: 47016 RVA: 0x002F0278 File Offset: 0x002EE478
		public unsafe RotationOption _rotationOption
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr__rotationOption);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new RotationOption(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr__rotationOption), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700416D RID: 16749
		// (get) Token: 0x0600B7A9 RID: 47017 RVA: 0x002F02A0 File Offset: 0x002EE4A0
		// (set) Token: 0x0600B7AA RID: 47018 RVA: 0x002F02D4 File Offset: 0x002EE4D4
		public unsafe ScaleOption _scaleOption
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr__scaleOption);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ScaleOption(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VestHapticClip.NativeFieldInfoPtr__scaleOption), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040075B1 RID: 30129
		private static readonly IntPtr NativeFieldInfoPtr_TactFileAngleX;

		// Token: 0x040075B2 RID: 30130
		private static readonly IntPtr NativeFieldInfoPtr_TactFileOffsetY;

		// Token: 0x040075B3 RID: 30131
		private static readonly IntPtr NativeFieldInfoPtr__rotationOption;

		// Token: 0x040075B4 RID: 30132
		private static readonly IntPtr NativeFieldInfoPtr__scaleOption;

		// Token: 0x040075B5 RID: 30133
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_0;

		// Token: 0x040075B6 RID: 30134
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_String_0;

		// Token: 0x040075B7 RID: 30135
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_String_0;

		// Token: 0x040075B8 RID: 30136
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_String_0;

		// Token: 0x040075B9 RID: 30137
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_String_0;

		// Token: 0x040075BA RID: 30138
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0;

		// Token: 0x040075BB RID: 30139
		private static readonly IntPtr NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0;

		// Token: 0x040075BC RID: 30140
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
