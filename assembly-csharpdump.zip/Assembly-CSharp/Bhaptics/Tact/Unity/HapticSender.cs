﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008BF RID: 2239
	public class HapticSender : MonoBehaviour
	{
		// Token: 0x0600B70A RID: 46858 RVA: 0x002ED4B8 File Offset: 0x002EB6B8
		[CallerCount(0)]
		public unsafe void Play([Optional] PositionTag posTag)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B70B RID: 46859 RVA: 0x002ED50C File Offset: 0x002EB70C
		[CallerCount(0)]
		public unsafe void Play(PositionTag posTag, Vector3 contactPos, Collider targetCollider)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref contactPos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(targetCollider);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_Vector3_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B70C RID: 46860 RVA: 0x002ED58C File Offset: 0x002EB78C
		[CallerCount(0)]
		public unsafe void Play(PositionTag posTag, Vector3 contactPos, Vector3 targetPos, Vector3 targetForward, float targetHeight)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref contactPos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPos;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetForward;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetHeight;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_Play_Private_Void_PositionTag_Vector3_Vector3_Vector3_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B70D RID: 46861 RVA: 0x002ED62C File Offset: 0x002EB82C
		[CallerCount(0)]
		public unsafe void Play(PositionTag posTag, RaycastHit hit)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hit;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_RaycastHit_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B70E RID: 46862 RVA: 0x002ED694 File Offset: 0x002EB894
		[CallerCount(0)]
		public unsafe HapticClip GetClip(PositionTag posTag)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_GetClip_Private_HapticClip_PositionTag_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HapticClip(intPtr2) : null;
		}

		// Token: 0x0600B70F RID: 46863 RVA: 0x002ED6FC File Offset: 0x002EB8FC
		[CallerCount(0)]
		public unsafe bool IsPlaying()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_IsPlaying_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B710 RID: 46864 RVA: 0x002ED74C File Offset: 0x002EB94C
		[CallerCount(0)]
		public unsafe void Play(PositionTag posTag, float angleX, float offsetY)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref posTag;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angleX;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B711 RID: 46865 RVA: 0x002ED7C8 File Offset: 0x002EB9C8
		[CallerCount(0)]
		public unsafe HapticSender() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticSender>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSender.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B712 RID: 46866 RVA: 0x002ED814 File Offset: 0x002EBA14
		// Note: this type is marked as 'beforefieldinit'.
		static HapticSender()
		{
			Il2CppClassPointerStore<HapticSender>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticSender");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticSender>.NativeClassPtr);
			HapticSender.NativeFieldInfoPtr_DefaultClips = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "DefaultClips");
			HapticSender.NativeFieldInfoPtr_HeadClips = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "HeadClips");
			HapticSender.NativeFieldInfoPtr_BodyClips = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "BodyClips");
			HapticSender.NativeFieldInfoPtr_LeftArmClips = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "LeftArmClips");
			HapticSender.NativeFieldInfoPtr_RightArmClips = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "RightArmClips");
			HapticSender.NativeFieldInfoPtr_yOffsetMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, "yOffsetMultiplier");
			HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678186);
			HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_Vector3_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678187);
			HapticSender.NativeMethodInfoPtr_Play_Private_Void_PositionTag_Vector3_Vector3_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678188);
			HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_RaycastHit_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678189);
			HapticSender.NativeMethodInfoPtr_GetClip_Private_HapticClip_PositionTag_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678190);
			HapticSender.NativeMethodInfoPtr_IsPlaying_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678191);
			HapticSender.NativeMethodInfoPtr_Play_Public_Void_PositionTag_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678192);
			HapticSender.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSender>.NativeClassPtr, 100678193);
		}

		// Token: 0x0600B713 RID: 46867 RVA: 0x0000210C File Offset: 0x0000030C
		public HapticSender(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700413E RID: 16702
		// (get) Token: 0x0600B714 RID: 46868 RVA: 0x002ED95C File Offset: 0x002EBB5C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticSender>.NativeClassPtr));
			}
		}

		// Token: 0x1700413F RID: 16703
		// (get) Token: 0x0600B715 RID: 46869 RVA: 0x002ED970 File Offset: 0x002EBB70
		// (set) Token: 0x0600B716 RID: 46870 RVA: 0x002ED9A4 File Offset: 0x002EBBA4
		public unsafe Il2CppReferenceArray<HapticClip> DefaultClips
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_DefaultClips);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<HapticClip>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_DefaultClips), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004140 RID: 16704
		// (get) Token: 0x0600B717 RID: 46871 RVA: 0x002ED9CC File Offset: 0x002EBBCC
		// (set) Token: 0x0600B718 RID: 46872 RVA: 0x002EDA00 File Offset: 0x002EBC00
		public unsafe Il2CppReferenceArray<HeadHapticClip> HeadClips
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_HeadClips);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<HeadHapticClip>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_HeadClips), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004141 RID: 16705
		// (get) Token: 0x0600B719 RID: 46873 RVA: 0x002EDA28 File Offset: 0x002EBC28
		// (set) Token: 0x0600B71A RID: 46874 RVA: 0x002EDA5C File Offset: 0x002EBC5C
		public unsafe Il2CppReferenceArray<VestHapticClip> BodyClips
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_BodyClips);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<VestHapticClip>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_BodyClips), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004142 RID: 16706
		// (get) Token: 0x0600B71B RID: 46875 RVA: 0x002EDA84 File Offset: 0x002EBC84
		// (set) Token: 0x0600B71C RID: 46876 RVA: 0x002EDAB8 File Offset: 0x002EBCB8
		public unsafe Il2CppReferenceArray<ArmsHapticClip> LeftArmClips
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_LeftArmClips);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<ArmsHapticClip>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_LeftArmClips), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004143 RID: 16707
		// (get) Token: 0x0600B71D RID: 46877 RVA: 0x002EDAE0 File Offset: 0x002EBCE0
		// (set) Token: 0x0600B71E RID: 46878 RVA: 0x002EDB14 File Offset: 0x002EBD14
		public unsafe Il2CppReferenceArray<ArmsHapticClip> RightArmClips
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_RightArmClips);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<ArmsHapticClip>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_RightArmClips), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004144 RID: 16708
		// (get) Token: 0x0600B71F RID: 46879 RVA: 0x002EDB3C File Offset: 0x002EBD3C
		// (set) Token: 0x0600B720 RID: 46880 RVA: 0x002EDB64 File Offset: 0x002EBD64
		public unsafe float yOffsetMultiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_yOffsetMultiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSender.NativeFieldInfoPtr_yOffsetMultiplier)) = value;
			}
		}

		// Token: 0x04007553 RID: 30035
		private static readonly IntPtr NativeFieldInfoPtr_DefaultClips;

		// Token: 0x04007554 RID: 30036
		private static readonly IntPtr NativeFieldInfoPtr_HeadClips;

		// Token: 0x04007555 RID: 30037
		private static readonly IntPtr NativeFieldInfoPtr_BodyClips;

		// Token: 0x04007556 RID: 30038
		private static readonly IntPtr NativeFieldInfoPtr_LeftArmClips;

		// Token: 0x04007557 RID: 30039
		private static readonly IntPtr NativeFieldInfoPtr_RightArmClips;

		// Token: 0x04007558 RID: 30040
		private static readonly IntPtr NativeFieldInfoPtr_yOffsetMultiplier;

		// Token: 0x04007559 RID: 30041
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_PositionTag_0;

		// Token: 0x0400755A RID: 30042
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_PositionTag_Vector3_Collider_0;

		// Token: 0x0400755B RID: 30043
		private static readonly IntPtr NativeMethodInfoPtr_Play_Private_Void_PositionTag_Vector3_Vector3_Vector3_Single_0;

		// Token: 0x0400755C RID: 30044
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_PositionTag_RaycastHit_0;

		// Token: 0x0400755D RID: 30045
		private static readonly IntPtr NativeMethodInfoPtr_GetClip_Private_HapticClip_PositionTag_0;

		// Token: 0x0400755E RID: 30046
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Boolean_0;

		// Token: 0x0400755F RID: 30047
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_PositionTag_Single_Single_0;

		// Token: 0x04007560 RID: 30048
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
