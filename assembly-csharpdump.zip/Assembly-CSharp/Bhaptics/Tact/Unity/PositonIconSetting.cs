﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A0 RID: 2208
	[Serializable]
	public class PositonIconSetting : Il2CppSystem.Object
	{
		// Token: 0x0600B510 RID: 46352 RVA: 0x002E4940 File Offset: 0x002E2B40
		[CallerCount(0)]
		public unsafe PositonIconSetting() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PositonIconSetting.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B511 RID: 46353 RVA: 0x002E498C File Offset: 0x002E2B8C
		// Note: this type is marked as 'beforefieldinit'.
		static PositonIconSetting()
		{
			Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "PositonIconSetting");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr);
			PositonIconSetting.NativeFieldInfoPtr_connect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr, "connect");
			PositonIconSetting.NativeFieldInfoPtr_disconnect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr, "disconnect");
			PositonIconSetting.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr, 100677973);
		}

		// Token: 0x0600B512 RID: 46354 RVA: 0x00002988 File Offset: 0x00000B88
		public PositonIconSetting(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700409D RID: 16541
		// (get) Token: 0x0600B513 RID: 46355 RVA: 0x002E49F8 File Offset: 0x002E2BF8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PositonIconSetting>.NativeClassPtr));
			}
		}

		// Token: 0x1700409E RID: 16542
		// (get) Token: 0x0600B514 RID: 46356 RVA: 0x002E4A0C File Offset: 0x002E2C0C
		// (set) Token: 0x0600B515 RID: 46357 RVA: 0x002E4A40 File Offset: 0x002E2C40
		public unsafe Sprite connect
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PositonIconSetting.NativeFieldInfoPtr_connect);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Sprite(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PositonIconSetting.NativeFieldInfoPtr_connect), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700409F RID: 16543
		// (get) Token: 0x0600B516 RID: 46358 RVA: 0x002E4A68 File Offset: 0x002E2C68
		// (set) Token: 0x0600B517 RID: 46359 RVA: 0x002E4A9C File Offset: 0x002E2C9C
		public unsafe Sprite disconnect
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PositonIconSetting.NativeFieldInfoPtr_disconnect);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Sprite(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PositonIconSetting.NativeFieldInfoPtr_disconnect), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007404 RID: 29700
		private static readonly IntPtr NativeFieldInfoPtr_connect;

		// Token: 0x04007405 RID: 29701
		private static readonly IntPtr NativeFieldInfoPtr_disconnect;

		// Token: 0x04007406 RID: 29702
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
