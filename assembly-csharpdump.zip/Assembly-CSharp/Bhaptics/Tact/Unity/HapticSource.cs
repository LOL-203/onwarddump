﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C1 RID: 2241
	public class HapticSource : MonoBehaviour
	{
		// Token: 0x0600B723 RID: 46883 RVA: 0x002EDBB4 File Offset: 0x002EBDB4
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B724 RID: 46884 RVA: 0x002EDBF8 File Offset: 0x002EBDF8
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B725 RID: 46885 RVA: 0x002EDC3C File Offset: 0x002EBE3C
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B726 RID: 46886 RVA: 0x002EDC80 File Offset: 0x002EBE80
		[CallerCount(0)]
		public unsafe void Play()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_Play_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B727 RID: 46887 RVA: 0x002EDCC4 File Offset: 0x002EBEC4
		[CallerCount(0)]
		public unsafe void PlayLoop()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_PlayLoop_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B728 RID: 46888 RVA: 0x002EDD08 File Offset: 0x002EBF08
		[CallerCount(0)]
		public unsafe void PlayDelayed([Optional] float delaySecond)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref delaySecond;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_PlayDelayed_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B729 RID: 46889 RVA: 0x002EDD5C File Offset: 0x002EBF5C
		[CallerCount(0)]
		public unsafe void Stop()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_Stop_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B72A RID: 46890 RVA: 0x002EDDA0 File Offset: 0x002EBFA0
		[CallerCount(0)]
		public unsafe bool IsPlaying()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_IsPlaying_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B72B RID: 46891 RVA: 0x002EDDF0 File Offset: 0x002EBFF0
		[CallerCount(0)]
		public unsafe IEnumerator PlayCoroutine(float delaySecond)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref delaySecond;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_PlayCoroutine_Private_IEnumerator_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600B72C RID: 46892 RVA: 0x002EDE58 File Offset: 0x002EC058
		[CallerCount(0)]
		public unsafe void PlayHapticClip()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_PlayHapticClip_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B72D RID: 46893 RVA: 0x002EDE9C File Offset: 0x002EC09C
		[CallerCount(0)]
		public unsafe IEnumerator PlayLoopCoroutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr_PlayLoopCoroutine_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600B72E RID: 46894 RVA: 0x002EDEF4 File Offset: 0x002EC0F4
		[CallerCount(0)]
		public unsafe HapticSource() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticSource>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B72F RID: 46895 RVA: 0x002EDF40 File Offset: 0x002EC140
		// Note: this type is marked as 'beforefieldinit'.
		static HapticSource()
		{
			Il2CppClassPointerStore<HapticSource>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticSource");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticSource>.NativeClassPtr);
			HapticSource.NativeFieldInfoPtr_clip = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "clip");
			HapticSource.NativeFieldInfoPtr_playOnAwake = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "playOnAwake");
			HapticSource.NativeFieldInfoPtr_loop = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "loop");
			HapticSource.NativeFieldInfoPtr_loopDelaySeconds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "loopDelaySeconds");
			HapticSource.NativeFieldInfoPtr_currentCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "currentCoroutine");
			HapticSource.NativeFieldInfoPtr_loopCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "loopCoroutine");
			HapticSource.NativeFieldInfoPtr_isLooping = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "isLooping");
			HapticSource.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678194);
			HapticSource.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678195);
			HapticSource.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678196);
			HapticSource.NativeMethodInfoPtr_Play_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678197);
			HapticSource.NativeMethodInfoPtr_PlayLoop_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678198);
			HapticSource.NativeMethodInfoPtr_PlayDelayed_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678199);
			HapticSource.NativeMethodInfoPtr_Stop_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678200);
			HapticSource.NativeMethodInfoPtr_IsPlaying_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678201);
			HapticSource.NativeMethodInfoPtr_PlayCoroutine_Private_IEnumerator_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678202);
			HapticSource.NativeMethodInfoPtr_PlayHapticClip_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678203);
			HapticSource.NativeMethodInfoPtr_PlayLoopCoroutine_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678204);
			HapticSource.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, 100678205);
		}

		// Token: 0x0600B730 RID: 46896 RVA: 0x0000210C File Offset: 0x0000030C
		public HapticSource(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004146 RID: 16710
		// (get) Token: 0x0600B731 RID: 46897 RVA: 0x002EE0EC File Offset: 0x002EC2EC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticSource>.NativeClassPtr));
			}
		}

		// Token: 0x17004147 RID: 16711
		// (get) Token: 0x0600B732 RID: 46898 RVA: 0x002EE100 File Offset: 0x002EC300
		// (set) Token: 0x0600B733 RID: 46899 RVA: 0x002EE134 File Offset: 0x002EC334
		public unsafe HapticClip clip
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_clip);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HapticClip(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_clip), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004148 RID: 16712
		// (get) Token: 0x0600B734 RID: 46900 RVA: 0x002EE15C File Offset: 0x002EC35C
		// (set) Token: 0x0600B735 RID: 46901 RVA: 0x002EE184 File Offset: 0x002EC384
		public unsafe bool playOnAwake
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_playOnAwake);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_playOnAwake)) = value;
			}
		}

		// Token: 0x17004149 RID: 16713
		// (get) Token: 0x0600B736 RID: 46902 RVA: 0x002EE1A8 File Offset: 0x002EC3A8
		// (set) Token: 0x0600B737 RID: 46903 RVA: 0x002EE1D0 File Offset: 0x002EC3D0
		public unsafe bool loop
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loop);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loop)) = value;
			}
		}

		// Token: 0x1700414A RID: 16714
		// (get) Token: 0x0600B738 RID: 46904 RVA: 0x002EE1F4 File Offset: 0x002EC3F4
		// (set) Token: 0x0600B739 RID: 46905 RVA: 0x002EE21C File Offset: 0x002EC41C
		public unsafe float loopDelaySeconds
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loopDelaySeconds);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loopDelaySeconds)) = value;
			}
		}

		// Token: 0x1700414B RID: 16715
		// (get) Token: 0x0600B73A RID: 46906 RVA: 0x002EE240 File Offset: 0x002EC440
		// (set) Token: 0x0600B73B RID: 46907 RVA: 0x002EE274 File Offset: 0x002EC474
		public unsafe Coroutine currentCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_currentCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_currentCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700414C RID: 16716
		// (get) Token: 0x0600B73C RID: 46908 RVA: 0x002EE29C File Offset: 0x002EC49C
		// (set) Token: 0x0600B73D RID: 46909 RVA: 0x002EE2D0 File Offset: 0x002EC4D0
		public unsafe Coroutine loopCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loopCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_loopCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700414D RID: 16717
		// (get) Token: 0x0600B73E RID: 46910 RVA: 0x002EE2F8 File Offset: 0x002EC4F8
		// (set) Token: 0x0600B73F RID: 46911 RVA: 0x002EE320 File Offset: 0x002EC520
		public unsafe bool isLooping
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_isLooping);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource.NativeFieldInfoPtr_isLooping)) = value;
			}
		}

		// Token: 0x04007567 RID: 30055
		private static readonly IntPtr NativeFieldInfoPtr_clip;

		// Token: 0x04007568 RID: 30056
		private static readonly IntPtr NativeFieldInfoPtr_playOnAwake;

		// Token: 0x04007569 RID: 30057
		private static readonly IntPtr NativeFieldInfoPtr_loop;

		// Token: 0x0400756A RID: 30058
		private static readonly IntPtr NativeFieldInfoPtr_loopDelaySeconds;

		// Token: 0x0400756B RID: 30059
		private static readonly IntPtr NativeFieldInfoPtr_currentCoroutine;

		// Token: 0x0400756C RID: 30060
		private static readonly IntPtr NativeFieldInfoPtr_loopCoroutine;

		// Token: 0x0400756D RID: 30061
		private static readonly IntPtr NativeFieldInfoPtr_isLooping;

		// Token: 0x0400756E RID: 30062
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400756F RID: 30063
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04007570 RID: 30064
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04007571 RID: 30065
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_0;

		// Token: 0x04007572 RID: 30066
		private static readonly IntPtr NativeMethodInfoPtr_PlayLoop_Public_Void_0;

		// Token: 0x04007573 RID: 30067
		private static readonly IntPtr NativeMethodInfoPtr_PlayDelayed_Public_Void_Single_0;

		// Token: 0x04007574 RID: 30068
		private static readonly IntPtr NativeMethodInfoPtr_Stop_Public_Void_0;

		// Token: 0x04007575 RID: 30069
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Boolean_0;

		// Token: 0x04007576 RID: 30070
		private static readonly IntPtr NativeMethodInfoPtr_PlayCoroutine_Private_IEnumerator_Single_0;

		// Token: 0x04007577 RID: 30071
		private static readonly IntPtr NativeMethodInfoPtr_PlayHapticClip_Private_Void_0;

		// Token: 0x04007578 RID: 30072
		private static readonly IntPtr NativeMethodInfoPtr_PlayLoopCoroutine_Private_IEnumerator_0;

		// Token: 0x04007579 RID: 30073
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x020008C2 RID: 2242
		[ObfuscatedName("Bhaptics.Tact.Unity.HapticSource/<PlayCoroutine>d__15")]
		public sealed class _PlayCoroutine_d__15 : Il2CppSystem.Object
		{
			// Token: 0x0600B740 RID: 46912 RVA: 0x002EE344 File Offset: 0x002EC544
			[CallerCount(0)]
			public unsafe _PlayCoroutine_d__15(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B741 RID: 46913 RVA: 0x002EE3A4 File Offset: 0x002EC5A4
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B742 RID: 46914 RVA: 0x002EE3E8 File Offset: 0x002EC5E8
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17004153 RID: 16723
			// (get) Token: 0x0600B743 RID: 46915 RVA: 0x002EE438 File Offset: 0x002EC638
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600B744 RID: 46916 RVA: 0x002EE490 File Offset: 0x002EC690
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17004154 RID: 16724
			// (get) Token: 0x0600B745 RID: 46917 RVA: 0x002EE4D4 File Offset: 0x002EC6D4
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600B746 RID: 46918 RVA: 0x002EE52C File Offset: 0x002EC72C
			// Note: this type is marked as 'beforefieldinit'.
			static _PlayCoroutine_d__15()
			{
				Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "<PlayCoroutine>d__15");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr);
				HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, "<>1__state");
				HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, "<>2__current");
				HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr_delaySecond = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, "delaySecond");
				HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, "<>4__this");
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678206);
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678207);
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678208);
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678209);
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678210);
				HapticSource._PlayCoroutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr, 100678211);
			}

			// Token: 0x0600B747 RID: 46919 RVA: 0x00002988 File Offset: 0x00000B88
			public _PlayCoroutine_d__15(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700414E RID: 16718
			// (get) Token: 0x0600B748 RID: 46920 RVA: 0x002EE61F File Offset: 0x002EC81F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticSource._PlayCoroutine_d__15>.NativeClassPtr));
				}
			}

			// Token: 0x1700414F RID: 16719
			// (get) Token: 0x0600B749 RID: 46921 RVA: 0x002EE630 File Offset: 0x002EC830
			// (set) Token: 0x0600B74A RID: 46922 RVA: 0x002EE658 File Offset: 0x002EC858
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17004150 RID: 16720
			// (get) Token: 0x0600B74B RID: 46923 RVA: 0x002EE67C File Offset: 0x002EC87C
			// (set) Token: 0x0600B74C RID: 46924 RVA: 0x002EE6B0 File Offset: 0x002EC8B0
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004151 RID: 16721
			// (get) Token: 0x0600B74D RID: 46925 RVA: 0x002EE6D8 File Offset: 0x002EC8D8
			// (set) Token: 0x0600B74E RID: 46926 RVA: 0x002EE700 File Offset: 0x002EC900
			public unsafe float delaySecond
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr_delaySecond);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr_delaySecond)) = value;
				}
			}

			// Token: 0x17004152 RID: 16722
			// (get) Token: 0x0600B74F RID: 46927 RVA: 0x002EE724 File Offset: 0x002EC924
			// (set) Token: 0x0600B750 RID: 46928 RVA: 0x002EE758 File Offset: 0x002EC958
			public unsafe HapticSource __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new HapticSource(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayCoroutine_d__15.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400757A RID: 30074
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400757B RID: 30075
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400757C RID: 30076
			private static readonly IntPtr NativeFieldInfoPtr_delaySecond;

			// Token: 0x0400757D RID: 30077
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400757E RID: 30078
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400757F RID: 30079
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007580 RID: 30080
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x04007581 RID: 30081
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x04007582 RID: 30082
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007583 RID: 30083
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}

		// Token: 0x020008C3 RID: 2243
		[ObfuscatedName("Bhaptics.Tact.Unity.HapticSource/<PlayLoopCoroutine>d__17")]
		public sealed class _PlayLoopCoroutine_d__17 : Il2CppSystem.Object
		{
			// Token: 0x0600B751 RID: 46929 RVA: 0x002EE780 File Offset: 0x002EC980
			[CallerCount(0)]
			public unsafe _PlayLoopCoroutine_d__17(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B752 RID: 46930 RVA: 0x002EE7E0 File Offset: 0x002EC9E0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B753 RID: 46931 RVA: 0x002EE824 File Offset: 0x002ECA24
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x1700415A RID: 16730
			// (get) Token: 0x0600B754 RID: 46932 RVA: 0x002EE874 File Offset: 0x002ECA74
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600B755 RID: 46933 RVA: 0x002EE8CC File Offset: 0x002ECACC
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x1700415B RID: 16731
			// (get) Token: 0x0600B756 RID: 46934 RVA: 0x002EE910 File Offset: 0x002ECB10
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600B757 RID: 46935 RVA: 0x002EE968 File Offset: 0x002ECB68
			// Note: this type is marked as 'beforefieldinit'.
			static _PlayLoopCoroutine_d__17()
			{
				Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<HapticSource>.NativeClassPtr, "<PlayLoopCoroutine>d__17");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr);
				HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, "<>1__state");
				HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, "<>2__current");
				HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, "<>4__this");
				HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr__duration_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, "<duration>5__2");
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678212);
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678213);
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678214);
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678215);
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678216);
				HapticSource._PlayLoopCoroutine_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr, 100678217);
			}

			// Token: 0x0600B758 RID: 46936 RVA: 0x00002988 File Offset: 0x00000B88
			public _PlayLoopCoroutine_d__17(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004155 RID: 16725
			// (get) Token: 0x0600B759 RID: 46937 RVA: 0x002EEA5B File Offset: 0x002ECC5B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticSource._PlayLoopCoroutine_d__17>.NativeClassPtr));
				}
			}

			// Token: 0x17004156 RID: 16726
			// (get) Token: 0x0600B75A RID: 46938 RVA: 0x002EEA6C File Offset: 0x002ECC6C
			// (set) Token: 0x0600B75B RID: 46939 RVA: 0x002EEA94 File Offset: 0x002ECC94
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17004157 RID: 16727
			// (get) Token: 0x0600B75C RID: 46940 RVA: 0x002EEAB8 File Offset: 0x002ECCB8
			// (set) Token: 0x0600B75D RID: 46941 RVA: 0x002EEAEC File Offset: 0x002ECCEC
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004158 RID: 16728
			// (get) Token: 0x0600B75E RID: 46942 RVA: 0x002EEB14 File Offset: 0x002ECD14
			// (set) Token: 0x0600B75F RID: 46943 RVA: 0x002EEB48 File Offset: 0x002ECD48
			public unsafe HapticSource __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new HapticSource(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004159 RID: 16729
			// (get) Token: 0x0600B760 RID: 46944 RVA: 0x002EEB70 File Offset: 0x002ECD70
			// (set) Token: 0x0600B761 RID: 46945 RVA: 0x002EEBA4 File Offset: 0x002ECDA4
			public unsafe WaitForSeconds _duration_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr__duration_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new WaitForSeconds(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticSource._PlayLoopCoroutine_d__17.NativeFieldInfoPtr__duration_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x04007584 RID: 30084
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x04007585 RID: 30085
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x04007586 RID: 30086
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04007587 RID: 30087
			private static readonly IntPtr NativeFieldInfoPtr__duration_5__2;

			// Token: 0x04007588 RID: 30088
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x04007589 RID: 30089
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400758A RID: 30090
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400758B RID: 30091
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400758C RID: 30092
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400758D RID: 30093
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
