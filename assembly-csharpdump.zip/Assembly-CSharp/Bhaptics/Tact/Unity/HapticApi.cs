﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x02000896 RID: 2198
	public class HapticApi : Object
	{
		// Token: 0x0600B455 RID: 46165 RVA: 0x002E165C File Offset: 0x002DF85C
		[CallerCount(0)]
		public unsafe static bool TryGetExePath(Il2CppStructArray<byte> buf, ref int size)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(buf);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &size;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_TryGetExePath_Public_Static_Boolean_ArrayOf_Byte_byref_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B456 RID: 46166 RVA: 0x002E16C8 File Offset: 0x002DF8C8
		[CallerCount(0)]
		public unsafe static void Initialise(string appId, string appName)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(appId);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(appName);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_Initialise_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B457 RID: 46167 RVA: 0x002E172C File Offset: 0x002DF92C
		[CallerCount(0)]
		public unsafe static void Destroy()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_Destroy_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B458 RID: 46168 RVA: 0x002E1760 File Offset: 0x002DF960
		[CallerCount(0)]
		public unsafe static void RegisterFeedback(string str, string projectJson)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(str);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(projectJson);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_RegisterFeedback_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B459 RID: 46169 RVA: 0x002E17C4 File Offset: 0x002DF9C4
		[CallerCount(0)]
		public unsafe static void RegisterFeedbackFromTactFile(string str, string tactFileStr)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(str);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_RegisterFeedbackFromTactFile_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45A RID: 46170 RVA: 0x002E1828 File Offset: 0x002DFA28
		[CallerCount(0)]
		public unsafe static void RegisterFeedbackFromTactFileReflected(string str, string tactFileStr)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(str);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_RegisterFeedbackFromTactFileReflected_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45B RID: 46171 RVA: 0x002E188C File Offset: 0x002DFA8C
		[CallerCount(0)]
		public unsafe static void SubmitRegistered(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_SubmitRegistered_Public_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45C RID: 46172 RVA: 0x002E18D8 File Offset: 0x002DFAD8
		[CallerCount(0)]
		public unsafe static void SubmitRegisteredStartMillis(string key, int startTimeMillis)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref startTimeMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_SubmitRegisteredStartMillis_Public_Static_Void_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45D RID: 46173 RVA: 0x002E1938 File Offset: 0x002DFB38
		[CallerCount(0)]
		public unsafe static void SubmitRegisteredWithOption(string key, string altKey, float intensity, float duration, float offsetX, float offsetY)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensity;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetX;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_SubmitRegisteredWithOption_Public_Static_Void_String_String_Single_Single_Single_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45E RID: 46174 RVA: 0x002E19E8 File Offset: 0x002DFBE8
		[CallerCount(0)]
		public unsafe static void SubmitByteArray(string key, PositionType pos, Il2CppStructArray<byte> charPtr, int length, int durationMillis)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(charPtr);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref length;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_SubmitByteArray_Public_Static_Void_String_PositionType_ArrayOf_Byte_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B45F RID: 46175 RVA: 0x002E1A84 File Offset: 0x002DFC84
		[CallerCount(0)]
		public unsafe static void SubmitPathArray(string key, PositionType pos, Il2CppStructArray<HapticApi.point> charPtr, int length, int durationMillis)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(charPtr);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref length;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_SubmitPathArray_Public_Static_Void_String_PositionType_ArrayOf_point_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B460 RID: 46176 RVA: 0x002E1B20 File Offset: 0x002DFD20
		[CallerCount(0)]
		public unsafe static bool IsFeedbackRegistered(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B461 RID: 46177 RVA: 0x002E1B78 File Offset: 0x002DFD78
		[CallerCount(0)]
		public unsafe static bool IsPlaying()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_IsPlaying_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B462 RID: 46178 RVA: 0x002E1BBC File Offset: 0x002DFDBC
		[CallerCount(0)]
		public unsafe static bool IsPlayingKey(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_IsPlayingKey_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B463 RID: 46179 RVA: 0x002E1C14 File Offset: 0x002DFE14
		[CallerCount(0)]
		public unsafe static void TurnOff()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_TurnOff_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B464 RID: 46180 RVA: 0x002E1C48 File Offset: 0x002DFE48
		[CallerCount(0)]
		public unsafe static void TurnOffKey(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_TurnOffKey_Public_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B465 RID: 46181 RVA: 0x002E1C94 File Offset: 0x002DFE94
		[CallerCount(0)]
		public unsafe static void EnableFeedback()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_EnableFeedback_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B466 RID: 46182 RVA: 0x002E1CC8 File Offset: 0x002DFEC8
		[CallerCount(0)]
		public unsafe static void DisableFeedback()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_DisableFeedback_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B467 RID: 46183 RVA: 0x002E1CFC File Offset: 0x002DFEFC
		[CallerCount(0)]
		public unsafe static void ToggleFeedback()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_ToggleFeedback_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B468 RID: 46184 RVA: 0x002E1D30 File Offset: 0x002DFF30
		[CallerCount(0)]
		public unsafe static bool IsDevicePlaying(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_IsDevicePlaying_Public_Static_Boolean_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B469 RID: 46185 RVA: 0x002E1D84 File Offset: 0x002DFF84
		[CallerCount(0)]
		public unsafe static bool TryGetResponseForPosition(PositionType pos, out HapticApi.status status)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(status);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr_TryGetResponseForPosition_Public_Static_Boolean_PositionType_byref_status_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B46A RID: 46186 RVA: 0x002E1DF0 File Offset: 0x002DFFF0
		[CallerCount(0)]
		public unsafe HapticApi() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticApi>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticApi.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B46B RID: 46187 RVA: 0x002E1E3C File Offset: 0x002E003C
		// Note: this type is marked as 'beforefieldinit'.
		static HapticApi()
		{
			Il2CppClassPointerStore<HapticApi>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticApi");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticApi>.NativeClassPtr);
			HapticApi.NativeMethodInfoPtr_TryGetExePath_Public_Static_Boolean_ArrayOf_Byte_byref_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677906);
			HapticApi.NativeMethodInfoPtr_Initialise_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677907);
			HapticApi.NativeMethodInfoPtr_Destroy_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677908);
			HapticApi.NativeMethodInfoPtr_RegisterFeedback_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677909);
			HapticApi.NativeMethodInfoPtr_RegisterFeedbackFromTactFile_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677910);
			HapticApi.NativeMethodInfoPtr_RegisterFeedbackFromTactFileReflected_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677911);
			HapticApi.NativeMethodInfoPtr_SubmitRegistered_Public_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677912);
			HapticApi.NativeMethodInfoPtr_SubmitRegisteredStartMillis_Public_Static_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677913);
			HapticApi.NativeMethodInfoPtr_SubmitRegisteredWithOption_Public_Static_Void_String_String_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677914);
			HapticApi.NativeMethodInfoPtr_SubmitByteArray_Public_Static_Void_String_PositionType_ArrayOf_Byte_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677915);
			HapticApi.NativeMethodInfoPtr_SubmitPathArray_Public_Static_Void_String_PositionType_ArrayOf_point_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677916);
			HapticApi.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677917);
			HapticApi.NativeMethodInfoPtr_IsPlaying_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677918);
			HapticApi.NativeMethodInfoPtr_IsPlayingKey_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677919);
			HapticApi.NativeMethodInfoPtr_TurnOff_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677920);
			HapticApi.NativeMethodInfoPtr_TurnOffKey_Public_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677921);
			HapticApi.NativeMethodInfoPtr_EnableFeedback_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677922);
			HapticApi.NativeMethodInfoPtr_DisableFeedback_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677923);
			HapticApi.NativeMethodInfoPtr_ToggleFeedback_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677924);
			HapticApi.NativeMethodInfoPtr_IsDevicePlaying_Public_Static_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677925);
			HapticApi.NativeMethodInfoPtr_TryGetResponseForPosition_Public_Static_Boolean_PositionType_byref_status_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677926);
			HapticApi.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, 100677927);
		}

		// Token: 0x0600B46C RID: 46188 RVA: 0x00002988 File Offset: 0x00000B88
		public HapticApi(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004066 RID: 16486
		// (get) Token: 0x0600B46D RID: 46189 RVA: 0x002E2024 File Offset: 0x002E0224
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticApi>.NativeClassPtr));
			}
		}

		// Token: 0x0400738B RID: 29579
		private static readonly IntPtr NativeMethodInfoPtr_TryGetExePath_Public_Static_Boolean_ArrayOf_Byte_byref_Int32_0;

		// Token: 0x0400738C RID: 29580
		private static readonly IntPtr NativeMethodInfoPtr_Initialise_Public_Static_Void_String_String_0;

		// Token: 0x0400738D RID: 29581
		private static readonly IntPtr NativeMethodInfoPtr_Destroy_Public_Static_Void_0;

		// Token: 0x0400738E RID: 29582
		private static readonly IntPtr NativeMethodInfoPtr_RegisterFeedback_Public_Static_Void_String_String_0;

		// Token: 0x0400738F RID: 29583
		private static readonly IntPtr NativeMethodInfoPtr_RegisterFeedbackFromTactFile_Public_Static_Void_String_String_0;

		// Token: 0x04007390 RID: 29584
		private static readonly IntPtr NativeMethodInfoPtr_RegisterFeedbackFromTactFileReflected_Public_Static_Void_String_String_0;

		// Token: 0x04007391 RID: 29585
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Static_Void_String_0;

		// Token: 0x04007392 RID: 29586
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegisteredStartMillis_Public_Static_Void_String_Int32_0;

		// Token: 0x04007393 RID: 29587
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegisteredWithOption_Public_Static_Void_String_String_Single_Single_Single_Single_0;

		// Token: 0x04007394 RID: 29588
		private static readonly IntPtr NativeMethodInfoPtr_SubmitByteArray_Public_Static_Void_String_PositionType_ArrayOf_Byte_Int32_Int32_0;

		// Token: 0x04007395 RID: 29589
		private static readonly IntPtr NativeMethodInfoPtr_SubmitPathArray_Public_Static_Void_String_PositionType_ArrayOf_point_Int32_Int32_0;

		// Token: 0x04007396 RID: 29590
		private static readonly IntPtr NativeMethodInfoPtr_IsFeedbackRegistered_Public_Static_Boolean_String_0;

		// Token: 0x04007397 RID: 29591
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Static_Boolean_0;

		// Token: 0x04007398 RID: 29592
		private static readonly IntPtr NativeMethodInfoPtr_IsPlayingKey_Public_Static_Boolean_String_0;

		// Token: 0x04007399 RID: 29593
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Static_Void_0;

		// Token: 0x0400739A RID: 29594
		private static readonly IntPtr NativeMethodInfoPtr_TurnOffKey_Public_Static_Void_String_0;

		// Token: 0x0400739B RID: 29595
		private static readonly IntPtr NativeMethodInfoPtr_EnableFeedback_Public_Static_Void_0;

		// Token: 0x0400739C RID: 29596
		private static readonly IntPtr NativeMethodInfoPtr_DisableFeedback_Public_Static_Void_0;

		// Token: 0x0400739D RID: 29597
		private static readonly IntPtr NativeMethodInfoPtr_ToggleFeedback_Public_Static_Void_0;

		// Token: 0x0400739E RID: 29598
		private static readonly IntPtr NativeMethodInfoPtr_IsDevicePlaying_Public_Static_Boolean_PositionType_0;

		// Token: 0x0400739F RID: 29599
		private static readonly IntPtr NativeMethodInfoPtr_TryGetResponseForPosition_Public_Static_Boolean_PositionType_byref_status_0;

		// Token: 0x040073A0 RID: 29600
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000897 RID: 2199
		[StructLayout(2)]
		public struct point
		{
			// Token: 0x0600B46E RID: 46190 RVA: 0x002E2038 File Offset: 0x002E0238
			// Note: this type is marked as 'beforefieldinit'.
			static point()
			{
				Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, "point");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr);
				HapticApi.point.NativeFieldInfoPtr_x = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr, "x");
				HapticApi.point.NativeFieldInfoPtr_y = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr, "y");
				HapticApi.point.NativeFieldInfoPtr_intensity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr, "intensity");
				HapticApi.point.NativeFieldInfoPtr_motorCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr, "motorCount");
			}

			// Token: 0x0600B46F RID: 46191 RVA: 0x002E20B3 File Offset: 0x002E02B3
			public Object BoxIl2CppObject()
			{
				return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr, ref this));
			}

			// Token: 0x17004067 RID: 16487
			// (get) Token: 0x0600B470 RID: 46192 RVA: 0x002E20C5 File Offset: 0x002E02C5
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticApi.point>.NativeClassPtr));
				}
			}

			// Token: 0x040073A1 RID: 29601
			private static readonly IntPtr NativeFieldInfoPtr_x;

			// Token: 0x040073A2 RID: 29602
			private static readonly IntPtr NativeFieldInfoPtr_y;

			// Token: 0x040073A3 RID: 29603
			private static readonly IntPtr NativeFieldInfoPtr_intensity;

			// Token: 0x040073A4 RID: 29604
			private static readonly IntPtr NativeFieldInfoPtr_motorCount;

			// Token: 0x040073A5 RID: 29605
			[FieldOffset(0)]
			public float x;

			// Token: 0x040073A6 RID: 29606
			[FieldOffset(4)]
			public float y;

			// Token: 0x040073A7 RID: 29607
			[FieldOffset(8)]
			public int intensity;

			// Token: 0x040073A8 RID: 29608
			[FieldOffset(12)]
			public int motorCount;
		}

		// Token: 0x02000898 RID: 2200
		[StructLayout(0)]
		public sealed class status : ValueType
		{
			// Token: 0x0600B471 RID: 46193 RVA: 0x002E20D6 File Offset: 0x002E02D6
			// Note: this type is marked as 'beforefieldinit'.
			static status()
			{
				Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<HapticApi>.NativeClassPtr, "status");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr);
				HapticApi.status.NativeFieldInfoPtr_values = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr, "values");
			}

			// Token: 0x0600B472 RID: 46194 RVA: 0x0002717B File Offset: 0x0002537B
			public status(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004068 RID: 16488
			// (get) Token: 0x0600B473 RID: 46195 RVA: 0x002E210A File Offset: 0x002E030A
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr));
				}
			}

			// Token: 0x0600B474 RID: 46196 RVA: 0x002E211C File Offset: 0x002E031C
			public unsafe status()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<HapticApi.status>.NativeClassPtr, data));
			}

			// Token: 0x17004069 RID: 16489
			// (get) Token: 0x0600B475 RID: 46197 RVA: 0x002E214C File Offset: 0x002E034C
			// (set) Token: 0x0600B476 RID: 46198 RVA: 0x002E2180 File Offset: 0x002E0380
			public unsafe Il2CppStructArray<int> values
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticApi.status.NativeFieldInfoPtr_values);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticApi.status.NativeFieldInfoPtr_values), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x040073A9 RID: 29609
			private static readonly IntPtr NativeFieldInfoPtr_values;
		}
	}
}
