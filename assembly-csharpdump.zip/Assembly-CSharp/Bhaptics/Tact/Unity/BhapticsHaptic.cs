﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A6 RID: 2214
	public class BhapticsHaptic : Object
	{
		// Token: 0x0600B5BB RID: 46523 RVA: 0x002E7298 File Offset: 0x002E5498
		[CallerCount(0)]
		public unsafe BhapticsHaptic() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5BC RID: 46524 RVA: 0x002E72E4 File Offset: 0x002E54E4
		[CallerCount(0)]
		public unsafe bool IsConnect(PositionType type)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5BD RID: 46525 RVA: 0x002E7348 File Offset: 0x002E5548
		[CallerCount(0)]
		public unsafe bool IsConnect(HapticDeviceType type, bool isLeft = true)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isLeft;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5BE RID: 46526 RVA: 0x002E73C0 File Offset: 0x002E55C0
		[CallerCount(0)]
		public unsafe bool IsPlaying(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5BF RID: 46527 RVA: 0x002E7428 File Offset: 0x002E5628
		[CallerCount(0)]
		public unsafe bool IsFeedbackRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5C0 RID: 46528 RVA: 0x002E7490 File Offset: 0x002E5690
		[CallerCount(0)]
		public unsafe bool IsPlaying()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5C1 RID: 46529 RVA: 0x002E74E0 File Offset: 0x002E56E0
		[CallerCount(0)]
		public unsafe void RegisterTactFileStr(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C2 RID: 46530 RVA: 0x002E7554 File Offset: 0x002E5754
		[CallerCount(0)]
		public unsafe void RegisterTactFileStrReflected(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C3 RID: 46531 RVA: 0x002E75C8 File Offset: 0x002E57C8
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<DotPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C4 RID: 46532 RVA: 0x002E7660 File Offset: 0x002E5860
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<PathPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C5 RID: 46533 RVA: 0x002E76F8 File Offset: 0x002E58F8
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, ScaleOption option)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(option);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C6 RID: 46534 RVA: 0x002E7784 File Offset: 0x002E5984
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, RotationOption rOption, ScaleOption sOption)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(rOption);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(sOption);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C7 RID: 46535 RVA: 0x002E7828 File Offset: 0x002E5A28
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C8 RID: 46536 RVA: 0x002E7884 File Offset: 0x002E5A84
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, int startTimeMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref startTimeMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5C9 RID: 46537 RVA: 0x002E78F0 File Offset: 0x002E5AF0
		[CallerCount(0)]
		public unsafe void TurnOff(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5CA RID: 46538 RVA: 0x002E794C File Offset: 0x002E5B4C
		[CallerCount(0)]
		public unsafe void TurnOff()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5CB RID: 46539 RVA: 0x002E7990 File Offset: 0x002E5B90
		[CallerCount(0)]
		public unsafe void Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5CC RID: 46540 RVA: 0x002E79D4 File Offset: 0x002E5BD4
		[CallerCount(0)]
		public unsafe Il2CppStructArray<int> GetCurrentFeedback(PositionType pos)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}

		// Token: 0x0600B5CD RID: 46541 RVA: 0x002E7A3C File Offset: 0x002E5C3C
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsHaptic()
		{
			Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "BhapticsHaptic");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr);
			BhapticsHaptic.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678024);
			BhapticsHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678025);
			BhapticsHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678026);
			BhapticsHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678027);
			BhapticsHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678028);
			BhapticsHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678029);
			BhapticsHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678030);
			BhapticsHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678031);
			BhapticsHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678032);
			BhapticsHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678033);
			BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678034);
			BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678035);
			BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678036);
			BhapticsHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678037);
			BhapticsHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678038);
			BhapticsHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678039);
			BhapticsHaptic.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678040);
			BhapticsHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr, 100678041);
		}

		// Token: 0x0600B5CE RID: 46542 RVA: 0x00002988 File Offset: 0x00000B88
		public BhapticsHaptic(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040D7 RID: 16599
		// (get) Token: 0x0600B5CF RID: 46543 RVA: 0x002E7BD4 File Offset: 0x002E5DD4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsHaptic>.NativeClassPtr));
			}
		}

		// Token: 0x04007469 RID: 29801
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0400746A RID: 29802
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0;

		// Token: 0x0400746B RID: 29803
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0;

		// Token: 0x0400746C RID: 29804
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0;

		// Token: 0x0400746D RID: 29805
		private static readonly IntPtr NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0;

		// Token: 0x0400746E RID: 29806
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0;

		// Token: 0x0400746F RID: 29807
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0;

		// Token: 0x04007470 RID: 29808
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0;

		// Token: 0x04007471 RID: 29809
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0;

		// Token: 0x04007472 RID: 29810
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0;

		// Token: 0x04007473 RID: 29811
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0;

		// Token: 0x04007474 RID: 29812
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0;

		// Token: 0x04007475 RID: 29813
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0;

		// Token: 0x04007476 RID: 29814
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0;

		// Token: 0x04007477 RID: 29815
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0;

		// Token: 0x04007478 RID: 29816
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0;

		// Token: 0x04007479 RID: 29817
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400747A RID: 29818
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0;
	}
}
