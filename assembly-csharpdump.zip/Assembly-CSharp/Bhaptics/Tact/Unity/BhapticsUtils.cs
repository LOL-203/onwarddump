﻿using System;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B5 RID: 2229
	public class BhapticsUtils : Il2CppSystem.Object
	{
		// Token: 0x0600B699 RID: 46745 RVA: 0x002EB478 File Offset: 0x002E9678
		[CallerCount(0)]
		public unsafe static Il2CppArrayBase<T> SubArray<T>(Il2CppArrayBase<T> data, int index, int length)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref index;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref length;
			IntPtr returnedException;
			IntPtr pointer = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.MethodInfoStoreGeneric_SubArray_Private_Static_ArrayOf_T_ArrayOf_T_Int32_Int32_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return Il2CppArrayBase<T>.WrapNativeGenericArrayPointer(pointer);
		}

		// Token: 0x0600B69A RID: 46746 RVA: 0x002EB4F4 File Offset: 0x002E96F4
		[CallerCount(0)]
		public unsafe static string GetExePath()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_GetExePath_Public_Static_String_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600B69B RID: 46747 RVA: 0x002EB530 File Offset: 0x002E9730
		[CallerCount(0)]
		public unsafe static bool IsPlayerInstalled()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_IsPlayerInstalled_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B69C RID: 46748 RVA: 0x002EB574 File Offset: 0x002E9774
		[CallerCount(0)]
		public unsafe static bool IsPlayerRunning()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_IsPlayerRunning_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B69D RID: 46749 RVA: 0x002EB5B8 File Offset: 0x002E97B8
		[CallerCount(0)]
		public unsafe static bool Is64BitBuild()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_Is64BitBuild_Private_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B69E RID: 46750 RVA: 0x002EB5FC File Offset: 0x002E97FC
		[CallerCount(0)]
		public unsafe static void LaunchPlayer(bool tryLaunch)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref tryLaunch;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_LaunchPlayer_Public_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B69F RID: 46751 RVA: 0x002EB644 File Offset: 0x002E9844
		[CallerCount(0)]
		public unsafe static float Angle(Vector3 fwd, Vector3 targetDir)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref fwd;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetDir;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_Angle_Public_Static_Single_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B6A0 RID: 46752 RVA: 0x002EB6AC File Offset: 0x002E98AC
		[CallerCount(0)]
		public unsafe static int AngleDir(Vector3 fwd, Vector3 targetDir, Vector3 up)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref fwd;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetDir;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref up;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_AngleDir_Private_Static_Int32_Vector3_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B6A1 RID: 46753 RVA: 0x002EB728 File Offset: 0x002E9928
		[CallerCount(0)]
		public unsafe static PositionType ToPositionType(HapticClipPositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticClipPositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B6A2 RID: 46754 RVA: 0x002EB77C File Offset: 0x002E997C
		[CallerCount(0)]
		public unsafe static PositionType ToPositionType(HapticDeviceType pos, bool isLeft = true)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isLeft;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticDeviceType_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B6A3 RID: 46755 RVA: 0x002EB7E4 File Offset: 0x002E99E4
		[CallerCount(0)]
		public unsafe BhapticsUtils() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsUtils.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6A4 RID: 46756 RVA: 0x002EB830 File Offset: 0x002E9A30
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsUtils()
		{
			Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "BhapticsUtils");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr);
			BhapticsUtils.NativeFieldInfoPtr_isInit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "isInit");
			BhapticsUtils.NativeFieldInfoPtr_exeFilePath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "exeFilePath");
			BhapticsUtils.NativeFieldInfoPtr_TypeHead = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeHead");
			BhapticsUtils.NativeFieldInfoPtr_TypeTactal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeTactal");
			BhapticsUtils.NativeFieldInfoPtr_TypeVest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeVest");
			BhapticsUtils.NativeFieldInfoPtr_TypeTactot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeTactot");
			BhapticsUtils.NativeFieldInfoPtr_TypeTactosy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeTactosy");
			BhapticsUtils.NativeFieldInfoPtr_TypeTactosy2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeTactosy2");
			BhapticsUtils.NativeFieldInfoPtr_TypeHand = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeHand");
			BhapticsUtils.NativeFieldInfoPtr_TypeFoot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeFoot");
			BhapticsUtils.NativeFieldInfoPtr_TypeGlove = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, "TypeGlove");
			BhapticsUtils.NativeMethodInfoPtr_SubArray_Private_Static_ArrayOf_T_ArrayOf_T_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678139);
			BhapticsUtils.NativeMethodInfoPtr_GetExePath_Public_Static_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678140);
			BhapticsUtils.NativeMethodInfoPtr_IsPlayerInstalled_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678141);
			BhapticsUtils.NativeMethodInfoPtr_IsPlayerRunning_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678142);
			BhapticsUtils.NativeMethodInfoPtr_Is64BitBuild_Private_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678143);
			BhapticsUtils.NativeMethodInfoPtr_LaunchPlayer_Public_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678144);
			BhapticsUtils.NativeMethodInfoPtr_Angle_Public_Static_Single_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678145);
			BhapticsUtils.NativeMethodInfoPtr_AngleDir_Private_Static_Int32_Vector3_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678146);
			BhapticsUtils.NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticClipPositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678147);
			BhapticsUtils.NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticDeviceType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678148);
			BhapticsUtils.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr, 100678149);
		}

		// Token: 0x0600B6A5 RID: 46757 RVA: 0x00002988 File Offset: 0x00000B88
		public BhapticsUtils(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004120 RID: 16672
		// (get) Token: 0x0600B6A6 RID: 46758 RVA: 0x002EBA18 File Offset: 0x002E9C18
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr));
			}
		}

		// Token: 0x17004121 RID: 16673
		// (get) Token: 0x0600B6A7 RID: 46759 RVA: 0x002EBA2C File Offset: 0x002E9C2C
		// (set) Token: 0x0600B6A8 RID: 46760 RVA: 0x002EBA4A File Offset: 0x002E9C4A
		public unsafe static bool isInit
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_isInit, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_isInit, (void*)(&value));
			}
		}

		// Token: 0x17004122 RID: 16674
		// (get) Token: 0x0600B6A9 RID: 46761 RVA: 0x002EBA5C File Offset: 0x002E9C5C
		// (set) Token: 0x0600B6AA RID: 46762 RVA: 0x002EBA7C File Offset: 0x002E9C7C
		public unsafe static string exeFilePath
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_exeFilePath, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_exeFilePath, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004123 RID: 16675
		// (get) Token: 0x0600B6AB RID: 46763 RVA: 0x002EBA94 File Offset: 0x002E9C94
		// (set) Token: 0x0600B6AC RID: 46764 RVA: 0x002EBAB4 File Offset: 0x002E9CB4
		public unsafe static string TypeHead
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeHead, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeHead, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004124 RID: 16676
		// (get) Token: 0x0600B6AD RID: 46765 RVA: 0x002EBACC File Offset: 0x002E9CCC
		// (set) Token: 0x0600B6AE RID: 46766 RVA: 0x002EBAEC File Offset: 0x002E9CEC
		public unsafe static string TypeTactal
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactal, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactal, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004125 RID: 16677
		// (get) Token: 0x0600B6AF RID: 46767 RVA: 0x002EBB04 File Offset: 0x002E9D04
		// (set) Token: 0x0600B6B0 RID: 46768 RVA: 0x002EBB24 File Offset: 0x002E9D24
		public unsafe static string TypeVest
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeVest, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeVest, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004126 RID: 16678
		// (get) Token: 0x0600B6B1 RID: 46769 RVA: 0x002EBB3C File Offset: 0x002E9D3C
		// (set) Token: 0x0600B6B2 RID: 46770 RVA: 0x002EBB5C File Offset: 0x002E9D5C
		public unsafe static string TypeTactot
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactot, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactot, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004127 RID: 16679
		// (get) Token: 0x0600B6B3 RID: 46771 RVA: 0x002EBB74 File Offset: 0x002E9D74
		// (set) Token: 0x0600B6B4 RID: 46772 RVA: 0x002EBB94 File Offset: 0x002E9D94
		public unsafe static string TypeTactosy
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactosy, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactosy, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004128 RID: 16680
		// (get) Token: 0x0600B6B5 RID: 46773 RVA: 0x002EBBAC File Offset: 0x002E9DAC
		// (set) Token: 0x0600B6B6 RID: 46774 RVA: 0x002EBBCC File Offset: 0x002E9DCC
		public unsafe static string TypeTactosy2
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactosy2, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeTactosy2, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004129 RID: 16681
		// (get) Token: 0x0600B6B7 RID: 46775 RVA: 0x002EBBE4 File Offset: 0x002E9DE4
		// (set) Token: 0x0600B6B8 RID: 46776 RVA: 0x002EBC04 File Offset: 0x002E9E04
		public unsafe static string TypeHand
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeHand, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeHand, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700412A RID: 16682
		// (get) Token: 0x0600B6B9 RID: 46777 RVA: 0x002EBC1C File Offset: 0x002E9E1C
		// (set) Token: 0x0600B6BA RID: 46778 RVA: 0x002EBC3C File Offset: 0x002E9E3C
		public unsafe static string TypeFoot
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeFoot, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeFoot, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700412B RID: 16683
		// (get) Token: 0x0600B6BB RID: 46779 RVA: 0x002EBC54 File Offset: 0x002E9E54
		// (set) Token: 0x0600B6BC RID: 46780 RVA: 0x002EBC74 File Offset: 0x002E9E74
		public unsafe static string TypeGlove
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BhapticsUtils.NativeFieldInfoPtr_TypeGlove, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsUtils.NativeFieldInfoPtr_TypeGlove, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x040074FB RID: 29947
		private static readonly IntPtr NativeFieldInfoPtr_isInit;

		// Token: 0x040074FC RID: 29948
		private static readonly IntPtr NativeFieldInfoPtr_exeFilePath;

		// Token: 0x040074FD RID: 29949
		private static readonly IntPtr NativeFieldInfoPtr_TypeHead;

		// Token: 0x040074FE RID: 29950
		private static readonly IntPtr NativeFieldInfoPtr_TypeTactal;

		// Token: 0x040074FF RID: 29951
		private static readonly IntPtr NativeFieldInfoPtr_TypeVest;

		// Token: 0x04007500 RID: 29952
		private static readonly IntPtr NativeFieldInfoPtr_TypeTactot;

		// Token: 0x04007501 RID: 29953
		private static readonly IntPtr NativeFieldInfoPtr_TypeTactosy;

		// Token: 0x04007502 RID: 29954
		private static readonly IntPtr NativeFieldInfoPtr_TypeTactosy2;

		// Token: 0x04007503 RID: 29955
		private static readonly IntPtr NativeFieldInfoPtr_TypeHand;

		// Token: 0x04007504 RID: 29956
		private static readonly IntPtr NativeFieldInfoPtr_TypeFoot;

		// Token: 0x04007505 RID: 29957
		private static readonly IntPtr NativeFieldInfoPtr_TypeGlove;

		// Token: 0x04007506 RID: 29958
		private static readonly IntPtr NativeMethodInfoPtr_SubArray_Private_Static_ArrayOf_T_ArrayOf_T_Int32_Int32_0;

		// Token: 0x04007507 RID: 29959
		private static readonly IntPtr NativeMethodInfoPtr_GetExePath_Public_Static_String_0;

		// Token: 0x04007508 RID: 29960
		private static readonly IntPtr NativeMethodInfoPtr_IsPlayerInstalled_Public_Static_Boolean_0;

		// Token: 0x04007509 RID: 29961
		private static readonly IntPtr NativeMethodInfoPtr_IsPlayerRunning_Public_Static_Boolean_0;

		// Token: 0x0400750A RID: 29962
		private static readonly IntPtr NativeMethodInfoPtr_Is64BitBuild_Private_Static_Boolean_0;

		// Token: 0x0400750B RID: 29963
		private static readonly IntPtr NativeMethodInfoPtr_LaunchPlayer_Public_Static_Void_Boolean_0;

		// Token: 0x0400750C RID: 29964
		private static readonly IntPtr NativeMethodInfoPtr_Angle_Public_Static_Single_Vector3_Vector3_0;

		// Token: 0x0400750D RID: 29965
		private static readonly IntPtr NativeMethodInfoPtr_AngleDir_Private_Static_Int32_Vector3_Vector3_Vector3_0;

		// Token: 0x0400750E RID: 29966
		private static readonly IntPtr NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticClipPositionType_0;

		// Token: 0x0400750F RID: 29967
		private static readonly IntPtr NativeMethodInfoPtr_ToPositionType_Public_Static_PositionType_HapticDeviceType_Boolean_0;

		// Token: 0x04007510 RID: 29968
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x020008B6 RID: 2230
		private sealed class MethodInfoStoreGeneric_SubArray_Private_Static_ArrayOf_T_ArrayOf_T_Int32_Int32_0<T>
		{
			// Token: 0x04007511 RID: 29969
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(BhapticsUtils.NativeMethodInfoPtr_SubArray_Private_Static_ArrayOf_T_ArrayOf_T_Int32_Int32_0, Il2CppClassPointerStore<BhapticsUtils>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
