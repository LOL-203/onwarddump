﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AA RID: 2218
	public class HapticEffect : Object
	{
		// Token: 0x170040E6 RID: 16614
		// (get) Token: 0x0600B5F0 RID: 46576 RVA: 0x002E84C8 File Offset: 0x002E66C8
		// (set) Token: 0x0600B5F1 RID: 46577 RVA: 0x002E8518 File Offset: 0x002E6718
		public unsafe int StartTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040E7 RID: 16615
		// (get) Token: 0x0600B5F2 RID: 46578 RVA: 0x002E856C File Offset: 0x002E676C
		// (set) Token: 0x0600B5F3 RID: 46579 RVA: 0x002E85BC File Offset: 0x002E67BC
		public unsafe int OffsetTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_get_OffsetTime_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_set_OffsetTime_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040E8 RID: 16616
		// (get) Token: 0x0600B5F4 RID: 46580 RVA: 0x002E8610 File Offset: 0x002E6810
		// (set) Token: 0x0600B5F5 RID: 46581 RVA: 0x002E8668 File Offset: 0x002E6868
		public unsafe Dictionary<string, HapticEffectMode> Modes
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_get_Modes_Public_get_Dictionary_2_String_HapticEffectMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, HapticEffectMode>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_set_Modes_Public_set_Void_Dictionary_2_String_HapticEffectMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B5F6 RID: 46582 RVA: 0x002E86C4 File Offset: 0x002E68C4
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), HapticEffect.NativeMethodInfoPtr_ToString_Public_Virtual_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600B5F7 RID: 46583 RVA: 0x002E871C File Offset: 0x002E691C
		[CallerCount(0)]
		public unsafe static HapticEffect ToEffect(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_ToEffect_Internal_Static_HapticEffect_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HapticEffect(intPtr2) : null;
		}

		// Token: 0x0600B5F8 RID: 46584 RVA: 0x002E877C File Offset: 0x002E697C
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B5F9 RID: 46585 RVA: 0x002E87D4 File Offset: 0x002E69D4
		[CallerCount(0)]
		public unsafe HapticEffect() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffect.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5FA RID: 46586 RVA: 0x002E8820 File Offset: 0x002E6A20
		// Note: this type is marked as 'beforefieldinit'.
		static HapticEffect()
		{
			Il2CppClassPointerStore<HapticEffect>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticEffect");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr);
			HapticEffect.NativeFieldInfoPtr__StartTime_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, "<StartTime>k__BackingField");
			HapticEffect.NativeFieldInfoPtr__OffsetTime_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, "<OffsetTime>k__BackingField");
			HapticEffect.NativeFieldInfoPtr__Modes_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, "<Modes>k__BackingField");
			HapticEffect.NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678057);
			HapticEffect.NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678058);
			HapticEffect.NativeMethodInfoPtr_get_OffsetTime_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678059);
			HapticEffect.NativeMethodInfoPtr_set_OffsetTime_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678060);
			HapticEffect.NativeMethodInfoPtr_get_Modes_Public_get_Dictionary_2_String_HapticEffectMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678061);
			HapticEffect.NativeMethodInfoPtr_set_Modes_Public_set_Void_Dictionary_2_String_HapticEffectMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678062);
			HapticEffect.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678063);
			HapticEffect.NativeMethodInfoPtr_ToEffect_Internal_Static_HapticEffect_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678064);
			HapticEffect.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678065);
			HapticEffect.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr, 100678066);
		}

		// Token: 0x0600B5FB RID: 46587 RVA: 0x00002988 File Offset: 0x00000B88
		public HapticEffect(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040E2 RID: 16610
		// (get) Token: 0x0600B5FC RID: 46588 RVA: 0x002E8954 File Offset: 0x002E6B54
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticEffect>.NativeClassPtr));
			}
		}

		// Token: 0x170040E3 RID: 16611
		// (get) Token: 0x0600B5FD RID: 46589 RVA: 0x002E8968 File Offset: 0x002E6B68
		// (set) Token: 0x0600B5FE RID: 46590 RVA: 0x002E8990 File Offset: 0x002E6B90
		public unsafe int _StartTime_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__StartTime_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__StartTime_k__BackingField)) = value;
			}
		}

		// Token: 0x170040E4 RID: 16612
		// (get) Token: 0x0600B5FF RID: 46591 RVA: 0x002E89B4 File Offset: 0x002E6BB4
		// (set) Token: 0x0600B600 RID: 46592 RVA: 0x002E89DC File Offset: 0x002E6BDC
		public unsafe int _OffsetTime_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__OffsetTime_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__OffsetTime_k__BackingField)) = value;
			}
		}

		// Token: 0x170040E5 RID: 16613
		// (get) Token: 0x0600B601 RID: 46593 RVA: 0x002E8A00 File Offset: 0x002E6C00
		// (set) Token: 0x0600B602 RID: 46594 RVA: 0x002E8A34 File Offset: 0x002E6C34
		public unsafe Dictionary<string, HapticEffectMode> _Modes_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__Modes_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, HapticEffectMode>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffect.NativeFieldInfoPtr__Modes_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400748E RID: 29838
		private static readonly IntPtr NativeFieldInfoPtr__StartTime_k__BackingField;

		// Token: 0x0400748F RID: 29839
		private static readonly IntPtr NativeFieldInfoPtr__OffsetTime_k__BackingField;

		// Token: 0x04007490 RID: 29840
		private static readonly IntPtr NativeFieldInfoPtr__Modes_k__BackingField;

		// Token: 0x04007491 RID: 29841
		private static readonly IntPtr NativeMethodInfoPtr_get_StartTime_Public_get_Int32_0;

		// Token: 0x04007492 RID: 29842
		private static readonly IntPtr NativeMethodInfoPtr_set_StartTime_Public_set_Void_Int32_0;

		// Token: 0x04007493 RID: 29843
		private static readonly IntPtr NativeMethodInfoPtr_get_OffsetTime_Public_get_Int32_0;

		// Token: 0x04007494 RID: 29844
		private static readonly IntPtr NativeMethodInfoPtr_set_OffsetTime_Public_set_Void_Int32_0;

		// Token: 0x04007495 RID: 29845
		private static readonly IntPtr NativeMethodInfoPtr_get_Modes_Public_get_Dictionary_2_String_HapticEffectMode_0;

		// Token: 0x04007496 RID: 29846
		private static readonly IntPtr NativeMethodInfoPtr_set_Modes_Public_set_Void_Dictionary_2_String_HapticEffectMode_0;

		// Token: 0x04007497 RID: 29847
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04007498 RID: 29848
		private static readonly IntPtr NativeMethodInfoPtr_ToEffect_Internal_Static_HapticEffect_JSONObject_0;

		// Token: 0x04007499 RID: 29849
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x0400749A RID: 29850
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
