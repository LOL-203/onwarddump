﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B3 RID: 2227
	public class PathModeObject : Object
	{
		// Token: 0x1700411B RID: 16667
		// (get) Token: 0x0600B67D RID: 46717 RVA: 0x002EAC70 File Offset: 0x002E8E70
		// (set) Token: 0x0600B67E RID: 46718 RVA: 0x002EACC0 File Offset: 0x002E8EC0
		public unsafe float X
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_get_X_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_set_X_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700411C RID: 16668
		// (get) Token: 0x0600B67F RID: 46719 RVA: 0x002EAD14 File Offset: 0x002E8F14
		// (set) Token: 0x0600B680 RID: 46720 RVA: 0x002EAD64 File Offset: 0x002E8F64
		public unsafe float Y
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_get_Y_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700411D RID: 16669
		// (get) Token: 0x0600B681 RID: 46721 RVA: 0x002EADB8 File Offset: 0x002E8FB8
		// (set) Token: 0x0600B682 RID: 46722 RVA: 0x002EAE08 File Offset: 0x002E9008
		public unsafe float Intensity
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_get_Intensity_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700411E RID: 16670
		// (get) Token: 0x0600B683 RID: 46723 RVA: 0x002EAE5C File Offset: 0x002E905C
		// (set) Token: 0x0600B684 RID: 46724 RVA: 0x002EAEAC File Offset: 0x002E90AC
		public unsafe int Time
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_get_Time_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_set_Time_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B685 RID: 46725 RVA: 0x002EAF00 File Offset: 0x002E9100
		[CallerCount(0)]
		public unsafe static PathModeObject ToObject(JSONObject jsonObject)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObject);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObject_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new PathModeObject(intPtr2) : null;
		}

		// Token: 0x0600B686 RID: 46726 RVA: 0x002EAF60 File Offset: 0x002E9160
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B687 RID: 46727 RVA: 0x002EAFB8 File Offset: 0x002E91B8
		[CallerCount(0)]
		public unsafe PathModeObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B688 RID: 46728 RVA: 0x002EB004 File Offset: 0x002E9204
		// Note: this type is marked as 'beforefieldinit'.
		static PathModeObject()
		{
			Il2CppClassPointerStore<PathModeObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "PathModeObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr);
			PathModeObject.NativeFieldInfoPtr__X_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, "<X>k__BackingField");
			PathModeObject.NativeFieldInfoPtr__Y_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, "<Y>k__BackingField");
			PathModeObject.NativeFieldInfoPtr__Intensity_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, "<Intensity>k__BackingField");
			PathModeObject.NativeFieldInfoPtr__Time_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, "<Time>k__BackingField");
			PathModeObject.NativeMethodInfoPtr_get_X_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678125);
			PathModeObject.NativeMethodInfoPtr_set_X_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678126);
			PathModeObject.NativeMethodInfoPtr_get_Y_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678127);
			PathModeObject.NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678128);
			PathModeObject.NativeMethodInfoPtr_get_Intensity_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678129);
			PathModeObject.NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678130);
			PathModeObject.NativeMethodInfoPtr_get_Time_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678131);
			PathModeObject.NativeMethodInfoPtr_set_Time_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678132);
			PathModeObject.NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObject_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678133);
			PathModeObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678134);
			PathModeObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr, 100678135);
		}

		// Token: 0x0600B689 RID: 46729 RVA: 0x00002988 File Offset: 0x00000B88
		public PathModeObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004116 RID: 16662
		// (get) Token: 0x0600B68A RID: 46730 RVA: 0x002EB160 File Offset: 0x002E9360
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PathModeObject>.NativeClassPtr));
			}
		}

		// Token: 0x17004117 RID: 16663
		// (get) Token: 0x0600B68B RID: 46731 RVA: 0x002EB174 File Offset: 0x002E9374
		// (set) Token: 0x0600B68C RID: 46732 RVA: 0x002EB19C File Offset: 0x002E939C
		public unsafe float _X_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__X_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__X_k__BackingField)) = value;
			}
		}

		// Token: 0x17004118 RID: 16664
		// (get) Token: 0x0600B68D RID: 46733 RVA: 0x002EB1C0 File Offset: 0x002E93C0
		// (set) Token: 0x0600B68E RID: 46734 RVA: 0x002EB1E8 File Offset: 0x002E93E8
		public unsafe float _Y_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Y_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Y_k__BackingField)) = value;
			}
		}

		// Token: 0x17004119 RID: 16665
		// (get) Token: 0x0600B68F RID: 46735 RVA: 0x002EB20C File Offset: 0x002E940C
		// (set) Token: 0x0600B690 RID: 46736 RVA: 0x002EB234 File Offset: 0x002E9434
		public unsafe float _Intensity_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Intensity_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Intensity_k__BackingField)) = value;
			}
		}

		// Token: 0x1700411A RID: 16666
		// (get) Token: 0x0600B691 RID: 46737 RVA: 0x002EB258 File Offset: 0x002E9458
		// (set) Token: 0x0600B692 RID: 46738 RVA: 0x002EB280 File Offset: 0x002E9480
		public unsafe int _Time_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Time_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObject.NativeFieldInfoPtr__Time_k__BackingField)) = value;
			}
		}

		// Token: 0x040074E9 RID: 29929
		private static readonly IntPtr NativeFieldInfoPtr__X_k__BackingField;

		// Token: 0x040074EA RID: 29930
		private static readonly IntPtr NativeFieldInfoPtr__Y_k__BackingField;

		// Token: 0x040074EB RID: 29931
		private static readonly IntPtr NativeFieldInfoPtr__Intensity_k__BackingField;

		// Token: 0x040074EC RID: 29932
		private static readonly IntPtr NativeFieldInfoPtr__Time_k__BackingField;

		// Token: 0x040074ED RID: 29933
		private static readonly IntPtr NativeMethodInfoPtr_get_X_Public_get_Single_0;

		// Token: 0x040074EE RID: 29934
		private static readonly IntPtr NativeMethodInfoPtr_set_X_Public_set_Void_Single_0;

		// Token: 0x040074EF RID: 29935
		private static readonly IntPtr NativeMethodInfoPtr_get_Y_Public_get_Single_0;

		// Token: 0x040074F0 RID: 29936
		private static readonly IntPtr NativeMethodInfoPtr_set_Y_Public_set_Void_Single_0;

		// Token: 0x040074F1 RID: 29937
		private static readonly IntPtr NativeMethodInfoPtr_get_Intensity_Public_get_Single_0;

		// Token: 0x040074F2 RID: 29938
		private static readonly IntPtr NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0;

		// Token: 0x040074F3 RID: 29939
		private static readonly IntPtr NativeMethodInfoPtr_get_Time_Public_get_Int32_0;

		// Token: 0x040074F4 RID: 29940
		private static readonly IntPtr NativeMethodInfoPtr_set_Time_Public_set_Void_Int32_0;

		// Token: 0x040074F5 RID: 29941
		private static readonly IntPtr NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObject_JSONObject_0;

		// Token: 0x040074F6 RID: 29942
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074F7 RID: 29943
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
