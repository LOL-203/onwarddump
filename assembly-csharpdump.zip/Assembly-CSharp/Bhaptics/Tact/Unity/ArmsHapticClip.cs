﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A5 RID: 2213
	public class ArmsHapticClip : FileHapticClip
	{
		// Token: 0x0600B5B3 RID: 46515 RVA: 0x002E7064 File Offset: 0x002E5264
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, float vestRotationOffsetY, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationOffsetY;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ArmsHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5B4 RID: 46516 RVA: 0x002E7114 File Offset: 0x002E5314
		[CallerCount(0)]
		public new unsafe void ResetValues()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ArmsHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5B5 RID: 46517 RVA: 0x002E7164 File Offset: 0x002E5364
		[CallerCount(0)]
		public unsafe ArmsHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ArmsHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5B6 RID: 46518 RVA: 0x002E71B0 File Offset: 0x002E53B0
		// Note: this type is marked as 'beforefieldinit'.
		static ArmsHapticClip()
		{
			Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "ArmsHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr);
			ArmsHapticClip.NativeFieldInfoPtr_IsReflect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr, "IsReflect");
			ArmsHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr, 100678021);
			ArmsHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr, 100678022);
			ArmsHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr, 100678023);
		}

		// Token: 0x0600B5B7 RID: 46519 RVA: 0x002E7230 File Offset: 0x002E5430
		public ArmsHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040D5 RID: 16597
		// (get) Token: 0x0600B5B8 RID: 46520 RVA: 0x002E7239 File Offset: 0x002E5439
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ArmsHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x170040D6 RID: 16598
		// (get) Token: 0x0600B5B9 RID: 46521 RVA: 0x002E724C File Offset: 0x002E544C
		// (set) Token: 0x0600B5BA RID: 46522 RVA: 0x002E7274 File Offset: 0x002E5474
		public unsafe bool IsReflect
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ArmsHapticClip.NativeFieldInfoPtr_IsReflect);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ArmsHapticClip.NativeFieldInfoPtr_IsReflect)) = value;
			}
		}

		// Token: 0x04007465 RID: 29797
		private static readonly IntPtr NativeFieldInfoPtr_IsReflect;

		// Token: 0x04007466 RID: 29798
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0;

		// Token: 0x04007467 RID: 29799
		private static readonly IntPtr NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0;

		// Token: 0x04007468 RID: 29800
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
