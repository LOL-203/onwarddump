﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x0200089B RID: 2203
	public static class AndroidUtils : Object
	{
		// Token: 0x0600B4E1 RID: 46305 RVA: 0x002E3E58 File Offset: 0x002E2058
		[CallerCount(0)]
		public unsafe static PositionType ToDeviceType(int type)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_ToDeviceType_Private_Static_PositionType_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B4E2 RID: 46306 RVA: 0x002E3EAC File Offset: 0x002E20AC
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<PositionType> ToCandidates(int type)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_ToCandidates_Private_Static_ArrayOf_PositionType_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<PositionType>(intPtr2) : null;
		}

		// Token: 0x0600B4E3 RID: 46307 RVA: 0x002E3F08 File Offset: 0x002E2108
		[CallerCount(0)]
		public unsafe static bool IsLeft(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_IsLeft_Public_Static_Boolean_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B4E4 RID: 46308 RVA: 0x002E3F5C File Offset: 0x002E215C
		[CallerCount(0)]
		public unsafe static bool CanChangePosition(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_CanChangePosition_Public_Static_Boolean_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B4E5 RID: 46309 RVA: 0x002E3FB0 File Offset: 0x002E21B0
		[CallerCount(0)]
		public unsafe static Il2CppArrayBase<T> GetJsonArray<T>(string json)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(json);
			IntPtr returnedException;
			IntPtr pointer = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.MethodInfoStoreGeneric_GetJsonArray_Public_Static_ArrayOf_T_String_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return Il2CppArrayBase<T>.WrapNativeGenericArrayPointer(pointer);
		}

		// Token: 0x0600B4E6 RID: 46310 RVA: 0x002E4004 File Offset: 0x002E2204
		[CallerCount(0)]
		public unsafe static HapticDevice Convert(AndroidUtils.Device d)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(d);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_Convert_Private_Static_HapticDevice_Device_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HapticDevice(intPtr2) : null;
		}

		// Token: 0x0600B4E7 RID: 46311 RVA: 0x002E4064 File Offset: 0x002E2264
		[CallerCount(0)]
		public unsafe static List<HapticDevice> ConvertToBhapticsDevices(Il2CppStringArray deviceJson)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(deviceJson);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_ConvertToBhapticsDevices_Public_Static_List_1_HapticDevice_ArrayOf_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
		}

		// Token: 0x0600B4E8 RID: 46312 RVA: 0x002E40C4 File Offset: 0x002E22C4
		[CallerCount(0)]
		public unsafe static void CallNativeVoidMethod(IntPtr androidObjPtr, IntPtr methodPtr, Il2CppReferenceArray<Object> param)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref androidObjPtr;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref methodPtr;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(param);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_CallNativeVoidMethod_Public_Static_Void_IntPtr_IntPtr_ArrayOf_Object_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B4E9 RID: 46313 RVA: 0x002E4134 File Offset: 0x002E2334
		[CallerCount(0)]
		public unsafe static bool CallNativeBoolMethod(IntPtr androidObjPtr, IntPtr methodPtr, Il2CppReferenceArray<Object> param)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref androidObjPtr;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref methodPtr;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(param);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.NativeMethodInfoPtr_CallNativeBoolMethod_Public_Static_Boolean_IntPtr_IntPtr_ArrayOf_Object_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B4EA RID: 46314 RVA: 0x002E41B4 File Offset: 0x002E23B4
		// Note: this type is marked as 'beforefieldinit'.
		static AndroidUtils()
		{
			Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "AndroidUtils");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr);
			AndroidUtils.NativeMethodInfoPtr_ToDeviceType_Private_Static_PositionType_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677961);
			AndroidUtils.NativeMethodInfoPtr_ToCandidates_Private_Static_ArrayOf_PositionType_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677962);
			AndroidUtils.NativeMethodInfoPtr_IsLeft_Public_Static_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677963);
			AndroidUtils.NativeMethodInfoPtr_CanChangePosition_Public_Static_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677964);
			AndroidUtils.NativeMethodInfoPtr_GetJsonArray_Public_Static_ArrayOf_T_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677965);
			AndroidUtils.NativeMethodInfoPtr_Convert_Private_Static_HapticDevice_Device_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677966);
			AndroidUtils.NativeMethodInfoPtr_ConvertToBhapticsDevices_Public_Static_List_1_HapticDevice_ArrayOf_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677967);
			AndroidUtils.NativeMethodInfoPtr_CallNativeVoidMethod_Public_Static_Void_IntPtr_IntPtr_ArrayOf_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677968);
			AndroidUtils.NativeMethodInfoPtr_CallNativeBoolMethod_Public_Static_Boolean_IntPtr_IntPtr_ArrayOf_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, 100677969);
		}

		// Token: 0x0600B4EB RID: 46315 RVA: 0x00002988 File Offset: 0x00000B88
		public AndroidUtils(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700408E RID: 16526
		// (get) Token: 0x0600B4EC RID: 46316 RVA: 0x002E4298 File Offset: 0x002E2498
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr));
			}
		}

		// Token: 0x040073EC RID: 29676
		private static readonly IntPtr NativeMethodInfoPtr_ToDeviceType_Private_Static_PositionType_Int32_0;

		// Token: 0x040073ED RID: 29677
		private static readonly IntPtr NativeMethodInfoPtr_ToCandidates_Private_Static_ArrayOf_PositionType_Int32_0;

		// Token: 0x040073EE RID: 29678
		private static readonly IntPtr NativeMethodInfoPtr_IsLeft_Public_Static_Boolean_PositionType_0;

		// Token: 0x040073EF RID: 29679
		private static readonly IntPtr NativeMethodInfoPtr_CanChangePosition_Public_Static_Boolean_PositionType_0;

		// Token: 0x040073F0 RID: 29680
		private static readonly IntPtr NativeMethodInfoPtr_GetJsonArray_Public_Static_ArrayOf_T_String_0;

		// Token: 0x040073F1 RID: 29681
		private static readonly IntPtr NativeMethodInfoPtr_Convert_Private_Static_HapticDevice_Device_0;

		// Token: 0x040073F2 RID: 29682
		private static readonly IntPtr NativeMethodInfoPtr_ConvertToBhapticsDevices_Public_Static_List_1_HapticDevice_ArrayOf_0;

		// Token: 0x040073F3 RID: 29683
		private static readonly IntPtr NativeMethodInfoPtr_CallNativeVoidMethod_Public_Static_Void_IntPtr_IntPtr_ArrayOf_Object_0;

		// Token: 0x040073F4 RID: 29684
		private static readonly IntPtr NativeMethodInfoPtr_CallNativeBoolMethod_Public_Static_Boolean_IntPtr_IntPtr_ArrayOf_Object_0;

		// Token: 0x0200089C RID: 2204
		[Serializable]
		public class Wrapper<T> : Object
		{
			// Token: 0x0600B4ED RID: 46317 RVA: 0x002E42AC File Offset: 0x002E24AC
			[CallerCount(0)]
			public unsafe Wrapper() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.Wrapper<T>.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B4EE RID: 46318 RVA: 0x002E42F8 File Offset: 0x002E24F8
			// Note: this type is marked as 'beforefieldinit'.
			static Wrapper()
			{
				Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr = IL2CPP.il2cpp_class_from_type(Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, "Wrapper`1"))).MakeGenericType(new Il2CppReferenceArray<Type>(new Type[]
				{
					Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
				})).TypeHandle.value);
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr);
				AndroidUtils.Wrapper<T>.NativeFieldInfoPtr_array = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr, "array");
				AndroidUtils.Wrapper<T>.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr, 100677970);
			}

			// Token: 0x0600B4EF RID: 46319 RVA: 0x00002988 File Offset: 0x00000B88
			public Wrapper(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700408F RID: 16527
			// (get) Token: 0x0600B4F0 RID: 46320 RVA: 0x002E4386 File Offset: 0x002E2586
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AndroidUtils.Wrapper<T>>.NativeClassPtr));
				}
			}

			// Token: 0x17004090 RID: 16528
			// (get) Token: 0x0600B4F1 RID: 46321 RVA: 0x002E4398 File Offset: 0x002E2598
			// (set) Token: 0x0600B4F2 RID: 46322 RVA: 0x002E43C0 File Offset: 0x002E25C0
			public Il2CppArrayBase<T> array
			{
				get
				{
					IntPtr pointer = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Wrapper<T>.NativeFieldInfoPtr_array);
					return Il2CppArrayBase<T>.WrapNativeGenericArrayPointer(pointer);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Wrapper<T>.NativeFieldInfoPtr_array), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x040073F5 RID: 29685
			private static readonly IntPtr NativeFieldInfoPtr_array;

			// Token: 0x040073F6 RID: 29686
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}

		// Token: 0x0200089D RID: 2205
		[Serializable]
		public class Device : Object
		{
			// Token: 0x0600B4F3 RID: 46323 RVA: 0x002E43E8 File Offset: 0x002E25E8
			[CallerCount(0)]
			public unsafe Device() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.Device.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B4F4 RID: 46324 RVA: 0x002E4434 File Offset: 0x002E2634
			// Note: this type is marked as 'beforefieldinit'.
			static Device()
			{
				Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, "Device");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr);
				AndroidUtils.Device.NativeFieldInfoPtr_paired = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "paired");
				AndroidUtils.Device.NativeFieldInfoPtr_deviceName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "deviceName");
				AndroidUtils.Device.NativeFieldInfoPtr_position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "position");
				AndroidUtils.Device.NativeFieldInfoPtr_connected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "connected");
				AndroidUtils.Device.NativeFieldInfoPtr_address = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "address");
				AndroidUtils.Device.NativeFieldInfoPtr_battery = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "battery");
				AndroidUtils.Device.NativeFieldInfoPtr_enable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "enable");
				AndroidUtils.Device.NativeFieldInfoPtr_audioJackIn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, "audioJackIn");
				AndroidUtils.Device.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr, 100677971);
			}

			// Token: 0x0600B4F5 RID: 46325 RVA: 0x00002988 File Offset: 0x00000B88
			public Device(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004091 RID: 16529
			// (get) Token: 0x0600B4F6 RID: 46326 RVA: 0x002E4513 File Offset: 0x002E2713
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AndroidUtils.Device>.NativeClassPtr));
				}
			}

			// Token: 0x17004092 RID: 16530
			// (get) Token: 0x0600B4F7 RID: 46327 RVA: 0x002E4524 File Offset: 0x002E2724
			// (set) Token: 0x0600B4F8 RID: 46328 RVA: 0x002E454C File Offset: 0x002E274C
			public unsafe bool paired
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_paired);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_paired)) = value;
				}
			}

			// Token: 0x17004093 RID: 16531
			// (get) Token: 0x0600B4F9 RID: 46329 RVA: 0x002E4570 File Offset: 0x002E2770
			// (set) Token: 0x0600B4FA RID: 46330 RVA: 0x002E4599 File Offset: 0x002E2799
			public unsafe string deviceName
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_deviceName);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_deviceName), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17004094 RID: 16532
			// (get) Token: 0x0600B4FB RID: 46331 RVA: 0x002E45C0 File Offset: 0x002E27C0
			// (set) Token: 0x0600B4FC RID: 46332 RVA: 0x002E45E8 File Offset: 0x002E27E8
			public unsafe int position
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_position);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_position)) = value;
				}
			}

			// Token: 0x17004095 RID: 16533
			// (get) Token: 0x0600B4FD RID: 46333 RVA: 0x002E460C File Offset: 0x002E280C
			// (set) Token: 0x0600B4FE RID: 46334 RVA: 0x002E4634 File Offset: 0x002E2834
			public unsafe bool connected
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_connected);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_connected)) = value;
				}
			}

			// Token: 0x17004096 RID: 16534
			// (get) Token: 0x0600B4FF RID: 46335 RVA: 0x002E4658 File Offset: 0x002E2858
			// (set) Token: 0x0600B500 RID: 46336 RVA: 0x002E4681 File Offset: 0x002E2881
			public unsafe string address
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_address);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_address), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17004097 RID: 16535
			// (get) Token: 0x0600B501 RID: 46337 RVA: 0x002E46A8 File Offset: 0x002E28A8
			// (set) Token: 0x0600B502 RID: 46338 RVA: 0x002E46D0 File Offset: 0x002E28D0
			public unsafe int battery
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_battery);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_battery)) = value;
				}
			}

			// Token: 0x17004098 RID: 16536
			// (get) Token: 0x0600B503 RID: 46339 RVA: 0x002E46F4 File Offset: 0x002E28F4
			// (set) Token: 0x0600B504 RID: 46340 RVA: 0x002E471C File Offset: 0x002E291C
			public unsafe bool enable
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_enable);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_enable)) = value;
				}
			}

			// Token: 0x17004099 RID: 16537
			// (get) Token: 0x0600B505 RID: 46341 RVA: 0x002E4740 File Offset: 0x002E2940
			// (set) Token: 0x0600B506 RID: 46342 RVA: 0x002E4768 File Offset: 0x002E2968
			public unsafe bool audioJackIn
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_audioJackIn);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.Device.NativeFieldInfoPtr_audioJackIn)) = value;
				}
			}

			// Token: 0x040073F7 RID: 29687
			private static readonly IntPtr NativeFieldInfoPtr_paired;

			// Token: 0x040073F8 RID: 29688
			private static readonly IntPtr NativeFieldInfoPtr_deviceName;

			// Token: 0x040073F9 RID: 29689
			private static readonly IntPtr NativeFieldInfoPtr_position;

			// Token: 0x040073FA RID: 29690
			private static readonly IntPtr NativeFieldInfoPtr_connected;

			// Token: 0x040073FB RID: 29691
			private static readonly IntPtr NativeFieldInfoPtr_address;

			// Token: 0x040073FC RID: 29692
			private static readonly IntPtr NativeFieldInfoPtr_battery;

			// Token: 0x040073FD RID: 29693
			private static readonly IntPtr NativeFieldInfoPtr_enable;

			// Token: 0x040073FE RID: 29694
			private static readonly IntPtr NativeFieldInfoPtr_audioJackIn;

			// Token: 0x040073FF RID: 29695
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}

		// Token: 0x0200089E RID: 2206
		[Serializable]
		public class StreamHost : Object
		{
			// Token: 0x0600B507 RID: 46343 RVA: 0x002E478C File Offset: 0x002E298C
			[CallerCount(0)]
			public unsafe StreamHost() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidUtils.StreamHost.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600B508 RID: 46344 RVA: 0x002E47D8 File Offset: 0x002E29D8
			// Note: this type is marked as 'beforefieldinit'.
			static StreamHost()
			{
				Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr, "StreamHost");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr);
				AndroidUtils.StreamHost.NativeFieldInfoPtr_ip = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr, "ip");
				AndroidUtils.StreamHost.NativeFieldInfoPtr_connected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr, "connected");
				AndroidUtils.StreamHost.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr, 100677972);
			}

			// Token: 0x0600B509 RID: 46345 RVA: 0x00002988 File Offset: 0x00000B88
			public StreamHost(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700409A RID: 16538
			// (get) Token: 0x0600B50A RID: 46346 RVA: 0x002E483F File Offset: 0x002E2A3F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AndroidUtils.StreamHost>.NativeClassPtr));
				}
			}

			// Token: 0x1700409B RID: 16539
			// (get) Token: 0x0600B50B RID: 46347 RVA: 0x002E4850 File Offset: 0x002E2A50
			// (set) Token: 0x0600B50C RID: 46348 RVA: 0x002E4879 File Offset: 0x002E2A79
			public unsafe string ip
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.StreamHost.NativeFieldInfoPtr_ip);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.StreamHost.NativeFieldInfoPtr_ip), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x1700409C RID: 16540
			// (get) Token: 0x0600B50D RID: 46349 RVA: 0x002E48A0 File Offset: 0x002E2AA0
			// (set) Token: 0x0600B50E RID: 46350 RVA: 0x002E48C8 File Offset: 0x002E2AC8
			public unsafe bool connected
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.StreamHost.NativeFieldInfoPtr_connected);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidUtils.StreamHost.NativeFieldInfoPtr_connected)) = value;
				}
			}

			// Token: 0x04007400 RID: 29696
			private static readonly IntPtr NativeFieldInfoPtr_ip;

			// Token: 0x04007401 RID: 29697
			private static readonly IntPtr NativeFieldInfoPtr_connected;

			// Token: 0x04007402 RID: 29698
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}

		// Token: 0x0200089F RID: 2207
		private sealed class MethodInfoStoreGeneric_GetJsonArray_Public_Static_ArrayOf_T_String_0<T>
		{
			// Token: 0x04007403 RID: 29699
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AndroidUtils.NativeMethodInfoPtr_GetJsonArray_Public_Static_ArrayOf_T_String_0, Il2CppClassPointerStore<AndroidUtils>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
