﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B0 RID: 2224
	public class DotModeObject : Object
	{
		// Token: 0x1700410C RID: 16652
		// (get) Token: 0x0600B657 RID: 46679 RVA: 0x002EA234 File Offset: 0x002E8434
		// (set) Token: 0x0600B658 RID: 46680 RVA: 0x002EA284 File Offset: 0x002E8484
		public unsafe int Index
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_get_Index_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700410D RID: 16653
		// (get) Token: 0x0600B659 RID: 46681 RVA: 0x002EA2D8 File Offset: 0x002E84D8
		// (set) Token: 0x0600B65A RID: 46682 RVA: 0x002EA328 File Offset: 0x002E8528
		public unsafe float Intensity
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_get_Intensity_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B65B RID: 46683 RVA: 0x002EA37C File Offset: 0x002E857C
		[CallerCount(0)]
		public unsafe static DotModeObject ToObject(JSONObject jsonObject)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObject);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObject_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DotModeObject(intPtr2) : null;
		}

		// Token: 0x0600B65C RID: 46684 RVA: 0x002EA3DC File Offset: 0x002E85DC
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B65D RID: 46685 RVA: 0x002EA434 File Offset: 0x002E8634
		[CallerCount(0)]
		public unsafe DotModeObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DotModeObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B65E RID: 46686 RVA: 0x002EA480 File Offset: 0x002E8680
		// Note: this type is marked as 'beforefieldinit'.
		static DotModeObject()
		{
			Il2CppClassPointerStore<DotModeObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "DotModeObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr);
			DotModeObject.NativeFieldInfoPtr__Index_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, "<Index>k__BackingField");
			DotModeObject.NativeFieldInfoPtr__Intensity_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, "<Intensity>k__BackingField");
			DotModeObject.NativeMethodInfoPtr_get_Index_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678108);
			DotModeObject.NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678109);
			DotModeObject.NativeMethodInfoPtr_get_Intensity_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678110);
			DotModeObject.NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678111);
			DotModeObject.NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObject_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678112);
			DotModeObject.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678113);
			DotModeObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr, 100678114);
		}

		// Token: 0x0600B65F RID: 46687 RVA: 0x00002988 File Offset: 0x00000B88
		public DotModeObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004109 RID: 16649
		// (get) Token: 0x0600B660 RID: 46688 RVA: 0x002EA564 File Offset: 0x002E8764
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DotModeObject>.NativeClassPtr));
			}
		}

		// Token: 0x1700410A RID: 16650
		// (get) Token: 0x0600B661 RID: 46689 RVA: 0x002EA578 File Offset: 0x002E8778
		// (set) Token: 0x0600B662 RID: 46690 RVA: 0x002EA5A0 File Offset: 0x002E87A0
		public unsafe int _Index_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObject.NativeFieldInfoPtr__Index_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObject.NativeFieldInfoPtr__Index_k__BackingField)) = value;
			}
		}

		// Token: 0x1700410B RID: 16651
		// (get) Token: 0x0600B663 RID: 46691 RVA: 0x002EA5C4 File Offset: 0x002E87C4
		// (set) Token: 0x0600B664 RID: 46692 RVA: 0x002EA5EC File Offset: 0x002E87EC
		public unsafe float _Intensity_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObject.NativeFieldInfoPtr__Intensity_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DotModeObject.NativeFieldInfoPtr__Intensity_k__BackingField)) = value;
			}
		}

		// Token: 0x040074D2 RID: 29906
		private static readonly IntPtr NativeFieldInfoPtr__Index_k__BackingField;

		// Token: 0x040074D3 RID: 29907
		private static readonly IntPtr NativeFieldInfoPtr__Intensity_k__BackingField;

		// Token: 0x040074D4 RID: 29908
		private static readonly IntPtr NativeMethodInfoPtr_get_Index_Public_get_Int32_0;

		// Token: 0x040074D5 RID: 29909
		private static readonly IntPtr NativeMethodInfoPtr_set_Index_Public_set_Void_Int32_0;

		// Token: 0x040074D6 RID: 29910
		private static readonly IntPtr NativeMethodInfoPtr_get_Intensity_Public_get_Single_0;

		// Token: 0x040074D7 RID: 29911
		private static readonly IntPtr NativeMethodInfoPtr_set_Intensity_Public_set_Void_Single_0;

		// Token: 0x040074D8 RID: 29912
		private static readonly IntPtr NativeMethodInfoPtr_ToObject_Internal_Static_DotModeObject_JSONObject_0;

		// Token: 0x040074D9 RID: 29913
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074DA RID: 29914
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
