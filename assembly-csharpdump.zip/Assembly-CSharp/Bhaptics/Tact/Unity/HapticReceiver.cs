﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008BE RID: 2238
	public class HapticReceiver : MonoBehaviour
	{
		// Token: 0x0600B6FE RID: 46846 RVA: 0x002ED19C File Offset: 0x002EB39C
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticReceiver.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6FF RID: 46847 RVA: 0x002ED1E0 File Offset: 0x002EB3E0
		[CallerCount(0)]
		public unsafe void OnTriggerEnter(Collider bullet)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bullet);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticReceiver.NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B700 RID: 46848 RVA: 0x002ED23C File Offset: 0x002EB43C
		[CallerCount(0)]
		public unsafe void OnCollisionEnter(Collision bullet)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bullet);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticReceiver.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B701 RID: 46849 RVA: 0x002ED298 File Offset: 0x002EB498
		[CallerCount(0)]
		public unsafe void Handle(Vector3 contactPoint, HapticSender tactSender)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref contactPoint;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(tactSender);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticReceiver.NativeMethodInfoPtr_Handle_Private_Void_Vector3_HapticSender_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B702 RID: 46850 RVA: 0x002ED304 File Offset: 0x002EB504
		[CallerCount(0)]
		public unsafe HapticReceiver() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticReceiver.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B703 RID: 46851 RVA: 0x002ED350 File Offset: 0x002EB550
		// Note: this type is marked as 'beforefieldinit'.
		static HapticReceiver()
		{
			Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticReceiver");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr);
			HapticReceiver.NativeFieldInfoPtr_IsActive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, "IsActive");
			HapticReceiver.NativeFieldInfoPtr_PositionTag = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, "PositionTag");
			HapticReceiver.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, 100678181);
			HapticReceiver.NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, 100678182);
			HapticReceiver.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, 100678183);
			HapticReceiver.NativeMethodInfoPtr_Handle_Private_Void_Vector3_HapticSender_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, 100678184);
			HapticReceiver.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr, 100678185);
		}

		// Token: 0x0600B704 RID: 46852 RVA: 0x0000210C File Offset: 0x0000030C
		public HapticReceiver(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700413B RID: 16699
		// (get) Token: 0x0600B705 RID: 46853 RVA: 0x002ED40C File Offset: 0x002EB60C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticReceiver>.NativeClassPtr));
			}
		}

		// Token: 0x1700413C RID: 16700
		// (get) Token: 0x0600B706 RID: 46854 RVA: 0x002ED420 File Offset: 0x002EB620
		// (set) Token: 0x0600B707 RID: 46855 RVA: 0x002ED448 File Offset: 0x002EB648
		public unsafe bool IsActive
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticReceiver.NativeFieldInfoPtr_IsActive);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticReceiver.NativeFieldInfoPtr_IsActive)) = value;
			}
		}

		// Token: 0x1700413D RID: 16701
		// (get) Token: 0x0600B708 RID: 46856 RVA: 0x002ED46C File Offset: 0x002EB66C
		// (set) Token: 0x0600B709 RID: 46857 RVA: 0x002ED494 File Offset: 0x002EB694
		public unsafe PositionTag PositionTag
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticReceiver.NativeFieldInfoPtr_PositionTag);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticReceiver.NativeFieldInfoPtr_PositionTag)) = value;
			}
		}

		// Token: 0x0400754C RID: 30028
		private static readonly IntPtr NativeFieldInfoPtr_IsActive;

		// Token: 0x0400754D RID: 30029
		private static readonly IntPtr NativeFieldInfoPtr_PositionTag;

		// Token: 0x0400754E RID: 30030
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400754F RID: 30031
		private static readonly IntPtr NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0;

		// Token: 0x04007550 RID: 30032
		private static readonly IntPtr NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0;

		// Token: 0x04007551 RID: 30033
		private static readonly IntPtr NativeMethodInfoPtr_Handle_Private_Void_Vector3_HapticSender_0;

		// Token: 0x04007552 RID: 30034
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
