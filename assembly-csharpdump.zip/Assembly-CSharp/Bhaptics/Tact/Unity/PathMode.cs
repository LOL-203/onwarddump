﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B1 RID: 2225
	public class PathMode : Object
	{
		// Token: 0x17004110 RID: 16656
		// (get) Token: 0x0600B665 RID: 46693 RVA: 0x002EA610 File Offset: 0x002E8810
		// (set) Token: 0x0600B666 RID: 46694 RVA: 0x002EA668 File Offset: 0x002E8868
		public unsafe Il2CppReferenceArray<PathModeObjectCollection> Feedback
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathMode.NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_PathModeObjectCollection_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<PathModeObjectCollection>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathMode.NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_PathModeObjectCollection_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B667 RID: 46695 RVA: 0x002EA6C4 File Offset: 0x002E88C4
		[CallerCount(0)]
		public unsafe static PathMode ToPathMode(JSONObject jsonObject)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObject);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathMode.NativeMethodInfoPtr_ToPathMode_Internal_Static_PathMode_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new PathMode(intPtr2) : null;
		}

		// Token: 0x0600B668 RID: 46696 RVA: 0x002EA724 File Offset: 0x002E8924
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B669 RID: 46697 RVA: 0x002EA77C File Offset: 0x002E897C
		[CallerCount(0)]
		public unsafe PathMode() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PathMode>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathMode.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B66A RID: 46698 RVA: 0x002EA7C8 File Offset: 0x002E89C8
		// Note: this type is marked as 'beforefieldinit'.
		static PathMode()
		{
			Il2CppClassPointerStore<PathMode>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "PathMode");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PathMode>.NativeClassPtr);
			PathMode.NativeFieldInfoPtr__Feedback_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathMode>.NativeClassPtr, "<Feedback>k__BackingField");
			PathMode.NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_PathModeObjectCollection_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathMode>.NativeClassPtr, 100678115);
			PathMode.NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_PathModeObjectCollection_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathMode>.NativeClassPtr, 100678116);
			PathMode.NativeMethodInfoPtr_ToPathMode_Internal_Static_PathMode_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathMode>.NativeClassPtr, 100678117);
			PathMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathMode>.NativeClassPtr, 100678118);
			PathMode.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathMode>.NativeClassPtr, 100678119);
		}

		// Token: 0x0600B66B RID: 46699 RVA: 0x00002988 File Offset: 0x00000B88
		public PathMode(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700410E RID: 16654
		// (get) Token: 0x0600B66C RID: 46700 RVA: 0x002EA870 File Offset: 0x002E8A70
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PathMode>.NativeClassPtr));
			}
		}

		// Token: 0x1700410F RID: 16655
		// (get) Token: 0x0600B66D RID: 46701 RVA: 0x002EA884 File Offset: 0x002E8A84
		// (set) Token: 0x0600B66E RID: 46702 RVA: 0x002EA8B8 File Offset: 0x002E8AB8
		public unsafe Il2CppReferenceArray<PathModeObjectCollection> _Feedback_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathMode.NativeFieldInfoPtr__Feedback_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<PathModeObjectCollection>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathMode.NativeFieldInfoPtr__Feedback_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040074DB RID: 29915
		private static readonly IntPtr NativeFieldInfoPtr__Feedback_k__BackingField;

		// Token: 0x040074DC RID: 29916
		private static readonly IntPtr NativeMethodInfoPtr_get_Feedback_Public_get_ArrayOf_PathModeObjectCollection_0;

		// Token: 0x040074DD RID: 29917
		private static readonly IntPtr NativeMethodInfoPtr_set_Feedback_Public_set_Void_ArrayOf_PathModeObjectCollection_0;

		// Token: 0x040074DE RID: 29918
		private static readonly IntPtr NativeMethodInfoPtr_ToPathMode_Internal_Static_PathMode_JSONObject_0;

		// Token: 0x040074DF RID: 29919
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074E0 RID: 29920
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
