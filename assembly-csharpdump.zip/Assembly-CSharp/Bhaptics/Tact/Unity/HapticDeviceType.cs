﻿using System;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008BB RID: 2235
	public enum HapticDeviceType
	{
		// Token: 0x04007527 RID: 29991
		None,
		// Token: 0x04007528 RID: 29992
		Tactal,
		// Token: 0x04007529 RID: 29993
		TactSuit,
		// Token: 0x0400752A RID: 29994
		Tactosy_arms,
		// Token: 0x0400752B RID: 29995
		Tactosy_hands,
		// Token: 0x0400752C RID: 29996
		Tactosy_feet,
		// Token: 0x0400752D RID: 29997
		TactGlove
	}
}
