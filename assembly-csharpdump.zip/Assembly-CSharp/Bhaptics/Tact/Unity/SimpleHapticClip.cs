﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C6 RID: 2246
	public class SimpleHapticClip : HapticClip
	{
		// Token: 0x0600B77A RID: 46970 RVA: 0x002EF5F8 File Offset: 0x002ED7F8
		[CallerCount(0)]
		public new unsafe void Play(float intensity, float duration, float vestRotationAngleX, float vestRotationOffsetY, string identifier = "")
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref intensity;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationAngleX;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestRotationOffsetY;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(identifier);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SimpleHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B77B RID: 46971 RVA: 0x002EF6A8 File Offset: 0x002ED8A8
		[CallerCount(0)]
		public new unsafe void ResetValues()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SimpleHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B77C RID: 46972 RVA: 0x002EF6F8 File Offset: 0x002ED8F8
		[CallerCount(0)]
		public unsafe static List<DotPoint> Convert(Il2CppStructArray<int> points)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(points);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SimpleHapticClip.NativeMethodInfoPtr_Convert_Private_Static_List_1_DotPoint_ArrayOf_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<DotPoint>(intPtr2) : null;
		}

		// Token: 0x0600B77D RID: 46973 RVA: 0x002EF758 File Offset: 0x002ED958
		[CallerCount(0)]
		public unsafe static List<PathPoint> Convert(Il2CppReferenceArray<Point> points)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(points);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SimpleHapticClip.NativeMethodInfoPtr_Convert_Private_Static_List_1_PathPoint_ArrayOf_Point_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<PathPoint>(intPtr2) : null;
		}

		// Token: 0x0600B77E RID: 46974 RVA: 0x002EF7B8 File Offset: 0x002ED9B8
		[CallerCount(0)]
		public unsafe SimpleHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SimpleHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B77F RID: 46975 RVA: 0x002EF804 File Offset: 0x002EDA04
		// Note: this type is marked as 'beforefieldinit'.
		static SimpleHapticClip()
		{
			Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "SimpleHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr);
			SimpleHapticClip.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, "Position");
			SimpleHapticClip.NativeFieldInfoPtr_Mode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, "Mode");
			SimpleHapticClip.NativeFieldInfoPtr_DotPoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, "DotPoints");
			SimpleHapticClip.NativeFieldInfoPtr_Points = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, "Points");
			SimpleHapticClip.NativeFieldInfoPtr_TimeMillis = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, "TimeMillis");
			SimpleHapticClip.NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, 100678236);
			SimpleHapticClip.NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, 100678237);
			SimpleHapticClip.NativeMethodInfoPtr_Convert_Private_Static_List_1_DotPoint_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, 100678238);
			SimpleHapticClip.NativeMethodInfoPtr_Convert_Private_Static_List_1_PathPoint_ArrayOf_Point_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, 100678239);
			SimpleHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr, 100678240);
		}

		// Token: 0x0600B780 RID: 46976 RVA: 0x002EC4A0 File Offset: 0x002EA6A0
		public SimpleHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700415E RID: 16734
		// (get) Token: 0x0600B781 RID: 46977 RVA: 0x002EF8FC File Offset: 0x002EDAFC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SimpleHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x1700415F RID: 16735
		// (get) Token: 0x0600B782 RID: 46978 RVA: 0x002EF910 File Offset: 0x002EDB10
		// (set) Token: 0x0600B783 RID: 46979 RVA: 0x002EF938 File Offset: 0x002EDB38
		public unsafe HapticClipPositionType Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x17004160 RID: 16736
		// (get) Token: 0x0600B784 RID: 46980 RVA: 0x002EF95C File Offset: 0x002EDB5C
		// (set) Token: 0x0600B785 RID: 46981 RVA: 0x002EF984 File Offset: 0x002EDB84
		public unsafe SimpleHapticType Mode
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Mode);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Mode)) = value;
			}
		}

		// Token: 0x17004161 RID: 16737
		// (get) Token: 0x0600B786 RID: 46982 RVA: 0x002EF9A8 File Offset: 0x002EDBA8
		// (set) Token: 0x0600B787 RID: 46983 RVA: 0x002EF9DC File Offset: 0x002EDBDC
		public unsafe Il2CppStructArray<int> DotPoints
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_DotPoints);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_DotPoints), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004162 RID: 16738
		// (get) Token: 0x0600B788 RID: 46984 RVA: 0x002EFA04 File Offset: 0x002EDC04
		// (set) Token: 0x0600B789 RID: 46985 RVA: 0x002EFA38 File Offset: 0x002EDC38
		public unsafe Il2CppReferenceArray<Point> Points
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Points);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Point>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_Points), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004163 RID: 16739
		// (get) Token: 0x0600B78A RID: 46986 RVA: 0x002EFA60 File Offset: 0x002EDC60
		// (set) Token: 0x0600B78B RID: 46987 RVA: 0x002EFA88 File Offset: 0x002EDC88
		public unsafe int TimeMillis
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_TimeMillis);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SimpleHapticClip.NativeFieldInfoPtr_TimeMillis)) = value;
			}
		}

		// Token: 0x040075A0 RID: 30112
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x040075A1 RID: 30113
		private static readonly IntPtr NativeFieldInfoPtr_Mode;

		// Token: 0x040075A2 RID: 30114
		private static readonly IntPtr NativeFieldInfoPtr_DotPoints;

		// Token: 0x040075A3 RID: 30115
		private static readonly IntPtr NativeFieldInfoPtr_Points;

		// Token: 0x040075A4 RID: 30116
		private static readonly IntPtr NativeFieldInfoPtr_TimeMillis;

		// Token: 0x040075A5 RID: 30117
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Virtual_Void_Single_Single_Single_Single_String_0;

		// Token: 0x040075A6 RID: 30118
		private static readonly IntPtr NativeMethodInfoPtr_ResetValues_Public_Virtual_Void_0;

		// Token: 0x040075A7 RID: 30119
		private static readonly IntPtr NativeMethodInfoPtr_Convert_Private_Static_List_1_DotPoint_ArrayOf_Int32_0;

		// Token: 0x040075A8 RID: 30120
		private static readonly IntPtr NativeMethodInfoPtr_Convert_Private_Static_List_1_PathPoint_ArrayOf_Point_0;

		// Token: 0x040075A9 RID: 30121
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
