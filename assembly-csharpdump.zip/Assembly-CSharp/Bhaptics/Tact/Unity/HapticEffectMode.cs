﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008AD RID: 2221
	public class HapticEffectMode : Object
	{
		// Token: 0x170040F9 RID: 16633
		// (get) Token: 0x0600B623 RID: 46627 RVA: 0x002E9368 File Offset: 0x002E7568
		// (set) Token: 0x0600B624 RID: 46628 RVA: 0x002E93B8 File Offset: 0x002E75B8
		public unsafe FeedbackMode Mode
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_get_Mode_Public_get_FeedbackMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_set_Mode_Public_set_Void_FeedbackMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040FA RID: 16634
		// (get) Token: 0x0600B625 RID: 46629 RVA: 0x002E940C File Offset: 0x002E760C
		// (set) Token: 0x0600B626 RID: 46630 RVA: 0x002E9464 File Offset: 0x002E7664
		public unsafe DotMode DotMode
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_get_DotMode_Public_get_DotMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new DotMode(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_set_DotMode_Public_set_Void_DotMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170040FB RID: 16635
		// (get) Token: 0x0600B627 RID: 46631 RVA: 0x002E94C0 File Offset: 0x002E76C0
		// (set) Token: 0x0600B628 RID: 46632 RVA: 0x002E9518 File Offset: 0x002E7718
		public unsafe PathMode PathMode
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_get_PathMode_Public_get_PathMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new PathMode(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_set_PathMode_Public_set_Void_PathMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B629 RID: 46633 RVA: 0x002E9574 File Offset: 0x002E7774
		[CallerCount(0)]
		public unsafe static HapticEffectMode ToMode(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_ToMode_Internal_Static_HapticEffectMode_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HapticEffectMode(intPtr2) : null;
		}

		// Token: 0x0600B62A RID: 46634 RVA: 0x002E95D4 File Offset: 0x002E77D4
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B62B RID: 46635 RVA: 0x002E962C File Offset: 0x002E782C
		[CallerCount(0)]
		public unsafe HapticEffectMode() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticEffectMode.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B62C RID: 46636 RVA: 0x002E9678 File Offset: 0x002E7878
		// Note: this type is marked as 'beforefieldinit'.
		static HapticEffectMode()
		{
			Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticEffectMode");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr);
			HapticEffectMode.NativeFieldInfoPtr__Mode_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, "<Mode>k__BackingField");
			HapticEffectMode.NativeFieldInfoPtr__DotMode_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, "<DotMode>k__BackingField");
			HapticEffectMode.NativeFieldInfoPtr__PathMode_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, "<PathMode>k__BackingField");
			HapticEffectMode.NativeMethodInfoPtr_get_Mode_Public_get_FeedbackMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678083);
			HapticEffectMode.NativeMethodInfoPtr_set_Mode_Public_set_Void_FeedbackMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678084);
			HapticEffectMode.NativeMethodInfoPtr_get_DotMode_Public_get_DotMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678085);
			HapticEffectMode.NativeMethodInfoPtr_set_DotMode_Public_set_Void_DotMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678086);
			HapticEffectMode.NativeMethodInfoPtr_get_PathMode_Public_get_PathMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678087);
			HapticEffectMode.NativeMethodInfoPtr_set_PathMode_Public_set_Void_PathMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678088);
			HapticEffectMode.NativeMethodInfoPtr_ToMode_Internal_Static_HapticEffectMode_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678089);
			HapticEffectMode.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678090);
			HapticEffectMode.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr, 100678091);
		}

		// Token: 0x0600B62D RID: 46637 RVA: 0x00002988 File Offset: 0x00000B88
		public HapticEffectMode(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040F5 RID: 16629
		// (get) Token: 0x0600B62E RID: 46638 RVA: 0x002E9798 File Offset: 0x002E7998
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticEffectMode>.NativeClassPtr));
			}
		}

		// Token: 0x170040F6 RID: 16630
		// (get) Token: 0x0600B62F RID: 46639 RVA: 0x002E97AC File Offset: 0x002E79AC
		// (set) Token: 0x0600B630 RID: 46640 RVA: 0x002E97D4 File Offset: 0x002E79D4
		public unsafe FeedbackMode _Mode_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__Mode_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__Mode_k__BackingField)) = value;
			}
		}

		// Token: 0x170040F7 RID: 16631
		// (get) Token: 0x0600B631 RID: 46641 RVA: 0x002E97F8 File Offset: 0x002E79F8
		// (set) Token: 0x0600B632 RID: 46642 RVA: 0x002E982C File Offset: 0x002E7A2C
		public unsafe DotMode _DotMode_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__DotMode_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DotMode(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__DotMode_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040F8 RID: 16632
		// (get) Token: 0x0600B633 RID: 46643 RVA: 0x002E9854 File Offset: 0x002E7A54
		// (set) Token: 0x0600B634 RID: 46644 RVA: 0x002E9888 File Offset: 0x002E7A88
		public unsafe PathMode _PathMode_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__PathMode_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PathMode(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticEffectMode.NativeFieldInfoPtr__PathMode_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040074B0 RID: 29872
		private static readonly IntPtr NativeFieldInfoPtr__Mode_k__BackingField;

		// Token: 0x040074B1 RID: 29873
		private static readonly IntPtr NativeFieldInfoPtr__DotMode_k__BackingField;

		// Token: 0x040074B2 RID: 29874
		private static readonly IntPtr NativeFieldInfoPtr__PathMode_k__BackingField;

		// Token: 0x040074B3 RID: 29875
		private static readonly IntPtr NativeMethodInfoPtr_get_Mode_Public_get_FeedbackMode_0;

		// Token: 0x040074B4 RID: 29876
		private static readonly IntPtr NativeMethodInfoPtr_set_Mode_Public_set_Void_FeedbackMode_0;

		// Token: 0x040074B5 RID: 29877
		private static readonly IntPtr NativeMethodInfoPtr_get_DotMode_Public_get_DotMode_0;

		// Token: 0x040074B6 RID: 29878
		private static readonly IntPtr NativeMethodInfoPtr_set_DotMode_Public_set_Void_DotMode_0;

		// Token: 0x040074B7 RID: 29879
		private static readonly IntPtr NativeMethodInfoPtr_get_PathMode_Public_get_PathMode_0;

		// Token: 0x040074B8 RID: 29880
		private static readonly IntPtr NativeMethodInfoPtr_set_PathMode_Public_set_Void_PathMode_0;

		// Token: 0x040074B9 RID: 29881
		private static readonly IntPtr NativeMethodInfoPtr_ToMode_Internal_Static_HapticEffectMode_JSONObject_0;

		// Token: 0x040074BA RID: 29882
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074BB RID: 29883
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
