﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A9 RID: 2217
	public class Track : Object
	{
		// Token: 0x170040E1 RID: 16609
		// (get) Token: 0x0600B5E5 RID: 46565 RVA: 0x002E818C File Offset: 0x002E638C
		// (set) Token: 0x0600B5E6 RID: 46566 RVA: 0x002E81E4 File Offset: 0x002E63E4
		public unsafe Il2CppReferenceArray<HapticEffect> Effects
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Track.NativeMethodInfoPtr_get_Effects_Public_get_ArrayOf_HapticEffect_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<HapticEffect>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Track.NativeMethodInfoPtr_set_Effects_Public_set_Void_ArrayOf_HapticEffect_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B5E7 RID: 46567 RVA: 0x002E8240 File Offset: 0x002E6440
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Track.NativeMethodInfoPtr_ToString_Public_Virtual_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600B5E8 RID: 46568 RVA: 0x002E8298 File Offset: 0x002E6498
		[CallerCount(0)]
		public unsafe static Track ToTrack(JSONObject jsonObj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObj);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Track.NativeMethodInfoPtr_ToTrack_Internal_Static_Track_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Track(intPtr2) : null;
		}

		// Token: 0x0600B5E9 RID: 46569 RVA: 0x002E82F8 File Offset: 0x002E64F8
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Track.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B5EA RID: 46570 RVA: 0x002E8350 File Offset: 0x002E6550
		[CallerCount(0)]
		public unsafe Track() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Track>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Track.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5EB RID: 46571 RVA: 0x002E839C File Offset: 0x002E659C
		// Note: this type is marked as 'beforefieldinit'.
		static Track()
		{
			Il2CppClassPointerStore<Track>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "Track");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Track>.NativeClassPtr);
			Track.NativeFieldInfoPtr__Effects_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Track>.NativeClassPtr, "<Effects>k__BackingField");
			Track.NativeMethodInfoPtr_get_Effects_Public_get_ArrayOf_HapticEffect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678051);
			Track.NativeMethodInfoPtr_set_Effects_Public_set_Void_ArrayOf_HapticEffect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678052);
			Track.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678053);
			Track.NativeMethodInfoPtr_ToTrack_Internal_Static_Track_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678054);
			Track.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678055);
			Track.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Track>.NativeClassPtr, 100678056);
		}

		// Token: 0x0600B5EC RID: 46572 RVA: 0x00002988 File Offset: 0x00000B88
		public Track(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040DF RID: 16607
		// (get) Token: 0x0600B5ED RID: 46573 RVA: 0x002E8458 File Offset: 0x002E6658
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Track>.NativeClassPtr));
			}
		}

		// Token: 0x170040E0 RID: 16608
		// (get) Token: 0x0600B5EE RID: 46574 RVA: 0x002E846C File Offset: 0x002E666C
		// (set) Token: 0x0600B5EF RID: 46575 RVA: 0x002E84A0 File Offset: 0x002E66A0
		public unsafe Il2CppReferenceArray<HapticEffect> _Effects_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Track.NativeFieldInfoPtr__Effects_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<HapticEffect>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Track.NativeFieldInfoPtr__Effects_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007487 RID: 29831
		private static readonly IntPtr NativeFieldInfoPtr__Effects_k__BackingField;

		// Token: 0x04007488 RID: 29832
		private static readonly IntPtr NativeMethodInfoPtr_get_Effects_Public_get_ArrayOf_HapticEffect_0;

		// Token: 0x04007489 RID: 29833
		private static readonly IntPtr NativeMethodInfoPtr_set_Effects_Public_set_Void_ArrayOf_HapticEffect_0;

		// Token: 0x0400748A RID: 29834
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x0400748B RID: 29835
		private static readonly IntPtr NativeMethodInfoPtr_ToTrack_Internal_Static_Track_JSONObject_0;

		// Token: 0x0400748C RID: 29836
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x0400748D RID: 29837
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
