﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.Events;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A4 RID: 2212
	public class BhapticsAndroidManager : MonoBehaviour
	{
		// Token: 0x0600B594 RID: 46484 RVA: 0x002E67A8 File Offset: 0x002E49A8
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B595 RID: 46485 RVA: 0x002E67EC File Offset: 0x002E49EC
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B596 RID: 46486 RVA: 0x002E6830 File Offset: 0x002E4A30
		[CallerCount(0)]
		public unsafe void RefreshDevices()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_RefreshDevices_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B597 RID: 46487 RVA: 0x002E6874 File Offset: 0x002E4A74
		[CallerCount(0)]
		public unsafe static void Ping(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_Ping_Public_Static_Void_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B598 RID: 46488 RVA: 0x002E68BC File Offset: 0x002E4ABC
		[CallerCount(0)]
		public unsafe static void TogglePosition(string address)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(address);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_TogglePosition_Public_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B599 RID: 46489 RVA: 0x002E6908 File Offset: 0x002E4B08
		[CallerCount(0)]
		public unsafe static void Ping(HapticDevice device)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(device);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_Ping_Public_Static_Void_HapticDevice_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B59A RID: 46490 RVA: 0x002E6954 File Offset: 0x002E4B54
		[CallerCount(0)]
		public unsafe static void PingAll()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_PingAll_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B59B RID: 46491 RVA: 0x002E6988 File Offset: 0x002E4B88
		[CallerCount(0)]
		public unsafe static List<HapticDevice> GetDevices()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_GetDevices_Public_Static_List_1_HapticDevice_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
		}

		// Token: 0x0600B59C RID: 46492 RVA: 0x002E69D0 File Offset: 0x002E4BD0
		[CallerCount(0)]
		public unsafe static List<HapticDevice> GetConnectedDevices(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_GetConnectedDevices_Public_Static_List_1_HapticDevice_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
		}

		// Token: 0x0600B59D RID: 46493 RVA: 0x002E6A2C File Offset: 0x002E4C2C
		[CallerCount(0)]
		public unsafe static List<HapticDevice> GetPairedDevices(PositionType pos)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_GetPairedDevices_Public_Static_List_1_HapticDevice_PositionType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
		}

		// Token: 0x0600B59E RID: 46494 RVA: 0x002E6A88 File Offset: 0x002E4C88
		[CallerCount(0)]
		public unsafe static void AddRefreshAction(UnityAction action)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(action);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_AddRefreshAction_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B59F RID: 46495 RVA: 0x002E6AD4 File Offset: 0x002E4CD4
		[CallerCount(0)]
		public unsafe static void RemoveRefreshAction(UnityAction action)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(action);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_RemoveRefreshAction_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A0 RID: 46496 RVA: 0x002E6B20 File Offset: 0x002E4D20
		[CallerCount(0)]
		public unsafe static void ClearRefreshAction()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_ClearRefreshAction_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A1 RID: 46497 RVA: 0x002E6B54 File Offset: 0x002E4D54
		[CallerCount(0)]
		public unsafe static bool IsStreaming()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_IsStreaming_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B5A2 RID: 46498 RVA: 0x002E6B98 File Offset: 0x002E4D98
		[CallerCount(0)]
		public unsafe static void ToggleStreaming()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_ToggleStreaming_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A3 RID: 46499 RVA: 0x002E6BCC File Offset: 0x002E4DCC
		[CallerCount(0)]
		public unsafe static List<AndroidUtils.StreamHost> GetStreamingHosts()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_GetStreamingHosts_Public_Static_List_1_StreamHost_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<AndroidUtils.StreamHost>(intPtr2) : null;
		}

		// Token: 0x0600B5A4 RID: 46500 RVA: 0x002E6C14 File Offset: 0x002E4E14
		[CallerCount(0)]
		public unsafe static void ShowBluetoothSetting()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_ShowBluetoothSetting_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A5 RID: 46501 RVA: 0x002E6C48 File Offset: 0x002E4E48
		[CallerCount(0)]
		public unsafe static void ToggleEnableDevice(HapticDevice device)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(device);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_ToggleEnableDevice_Public_Static_Void_HapticDevice_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A6 RID: 46502 RVA: 0x002E6C94 File Offset: 0x002E4E94
		[CallerCount(0)]
		public unsafe void OnApplicationFocus(bool pauseStatus)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pauseStatus;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A7 RID: 46503 RVA: 0x002E6CE8 File Offset: 0x002E4EE8
		[CallerCount(0)]
		public unsafe BhapticsAndroidManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsAndroidManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5A8 RID: 46504 RVA: 0x002E6D34 File Offset: 0x002E4F34
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsAndroidManager()
		{
			Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "BhapticsAndroidManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr);
			BhapticsAndroidManager.NativeFieldInfoPtr_Instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, "Instance");
			BhapticsAndroidManager.NativeFieldInfoPtr_pcAndoidTestMode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, "pcAndoidTestMode");
			BhapticsAndroidManager.NativeFieldInfoPtr_Devices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, "Devices");
			BhapticsAndroidManager.NativeFieldInfoPtr_refreshActions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, "refreshActions");
			BhapticsAndroidManager.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678000);
			BhapticsAndroidManager.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678001);
			BhapticsAndroidManager.NativeMethodInfoPtr_RefreshDevices_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678002);
			BhapticsAndroidManager.NativeMethodInfoPtr_Ping_Public_Static_Void_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678003);
			BhapticsAndroidManager.NativeMethodInfoPtr_TogglePosition_Public_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678004);
			BhapticsAndroidManager.NativeMethodInfoPtr_Ping_Public_Static_Void_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678005);
			BhapticsAndroidManager.NativeMethodInfoPtr_PingAll_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678006);
			BhapticsAndroidManager.NativeMethodInfoPtr_GetDevices_Public_Static_List_1_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678007);
			BhapticsAndroidManager.NativeMethodInfoPtr_GetConnectedDevices_Public_Static_List_1_HapticDevice_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678008);
			BhapticsAndroidManager.NativeMethodInfoPtr_GetPairedDevices_Public_Static_List_1_HapticDevice_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678009);
			BhapticsAndroidManager.NativeMethodInfoPtr_AddRefreshAction_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678010);
			BhapticsAndroidManager.NativeMethodInfoPtr_RemoveRefreshAction_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678011);
			BhapticsAndroidManager.NativeMethodInfoPtr_ClearRefreshAction_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678012);
			BhapticsAndroidManager.NativeMethodInfoPtr_IsStreaming_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678013);
			BhapticsAndroidManager.NativeMethodInfoPtr_ToggleStreaming_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678014);
			BhapticsAndroidManager.NativeMethodInfoPtr_GetStreamingHosts_Public_Static_List_1_StreamHost_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678015);
			BhapticsAndroidManager.NativeMethodInfoPtr_ShowBluetoothSetting_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678016);
			BhapticsAndroidManager.NativeMethodInfoPtr_ToggleEnableDevice_Public_Static_Void_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678017);
			BhapticsAndroidManager.NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678018);
			BhapticsAndroidManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr, 100678019);
		}

		// Token: 0x0600B5A9 RID: 46505 RVA: 0x0000210C File Offset: 0x0000030C
		public BhapticsAndroidManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040D0 RID: 16592
		// (get) Token: 0x0600B5AA RID: 46506 RVA: 0x002E6F44 File Offset: 0x002E5144
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsAndroidManager>.NativeClassPtr));
			}
		}

		// Token: 0x170040D1 RID: 16593
		// (get) Token: 0x0600B5AB RID: 46507 RVA: 0x002E6F58 File Offset: 0x002E5158
		// (set) Token: 0x0600B5AC RID: 46508 RVA: 0x002E6F83 File Offset: 0x002E5183
		public unsafe static BhapticsAndroidManager Instance
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BhapticsAndroidManager.NativeFieldInfoPtr_Instance, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new BhapticsAndroidManager(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsAndroidManager.NativeFieldInfoPtr_Instance, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040D2 RID: 16594
		// (get) Token: 0x0600B5AD RID: 46509 RVA: 0x002E6F98 File Offset: 0x002E5198
		// (set) Token: 0x0600B5AE RID: 46510 RVA: 0x002E6FB6 File Offset: 0x002E51B6
		public unsafe static bool pcAndoidTestMode
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsAndroidManager.NativeFieldInfoPtr_pcAndoidTestMode, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsAndroidManager.NativeFieldInfoPtr_pcAndoidTestMode, (void*)(&value));
			}
		}

		// Token: 0x170040D3 RID: 16595
		// (get) Token: 0x0600B5AF RID: 46511 RVA: 0x002E6FC8 File Offset: 0x002E51C8
		// (set) Token: 0x0600B5B0 RID: 46512 RVA: 0x002E6FFC File Offset: 0x002E51FC
		public unsafe List<HapticDevice> Devices
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsAndroidManager.NativeFieldInfoPtr_Devices);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsAndroidManager.NativeFieldInfoPtr_Devices), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040D4 RID: 16596
		// (get) Token: 0x0600B5B1 RID: 46513 RVA: 0x002E7024 File Offset: 0x002E5224
		// (set) Token: 0x0600B5B2 RID: 46514 RVA: 0x002E704F File Offset: 0x002E524F
		public unsafe static List<UnityAction> refreshActions
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BhapticsAndroidManager.NativeFieldInfoPtr_refreshActions, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<UnityAction>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsAndroidManager.NativeFieldInfoPtr_refreshActions, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400744D RID: 29773
		private static readonly IntPtr NativeFieldInfoPtr_Instance;

		// Token: 0x0400744E RID: 29774
		private static readonly IntPtr NativeFieldInfoPtr_pcAndoidTestMode;

		// Token: 0x0400744F RID: 29775
		private static readonly IntPtr NativeFieldInfoPtr_Devices;

		// Token: 0x04007450 RID: 29776
		private static readonly IntPtr NativeFieldInfoPtr_refreshActions;

		// Token: 0x04007451 RID: 29777
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x04007452 RID: 29778
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04007453 RID: 29779
		private static readonly IntPtr NativeMethodInfoPtr_RefreshDevices_Private_Void_0;

		// Token: 0x04007454 RID: 29780
		private static readonly IntPtr NativeMethodInfoPtr_Ping_Public_Static_Void_PositionType_0;

		// Token: 0x04007455 RID: 29781
		private static readonly IntPtr NativeMethodInfoPtr_TogglePosition_Public_Static_Void_String_0;

		// Token: 0x04007456 RID: 29782
		private static readonly IntPtr NativeMethodInfoPtr_Ping_Public_Static_Void_HapticDevice_0;

		// Token: 0x04007457 RID: 29783
		private static readonly IntPtr NativeMethodInfoPtr_PingAll_Public_Static_Void_0;

		// Token: 0x04007458 RID: 29784
		private static readonly IntPtr NativeMethodInfoPtr_GetDevices_Public_Static_List_1_HapticDevice_0;

		// Token: 0x04007459 RID: 29785
		private static readonly IntPtr NativeMethodInfoPtr_GetConnectedDevices_Public_Static_List_1_HapticDevice_PositionType_0;

		// Token: 0x0400745A RID: 29786
		private static readonly IntPtr NativeMethodInfoPtr_GetPairedDevices_Public_Static_List_1_HapticDevice_PositionType_0;

		// Token: 0x0400745B RID: 29787
		private static readonly IntPtr NativeMethodInfoPtr_AddRefreshAction_Public_Static_Void_UnityAction_0;

		// Token: 0x0400745C RID: 29788
		private static readonly IntPtr NativeMethodInfoPtr_RemoveRefreshAction_Public_Static_Void_UnityAction_0;

		// Token: 0x0400745D RID: 29789
		private static readonly IntPtr NativeMethodInfoPtr_ClearRefreshAction_Public_Static_Void_0;

		// Token: 0x0400745E RID: 29790
		private static readonly IntPtr NativeMethodInfoPtr_IsStreaming_Public_Static_Boolean_0;

		// Token: 0x0400745F RID: 29791
		private static readonly IntPtr NativeMethodInfoPtr_ToggleStreaming_Public_Static_Void_0;

		// Token: 0x04007460 RID: 29792
		private static readonly IntPtr NativeMethodInfoPtr_GetStreamingHosts_Public_Static_List_1_StreamHost_0;

		// Token: 0x04007461 RID: 29793
		private static readonly IntPtr NativeMethodInfoPtr_ShowBluetoothSetting_Public_Static_Void_0;

		// Token: 0x04007462 RID: 29794
		private static readonly IntPtr NativeMethodInfoPtr_ToggleEnableDevice_Public_Static_Void_HapticDevice_0;

		// Token: 0x04007463 RID: 29795
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0;

		// Token: 0x04007464 RID: 29796
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
