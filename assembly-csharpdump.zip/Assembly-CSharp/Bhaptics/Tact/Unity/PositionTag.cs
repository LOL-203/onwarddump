﻿using System;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C0 RID: 2240
	public enum PositionTag
	{
		// Token: 0x04007562 RID: 30050
		Body,
		// Token: 0x04007563 RID: 30051
		Head,
		// Token: 0x04007564 RID: 30052
		LeftArm,
		// Token: 0x04007565 RID: 30053
		RightArm,
		// Token: 0x04007566 RID: 30054
		Default
	}
}
