﻿using System;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C8 RID: 2248
	[Serializable]
	public enum SimpleHapticType
	{
		// Token: 0x040075AF RID: 30127
		DotMode = 1,
		// Token: 0x040075B0 RID: 30128
		PathMode
	}
}
