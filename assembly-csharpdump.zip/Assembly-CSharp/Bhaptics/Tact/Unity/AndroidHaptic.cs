﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x02000899 RID: 2201
	public class AndroidHaptic : Il2CppSystem.Object
	{
		// Token: 0x0600B477 RID: 46199 RVA: 0x002E21A8 File Offset: 0x002E03A8
		[CallerCount(0)]
		public unsafe AndroidHaptic() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B478 RID: 46200 RVA: 0x002E21F4 File Offset: 0x002E03F4
		[CallerCount(0)]
		public unsafe List<AndroidUtils.StreamHost> GetStreamingHosts()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_GetStreamingHosts_Public_List_1_StreamHost_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<AndroidUtils.StreamHost>(intPtr2) : null;
		}

		// Token: 0x0600B479 RID: 46201 RVA: 0x002E224C File Offset: 0x002E044C
		[CallerCount(0)]
		public unsafe bool IsStreamingEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsStreamingEnable_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B47A RID: 46202 RVA: 0x002E229C File Offset: 0x002E049C
		[CallerCount(0)]
		public unsafe void ToggleStreaming()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_ToggleStreaming_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B47B RID: 46203 RVA: 0x002E22E0 File Offset: 0x002E04E0
		[CallerCount(0)]
		public unsafe bool IsConnect(PositionType type)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B47C RID: 46204 RVA: 0x002E2344 File Offset: 0x002E0544
		[CallerCount(0)]
		public unsafe bool IsConnect(HapticDeviceType type, bool isLeft = true)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isLeft;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B47D RID: 46205 RVA: 0x002E23BC File Offset: 0x002E05BC
		[CallerCount(0)]
		public unsafe bool IsPlaying(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B47E RID: 46206 RVA: 0x002E2424 File Offset: 0x002E0624
		[CallerCount(0)]
		public unsafe bool IsFeedbackRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B47F RID: 46207 RVA: 0x002E248C File Offset: 0x002E068C
		[CallerCount(0)]
		public unsafe bool IsPlaying()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B480 RID: 46208 RVA: 0x002E24DC File Offset: 0x002E06DC
		[CallerCount(0)]
		public unsafe void RegisterTactFileStr(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B481 RID: 46209 RVA: 0x002E2550 File Offset: 0x002E0750
		[CallerCount(0)]
		public unsafe void RegisterTactFileStrReflected(string key, string tactFileStr)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(tactFileStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B482 RID: 46210 RVA: 0x002E25C4 File Offset: 0x002E07C4
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<DotPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B483 RID: 46211 RVA: 0x002E265C File Offset: 0x002E085C
		[CallerCount(0)]
		public unsafe void Submit(string key, PositionType position, List<PathPoint> points, int durationMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B484 RID: 46212 RVA: 0x002E26F4 File Offset: 0x002E08F4
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, ScaleOption option)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(option);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B485 RID: 46213 RVA: 0x002E2780 File Offset: 0x002E0980
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, string altKey, RotationOption rOption, ScaleOption sOption)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(rOption);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(sOption);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B486 RID: 46214 RVA: 0x002E2824 File Offset: 0x002E0A24
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B487 RID: 46215 RVA: 0x002E2880 File Offset: 0x002E0A80
		[CallerCount(0)]
		public unsafe void SubmitRegistered(string key, int startTimeMillis)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref startTimeMillis;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B488 RID: 46216 RVA: 0x002E28EC File Offset: 0x002E0AEC
		[CallerCount(0)]
		public unsafe void TurnOff(string key)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B489 RID: 46217 RVA: 0x002E2948 File Offset: 0x002E0B48
		[CallerCount(0)]
		public unsafe void TurnOff()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B48A RID: 46218 RVA: 0x002E298C File Offset: 0x002E0B8C
		[CallerCount(0)]
		public unsafe void Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B48B RID: 46219 RVA: 0x002E29D0 File Offset: 0x002E0BD0
		[CallerCount(0)]
		public unsafe void SubmitRequest(string key, string altKey, float intensity, float duration, float offsetAngleX, float offsetY)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(altKey);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensity;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetAngleX;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_SubmitRequest_Private_Void_String_String_Single_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B48C RID: 46220 RVA: 0x002E2A90 File Offset: 0x002E0C90
		[CallerCount(0)]
		public unsafe Il2CppStructArray<int> GetCurrentFeedback(PositionType pos)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}

		// Token: 0x0600B48D RID: 46221 RVA: 0x002E2AF8 File Offset: 0x002E0CF8
		[CallerCount(0)]
		public unsafe List<HapticDevice> GetDevices()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_GetDevices_Public_List_1_HapticDevice_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
		}

		// Token: 0x0600B48E RID: 46222 RVA: 0x002E2B50 File Offset: 0x002E0D50
		[CallerCount(0)]
		public unsafe void TogglePosition(string address)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(address);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_TogglePosition_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B48F RID: 46223 RVA: 0x002E2BAC File Offset: 0x002E0DAC
		[CallerCount(0)]
		public unsafe void PingAll()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_PingAll_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B490 RID: 46224 RVA: 0x002E2BF0 File Offset: 0x002E0DF0
		[CallerCount(0)]
		public unsafe void Ping(string address)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(address);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_Ping_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B491 RID: 46225 RVA: 0x002E2C4C File Offset: 0x002E0E4C
		[CallerCount(0)]
		public unsafe void ShowBluetoothSetting()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_ShowBluetoothSetting_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B492 RID: 46226 RVA: 0x002E2C90 File Offset: 0x002E0E90
		[CallerCount(0)]
		public unsafe void EnableDevice(string address, bool boo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(address);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref boo;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_EnableDevice_Public_Void_String_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B493 RID: 46227 RVA: 0x002E2CFC File Offset: 0x002E0EFC
		[CallerCount(0)]
		public unsafe void RefreshPairingInfo()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_RefreshPairingInfo_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B494 RID: 46228 RVA: 0x002E2D40 File Offset: 0x002E0F40
		[CallerCount(0)]
		public unsafe void CallNativeVoidMethod(IntPtr methodPtr, Il2CppReferenceArray<Il2CppSystem.Object> param)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref methodPtr;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(param);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_CallNativeVoidMethod_Private_Void_IntPtr_ArrayOf_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B495 RID: 46229 RVA: 0x002E2DAC File Offset: 0x002E0FAC
		[CallerCount(0)]
		public unsafe bool CallNativeBoolMethod(IntPtr methodPtr, Il2CppReferenceArray<Il2CppSystem.Object> param)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref methodPtr;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(param);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AndroidHaptic.NativeMethodInfoPtr_CallNativeBoolMethod_Private_Boolean_IntPtr_ArrayOf_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600B496 RID: 46230 RVA: 0x002E2E28 File Offset: 0x002E1028
		// Note: this type is marked as 'beforefieldinit'.
		static AndroidHaptic()
		{
			Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "AndroidHaptic");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr);
			AndroidHaptic.NativeFieldInfoPtr_androidJavaObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "androidJavaObject");
			AndroidHaptic.NativeFieldInfoPtr_deviceList = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "deviceList");
			AndroidHaptic.NativeFieldInfoPtr_registeredCache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "registeredCache");
			AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredParams = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "SubmitRegisteredParams");
			AndroidHaptic.NativeFieldInfoPtr_Empty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "Empty");
			AndroidHaptic.NativeFieldInfoPtr_EmptyParams = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "EmptyParams");
			AndroidHaptic.NativeFieldInfoPtr_DefaultRotationOption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "DefaultRotationOption");
			AndroidHaptic.NativeFieldInfoPtr_syncLock = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "syncLock");
			AndroidHaptic.NativeFieldInfoPtr_updatedList = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "updatedList");
			AndroidHaptic.NativeFieldInfoPtr_AndroidJavaObjectPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "AndroidJavaObjectPtr");
			AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "SubmitRegisteredPtr");
			AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredWithTimePtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "SubmitRegisteredWithTimePtr");
			AndroidHaptic.NativeFieldInfoPtr_RegisterPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "RegisterPtr");
			AndroidHaptic.NativeFieldInfoPtr_RegisterReflectedPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "RegisterReflectedPtr");
			AndroidHaptic.NativeFieldInfoPtr_PingPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "PingPtr");
			AndroidHaptic.NativeFieldInfoPtr_PingAllPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "PingAllPtr");
			AndroidHaptic.NativeFieldInfoPtr_IsRegisteredPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "IsRegisteredPtr");
			AndroidHaptic.NativeFieldInfoPtr_IsPlayingPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "IsPlayingPtr");
			AndroidHaptic.NativeFieldInfoPtr_IsPlayingAnythingPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "IsPlayingAnythingPtr");
			AndroidHaptic.NativeFieldInfoPtr_ToggleStreamPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "ToggleStreamPtr");
			AndroidHaptic.NativeFieldInfoPtr_IsStreamingEnablePtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "IsStreamingEnablePtr");
			AndroidHaptic.NativeFieldInfoPtr_GetStreamingHostsPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "GetStreamingHostsPtr");
			AndroidHaptic.NativeFieldInfoPtr_ShowBluetoothPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "ShowBluetoothPtr");
			AndroidHaptic.NativeFieldInfoPtr_RefreshPairingInfoPtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "RefreshPairingInfoPtr");
			AndroidHaptic.NativeFieldInfoPtr_EnableDevicePtr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, "EnableDevicePtr");
			AndroidHaptic.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677928);
			AndroidHaptic.NativeMethodInfoPtr_GetStreamingHosts_Public_List_1_StreamHost_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677929);
			AndroidHaptic.NativeMethodInfoPtr_IsStreamingEnable_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677930);
			AndroidHaptic.NativeMethodInfoPtr_ToggleStreaming_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677931);
			AndroidHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677932);
			AndroidHaptic.NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677933);
			AndroidHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677934);
			AndroidHaptic.NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677935);
			AndroidHaptic.NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677936);
			AndroidHaptic.NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677937);
			AndroidHaptic.NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677938);
			AndroidHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677939);
			AndroidHaptic.NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677940);
			AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677941);
			AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677942);
			AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677943);
			AndroidHaptic.NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677944);
			AndroidHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677945);
			AndroidHaptic.NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677946);
			AndroidHaptic.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677947);
			AndroidHaptic.NativeMethodInfoPtr_SubmitRequest_Private_Void_String_String_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677948);
			AndroidHaptic.NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677949);
			AndroidHaptic.NativeMethodInfoPtr_GetDevices_Public_List_1_HapticDevice_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677950);
			AndroidHaptic.NativeMethodInfoPtr_TogglePosition_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677951);
			AndroidHaptic.NativeMethodInfoPtr_PingAll_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677952);
			AndroidHaptic.NativeMethodInfoPtr_Ping_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677953);
			AndroidHaptic.NativeMethodInfoPtr_ShowBluetoothSetting_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677954);
			AndroidHaptic.NativeMethodInfoPtr_EnableDevice_Public_Void_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677955);
			AndroidHaptic.NativeMethodInfoPtr_RefreshPairingInfo_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677956);
			AndroidHaptic.NativeMethodInfoPtr_CallNativeVoidMethod_Private_Void_IntPtr_ArrayOf_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677957);
			AndroidHaptic.NativeMethodInfoPtr_CallNativeBoolMethod_Private_Boolean_IntPtr_ArrayOf_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr, 100677958);
		}

		// Token: 0x0600B497 RID: 46231 RVA: 0x00002988 File Offset: 0x00000B88
		public AndroidHaptic(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700406A RID: 16490
		// (get) Token: 0x0600B498 RID: 46232 RVA: 0x002E32B8 File Offset: 0x002E14B8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AndroidHaptic>.NativeClassPtr));
			}
		}

		// Token: 0x1700406B RID: 16491
		// (get) Token: 0x0600B499 RID: 46233 RVA: 0x002E32CC File Offset: 0x002E14CC
		// (set) Token: 0x0600B49A RID: 46234 RVA: 0x002E32F7 File Offset: 0x002E14F7
		public unsafe static AndroidJavaObject androidJavaObject
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AndroidHaptic.NativeFieldInfoPtr_androidJavaObject, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new AndroidJavaObject(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AndroidHaptic.NativeFieldInfoPtr_androidJavaObject, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700406C RID: 16492
		// (get) Token: 0x0600B49B RID: 46235 RVA: 0x002E330C File Offset: 0x002E150C
		// (set) Token: 0x0600B49C RID: 46236 RVA: 0x002E3340 File Offset: 0x002E1540
		public unsafe List<HapticDevice> deviceList
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_deviceList);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<HapticDevice>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_deviceList), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700406D RID: 16493
		// (get) Token: 0x0600B49D RID: 46237 RVA: 0x002E3368 File Offset: 0x002E1568
		// (set) Token: 0x0600B49E RID: 46238 RVA: 0x002E339C File Offset: 0x002E159C
		public unsafe List<string> registeredCache
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_registeredCache);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<string>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_registeredCache), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700406E RID: 16494
		// (get) Token: 0x0600B49F RID: 46239 RVA: 0x002E33C4 File Offset: 0x002E15C4
		// (set) Token: 0x0600B4A0 RID: 46240 RVA: 0x002E33EF File Offset: 0x002E15EF
		public unsafe static Il2CppReferenceArray<Il2CppSystem.Object> SubmitRegisteredParams
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredParams, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Il2CppSystem.Object>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredParams, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700406F RID: 16495
		// (get) Token: 0x0600B4A1 RID: 46241 RVA: 0x002E3404 File Offset: 0x002E1604
		// (set) Token: 0x0600B4A2 RID: 46242 RVA: 0x002E342F File Offset: 0x002E162F
		public unsafe static Il2CppStructArray<int> Empty
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AndroidHaptic.NativeFieldInfoPtr_Empty, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AndroidHaptic.NativeFieldInfoPtr_Empty, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004070 RID: 16496
		// (get) Token: 0x0600B4A3 RID: 46243 RVA: 0x002E3444 File Offset: 0x002E1644
		// (set) Token: 0x0600B4A4 RID: 46244 RVA: 0x002E346F File Offset: 0x002E166F
		public unsafe static Il2CppReferenceArray<Il2CppSystem.Object> EmptyParams
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AndroidHaptic.NativeFieldInfoPtr_EmptyParams, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Il2CppSystem.Object>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AndroidHaptic.NativeFieldInfoPtr_EmptyParams, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004071 RID: 16497
		// (get) Token: 0x0600B4A5 RID: 46245 RVA: 0x002E3484 File Offset: 0x002E1684
		// (set) Token: 0x0600B4A6 RID: 46246 RVA: 0x002E34AF File Offset: 0x002E16AF
		public unsafe static RotationOption DefaultRotationOption
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AndroidHaptic.NativeFieldInfoPtr_DefaultRotationOption, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new RotationOption(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AndroidHaptic.NativeFieldInfoPtr_DefaultRotationOption, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004072 RID: 16498
		// (get) Token: 0x0600B4A7 RID: 46247 RVA: 0x002E34C4 File Offset: 0x002E16C4
		// (set) Token: 0x0600B4A8 RID: 46248 RVA: 0x002E34F8 File Offset: 0x002E16F8
		public unsafe Il2CppSystem.Object syncLock
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_syncLock);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_syncLock), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004073 RID: 16499
		// (get) Token: 0x0600B4A9 RID: 46249 RVA: 0x002E3520 File Offset: 0x002E1720
		// (set) Token: 0x0600B4AA RID: 46250 RVA: 0x002E3554 File Offset: 0x002E1754
		public unsafe Dictionary<PositionType, Il2CppStructArray<int>> updatedList
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_updatedList);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<PositionType, Il2CppStructArray<int>>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_updatedList), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004074 RID: 16500
		// (get) Token: 0x0600B4AB RID: 46251 RVA: 0x002E357C File Offset: 0x002E177C
		// (set) Token: 0x0600B4AC RID: 46252 RVA: 0x002E35A4 File Offset: 0x002E17A4
		public unsafe IntPtr AndroidJavaObjectPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_AndroidJavaObjectPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_AndroidJavaObjectPtr)) = value;
			}
		}

		// Token: 0x17004075 RID: 16501
		// (get) Token: 0x0600B4AD RID: 46253 RVA: 0x002E35C8 File Offset: 0x002E17C8
		// (set) Token: 0x0600B4AE RID: 46254 RVA: 0x002E35F0 File Offset: 0x002E17F0
		public unsafe IntPtr SubmitRegisteredPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredPtr)) = value;
			}
		}

		// Token: 0x17004076 RID: 16502
		// (get) Token: 0x0600B4AF RID: 46255 RVA: 0x002E3614 File Offset: 0x002E1814
		// (set) Token: 0x0600B4B0 RID: 46256 RVA: 0x002E363C File Offset: 0x002E183C
		public unsafe IntPtr SubmitRegisteredWithTimePtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredWithTimePtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_SubmitRegisteredWithTimePtr)) = value;
			}
		}

		// Token: 0x17004077 RID: 16503
		// (get) Token: 0x0600B4B1 RID: 46257 RVA: 0x002E3660 File Offset: 0x002E1860
		// (set) Token: 0x0600B4B2 RID: 46258 RVA: 0x002E3688 File Offset: 0x002E1888
		public unsafe IntPtr RegisterPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RegisterPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RegisterPtr)) = value;
			}
		}

		// Token: 0x17004078 RID: 16504
		// (get) Token: 0x0600B4B3 RID: 46259 RVA: 0x002E36AC File Offset: 0x002E18AC
		// (set) Token: 0x0600B4B4 RID: 46260 RVA: 0x002E36D4 File Offset: 0x002E18D4
		public unsafe IntPtr RegisterReflectedPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RegisterReflectedPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RegisterReflectedPtr)) = value;
			}
		}

		// Token: 0x17004079 RID: 16505
		// (get) Token: 0x0600B4B5 RID: 46261 RVA: 0x002E36F8 File Offset: 0x002E18F8
		// (set) Token: 0x0600B4B6 RID: 46262 RVA: 0x002E3720 File Offset: 0x002E1920
		public unsafe IntPtr PingPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_PingPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_PingPtr)) = value;
			}
		}

		// Token: 0x1700407A RID: 16506
		// (get) Token: 0x0600B4B7 RID: 46263 RVA: 0x002E3744 File Offset: 0x002E1944
		// (set) Token: 0x0600B4B8 RID: 46264 RVA: 0x002E376C File Offset: 0x002E196C
		public unsafe IntPtr PingAllPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_PingAllPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_PingAllPtr)) = value;
			}
		}

		// Token: 0x1700407B RID: 16507
		// (get) Token: 0x0600B4B9 RID: 46265 RVA: 0x002E3790 File Offset: 0x002E1990
		// (set) Token: 0x0600B4BA RID: 46266 RVA: 0x002E37B8 File Offset: 0x002E19B8
		public unsafe IntPtr IsRegisteredPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsRegisteredPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsRegisteredPtr)) = value;
			}
		}

		// Token: 0x1700407C RID: 16508
		// (get) Token: 0x0600B4BB RID: 46267 RVA: 0x002E37DC File Offset: 0x002E19DC
		// (set) Token: 0x0600B4BC RID: 46268 RVA: 0x002E3804 File Offset: 0x002E1A04
		public unsafe IntPtr IsPlayingPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsPlayingPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsPlayingPtr)) = value;
			}
		}

		// Token: 0x1700407D RID: 16509
		// (get) Token: 0x0600B4BD RID: 46269 RVA: 0x002E3828 File Offset: 0x002E1A28
		// (set) Token: 0x0600B4BE RID: 46270 RVA: 0x002E3850 File Offset: 0x002E1A50
		public unsafe IntPtr IsPlayingAnythingPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsPlayingAnythingPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsPlayingAnythingPtr)) = value;
			}
		}

		// Token: 0x1700407E RID: 16510
		// (get) Token: 0x0600B4BF RID: 46271 RVA: 0x002E3874 File Offset: 0x002E1A74
		// (set) Token: 0x0600B4C0 RID: 46272 RVA: 0x002E389C File Offset: 0x002E1A9C
		public unsafe IntPtr ToggleStreamPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_ToggleStreamPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_ToggleStreamPtr)) = value;
			}
		}

		// Token: 0x1700407F RID: 16511
		// (get) Token: 0x0600B4C1 RID: 46273 RVA: 0x002E38C0 File Offset: 0x002E1AC0
		// (set) Token: 0x0600B4C2 RID: 46274 RVA: 0x002E38E8 File Offset: 0x002E1AE8
		public unsafe IntPtr IsStreamingEnablePtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsStreamingEnablePtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_IsStreamingEnablePtr)) = value;
			}
		}

		// Token: 0x17004080 RID: 16512
		// (get) Token: 0x0600B4C3 RID: 46275 RVA: 0x002E390C File Offset: 0x002E1B0C
		// (set) Token: 0x0600B4C4 RID: 46276 RVA: 0x002E3934 File Offset: 0x002E1B34
		public unsafe IntPtr GetStreamingHostsPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_GetStreamingHostsPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_GetStreamingHostsPtr)) = value;
			}
		}

		// Token: 0x17004081 RID: 16513
		// (get) Token: 0x0600B4C5 RID: 46277 RVA: 0x002E3958 File Offset: 0x002E1B58
		// (set) Token: 0x0600B4C6 RID: 46278 RVA: 0x002E3980 File Offset: 0x002E1B80
		public unsafe IntPtr ShowBluetoothPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_ShowBluetoothPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_ShowBluetoothPtr)) = value;
			}
		}

		// Token: 0x17004082 RID: 16514
		// (get) Token: 0x0600B4C7 RID: 46279 RVA: 0x002E39A4 File Offset: 0x002E1BA4
		// (set) Token: 0x0600B4C8 RID: 46280 RVA: 0x002E39CC File Offset: 0x002E1BCC
		public unsafe IntPtr RefreshPairingInfoPtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RefreshPairingInfoPtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_RefreshPairingInfoPtr)) = value;
			}
		}

		// Token: 0x17004083 RID: 16515
		// (get) Token: 0x0600B4C9 RID: 46281 RVA: 0x002E39F0 File Offset: 0x002E1BF0
		// (set) Token: 0x0600B4CA RID: 46282 RVA: 0x002E3A18 File Offset: 0x002E1C18
		public unsafe IntPtr EnableDevicePtr
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_EnableDevicePtr);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AndroidHaptic.NativeFieldInfoPtr_EnableDevicePtr)) = value;
			}
		}

		// Token: 0x040073AA RID: 29610
		private static readonly IntPtr NativeFieldInfoPtr_androidJavaObject;

		// Token: 0x040073AB RID: 29611
		private static readonly IntPtr NativeFieldInfoPtr_deviceList;

		// Token: 0x040073AC RID: 29612
		private static readonly IntPtr NativeFieldInfoPtr_registeredCache;

		// Token: 0x040073AD RID: 29613
		private static readonly IntPtr NativeFieldInfoPtr_SubmitRegisteredParams;

		// Token: 0x040073AE RID: 29614
		private static readonly IntPtr NativeFieldInfoPtr_Empty;

		// Token: 0x040073AF RID: 29615
		private static readonly IntPtr NativeFieldInfoPtr_EmptyParams;

		// Token: 0x040073B0 RID: 29616
		private static readonly IntPtr NativeFieldInfoPtr_DefaultRotationOption;

		// Token: 0x040073B1 RID: 29617
		private static readonly IntPtr NativeFieldInfoPtr_syncLock;

		// Token: 0x040073B2 RID: 29618
		private static readonly IntPtr NativeFieldInfoPtr_updatedList;

		// Token: 0x040073B3 RID: 29619
		private static readonly IntPtr NativeFieldInfoPtr_AndroidJavaObjectPtr;

		// Token: 0x040073B4 RID: 29620
		private static readonly IntPtr NativeFieldInfoPtr_SubmitRegisteredPtr;

		// Token: 0x040073B5 RID: 29621
		private static readonly IntPtr NativeFieldInfoPtr_SubmitRegisteredWithTimePtr;

		// Token: 0x040073B6 RID: 29622
		private static readonly IntPtr NativeFieldInfoPtr_RegisterPtr;

		// Token: 0x040073B7 RID: 29623
		private static readonly IntPtr NativeFieldInfoPtr_RegisterReflectedPtr;

		// Token: 0x040073B8 RID: 29624
		private static readonly IntPtr NativeFieldInfoPtr_PingPtr;

		// Token: 0x040073B9 RID: 29625
		private static readonly IntPtr NativeFieldInfoPtr_PingAllPtr;

		// Token: 0x040073BA RID: 29626
		private static readonly IntPtr NativeFieldInfoPtr_IsRegisteredPtr;

		// Token: 0x040073BB RID: 29627
		private static readonly IntPtr NativeFieldInfoPtr_IsPlayingPtr;

		// Token: 0x040073BC RID: 29628
		private static readonly IntPtr NativeFieldInfoPtr_IsPlayingAnythingPtr;

		// Token: 0x040073BD RID: 29629
		private static readonly IntPtr NativeFieldInfoPtr_ToggleStreamPtr;

		// Token: 0x040073BE RID: 29630
		private static readonly IntPtr NativeFieldInfoPtr_IsStreamingEnablePtr;

		// Token: 0x040073BF RID: 29631
		private static readonly IntPtr NativeFieldInfoPtr_GetStreamingHostsPtr;

		// Token: 0x040073C0 RID: 29632
		private static readonly IntPtr NativeFieldInfoPtr_ShowBluetoothPtr;

		// Token: 0x040073C1 RID: 29633
		private static readonly IntPtr NativeFieldInfoPtr_RefreshPairingInfoPtr;

		// Token: 0x040073C2 RID: 29634
		private static readonly IntPtr NativeFieldInfoPtr_EnableDevicePtr;

		// Token: 0x040073C3 RID: 29635
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x040073C4 RID: 29636
		private static readonly IntPtr NativeMethodInfoPtr_GetStreamingHosts_Public_List_1_StreamHost_0;

		// Token: 0x040073C5 RID: 29637
		private static readonly IntPtr NativeMethodInfoPtr_IsStreamingEnable_Public_Boolean_0;

		// Token: 0x040073C6 RID: 29638
		private static readonly IntPtr NativeMethodInfoPtr_ToggleStreaming_Public_Void_0;

		// Token: 0x040073C7 RID: 29639
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_PositionType_0;

		// Token: 0x040073C8 RID: 29640
		private static readonly IntPtr NativeMethodInfoPtr_IsConnect_Public_Virtual_Final_New_Boolean_HapticDeviceType_Boolean_0;

		// Token: 0x040073C9 RID: 29641
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_String_0;

		// Token: 0x040073CA RID: 29642
		private static readonly IntPtr NativeMethodInfoPtr_IsFeedbackRegistered_Public_Virtual_Final_New_Boolean_String_0;

		// Token: 0x040073CB RID: 29643
		private static readonly IntPtr NativeMethodInfoPtr_IsPlaying_Public_Virtual_Final_New_Boolean_0;

		// Token: 0x040073CC RID: 29644
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStr_Public_Virtual_Final_New_Void_String_String_0;

		// Token: 0x040073CD RID: 29645
		private static readonly IntPtr NativeMethodInfoPtr_RegisterTactFileStrReflected_Public_Virtual_Final_New_Void_String_String_0;

		// Token: 0x040073CE RID: 29646
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_DotPoint_Int32_0;

		// Token: 0x040073CF RID: 29647
		private static readonly IntPtr NativeMethodInfoPtr_Submit_Public_Virtual_Final_New_Void_String_PositionType_List_1_PathPoint_Int32_0;

		// Token: 0x040073D0 RID: 29648
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_ScaleOption_0;

		// Token: 0x040073D1 RID: 29649
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_String_RotationOption_ScaleOption_0;

		// Token: 0x040073D2 RID: 29650
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_0;

		// Token: 0x040073D3 RID: 29651
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRegistered_Public_Virtual_Final_New_Void_String_Int32_0;

		// Token: 0x040073D4 RID: 29652
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_String_0;

		// Token: 0x040073D5 RID: 29653
		private static readonly IntPtr NativeMethodInfoPtr_TurnOff_Public_Virtual_Final_New_Void_0;

		// Token: 0x040073D6 RID: 29654
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0;

		// Token: 0x040073D7 RID: 29655
		private static readonly IntPtr NativeMethodInfoPtr_SubmitRequest_Private_Void_String_String_Single_Single_Single_Single_0;

		// Token: 0x040073D8 RID: 29656
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentFeedback_Public_Virtual_Final_New_ArrayOf_Int32_PositionType_0;

		// Token: 0x040073D9 RID: 29657
		private static readonly IntPtr NativeMethodInfoPtr_GetDevices_Public_List_1_HapticDevice_0;

		// Token: 0x040073DA RID: 29658
		private static readonly IntPtr NativeMethodInfoPtr_TogglePosition_Public_Void_String_0;

		// Token: 0x040073DB RID: 29659
		private static readonly IntPtr NativeMethodInfoPtr_PingAll_Public_Void_0;

		// Token: 0x040073DC RID: 29660
		private static readonly IntPtr NativeMethodInfoPtr_Ping_Public_Void_String_0;

		// Token: 0x040073DD RID: 29661
		private static readonly IntPtr NativeMethodInfoPtr_ShowBluetoothSetting_Public_Void_0;

		// Token: 0x040073DE RID: 29662
		private static readonly IntPtr NativeMethodInfoPtr_EnableDevice_Public_Void_String_Boolean_0;

		// Token: 0x040073DF RID: 29663
		private static readonly IntPtr NativeMethodInfoPtr_RefreshPairingInfo_Public_Void_0;

		// Token: 0x040073E0 RID: 29664
		private static readonly IntPtr NativeMethodInfoPtr_CallNativeVoidMethod_Private_Void_IntPtr_ArrayOf_Object_0;

		// Token: 0x040073E1 RID: 29665
		private static readonly IntPtr NativeMethodInfoPtr_CallNativeBoolMethod_Private_Boolean_IntPtr_ArrayOf_Object_0;
	}
}
