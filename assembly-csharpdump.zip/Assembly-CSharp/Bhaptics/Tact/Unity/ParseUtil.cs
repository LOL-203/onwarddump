﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B4 RID: 2228
	public class ParseUtil : Object
	{
		// Token: 0x0600B693 RID: 46739 RVA: 0x002EB2A4 File Offset: 0x002E94A4
		[CallerCount(0)]
		public unsafe static float GetFloat(JSONObject obj, string key, [Optional] float defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ParseUtil.NativeMethodInfoPtr_GetFloat_Internal_Static_Single_JSONObject_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600B694 RID: 46740 RVA: 0x002EB328 File Offset: 0x002E9528
		[CallerCount(0)]
		public unsafe static int GetInt(JSONObject obj, string key, [Optional] int defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ParseUtil.NativeMethodInfoPtr_GetInt_Internal_Static_Int32_JSONObject_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600B695 RID: 46741 RVA: 0x002EB3AC File Offset: 0x002E95AC
		[CallerCount(0)]
		public unsafe ParseUtil() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ParseUtil.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B696 RID: 46742 RVA: 0x002EB3F8 File Offset: 0x002E95F8
		// Note: this type is marked as 'beforefieldinit'.
		static ParseUtil()
		{
			Il2CppClassPointerStore<ParseUtil>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "ParseUtil");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr);
			ParseUtil.NativeMethodInfoPtr_GetFloat_Internal_Static_Single_JSONObject_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr, 100678136);
			ParseUtil.NativeMethodInfoPtr_GetInt_Internal_Static_Int32_JSONObject_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr, 100678137);
			ParseUtil.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr, 100678138);
		}

		// Token: 0x0600B697 RID: 46743 RVA: 0x00002988 File Offset: 0x00000B88
		public ParseUtil(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700411F RID: 16671
		// (get) Token: 0x0600B698 RID: 46744 RVA: 0x002EB464 File Offset: 0x002E9664
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ParseUtil>.NativeClassPtr));
			}
		}

		// Token: 0x040074F8 RID: 29944
		private static readonly IntPtr NativeMethodInfoPtr_GetFloat_Internal_Static_Single_JSONObject_String_Single_0;

		// Token: 0x040074F9 RID: 29945
		private static readonly IntPtr NativeMethodInfoPtr_GetInt_Internal_Static_Int32_JSONObject_String_Int32_0;

		// Token: 0x040074FA RID: 29946
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
