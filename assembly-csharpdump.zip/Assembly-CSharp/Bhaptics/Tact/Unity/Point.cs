﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008C7 RID: 2247
	[Serializable]
	public class Point : Object
	{
		// Token: 0x0600B78C RID: 46988 RVA: 0x002EFAAC File Offset: 0x002EDCAC
		[CallerCount(0)]
		public unsafe Point(float x, float y, int intensity) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Point>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensity;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Point.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B78D RID: 46989 RVA: 0x002EFB30 File Offset: 0x002EDD30
		// Note: this type is marked as 'beforefieldinit'.
		static Point()
		{
			Il2CppClassPointerStore<Point>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "Point");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Point>.NativeClassPtr);
			Point.NativeFieldInfoPtr_X = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Point>.NativeClassPtr, "X");
			Point.NativeFieldInfoPtr_Y = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Point>.NativeClassPtr, "Y");
			Point.NativeFieldInfoPtr_Intensity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Point>.NativeClassPtr, "Intensity");
			Point.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Point>.NativeClassPtr, 100678241);
		}

		// Token: 0x0600B78E RID: 46990 RVA: 0x00002988 File Offset: 0x00000B88
		public Point(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004164 RID: 16740
		// (get) Token: 0x0600B78F RID: 46991 RVA: 0x002EFBB0 File Offset: 0x002EDDB0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Point>.NativeClassPtr));
			}
		}

		// Token: 0x17004165 RID: 16741
		// (get) Token: 0x0600B790 RID: 46992 RVA: 0x002EFBC4 File Offset: 0x002EDDC4
		// (set) Token: 0x0600B791 RID: 46993 RVA: 0x002EFBEC File Offset: 0x002EDDEC
		public unsafe float X
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_X);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_X)) = value;
			}
		}

		// Token: 0x17004166 RID: 16742
		// (get) Token: 0x0600B792 RID: 46994 RVA: 0x002EFC10 File Offset: 0x002EDE10
		// (set) Token: 0x0600B793 RID: 46995 RVA: 0x002EFC38 File Offset: 0x002EDE38
		public unsafe float Y
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_Y);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_Y)) = value;
			}
		}

		// Token: 0x17004167 RID: 16743
		// (get) Token: 0x0600B794 RID: 46996 RVA: 0x002EFC5C File Offset: 0x002EDE5C
		// (set) Token: 0x0600B795 RID: 46997 RVA: 0x002EFC84 File Offset: 0x002EDE84
		public unsafe int Intensity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_Intensity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Point.NativeFieldInfoPtr_Intensity)) = value;
			}
		}

		// Token: 0x040075AA RID: 30122
		private static readonly IntPtr NativeFieldInfoPtr_X;

		// Token: 0x040075AB RID: 30123
		private static readonly IntPtr NativeFieldInfoPtr_Y;

		// Token: 0x040075AC RID: 30124
		private static readonly IntPtr NativeFieldInfoPtr_Intensity;

		// Token: 0x040075AD RID: 30125
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Int32_0;
	}
}
