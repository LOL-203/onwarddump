﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B9 RID: 2233
	public class GloveHapticClip : ArmsHapticClip
	{
		// Token: 0x0600B6DB RID: 46811 RVA: 0x002EC63C File Offset: 0x002EA83C
		[CallerCount(0)]
		public unsafe GloveHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<GloveHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(GloveHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6DC RID: 46812 RVA: 0x002EC687 File Offset: 0x002EA887
		// Note: this type is marked as 'beforefieldinit'.
		static GloveHapticClip()
		{
			Il2CppClassPointerStore<GloveHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "GloveHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<GloveHapticClip>.NativeClassPtr);
			GloveHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<GloveHapticClip>.NativeClassPtr, 100678163);
		}

		// Token: 0x0600B6DD RID: 46813 RVA: 0x002EBD64 File Offset: 0x002E9F64
		public GloveHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004134 RID: 16692
		// (get) Token: 0x0600B6DE RID: 46814 RVA: 0x002EC6C0 File Offset: 0x002EA8C0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<GloveHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x04007524 RID: 29988
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
