﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A8 RID: 2216
	public class HapticFeedbackFile : Object
	{
		// Token: 0x0600B5DE RID: 46558 RVA: 0x002E8004 File Offset: 0x002E6204
		[CallerCount(0)]
		public unsafe static HapticFeedbackFile ToHapticFeedbackFile(string jsonStr)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(jsonStr);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticFeedbackFile.NativeMethodInfoPtr_ToHapticFeedbackFile_Public_Static_HapticFeedbackFile_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HapticFeedbackFile(intPtr2) : null;
		}

		// Token: 0x0600B5DF RID: 46559 RVA: 0x002E8064 File Offset: 0x002E6264
		[CallerCount(0)]
		public unsafe HapticFeedbackFile() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticFeedbackFile.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B5E0 RID: 46560 RVA: 0x002E80B0 File Offset: 0x002E62B0
		// Note: this type is marked as 'beforefieldinit'.
		static HapticFeedbackFile()
		{
			Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticFeedbackFile");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr);
			HapticFeedbackFile.NativeFieldInfoPtr_Project = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr, "Project");
			HapticFeedbackFile.NativeMethodInfoPtr_ToHapticFeedbackFile_Public_Static_HapticFeedbackFile_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr, 100678049);
			HapticFeedbackFile.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr, 100678050);
		}

		// Token: 0x0600B5E1 RID: 46561 RVA: 0x00002988 File Offset: 0x00000B88
		public HapticFeedbackFile(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040DD RID: 16605
		// (get) Token: 0x0600B5E2 RID: 46562 RVA: 0x002E811C File Offset: 0x002E631C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticFeedbackFile>.NativeClassPtr));
			}
		}

		// Token: 0x170040DE RID: 16606
		// (get) Token: 0x0600B5E3 RID: 46563 RVA: 0x002E8130 File Offset: 0x002E6330
		// (set) Token: 0x0600B5E4 RID: 46564 RVA: 0x002E8164 File Offset: 0x002E6364
		public unsafe BhapticsProject Project
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticFeedbackFile.NativeFieldInfoPtr_Project);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BhapticsProject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticFeedbackFile.NativeFieldInfoPtr_Project), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007484 RID: 29828
		private static readonly IntPtr NativeFieldInfoPtr_Project;

		// Token: 0x04007485 RID: 29829
		private static readonly IntPtr NativeMethodInfoPtr_ToHapticFeedbackFile_Public_Static_HapticFeedbackFile_String_0;

		// Token: 0x04007486 RID: 29830
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
