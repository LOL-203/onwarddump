﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B2 RID: 2226
	public class PathModeObjectCollection : Object
	{
		// Token: 0x17004115 RID: 16661
		// (get) Token: 0x0600B66F RID: 46703 RVA: 0x002EA8E0 File Offset: 0x002E8AE0
		// (set) Token: 0x0600B670 RID: 46704 RVA: 0x002EA938 File Offset: 0x002E8B38
		public unsafe Il2CppReferenceArray<PathModeObject> PointList
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObjectCollection.NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_PathModeObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<PathModeObject>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObjectCollection.NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_PathModeObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600B671 RID: 46705 RVA: 0x002EA994 File Offset: 0x002E8B94
		[CallerCount(0)]
		public unsafe static PathModeObjectCollection ToObject(JSONObject jsonObject)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(jsonObject);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObjectCollection.NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObjectCollection_JSONObject_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new PathModeObjectCollection(intPtr2) : null;
		}

		// Token: 0x0600B672 RID: 46706 RVA: 0x002EA9F4 File Offset: 0x002E8BF4
		[CallerCount(0)]
		public unsafe JSONObject ToJsonObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObjectCollection.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new JSONObject(intPtr2) : null;
		}

		// Token: 0x0600B673 RID: 46707 RVA: 0x002EAA4C File Offset: 0x002E8C4C
		[CallerCount(0)]
		public unsafe PathModeObjectCollection() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathModeObjectCollection.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B674 RID: 46708 RVA: 0x002EAA98 File Offset: 0x002E8C98
		// Note: this type is marked as 'beforefieldinit'.
		static PathModeObjectCollection()
		{
			Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "PathModeObjectCollection");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr);
			PathModeObjectCollection.NativeFieldInfoPtr_PlaybackType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, "PlaybackType");
			PathModeObjectCollection.NativeFieldInfoPtr_MovingPattern = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, "MovingPattern");
			PathModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, "<PointList>k__BackingField");
			PathModeObjectCollection.NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_PathModeObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, 100678120);
			PathModeObjectCollection.NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_PathModeObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, 100678121);
			PathModeObjectCollection.NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObjectCollection_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, 100678122);
			PathModeObjectCollection.NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, 100678123);
			PathModeObjectCollection.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr, 100678124);
		}

		// Token: 0x0600B675 RID: 46709 RVA: 0x00002988 File Offset: 0x00000B88
		public PathModeObjectCollection(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004111 RID: 16657
		// (get) Token: 0x0600B676 RID: 46710 RVA: 0x002EAB68 File Offset: 0x002E8D68
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PathModeObjectCollection>.NativeClassPtr));
			}
		}

		// Token: 0x17004112 RID: 16658
		// (get) Token: 0x0600B677 RID: 46711 RVA: 0x002EAB7C File Offset: 0x002E8D7C
		// (set) Token: 0x0600B678 RID: 46712 RVA: 0x002EABA4 File Offset: 0x002E8DA4
		public unsafe PlaybackType PlaybackType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr_PlaybackType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr_PlaybackType)) = value;
			}
		}

		// Token: 0x17004113 RID: 16659
		// (get) Token: 0x0600B679 RID: 46713 RVA: 0x002EABC8 File Offset: 0x002E8DC8
		// (set) Token: 0x0600B67A RID: 46714 RVA: 0x002EABF0 File Offset: 0x002E8DF0
		public unsafe PathMovingPattern MovingPattern
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr_MovingPattern);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr_MovingPattern)) = value;
			}
		}

		// Token: 0x17004114 RID: 16660
		// (get) Token: 0x0600B67B RID: 46715 RVA: 0x002EAC14 File Offset: 0x002E8E14
		// (set) Token: 0x0600B67C RID: 46716 RVA: 0x002EAC48 File Offset: 0x002E8E48
		public unsafe Il2CppReferenceArray<PathModeObject> _PointList_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<PathModeObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathModeObjectCollection.NativeFieldInfoPtr__PointList_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040074E1 RID: 29921
		private static readonly IntPtr NativeFieldInfoPtr_PlaybackType;

		// Token: 0x040074E2 RID: 29922
		private static readonly IntPtr NativeFieldInfoPtr_MovingPattern;

		// Token: 0x040074E3 RID: 29923
		private static readonly IntPtr NativeFieldInfoPtr__PointList_k__BackingField;

		// Token: 0x040074E4 RID: 29924
		private static readonly IntPtr NativeMethodInfoPtr_get_PointList_Public_get_ArrayOf_PathModeObject_0;

		// Token: 0x040074E5 RID: 29925
		private static readonly IntPtr NativeMethodInfoPtr_set_PointList_Public_set_Void_ArrayOf_PathModeObject_0;

		// Token: 0x040074E6 RID: 29926
		private static readonly IntPtr NativeMethodInfoPtr_ToObject_Internal_Static_PathModeObjectCollection_JSONObject_0;

		// Token: 0x040074E7 RID: 29927
		private static readonly IntPtr NativeMethodInfoPtr_ToJsonObject_Internal_JSONObject_0;

		// Token: 0x040074E8 RID: 29928
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
