﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x0200089A RID: 2202
	[Serializable]
	public class HapticDevice : Object
	{
		// Token: 0x0600B4CB RID: 46283 RVA: 0x002E3A3C File Offset: 0x002E1C3C
		[CallerCount(0)]
		public unsafe HapticDevice() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HapticDevice.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B4CC RID: 46284 RVA: 0x002E3A88 File Offset: 0x002E1C88
		// Note: this type is marked as 'beforefieldinit'.
		static HapticDevice()
		{
			Il2CppClassPointerStore<HapticDevice>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "HapticDevice");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr);
			HapticDevice.NativeFieldInfoPtr_IsPaired = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "IsPaired");
			HapticDevice.NativeFieldInfoPtr_IsConnected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "IsConnected");
			HapticDevice.NativeFieldInfoPtr_DeviceName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "DeviceName");
			HapticDevice.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "Position");
			HapticDevice.NativeFieldInfoPtr_Address = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "Address");
			HapticDevice.NativeFieldInfoPtr_Candidates = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "Candidates");
			HapticDevice.NativeFieldInfoPtr_IsEnable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "IsEnable");
			HapticDevice.NativeFieldInfoPtr_IsAudioJack = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "IsAudioJack");
			HapticDevice.NativeFieldInfoPtr_Battery = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, "Battery");
			HapticDevice.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr, 100677960);
		}

		// Token: 0x0600B4CD RID: 46285 RVA: 0x00002988 File Offset: 0x00000B88
		public HapticDevice(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004084 RID: 16516
		// (get) Token: 0x0600B4CE RID: 46286 RVA: 0x002E3B80 File Offset: 0x002E1D80
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HapticDevice>.NativeClassPtr));
			}
		}

		// Token: 0x17004085 RID: 16517
		// (get) Token: 0x0600B4CF RID: 46287 RVA: 0x002E3B94 File Offset: 0x002E1D94
		// (set) Token: 0x0600B4D0 RID: 46288 RVA: 0x002E3BBC File Offset: 0x002E1DBC
		public unsafe bool IsPaired
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsPaired);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsPaired)) = value;
			}
		}

		// Token: 0x17004086 RID: 16518
		// (get) Token: 0x0600B4D1 RID: 46289 RVA: 0x002E3BE0 File Offset: 0x002E1DE0
		// (set) Token: 0x0600B4D2 RID: 46290 RVA: 0x002E3C08 File Offset: 0x002E1E08
		public unsafe bool IsConnected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsConnected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsConnected)) = value;
			}
		}

		// Token: 0x17004087 RID: 16519
		// (get) Token: 0x0600B4D3 RID: 46291 RVA: 0x002E3C2C File Offset: 0x002E1E2C
		// (set) Token: 0x0600B4D4 RID: 46292 RVA: 0x002E3C55 File Offset: 0x002E1E55
		public unsafe string DeviceName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_DeviceName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_DeviceName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004088 RID: 16520
		// (get) Token: 0x0600B4D5 RID: 46293 RVA: 0x002E3C7C File Offset: 0x002E1E7C
		// (set) Token: 0x0600B4D6 RID: 46294 RVA: 0x002E3CA4 File Offset: 0x002E1EA4
		public unsafe PositionType Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x17004089 RID: 16521
		// (get) Token: 0x0600B4D7 RID: 46295 RVA: 0x002E3CC8 File Offset: 0x002E1EC8
		// (set) Token: 0x0600B4D8 RID: 46296 RVA: 0x002E3CF1 File Offset: 0x002E1EF1
		public unsafe string Address
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Address);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Address), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700408A RID: 16522
		// (get) Token: 0x0600B4D9 RID: 46297 RVA: 0x002E3D18 File Offset: 0x002E1F18
		// (set) Token: 0x0600B4DA RID: 46298 RVA: 0x002E3D4C File Offset: 0x002E1F4C
		public unsafe Il2CppStructArray<PositionType> Candidates
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Candidates);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<PositionType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Candidates), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700408B RID: 16523
		// (get) Token: 0x0600B4DB RID: 46299 RVA: 0x002E3D74 File Offset: 0x002E1F74
		// (set) Token: 0x0600B4DC RID: 46300 RVA: 0x002E3D9C File Offset: 0x002E1F9C
		public unsafe bool IsEnable
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsEnable);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsEnable)) = value;
			}
		}

		// Token: 0x1700408C RID: 16524
		// (get) Token: 0x0600B4DD RID: 46301 RVA: 0x002E3DC0 File Offset: 0x002E1FC0
		// (set) Token: 0x0600B4DE RID: 46302 RVA: 0x002E3DE8 File Offset: 0x002E1FE8
		public unsafe bool IsAudioJack
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsAudioJack);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_IsAudioJack)) = value;
			}
		}

		// Token: 0x1700408D RID: 16525
		// (get) Token: 0x0600B4DF RID: 46303 RVA: 0x002E3E0C File Offset: 0x002E200C
		// (set) Token: 0x0600B4E0 RID: 46304 RVA: 0x002E3E34 File Offset: 0x002E2034
		public unsafe int Battery
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Battery);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HapticDevice.NativeFieldInfoPtr_Battery)) = value;
			}
		}

		// Token: 0x040073E2 RID: 29666
		private static readonly IntPtr NativeFieldInfoPtr_IsPaired;

		// Token: 0x040073E3 RID: 29667
		private static readonly IntPtr NativeFieldInfoPtr_IsConnected;

		// Token: 0x040073E4 RID: 29668
		private static readonly IntPtr NativeFieldInfoPtr_DeviceName;

		// Token: 0x040073E5 RID: 29669
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x040073E6 RID: 29670
		private static readonly IntPtr NativeFieldInfoPtr_Address;

		// Token: 0x040073E7 RID: 29671
		private static readonly IntPtr NativeFieldInfoPtr_Candidates;

		// Token: 0x040073E8 RID: 29672
		private static readonly IntPtr NativeFieldInfoPtr_IsEnable;

		// Token: 0x040073E9 RID: 29673
		private static readonly IntPtr NativeFieldInfoPtr_IsAudioJack;

		// Token: 0x040073EA RID: 29674
		private static readonly IntPtr NativeFieldInfoPtr_Battery;

		// Token: 0x040073EB RID: 29675
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
