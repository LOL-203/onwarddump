﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008A3 RID: 2211
	public class Android_UIController : MonoBehaviour
	{
		// Token: 0x0600B55A RID: 46426 RVA: 0x002E5AC4 File Offset: 0x002E3CC4
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B55B RID: 46427 RVA: 0x002E5B08 File Offset: 0x002E3D08
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B55C RID: 46428 RVA: 0x002E5B4C File Offset: 0x002E3D4C
		[CallerCount(0)]
		public unsafe void Refresh()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_Refresh_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B55D RID: 46429 RVA: 0x002E5B90 File Offset: 0x002E3D90
		[CallerCount(0)]
		public unsafe void OnHelp()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_OnHelp_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B55E RID: 46430 RVA: 0x002E5BD4 File Offset: 0x002E3DD4
		[CallerCount(0)]
		public unsafe void CloseHelpNotification()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_CloseHelpNotification_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B55F RID: 46431 RVA: 0x002E5C18 File Offset: 0x002E3E18
		[CallerCount(0)]
		public unsafe void OpenLink()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_OpenLink_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B560 RID: 46432 RVA: 0x002E5C5C File Offset: 0x002E3E5C
		[CallerCount(0)]
		public unsafe void NextPage()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_NextPage_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B561 RID: 46433 RVA: 0x002E5CA0 File Offset: 0x002E3EA0
		[CallerCount(0)]
		public unsafe void BackPage()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr_BackPage_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B562 RID: 46434 RVA: 0x002E5CE4 File Offset: 0x002E3EE4
		[CallerCount(0)]
		public unsafe Android_UIController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Android_UIController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B563 RID: 46435 RVA: 0x002E5D30 File Offset: 0x002E3F30
		// Note: this type is marked as 'beforefieldinit'.
		static Android_UIController()
		{
			Il2CppClassPointerStore<Android_UIController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "Android_UIController");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr);
			Android_UIController.NativeFieldInfoPtr_mainPanel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "mainPanel");
			Android_UIController.NativeFieldInfoPtr_devicesContainer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "devicesContainer");
			Android_UIController.NativeFieldInfoPtr_deviceListPageUi = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListPageUi");
			Android_UIController.NativeFieldInfoPtr_deviceListNextPageButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListNextPageButton");
			Android_UIController.NativeFieldInfoPtr_deviceListBackPageButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListBackPageButton");
			Android_UIController.NativeFieldInfoPtr_deviceListPageText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListPageText");
			Android_UIController.NativeFieldInfoPtr_devicePrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "devicePrefab");
			Android_UIController.NativeFieldInfoPtr_noPairedDeviceUi = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "noPairedDeviceUi");
			Android_UIController.NativeFieldInfoPtr_helpButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "helpButton");
			Android_UIController.NativeFieldInfoPtr_bHpaticsLinkButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "bHpaticsLinkButton");
			Android_UIController.NativeFieldInfoPtr_helpUi = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "helpUi");
			Android_UIController.NativeFieldInfoPtr_helpCloseButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "helpCloseButton");
			Android_UIController.NativeFieldInfoPtr_controllers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "controllers");
			Android_UIController.NativeFieldInfoPtr_mainPanelCollider = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "mainPanelCollider");
			Android_UIController.NativeFieldInfoPtr_defaultMainPanelSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "defaultMainPanelSize");
			Android_UIController.NativeFieldInfoPtr_defaultDeviceContainerSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "defaultDeviceContainerSize");
			Android_UIController.NativeFieldInfoPtr_deviceListSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListSize");
			Android_UIController.NativeFieldInfoPtr_deviceListPageIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "deviceListPageIndex");
			Android_UIController.NativeFieldInfoPtr_expandHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "expandHeight");
			Android_UIController.NativeFieldInfoPtr_expandDeviceCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "expandDeviceCount");
			Android_UIController.NativeFieldInfoPtr_pageActivateDeviceCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "pageActivateDeviceCount");
			Android_UIController.NativeFieldInfoPtr_pageExpandHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "pageExpandHeight");
			Android_UIController.NativeFieldInfoPtr_maxPageIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, "maxPageIndex");
			Android_UIController.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677991);
			Android_UIController.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677992);
			Android_UIController.NativeMethodInfoPtr_Refresh_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677993);
			Android_UIController.NativeMethodInfoPtr_OnHelp_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677994);
			Android_UIController.NativeMethodInfoPtr_CloseHelpNotification_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677995);
			Android_UIController.NativeMethodInfoPtr_OpenLink_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677996);
			Android_UIController.NativeMethodInfoPtr_NextPage_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677997);
			Android_UIController.NativeMethodInfoPtr_BackPage_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677998);
			Android_UIController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr, 100677999);
		}

		// Token: 0x0600B564 RID: 46436 RVA: 0x0000210C File Offset: 0x0000030C
		public Android_UIController(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170040B8 RID: 16568
		// (get) Token: 0x0600B565 RID: 46437 RVA: 0x002E5FE0 File Offset: 0x002E41E0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Android_UIController>.NativeClassPtr));
			}
		}

		// Token: 0x170040B9 RID: 16569
		// (get) Token: 0x0600B566 RID: 46438 RVA: 0x002E5FF4 File Offset: 0x002E41F4
		// (set) Token: 0x0600B567 RID: 46439 RVA: 0x002E6028 File Offset: 0x002E4228
		public unsafe RectTransform mainPanel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_mainPanel);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_mainPanel), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BA RID: 16570
		// (get) Token: 0x0600B568 RID: 46440 RVA: 0x002E6050 File Offset: 0x002E4250
		// (set) Token: 0x0600B569 RID: 46441 RVA: 0x002E6084 File Offset: 0x002E4284
		public unsafe Transform devicesContainer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_devicesContainer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_devicesContainer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BB RID: 16571
		// (get) Token: 0x0600B56A RID: 46442 RVA: 0x002E60AC File Offset: 0x002E42AC
		// (set) Token: 0x0600B56B RID: 46443 RVA: 0x002E60E0 File Offset: 0x002E42E0
		public unsafe Transform deviceListPageUi
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageUi);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageUi), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BC RID: 16572
		// (get) Token: 0x0600B56C RID: 46444 RVA: 0x002E6108 File Offset: 0x002E4308
		// (set) Token: 0x0600B56D RID: 46445 RVA: 0x002E613C File Offset: 0x002E433C
		public unsafe Button deviceListNextPageButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListNextPageButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListNextPageButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BD RID: 16573
		// (get) Token: 0x0600B56E RID: 46446 RVA: 0x002E6164 File Offset: 0x002E4364
		// (set) Token: 0x0600B56F RID: 46447 RVA: 0x002E6198 File Offset: 0x002E4398
		public unsafe Button deviceListBackPageButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListBackPageButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListBackPageButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BE RID: 16574
		// (get) Token: 0x0600B570 RID: 46448 RVA: 0x002E61C0 File Offset: 0x002E43C0
		// (set) Token: 0x0600B571 RID: 46449 RVA: 0x002E61F4 File Offset: 0x002E43F4
		public unsafe Text deviceListPageText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Text(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040BF RID: 16575
		// (get) Token: 0x0600B572 RID: 46450 RVA: 0x002E621C File Offset: 0x002E441C
		// (set) Token: 0x0600B573 RID: 46451 RVA: 0x002E6250 File Offset: 0x002E4450
		public unsafe Android_DeviceController devicePrefab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_devicePrefab);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Android_DeviceController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_devicePrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C0 RID: 16576
		// (get) Token: 0x0600B574 RID: 46452 RVA: 0x002E6278 File Offset: 0x002E4478
		// (set) Token: 0x0600B575 RID: 46453 RVA: 0x002E62AC File Offset: 0x002E44AC
		public unsafe GameObject noPairedDeviceUi
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_noPairedDeviceUi);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_noPairedDeviceUi), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C1 RID: 16577
		// (get) Token: 0x0600B576 RID: 46454 RVA: 0x002E62D4 File Offset: 0x002E44D4
		// (set) Token: 0x0600B577 RID: 46455 RVA: 0x002E6308 File Offset: 0x002E4508
		public unsafe Button helpButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C2 RID: 16578
		// (get) Token: 0x0600B578 RID: 46456 RVA: 0x002E6330 File Offset: 0x002E4530
		// (set) Token: 0x0600B579 RID: 46457 RVA: 0x002E6364 File Offset: 0x002E4564
		public unsafe Button bHpaticsLinkButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_bHpaticsLinkButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_bHpaticsLinkButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C3 RID: 16579
		// (get) Token: 0x0600B57A RID: 46458 RVA: 0x002E638C File Offset: 0x002E458C
		// (set) Token: 0x0600B57B RID: 46459 RVA: 0x002E63C0 File Offset: 0x002E45C0
		public unsafe GameObject helpUi
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpUi);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpUi), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C4 RID: 16580
		// (get) Token: 0x0600B57C RID: 46460 RVA: 0x002E63E8 File Offset: 0x002E45E8
		// (set) Token: 0x0600B57D RID: 46461 RVA: 0x002E641C File Offset: 0x002E461C
		public unsafe Button helpCloseButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpCloseButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_helpCloseButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C5 RID: 16581
		// (get) Token: 0x0600B57E RID: 46462 RVA: 0x002E6444 File Offset: 0x002E4644
		// (set) Token: 0x0600B57F RID: 46463 RVA: 0x002E6478 File Offset: 0x002E4678
		public unsafe List<Android_DeviceController> controllers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_controllers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Android_DeviceController>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_controllers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C6 RID: 16582
		// (get) Token: 0x0600B580 RID: 46464 RVA: 0x002E64A0 File Offset: 0x002E46A0
		// (set) Token: 0x0600B581 RID: 46465 RVA: 0x002E64D4 File Offset: 0x002E46D4
		public unsafe BoxCollider mainPanelCollider
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_mainPanelCollider);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BoxCollider(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_mainPanelCollider), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170040C7 RID: 16583
		// (get) Token: 0x0600B582 RID: 46466 RVA: 0x002E64FC File Offset: 0x002E46FC
		// (set) Token: 0x0600B583 RID: 46467 RVA: 0x002E6524 File Offset: 0x002E4724
		public unsafe Vector2 defaultMainPanelSize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_defaultMainPanelSize);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_defaultMainPanelSize)) = value;
			}
		}

		// Token: 0x170040C8 RID: 16584
		// (get) Token: 0x0600B584 RID: 46468 RVA: 0x002E6548 File Offset: 0x002E4748
		// (set) Token: 0x0600B585 RID: 46469 RVA: 0x002E6570 File Offset: 0x002E4770
		public unsafe Vector2 defaultDeviceContainerSize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_defaultDeviceContainerSize);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_defaultDeviceContainerSize)) = value;
			}
		}

		// Token: 0x170040C9 RID: 16585
		// (get) Token: 0x0600B586 RID: 46470 RVA: 0x002E6594 File Offset: 0x002E4794
		// (set) Token: 0x0600B587 RID: 46471 RVA: 0x002E65BC File Offset: 0x002E47BC
		public unsafe int deviceListSize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListSize);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListSize)) = value;
			}
		}

		// Token: 0x170040CA RID: 16586
		// (get) Token: 0x0600B588 RID: 46472 RVA: 0x002E65E0 File Offset: 0x002E47E0
		// (set) Token: 0x0600B589 RID: 46473 RVA: 0x002E6608 File Offset: 0x002E4808
		public unsafe int deviceListPageIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_deviceListPageIndex)) = value;
			}
		}

		// Token: 0x170040CB RID: 16587
		// (get) Token: 0x0600B58A RID: 46474 RVA: 0x002E662C File Offset: 0x002E482C
		// (set) Token: 0x0600B58B RID: 46475 RVA: 0x002E6654 File Offset: 0x002E4854
		public unsafe int expandHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_expandHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_expandHeight)) = value;
			}
		}

		// Token: 0x170040CC RID: 16588
		// (get) Token: 0x0600B58C RID: 46476 RVA: 0x002E6678 File Offset: 0x002E4878
		// (set) Token: 0x0600B58D RID: 46477 RVA: 0x002E66A0 File Offset: 0x002E48A0
		public unsafe int expandDeviceCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_expandDeviceCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_expandDeviceCount)) = value;
			}
		}

		// Token: 0x170040CD RID: 16589
		// (get) Token: 0x0600B58E RID: 46478 RVA: 0x002E66C4 File Offset: 0x002E48C4
		// (set) Token: 0x0600B58F RID: 46479 RVA: 0x002E66EC File Offset: 0x002E48EC
		public unsafe int pageActivateDeviceCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_pageActivateDeviceCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_pageActivateDeviceCount)) = value;
			}
		}

		// Token: 0x170040CE RID: 16590
		// (get) Token: 0x0600B590 RID: 46480 RVA: 0x002E6710 File Offset: 0x002E4910
		// (set) Token: 0x0600B591 RID: 46481 RVA: 0x002E6738 File Offset: 0x002E4938
		public unsafe int pageExpandHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_pageExpandHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_pageExpandHeight)) = value;
			}
		}

		// Token: 0x170040CF RID: 16591
		// (get) Token: 0x0600B592 RID: 46482 RVA: 0x002E675C File Offset: 0x002E495C
		// (set) Token: 0x0600B593 RID: 46483 RVA: 0x002E6784 File Offset: 0x002E4984
		public unsafe int maxPageIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_maxPageIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Android_UIController.NativeFieldInfoPtr_maxPageIndex)) = value;
			}
		}

		// Token: 0x0400742D RID: 29741
		private static readonly IntPtr NativeFieldInfoPtr_mainPanel;

		// Token: 0x0400742E RID: 29742
		private static readonly IntPtr NativeFieldInfoPtr_devicesContainer;

		// Token: 0x0400742F RID: 29743
		private static readonly IntPtr NativeFieldInfoPtr_deviceListPageUi;

		// Token: 0x04007430 RID: 29744
		private static readonly IntPtr NativeFieldInfoPtr_deviceListNextPageButton;

		// Token: 0x04007431 RID: 29745
		private static readonly IntPtr NativeFieldInfoPtr_deviceListBackPageButton;

		// Token: 0x04007432 RID: 29746
		private static readonly IntPtr NativeFieldInfoPtr_deviceListPageText;

		// Token: 0x04007433 RID: 29747
		private static readonly IntPtr NativeFieldInfoPtr_devicePrefab;

		// Token: 0x04007434 RID: 29748
		private static readonly IntPtr NativeFieldInfoPtr_noPairedDeviceUi;

		// Token: 0x04007435 RID: 29749
		private static readonly IntPtr NativeFieldInfoPtr_helpButton;

		// Token: 0x04007436 RID: 29750
		private static readonly IntPtr NativeFieldInfoPtr_bHpaticsLinkButton;

		// Token: 0x04007437 RID: 29751
		private static readonly IntPtr NativeFieldInfoPtr_helpUi;

		// Token: 0x04007438 RID: 29752
		private static readonly IntPtr NativeFieldInfoPtr_helpCloseButton;

		// Token: 0x04007439 RID: 29753
		private static readonly IntPtr NativeFieldInfoPtr_controllers;

		// Token: 0x0400743A RID: 29754
		private static readonly IntPtr NativeFieldInfoPtr_mainPanelCollider;

		// Token: 0x0400743B RID: 29755
		private static readonly IntPtr NativeFieldInfoPtr_defaultMainPanelSize;

		// Token: 0x0400743C RID: 29756
		private static readonly IntPtr NativeFieldInfoPtr_defaultDeviceContainerSize;

		// Token: 0x0400743D RID: 29757
		private static readonly IntPtr NativeFieldInfoPtr_deviceListSize;

		// Token: 0x0400743E RID: 29758
		private static readonly IntPtr NativeFieldInfoPtr_deviceListPageIndex;

		// Token: 0x0400743F RID: 29759
		private static readonly IntPtr NativeFieldInfoPtr_expandHeight;

		// Token: 0x04007440 RID: 29760
		private static readonly IntPtr NativeFieldInfoPtr_expandDeviceCount;

		// Token: 0x04007441 RID: 29761
		private static readonly IntPtr NativeFieldInfoPtr_pageActivateDeviceCount;

		// Token: 0x04007442 RID: 29762
		private static readonly IntPtr NativeFieldInfoPtr_pageExpandHeight;

		// Token: 0x04007443 RID: 29763
		private static readonly IntPtr NativeFieldInfoPtr_maxPageIndex;

		// Token: 0x04007444 RID: 29764
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x04007445 RID: 29765
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x04007446 RID: 29766
		private static readonly IntPtr NativeMethodInfoPtr_Refresh_Private_Void_0;

		// Token: 0x04007447 RID: 29767
		private static readonly IntPtr NativeMethodInfoPtr_OnHelp_Private_Void_0;

		// Token: 0x04007448 RID: 29768
		private static readonly IntPtr NativeMethodInfoPtr_CloseHelpNotification_Private_Void_0;

		// Token: 0x04007449 RID: 29769
		private static readonly IntPtr NativeMethodInfoPtr_OpenLink_Private_Void_0;

		// Token: 0x0400744A RID: 29770
		private static readonly IntPtr NativeMethodInfoPtr_NextPage_Private_Void_0;

		// Token: 0x0400744B RID: 29771
		private static readonly IntPtr NativeMethodInfoPtr_BackPage_Private_Void_0;

		// Token: 0x0400744C RID: 29772
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
