﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Bhaptics.Tact.Unity
{
	// Token: 0x020008B7 RID: 2231
	public class FeetHapticClip : ArmsHapticClip
	{
		// Token: 0x0600B6BE RID: 46782 RVA: 0x002EBCE0 File Offset: 0x002E9EE0
		[CallerCount(0)]
		public unsafe FeetHapticClip() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<FeetHapticClip>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(FeetHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600B6BF RID: 46783 RVA: 0x002EBD2B File Offset: 0x002E9F2B
		// Note: this type is marked as 'beforefieldinit'.
		static FeetHapticClip()
		{
			Il2CppClassPointerStore<FeetHapticClip>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Bhaptics.Tact.Unity", "FeetHapticClip");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<FeetHapticClip>.NativeClassPtr);
			FeetHapticClip.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FeetHapticClip>.NativeClassPtr, 100678150);
		}

		// Token: 0x0600B6C0 RID: 46784 RVA: 0x002EBD64 File Offset: 0x002E9F64
		public FeetHapticClip(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700412C RID: 16684
		// (get) Token: 0x0600B6C1 RID: 46785 RVA: 0x002EBD6D File Offset: 0x002E9F6D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<FeetHapticClip>.NativeClassPtr));
			}
		}

		// Token: 0x04007512 RID: 29970
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
