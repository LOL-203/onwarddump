﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020001B0 RID: 432
public class DestructibleObject : MonoBehaviour
{
	// Token: 0x06001D83 RID: 7555 RVA: 0x00074D2C File Offset: 0x00072F2C
	[CallerCount(0)]
	public unsafe GameObject SpawnDestroyedObject()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestructibleObject.NativeMethodInfoPtr_SpawnDestroyedObject_Private_GameObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
	}

	// Token: 0x06001D84 RID: 7556 RVA: 0x00074D84 File Offset: 0x00072F84
	[CallerCount(0)]
	public unsafe void SimpleDestroyObject()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestructibleObject.NativeMethodInfoPtr_SimpleDestroyObject_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D85 RID: 7557 RVA: 0x00074DC8 File Offset: 0x00072FC8
	[CallerCount(0)]
	public unsafe GameObject ObjectExplosionImpact(Vector3 point, float force, float radius)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref point;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref force;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref radius;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestructibleObject.NativeMethodInfoPtr_ObjectExplosionImpact_Public_GameObject_Vector3_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
	}

	// Token: 0x06001D86 RID: 7558 RVA: 0x00074E58 File Offset: 0x00073058
	[CallerCount(0)]
	public unsafe void OnCollisionEnter(Collision collision)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(collision);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestructibleObject.NativeMethodInfoPtr_OnCollisionEnter_Public_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D87 RID: 7559 RVA: 0x00074EB4 File Offset: 0x000730B4
	[CallerCount(0)]
	public unsafe DestructibleObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestructibleObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D88 RID: 7560 RVA: 0x00074F00 File Offset: 0x00073100
	// Note: this type is marked as 'beforefieldinit'.
	static DestructibleObject()
	{
		Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DestructibleObject");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr);
		DestructibleObject.NativeFieldInfoPtr__destroyMagnitude = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, "_destroyMagnitude");
		DestructibleObject.NativeFieldInfoPtr__destructiblePrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, "_destructiblePrefab");
		DestructibleObject.NativeFieldInfoPtr__destructionSound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, "_destructionSound");
		DestructibleObject.NativeMethodInfoPtr_SpawnDestroyedObject_Private_GameObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, 100665598);
		DestructibleObject.NativeMethodInfoPtr_SimpleDestroyObject_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, 100665599);
		DestructibleObject.NativeMethodInfoPtr_ObjectExplosionImpact_Public_GameObject_Vector3_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, 100665600);
		DestructibleObject.NativeMethodInfoPtr_OnCollisionEnter_Public_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, 100665601);
		DestructibleObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr, 100665602);
	}

	// Token: 0x06001D89 RID: 7561 RVA: 0x0000210C File Offset: 0x0000030C
	public DestructibleObject(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000A50 RID: 2640
	// (get) Token: 0x06001D8A RID: 7562 RVA: 0x00074FD0 File Offset: 0x000731D0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DestructibleObject>.NativeClassPtr));
		}
	}

	// Token: 0x17000A51 RID: 2641
	// (get) Token: 0x06001D8B RID: 7563 RVA: 0x00074FE4 File Offset: 0x000731E4
	// (set) Token: 0x06001D8C RID: 7564 RVA: 0x0007500C File Offset: 0x0007320C
	public unsafe float _destroyMagnitude
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destroyMagnitude);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destroyMagnitude)) = value;
		}
	}

	// Token: 0x17000A52 RID: 2642
	// (get) Token: 0x06001D8D RID: 7565 RVA: 0x00075030 File Offset: 0x00073230
	// (set) Token: 0x06001D8E RID: 7566 RVA: 0x00075064 File Offset: 0x00073264
	public unsafe GameObject _destructiblePrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destructiblePrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destructiblePrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000A53 RID: 2643
	// (get) Token: 0x06001D8F RID: 7567 RVA: 0x0007508C File Offset: 0x0007328C
	// (set) Token: 0x06001D90 RID: 7568 RVA: 0x000750C0 File Offset: 0x000732C0
	public unsafe AudioClip _destructionSound
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destructionSound);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AudioClip(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DestructibleObject.NativeFieldInfoPtr__destructionSound), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040012D5 RID: 4821
	private static readonly IntPtr NativeFieldInfoPtr__destroyMagnitude;

	// Token: 0x040012D6 RID: 4822
	private static readonly IntPtr NativeFieldInfoPtr__destructiblePrefab;

	// Token: 0x040012D7 RID: 4823
	private static readonly IntPtr NativeFieldInfoPtr__destructionSound;

	// Token: 0x040012D8 RID: 4824
	private static readonly IntPtr NativeMethodInfoPtr_SpawnDestroyedObject_Private_GameObject_0;

	// Token: 0x040012D9 RID: 4825
	private static readonly IntPtr NativeMethodInfoPtr_SimpleDestroyObject_Public_Void_0;

	// Token: 0x040012DA RID: 4826
	private static readonly IntPtr NativeMethodInfoPtr_ObjectExplosionImpact_Public_GameObject_Vector3_Single_Single_0;

	// Token: 0x040012DB RID: 4827
	private static readonly IntPtr NativeMethodInfoPtr_OnCollisionEnter_Public_Void_Collision_0;

	// Token: 0x040012DC RID: 4828
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
