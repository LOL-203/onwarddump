﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C7 RID: 199
public class CaptureTransparentPNG : MonoBehaviour
{
	// Token: 0x06000C6D RID: 3181 RVA: 0x000327C0 File Offset: 0x000309C0
	[CallerCount(0)]
	public unsafe void Capture()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr_Capture_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C6E RID: 3182 RVA: 0x00032804 File Offset: 0x00030A04
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x00032848 File Offset: 0x00030A48
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x0003288C File Offset: 0x00030A8C
	[CallerCount(0)]
	public unsafe static string ScreenShotName(int width, int height)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref width;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref height;
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr_ScreenShotName_Public_Static_String_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x000328F0 File Offset: 0x00030AF0
	[CallerCount(0)]
	public unsafe void LateUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr_LateUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x00032934 File Offset: 0x00030B34
	[CallerCount(0)]
	public unsafe CaptureTransparentPNG() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CaptureTransparentPNG.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C73 RID: 3187 RVA: 0x00032980 File Offset: 0x00030B80
	// Note: this type is marked as 'beforefieldinit'.
	static CaptureTransparentPNG()
	{
		Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CaptureTransparentPNG");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr);
		CaptureTransparentPNG.NativeFieldInfoPtr_CameraToUse = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "CameraToUse");
		CaptureTransparentPNG.NativeFieldInfoPtr_ResWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "ResWidth");
		CaptureTransparentPNG.NativeFieldInfoPtr_ResHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "ResHeight");
		CaptureTransparentPNG.NativeFieldInfoPtr_TakeScreenshot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "TakeScreenshot");
		CaptureTransparentPNG.NativeFieldInfoPtr_ShowScreenshotAfterTake = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "ShowScreenshotAfterTake");
		CaptureTransparentPNG.NativeFieldInfoPtr_Resolution = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "Resolution");
		CaptureTransparentPNG.NativeFieldInfoPtr_PrevResWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "PrevResWidth");
		CaptureTransparentPNG.NativeFieldInfoPtr_PrevResHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "PrevResHeight");
		CaptureTransparentPNG.NativeFieldInfoPtr_RenderTex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "RenderTex");
		CaptureTransparentPNG.NativeFieldInfoPtr_Screenshot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "Screenshot");
		CaptureTransparentPNG.NativeFieldInfoPtr_ScreenshotFunction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, "ScreenshotFunction");
		CaptureTransparentPNG.NativeMethodInfoPtr_Capture_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664263);
		CaptureTransparentPNG.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664264);
		CaptureTransparentPNG.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664265);
		CaptureTransparentPNG.NativeMethodInfoPtr_ScreenShotName_Public_Static_String_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664266);
		CaptureTransparentPNG.NativeMethodInfoPtr_LateUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664267);
		CaptureTransparentPNG.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr, 100664268);
	}

	// Token: 0x06000C74 RID: 3188 RVA: 0x0000210C File Offset: 0x0000030C
	public CaptureTransparentPNG(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000448 RID: 1096
	// (get) Token: 0x06000C75 RID: 3189 RVA: 0x00032B04 File Offset: 0x00030D04
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CaptureTransparentPNG>.NativeClassPtr));
		}
	}

	// Token: 0x17000449 RID: 1097
	// (get) Token: 0x06000C76 RID: 3190 RVA: 0x00032B18 File Offset: 0x00030D18
	// (set) Token: 0x06000C77 RID: 3191 RVA: 0x00032B4C File Offset: 0x00030D4C
	public unsafe Camera CameraToUse
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_CameraToUse);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_CameraToUse), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700044A RID: 1098
	// (get) Token: 0x06000C78 RID: 3192 RVA: 0x00032B74 File Offset: 0x00030D74
	// (set) Token: 0x06000C79 RID: 3193 RVA: 0x00032B9C File Offset: 0x00030D9C
	public unsafe int ResWidth
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ResWidth);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ResWidth)) = value;
		}
	}

	// Token: 0x1700044B RID: 1099
	// (get) Token: 0x06000C7A RID: 3194 RVA: 0x00032BC0 File Offset: 0x00030DC0
	// (set) Token: 0x06000C7B RID: 3195 RVA: 0x00032BE8 File Offset: 0x00030DE8
	public unsafe int ResHeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ResHeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ResHeight)) = value;
		}
	}

	// Token: 0x1700044C RID: 1100
	// (get) Token: 0x06000C7C RID: 3196 RVA: 0x00032C0C File Offset: 0x00030E0C
	// (set) Token: 0x06000C7D RID: 3197 RVA: 0x00032C34 File Offset: 0x00030E34
	public unsafe bool TakeScreenshot
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_TakeScreenshot);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_TakeScreenshot)) = value;
		}
	}

	// Token: 0x1700044D RID: 1101
	// (get) Token: 0x06000C7E RID: 3198 RVA: 0x00032C58 File Offset: 0x00030E58
	// (set) Token: 0x06000C7F RID: 3199 RVA: 0x00032C80 File Offset: 0x00030E80
	public unsafe bool ShowScreenshotAfterTake
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ShowScreenshotAfterTake);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ShowScreenshotAfterTake)) = value;
		}
	}

	// Token: 0x1700044E RID: 1102
	// (get) Token: 0x06000C80 RID: 3200 RVA: 0x00032CA4 File Offset: 0x00030EA4
	// (set) Token: 0x06000C81 RID: 3201 RVA: 0x00032CCC File Offset: 0x00030ECC
	public unsafe int Resolution
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_Resolution);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_Resolution)) = value;
		}
	}

	// Token: 0x1700044F RID: 1103
	// (get) Token: 0x06000C82 RID: 3202 RVA: 0x00032CF0 File Offset: 0x00030EF0
	// (set) Token: 0x06000C83 RID: 3203 RVA: 0x00032D18 File Offset: 0x00030F18
	public unsafe int PrevResWidth
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_PrevResWidth);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_PrevResWidth)) = value;
		}
	}

	// Token: 0x17000450 RID: 1104
	// (get) Token: 0x06000C84 RID: 3204 RVA: 0x00032D3C File Offset: 0x00030F3C
	// (set) Token: 0x06000C85 RID: 3205 RVA: 0x00032D64 File Offset: 0x00030F64
	public unsafe int PrevResHeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_PrevResHeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_PrevResHeight)) = value;
		}
	}

	// Token: 0x17000451 RID: 1105
	// (get) Token: 0x06000C86 RID: 3206 RVA: 0x00032D88 File Offset: 0x00030F88
	// (set) Token: 0x06000C87 RID: 3207 RVA: 0x00032DBC File Offset: 0x00030FBC
	public unsafe RenderTexture RenderTex
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_RenderTex);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RenderTexture(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_RenderTex), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000452 RID: 1106
	// (get) Token: 0x06000C88 RID: 3208 RVA: 0x00032DE4 File Offset: 0x00030FE4
	// (set) Token: 0x06000C89 RID: 3209 RVA: 0x00032E18 File Offset: 0x00031018
	public unsafe Texture2D Screenshot
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_Screenshot);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Texture2D(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_Screenshot), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000453 RID: 1107
	// (get) Token: 0x06000C8A RID: 3210 RVA: 0x00032E40 File Offset: 0x00031040
	// (set) Token: 0x06000C8B RID: 3211 RVA: 0x00032E68 File Offset: 0x00031068
	public unsafe CaptureTransparentPNG.EScreenshotFunction ScreenshotFunction
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ScreenshotFunction);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CaptureTransparentPNG.NativeFieldInfoPtr_ScreenshotFunction)) = value;
		}
	}

	// Token: 0x04000782 RID: 1922
	private static readonly IntPtr NativeFieldInfoPtr_CameraToUse;

	// Token: 0x04000783 RID: 1923
	private static readonly IntPtr NativeFieldInfoPtr_ResWidth;

	// Token: 0x04000784 RID: 1924
	private static readonly IntPtr NativeFieldInfoPtr_ResHeight;

	// Token: 0x04000785 RID: 1925
	private static readonly IntPtr NativeFieldInfoPtr_TakeScreenshot;

	// Token: 0x04000786 RID: 1926
	private static readonly IntPtr NativeFieldInfoPtr_ShowScreenshotAfterTake;

	// Token: 0x04000787 RID: 1927
	private static readonly IntPtr NativeFieldInfoPtr_Resolution;

	// Token: 0x04000788 RID: 1928
	private static readonly IntPtr NativeFieldInfoPtr_PrevResWidth;

	// Token: 0x04000789 RID: 1929
	private static readonly IntPtr NativeFieldInfoPtr_PrevResHeight;

	// Token: 0x0400078A RID: 1930
	private static readonly IntPtr NativeFieldInfoPtr_RenderTex;

	// Token: 0x0400078B RID: 1931
	private static readonly IntPtr NativeFieldInfoPtr_Screenshot;

	// Token: 0x0400078C RID: 1932
	private static readonly IntPtr NativeFieldInfoPtr_ScreenshotFunction;

	// Token: 0x0400078D RID: 1933
	private static readonly IntPtr NativeMethodInfoPtr_Capture_Public_Void_0;

	// Token: 0x0400078E RID: 1934
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x0400078F RID: 1935
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04000790 RID: 1936
	private static readonly IntPtr NativeMethodInfoPtr_ScreenShotName_Public_Static_String_Int32_Int32_0;

	// Token: 0x04000791 RID: 1937
	private static readonly IntPtr NativeMethodInfoPtr_LateUpdate_Private_Void_0;

	// Token: 0x04000792 RID: 1938
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020000C8 RID: 200
	public enum EScreenshotFunction
	{
		// Token: 0x04000794 RID: 1940
		Custom,
		// Token: 0x04000795 RID: 1941
		Unity
	}
}
