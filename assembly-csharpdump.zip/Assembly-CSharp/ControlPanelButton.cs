﻿using System;
using Il2CppSystem;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200044A RID: 1098
public class ControlPanelButton : MonoBehaviour
{
	// Token: 0x17001F23 RID: 7971
	// (get) Token: 0x0600577A RID: 22394 RVA: 0x0015E360 File Offset: 0x0015C560
	// (set) Token: 0x0600577B RID: 22395 RVA: 0x0015E3B0 File Offset: 0x0015C5B0
	public unsafe bool IsHovered
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_get_IsHovered_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_set_IsHovered_Private_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x0600577C RID: 22396 RVA: 0x0015E404 File Offset: 0x0015C604
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600577D RID: 22397 RVA: 0x0015E448 File Offset: 0x0015C648
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600577E RID: 22398 RVA: 0x0015E48C File Offset: 0x0015C68C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600577F RID: 22399 RVA: 0x0015E4D0 File Offset: 0x0015C6D0
	[CallerCount(0)]
	public unsafe void InitializeColliders()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_InitializeColliders_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005780 RID: 22400 RVA: 0x0015E514 File Offset: 0x0015C714
	[CallerCount(0)]
	public unsafe void RestoreDefaultTextColor()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_RestoreDefaultTextColor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005781 RID: 22401 RVA: 0x0015E558 File Offset: 0x0015C758
	[CallerCount(0)]
	public unsafe void OnRaycastLaserHover(HandController hoverHand, bool newHover)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(hoverHand);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newHover;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_OnRaycastLaserHover_Public_Virtual_Final_New_Void_HandController_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005782 RID: 22402 RVA: 0x0015E5C4 File Offset: 0x0015C7C4
	[CallerCount(0)]
	public unsafe void OnRaycastClick(HandController hand)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(hand);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr_OnRaycastClick_Public_Virtual_Final_New_Void_HandController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005783 RID: 22403 RVA: 0x0015E620 File Offset: 0x0015C820
	[CallerCount(0)]
	public unsafe ControlPanelButton() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ControlPanelButton.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005784 RID: 22404 RVA: 0x0015E66C File Offset: 0x0015C86C
	// Note: this type is marked as 'beforefieldinit'.
	static ControlPanelButton()
	{
		Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ControlPanelButton");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr);
		ControlPanelButton.NativeFieldInfoPtr_Text = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "Text");
		ControlPanelButton.NativeFieldInfoPtr_ExitButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "ExitButton");
		ControlPanelButton.NativeFieldInfoPtr_isNumberButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "isNumberButton");
		ControlPanelButton.NativeFieldInfoPtr_editCachedColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "editCachedColliders");
		ControlPanelButton.NativeFieldInfoPtr_cachedColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "cachedColliders");
		ControlPanelButton.NativeFieldInfoPtr__IsHovered_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, "<IsHovered>k__BackingField");
		ControlPanelButton.NativeMethodInfoPtr_get_IsHovered_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670192);
		ControlPanelButton.NativeMethodInfoPtr_set_IsHovered_Private_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670193);
		ControlPanelButton.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670194);
		ControlPanelButton.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670195);
		ControlPanelButton.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670196);
		ControlPanelButton.NativeMethodInfoPtr_InitializeColliders_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670197);
		ControlPanelButton.NativeMethodInfoPtr_RestoreDefaultTextColor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670198);
		ControlPanelButton.NativeMethodInfoPtr_OnRaycastLaserHover_Public_Virtual_Final_New_Void_HandController_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670199);
		ControlPanelButton.NativeMethodInfoPtr_OnRaycastClick_Public_Virtual_Final_New_Void_HandController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670200);
		ControlPanelButton.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr, 100670201);
	}

	// Token: 0x06005785 RID: 22405 RVA: 0x0000210C File Offset: 0x0000030C
	public ControlPanelButton(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001F1C RID: 7964
	// (get) Token: 0x06005786 RID: 22406 RVA: 0x0015E7DC File Offset: 0x0015C9DC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ControlPanelButton>.NativeClassPtr));
		}
	}

	// Token: 0x17001F1D RID: 7965
	// (get) Token: 0x06005787 RID: 22407 RVA: 0x0015E7F0 File Offset: 0x0015C9F0
	// (set) Token: 0x06005788 RID: 22408 RVA: 0x0015E824 File Offset: 0x0015CA24
	public unsafe TextMeshPro Text
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_Text);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshPro(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_Text), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F1E RID: 7966
	// (get) Token: 0x06005789 RID: 22409 RVA: 0x0015E84C File Offset: 0x0015CA4C
	// (set) Token: 0x0600578A RID: 22410 RVA: 0x0015E874 File Offset: 0x0015CA74
	public unsafe bool ExitButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_ExitButton);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_ExitButton)) = value;
		}
	}

	// Token: 0x17001F1F RID: 7967
	// (get) Token: 0x0600578B RID: 22411 RVA: 0x0015E898 File Offset: 0x0015CA98
	// (set) Token: 0x0600578C RID: 22412 RVA: 0x0015E8C0 File Offset: 0x0015CAC0
	public unsafe bool isNumberButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_isNumberButton);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_isNumberButton)) = value;
		}
	}

	// Token: 0x17001F20 RID: 7968
	// (get) Token: 0x0600578D RID: 22413 RVA: 0x0015E8E4 File Offset: 0x0015CAE4
	// (set) Token: 0x0600578E RID: 22414 RVA: 0x0015E90C File Offset: 0x0015CB0C
	public unsafe bool editCachedColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_editCachedColliders);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_editCachedColliders)) = value;
		}
	}

	// Token: 0x17001F21 RID: 7969
	// (get) Token: 0x0600578F RID: 22415 RVA: 0x0015E930 File Offset: 0x0015CB30
	// (set) Token: 0x06005790 RID: 22416 RVA: 0x0015E964 File Offset: 0x0015CB64
	public unsafe Il2CppReferenceArray<BoxCollider> cachedColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_cachedColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<BoxCollider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr_cachedColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F22 RID: 7970
	// (get) Token: 0x06005791 RID: 22417 RVA: 0x0015E98C File Offset: 0x0015CB8C
	// (set) Token: 0x06005792 RID: 22418 RVA: 0x0015E9B4 File Offset: 0x0015CBB4
	public unsafe bool _IsHovered_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr__IsHovered_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ControlPanelButton.NativeFieldInfoPtr__IsHovered_k__BackingField)) = value;
		}
	}

	// Token: 0x0400376E RID: 14190
	private static readonly IntPtr NativeFieldInfoPtr_Text;

	// Token: 0x0400376F RID: 14191
	private static readonly IntPtr NativeFieldInfoPtr_ExitButton;

	// Token: 0x04003770 RID: 14192
	private static readonly IntPtr NativeFieldInfoPtr_isNumberButton;

	// Token: 0x04003771 RID: 14193
	private static readonly IntPtr NativeFieldInfoPtr_editCachedColliders;

	// Token: 0x04003772 RID: 14194
	private static readonly IntPtr NativeFieldInfoPtr_cachedColliders;

	// Token: 0x04003773 RID: 14195
	private static readonly IntPtr NativeFieldInfoPtr__IsHovered_k__BackingField;

	// Token: 0x04003774 RID: 14196
	private static readonly IntPtr NativeMethodInfoPtr_get_IsHovered_Public_get_Boolean_0;

	// Token: 0x04003775 RID: 14197
	private static readonly IntPtr NativeMethodInfoPtr_set_IsHovered_Private_set_Void_Boolean_0;

	// Token: 0x04003776 RID: 14198
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04003777 RID: 14199
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04003778 RID: 14200
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04003779 RID: 14201
	private static readonly IntPtr NativeMethodInfoPtr_InitializeColliders_Private_Void_0;

	// Token: 0x0400377A RID: 14202
	private static readonly IntPtr NativeMethodInfoPtr_RestoreDefaultTextColor_Private_Void_0;

	// Token: 0x0400377B RID: 14203
	private static readonly IntPtr NativeMethodInfoPtr_OnRaycastLaserHover_Public_Virtual_Final_New_Void_HandController_Boolean_0;

	// Token: 0x0400377C RID: 14204
	private static readonly IntPtr NativeMethodInfoPtr_OnRaycastClick_Public_Virtual_Final_New_Void_HandController_0;

	// Token: 0x0400377D RID: 14205
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
