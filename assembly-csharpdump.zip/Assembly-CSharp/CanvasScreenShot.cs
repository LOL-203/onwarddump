﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020003E1 RID: 993
public class CanvasScreenShot : MonoBehaviour
{
	// Token: 0x06004E31 RID: 20017 RVA: 0x00139538 File Offset: 0x00137738
	[CallerCount(0)]
	public unsafe static void add_OnPictureTaken(CanvasScreenShot.takePictureHandler value)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_add_OnPictureTaken_Public_Static_add_Void_takePictureHandler_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E32 RID: 20018 RVA: 0x00139584 File Offset: 0x00137784
	[CallerCount(0)]
	public unsafe static void remove_OnPictureTaken(CanvasScreenShot.takePictureHandler value)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_remove_OnPictureTaken_Public_Static_rem_Void_takePictureHandler_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E33 RID: 20019 RVA: 0x001395D0 File Offset: 0x001377D0
	[CallerCount(0)]
	public unsafe void TakeScreenshot()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_TakeScreenshot_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E34 RID: 20020 RVA: 0x00139614 File Offset: 0x00137814
	[CallerCount(0)]
	public unsafe void SaveScreenshot(Il2CppStructArray<byte> pngArray)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(pngArray);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_SaveScreenshot_Private_Void_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E35 RID: 20021 RVA: 0x00139670 File Offset: 0x00137870
	[CallerCount(0)]
	public unsafe void takeScreenShot(Canvas canvasPanel, [Optional] CanvasScreenShot.SCREENSHOT_TYPE screenShotType, bool createNewInstance = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasPanel);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref screenShotType;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref createNewInstance;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_takeScreenShot_Public_Void_Canvas_SCREENSHOT_TYPE_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E36 RID: 20022 RVA: 0x001396F0 File Offset: 0x001378F0
	[CallerCount(0)]
	public unsafe IEnumerator _takeScreenShot(Canvas canvasPanel, [Optional] CanvasScreenShot.SCREENSHOT_TYPE screenShotType, bool createNewInstance = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasPanel);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref screenShotType;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref createNewInstance;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr__takeScreenShot_Private_IEnumerator_Canvas_SCREENSHOT_TYPE_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004E37 RID: 20023 RVA: 0x00139784 File Offset: 0x00137984
	[CallerCount(0)]
	public unsafe GameObject duplicateUI(GameObject parentUICanvasOrPanel, string newOBjectName)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(parentUICanvasOrPanel);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(newOBjectName);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_duplicateUI_Private_GameObject_GameObject_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
	}

	// Token: 0x06004E38 RID: 20024 RVA: 0x0013980C File Offset: 0x00137A0C
	[CallerCount(0)]
	public unsafe Il2CppReferenceArray<Image> getAllImagesFromCanvas(GameObject canvasParentGameObject, bool findDisabledCanvas = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasParentGameObject);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref findDisabledCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_getAllImagesFromCanvas_Private_ArrayOf_Image_GameObject_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppReferenceArray<Image>(intPtr2) : null;
	}

	// Token: 0x06004E39 RID: 20025 RVA: 0x0013988C File Offset: 0x00137A8C
	[CallerCount(0)]
	public unsafe Il2CppReferenceArray<Text> getAllTextsFromCanvas(GameObject canvasParentGameObject, bool findDisabledCanvas = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasParentGameObject);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref findDisabledCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_getAllTextsFromCanvas_Private_ArrayOf_Text_GameObject_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppReferenceArray<Text>(intPtr2) : null;
	}

	// Token: 0x06004E3A RID: 20026 RVA: 0x0013990C File Offset: 0x00137B0C
	[CallerCount(0)]
	public unsafe Il2CppReferenceArray<Canvas> getAllCanvasFromCanvas(Canvas canvasParentGameObject, bool findDisabledCanvas = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasParentGameObject);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref findDisabledCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_getAllCanvasFromCanvas_Private_ArrayOf_Canvas_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppReferenceArray<Canvas>(intPtr2) : null;
	}

	// Token: 0x06004E3B RID: 20027 RVA: 0x0013998C File Offset: 0x00137B8C
	[CallerCount(0)]
	public unsafe Il2CppReferenceArray<Canvas> getAllCanvasInScene(bool findDisabledCanvas = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref findDisabledCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_getAllCanvasInScene_Private_ArrayOf_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppReferenceArray<Canvas>(intPtr2) : null;
	}

	// Token: 0x06004E3C RID: 20028 RVA: 0x001399F4 File Offset: 0x00137BF4
	[CallerCount(0)]
	public unsafe void showImages(Il2CppReferenceArray<Image> imagesToDisable, bool enableImage = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(imagesToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableImage;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showImages_Private_Void_ArrayOf_Image_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E3D RID: 20029 RVA: 0x00139A60 File Offset: 0x00137C60
	[CallerCount(0)]
	public unsafe void showTexts(Il2CppReferenceArray<Text> imagesToDisable, bool enableTexts = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(imagesToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableTexts;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showTexts_Private_Void_ArrayOf_Text_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E3E RID: 20030 RVA: 0x00139ACC File Offset: 0x00137CCC
	[CallerCount(0)]
	public unsafe void showCanvas(Il2CppReferenceArray<Canvas> canvasToDisable, bool enableCanvas = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showCanvas_Private_Void_ArrayOf_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E3F RID: 20031 RVA: 0x00139B38 File Offset: 0x00137D38
	[CallerCount(0)]
	public unsafe void showCanvas(Canvas canvasToDisable, bool enableCanvas = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showCanvas_Private_Void_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E40 RID: 20032 RVA: 0x00139BA4 File Offset: 0x00137DA4
	[CallerCount(0)]
	public unsafe void showCanvasExcept(Il2CppReferenceArray<Canvas> canvasToDisable, Canvas ignoreCanvas, bool enableCanvas = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(ignoreCanvas);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E41 RID: 20033 RVA: 0x00139C28 File Offset: 0x00137E28
	[CallerCount(0)]
	public unsafe void showCanvasExcept(Il2CppReferenceArray<Canvas> canvasToDisable, Il2CppReferenceArray<Canvas> ignoreCanvas, bool enableCanvas = true)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(canvasToDisable);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(ignoreCanvas);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref enableCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_ArrayOf_Canvas_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E42 RID: 20034 RVA: 0x00139CAC File Offset: 0x00137EAC
	[CallerCount(0)]
	public unsafe void resetPosAndRot(GameObject posToReset)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(posToReset);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr_resetPosAndRot_Private_Void_GameObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E43 RID: 20035 RVA: 0x00139D08 File Offset: 0x00137F08
	[CallerCount(0)]
	public unsafe CanvasScreenShot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E44 RID: 20036 RVA: 0x00139D54 File Offset: 0x00137F54
	// Note: this type is marked as 'beforefieldinit'.
	static CanvasScreenShot()
	{
		Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CanvasScreenShot");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr);
		CanvasScreenShot.NativeFieldInfoPtr_OnPictureTaken = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "OnPictureTaken");
		CanvasScreenShot.NativeFieldInfoPtr_ScreenshotType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "ScreenshotType");
		CanvasScreenShot.NativeFieldInfoPtr_ScreenshotCanvas = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "ScreenshotCanvas");
		CanvasScreenShot.NativeFieldInfoPtr_ScreenshotPath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "ScreenshotPath");
		CanvasScreenShot.NativeFieldInfoPtr_duplicatedTargetUI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "duplicatedTargetUI");
		CanvasScreenShot.NativeFieldInfoPtr_allImages = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "allImages");
		CanvasScreenShot.NativeFieldInfoPtr_allTexts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "allTexts");
		CanvasScreenShot.NativeFieldInfoPtr_allOtherCanvas = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "allOtherCanvas");
		CanvasScreenShot.NativeMethodInfoPtr_add_OnPictureTaken_Public_Static_add_Void_takePictureHandler_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669451);
		CanvasScreenShot.NativeMethodInfoPtr_remove_OnPictureTaken_Public_Static_rem_Void_takePictureHandler_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669452);
		CanvasScreenShot.NativeMethodInfoPtr_TakeScreenshot_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669453);
		CanvasScreenShot.NativeMethodInfoPtr_SaveScreenshot_Private_Void_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669454);
		CanvasScreenShot.NativeMethodInfoPtr_takeScreenShot_Public_Void_Canvas_SCREENSHOT_TYPE_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669455);
		CanvasScreenShot.NativeMethodInfoPtr__takeScreenShot_Private_IEnumerator_Canvas_SCREENSHOT_TYPE_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669456);
		CanvasScreenShot.NativeMethodInfoPtr_duplicateUI_Private_GameObject_GameObject_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669457);
		CanvasScreenShot.NativeMethodInfoPtr_getAllImagesFromCanvas_Private_ArrayOf_Image_GameObject_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669458);
		CanvasScreenShot.NativeMethodInfoPtr_getAllTextsFromCanvas_Private_ArrayOf_Text_GameObject_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669459);
		CanvasScreenShot.NativeMethodInfoPtr_getAllCanvasFromCanvas_Private_ArrayOf_Canvas_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669460);
		CanvasScreenShot.NativeMethodInfoPtr_getAllCanvasInScene_Private_ArrayOf_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669461);
		CanvasScreenShot.NativeMethodInfoPtr_showImages_Private_Void_ArrayOf_Image_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669462);
		CanvasScreenShot.NativeMethodInfoPtr_showTexts_Private_Void_ArrayOf_Text_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669463);
		CanvasScreenShot.NativeMethodInfoPtr_showCanvas_Private_Void_ArrayOf_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669464);
		CanvasScreenShot.NativeMethodInfoPtr_showCanvas_Private_Void_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669465);
		CanvasScreenShot.NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669466);
		CanvasScreenShot.NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_ArrayOf_Canvas_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669467);
		CanvasScreenShot.NativeMethodInfoPtr_resetPosAndRot_Private_Void_GameObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669468);
		CanvasScreenShot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, 100669469);
	}

	// Token: 0x06004E45 RID: 20037 RVA: 0x0000210C File Offset: 0x0000030C
	public CanvasScreenShot(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001BF5 RID: 7157
	// (get) Token: 0x06004E46 RID: 20038 RVA: 0x00139FA0 File Offset: 0x001381A0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr));
		}
	}

	// Token: 0x17001BF6 RID: 7158
	// (get) Token: 0x06004E47 RID: 20039 RVA: 0x00139FB4 File Offset: 0x001381B4
	// (set) Token: 0x06004E48 RID: 20040 RVA: 0x00139FDF File Offset: 0x001381DF
	public unsafe static CanvasScreenShot.takePictureHandler OnPictureTaken
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CanvasScreenShot.NativeFieldInfoPtr_OnPictureTaken, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new CanvasScreenShot.takePictureHandler(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CanvasScreenShot.NativeFieldInfoPtr_OnPictureTaken, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BF7 RID: 7159
	// (get) Token: 0x06004E49 RID: 20041 RVA: 0x00139FF4 File Offset: 0x001381F4
	// (set) Token: 0x06004E4A RID: 20042 RVA: 0x0013A01C File Offset: 0x0013821C
	public unsafe CanvasScreenShot.SCREENSHOT_TYPE ScreenshotType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotType)) = value;
		}
	}

	// Token: 0x17001BF8 RID: 7160
	// (get) Token: 0x06004E4B RID: 20043 RVA: 0x0013A040 File Offset: 0x00138240
	// (set) Token: 0x06004E4C RID: 20044 RVA: 0x0013A074 File Offset: 0x00138274
	public unsafe Canvas ScreenshotCanvas
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotCanvas);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Canvas(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotCanvas), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BF9 RID: 7161
	// (get) Token: 0x06004E4D RID: 20045 RVA: 0x0013A09C File Offset: 0x0013829C
	// (set) Token: 0x06004E4E RID: 20046 RVA: 0x0013A0C5 File Offset: 0x001382C5
	public unsafe string ScreenshotPath
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotPath);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_ScreenshotPath), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001BFA RID: 7162
	// (get) Token: 0x06004E4F RID: 20047 RVA: 0x0013A0EC File Offset: 0x001382EC
	// (set) Token: 0x06004E50 RID: 20048 RVA: 0x0013A120 File Offset: 0x00138320
	public unsafe GameObject duplicatedTargetUI
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_duplicatedTargetUI);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_duplicatedTargetUI), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BFB RID: 7163
	// (get) Token: 0x06004E51 RID: 20049 RVA: 0x0013A148 File Offset: 0x00138348
	// (set) Token: 0x06004E52 RID: 20050 RVA: 0x0013A17C File Offset: 0x0013837C
	public unsafe Il2CppReferenceArray<Image> allImages
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allImages);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Image>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allImages), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BFC RID: 7164
	// (get) Token: 0x06004E53 RID: 20051 RVA: 0x0013A1A4 File Offset: 0x001383A4
	// (set) Token: 0x06004E54 RID: 20052 RVA: 0x0013A1D8 File Offset: 0x001383D8
	public unsafe Il2CppReferenceArray<Text> allTexts
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allTexts);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Text>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allTexts), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BFD RID: 7165
	// (get) Token: 0x06004E55 RID: 20053 RVA: 0x0013A200 File Offset: 0x00138400
	// (set) Token: 0x06004E56 RID: 20054 RVA: 0x0013A234 File Offset: 0x00138434
	public unsafe Il2CppReferenceArray<Canvas> allOtherCanvas
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allOtherCanvas);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Canvas>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.NativeFieldInfoPtr_allOtherCanvas), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040031A7 RID: 12711
	private static readonly IntPtr NativeFieldInfoPtr_OnPictureTaken;

	// Token: 0x040031A8 RID: 12712
	private static readonly IntPtr NativeFieldInfoPtr_ScreenshotType;

	// Token: 0x040031A9 RID: 12713
	private static readonly IntPtr NativeFieldInfoPtr_ScreenshotCanvas;

	// Token: 0x040031AA RID: 12714
	private static readonly IntPtr NativeFieldInfoPtr_ScreenshotPath;

	// Token: 0x040031AB RID: 12715
	private static readonly IntPtr NativeFieldInfoPtr_duplicatedTargetUI;

	// Token: 0x040031AC RID: 12716
	private static readonly IntPtr NativeFieldInfoPtr_allImages;

	// Token: 0x040031AD RID: 12717
	private static readonly IntPtr NativeFieldInfoPtr_allTexts;

	// Token: 0x040031AE RID: 12718
	private static readonly IntPtr NativeFieldInfoPtr_allOtherCanvas;

	// Token: 0x040031AF RID: 12719
	private static readonly IntPtr NativeMethodInfoPtr_add_OnPictureTaken_Public_Static_add_Void_takePictureHandler_0;

	// Token: 0x040031B0 RID: 12720
	private static readonly IntPtr NativeMethodInfoPtr_remove_OnPictureTaken_Public_Static_rem_Void_takePictureHandler_0;

	// Token: 0x040031B1 RID: 12721
	private static readonly IntPtr NativeMethodInfoPtr_TakeScreenshot_Public_Void_0;

	// Token: 0x040031B2 RID: 12722
	private static readonly IntPtr NativeMethodInfoPtr_SaveScreenshot_Private_Void_ArrayOf_Byte_0;

	// Token: 0x040031B3 RID: 12723
	private static readonly IntPtr NativeMethodInfoPtr_takeScreenShot_Public_Void_Canvas_SCREENSHOT_TYPE_Boolean_0;

	// Token: 0x040031B4 RID: 12724
	private static readonly IntPtr NativeMethodInfoPtr__takeScreenShot_Private_IEnumerator_Canvas_SCREENSHOT_TYPE_Boolean_0;

	// Token: 0x040031B5 RID: 12725
	private static readonly IntPtr NativeMethodInfoPtr_duplicateUI_Private_GameObject_GameObject_String_0;

	// Token: 0x040031B6 RID: 12726
	private static readonly IntPtr NativeMethodInfoPtr_getAllImagesFromCanvas_Private_ArrayOf_Image_GameObject_Boolean_0;

	// Token: 0x040031B7 RID: 12727
	private static readonly IntPtr NativeMethodInfoPtr_getAllTextsFromCanvas_Private_ArrayOf_Text_GameObject_Boolean_0;

	// Token: 0x040031B8 RID: 12728
	private static readonly IntPtr NativeMethodInfoPtr_getAllCanvasFromCanvas_Private_ArrayOf_Canvas_Canvas_Boolean_0;

	// Token: 0x040031B9 RID: 12729
	private static readonly IntPtr NativeMethodInfoPtr_getAllCanvasInScene_Private_ArrayOf_Canvas_Boolean_0;

	// Token: 0x040031BA RID: 12730
	private static readonly IntPtr NativeMethodInfoPtr_showImages_Private_Void_ArrayOf_Image_Boolean_0;

	// Token: 0x040031BB RID: 12731
	private static readonly IntPtr NativeMethodInfoPtr_showTexts_Private_Void_ArrayOf_Text_Boolean_0;

	// Token: 0x040031BC RID: 12732
	private static readonly IntPtr NativeMethodInfoPtr_showCanvas_Private_Void_ArrayOf_Canvas_Boolean_0;

	// Token: 0x040031BD RID: 12733
	private static readonly IntPtr NativeMethodInfoPtr_showCanvas_Private_Void_Canvas_Boolean_0;

	// Token: 0x040031BE RID: 12734
	private static readonly IntPtr NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_Canvas_Boolean_0;

	// Token: 0x040031BF RID: 12735
	private static readonly IntPtr NativeMethodInfoPtr_showCanvasExcept_Private_Void_ArrayOf_Canvas_ArrayOf_Canvas_Boolean_0;

	// Token: 0x040031C0 RID: 12736
	private static readonly IntPtr NativeMethodInfoPtr_resetPosAndRot_Private_Void_GameObject_0;

	// Token: 0x040031C1 RID: 12737
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003E2 RID: 994
	public sealed class takePictureHandler : MulticastDelegate
	{
		// Token: 0x06004E57 RID: 20055 RVA: 0x0013A25C File Offset: 0x0013845C
		[CallerCount(0)]
		public unsafe takePictureHandler(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E58 RID: 20056 RVA: 0x0013A2D4 File Offset: 0x001384D4
		[CallerCount(0)]
		public unsafe void Invoke(Il2CppStructArray<byte> pngArray)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(pngArray);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E59 RID: 20057 RVA: 0x0013A330 File Offset: 0x00138530
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(Il2CppStructArray<byte> pngArray, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(pngArray);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_ArrayOf_Byte_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x06004E5A RID: 20058 RVA: 0x0013A3D0 File Offset: 0x001385D0
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E5B RID: 20059 RVA: 0x0013A42C File Offset: 0x0013862C
		// Note: this type is marked as 'beforefieldinit'.
		static takePictureHandler()
		{
			Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "takePictureHandler");
			CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr, 100669470);
			CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr, 100669471);
			CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_ArrayOf_Byte_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr, 100669472);
			CanvasScreenShot.takePictureHandler.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr, 100669473);
		}

		// Token: 0x06004E5C RID: 20060 RVA: 0x00005E35 File Offset: 0x00004035
		public takePictureHandler(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001BFE RID: 7166
		// (get) Token: 0x06004E5D RID: 20061 RVA: 0x0013A49D File Offset: 0x0013869D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CanvasScreenShot.takePictureHandler>.NativeClassPtr));
			}
		}

		// Token: 0x06004E5E RID: 20062 RVA: 0x0013A4AE File Offset: 0x001386AE
		public static implicit operator CanvasScreenShot.takePictureHandler(Action<Il2CppStructArray<byte>> A_0)
		{
			return DelegateSupport.ConvertDelegate<CanvasScreenShot.takePictureHandler>(A_0);
		}

		// Token: 0x06004E5F RID: 20063 RVA: 0x0013A4B6 File Offset: 0x001386B6
		public static CanvasScreenShot.takePictureHandler operator +(CanvasScreenShot.takePictureHandler A_0, CanvasScreenShot.takePictureHandler A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<CanvasScreenShot.takePictureHandler>();
		}

		// Token: 0x06004E60 RID: 20064 RVA: 0x0013A4C4 File Offset: 0x001386C4
		public static CanvasScreenShot.takePictureHandler operator -(CanvasScreenShot.takePictureHandler A_0, CanvasScreenShot.takePictureHandler A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<CanvasScreenShot.takePictureHandler>();
			}
			return result;
		}

		// Token: 0x040031C2 RID: 12738
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x040031C3 RID: 12739
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_ArrayOf_Byte_0;

		// Token: 0x040031C4 RID: 12740
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_ArrayOf_Byte_AsyncCallback_Object_0;

		// Token: 0x040031C5 RID: 12741
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x020003E3 RID: 995
	public enum SCREENSHOT_TYPE
	{
		// Token: 0x040031C7 RID: 12743
		IMAGE_AND_TEXT,
		// Token: 0x040031C8 RID: 12744
		IMAGE_ONLY,
		// Token: 0x040031C9 RID: 12745
		TEXT_ONLY
	}

	// Token: 0x020003E4 RID: 996
	[ObfuscatedName("CanvasScreenShot/<_takeScreenShot>d__15")]
	public sealed class __takeScreenShot_d__15 : Il2CppSystem.Object
	{
		// Token: 0x06004E63 RID: 20067 RVA: 0x0013A4FC File Offset: 0x001386FC
		[CallerCount(0)]
		public unsafe __takeScreenShot_d__15(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E64 RID: 20068 RVA: 0x0013A55C File Offset: 0x0013875C
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E65 RID: 20069 RVA: 0x0013A5A0 File Offset: 0x001387A0
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001C09 RID: 7177
		// (get) Token: 0x06004E66 RID: 20070 RVA: 0x0013A5F0 File Offset: 0x001387F0
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004E67 RID: 20071 RVA: 0x0013A648 File Offset: 0x00138848
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001C0A RID: 7178
		// (get) Token: 0x06004E68 RID: 20072 RVA: 0x0013A68C File Offset: 0x0013888C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004E69 RID: 20073 RVA: 0x0013A6E4 File Offset: 0x001388E4
		// Note: this type is marked as 'beforefieldinit'.
		static __takeScreenShot_d__15()
		{
			Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CanvasScreenShot>.NativeClassPtr, "<_takeScreenShot>d__15");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr);
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "<>1__state");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "<>2__current");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "<>4__this");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_canvasPanel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "canvasPanel");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_createNewInstance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "createNewInstance");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_screenShotType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "screenShotType");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__defaultRenderMode_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "<defaultRenderMode>5__2");
			CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__duplicatedCanvas_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, "<duplicatedCanvas>5__3");
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669474);
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669475);
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669476);
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669477);
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669478);
			CanvasScreenShot.__takeScreenShot_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr, 100669479);
		}

		// Token: 0x06004E6A RID: 20074 RVA: 0x00002988 File Offset: 0x00000B88
		public __takeScreenShot_d__15(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C00 RID: 7168
		// (get) Token: 0x06004E6B RID: 20075 RVA: 0x0013A827 File Offset: 0x00138A27
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CanvasScreenShot.__takeScreenShot_d__15>.NativeClassPtr));
			}
		}

		// Token: 0x17001C01 RID: 7169
		// (get) Token: 0x06004E6C RID: 20076 RVA: 0x0013A838 File Offset: 0x00138A38
		// (set) Token: 0x06004E6D RID: 20077 RVA: 0x0013A860 File Offset: 0x00138A60
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C02 RID: 7170
		// (get) Token: 0x06004E6E RID: 20078 RVA: 0x0013A884 File Offset: 0x00138A84
		// (set) Token: 0x06004E6F RID: 20079 RVA: 0x0013A8B8 File Offset: 0x00138AB8
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C03 RID: 7171
		// (get) Token: 0x06004E70 RID: 20080 RVA: 0x0013A8E0 File Offset: 0x00138AE0
		// (set) Token: 0x06004E71 RID: 20081 RVA: 0x0013A914 File Offset: 0x00138B14
		public unsafe CanvasScreenShot __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CanvasScreenShot(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C04 RID: 7172
		// (get) Token: 0x06004E72 RID: 20082 RVA: 0x0013A93C File Offset: 0x00138B3C
		// (set) Token: 0x06004E73 RID: 20083 RVA: 0x0013A970 File Offset: 0x00138B70
		public unsafe Canvas canvasPanel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_canvasPanel);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Canvas(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_canvasPanel), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C05 RID: 7173
		// (get) Token: 0x06004E74 RID: 20084 RVA: 0x0013A998 File Offset: 0x00138B98
		// (set) Token: 0x06004E75 RID: 20085 RVA: 0x0013A9C0 File Offset: 0x00138BC0
		public unsafe bool createNewInstance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_createNewInstance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_createNewInstance)) = value;
			}
		}

		// Token: 0x17001C06 RID: 7174
		// (get) Token: 0x06004E76 RID: 20086 RVA: 0x0013A9E4 File Offset: 0x00138BE4
		// (set) Token: 0x06004E77 RID: 20087 RVA: 0x0013AA0C File Offset: 0x00138C0C
		public unsafe CanvasScreenShot.SCREENSHOT_TYPE screenShotType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_screenShotType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr_screenShotType)) = value;
			}
		}

		// Token: 0x17001C07 RID: 7175
		// (get) Token: 0x06004E78 RID: 20088 RVA: 0x0013AA30 File Offset: 0x00138C30
		// (set) Token: 0x06004E79 RID: 20089 RVA: 0x0013AA58 File Offset: 0x00138C58
		public unsafe RenderMode _defaultRenderMode_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__defaultRenderMode_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__defaultRenderMode_5__2)) = value;
			}
		}

		// Token: 0x17001C08 RID: 7176
		// (get) Token: 0x06004E7A RID: 20090 RVA: 0x0013AA7C File Offset: 0x00138C7C
		// (set) Token: 0x06004E7B RID: 20091 RVA: 0x0013AAB0 File Offset: 0x00138CB0
		public unsafe Canvas _duplicatedCanvas_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__duplicatedCanvas_5__3);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Canvas(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CanvasScreenShot.__takeScreenShot_d__15.NativeFieldInfoPtr__duplicatedCanvas_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040031CA RID: 12746
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040031CB RID: 12747
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040031CC RID: 12748
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040031CD RID: 12749
		private static readonly IntPtr NativeFieldInfoPtr_canvasPanel;

		// Token: 0x040031CE RID: 12750
		private static readonly IntPtr NativeFieldInfoPtr_createNewInstance;

		// Token: 0x040031CF RID: 12751
		private static readonly IntPtr NativeFieldInfoPtr_screenShotType;

		// Token: 0x040031D0 RID: 12752
		private static readonly IntPtr NativeFieldInfoPtr__defaultRenderMode_5__2;

		// Token: 0x040031D1 RID: 12753
		private static readonly IntPtr NativeFieldInfoPtr__duplicatedCanvas_5__3;

		// Token: 0x040031D2 RID: 12754
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040031D3 RID: 12755
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040031D4 RID: 12756
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040031D5 RID: 12757
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040031D6 RID: 12758
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040031D7 RID: 12759
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
