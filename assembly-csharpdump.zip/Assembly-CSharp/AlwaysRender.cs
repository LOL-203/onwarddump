﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200033F RID: 831
public class AlwaysRender : MonoBehaviour
{
	// Token: 0x060041C1 RID: 16833 RVA: 0x00109620 File Offset: 0x00107820
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlwaysRender.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060041C2 RID: 16834 RVA: 0x00109664 File Offset: 0x00107864
	[CallerCount(0)]
	public unsafe AlwaysRender() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlwaysRender.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060041C3 RID: 16835 RVA: 0x001096B0 File Offset: 0x001078B0
	// Note: this type is marked as 'beforefieldinit'.
	static AlwaysRender()
	{
		Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "AlwaysRender");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr);
		AlwaysRender.NativeFieldInfoPtr_alwaysRender = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, "alwaysRender");
		AlwaysRender.NativeFieldInfoPtr_originalBounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, "originalBounds");
		AlwaysRender.NativeFieldInfoPtr_rend = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, "rend");
		AlwaysRender.NativeFieldInfoPtr_skinnedMeshRenderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, "skinnedMeshRenderer");
		AlwaysRender.NativeFieldInfoPtr_meshRenderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, "meshRenderer");
		AlwaysRender.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, 100668555);
		AlwaysRender.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr, 100668556);
	}

	// Token: 0x060041C4 RID: 16836 RVA: 0x0000210C File Offset: 0x0000030C
	public AlwaysRender(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700174C RID: 5964
	// (get) Token: 0x060041C5 RID: 16837 RVA: 0x0010976C File Offset: 0x0010796C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AlwaysRender>.NativeClassPtr));
		}
	}

	// Token: 0x1700174D RID: 5965
	// (get) Token: 0x060041C6 RID: 16838 RVA: 0x00109780 File Offset: 0x00107980
	// (set) Token: 0x060041C7 RID: 16839 RVA: 0x001097A8 File Offset: 0x001079A8
	public unsafe bool alwaysRender
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_alwaysRender);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_alwaysRender)) = value;
		}
	}

	// Token: 0x1700174E RID: 5966
	// (get) Token: 0x060041C8 RID: 16840 RVA: 0x001097CC File Offset: 0x001079CC
	// (set) Token: 0x060041C9 RID: 16841 RVA: 0x001097F4 File Offset: 0x001079F4
	public unsafe Bounds originalBounds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_originalBounds);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_originalBounds)) = value;
		}
	}

	// Token: 0x1700174F RID: 5967
	// (get) Token: 0x060041CA RID: 16842 RVA: 0x00109818 File Offset: 0x00107A18
	// (set) Token: 0x060041CB RID: 16843 RVA: 0x0010984C File Offset: 0x00107A4C
	public unsafe Renderer rend
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_rend);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Renderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_rend), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001750 RID: 5968
	// (get) Token: 0x060041CC RID: 16844 RVA: 0x00109874 File Offset: 0x00107A74
	// (set) Token: 0x060041CD RID: 16845 RVA: 0x001098A8 File Offset: 0x00107AA8
	public unsafe SkinnedMeshRenderer skinnedMeshRenderer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_skinnedMeshRenderer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new SkinnedMeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_skinnedMeshRenderer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001751 RID: 5969
	// (get) Token: 0x060041CE RID: 16846 RVA: 0x001098D0 File Offset: 0x00107AD0
	// (set) Token: 0x060041CF RID: 16847 RVA: 0x00109904 File Offset: 0x00107B04
	public unsafe MeshRenderer meshRenderer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_meshRenderer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlwaysRender.NativeFieldInfoPtr_meshRenderer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002A3D RID: 10813
	private static readonly IntPtr NativeFieldInfoPtr_alwaysRender;

	// Token: 0x04002A3E RID: 10814
	private static readonly IntPtr NativeFieldInfoPtr_originalBounds;

	// Token: 0x04002A3F RID: 10815
	private static readonly IntPtr NativeFieldInfoPtr_rend;

	// Token: 0x04002A40 RID: 10816
	private static readonly IntPtr NativeFieldInfoPtr_skinnedMeshRenderer;

	// Token: 0x04002A41 RID: 10817
	private static readonly IntPtr NativeFieldInfoPtr_meshRenderer;

	// Token: 0x04002A42 RID: 10818
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04002A43 RID: 10819
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
