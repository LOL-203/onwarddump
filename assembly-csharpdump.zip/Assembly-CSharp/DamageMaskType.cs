﻿using System;

// Token: 0x020000CC RID: 204
public enum DamageMaskType
{
	// Token: 0x040007B0 RID: 1968
	Fragmentation,
	// Token: 0x040007B1 RID: 1969
	HighExplosive
}
