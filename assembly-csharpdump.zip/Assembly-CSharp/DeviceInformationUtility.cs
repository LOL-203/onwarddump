﻿using System;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020000CE RID: 206
public static class DeviceInformationUtility : Object
{
	// Token: 0x06000CC4 RID: 3268 RVA: 0x00033AF4 File Offset: 0x00031CF4
	[CallerCount(0)]
	public unsafe static void LogDeviceInformation(bool unstripped, bool extended)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref unstripped;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref extended;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_LogDeviceInformation_Public_Static_Void_Boolean_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CC5 RID: 3269 RVA: 0x00033B4C File Offset: 0x00031D4C
	[CallerCount(0)]
	public unsafe static void AppendInfoBullet<T>(string title, T information)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(title);
		IntPtr* ptr2 = ptr + checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr);
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = information;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref information;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.MethodInfoStoreGeneric_AppendInfoBullet_Private_Static_Void_String_T_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CC6 RID: 3270 RVA: 0x00033C04 File Offset: 0x00031E04
	[CallerCount(0)]
	public unsafe static void AppendTitle(bool extended)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref extended;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_AppendTitle_Private_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CC7 RID: 3271 RVA: 0x00033C4C File Offset: 0x00031E4C
	[CallerCount(0)]
	public unsafe static void AppendSummary()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_AppendSummary_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CC8 RID: 3272 RVA: 0x00033C80 File Offset: 0x00031E80
	[CallerCount(0)]
	public unsafe static void AppendExtendedProperties()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_AppendExtendedProperties_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CC9 RID: 3273 RVA: 0x00033CB4 File Offset: 0x00031EB4
	[CallerCount(0)]
	public unsafe static void AppendSupportedFeatures()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_AppendSupportedFeatures_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CCA RID: 3274 RVA: 0x00033CE8 File Offset: 0x00031EE8
	[CallerCount(0)]
	public unsafe static void AppendOculus(bool extended)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref extended;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeviceInformationUtility.NativeMethodInfoPtr_AppendOculus_Private_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CCB RID: 3275 RVA: 0x00033D30 File Offset: 0x00031F30
	// Note: this type is marked as 'beforefieldinit'.
	static DeviceInformationUtility()
	{
		Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DeviceInformationUtility");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr);
		DeviceInformationUtility.NativeMethodInfoPtr_LogDeviceInformation_Public_Static_Void_Boolean_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664289);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendInfoBullet_Private_Static_Void_String_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664290);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendTitle_Private_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664291);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendSummary_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664292);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendExtendedProperties_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664293);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendSupportedFeatures_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664294);
		DeviceInformationUtility.NativeMethodInfoPtr_AppendOculus_Private_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr, 100664295);
	}

	// Token: 0x06000CCC RID: 3276 RVA: 0x00002988 File Offset: 0x00000B88
	public DeviceInformationUtility(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700046A RID: 1130
	// (get) Token: 0x06000CCD RID: 3277 RVA: 0x00033DEC File Offset: 0x00031FEC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr));
		}
	}

	// Token: 0x040007B6 RID: 1974
	private static readonly IntPtr NativeMethodInfoPtr_LogDeviceInformation_Public_Static_Void_Boolean_Boolean_0;

	// Token: 0x040007B7 RID: 1975
	private static readonly IntPtr NativeMethodInfoPtr_AppendInfoBullet_Private_Static_Void_String_T_0;

	// Token: 0x040007B8 RID: 1976
	private static readonly IntPtr NativeMethodInfoPtr_AppendTitle_Private_Static_Void_Boolean_0;

	// Token: 0x040007B9 RID: 1977
	private static readonly IntPtr NativeMethodInfoPtr_AppendSummary_Private_Static_Void_0;

	// Token: 0x040007BA RID: 1978
	private static readonly IntPtr NativeMethodInfoPtr_AppendExtendedProperties_Private_Static_Void_0;

	// Token: 0x040007BB RID: 1979
	private static readonly IntPtr NativeMethodInfoPtr_AppendSupportedFeatures_Private_Static_Void_0;

	// Token: 0x040007BC RID: 1980
	private static readonly IntPtr NativeMethodInfoPtr_AppendOculus_Private_Static_Void_Boolean_0;

	// Token: 0x020000CF RID: 207
	private sealed class MethodInfoStoreGeneric_AppendInfoBullet_Private_Static_Void_String_T_0<T>
	{
		// Token: 0x040007BD RID: 1981
		internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(DeviceInformationUtility.NativeMethodInfoPtr_AppendInfoBullet_Private_Static_Void_String_T_0, Il2CppClassPointerStore<DeviceInformationUtility>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
		{
			Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
		}))));
	}
}
