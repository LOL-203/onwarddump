﻿using System;

// Token: 0x02000191 RID: 401
public enum BodyParts
{
	// Token: 0x04001131 RID: 4401
	None,
	// Token: 0x04001132 RID: 4402
	Clavicle,
	// Token: 0x04001133 RID: 4403
	UpperArm,
	// Token: 0x04001134 RID: 4404
	Forearm,
	// Token: 0x04001135 RID: 4405
	Hand,
	// Token: 0x04001136 RID: 4406
	Thigh,
	// Token: 0x04001137 RID: 4407
	Calf,
	// Token: 0x04001138 RID: 4408
	Foot,
	// Token: 0x04001139 RID: 4409
	Pelvis,
	// Token: 0x0400113A RID: 4410
	Spine,
	// Token: 0x0400113B RID: 4411
	Chest,
	// Token: 0x0400113C RID: 4412
	Head
}
