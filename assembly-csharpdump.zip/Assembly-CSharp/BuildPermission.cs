﻿using System;

// Token: 0x0200016A RID: 362
[Flags]
public enum BuildPermission
{
	// Token: 0x04000F94 RID: 3988
	None = 0,
	// Token: 0x04000F95 RID: 3989
	Editor = 1,
	// Token: 0x04000F96 RID: 3990
	QA = 2,
	// Token: 0x04000F97 RID: 3991
	Live = 4,
	// Token: 0x04000F98 RID: 3992
	All = -1
}
