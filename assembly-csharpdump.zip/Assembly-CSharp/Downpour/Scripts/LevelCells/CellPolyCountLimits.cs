﻿using System;
using DPI.Data;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Downpour.Scripts.LevelCells
{
	// Token: 0x0200098F RID: 2447
	public class CellPolyCountLimits : BaseData
	{
		// Token: 0x0600CE88 RID: 52872 RVA: 0x003357B0 File Offset: 0x003339B0
		[CallerCount(0)]
		public unsafe CellPolyCountLimits() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CellPolyCountLimits.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE89 RID: 52873 RVA: 0x003357FC File Offset: 0x003339FC
		// Note: this type is marked as 'beforefieldinit'.
		static CellPolyCountLimits()
		{
			Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Downpour.Scripts.LevelCells", "CellPolyCountLimits");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr);
			CellPolyCountLimits.NativeFieldInfoPtr_WholeCellPolyCountLimit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr, "WholeCellPolyCountLimit");
			CellPolyCountLimits.NativeFieldInfoPtr_OneDirectionPolyCountLimit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr, "OneDirectionPolyCountLimit");
			CellPolyCountLimits.NativeFieldInfoPtr_SubCellPolyCountLimit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr, "SubCellPolyCountLimit");
			CellPolyCountLimits.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr, 100679205);
		}

		// Token: 0x0600CE8A RID: 52874 RVA: 0x000AD628 File Offset: 0x000AB828
		public CellPolyCountLimits(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B36 RID: 19254
		// (get) Token: 0x0600CE8B RID: 52875 RVA: 0x0033587C File Offset: 0x00333A7C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CellPolyCountLimits>.NativeClassPtr));
			}
		}

		// Token: 0x17004B37 RID: 19255
		// (get) Token: 0x0600CE8C RID: 52876 RVA: 0x00335890 File Offset: 0x00333A90
		// (set) Token: 0x0600CE8D RID: 52877 RVA: 0x003358B8 File Offset: 0x00333AB8
		public unsafe float WholeCellPolyCountLimit
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_WholeCellPolyCountLimit);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_WholeCellPolyCountLimit)) = value;
			}
		}

		// Token: 0x17004B38 RID: 19256
		// (get) Token: 0x0600CE8E RID: 52878 RVA: 0x003358DC File Offset: 0x00333ADC
		// (set) Token: 0x0600CE8F RID: 52879 RVA: 0x00335904 File Offset: 0x00333B04
		public unsafe float OneDirectionPolyCountLimit
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_OneDirectionPolyCountLimit);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_OneDirectionPolyCountLimit)) = value;
			}
		}

		// Token: 0x17004B39 RID: 19257
		// (get) Token: 0x0600CE90 RID: 52880 RVA: 0x00335928 File Offset: 0x00333B28
		// (set) Token: 0x0600CE91 RID: 52881 RVA: 0x00335950 File Offset: 0x00333B50
		public unsafe float SubCellPolyCountLimit
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_SubCellPolyCountLimit);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CellPolyCountLimits.NativeFieldInfoPtr_SubCellPolyCountLimit)) = value;
			}
		}

		// Token: 0x0400829A RID: 33434
		private static readonly IntPtr NativeFieldInfoPtr_WholeCellPolyCountLimit;

		// Token: 0x0400829B RID: 33435
		private static readonly IntPtr NativeFieldInfoPtr_OneDirectionPolyCountLimit;

		// Token: 0x0400829C RID: 33436
		private static readonly IntPtr NativeFieldInfoPtr_SubCellPolyCountLimit;

		// Token: 0x0400829D RID: 33437
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
