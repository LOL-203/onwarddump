﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Downpour.Scripts.Utilities
{
	// Token: 0x02000990 RID: 2448
	public static class MatrixExtensions : Il2CppSystem.Object
	{
		// Token: 0x0600CE92 RID: 52882 RVA: 0x00335974 File Offset: 0x00333B74
		[CallerCount(0)]
		public unsafe static Vector3 GetMatrixPosition(this Matrix4x4 matrix)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref matrix;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MatrixExtensions.NativeMethodInfoPtr_GetMatrixPosition_Public_Static_Vector3_Matrix4x4_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CE93 RID: 52883 RVA: 0x003359C7 File Offset: 0x00333BC7
		// Note: this type is marked as 'beforefieldinit'.
		static MatrixExtensions()
		{
			Il2CppClassPointerStore<MatrixExtensions>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Downpour.Scripts.Utilities", "MatrixExtensions");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MatrixExtensions>.NativeClassPtr);
			MatrixExtensions.NativeMethodInfoPtr_GetMatrixPosition_Public_Static_Vector3_Matrix4x4_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MatrixExtensions>.NativeClassPtr, 100679206);
		}

		// Token: 0x0600CE94 RID: 52884 RVA: 0x00002988 File Offset: 0x00000B88
		public MatrixExtensions(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B3A RID: 19258
		// (get) Token: 0x0600CE95 RID: 52885 RVA: 0x00335A00 File Offset: 0x00333C00
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MatrixExtensions>.NativeClassPtr));
			}
		}

		// Token: 0x0400829E RID: 33438
		private static readonly IntPtr NativeMethodInfoPtr_GetMatrixPosition_Public_Static_Vector3_Matrix4x4_0;
	}
}
