﻿using System;
using Il2CppSystem;
using Il2CppSystem.IO;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace Downpour.Scripts.Utilities
{
	// Token: 0x02000992 RID: 2450
	[Serializable]
	public class SerializableType : Object
	{
		// Token: 0x0600CEA4 RID: 52900 RVA: 0x0033603C File Offset: 0x0033423C
		[CallerCount(0)]
		public unsafe SerializableType(Type aType) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SerializableType>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(aType);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializableType.NativeMethodInfoPtr__ctor_Public_Void_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CEA5 RID: 52901 RVA: 0x003360A0 File Offset: 0x003342A0
		[CallerCount(0)]
		public new unsafe bool Equals(Object typeObject)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(typeObject);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SerializableType.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CEA6 RID: 52902 RVA: 0x00336114 File Offset: 0x00334314
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SerializableType.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CEA7 RID: 52903 RVA: 0x00336170 File Offset: 0x00334370
		[CallerCount(0)]
		public unsafe static Type Read(BinaryReader aReader)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(aReader);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializableType.NativeMethodInfoPtr_Read_Private_Static_Type_BinaryReader_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Type(intPtr2) : null;
		}

		// Token: 0x0600CEA8 RID: 52904 RVA: 0x003361D0 File Offset: 0x003343D0
		[CallerCount(0)]
		public unsafe static void Write(BinaryWriter aWriter, Type aType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(aWriter);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(aType);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializableType.NativeMethodInfoPtr_Write_Private_Static_Void_BinaryWriter_Type_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CEA9 RID: 52905 RVA: 0x00336234 File Offset: 0x00334434
		[CallerCount(0)]
		public unsafe void OnBeforeSerialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializableType.NativeMethodInfoPtr_OnBeforeSerialize_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CEAA RID: 52906 RVA: 0x00336278 File Offset: 0x00334478
		[CallerCount(0)]
		public unsafe void OnAfterDeserialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializableType.NativeMethodInfoPtr_OnAfterDeserialize_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CEAB RID: 52907 RVA: 0x003362BC File Offset: 0x003344BC
		// Note: this type is marked as 'beforefieldinit'.
		static SerializableType()
		{
			Il2CppClassPointerStore<SerializableType>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Downpour.Scripts.Utilities", "SerializableType");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SerializableType>.NativeClassPtr);
			SerializableType.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, "Type");
			SerializableType.NativeFieldInfoPtr__data = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, "_data");
			SerializableType.NativeMethodInfoPtr__ctor_Public_Void_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679216);
			SerializableType.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679217);
			SerializableType.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679218);
			SerializableType.NativeMethodInfoPtr_Read_Private_Static_Type_BinaryReader_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679219);
			SerializableType.NativeMethodInfoPtr_Write_Private_Static_Void_BinaryWriter_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679220);
			SerializableType.NativeMethodInfoPtr_OnBeforeSerialize_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679221);
			SerializableType.NativeMethodInfoPtr_OnAfterDeserialize_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializableType>.NativeClassPtr, 100679222);
		}

		// Token: 0x0600CEAC RID: 52908 RVA: 0x00002988 File Offset: 0x00000B88
		public SerializableType(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B3F RID: 19263
		// (get) Token: 0x0600CEAD RID: 52909 RVA: 0x003363A0 File Offset: 0x003345A0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SerializableType>.NativeClassPtr));
			}
		}

		// Token: 0x17004B40 RID: 19264
		// (get) Token: 0x0600CEAE RID: 52910 RVA: 0x003363B4 File Offset: 0x003345B4
		// (set) Token: 0x0600CEAF RID: 52911 RVA: 0x003363E8 File Offset: 0x003345E8
		public unsafe Type Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializableType.NativeFieldInfoPtr_Type);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Type(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializableType.NativeFieldInfoPtr_Type), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B41 RID: 19265
		// (get) Token: 0x0600CEB0 RID: 52912 RVA: 0x00336410 File Offset: 0x00334610
		// (set) Token: 0x0600CEB1 RID: 52913 RVA: 0x00336444 File Offset: 0x00334644
		public unsafe Il2CppStructArray<byte> _data
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializableType.NativeFieldInfoPtr__data);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializableType.NativeFieldInfoPtr__data), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040082A9 RID: 33449
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x040082AA RID: 33450
		private static readonly IntPtr NativeFieldInfoPtr__data;

		// Token: 0x040082AB RID: 33451
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Type_0;

		// Token: 0x040082AC RID: 33452
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040082AD RID: 33453
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040082AE RID: 33454
		private static readonly IntPtr NativeMethodInfoPtr_Read_Private_Static_Type_BinaryReader_0;

		// Token: 0x040082AF RID: 33455
		private static readonly IntPtr NativeMethodInfoPtr_Write_Private_Static_Void_BinaryWriter_Type_0;

		// Token: 0x040082B0 RID: 33456
		private static readonly IntPtr NativeMethodInfoPtr_OnBeforeSerialize_Public_Virtual_Final_New_Void_0;

		// Token: 0x040082B1 RID: 33457
		private static readonly IntPtr NativeMethodInfoPtr_OnAfterDeserialize_Public_Virtual_Final_New_Void_0;
	}
}
