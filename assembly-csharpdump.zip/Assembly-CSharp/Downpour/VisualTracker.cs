﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace Downpour
{
	// Token: 0x0200098E RID: 2446
	public static class VisualTracker : Il2CppSystem.Object
	{
		// Token: 0x0600CE7D RID: 52861 RVA: 0x00335574 File Offset: 0x00333774
		[CallerCount(0)]
		public unsafe static void Increment(Material mat)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(mat);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualTracker.NativeMethodInfoPtr_Increment_Public_Static_Void_Material_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE7E RID: 52862 RVA: 0x003355C0 File Offset: 0x003337C0
		[CallerCount(0)]
		public unsafe static void Decrement(Material mat)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(mat);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualTracker.NativeMethodInfoPtr_Decrement_Public_Static_Void_Material_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE7F RID: 52863 RVA: 0x0033560C File Offset: 0x0033380C
		[CallerCount(0)]
		public unsafe static void Snapshot()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualTracker.NativeMethodInfoPtr_Snapshot_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE80 RID: 52864 RVA: 0x00335640 File Offset: 0x00333840
		[CallerCount(0)]
		public unsafe static void DiffAgainstSnapshot()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisualTracker.NativeMethodInfoPtr_DiffAgainstSnapshot_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE81 RID: 52865 RVA: 0x00335674 File Offset: 0x00333874
		// Note: this type is marked as 'beforefieldinit'.
		static VisualTracker()
		{
			Il2CppClassPointerStore<VisualTracker>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "Downpour", "VisualTracker");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr);
			VisualTracker.NativeFieldInfoPtr__balances = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, "_balances");
			VisualTracker.NativeFieldInfoPtr__snapshot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, "_snapshot");
			VisualTracker.NativeMethodInfoPtr_Increment_Public_Static_Void_Material_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, 100679200);
			VisualTracker.NativeMethodInfoPtr_Decrement_Public_Static_Void_Material_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, 100679201);
			VisualTracker.NativeMethodInfoPtr_Snapshot_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, 100679202);
			VisualTracker.NativeMethodInfoPtr_DiffAgainstSnapshot_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr, 100679203);
		}

		// Token: 0x0600CE82 RID: 52866 RVA: 0x00002988 File Offset: 0x00000B88
		public VisualTracker(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B33 RID: 19251
		// (get) Token: 0x0600CE83 RID: 52867 RVA: 0x0033571C File Offset: 0x0033391C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisualTracker>.NativeClassPtr));
			}
		}

		// Token: 0x17004B34 RID: 19252
		// (get) Token: 0x0600CE84 RID: 52868 RVA: 0x00335730 File Offset: 0x00333930
		// (set) Token: 0x0600CE85 RID: 52869 RVA: 0x0033575B File Offset: 0x0033395B
		public unsafe static Dictionary<string, int> _balances
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(VisualTracker.NativeFieldInfoPtr__balances, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, int>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VisualTracker.NativeFieldInfoPtr__balances, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B35 RID: 19253
		// (get) Token: 0x0600CE86 RID: 52870 RVA: 0x00335770 File Offset: 0x00333970
		// (set) Token: 0x0600CE87 RID: 52871 RVA: 0x0033579B File Offset: 0x0033399B
		public unsafe static Dictionary<string, int> _snapshot
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(VisualTracker.NativeFieldInfoPtr__snapshot, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<string, int>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VisualTracker.NativeFieldInfoPtr__snapshot, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008294 RID: 33428
		private static readonly IntPtr NativeFieldInfoPtr__balances;

		// Token: 0x04008295 RID: 33429
		private static readonly IntPtr NativeFieldInfoPtr__snapshot;

		// Token: 0x04008296 RID: 33430
		private static readonly IntPtr NativeMethodInfoPtr_Increment_Public_Static_Void_Material_0;

		// Token: 0x04008297 RID: 33431
		private static readonly IntPtr NativeMethodInfoPtr_Decrement_Public_Static_Void_Material_0;

		// Token: 0x04008298 RID: 33432
		private static readonly IntPtr NativeMethodInfoPtr_Snapshot_Public_Static_Void_0;

		// Token: 0x04008299 RID: 33433
		private static readonly IntPtr NativeMethodInfoPtr_DiffAgainstSnapshot_Public_Static_Void_0;
	}
}
