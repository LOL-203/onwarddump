﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000174 RID: 372
public class CameraFollow : MonoBehaviour
{
	// Token: 0x060018C1 RID: 6337 RVA: 0x00063028 File Offset: 0x00061228
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraFollow.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018C2 RID: 6338 RVA: 0x0006306C File Offset: 0x0006126C
	[CallerCount(0)]
	public unsafe CameraFollow() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraFollow.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018C3 RID: 6339 RVA: 0x000630B8 File Offset: 0x000612B8
	// Note: this type is marked as 'beforefieldinit'.
	static CameraFollow()
	{
		Il2CppClassPointerStore<CameraFollow>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraFollow");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr);
		CameraFollow.NativeFieldInfoPtr_VRCameraPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr, "VRCameraPos");
		CameraFollow.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr, 100665279);
		CameraFollow.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr, 100665280);
	}

	// Token: 0x060018C4 RID: 6340 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraFollow(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700088E RID: 2190
	// (get) Token: 0x060018C5 RID: 6341 RVA: 0x00063124 File Offset: 0x00061324
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraFollow>.NativeClassPtr));
		}
	}

	// Token: 0x1700088F RID: 2191
	// (get) Token: 0x060018C6 RID: 6342 RVA: 0x00063138 File Offset: 0x00061338
	// (set) Token: 0x060018C7 RID: 6343 RVA: 0x0006316C File Offset: 0x0006136C
	public unsafe GameObject VRCameraPos
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraFollow.NativeFieldInfoPtr_VRCameraPos);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraFollow.NativeFieldInfoPtr_VRCameraPos), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000FF7 RID: 4087
	private static readonly IntPtr NativeFieldInfoPtr_VRCameraPos;

	// Token: 0x04000FF8 RID: 4088
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04000FF9 RID: 4089
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
