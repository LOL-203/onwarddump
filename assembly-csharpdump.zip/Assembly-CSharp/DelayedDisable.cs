﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200048B RID: 1163
public class DelayedDisable : MonoBehaviour
{
	// Token: 0x06005D28 RID: 23848 RVA: 0x001748D4 File Offset: 0x00172AD4
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DelayedDisable.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D29 RID: 23849 RVA: 0x00174918 File Offset: 0x00172B18
	[CallerCount(0)]
	public unsafe void Destroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DelayedDisable.NativeMethodInfoPtr_Destroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D2A RID: 23850 RVA: 0x0017495C File Offset: 0x00172B5C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DelayedDisable.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D2B RID: 23851 RVA: 0x001749A0 File Offset: 0x00172BA0
	[CallerCount(0)]
	public unsafe DelayedDisable() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DelayedDisable.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D2C RID: 23852 RVA: 0x001749EC File Offset: 0x00172BEC
	// Note: this type is marked as 'beforefieldinit'.
	static DelayedDisable()
	{
		Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DelayedDisable");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr);
		DelayedDisable.NativeFieldInfoPtr_DestroyTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr, "DestroyTime");
		DelayedDisable.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr, 100670638);
		DelayedDisable.NativeMethodInfoPtr_Destroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr, 100670639);
		DelayedDisable.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr, 100670640);
		DelayedDisable.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr, 100670641);
	}

	// Token: 0x06005D2D RID: 23853 RVA: 0x0000210C File Offset: 0x0000030C
	public DelayedDisable(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002120 RID: 8480
	// (get) Token: 0x06005D2E RID: 23854 RVA: 0x00174A80 File Offset: 0x00172C80
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DelayedDisable>.NativeClassPtr));
		}
	}

	// Token: 0x17002121 RID: 8481
	// (get) Token: 0x06005D2F RID: 23855 RVA: 0x00174A94 File Offset: 0x00172C94
	// (set) Token: 0x06005D30 RID: 23856 RVA: 0x00174ABC File Offset: 0x00172CBC
	public unsafe float DestroyTime
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DelayedDisable.NativeFieldInfoPtr_DestroyTime);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DelayedDisable.NativeFieldInfoPtr_DestroyTime)) = value;
		}
	}

	// Token: 0x04003AD8 RID: 15064
	private static readonly IntPtr NativeFieldInfoPtr_DestroyTime;

	// Token: 0x04003AD9 RID: 15065
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04003ADA RID: 15066
	private static readonly IntPtr NativeMethodInfoPtr_Destroy_Private_Void_0;

	// Token: 0x04003ADB RID: 15067
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04003ADC RID: 15068
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
