﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000175 RID: 373
public class CameraPosRotFollow : MonoBehaviour
{
	// Token: 0x060018C8 RID: 6344 RVA: 0x00063194 File Offset: 0x00061394
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018C9 RID: 6345 RVA: 0x000631D8 File Offset: 0x000613D8
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CA RID: 6346 RVA: 0x0006321C File Offset: 0x0006141C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CB RID: 6347 RVA: 0x00063260 File Offset: 0x00061460
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CC RID: 6348 RVA: 0x000632A4 File Offset: 0x000614A4
	[CallerCount(0)]
	public unsafe void LateUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_LateUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CD RID: 6349 RVA: 0x000632E8 File Offset: 0x000614E8
	[CallerCount(0)]
	public unsafe void OnCameraPreRender(Camera cam)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(cam);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr_OnCameraPreRender_Private_Void_Camera_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CE RID: 6350 RVA: 0x00063344 File Offset: 0x00061544
	[CallerCount(0)]
	public unsafe CameraPosRotFollow() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraPosRotFollow.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018CF RID: 6351 RVA: 0x00063390 File Offset: 0x00061590
	// Note: this type is marked as 'beforefieldinit'.
	static CameraPosRotFollow()
	{
		Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraPosRotFollow");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr);
		CameraPosRotFollow.NativeFieldInfoPtr_Cam = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, "Cam");
		CameraPosRotFollow.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665281);
		CameraPosRotFollow.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665282);
		CameraPosRotFollow.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665283);
		CameraPosRotFollow.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665284);
		CameraPosRotFollow.NativeMethodInfoPtr_LateUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665285);
		CameraPosRotFollow.NativeMethodInfoPtr_OnCameraPreRender_Private_Void_Camera_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665286);
		CameraPosRotFollow.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr, 100665287);
	}

	// Token: 0x060018D0 RID: 6352 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraPosRotFollow(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000890 RID: 2192
	// (get) Token: 0x060018D1 RID: 6353 RVA: 0x00063460 File Offset: 0x00061660
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraPosRotFollow>.NativeClassPtr));
		}
	}

	// Token: 0x17000891 RID: 2193
	// (get) Token: 0x060018D2 RID: 6354 RVA: 0x00063474 File Offset: 0x00061674
	// (set) Token: 0x060018D3 RID: 6355 RVA: 0x000634A8 File Offset: 0x000616A8
	public unsafe Camera Cam
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraPosRotFollow.NativeFieldInfoPtr_Cam);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraPosRotFollow.NativeFieldInfoPtr_Cam), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000FFA RID: 4090
	private static readonly IntPtr NativeFieldInfoPtr_Cam;

	// Token: 0x04000FFB RID: 4091
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04000FFC RID: 4092
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04000FFD RID: 4093
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04000FFE RID: 4094
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04000FFF RID: 4095
	private static readonly IntPtr NativeMethodInfoPtr_LateUpdate_Private_Void_0;

	// Token: 0x04001000 RID: 4096
	private static readonly IntPtr NativeMethodInfoPtr_OnCameraPreRender_Private_Void_Camera_0;

	// Token: 0x04001001 RID: 4097
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
