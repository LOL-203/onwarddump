﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnhollowerRuntimeLib;
using UnityEngine;

// Token: 0x020005A1 RID: 1441
public class ConcaveCollider : MonoBehaviour
{
	// Token: 0x060075A0 RID: 30112 RVA: 0x001D9E48 File Offset: 0x001D8048
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A1 RID: 30113 RVA: 0x001D9E8C File Offset: 0x001D808C
	[CallerCount(0)]
	public unsafe void Reset()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_Reset_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A2 RID: 30114 RVA: 0x001D9ED0 File Offset: 0x001D80D0
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A3 RID: 30115 RVA: 0x001D9F14 File Offset: 0x001D8114
	[CallerCount(0)]
	public unsafe void DestroyHulls()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_DestroyHulls_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A4 RID: 30116 RVA: 0x001D9F58 File Offset: 0x001D8158
	[CallerCount(0)]
	public unsafe void CancelComputation()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_CancelComputation_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A5 RID: 30117 RVA: 0x001D9F9C File Offset: 0x001D819C
	[CallerCount(0)]
	public unsafe int GetLargestHullVertices()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_GetLargestHullVertices_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060075A6 RID: 30118 RVA: 0x001D9FEC File Offset: 0x001D81EC
	[CallerCount(0)]
	public unsafe int GetLargestHullFaces()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_GetLargestHullFaces_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060075A7 RID: 30119 RVA: 0x001DA03C File Offset: 0x001D823C
	[CallerCount(0)]
	public unsafe static void DllInit(bool bUseMultithreading)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref bUseMultithreading;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_DllInit_Private_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A8 RID: 30120 RVA: 0x001DA084 File Offset: 0x001D8284
	[CallerCount(0)]
	public unsafe static void DllClose()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_DllClose_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075A9 RID: 30121 RVA: 0x001DA0B8 File Offset: 0x001D82B8
	[CallerCount(0)]
	public unsafe static void SetLogFunctionPointer(IntPtr pfnUnity3DLog)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref pfnUnity3DLog;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_SetLogFunctionPointer_Private_Static_Void_IntPtr_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075AA RID: 30122 RVA: 0x001DA100 File Offset: 0x001D8300
	[CallerCount(0)]
	public unsafe static void SetProgressFunctionPointer(IntPtr pfnUnity3DProgress)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref pfnUnity3DProgress;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_SetProgressFunctionPointer_Private_Static_Void_IntPtr_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075AB RID: 30123 RVA: 0x001DA148 File Offset: 0x001D8348
	[CallerCount(0)]
	public unsafe static void CancelConvexDecomposition()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_CancelConvexDecomposition_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075AC RID: 30124 RVA: 0x001DA17C File Offset: 0x001D837C
	[CallerCount(0)]
	public unsafe static bool DoConvexDecomposition(ref ConcaveCollider.SConvexDecompositionInfoInOut infoInOut, Il2CppStructArray<Vector3> pfVertices, Il2CppStructArray<int> puIndices)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &infoInOut;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(pfVertices);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(puIndices);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_DoConvexDecomposition_Private_Static_Boolean_byref_SConvexDecompositionInfoInOut_ArrayOf_Vector3_ArrayOf_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060075AD RID: 30125 RVA: 0x001DA200 File Offset: 0x001D8400
	[CallerCount(0)]
	public unsafe static bool GetHullInfo(uint uHullIndex, ref ConcaveCollider.SConvexDecompositionHullInfo infoOut)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref uHullIndex;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &infoOut;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_GetHullInfo_Private_Static_Boolean_UInt32_byref_SConvexDecompositionHullInfo_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060075AE RID: 30126 RVA: 0x001DA268 File Offset: 0x001D8468
	[CallerCount(0)]
	public unsafe static bool FillHullMeshData(uint uHullIndex, ref float pfVolumeOut, Il2CppStructArray<int> pnIndicesOut, Il2CppStructArray<Vector3> pfVerticesOut)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref uHullIndex;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &pfVolumeOut;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(pnIndicesOut);
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(pfVerticesOut);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr_FillHullMeshData_Private_Static_Boolean_UInt32_byref_Single_ArrayOf_Int32_ArrayOf_Vector3_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060075AF RID: 30127 RVA: 0x001DA300 File Offset: 0x001D8500
	[CallerCount(0)]
	public unsafe ConcaveCollider() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060075B0 RID: 30128 RVA: 0x001DA34C File Offset: 0x001D854C
	// Note: this type is marked as 'beforefieldinit'.
	static ConcaveCollider()
	{
		Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConcaveCollider");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr);
		ConcaveCollider.NativeFieldInfoPtr_Algorithm = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "Algorithm");
		ConcaveCollider.NativeFieldInfoPtr_MaxHullVertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "MaxHullVertices");
		ConcaveCollider.NativeFieldInfoPtr_MaxHulls = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "MaxHulls");
		ConcaveCollider.NativeFieldInfoPtr_InternalScale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "InternalScale");
		ConcaveCollider.NativeFieldInfoPtr_Precision = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "Precision");
		ConcaveCollider.NativeFieldInfoPtr_CreateMeshAssets = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "CreateMeshAssets");
		ConcaveCollider.NativeFieldInfoPtr_CreateHullMesh = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "CreateHullMesh");
		ConcaveCollider.NativeFieldInfoPtr_DebugLog = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "DebugLog");
		ConcaveCollider.NativeFieldInfoPtr_LegacyDepth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LegacyDepth");
		ConcaveCollider.NativeFieldInfoPtr_ShowAdvancedOptions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "ShowAdvancedOptions");
		ConcaveCollider.NativeFieldInfoPtr_MinHullVolume = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "MinHullVolume");
		ConcaveCollider.NativeFieldInfoPtr_BackFaceDistanceFactor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "BackFaceDistanceFactor");
		ConcaveCollider.NativeFieldInfoPtr_NormalizeInputMesh = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "NormalizeInputMesh");
		ConcaveCollider.NativeFieldInfoPtr_ForceNoMultithreading = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "ForceNoMultithreading");
		ConcaveCollider.NativeFieldInfoPtr_PhysMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "PhysMaterial");
		ConcaveCollider.NativeFieldInfoPtr_IsTrigger = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "IsTrigger");
		ConcaveCollider.NativeFieldInfoPtr_m_aGoHulls = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "m_aGoHulls");
		ConcaveCollider.NativeFieldInfoPtr_LastMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LastMaterial");
		ConcaveCollider.NativeFieldInfoPtr_LastIsTrigger = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LastIsTrigger");
		ConcaveCollider.NativeFieldInfoPtr_LargestHullVertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LargestHullVertices");
		ConcaveCollider.NativeFieldInfoPtr_LargestHullFaces = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LargestHullFaces");
		ConcaveCollider.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672666);
		ConcaveCollider.NativeMethodInfoPtr_Reset_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672667);
		ConcaveCollider.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672668);
		ConcaveCollider.NativeMethodInfoPtr_DestroyHulls_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672669);
		ConcaveCollider.NativeMethodInfoPtr_CancelComputation_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672670);
		ConcaveCollider.NativeMethodInfoPtr_GetLargestHullVertices_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672671);
		ConcaveCollider.NativeMethodInfoPtr_GetLargestHullFaces_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672672);
		ConcaveCollider.NativeMethodInfoPtr_DllInit_Private_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672673);
		ConcaveCollider.NativeMethodInfoPtr_DllClose_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672674);
		ConcaveCollider.NativeMethodInfoPtr_SetLogFunctionPointer_Private_Static_Void_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672675);
		ConcaveCollider.NativeMethodInfoPtr_SetProgressFunctionPointer_Private_Static_Void_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672676);
		ConcaveCollider.NativeMethodInfoPtr_CancelConvexDecomposition_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672677);
		ConcaveCollider.NativeMethodInfoPtr_DoConvexDecomposition_Private_Static_Boolean_byref_SConvexDecompositionInfoInOut_ArrayOf_Vector3_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672678);
		ConcaveCollider.NativeMethodInfoPtr_GetHullInfo_Private_Static_Boolean_UInt32_byref_SConvexDecompositionHullInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672679);
		ConcaveCollider.NativeMethodInfoPtr_FillHullMeshData_Private_Static_Boolean_UInt32_byref_Single_ArrayOf_Int32_ArrayOf_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672680);
		ConcaveCollider.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, 100672681);
	}

	// Token: 0x060075B1 RID: 30129 RVA: 0x0000210C File Offset: 0x0000030C
	public ConcaveCollider(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002A1F RID: 10783
	// (get) Token: 0x060075B2 RID: 30130 RVA: 0x001DA660 File Offset: 0x001D8860
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr));
		}
	}

	// Token: 0x17002A20 RID: 10784
	// (get) Token: 0x060075B3 RID: 30131 RVA: 0x001DA674 File Offset: 0x001D8874
	// (set) Token: 0x060075B4 RID: 30132 RVA: 0x001DA69C File Offset: 0x001D889C
	public unsafe ConcaveCollider.EAlgorithm Algorithm
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_Algorithm);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_Algorithm)) = value;
		}
	}

	// Token: 0x17002A21 RID: 10785
	// (get) Token: 0x060075B5 RID: 30133 RVA: 0x001DA6C0 File Offset: 0x001D88C0
	// (set) Token: 0x060075B6 RID: 30134 RVA: 0x001DA6E8 File Offset: 0x001D88E8
	public unsafe int MaxHullVertices
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MaxHullVertices);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MaxHullVertices)) = value;
		}
	}

	// Token: 0x17002A22 RID: 10786
	// (get) Token: 0x060075B7 RID: 30135 RVA: 0x001DA70C File Offset: 0x001D890C
	// (set) Token: 0x060075B8 RID: 30136 RVA: 0x001DA734 File Offset: 0x001D8934
	public unsafe int MaxHulls
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MaxHulls);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MaxHulls)) = value;
		}
	}

	// Token: 0x17002A23 RID: 10787
	// (get) Token: 0x060075B9 RID: 30137 RVA: 0x001DA758 File Offset: 0x001D8958
	// (set) Token: 0x060075BA RID: 30138 RVA: 0x001DA780 File Offset: 0x001D8980
	public unsafe float InternalScale
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_InternalScale);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_InternalScale)) = value;
		}
	}

	// Token: 0x17002A24 RID: 10788
	// (get) Token: 0x060075BB RID: 30139 RVA: 0x001DA7A4 File Offset: 0x001D89A4
	// (set) Token: 0x060075BC RID: 30140 RVA: 0x001DA7CC File Offset: 0x001D89CC
	public unsafe float Precision
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_Precision);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_Precision)) = value;
		}
	}

	// Token: 0x17002A25 RID: 10789
	// (get) Token: 0x060075BD RID: 30141 RVA: 0x001DA7F0 File Offset: 0x001D89F0
	// (set) Token: 0x060075BE RID: 30142 RVA: 0x001DA818 File Offset: 0x001D8A18
	public unsafe bool CreateMeshAssets
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_CreateMeshAssets);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_CreateMeshAssets)) = value;
		}
	}

	// Token: 0x17002A26 RID: 10790
	// (get) Token: 0x060075BF RID: 30143 RVA: 0x001DA83C File Offset: 0x001D8A3C
	// (set) Token: 0x060075C0 RID: 30144 RVA: 0x001DA864 File Offset: 0x001D8A64
	public unsafe bool CreateHullMesh
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_CreateHullMesh);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_CreateHullMesh)) = value;
		}
	}

	// Token: 0x17002A27 RID: 10791
	// (get) Token: 0x060075C1 RID: 30145 RVA: 0x001DA888 File Offset: 0x001D8A88
	// (set) Token: 0x060075C2 RID: 30146 RVA: 0x001DA8B0 File Offset: 0x001D8AB0
	public unsafe bool DebugLog
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_DebugLog);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_DebugLog)) = value;
		}
	}

	// Token: 0x17002A28 RID: 10792
	// (get) Token: 0x060075C3 RID: 30147 RVA: 0x001DA8D4 File Offset: 0x001D8AD4
	// (set) Token: 0x060075C4 RID: 30148 RVA: 0x001DA8FC File Offset: 0x001D8AFC
	public unsafe int LegacyDepth
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LegacyDepth);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LegacyDepth)) = value;
		}
	}

	// Token: 0x17002A29 RID: 10793
	// (get) Token: 0x060075C5 RID: 30149 RVA: 0x001DA920 File Offset: 0x001D8B20
	// (set) Token: 0x060075C6 RID: 30150 RVA: 0x001DA948 File Offset: 0x001D8B48
	public unsafe bool ShowAdvancedOptions
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_ShowAdvancedOptions);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_ShowAdvancedOptions)) = value;
		}
	}

	// Token: 0x17002A2A RID: 10794
	// (get) Token: 0x060075C7 RID: 30151 RVA: 0x001DA96C File Offset: 0x001D8B6C
	// (set) Token: 0x060075C8 RID: 30152 RVA: 0x001DA994 File Offset: 0x001D8B94
	public unsafe float MinHullVolume
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MinHullVolume);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_MinHullVolume)) = value;
		}
	}

	// Token: 0x17002A2B RID: 10795
	// (get) Token: 0x060075C9 RID: 30153 RVA: 0x001DA9B8 File Offset: 0x001D8BB8
	// (set) Token: 0x060075CA RID: 30154 RVA: 0x001DA9E0 File Offset: 0x001D8BE0
	public unsafe float BackFaceDistanceFactor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_BackFaceDistanceFactor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_BackFaceDistanceFactor)) = value;
		}
	}

	// Token: 0x17002A2C RID: 10796
	// (get) Token: 0x060075CB RID: 30155 RVA: 0x001DAA04 File Offset: 0x001D8C04
	// (set) Token: 0x060075CC RID: 30156 RVA: 0x001DAA2C File Offset: 0x001D8C2C
	public unsafe bool NormalizeInputMesh
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_NormalizeInputMesh);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_NormalizeInputMesh)) = value;
		}
	}

	// Token: 0x17002A2D RID: 10797
	// (get) Token: 0x060075CD RID: 30157 RVA: 0x001DAA50 File Offset: 0x001D8C50
	// (set) Token: 0x060075CE RID: 30158 RVA: 0x001DAA78 File Offset: 0x001D8C78
	public unsafe bool ForceNoMultithreading
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_ForceNoMultithreading);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_ForceNoMultithreading)) = value;
		}
	}

	// Token: 0x17002A2E RID: 10798
	// (get) Token: 0x060075CF RID: 30159 RVA: 0x001DAA9C File Offset: 0x001D8C9C
	// (set) Token: 0x060075D0 RID: 30160 RVA: 0x001DAAD0 File Offset: 0x001D8CD0
	public unsafe PhysicMaterial PhysMaterial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_PhysMaterial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new PhysicMaterial(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_PhysMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002A2F RID: 10799
	// (get) Token: 0x060075D1 RID: 30161 RVA: 0x001DAAF8 File Offset: 0x001D8CF8
	// (set) Token: 0x060075D2 RID: 30162 RVA: 0x001DAB20 File Offset: 0x001D8D20
	public unsafe bool IsTrigger
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_IsTrigger);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_IsTrigger)) = value;
		}
	}

	// Token: 0x17002A30 RID: 10800
	// (get) Token: 0x060075D3 RID: 30163 RVA: 0x001DAB44 File Offset: 0x001D8D44
	// (set) Token: 0x060075D4 RID: 30164 RVA: 0x001DAB78 File Offset: 0x001D8D78
	public unsafe Il2CppReferenceArray<GameObject> m_aGoHulls
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_m_aGoHulls);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_m_aGoHulls), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002A31 RID: 10801
	// (get) Token: 0x060075D5 RID: 30165 RVA: 0x001DABA0 File Offset: 0x001D8DA0
	// (set) Token: 0x060075D6 RID: 30166 RVA: 0x001DABD4 File Offset: 0x001D8DD4
	public unsafe PhysicMaterial LastMaterial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LastMaterial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new PhysicMaterial(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LastMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002A32 RID: 10802
	// (get) Token: 0x060075D7 RID: 30167 RVA: 0x001DABFC File Offset: 0x001D8DFC
	// (set) Token: 0x060075D8 RID: 30168 RVA: 0x001DAC24 File Offset: 0x001D8E24
	public unsafe bool LastIsTrigger
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LastIsTrigger);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LastIsTrigger)) = value;
		}
	}

	// Token: 0x17002A33 RID: 10803
	// (get) Token: 0x060075D9 RID: 30169 RVA: 0x001DAC48 File Offset: 0x001D8E48
	// (set) Token: 0x060075DA RID: 30170 RVA: 0x001DAC70 File Offset: 0x001D8E70
	public unsafe int LargestHullVertices
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LargestHullVertices);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LargestHullVertices)) = value;
		}
	}

	// Token: 0x17002A34 RID: 10804
	// (get) Token: 0x060075DB RID: 30171 RVA: 0x001DAC94 File Offset: 0x001D8E94
	// (set) Token: 0x060075DC RID: 30172 RVA: 0x001DACBC File Offset: 0x001D8EBC
	public unsafe int LargestHullFaces
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LargestHullFaces);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConcaveCollider.NativeFieldInfoPtr_LargestHullFaces)) = value;
		}
	}

	// Token: 0x04004B3D RID: 19261
	private static readonly IntPtr NativeFieldInfoPtr_Algorithm;

	// Token: 0x04004B3E RID: 19262
	private static readonly IntPtr NativeFieldInfoPtr_MaxHullVertices;

	// Token: 0x04004B3F RID: 19263
	private static readonly IntPtr NativeFieldInfoPtr_MaxHulls;

	// Token: 0x04004B40 RID: 19264
	private static readonly IntPtr NativeFieldInfoPtr_InternalScale;

	// Token: 0x04004B41 RID: 19265
	private static readonly IntPtr NativeFieldInfoPtr_Precision;

	// Token: 0x04004B42 RID: 19266
	private static readonly IntPtr NativeFieldInfoPtr_CreateMeshAssets;

	// Token: 0x04004B43 RID: 19267
	private static readonly IntPtr NativeFieldInfoPtr_CreateHullMesh;

	// Token: 0x04004B44 RID: 19268
	private static readonly IntPtr NativeFieldInfoPtr_DebugLog;

	// Token: 0x04004B45 RID: 19269
	private static readonly IntPtr NativeFieldInfoPtr_LegacyDepth;

	// Token: 0x04004B46 RID: 19270
	private static readonly IntPtr NativeFieldInfoPtr_ShowAdvancedOptions;

	// Token: 0x04004B47 RID: 19271
	private static readonly IntPtr NativeFieldInfoPtr_MinHullVolume;

	// Token: 0x04004B48 RID: 19272
	private static readonly IntPtr NativeFieldInfoPtr_BackFaceDistanceFactor;

	// Token: 0x04004B49 RID: 19273
	private static readonly IntPtr NativeFieldInfoPtr_NormalizeInputMesh;

	// Token: 0x04004B4A RID: 19274
	private static readonly IntPtr NativeFieldInfoPtr_ForceNoMultithreading;

	// Token: 0x04004B4B RID: 19275
	private static readonly IntPtr NativeFieldInfoPtr_PhysMaterial;

	// Token: 0x04004B4C RID: 19276
	private static readonly IntPtr NativeFieldInfoPtr_IsTrigger;

	// Token: 0x04004B4D RID: 19277
	private static readonly IntPtr NativeFieldInfoPtr_m_aGoHulls;

	// Token: 0x04004B4E RID: 19278
	private static readonly IntPtr NativeFieldInfoPtr_LastMaterial;

	// Token: 0x04004B4F RID: 19279
	private static readonly IntPtr NativeFieldInfoPtr_LastIsTrigger;

	// Token: 0x04004B50 RID: 19280
	private static readonly IntPtr NativeFieldInfoPtr_LargestHullVertices;

	// Token: 0x04004B51 RID: 19281
	private static readonly IntPtr NativeFieldInfoPtr_LargestHullFaces;

	// Token: 0x04004B52 RID: 19282
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04004B53 RID: 19283
	private static readonly IntPtr NativeMethodInfoPtr_Reset_Private_Void_0;

	// Token: 0x04004B54 RID: 19284
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04004B55 RID: 19285
	private static readonly IntPtr NativeMethodInfoPtr_DestroyHulls_Public_Void_0;

	// Token: 0x04004B56 RID: 19286
	private static readonly IntPtr NativeMethodInfoPtr_CancelComputation_Public_Void_0;

	// Token: 0x04004B57 RID: 19287
	private static readonly IntPtr NativeMethodInfoPtr_GetLargestHullVertices_Public_Int32_0;

	// Token: 0x04004B58 RID: 19288
	private static readonly IntPtr NativeMethodInfoPtr_GetLargestHullFaces_Public_Int32_0;

	// Token: 0x04004B59 RID: 19289
	private static readonly IntPtr NativeMethodInfoPtr_DllInit_Private_Static_Void_Boolean_0;

	// Token: 0x04004B5A RID: 19290
	private static readonly IntPtr NativeMethodInfoPtr_DllClose_Private_Static_Void_0;

	// Token: 0x04004B5B RID: 19291
	private static readonly IntPtr NativeMethodInfoPtr_SetLogFunctionPointer_Private_Static_Void_IntPtr_0;

	// Token: 0x04004B5C RID: 19292
	private static readonly IntPtr NativeMethodInfoPtr_SetProgressFunctionPointer_Private_Static_Void_IntPtr_0;

	// Token: 0x04004B5D RID: 19293
	private static readonly IntPtr NativeMethodInfoPtr_CancelConvexDecomposition_Private_Static_Void_0;

	// Token: 0x04004B5E RID: 19294
	private static readonly IntPtr NativeMethodInfoPtr_DoConvexDecomposition_Private_Static_Boolean_byref_SConvexDecompositionInfoInOut_ArrayOf_Vector3_ArrayOf_Int32_0;

	// Token: 0x04004B5F RID: 19295
	private static readonly IntPtr NativeMethodInfoPtr_GetHullInfo_Private_Static_Boolean_UInt32_byref_SConvexDecompositionHullInfo_0;

	// Token: 0x04004B60 RID: 19296
	private static readonly IntPtr NativeMethodInfoPtr_FillHullMeshData_Private_Static_Boolean_UInt32_byref_Single_ArrayOf_Int32_ArrayOf_Vector3_0;

	// Token: 0x04004B61 RID: 19297
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020005A2 RID: 1442
	public enum EAlgorithm
	{
		// Token: 0x04004B63 RID: 19299
		Normal,
		// Token: 0x04004B64 RID: 19300
		Fast,
		// Token: 0x04004B65 RID: 19301
		Legacy
	}

	// Token: 0x020005A3 RID: 1443
	public sealed class LogDelegate : MulticastDelegate
	{
		// Token: 0x060075DF RID: 30175 RVA: 0x001DAD04 File Offset: 0x001D8F04
		[CallerCount(0)]
		public unsafe LogDelegate(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.LogDelegate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075E0 RID: 30176 RVA: 0x001DAD7C File Offset: 0x001D8F7C
		[CallerCount(0)]
		public unsafe void Invoke(string message)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.LogDelegate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075E1 RID: 30177 RVA: 0x001DADD8 File Offset: 0x001D8FD8
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(string message, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.LogDelegate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060075E2 RID: 30178 RVA: 0x001DAE78 File Offset: 0x001D9078
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.LogDelegate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075E3 RID: 30179 RVA: 0x001DAED4 File Offset: 0x001D90D4
		// Note: this type is marked as 'beforefieldinit'.
		static LogDelegate()
		{
			Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "LogDelegate");
			ConcaveCollider.LogDelegate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr, 100672682);
			ConcaveCollider.LogDelegate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr, 100672683);
			ConcaveCollider.LogDelegate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr, 100672684);
			ConcaveCollider.LogDelegate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr, 100672685);
		}

		// Token: 0x060075E4 RID: 30180 RVA: 0x00005E35 File Offset: 0x00004035
		public LogDelegate(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002A36 RID: 10806
		// (get) Token: 0x060075E5 RID: 30181 RVA: 0x001DAF45 File Offset: 0x001D9145
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcaveCollider.LogDelegate>.NativeClassPtr));
			}
		}

		// Token: 0x060075E6 RID: 30182 RVA: 0x001DAF56 File Offset: 0x001D9156
		public static implicit operator ConcaveCollider.LogDelegate(Action<string> A_0)
		{
			return DelegateSupport.ConvertDelegate<ConcaveCollider.LogDelegate>(A_0);
		}

		// Token: 0x060075E7 RID: 30183 RVA: 0x001DAF5E File Offset: 0x001D915E
		public static ConcaveCollider.LogDelegate operator +(ConcaveCollider.LogDelegate A_0, ConcaveCollider.LogDelegate A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<ConcaveCollider.LogDelegate>();
		}

		// Token: 0x060075E8 RID: 30184 RVA: 0x001DAF6C File Offset: 0x001D916C
		public static ConcaveCollider.LogDelegate operator -(ConcaveCollider.LogDelegate A_0, ConcaveCollider.LogDelegate A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<ConcaveCollider.LogDelegate>();
			}
			return result;
		}

		// Token: 0x04004B66 RID: 19302
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x04004B67 RID: 19303
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_0;

		// Token: 0x04004B68 RID: 19304
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_AsyncCallback_Object_0;

		// Token: 0x04004B69 RID: 19305
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x020005A4 RID: 1444
	public sealed class ProgressDelegate : MulticastDelegate
	{
		// Token: 0x060075E9 RID: 30185 RVA: 0x001DAF80 File Offset: 0x001D9180
		[CallerCount(0)]
		public unsafe ProgressDelegate(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075EA RID: 30186 RVA: 0x001DAFF8 File Offset: 0x001D91F8
		[CallerCount(0)]
		public unsafe void Invoke(string message, float fPercent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref fPercent;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075EB RID: 30187 RVA: 0x001DB064 File Offset: 0x001D9264
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(string message, float fPercent, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref fPercent;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_Single_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060075EC RID: 30188 RVA: 0x001DB114 File Offset: 0x001D9314
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060075ED RID: 30189 RVA: 0x001DB170 File Offset: 0x001D9370
		// Note: this type is marked as 'beforefieldinit'.
		static ProgressDelegate()
		{
			Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "ProgressDelegate");
			ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr, 100672686);
			ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr, 100672687);
			ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_Single_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr, 100672688);
			ConcaveCollider.ProgressDelegate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr, 100672689);
		}

		// Token: 0x060075EE RID: 30190 RVA: 0x00005E35 File Offset: 0x00004035
		public ProgressDelegate(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002A37 RID: 10807
		// (get) Token: 0x060075EF RID: 30191 RVA: 0x001DB1E1 File Offset: 0x001D93E1
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcaveCollider.ProgressDelegate>.NativeClassPtr));
			}
		}

		// Token: 0x060075F0 RID: 30192 RVA: 0x001DB1F2 File Offset: 0x001D93F2
		public static implicit operator ConcaveCollider.ProgressDelegate(Action<string, float> A_0)
		{
			return DelegateSupport.ConvertDelegate<ConcaveCollider.ProgressDelegate>(A_0);
		}

		// Token: 0x060075F1 RID: 30193 RVA: 0x001DB1FA File Offset: 0x001D93FA
		public static ConcaveCollider.ProgressDelegate operator +(ConcaveCollider.ProgressDelegate A_0, ConcaveCollider.ProgressDelegate A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<ConcaveCollider.ProgressDelegate>();
		}

		// Token: 0x060075F2 RID: 30194 RVA: 0x001DB208 File Offset: 0x001D9408
		public static ConcaveCollider.ProgressDelegate operator -(ConcaveCollider.ProgressDelegate A_0, ConcaveCollider.ProgressDelegate A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<ConcaveCollider.ProgressDelegate>();
			}
			return result;
		}

		// Token: 0x04004B6A RID: 19306
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x04004B6B RID: 19307
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_String_Single_0;

		// Token: 0x04004B6C RID: 19308
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_String_Single_AsyncCallback_Object_0;

		// Token: 0x04004B6D RID: 19309
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x020005A5 RID: 1445
	[StructLayout(2)]
	public struct SConvexDecompositionInfoInOut
	{
		// Token: 0x060075F3 RID: 30195 RVA: 0x001DB21C File Offset: 0x001D941C
		// Note: this type is marked as 'beforefieldinit'.
		static SConvexDecompositionInfoInOut()
		{
			Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "SConvexDecompositionInfoInOut");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr);
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uMaxHullVertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uMaxHullVertices");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uMaxHulls = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uMaxHulls");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_fPrecision = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "fPrecision");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_fBackFaceDistanceFactor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "fBackFaceDistanceFactor");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uLegacyDepth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uLegacyDepth");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uNormalizeInputMesh = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uNormalizeInputMesh");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uUseFastVersion = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uUseFastVersion");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uTriangleCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uTriangleCount");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_uVertexCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "uVertexCount");
			ConcaveCollider.SConvexDecompositionInfoInOut.NativeFieldInfoPtr_nHullsOut = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, "nHullsOut");
		}

		// Token: 0x060075F4 RID: 30196 RVA: 0x001DB30F File Offset: 0x001D950F
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr, ref this));
		}

		// Token: 0x17002A38 RID: 10808
		// (get) Token: 0x060075F5 RID: 30197 RVA: 0x001DB321 File Offset: 0x001D9521
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionInfoInOut>.NativeClassPtr));
			}
		}

		// Token: 0x04004B6E RID: 19310
		private static readonly IntPtr NativeFieldInfoPtr_uMaxHullVertices;

		// Token: 0x04004B6F RID: 19311
		private static readonly IntPtr NativeFieldInfoPtr_uMaxHulls;

		// Token: 0x04004B70 RID: 19312
		private static readonly IntPtr NativeFieldInfoPtr_fPrecision;

		// Token: 0x04004B71 RID: 19313
		private static readonly IntPtr NativeFieldInfoPtr_fBackFaceDistanceFactor;

		// Token: 0x04004B72 RID: 19314
		private static readonly IntPtr NativeFieldInfoPtr_uLegacyDepth;

		// Token: 0x04004B73 RID: 19315
		private static readonly IntPtr NativeFieldInfoPtr_uNormalizeInputMesh;

		// Token: 0x04004B74 RID: 19316
		private static readonly IntPtr NativeFieldInfoPtr_uUseFastVersion;

		// Token: 0x04004B75 RID: 19317
		private static readonly IntPtr NativeFieldInfoPtr_uTriangleCount;

		// Token: 0x04004B76 RID: 19318
		private static readonly IntPtr NativeFieldInfoPtr_uVertexCount;

		// Token: 0x04004B77 RID: 19319
		private static readonly IntPtr NativeFieldInfoPtr_nHullsOut;

		// Token: 0x04004B78 RID: 19320
		[FieldOffset(0)]
		public uint uMaxHullVertices;

		// Token: 0x04004B79 RID: 19321
		[FieldOffset(4)]
		public uint uMaxHulls;

		// Token: 0x04004B7A RID: 19322
		[FieldOffset(8)]
		public float fPrecision;

		// Token: 0x04004B7B RID: 19323
		[FieldOffset(12)]
		public float fBackFaceDistanceFactor;

		// Token: 0x04004B7C RID: 19324
		[FieldOffset(16)]
		public uint uLegacyDepth;

		// Token: 0x04004B7D RID: 19325
		[FieldOffset(20)]
		public uint uNormalizeInputMesh;

		// Token: 0x04004B7E RID: 19326
		[FieldOffset(24)]
		public uint uUseFastVersion;

		// Token: 0x04004B7F RID: 19327
		[FieldOffset(28)]
		public uint uTriangleCount;

		// Token: 0x04004B80 RID: 19328
		[FieldOffset(32)]
		public uint uVertexCount;

		// Token: 0x04004B81 RID: 19329
		[FieldOffset(36)]
		public int nHullsOut;
	}

	// Token: 0x020005A6 RID: 1446
	[StructLayout(2)]
	public struct SConvexDecompositionHullInfo
	{
		// Token: 0x060075F6 RID: 30198 RVA: 0x001DB334 File Offset: 0x001D9534
		// Note: this type is marked as 'beforefieldinit'.
		static SConvexDecompositionHullInfo()
		{
			Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConcaveCollider>.NativeClassPtr, "SConvexDecompositionHullInfo");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr);
			ConcaveCollider.SConvexDecompositionHullInfo.NativeFieldInfoPtr_nVertexCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr, "nVertexCount");
			ConcaveCollider.SConvexDecompositionHullInfo.NativeFieldInfoPtr_nTriangleCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr, "nTriangleCount");
		}

		// Token: 0x060075F7 RID: 30199 RVA: 0x001DB387 File Offset: 0x001D9587
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr, ref this));
		}

		// Token: 0x17002A39 RID: 10809
		// (get) Token: 0x060075F8 RID: 30200 RVA: 0x001DB399 File Offset: 0x001D9599
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConcaveCollider.SConvexDecompositionHullInfo>.NativeClassPtr));
			}
		}

		// Token: 0x04004B82 RID: 19330
		private static readonly IntPtr NativeFieldInfoPtr_nVertexCount;

		// Token: 0x04004B83 RID: 19331
		private static readonly IntPtr NativeFieldInfoPtr_nTriangleCount;

		// Token: 0x04004B84 RID: 19332
		[FieldOffset(0)]
		public int nVertexCount;

		// Token: 0x04004B85 RID: 19333
		[FieldOffset(4)]
		public int nTriangleCount;
	}
}
