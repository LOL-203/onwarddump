﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000377 RID: 887
public sealed class DebugLoadDirectlyIntoMap : MonoBehaviour
{
	// Token: 0x060046BA RID: 18106 RVA: 0x0011C15C File Offset: 0x0011A35C
	[CallerCount(0)]
	public unsafe DebugLoadDirectlyIntoMap() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugLoadDirectlyIntoMap.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060046BB RID: 18107 RVA: 0x0011C1A8 File Offset: 0x0011A3A8
	// Note: this type is marked as 'beforefieldinit'.
	static DebugLoadDirectlyIntoMap()
	{
		Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DebugLoadDirectlyIntoMap");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr);
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GameModeToLoad = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "GameModeToLoad");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_MapToSet = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "MapToSet");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GamemodeType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "GamemodeType");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsCompetitiveMode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "IsCompetitiveMode");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_UseESLRuleset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "UseESLRuleset");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SinglePlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "SinglePlayer");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsSpectator = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "IsSpectator");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SpectateSlots = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "SpectateSlots");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_LobbyPassword = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "LobbyPassword");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Username = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "Username");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_NormalLoad = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "NormalLoad");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_RootActivatedGameObjs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "RootActivatedGameObjs");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Initialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "Initialized");
		DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_ShouldReconnect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, "ShouldReconnect");
		DebugLoadDirectlyIntoMap.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr, 100668876);
	}

	// Token: 0x060046BC RID: 18108 RVA: 0x0000210C File Offset: 0x0000030C
	public DebugLoadDirectlyIntoMap(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001930 RID: 6448
	// (get) Token: 0x060046BD RID: 18109 RVA: 0x0011C304 File Offset: 0x0011A504
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugLoadDirectlyIntoMap>.NativeClassPtr));
		}
	}

	// Token: 0x17001931 RID: 6449
	// (get) Token: 0x060046BE RID: 18110 RVA: 0x0011C318 File Offset: 0x0011A518
	// (set) Token: 0x060046BF RID: 18111 RVA: 0x0011C340 File Offset: 0x0011A540
	public unsafe GameVariantTypes GameModeToLoad
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GameModeToLoad);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GameModeToLoad)) = value;
		}
	}

	// Token: 0x17001932 RID: 6450
	// (get) Token: 0x060046C0 RID: 18112 RVA: 0x0011C364 File Offset: 0x0011A564
	// (set) Token: 0x060046C1 RID: 18113 RVA: 0x0011C38C File Offset: 0x0011A58C
	public unsafe OnwardMap MapToSet
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_MapToSet);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_MapToSet)) = value;
		}
	}

	// Token: 0x17001933 RID: 6451
	// (get) Token: 0x060046C2 RID: 18114 RVA: 0x0011C3B0 File Offset: 0x0011A5B0
	// (set) Token: 0x060046C3 RID: 18115 RVA: 0x0011C3D8 File Offset: 0x0011A5D8
	public unsafe GameVariantStyleTypes GamemodeType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GamemodeType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_GamemodeType)) = value;
		}
	}

	// Token: 0x17001934 RID: 6452
	// (get) Token: 0x060046C4 RID: 18116 RVA: 0x0011C3FC File Offset: 0x0011A5FC
	// (set) Token: 0x060046C5 RID: 18117 RVA: 0x0011C424 File Offset: 0x0011A624
	public unsafe bool IsCompetitiveMode
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsCompetitiveMode);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsCompetitiveMode)) = value;
		}
	}

	// Token: 0x17001935 RID: 6453
	// (get) Token: 0x060046C6 RID: 18118 RVA: 0x0011C448 File Offset: 0x0011A648
	// (set) Token: 0x060046C7 RID: 18119 RVA: 0x0011C470 File Offset: 0x0011A670
	public unsafe bool UseESLRuleset
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_UseESLRuleset);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_UseESLRuleset)) = value;
		}
	}

	// Token: 0x17001936 RID: 6454
	// (get) Token: 0x060046C8 RID: 18120 RVA: 0x0011C494 File Offset: 0x0011A694
	// (set) Token: 0x060046C9 RID: 18121 RVA: 0x0011C4BC File Offset: 0x0011A6BC
	public unsafe bool SinglePlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SinglePlayer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SinglePlayer)) = value;
		}
	}

	// Token: 0x17001937 RID: 6455
	// (get) Token: 0x060046CA RID: 18122 RVA: 0x0011C4E0 File Offset: 0x0011A6E0
	// (set) Token: 0x060046CB RID: 18123 RVA: 0x0011C508 File Offset: 0x0011A708
	public unsafe bool IsSpectator
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsSpectator);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_IsSpectator)) = value;
		}
	}

	// Token: 0x17001938 RID: 6456
	// (get) Token: 0x060046CC RID: 18124 RVA: 0x0011C52C File Offset: 0x0011A72C
	// (set) Token: 0x060046CD RID: 18125 RVA: 0x0011C554 File Offset: 0x0011A754
	public unsafe int SpectateSlots
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SpectateSlots);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_SpectateSlots)) = value;
		}
	}

	// Token: 0x17001939 RID: 6457
	// (get) Token: 0x060046CE RID: 18126 RVA: 0x0011C578 File Offset: 0x0011A778
	// (set) Token: 0x060046CF RID: 18127 RVA: 0x0011C5A1 File Offset: 0x0011A7A1
	public unsafe string LobbyPassword
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_LobbyPassword);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_LobbyPassword), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x1700193A RID: 6458
	// (get) Token: 0x060046D0 RID: 18128 RVA: 0x0011C5C8 File Offset: 0x0011A7C8
	// (set) Token: 0x060046D1 RID: 18129 RVA: 0x0011C5F1 File Offset: 0x0011A7F1
	public unsafe string Username
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Username);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Username), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x1700193B RID: 6459
	// (get) Token: 0x060046D2 RID: 18130 RVA: 0x0011C618 File Offset: 0x0011A818
	// (set) Token: 0x060046D3 RID: 18131 RVA: 0x0011C640 File Offset: 0x0011A840
	public unsafe bool NormalLoad
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_NormalLoad);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_NormalLoad)) = value;
		}
	}

	// Token: 0x1700193C RID: 6460
	// (get) Token: 0x060046D4 RID: 18132 RVA: 0x0011C664 File Offset: 0x0011A864
	// (set) Token: 0x060046D5 RID: 18133 RVA: 0x0011C698 File Offset: 0x0011A898
	public unsafe List<GameObject> RootActivatedGameObjs
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_RootActivatedGameObjs);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_RootActivatedGameObjs), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700193D RID: 6461
	// (get) Token: 0x060046D6 RID: 18134 RVA: 0x0011C6C0 File Offset: 0x0011A8C0
	// (set) Token: 0x060046D7 RID: 18135 RVA: 0x0011C6E8 File Offset: 0x0011A8E8
	public unsafe bool Initialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Initialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_Initialized)) = value;
		}
	}

	// Token: 0x1700193E RID: 6462
	// (get) Token: 0x060046D8 RID: 18136 RVA: 0x0011C70C File Offset: 0x0011A90C
	// (set) Token: 0x060046D9 RID: 18137 RVA: 0x0011C734 File Offset: 0x0011A934
	public unsafe bool ShouldReconnect
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_ShouldReconnect);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugLoadDirectlyIntoMap.NativeFieldInfoPtr_ShouldReconnect)) = value;
		}
	}

	// Token: 0x04002D28 RID: 11560
	private static readonly IntPtr NativeFieldInfoPtr_GameModeToLoad;

	// Token: 0x04002D29 RID: 11561
	private static readonly IntPtr NativeFieldInfoPtr_MapToSet;

	// Token: 0x04002D2A RID: 11562
	private static readonly IntPtr NativeFieldInfoPtr_GamemodeType;

	// Token: 0x04002D2B RID: 11563
	private static readonly IntPtr NativeFieldInfoPtr_IsCompetitiveMode;

	// Token: 0x04002D2C RID: 11564
	private static readonly IntPtr NativeFieldInfoPtr_UseESLRuleset;

	// Token: 0x04002D2D RID: 11565
	private static readonly IntPtr NativeFieldInfoPtr_SinglePlayer;

	// Token: 0x04002D2E RID: 11566
	private static readonly IntPtr NativeFieldInfoPtr_IsSpectator;

	// Token: 0x04002D2F RID: 11567
	private static readonly IntPtr NativeFieldInfoPtr_SpectateSlots;

	// Token: 0x04002D30 RID: 11568
	private static readonly IntPtr NativeFieldInfoPtr_LobbyPassword;

	// Token: 0x04002D31 RID: 11569
	private static readonly IntPtr NativeFieldInfoPtr_Username;

	// Token: 0x04002D32 RID: 11570
	private static readonly IntPtr NativeFieldInfoPtr_NormalLoad;

	// Token: 0x04002D33 RID: 11571
	private static readonly IntPtr NativeFieldInfoPtr_RootActivatedGameObjs;

	// Token: 0x04002D34 RID: 11572
	private static readonly IntPtr NativeFieldInfoPtr_Initialized;

	// Token: 0x04002D35 RID: 11573
	private static readonly IntPtr NativeFieldInfoPtr_ShouldReconnect;

	// Token: 0x04002D36 RID: 11574
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
