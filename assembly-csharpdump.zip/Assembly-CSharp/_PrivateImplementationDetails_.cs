﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x02001299 RID: 4761
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060159AB RID: 88491 RVA: 0x00570670 File Offset: 0x0056E870
	[CallerCount(0)]
	public unsafe static uint ComputeStringHash(string s)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(s);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(global::_PrivateImplementationDetails_.NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060159AC RID: 88492 RVA: 0x005706C8 File Offset: 0x0056E8C8
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936");
		global::_PrivateImplementationDetails_.NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, 100691016);
	}

	// Token: 0x060159AD RID: 88493 RVA: 0x00002988 File Offset: 0x00000B88
	public _PrivateImplementationDetails_(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170079D4 RID: 31188
	// (get) Token: 0x060159AE RID: 88494 RVA: 0x0057091E File Offset: 0x0056EB1E
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr));
		}
	}

	// Token: 0x170079D5 RID: 31189
	// (get) Token: 0x060159AF RID: 88495 RVA: 0x00570930 File Offset: 0x0056EB30
	// (set) Token: 0x060159B0 RID: 88496 RVA: 0x0057094E File Offset: 0x0056EB4E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D, (void*)(&value));
		}
	}

	// Token: 0x170079D6 RID: 31190
	// (get) Token: 0x060159B1 RID: 88497 RVA: 0x00570960 File Offset: 0x0056EB60
	// (set) Token: 0x060159B2 RID: 88498 RVA: 0x0057097E File Offset: 0x0056EB7E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed13 0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed13 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09, (void*)(&value));
		}
	}

	// Token: 0x170079D7 RID: 31191
	// (get) Token: 0x060159B3 RID: 88499 RVA: 0x00570990 File Offset: 0x0056EB90
	// (set) Token: 0x060159B4 RID: 88500 RVA: 0x005709AE File Offset: 0x0056EBAE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40, (void*)(&value));
		}
	}

	// Token: 0x170079D8 RID: 31192
	// (get) Token: 0x060159B5 RID: 88501 RVA: 0x005709C0 File Offset: 0x0056EBC0
	// (set) Token: 0x060159B6 RID: 88502 RVA: 0x005709DE File Offset: 0x0056EBDE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841, (void*)(&value));
		}
	}

	// Token: 0x170079D9 RID: 31193
	// (get) Token: 0x060159B7 RID: 88503 RVA: 0x005709F0 File Offset: 0x0056EBF0
	// (set) Token: 0x060159B8 RID: 88504 RVA: 0x00570A0E File Offset: 0x0056EC0E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0, (void*)(&value));
		}
	}

	// Token: 0x170079DA RID: 31194
	// (get) Token: 0x060159B9 RID: 88505 RVA: 0x00570A20 File Offset: 0x0056EC20
	// (set) Token: 0x060159BA RID: 88506 RVA: 0x00570A3E File Offset: 0x0056EC3E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2, (void*)(&value));
		}
	}

	// Token: 0x170079DB RID: 31195
	// (get) Token: 0x060159BB RID: 88507 RVA: 0x00570A50 File Offset: 0x0056EC50
	// (set) Token: 0x060159BC RID: 88508 RVA: 0x00570A6E File Offset: 0x0056EC6E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0, (void*)(&value));
		}
	}

	// Token: 0x170079DC RID: 31196
	// (get) Token: 0x060159BD RID: 88509 RVA: 0x00570A80 File Offset: 0x0056EC80
	// (set) Token: 0x060159BE RID: 88510 RVA: 0x00570A9E File Offset: 0x0056EC9E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed14 38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed14 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26, (void*)(&value));
		}
	}

	// Token: 0x170079DD RID: 31197
	// (get) Token: 0x060159BF RID: 88511 RVA: 0x00570AB0 File Offset: 0x0056ECB0
	// (set) Token: 0x060159C0 RID: 88512 RVA: 0x00570ACE File Offset: 0x0056ECCE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF, (void*)(&value));
		}
	}

	// Token: 0x170079DE RID: 31198
	// (get) Token: 0x060159C1 RID: 88513 RVA: 0x00570AE0 File Offset: 0x0056ECE0
	// (set) Token: 0x060159C2 RID: 88514 RVA: 0x00570AFE File Offset: 0x0056ECFE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E, (void*)(&value));
		}
	}

	// Token: 0x170079DF RID: 31199
	// (get) Token: 0x060159C3 RID: 88515 RVA: 0x00570B10 File Offset: 0x0056ED10
	// (set) Token: 0x060159C4 RID: 88516 RVA: 0x00570B2E File Offset: 0x0056ED2E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D, (void*)(&value));
		}
	}

	// Token: 0x170079E0 RID: 31200
	// (get) Token: 0x060159C5 RID: 88517 RVA: 0x00570B40 File Offset: 0x0056ED40
	// (set) Token: 0x060159C6 RID: 88518 RVA: 0x00570B5E File Offset: 0x0056ED5E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC, (void*)(&value));
		}
	}

	// Token: 0x170079E1 RID: 31201
	// (get) Token: 0x060159C7 RID: 88519 RVA: 0x00570B70 File Offset: 0x0056ED70
	// (set) Token: 0x060159C8 RID: 88520 RVA: 0x00570B8E File Offset: 0x0056ED8E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164, (void*)(&value));
		}
	}

	// Token: 0x170079E2 RID: 31202
	// (get) Token: 0x060159C9 RID: 88521 RVA: 0x00570BA0 File Offset: 0x0056EDA0
	// (set) Token: 0x060159CA RID: 88522 RVA: 0x00570BBE File Offset: 0x0056EDBE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459, (void*)(&value));
		}
	}

	// Token: 0x170079E3 RID: 31203
	// (get) Token: 0x060159CB RID: 88523 RVA: 0x00570BD0 File Offset: 0x0056EDD0
	// (set) Token: 0x060159CC RID: 88524 RVA: 0x00570BEE File Offset: 0x0056EDEE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1, (void*)(&value));
		}
	}

	// Token: 0x170079E4 RID: 31204
	// (get) Token: 0x060159CD RID: 88525 RVA: 0x00570C00 File Offset: 0x0056EE00
	// (set) Token: 0x060159CE RID: 88526 RVA: 0x00570C1E File Offset: 0x0056EE1E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69, (void*)(&value));
		}
	}

	// Token: 0x170079E5 RID: 31205
	// (get) Token: 0x060159CF RID: 88527 RVA: 0x00570C30 File Offset: 0x0056EE30
	// (set) Token: 0x060159D0 RID: 88528 RVA: 0x00570C4E File Offset: 0x0056EE4E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed10 82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed10 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7, (void*)(&value));
		}
	}

	// Token: 0x170079E6 RID: 31206
	// (get) Token: 0x060159D1 RID: 88529 RVA: 0x00570C60 File Offset: 0x0056EE60
	// (set) Token: 0x060159D2 RID: 88530 RVA: 0x00570C7E File Offset: 0x0056EE7E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A, (void*)(&value));
		}
	}

	// Token: 0x170079E7 RID: 31207
	// (get) Token: 0x060159D3 RID: 88531 RVA: 0x00570C90 File Offset: 0x0056EE90
	// (set) Token: 0x060159D4 RID: 88532 RVA: 0x00570CAE File Offset: 0x0056EEAE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418, (void*)(&value));
		}
	}

	// Token: 0x170079E8 RID: 31208
	// (get) Token: 0x060159D5 RID: 88533 RVA: 0x00570CC0 File Offset: 0x0056EEC0
	// (set) Token: 0x060159D6 RID: 88534 RVA: 0x00570CDE File Offset: 0x0056EEDE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72, (void*)(&value));
		}
	}

	// Token: 0x170079E9 RID: 31209
	// (get) Token: 0x060159D7 RID: 88535 RVA: 0x00570CF0 File Offset: 0x0056EEF0
	// (set) Token: 0x060159D8 RID: 88536 RVA: 0x00570D0E File Offset: 0x0056EF0E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97, (void*)(&value));
		}
	}

	// Token: 0x170079EA RID: 31210
	// (get) Token: 0x060159D9 RID: 88537 RVA: 0x00570D20 File Offset: 0x0056EF20
	// (set) Token: 0x060159DA RID: 88538 RVA: 0x00570D3E File Offset: 0x0056EF3E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD, (void*)(&value));
		}
	}

	// Token: 0x170079EB RID: 31211
	// (get) Token: 0x060159DB RID: 88539 RVA: 0x00570D50 File Offset: 0x0056EF50
	// (set) Token: 0x060159DC RID: 88540 RVA: 0x00570D6E File Offset: 0x0056EF6E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7, (void*)(&value));
		}
	}

	// Token: 0x170079EC RID: 31212
	// (get) Token: 0x060159DD RID: 88541 RVA: 0x00570D80 File Offset: 0x0056EF80
	// (set) Token: 0x060159DE RID: 88542 RVA: 0x00570D9E File Offset: 0x0056EF9E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed12 EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed12 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919, (void*)(&value));
		}
	}

	// Token: 0x170079ED RID: 31213
	// (get) Token: 0x060159DF RID: 88543 RVA: 0x00570DB0 File Offset: 0x0056EFB0
	// (set) Token: 0x060159E0 RID: 88544 RVA: 0x00570DCE File Offset: 0x0056EFCE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B, (void*)(&value));
		}
	}

	// Token: 0x170079EE RID: 31214
	// (get) Token: 0x060159E1 RID: 88545 RVA: 0x00570DE0 File Offset: 0x0056EFE0
	// (set) Token: 0x060159E2 RID: 88546 RVA: 0x00570DFE File Offset: 0x0056EFFE
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11 result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D, (void*)(&value));
		}
	}

	// Token: 0x170079EF RID: 31215
	// (get) Token: 0x060159E3 RID: 88547 RVA: 0x00570E10 File Offset: 0x0056F010
	// (set) Token: 0x060159E4 RID: 88548 RVA: 0x00570E2E File Offset: 0x0056F02E
	public unsafe static long F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936
	{
		get
		{
			long result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936, (void*)(&value));
		}
	}

	// Token: 0x0400DDA7 RID: 56743
	private static readonly IntPtr NativeFieldInfoPtr_0A0EC6D4742068B4D88C6145B8224EF1DC240C8A305CDFC50C3AAF9121E6875D;

	// Token: 0x0400DDA8 RID: 56744
	private static readonly IntPtr NativeFieldInfoPtr_0ACEC52616C2657143F3DA95CA6E4996D4DFD173058B42BEADCF92128A93AD09;

	// Token: 0x0400DDA9 RID: 56745
	private static readonly IntPtr NativeFieldInfoPtr_0C0EF88D5201352B2874EA39337847613A58DFED1C35C12D3445E7F5EC3C6F40;

	// Token: 0x0400DDAA RID: 56746
	private static readonly IntPtr NativeFieldInfoPtr_10B4796EAC59C7D81C33711F219BA227247A4E338ADAD078159BA01E87590841;

	// Token: 0x0400DDAB RID: 56747
	private static readonly IntPtr NativeFieldInfoPtr_1385A3395CDC9F7F90324CB0A06C5AC11AD4A425A35BBB7D5C9C0C33D8ADE9A0;

	// Token: 0x0400DDAC RID: 56748
	private static readonly IntPtr NativeFieldInfoPtr_170AFC6EC7562D42EE77EFB5F8B347F4ED01A3D1EC9FDF948483291B677CB2E2;

	// Token: 0x0400DDAD RID: 56749
	private static readonly IntPtr NativeFieldInfoPtr_27D74DCAB98C4F3CB9B9925BC898AB1CF5D803F5408910920A735DDDE7D329A0;

	// Token: 0x0400DDAE RID: 56750
	private static readonly IntPtr NativeFieldInfoPtr_38B7B4B046BC245D681009C0CF75E377102D263A7433F1055DBDF40EF7C58A26;

	// Token: 0x0400DDAF RID: 56751
	private static readonly IntPtr NativeFieldInfoPtr_3B6D3EDAC267C0B64EEF6AE9AA9BC93DE9BFE367EC2FE32FD35C460BEB0634EF;

	// Token: 0x0400DDB0 RID: 56752
	private static readonly IntPtr NativeFieldInfoPtr_3FFD3A99FEB04D929273F1B3967FCF6D35552AF56FDF80F188B9FA32D7E7FC4E;

	// Token: 0x0400DDB1 RID: 56753
	private static readonly IntPtr NativeFieldInfoPtr_5419DADFA55DB7A9B5C9984CE1F92D4C5EC88B254C35BAF2474094E2AECE076D;

	// Token: 0x0400DDB2 RID: 56754
	private static readonly IntPtr NativeFieldInfoPtr_5F5673AE83EE13B46A7C1D9CE2F8CC01C37CFC893B0AC5E6E9260B79215F5ADC;

	// Token: 0x0400DDB3 RID: 56755
	private static readonly IntPtr NativeFieldInfoPtr_69E57350522E4ECC12B50316F80F71B81FE20C753CD48D5613BE2386EB0AE164;

	// Token: 0x0400DDB4 RID: 56756
	private static readonly IntPtr NativeFieldInfoPtr_72DEE82963951660690CE40A0C2B8881CE2DA365F1DEF871E78611E09DA8A459;

	// Token: 0x0400DDB5 RID: 56757
	private static readonly IntPtr NativeFieldInfoPtr_753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1;

	// Token: 0x0400DDB6 RID: 56758
	private static readonly IntPtr NativeFieldInfoPtr_812298DE81815948BEB5544C3EF33203EA61D6EE3A9C01C19AE39B8B7D624D69;

	// Token: 0x0400DDB7 RID: 56759
	private static readonly IntPtr NativeFieldInfoPtr_82CA71B085A9CD5293D1E1300247447B88C83BE3F0CB3755E88D6B7FBFD441B7;

	// Token: 0x0400DDB8 RID: 56760
	private static readonly IntPtr NativeFieldInfoPtr_9CEA0740A1DAB2C21A3FCC7725E338AF6DFFD7DC3BC62AB57B7854A964ADD75A;

	// Token: 0x0400DDB9 RID: 56761
	private static readonly IntPtr NativeFieldInfoPtr_A55571C9DB30026E44AC0BDD7674D9C597D8254732FEB18418F3AAF8A5B4F418;

	// Token: 0x0400DDBA RID: 56762
	private static readonly IntPtr NativeFieldInfoPtr_CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72;

	// Token: 0x0400DDBB RID: 56763
	private static readonly IntPtr NativeFieldInfoPtr_DF1562A74374EDC1D8388361A3BDB4F2AD2C26E6201BCD68F91CCA69B3FEEC97;

	// Token: 0x0400DDBC RID: 56764
	private static readonly IntPtr NativeFieldInfoPtr_E157F1250D3AD5BB797DB4766E316424315B66E1FBA23FE6C84F9966F2265CAD;

	// Token: 0x0400DDBD RID: 56765
	private static readonly IntPtr NativeFieldInfoPtr_E9992125031E44BE02F4E4970BD1D45485C0A09182FB41F999398827A90DAFE7;

	// Token: 0x0400DDBE RID: 56766
	private static readonly IntPtr NativeFieldInfoPtr_EC57695267D76EC47696E24F027D51A90C1AFCBD54DC90566215A66297A99919;

	// Token: 0x0400DDBF RID: 56767
	private static readonly IntPtr NativeFieldInfoPtr_F186F2262AE48F2AA4F90C9A6B35913B0F6B0B895423B6267252259BFD357D3B;

	// Token: 0x0400DDC0 RID: 56768
	private static readonly IntPtr NativeFieldInfoPtr_F277DEF3640132FEE7D00B4738B95C550FBAA307FBFEC9EB932C2CFE1DC2C91D;

	// Token: 0x0400DDC1 RID: 56769
	private static readonly IntPtr NativeFieldInfoPtr_F585FEBCD0E048E36D080EA7AD72758A5A2D75AB1CE07E48BD66CA791AD27936;

	// Token: 0x0400DDC2 RID: 56770
	private static readonly IntPtr NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0;

	// Token: 0x0200129A RID: 4762
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=6")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060159E5 RID: 88549 RVA: 0x00570E3E File Offset: 0x0056F03E
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=6");
		}

		// Token: 0x060159E6 RID: 88550 RVA: 0x00570E54 File Offset: 0x0056F054
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F0 RID: 31216
		// (get) Token: 0x060159E7 RID: 88551 RVA: 0x00570E66 File Offset: 0x0056F066
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr));
			}
		}
	}

	// Token: 0x0200129B RID: 4763
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=12")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060159E8 RID: 88552 RVA: 0x00570E77 File Offset: 0x0056F077
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=12");
		}

		// Token: 0x060159E9 RID: 88553 RVA: 0x00570E8D File Offset: 0x0056F08D
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F1 RID: 31217
		// (get) Token: 0x060159EA RID: 88554 RVA: 0x00570E9F File Offset: 0x0056F09F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr));
			}
		}
	}

	// Token: 0x0200129C RID: 4764
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=14")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed2
	{
		// Token: 0x060159EB RID: 88555 RVA: 0x00570EB0 File Offset: 0x0056F0B0
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed2()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=14");
		}

		// Token: 0x060159EC RID: 88556 RVA: 0x00570EC6 File Offset: 0x0056F0C6
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F2 RID: 31218
		// (get) Token: 0x060159ED RID: 88557 RVA: 0x00570ED8 File Offset: 0x0056F0D8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr));
			}
		}
	}

	// Token: 0x0200129D RID: 4765
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=16")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed3
	{
		// Token: 0x060159EE RID: 88558 RVA: 0x00570EE9 File Offset: 0x0056F0E9
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed3()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=16");
		}

		// Token: 0x060159EF RID: 88559 RVA: 0x00570EFF File Offset: 0x0056F0FF
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F3 RID: 31219
		// (get) Token: 0x060159F0 RID: 88560 RVA: 0x00570F11 File Offset: 0x0056F111
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr));
			}
		}
	}

	// Token: 0x0200129E RID: 4766
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=17")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed4
	{
		// Token: 0x060159F1 RID: 88561 RVA: 0x00570F22 File Offset: 0x0056F122
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed4()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=17");
		}

		// Token: 0x060159F2 RID: 88562 RVA: 0x00570F38 File Offset: 0x0056F138
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F4 RID: 31220
		// (get) Token: 0x060159F3 RID: 88563 RVA: 0x00570F4A File Offset: 0x0056F14A
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr));
			}
		}
	}

	// Token: 0x0200129F RID: 4767
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=18")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed5
	{
		// Token: 0x060159F4 RID: 88564 RVA: 0x00570F5B File Offset: 0x0056F15B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed5()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=18");
		}

		// Token: 0x060159F5 RID: 88565 RVA: 0x00570F71 File Offset: 0x0056F171
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F5 RID: 31221
		// (get) Token: 0x060159F6 RID: 88566 RVA: 0x00570F83 File Offset: 0x0056F183
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A0 RID: 4768
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=20")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed6
	{
		// Token: 0x060159F7 RID: 88567 RVA: 0x00570F94 File Offset: 0x0056F194
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed6()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=20");
		}

		// Token: 0x060159F8 RID: 88568 RVA: 0x00570FAA File Offset: 0x0056F1AA
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F6 RID: 31222
		// (get) Token: 0x060159F9 RID: 88569 RVA: 0x00570FBC File Offset: 0x0056F1BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A1 RID: 4769
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=24")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed7
	{
		// Token: 0x060159FA RID: 88570 RVA: 0x00570FCD File Offset: 0x0056F1CD
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed7()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=24");
		}

		// Token: 0x060159FB RID: 88571 RVA: 0x00570FE3 File Offset: 0x0056F1E3
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F7 RID: 31223
		// (get) Token: 0x060159FC RID: 88572 RVA: 0x00570FF5 File Offset: 0x0056F1F5
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A2 RID: 4770
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=28")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed8
	{
		// Token: 0x060159FD RID: 88573 RVA: 0x00571006 File Offset: 0x0056F206
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed8()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=28");
		}

		// Token: 0x060159FE RID: 88574 RVA: 0x0057101C File Offset: 0x0056F21C
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F8 RID: 31224
		// (get) Token: 0x060159FF RID: 88575 RVA: 0x0057102E File Offset: 0x0056F22E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A3 RID: 4771
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=32")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed9
	{
		// Token: 0x06015A00 RID: 88576 RVA: 0x0057103F File Offset: 0x0056F23F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed9()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=32");
		}

		// Token: 0x06015A01 RID: 88577 RVA: 0x00571055 File Offset: 0x0056F255
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9>.NativeClassPtr, ref this));
		}

		// Token: 0x170079F9 RID: 31225
		// (get) Token: 0x06015A02 RID: 88578 RVA: 0x00571067 File Offset: 0x0056F267
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A4 RID: 4772
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=36")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed10
	{
		// Token: 0x06015A03 RID: 88579 RVA: 0x00571078 File Offset: 0x0056F278
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed10()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed10>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=36");
		}

		// Token: 0x06015A04 RID: 88580 RVA: 0x0057108E File Offset: 0x0056F28E
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed10>.NativeClassPtr, ref this));
		}

		// Token: 0x170079FA RID: 31226
		// (get) Token: 0x06015A05 RID: 88581 RVA: 0x005710A0 File Offset: 0x0056F2A0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed10>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A5 RID: 4773
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=40")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed11
	{
		// Token: 0x06015A06 RID: 88582 RVA: 0x005710B1 File Offset: 0x0056F2B1
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed11()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=40");
		}

		// Token: 0x06015A07 RID: 88583 RVA: 0x005710C7 File Offset: 0x0056F2C7
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11>.NativeClassPtr, ref this));
		}

		// Token: 0x170079FB RID: 31227
		// (get) Token: 0x06015A08 RID: 88584 RVA: 0x005710D9 File Offset: 0x0056F2D9
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed11>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A6 RID: 4774
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=84")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed12
	{
		// Token: 0x06015A09 RID: 88585 RVA: 0x005710EA File Offset: 0x0056F2EA
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed12()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed12>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=84");
		}

		// Token: 0x06015A0A RID: 88586 RVA: 0x00571100 File Offset: 0x0056F300
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed12>.NativeClassPtr, ref this));
		}

		// Token: 0x170079FC RID: 31228
		// (get) Token: 0x06015A0B RID: 88587 RVA: 0x00571112 File Offset: 0x0056F312
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed12>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A7 RID: 4775
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=128")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed13
	{
		// Token: 0x06015A0C RID: 88588 RVA: 0x00571123 File Offset: 0x0056F323
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed13()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed13>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=128");
		}

		// Token: 0x06015A0D RID: 88589 RVA: 0x00571139 File Offset: 0x0056F339
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed13>.NativeClassPtr, ref this));
		}

		// Token: 0x170079FD RID: 31229
		// (get) Token: 0x06015A0E RID: 88590 RVA: 0x0057114B File Offset: 0x0056F34B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed13>.NativeClassPtr));
			}
		}
	}

	// Token: 0x020012A8 RID: 4776
	[ObfuscatedName("<PrivateImplementationDetails>/__StaticArrayInitTypeSize=512")]
	[StructLayout(2, Size = 1)]
	public struct ValueTypeNPrivateSealed14
	{
		// Token: 0x06015A0F RID: 88591 RVA: 0x0057115C File Offset: 0x0056F35C
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed14()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed14>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=512");
		}

		// Token: 0x06015A10 RID: 88592 RVA: 0x00571172 File Offset: 0x0056F372
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed14>.NativeClassPtr, ref this));
		}

		// Token: 0x170079FE RID: 31230
		// (get) Token: 0x06015A11 RID: 88593 RVA: 0x00571184 File Offset: 0x0056F384
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed14>.NativeClassPtr));
			}
		}
	}
}
