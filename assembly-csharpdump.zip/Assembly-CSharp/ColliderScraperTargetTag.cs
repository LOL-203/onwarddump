﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000182 RID: 386
public class ColliderScraperTargetTag : MonoBehaviour
{
	// Token: 0x060019DB RID: 6619 RVA: 0x000670A0 File Offset: 0x000652A0
	[CallerCount(0)]
	public unsafe ColliderScraperTargetTag() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColliderScraperTargetTag>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColliderScraperTargetTag.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019DC RID: 6620 RVA: 0x000670EB File Offset: 0x000652EB
	// Note: this type is marked as 'beforefieldinit'.
	static ColliderScraperTargetTag()
	{
		Il2CppClassPointerStore<ColliderScraperTargetTag>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ColliderScraperTargetTag");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColliderScraperTargetTag>.NativeClassPtr);
		ColliderScraperTargetTag.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColliderScraperTargetTag>.NativeClassPtr, 100665351);
	}

	// Token: 0x060019DD RID: 6621 RVA: 0x0000210C File Offset: 0x0000030C
	public ColliderScraperTargetTag(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170008F8 RID: 2296
	// (get) Token: 0x060019DE RID: 6622 RVA: 0x00067124 File Offset: 0x00065324
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColliderScraperTargetTag>.NativeClassPtr));
		}
	}

	// Token: 0x04001093 RID: 4243
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
