﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000CD RID: 205
public class DestroyDebugger : MonoBehaviour
{
	// Token: 0x06000CBC RID: 3260 RVA: 0x00033944 File Offset: 0x00031B44
	[CallerCount(0)]
	public new unsafe static void Destroy(UnityEngine.Object obj)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestroyDebugger.NativeMethodInfoPtr_Destroy_Public_Static_Void_Object_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CBD RID: 3261 RVA: 0x00033990 File Offset: 0x00031B90
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestroyDebugger.NativeMethodInfoPtr_OnDestroy_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CBE RID: 3262 RVA: 0x000339D4 File Offset: 0x00031BD4
	[CallerCount(0)]
	public unsafe DestroyDebugger() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DestroyDebugger.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CBF RID: 3263 RVA: 0x00033A20 File Offset: 0x00031C20
	// Note: this type is marked as 'beforefieldinit'.
	static DestroyDebugger()
	{
		Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DestroyDebugger");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr);
		DestroyDebugger.NativeFieldInfoPtr_DestroyStackTraces = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr, "DestroyStackTraces");
		DestroyDebugger.NativeMethodInfoPtr_Destroy_Public_Static_Void_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr, 100664285);
		DestroyDebugger.NativeMethodInfoPtr_OnDestroy_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr, 100664286);
		DestroyDebugger.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr, 100664287);
	}

	// Token: 0x06000CC0 RID: 3264 RVA: 0x0000210C File Offset: 0x0000030C
	public DestroyDebugger(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000468 RID: 1128
	// (get) Token: 0x06000CC1 RID: 3265 RVA: 0x00033AA0 File Offset: 0x00031CA0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DestroyDebugger>.NativeClassPtr));
		}
	}

	// Token: 0x17000469 RID: 1129
	// (get) Token: 0x06000CC2 RID: 3266 RVA: 0x00033AB4 File Offset: 0x00031CB4
	// (set) Token: 0x06000CC3 RID: 3267 RVA: 0x00033ADF File Offset: 0x00031CDF
	public unsafe static Dictionary<int, string> DestroyStackTraces
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DestroyDebugger.NativeFieldInfoPtr_DestroyStackTraces, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<int, string>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DestroyDebugger.NativeFieldInfoPtr_DestroyStackTraces, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040007B2 RID: 1970
	private static readonly IntPtr NativeFieldInfoPtr_DestroyStackTraces;

	// Token: 0x040007B3 RID: 1971
	private static readonly IntPtr NativeMethodInfoPtr_Destroy_Public_Static_Void_Object_0;

	// Token: 0x040007B4 RID: 1972
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Public_Void_0;

	// Token: 0x040007B5 RID: 1973
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
