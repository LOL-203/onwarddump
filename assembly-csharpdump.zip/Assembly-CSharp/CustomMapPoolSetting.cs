﻿using System;

// Token: 0x0200016F RID: 367
public enum CustomMapPoolSetting
{
	// Token: 0x04000FAC RID: 4012
	OnlyHostMaps,
	// Token: 0x04000FAD RID: 4013
	AnyPlayersMaps,
	// Token: 0x04000FAE RID: 4014
	AnyWorkshopMaps
}
