﻿using System;

// Token: 0x020003EE RID: 1006
public enum AutoStartState
{
	// Token: 0x04003214 RID: 12820
	HasNotStarted,
	// Token: 0x04003215 RID: 12821
	IsRunning,
	// Token: 0x04003216 RID: 12822
	HasStopped
}
