﻿using System;
using System.Runtime.InteropServices;
using CodeStage.AntiCheat.ObscuredTypes;
using DPI.Bhaptics;
using DPI.Networking;
using DPI.Networking.IO;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward;
using Onward.Networking;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnhollowerRuntimeLib;
using UnityEngine;

// Token: 0x02000192 RID: 402
public class DamageController : MonoBehaviourDPINetworking
{
	// Token: 0x06001ABD RID: 6845 RVA: 0x0006A7E0 File Offset: 0x000689E0
	[CallerCount(0)]
	public unsafe static List<DamageController> GetAllDamageControllers()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_List_1_DamageController_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new List<DamageController>(intPtr2) : null;
	}

	// Token: 0x06001ABE RID: 6846 RVA: 0x0006A828 File Offset: 0x00068A28
	[CallerCount(0)]
	public unsafe static void GetAllDamageControllers(ref List<DamageController> damageControllers)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		ref IntPtr ptr2 = ref *ptr;
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(damageControllers);
		ptr2 = &intPtr;
		IntPtr returnedException;
		IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr3 = intPtr;
		damageControllers = ((intPtr3 == 0) ? null : new List(intPtr3));
	}

	// Token: 0x06001ABF RID: 6847 RVA: 0x0006A894 File Offset: 0x00068A94
	[CallerCount(0)]
	public unsafe static void GetAllDamageControllers(ref List<DamageController> damageControllers, Faction targetFaction)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		ref IntPtr ptr2 = ref *ptr;
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(damageControllers);
		ptr2 = &intPtr;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetFaction;
		IntPtr returnedException;
		IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_Faction_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr3 = intPtr;
		damageControllers = ((intPtr3 == 0) ? null : new List(intPtr3));
	}

	// Token: 0x06001AC0 RID: 6848 RVA: 0x0006A914 File Offset: 0x00068B14
	[CallerCount(0)]
	public unsafe static void GetAllDamageControllersInRange(ref List<DamageController> damageControllers, Vector3 centerPoint, float range, bool damageableOnly)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		ref IntPtr ptr2 = ref *ptr;
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(damageControllers);
		ptr2 = &intPtr;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref centerPoint;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref range;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageableOnly;
		IntPtr returnedException;
		IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetAllDamageControllersInRange_Public_Static_Void_byref_List_1_DamageController_Vector3_Single_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr3 = intPtr;
		damageControllers = ((intPtr3 == 0) ? null : new List(intPtr3));
	}

	// Token: 0x06001AC1 RID: 6849 RVA: 0x0006A9B8 File Offset: 0x00068BB8
	[CallerCount(0)]
	public unsafe static void GetAllDamageControllersAlongPath(List<DamageController> damageControllers, List<ValueTuple<SuppressionOwner, Vector3>> suppressionOnwersInRangeAndClosestPoint, Vector3 pathStart, Vector3 pathDirection, float range, float pathLength, bool damageableOnly, bool addSafetyLength = true)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)8) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageControllers);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(suppressionOnwersInRangeAndClosestPoint);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pathStart;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pathDirection;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref range;
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pathLength;
		ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageableOnly;
		ptr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref addSafetyLength;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetAllDamageControllersAlongPath_Public_Static_Void_List_1_DamageController_List_1_ValueTuple_2_SuppressionOwner_Vector3_Vector3_Vector3_Single_Single_Boolean_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17000978 RID: 2424
	// (get) Token: 0x06001AC2 RID: 6850 RVA: 0x0006AA8C File Offset: 0x00068C8C
	// (set) Token: 0x06001AC3 RID: 6851 RVA: 0x0006AADC File Offset: 0x00068CDC
	public unsafe Faction Faction
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_Faction_Public_get_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_set_Faction_Public_set_Void_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x17000979 RID: 2425
	// (get) Token: 0x06001AC4 RID: 6852 RVA: 0x0006AB30 File Offset: 0x00068D30
	public unsafe bool IsWounded
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsWounded_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700097A RID: 2426
	// (get) Token: 0x06001AC5 RID: 6853 RVA: 0x0006AB80 File Offset: 0x00068D80
	public unsafe bool IsBleeding
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsBleeding_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700097B RID: 2427
	// (get) Token: 0x06001AC6 RID: 6854 RVA: 0x0006ABD0 File Offset: 0x00068DD0
	public unsafe bool IsCharacter
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsCharacter_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700097C RID: 2428
	// (get) Token: 0x06001AC7 RID: 6855 RVA: 0x0006AC20 File Offset: 0x00068E20
	public unsafe bool IsDead
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsDead_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700097D RID: 2429
	// (get) Token: 0x06001AC8 RID: 6856 RVA: 0x0006AC70 File Offset: 0x00068E70
	public unsafe bool IsAlive
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsAlive_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700097E RID: 2430
	// (get) Token: 0x06001AC9 RID: 6857 RVA: 0x0006ACC0 File Offset: 0x00068EC0
	// (set) Token: 0x06001ACA RID: 6858 RVA: 0x0006AD10 File Offset: 0x00068F10
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x1700097F RID: 2431
	// (get) Token: 0x06001ACB RID: 6859 RVA: 0x0006AD64 File Offset: 0x00068F64
	public unsafe bool IsDamageable
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsDamageable_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17000980 RID: 2432
	// (get) Token: 0x06001ACC RID: 6860 RVA: 0x0006ADB4 File Offset: 0x00068FB4
	public unsafe bool PassesAllLivingChecks
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_PassesAllLivingChecks_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17000981 RID: 2433
	// (get) Token: 0x06001ACD RID: 6861 RVA: 0x0006AE04 File Offset: 0x00069004
	public unsafe bool IsRelevantForAISight
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsRelevantForAISight_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06001ACE RID: 6862 RVA: 0x0006AE54 File Offset: 0x00069054
	[CallerCount(0)]
	public unsafe void add_OnDeath(DamageController.DeathEvent value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_add_OnDeath_Public_add_Void_DeathEvent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ACF RID: 6863 RVA: 0x0006AEB0 File Offset: 0x000690B0
	[CallerCount(0)]
	public unsafe void remove_OnDeath(DamageController.DeathEvent value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_remove_OnDeath_Public_rem_Void_DeathEvent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD0 RID: 6864 RVA: 0x0006AF0C File Offset: 0x0006910C
	[CallerCount(0)]
	public unsafe void add_OnDamageTaken(DamageController.DamageEvent value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_add_OnDamageTaken_Public_add_Void_DamageEvent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD1 RID: 6865 RVA: 0x0006AF68 File Offset: 0x00069168
	[CallerCount(0)]
	public unsafe void remove_OnDamageTaken(DamageController.DamageEvent value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_remove_OnDamageTaken_Public_rem_Void_DamageEvent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17000982 RID: 2434
	// (get) Token: 0x06001AD2 RID: 6866 RVA: 0x0006AFC4 File Offset: 0x000691C4
	public unsafe static bool IsDamageBanned
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_get_IsDamageBanned_Public_Static_get_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06001AD3 RID: 6867 RVA: 0x0006B008 File Offset: 0x00069208
	[CallerCount(0)]
	public unsafe static bool ShouldIgnoreDamageDueToBan(DPIPlayer targetPlayer, DPIPlayer sourcePlayer, int sourceAI)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(targetPlayer);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(sourcePlayer);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref sourceAI;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ShouldIgnoreDamageDueToBan_Public_Static_Boolean_DPIPlayer_DPIPlayer_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001AD4 RID: 6868 RVA: 0x0006B08C File Offset: 0x0006928C
	[CallerCount(0)]
	public unsafe static void ApplyDamage(DamageController target, float damageToApply, DamageType damageType, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageToApply;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ApplyDamage_Public_Static_Void_DamageController_Single_DamageType_Nullable_1_Vector3_DPIPlayer_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD5 RID: 6869 RVA: 0x0006B144 File Offset: 0x00069344
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamageToChild(int childIndex, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref childIndex;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Private_Void_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD6 RID: 6870 RVA: 0x0006B224 File Offset: 0x00069424
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD7 RID: 6871 RVA: 0x0006B268 File Offset: 0x00069468
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD8 RID: 6872 RVA: 0x0006B2AC File Offset: 0x000694AC
	[CallerCount(0)]
	public unsafe void SetHealth(float newHealth, DPIPlayer source)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref newHealth;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_SetHealth_Public_Void_Single_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AD9 RID: 6873 RVA: 0x0006B318 File Offset: 0x00069518
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADA RID: 6874 RVA: 0x0006B35C File Offset: 0x0006955C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADB RID: 6875 RVA: 0x0006B3A0 File Offset: 0x000695A0
	[CallerCount(0)]
	public unsafe void RefreshBannedCache()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RefreshBannedCache_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADC RID: 6876 RVA: 0x0006B3E4 File Offset: 0x000695E4
	[CallerCount(0)]
	public unsafe void AddToStaticList()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_AddToStaticList_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADD RID: 6877 RVA: 0x0006B428 File Offset: 0x00069628
	[CallerCount(0)]
	public unsafe void RemoveFromStaticList()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RemoveFromStaticList_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADE RID: 6878 RVA: 0x0006B46C File Offset: 0x0006966C
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001ADF RID: 6879 RVA: 0x0006B4B0 File Offset: 0x000696B0
	[CallerCount(0)]
	public unsafe void ParentDied(DPIPlayer source)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ParentDied_Private_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE0 RID: 6880 RVA: 0x0006B50C File Offset: 0x0006970C
	[CallerCount(0)]
	public unsafe void ToggleTriggers(bool isTrigger)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref isTrigger;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ToggleTriggers_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE1 RID: 6881 RVA: 0x0006B560 File Offset: 0x00069760
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE2 RID: 6882 RVA: 0x0006B5A4 File Offset: 0x000697A4
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamage(float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref amount;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Private_Void_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE3 RID: 6883 RVA: 0x0006B670 File Offset: 0x00069870
	[CallerCount(0)]
	public unsafe void ToggleColliders(bool on)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref on;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE4 RID: 6884 RVA: 0x0006B6C4 File Offset: 0x000698C4
	[CallerCount(0)]
	public unsafe void Die(DPIPlayer source)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Die_Private_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE5 RID: 6885 RVA: 0x0006B720 File Offset: 0x00069920
	[CallerCount(0)]
	public unsafe void Reset()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Reset_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE6 RID: 6886 RVA: 0x0006B764 File Offset: 0x00069964
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE7 RID: 6887 RVA: 0x0006B7A8 File Offset: 0x000699A8
	[CallerCount(0)]
	public unsafe void SetInvincibility(bool isInvincible)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref isInvincible;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE8 RID: 6888 RVA: 0x0006B7FC File Offset: 0x000699FC
	[CallerCount(0)]
	public unsafe void SetInvincibilityTimer(float timeToBeInvincible)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref timeToBeInvincible;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_SetInvincibilityTimer_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AE9 RID: 6889 RVA: 0x0006B850 File Offset: 0x00069A50
	[CallerCount(0)]
	public unsafe void ToggleInvincibility()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ToggleInvincibility_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AEA RID: 6890 RVA: 0x0006B894 File Offset: 0x00069A94
	[CallerCount(0)]
	public unsafe bool IsInvincible()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_IsInvincible_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001AEB RID: 6891 RVA: 0x0006B8E4 File Offset: 0x00069AE4
	[CallerCount(0)]
	public unsafe Il2CppReferenceArray<Collider> GetExclusiveChildColliders()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetExclusiveChildColliders_Public_ArrayOf_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppReferenceArray<Collider>(intPtr2) : null;
	}

	// Token: 0x06001AEC RID: 6892 RVA: 0x0006B93C File Offset: 0x00069B3C
	[CallerCount(0)]
	public unsafe bool IsChildColliderExclusive(Collider c)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(c);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_IsChildColliderExclusive_Protected_Boolean_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001AED RID: 6893 RVA: 0x0006B9A4 File Offset: 0x00069BA4
	[CallerCount(0)]
	public unsafe void AddDamageBody(DamageBody damageBody)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageBody);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_AddDamageBody_Public_Void_DamageBody_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AEE RID: 6894 RVA: 0x0006BA00 File Offset: 0x00069C00
	[CallerCount(0)]
	public unsafe Collider GetChestCollider()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_GetChestCollider_Public_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Collider(intPtr2) : null;
	}

	// Token: 0x06001AEF RID: 6895 RVA: 0x0006BA58 File Offset: 0x00069C58
	[CallerCount(0)]
	public unsafe static void RegisterControllerColliders(DamageController damageController, Il2CppReferenceArray<Collider> colliders)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageController);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(colliders);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RegisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF0 RID: 6896 RVA: 0x0006BABC File Offset: 0x00069CBC
	[CallerCount(0)]
	public unsafe static void UnregisterControllerColliders(DamageController damageController, Il2CppReferenceArray<Collider> colliders)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageController);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(colliders);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_UnregisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF1 RID: 6897 RVA: 0x0006BB20 File Offset: 0x00069D20
	[CallerCount(0)]
	public unsafe static void RegisterBodyColliders(DamageBody damageBody, Il2CppReferenceArray<Collider> colliders)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageBody);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(colliders);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RegisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF2 RID: 6898 RVA: 0x0006BB84 File Offset: 0x00069D84
	[CallerCount(0)]
	public unsafe static void UnregisterBodyColliders(DamageBody damageBody, Il2CppReferenceArray<Collider> colliders)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageBody);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(colliders);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_UnregisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF3 RID: 6899 RVA: 0x0006BBE8 File Offset: 0x00069DE8
	[CallerCount(0)]
	public unsafe static void ClearColliderCaches()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_ClearColliderCaches_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF4 RID: 6900 RVA: 0x0006BC1C File Offset: 0x00069E1C
	[CallerCount(0)]
	public unsafe void Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_DPINetworkMessageInfo_0(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique tmp, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(tmp));
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF5 RID: 6901 RVA: 0x0006BC98 File Offset: 0x00069E98
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamageToChild(Il2CppReferenceArray<DPIPlayer> invokeRpcPlayerTargets, int childIndex, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTargets);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref childIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_ArrayOf_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF6 RID: 6902 RVA: 0x0006BD74 File Offset: 0x00069F74
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamageToChild(DPIPlayer invokeRpcPlayerTarget, int childIndex, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTarget);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref childIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF7 RID: 6903 RVA: 0x0006BE50 File Offset: 0x0006A050
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamageToChild(RpcTarget invokeRpcTarget, int childIndex, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref invokeRpcTarget;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref childIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_RpcTarget_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF8 RID: 6904 RVA: 0x0006BF28 File Offset: 0x0006A128
	[CallerCount(0)]
	public unsafe void Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_DPINetworkMessageInfo_0(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique tmp, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(tmp));
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AF9 RID: 6905 RVA: 0x0006BFA4 File Offset: 0x0006A1A4
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamage(Il2CppReferenceArray<DPIPlayer> invokeRpcPlayerTargets, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTargets);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_ArrayOf_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AFA RID: 6906 RVA: 0x0006C06C File Offset: 0x0006A26C
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamage(DPIPlayer invokeRpcPlayerTarget, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTarget);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AFB RID: 6907 RVA: 0x0006C134 File Offset: 0x0006A334
	[CallerCount(0)]
	public unsafe void RPC_ApplyDamage(RpcTarget invokeRpcTarget, float amount, byte damageTypeByte, Nullable<Vector3> force, DPIPlayer source, int aiSourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref invokeRpcTarget;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref amount;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageTypeByte;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(force));
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiSourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_RpcTarget_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AFC RID: 6908 RVA: 0x0006C1F8 File Offset: 0x0006A3F8
	[CallerCount(0)]
	public new unsafe void OnCodeGenInitializeHook()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageController.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AFD RID: 6909 RVA: 0x0006C248 File Offset: 0x0006A448
	[CallerCount(0)]
	public unsafe DamageController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageController>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AFE RID: 6910 RVA: 0x0006C294 File Offset: 0x0006A494
	// Note: this type is marked as 'beforefieldinit'.
	static DamageController()
	{
		Il2CppClassPointerStore<DamageController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageController");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController>.NativeClassPtr);
		DamageController.NativeFieldInfoPtr_OnAIDied = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnAIDied");
		DamageController.NativeFieldInfoPtr_OnwardPhotonView = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnwardPhotonView");
		DamageController.NativeFieldInfoPtr_allDamageControllers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "allDamageControllers");
		DamageController.NativeFieldInfoPtr_OnDamageControllerAdded = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnDamageControllerAdded");
		DamageController.NativeFieldInfoPtr_OnDamageControllerRemoved = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnDamageControllerRemoved");
		DamageController.NativeFieldInfoPtr_OnDamageControllerFactionChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnDamageControllerFactionChanged");
		DamageController.NativeFieldInfoPtr_DamageControllersByPhotonID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageControllersByPhotonID");
		DamageController.NativeFieldInfoPtr_faction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "faction");
		DamageController.NativeFieldInfoPtr_StartingHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "StartingHealth");
		DamageController.NativeFieldInfoPtr_CurrentHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "CurrentHealth");
		DamageController.NativeFieldInfoPtr_BhapticsReference = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "BhapticsReference");
		DamageController.NativeFieldInfoPtr_TargettingReference = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "TargettingReference");
		DamageController.NativeFieldInfoPtr_TargetPriority = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "TargetPriority");
		DamageController.NativeFieldInfoPtr_AllowsPassthroughDamage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "AllowsPassthroughDamage");
		DamageController.NativeFieldInfoPtr_DamageControllerType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageControllerType");
		DamageController.NativeFieldInfoPtr_IsValidAITarget = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "IsValidAITarget");
		DamageController.NativeFieldInfoPtr_WarPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "WarPlayer");
		DamageController.NativeFieldInfoPtr_AI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "AI");
		DamageController.NativeFieldInfoPtr_StatusController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "StatusController");
		DamageController.NativeFieldInfoPtr_isAI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "isAI");
		DamageController.NativeFieldInfoPtr_DamageBoundaryStateController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageBoundaryStateController");
		DamageController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		DamageController.NativeFieldInfoPtr_aiVisibility = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "aiVisibility");
		DamageController.NativeFieldInfoPtr_HitEffect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "HitEffect");
		DamageController.NativeFieldInfoPtr_ragdolling = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "ragdolling");
		DamageController.NativeFieldInfoPtr_DoNotToggleColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DoNotToggleColliders");
		DamageController.NativeFieldInfoPtr_ExplosionsIgnoreOwnColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "ExplosionsIgnoreOwnColliders");
		DamageController.NativeFieldInfoPtr_ParentDamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "ParentDamageController");
		DamageController.NativeFieldInfoPtr_DamageChildren = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageChildren");
		DamageController.NativeFieldInfoPtr_DiesWhenParentDies = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DiesWhenParentDies");
		DamageController.NativeFieldInfoPtr_KickBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "KickBody");
		DamageController.NativeFieldInfoPtr_DamageTypeMultipliers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageTypeMultipliers");
		DamageController.NativeFieldInfoPtr_DamageBlacklist = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageBlacklist");
		DamageController.NativeFieldInfoPtr_DamageWhitelist = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageWhitelist");
		DamageController.NativeFieldInfoPtr_DamageBodies = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageBodies");
		DamageController.NativeFieldInfoPtr_DamageColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageColliders");
		DamageController.NativeFieldInfoPtr_TotalBodySightWeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "TotalBodySightWeight");
		DamageController.NativeFieldInfoPtr_SizeScale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "SizeScale");
		DamageController.NativeFieldInfoPtr_SuppressionOwner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "SuppressionOwner");
		DamageController.NativeFieldInfoPtr_OnDeath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnDeath");
		DamageController.NativeFieldInfoPtr_OnDamageTaken = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "OnDamageTaken");
		DamageController.NativeFieldInfoPtr__invincibilityState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "_invincibilityState");
		DamageController.NativeFieldInfoPtr_isTracked = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "isTracked");
		DamageController.NativeFieldInfoPtr__staticListAdditionComplete = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "_staticListAdditionComplete");
		DamageController.NativeFieldInfoPtr_CachedColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "CachedColliders");
		DamageController.NativeFieldInfoPtr_CachedChestCollider = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "CachedChestCollider");
		DamageController.NativeFieldInfoPtr_isDamageBanned = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "isDamageBanned");
		DamageController.NativeFieldInfoPtr_DamageColliderCaches = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageColliderCaches");
		DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "Δδδ_H_RPC_ApplyDamageToChild");
		DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "Δδδ_H_RPC_ApplyDamage");
		DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_List_1_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665418);
		DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665419);
		DamageController.NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665420);
		DamageController.NativeMethodInfoPtr_GetAllDamageControllersInRange_Public_Static_Void_byref_List_1_DamageController_Vector3_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665421);
		DamageController.NativeMethodInfoPtr_GetAllDamageControllersAlongPath_Public_Static_Void_List_1_DamageController_List_1_ValueTuple_2_SuppressionOwner_Vector3_Vector3_Vector3_Single_Single_Boolean_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665422);
		DamageController.NativeMethodInfoPtr_get_Faction_Public_get_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665423);
		DamageController.NativeMethodInfoPtr_set_Faction_Public_set_Void_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665424);
		DamageController.NativeMethodInfoPtr_get_IsWounded_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665425);
		DamageController.NativeMethodInfoPtr_get_IsBleeding_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665426);
		DamageController.NativeMethodInfoPtr_get_IsCharacter_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665427);
		DamageController.NativeMethodInfoPtr_get_IsDead_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665428);
		DamageController.NativeMethodInfoPtr_get_IsAlive_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665429);
		DamageController.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665430);
		DamageController.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665431);
		DamageController.NativeMethodInfoPtr_get_IsDamageable_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665432);
		DamageController.NativeMethodInfoPtr_get_PassesAllLivingChecks_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665433);
		DamageController.NativeMethodInfoPtr_get_IsRelevantForAISight_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665434);
		DamageController.NativeMethodInfoPtr_add_OnDeath_Public_add_Void_DeathEvent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665435);
		DamageController.NativeMethodInfoPtr_remove_OnDeath_Public_rem_Void_DeathEvent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665436);
		DamageController.NativeMethodInfoPtr_add_OnDamageTaken_Public_add_Void_DamageEvent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665437);
		DamageController.NativeMethodInfoPtr_remove_OnDamageTaken_Public_rem_Void_DamageEvent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665438);
		DamageController.NativeMethodInfoPtr_get_IsDamageBanned_Public_Static_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665439);
		DamageController.NativeMethodInfoPtr_ShouldIgnoreDamageDueToBan_Public_Static_Boolean_DPIPlayer_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665440);
		DamageController.NativeMethodInfoPtr_ApplyDamage_Public_Static_Void_DamageController_Single_DamageType_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665441);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Private_Void_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665442);
		DamageController.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665443);
		DamageController.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665444);
		DamageController.NativeMethodInfoPtr_SetHealth_Public_Void_Single_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665445);
		DamageController.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665446);
		DamageController.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665447);
		DamageController.NativeMethodInfoPtr_RefreshBannedCache_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665448);
		DamageController.NativeMethodInfoPtr_AddToStaticList_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665449);
		DamageController.NativeMethodInfoPtr_RemoveFromStaticList_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665450);
		DamageController.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665451);
		DamageController.NativeMethodInfoPtr_ParentDied_Private_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665452);
		DamageController.NativeMethodInfoPtr_ToggleTriggers_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665453);
		DamageController.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665454);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Private_Void_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665455);
		DamageController.NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665456);
		DamageController.NativeMethodInfoPtr_Die_Private_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665457);
		DamageController.NativeMethodInfoPtr_Reset_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665458);
		DamageController.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665459);
		DamageController.NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665460);
		DamageController.NativeMethodInfoPtr_SetInvincibilityTimer_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665461);
		DamageController.NativeMethodInfoPtr_ToggleInvincibility_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665462);
		DamageController.NativeMethodInfoPtr_IsInvincible_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665463);
		DamageController.NativeMethodInfoPtr_GetExclusiveChildColliders_Public_ArrayOf_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665464);
		DamageController.NativeMethodInfoPtr_IsChildColliderExclusive_Protected_Boolean_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665465);
		DamageController.NativeMethodInfoPtr_AddDamageBody_Public_Void_DamageBody_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665466);
		DamageController.NativeMethodInfoPtr_GetChestCollider_Public_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665467);
		DamageController.NativeMethodInfoPtr_RegisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665468);
		DamageController.NativeMethodInfoPtr_UnregisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665469);
		DamageController.NativeMethodInfoPtr_RegisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665470);
		DamageController.NativeMethodInfoPtr_UnregisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665471);
		DamageController.NativeMethodInfoPtr_ClearColliderCaches_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665472);
		DamageController.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665473);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_ArrayOf_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665474);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665475);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_RpcTarget_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665476);
		DamageController.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665477);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_ArrayOf_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665478);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665479);
		DamageController.NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_RpcTarget_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665480);
		DamageController.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665481);
		DamageController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController>.NativeClassPtr, 100665482);
	}

	// Token: 0x06001AFF RID: 6911 RVA: 0x00047530 File Offset: 0x00045730
	public DamageController(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000945 RID: 2373
	// (get) Token: 0x06001B00 RID: 6912 RVA: 0x0006CBC0 File Offset: 0x0006ADC0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController>.NativeClassPtr));
		}
	}

	// Token: 0x17000946 RID: 2374
	// (get) Token: 0x06001B01 RID: 6913 RVA: 0x0006CBD4 File Offset: 0x0006ADD4
	// (set) Token: 0x06001B02 RID: 6914 RVA: 0x0006CBFF File Offset: 0x0006ADFF
	public unsafe static Action<Faction> OnAIDied
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_OnAIDied, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<Faction>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_OnAIDied, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000947 RID: 2375
	// (get) Token: 0x06001B03 RID: 6915 RVA: 0x0006CC14 File Offset: 0x0006AE14
	// (set) Token: 0x06001B04 RID: 6916 RVA: 0x0006CC48 File Offset: 0x0006AE48
	public unsafe OnwardPhotonView OnwardPhotonView
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnwardPhotonView);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OnwardPhotonView(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnwardPhotonView), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000948 RID: 2376
	// (get) Token: 0x06001B05 RID: 6917 RVA: 0x0006CC70 File Offset: 0x0006AE70
	// (set) Token: 0x06001B06 RID: 6918 RVA: 0x0006CC9B File Offset: 0x0006AE9B
	public unsafe static ConstantList<DamageController> allDamageControllers
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_allDamageControllers, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new ConstantList<DamageController>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_allDamageControllers, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000949 RID: 2377
	// (get) Token: 0x06001B07 RID: 6919 RVA: 0x0006CCB0 File Offset: 0x0006AEB0
	// (set) Token: 0x06001B08 RID: 6920 RVA: 0x0006CCDB File Offset: 0x0006AEDB
	public unsafe static Action<DamageController> OnDamageControllerAdded
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_OnDamageControllerAdded, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<DamageController>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_OnDamageControllerAdded, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700094A RID: 2378
	// (get) Token: 0x06001B09 RID: 6921 RVA: 0x0006CCF0 File Offset: 0x0006AEF0
	// (set) Token: 0x06001B0A RID: 6922 RVA: 0x0006CD1B File Offset: 0x0006AF1B
	public unsafe static Action<DamageController> OnDamageControllerRemoved
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_OnDamageControllerRemoved, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<DamageController>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_OnDamageControllerRemoved, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700094B RID: 2379
	// (get) Token: 0x06001B0B RID: 6923 RVA: 0x0006CD30 File Offset: 0x0006AF30
	// (set) Token: 0x06001B0C RID: 6924 RVA: 0x0006CD5B File Offset: 0x0006AF5B
	public unsafe static Action<DamageController> OnDamageControllerFactionChanged
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_OnDamageControllerFactionChanged, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<DamageController>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_OnDamageControllerFactionChanged, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700094C RID: 2380
	// (get) Token: 0x06001B0D RID: 6925 RVA: 0x0006CD70 File Offset: 0x0006AF70
	// (set) Token: 0x06001B0E RID: 6926 RVA: 0x0006CD9B File Offset: 0x0006AF9B
	public unsafe static Dictionary<int, DamageController> DamageControllersByPhotonID
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_DamageControllersByPhotonID, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<int, DamageController>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_DamageControllersByPhotonID, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700094D RID: 2381
	// (get) Token: 0x06001B0F RID: 6927 RVA: 0x0006CDB0 File Offset: 0x0006AFB0
	// (set) Token: 0x06001B10 RID: 6928 RVA: 0x0006CDD8 File Offset: 0x0006AFD8
	public unsafe Faction faction
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_faction);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_faction)) = value;
		}
	}

	// Token: 0x1700094E RID: 2382
	// (get) Token: 0x06001B11 RID: 6929 RVA: 0x0006CDFC File Offset: 0x0006AFFC
	// (set) Token: 0x06001B12 RID: 6930 RVA: 0x0006CE2E File Offset: 0x0006B02E
	public ObscuredFloat StartingHealth
	{
		get
		{
			IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_StartingHealth);
			return new ObscuredFloat(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, data));
		}
		set
		{
			cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_StartingHealth), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, (UIntPtr)0));
		}
	}

	// Token: 0x1700094F RID: 2383
	// (get) Token: 0x06001B13 RID: 6931 RVA: 0x0006CE64 File Offset: 0x0006B064
	// (set) Token: 0x06001B14 RID: 6932 RVA: 0x0006CE96 File Offset: 0x0006B096
	public ObscuredFloat CurrentHealth
	{
		get
		{
			IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CurrentHealth);
			return new ObscuredFloat(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, data));
		}
		set
		{
			cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CurrentHealth), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, (UIntPtr)0));
		}
	}

	// Token: 0x17000950 RID: 2384
	// (get) Token: 0x06001B15 RID: 6933 RVA: 0x0006CECC File Offset: 0x0006B0CC
	// (set) Token: 0x06001B16 RID: 6934 RVA: 0x0006CF00 File Offset: 0x0006B100
	public unsafe BhapticsVestBounds BhapticsReference
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_BhapticsReference);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new BhapticsVestBounds(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_BhapticsReference), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000951 RID: 2385
	// (get) Token: 0x06001B17 RID: 6935 RVA: 0x0006CF28 File Offset: 0x0006B128
	// (set) Token: 0x06001B18 RID: 6936 RVA: 0x0006CF5C File Offset: 0x0006B15C
	public unsafe Transform TargettingReference
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TargettingReference);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TargettingReference), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000952 RID: 2386
	// (get) Token: 0x06001B19 RID: 6937 RVA: 0x0006CF84 File Offset: 0x0006B184
	// (set) Token: 0x06001B1A RID: 6938 RVA: 0x0006CFAC File Offset: 0x0006B1AC
	public unsafe short TargetPriority
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TargetPriority);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TargetPriority)) = value;
		}
	}

	// Token: 0x17000953 RID: 2387
	// (get) Token: 0x06001B1B RID: 6939 RVA: 0x0006CFD0 File Offset: 0x0006B1D0
	// (set) Token: 0x06001B1C RID: 6940 RVA: 0x0006CFF8 File Offset: 0x0006B1F8
	public unsafe bool AllowsPassthroughDamage
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_AllowsPassthroughDamage);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_AllowsPassthroughDamage)) = value;
		}
	}

	// Token: 0x17000954 RID: 2388
	// (get) Token: 0x06001B1D RID: 6941 RVA: 0x0006D01C File Offset: 0x0006B21C
	// (set) Token: 0x06001B1E RID: 6942 RVA: 0x0006D044 File Offset: 0x0006B244
	public unsafe DamageControllerTypes DamageControllerType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageControllerType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageControllerType)) = value;
		}
	}

	// Token: 0x17000955 RID: 2389
	// (get) Token: 0x06001B1F RID: 6943 RVA: 0x0006D068 File Offset: 0x0006B268
	// (set) Token: 0x06001B20 RID: 6944 RVA: 0x0006D090 File Offset: 0x0006B290
	public unsafe bool IsValidAITarget
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_IsValidAITarget);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_IsValidAITarget)) = value;
		}
	}

	// Token: 0x17000956 RID: 2390
	// (get) Token: 0x06001B21 RID: 6945 RVA: 0x0006D0B4 File Offset: 0x0006B2B4
	// (set) Token: 0x06001B22 RID: 6946 RVA: 0x0006D0E8 File Offset: 0x0006B2E8
	public unsafe WarPlayerScript WarPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_WarPlayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_WarPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000957 RID: 2391
	// (get) Token: 0x06001B23 RID: 6947 RVA: 0x0006D110 File Offset: 0x0006B310
	// (set) Token: 0x06001B24 RID: 6948 RVA: 0x0006D144 File Offset: 0x0006B344
	public unsafe HumanoidAI AI
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_AI);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_AI), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000958 RID: 2392
	// (get) Token: 0x06001B25 RID: 6949 RVA: 0x0006D16C File Offset: 0x0006B36C
	// (set) Token: 0x06001B26 RID: 6950 RVA: 0x0006D1A0 File Offset: 0x0006B3A0
	public unsafe StatusController StatusController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_StatusController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new StatusController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_StatusController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000959 RID: 2393
	// (get) Token: 0x06001B27 RID: 6951 RVA: 0x0006D1C8 File Offset: 0x0006B3C8
	// (set) Token: 0x06001B28 RID: 6952 RVA: 0x0006D1F0 File Offset: 0x0006B3F0
	public unsafe bool isAI
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_isAI);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_isAI)) = value;
		}
	}

	// Token: 0x1700095A RID: 2394
	// (get) Token: 0x06001B29 RID: 6953 RVA: 0x0006D214 File Offset: 0x0006B414
	// (set) Token: 0x06001B2A RID: 6954 RVA: 0x0006D248 File Offset: 0x0006B448
	public unsafe DamageBoundaryStateController DamageBoundaryStateController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBoundaryStateController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageBoundaryStateController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBoundaryStateController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700095B RID: 2395
	// (get) Token: 0x06001B2B RID: 6955 RVA: 0x0006D270 File Offset: 0x0006B470
	// (set) Token: 0x06001B2C RID: 6956 RVA: 0x0006D298 File Offset: 0x0006B498
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x1700095C RID: 2396
	// (get) Token: 0x06001B2D RID: 6957 RVA: 0x0006D2BC File Offset: 0x0006B4BC
	// (set) Token: 0x06001B2E RID: 6958 RVA: 0x0006D2E4 File Offset: 0x0006B4E4
	public unsafe ObscuredBool aiVisibility
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_aiVisibility);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_aiVisibility)) = value;
		}
	}

	// Token: 0x1700095D RID: 2397
	// (get) Token: 0x06001B2F RID: 6959 RVA: 0x0006D308 File Offset: 0x0006B508
	// (set) Token: 0x06001B30 RID: 6960 RVA: 0x0006D33C File Offset: 0x0006B53C
	public unsafe GameObject HitEffect
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_HitEffect);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_HitEffect), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700095E RID: 2398
	// (get) Token: 0x06001B31 RID: 6961 RVA: 0x0006D364 File Offset: 0x0006B564
	// (set) Token: 0x06001B32 RID: 6962 RVA: 0x0006D38C File Offset: 0x0006B58C
	public unsafe bool ragdolling
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ragdolling);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ragdolling)) = value;
		}
	}

	// Token: 0x1700095F RID: 2399
	// (get) Token: 0x06001B33 RID: 6963 RVA: 0x0006D3B0 File Offset: 0x0006B5B0
	// (set) Token: 0x06001B34 RID: 6964 RVA: 0x0006D3D8 File Offset: 0x0006B5D8
	public unsafe bool DoNotToggleColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DoNotToggleColliders);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DoNotToggleColliders)) = value;
		}
	}

	// Token: 0x17000960 RID: 2400
	// (get) Token: 0x06001B35 RID: 6965 RVA: 0x0006D3FC File Offset: 0x0006B5FC
	// (set) Token: 0x06001B36 RID: 6966 RVA: 0x0006D424 File Offset: 0x0006B624
	public unsafe bool ExplosionsIgnoreOwnColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ExplosionsIgnoreOwnColliders);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ExplosionsIgnoreOwnColliders)) = value;
		}
	}

	// Token: 0x17000961 RID: 2401
	// (get) Token: 0x06001B37 RID: 6967 RVA: 0x0006D448 File Offset: 0x0006B648
	// (set) Token: 0x06001B38 RID: 6968 RVA: 0x0006D47C File Offset: 0x0006B67C
	public unsafe DamageController ParentDamageController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ParentDamageController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_ParentDamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000962 RID: 2402
	// (get) Token: 0x06001B39 RID: 6969 RVA: 0x0006D4A4 File Offset: 0x0006B6A4
	// (set) Token: 0x06001B3A RID: 6970 RVA: 0x0006D4D8 File Offset: 0x0006B6D8
	public unsafe Il2CppReferenceArray<DamageController> DamageChildren
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageChildren);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<DamageController>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageChildren), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000963 RID: 2403
	// (get) Token: 0x06001B3B RID: 6971 RVA: 0x0006D500 File Offset: 0x0006B700
	// (set) Token: 0x06001B3C RID: 6972 RVA: 0x0006D528 File Offset: 0x0006B728
	public unsafe bool DiesWhenParentDies
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DiesWhenParentDies);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DiesWhenParentDies)) = value;
		}
	}

	// Token: 0x17000964 RID: 2404
	// (get) Token: 0x06001B3D RID: 6973 RVA: 0x0006D54C File Offset: 0x0006B74C
	// (set) Token: 0x06001B3E RID: 6974 RVA: 0x0006D580 File Offset: 0x0006B780
	public unsafe Rigidbody KickBody
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_KickBody);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_KickBody), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000965 RID: 2405
	// (get) Token: 0x06001B3F RID: 6975 RVA: 0x0006D5A8 File Offset: 0x0006B7A8
	// (set) Token: 0x06001B40 RID: 6976 RVA: 0x0006D5DC File Offset: 0x0006B7DC
	public unsafe List<DamageController.DamageTypeMultiplier> DamageTypeMultipliers
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageTypeMultipliers);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageController.DamageTypeMultiplier>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageTypeMultipliers), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000966 RID: 2406
	// (get) Token: 0x06001B41 RID: 6977 RVA: 0x0006D604 File Offset: 0x0006B804
	// (set) Token: 0x06001B42 RID: 6978 RVA: 0x0006D638 File Offset: 0x0006B838
	public unsafe List<DamageType> DamageBlacklist
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBlacklist);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageType>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBlacklist), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000967 RID: 2407
	// (get) Token: 0x06001B43 RID: 6979 RVA: 0x0006D660 File Offset: 0x0006B860
	// (set) Token: 0x06001B44 RID: 6980 RVA: 0x0006D694 File Offset: 0x0006B894
	public unsafe List<DamageType> DamageWhitelist
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageWhitelist);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageType>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageWhitelist), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000968 RID: 2408
	// (get) Token: 0x06001B45 RID: 6981 RVA: 0x0006D6BC File Offset: 0x0006B8BC
	// (set) Token: 0x06001B46 RID: 6982 RVA: 0x0006D6F0 File Offset: 0x0006B8F0
	public unsafe List<DamageBody> DamageBodies
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBodies);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageBody>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageBodies), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000969 RID: 2409
	// (get) Token: 0x06001B47 RID: 6983 RVA: 0x0006D718 File Offset: 0x0006B918
	// (set) Token: 0x06001B48 RID: 6984 RVA: 0x0006D74C File Offset: 0x0006B94C
	public unsafe Il2CppReferenceArray<Collider> DamageColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Collider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_DamageColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700096A RID: 2410
	// (get) Token: 0x06001B49 RID: 6985 RVA: 0x0006D774 File Offset: 0x0006B974
	// (set) Token: 0x06001B4A RID: 6986 RVA: 0x0006D79C File Offset: 0x0006B99C
	public unsafe float TotalBodySightWeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TotalBodySightWeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_TotalBodySightWeight)) = value;
		}
	}

	// Token: 0x1700096B RID: 2411
	// (get) Token: 0x06001B4B RID: 6987 RVA: 0x0006D7C0 File Offset: 0x0006B9C0
	// (set) Token: 0x06001B4C RID: 6988 RVA: 0x0006D7E8 File Offset: 0x0006B9E8
	public unsafe float SizeScale
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_SizeScale);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_SizeScale)) = value;
		}
	}

	// Token: 0x1700096C RID: 2412
	// (get) Token: 0x06001B4D RID: 6989 RVA: 0x0006D80C File Offset: 0x0006BA0C
	// (set) Token: 0x06001B4E RID: 6990 RVA: 0x0006D840 File Offset: 0x0006BA40
	public unsafe SuppressionOwner SuppressionOwner
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_SuppressionOwner);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new SuppressionOwner(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_SuppressionOwner), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700096D RID: 2413
	// (get) Token: 0x06001B4F RID: 6991 RVA: 0x0006D868 File Offset: 0x0006BA68
	// (set) Token: 0x06001B50 RID: 6992 RVA: 0x0006D89C File Offset: 0x0006BA9C
	public unsafe DamageController.DeathEvent OnDeath
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnDeath);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController.DeathEvent(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnDeath), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700096E RID: 2414
	// (get) Token: 0x06001B51 RID: 6993 RVA: 0x0006D8C4 File Offset: 0x0006BAC4
	// (set) Token: 0x06001B52 RID: 6994 RVA: 0x0006D8F8 File Offset: 0x0006BAF8
	public unsafe DamageController.DamageEvent OnDamageTaken
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnDamageTaken);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController.DamageEvent(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_OnDamageTaken), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700096F RID: 2415
	// (get) Token: 0x06001B53 RID: 6995 RVA: 0x0006D920 File Offset: 0x0006BB20
	// (set) Token: 0x06001B54 RID: 6996 RVA: 0x0006D948 File Offset: 0x0006BB48
	public unsafe DamageController.InvincibilityState _invincibilityState
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__invincibilityState);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__invincibilityState)) = value;
		}
	}

	// Token: 0x17000970 RID: 2416
	// (get) Token: 0x06001B55 RID: 6997 RVA: 0x0006D96C File Offset: 0x0006BB6C
	// (set) Token: 0x06001B56 RID: 6998 RVA: 0x0006D994 File Offset: 0x0006BB94
	public unsafe bool isTracked
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_isTracked);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_isTracked)) = value;
		}
	}

	// Token: 0x17000971 RID: 2417
	// (get) Token: 0x06001B57 RID: 6999 RVA: 0x0006D9B8 File Offset: 0x0006BBB8
	// (set) Token: 0x06001B58 RID: 7000 RVA: 0x0006D9E0 File Offset: 0x0006BBE0
	public unsafe bool _staticListAdditionComplete
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__staticListAdditionComplete);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr__staticListAdditionComplete)) = value;
		}
	}

	// Token: 0x17000972 RID: 2418
	// (get) Token: 0x06001B59 RID: 7001 RVA: 0x0006DA04 File Offset: 0x0006BC04
	// (set) Token: 0x06001B5A RID: 7002 RVA: 0x0006DA38 File Offset: 0x0006BC38
	public unsafe Il2CppReferenceArray<Collider> CachedColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CachedColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Collider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CachedColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000973 RID: 2419
	// (get) Token: 0x06001B5B RID: 7003 RVA: 0x0006DA60 File Offset: 0x0006BC60
	// (set) Token: 0x06001B5C RID: 7004 RVA: 0x0006DA94 File Offset: 0x0006BC94
	public unsafe Collider CachedChestCollider
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CachedChestCollider);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Collider(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_CachedChestCollider), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000974 RID: 2420
	// (get) Token: 0x06001B5D RID: 7005 RVA: 0x0006DABC File Offset: 0x0006BCBC
	// (set) Token: 0x06001B5E RID: 7006 RVA: 0x0006DADA File Offset: 0x0006BCDA
	public unsafe static bool isDamageBanned
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_isDamageBanned, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_isDamageBanned, (void*)(&value));
		}
	}

	// Token: 0x17000975 RID: 2421
	// (get) Token: 0x06001B5F RID: 7007 RVA: 0x0006DAEC File Offset: 0x0006BCEC
	// (set) Token: 0x06001B60 RID: 7008 RVA: 0x0006DB17 File Offset: 0x0006BD17
	public unsafe static Dictionary<Collider, DamageController.DamageColliderCache> DamageColliderCaches
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageController.NativeFieldInfoPtr_DamageColliderCaches, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<Collider, DamageController.DamageColliderCache>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageController.NativeFieldInfoPtr_DamageColliderCaches, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000976 RID: 2422
	// (get) Token: 0x06001B61 RID: 7009 RVA: 0x0006DB2C File Offset: 0x0006BD2C
	// (set) Token: 0x06001B62 RID: 7010 RVA: 0x0006DB60 File Offset: 0x0006BD60
	public unsafe EntityClientRpcHandle<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique> field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_0
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_0);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EntityClientRpcHandle<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_0), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000977 RID: 2423
	// (get) Token: 0x06001B63 RID: 7011 RVA: 0x0006DB88 File Offset: 0x0006BD88
	// (set) Token: 0x06001B64 RID: 7012 RVA: 0x0006DBBC File Offset: 0x0006BDBC
	public unsafe EntityClientRpcHandle<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique> field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_0
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_0);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EntityClientRpcHandle<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_0), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400113D RID: 4413
	private static readonly IntPtr NativeFieldInfoPtr_OnAIDied;

	// Token: 0x0400113E RID: 4414
	private static readonly IntPtr NativeFieldInfoPtr_OnwardPhotonView;

	// Token: 0x0400113F RID: 4415
	private static readonly IntPtr NativeFieldInfoPtr_allDamageControllers;

	// Token: 0x04001140 RID: 4416
	private static readonly IntPtr NativeFieldInfoPtr_OnDamageControllerAdded;

	// Token: 0x04001141 RID: 4417
	private static readonly IntPtr NativeFieldInfoPtr_OnDamageControllerRemoved;

	// Token: 0x04001142 RID: 4418
	private static readonly IntPtr NativeFieldInfoPtr_OnDamageControllerFactionChanged;

	// Token: 0x04001143 RID: 4419
	private static readonly IntPtr NativeFieldInfoPtr_DamageControllersByPhotonID;

	// Token: 0x04001144 RID: 4420
	private static readonly IntPtr NativeFieldInfoPtr_faction;

	// Token: 0x04001145 RID: 4421
	private static readonly IntPtr NativeFieldInfoPtr_StartingHealth;

	// Token: 0x04001146 RID: 4422
	private static readonly IntPtr NativeFieldInfoPtr_CurrentHealth;

	// Token: 0x04001147 RID: 4423
	private static readonly IntPtr NativeFieldInfoPtr_BhapticsReference;

	// Token: 0x04001148 RID: 4424
	private static readonly IntPtr NativeFieldInfoPtr_TargettingReference;

	// Token: 0x04001149 RID: 4425
	private static readonly IntPtr NativeFieldInfoPtr_TargetPriority;

	// Token: 0x0400114A RID: 4426
	private static readonly IntPtr NativeFieldInfoPtr_AllowsPassthroughDamage;

	// Token: 0x0400114B RID: 4427
	private static readonly IntPtr NativeFieldInfoPtr_DamageControllerType;

	// Token: 0x0400114C RID: 4428
	private static readonly IntPtr NativeFieldInfoPtr_IsValidAITarget;

	// Token: 0x0400114D RID: 4429
	private static readonly IntPtr NativeFieldInfoPtr_WarPlayer;

	// Token: 0x0400114E RID: 4430
	private static readonly IntPtr NativeFieldInfoPtr_AI;

	// Token: 0x0400114F RID: 4431
	private static readonly IntPtr NativeFieldInfoPtr_StatusController;

	// Token: 0x04001150 RID: 4432
	private static readonly IntPtr NativeFieldInfoPtr_isAI;

	// Token: 0x04001151 RID: 4433
	private static readonly IntPtr NativeFieldInfoPtr_DamageBoundaryStateController;

	// Token: 0x04001152 RID: 4434
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x04001153 RID: 4435
	private static readonly IntPtr NativeFieldInfoPtr_aiVisibility;

	// Token: 0x04001154 RID: 4436
	private static readonly IntPtr NativeFieldInfoPtr_HitEffect;

	// Token: 0x04001155 RID: 4437
	private static readonly IntPtr NativeFieldInfoPtr_ragdolling;

	// Token: 0x04001156 RID: 4438
	private static readonly IntPtr NativeFieldInfoPtr_DoNotToggleColliders;

	// Token: 0x04001157 RID: 4439
	private static readonly IntPtr NativeFieldInfoPtr_ExplosionsIgnoreOwnColliders;

	// Token: 0x04001158 RID: 4440
	private static readonly IntPtr NativeFieldInfoPtr_ParentDamageController;

	// Token: 0x04001159 RID: 4441
	private static readonly IntPtr NativeFieldInfoPtr_DamageChildren;

	// Token: 0x0400115A RID: 4442
	private static readonly IntPtr NativeFieldInfoPtr_DiesWhenParentDies;

	// Token: 0x0400115B RID: 4443
	private static readonly IntPtr NativeFieldInfoPtr_KickBody;

	// Token: 0x0400115C RID: 4444
	private static readonly IntPtr NativeFieldInfoPtr_DamageTypeMultipliers;

	// Token: 0x0400115D RID: 4445
	private static readonly IntPtr NativeFieldInfoPtr_DamageBlacklist;

	// Token: 0x0400115E RID: 4446
	private static readonly IntPtr NativeFieldInfoPtr_DamageWhitelist;

	// Token: 0x0400115F RID: 4447
	private static readonly IntPtr NativeFieldInfoPtr_DamageBodies;

	// Token: 0x04001160 RID: 4448
	private static readonly IntPtr NativeFieldInfoPtr_DamageColliders;

	// Token: 0x04001161 RID: 4449
	private static readonly IntPtr NativeFieldInfoPtr_TotalBodySightWeight;

	// Token: 0x04001162 RID: 4450
	private static readonly IntPtr NativeFieldInfoPtr_SizeScale;

	// Token: 0x04001163 RID: 4451
	private static readonly IntPtr NativeFieldInfoPtr_SuppressionOwner;

	// Token: 0x04001164 RID: 4452
	private static readonly IntPtr NativeFieldInfoPtr_OnDeath;

	// Token: 0x04001165 RID: 4453
	private static readonly IntPtr NativeFieldInfoPtr_OnDamageTaken;

	// Token: 0x04001166 RID: 4454
	private static readonly IntPtr NativeFieldInfoPtr__invincibilityState;

	// Token: 0x04001167 RID: 4455
	private static readonly IntPtr NativeFieldInfoPtr_isTracked;

	// Token: 0x04001168 RID: 4456
	private static readonly IntPtr NativeFieldInfoPtr__staticListAdditionComplete;

	// Token: 0x04001169 RID: 4457
	private static readonly IntPtr NativeFieldInfoPtr_CachedColliders;

	// Token: 0x0400116A RID: 4458
	private static readonly IntPtr NativeFieldInfoPtr_CachedChestCollider;

	// Token: 0x0400116B RID: 4459
	private static readonly IntPtr NativeFieldInfoPtr_isDamageBanned;

	// Token: 0x0400116C RID: 4460
	private static readonly IntPtr NativeFieldInfoPtr_DamageColliderCaches;

	// Token: 0x0400116D RID: 4461
	private static readonly IntPtr NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_0;

	// Token: 0x0400116E RID: 4462
	private static readonly IntPtr NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_0;

	// Token: 0x0400116F RID: 4463
	private static readonly IntPtr NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_List_1_DamageController_0;

	// Token: 0x04001170 RID: 4464
	private static readonly IntPtr NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_0;

	// Token: 0x04001171 RID: 4465
	private static readonly IntPtr NativeMethodInfoPtr_GetAllDamageControllers_Public_Static_Void_byref_List_1_DamageController_Faction_0;

	// Token: 0x04001172 RID: 4466
	private static readonly IntPtr NativeMethodInfoPtr_GetAllDamageControllersInRange_Public_Static_Void_byref_List_1_DamageController_Vector3_Single_Boolean_0;

	// Token: 0x04001173 RID: 4467
	private static readonly IntPtr NativeMethodInfoPtr_GetAllDamageControllersAlongPath_Public_Static_Void_List_1_DamageController_List_1_ValueTuple_2_SuppressionOwner_Vector3_Vector3_Vector3_Single_Single_Boolean_Boolean_0;

	// Token: 0x04001174 RID: 4468
	private static readonly IntPtr NativeMethodInfoPtr_get_Faction_Public_get_Faction_0;

	// Token: 0x04001175 RID: 4469
	private static readonly IntPtr NativeMethodInfoPtr_set_Faction_Public_set_Void_Faction_0;

	// Token: 0x04001176 RID: 4470
	private static readonly IntPtr NativeMethodInfoPtr_get_IsWounded_Public_get_Boolean_0;

	// Token: 0x04001177 RID: 4471
	private static readonly IntPtr NativeMethodInfoPtr_get_IsBleeding_Public_get_Boolean_0;

	// Token: 0x04001178 RID: 4472
	private static readonly IntPtr NativeMethodInfoPtr_get_IsCharacter_Public_get_Boolean_0;

	// Token: 0x04001179 RID: 4473
	private static readonly IntPtr NativeMethodInfoPtr_get_IsDead_Public_get_Boolean_0;

	// Token: 0x0400117A RID: 4474
	private static readonly IntPtr NativeMethodInfoPtr_get_IsAlive_Public_get_Boolean_0;

	// Token: 0x0400117B RID: 4475
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x0400117C RID: 4476
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x0400117D RID: 4477
	private static readonly IntPtr NativeMethodInfoPtr_get_IsDamageable_Public_get_Boolean_0;

	// Token: 0x0400117E RID: 4478
	private static readonly IntPtr NativeMethodInfoPtr_get_PassesAllLivingChecks_Public_get_Boolean_0;

	// Token: 0x0400117F RID: 4479
	private static readonly IntPtr NativeMethodInfoPtr_get_IsRelevantForAISight_Public_get_Boolean_0;

	// Token: 0x04001180 RID: 4480
	private static readonly IntPtr NativeMethodInfoPtr_add_OnDeath_Public_add_Void_DeathEvent_0;

	// Token: 0x04001181 RID: 4481
	private static readonly IntPtr NativeMethodInfoPtr_remove_OnDeath_Public_rem_Void_DeathEvent_0;

	// Token: 0x04001182 RID: 4482
	private static readonly IntPtr NativeMethodInfoPtr_add_OnDamageTaken_Public_add_Void_DamageEvent_0;

	// Token: 0x04001183 RID: 4483
	private static readonly IntPtr NativeMethodInfoPtr_remove_OnDamageTaken_Public_rem_Void_DamageEvent_0;

	// Token: 0x04001184 RID: 4484
	private static readonly IntPtr NativeMethodInfoPtr_get_IsDamageBanned_Public_Static_get_Boolean_0;

	// Token: 0x04001185 RID: 4485
	private static readonly IntPtr NativeMethodInfoPtr_ShouldIgnoreDamageDueToBan_Public_Static_Boolean_DPIPlayer_DPIPlayer_Int32_0;

	// Token: 0x04001186 RID: 4486
	private static readonly IntPtr NativeMethodInfoPtr_ApplyDamage_Public_Static_Void_DamageController_Single_DamageType_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x04001187 RID: 4487
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamageToChild_Private_Void_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0;

	// Token: 0x04001188 RID: 4488
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04001189 RID: 4489
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x0400118A RID: 4490
	private static readonly IntPtr NativeMethodInfoPtr_SetHealth_Public_Void_Single_DPIPlayer_0;

	// Token: 0x0400118B RID: 4491
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x0400118C RID: 4492
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x0400118D RID: 4493
	private static readonly IntPtr NativeMethodInfoPtr_RefreshBannedCache_Public_Void_0;

	// Token: 0x0400118E RID: 4494
	private static readonly IntPtr NativeMethodInfoPtr_AddToStaticList_Private_Void_0;

	// Token: 0x0400118F RID: 4495
	private static readonly IntPtr NativeMethodInfoPtr_RemoveFromStaticList_Private_Void_0;

	// Token: 0x04001190 RID: 4496
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04001191 RID: 4497
	private static readonly IntPtr NativeMethodInfoPtr_ParentDied_Private_Void_DPIPlayer_0;

	// Token: 0x04001192 RID: 4498
	private static readonly IntPtr NativeMethodInfoPtr_ToggleTriggers_Public_Void_Boolean_0;

	// Token: 0x04001193 RID: 4499
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04001194 RID: 4500
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamage_Private_Void_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_DPINetworkMessageInfo_0;

	// Token: 0x04001195 RID: 4501
	private static readonly IntPtr NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0;

	// Token: 0x04001196 RID: 4502
	private static readonly IntPtr NativeMethodInfoPtr_Die_Private_Void_DPIPlayer_0;

	// Token: 0x04001197 RID: 4503
	private static readonly IntPtr NativeMethodInfoPtr_Reset_Public_Void_0;

	// Token: 0x04001198 RID: 4504
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04001199 RID: 4505
	private static readonly IntPtr NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0;

	// Token: 0x0400119A RID: 4506
	private static readonly IntPtr NativeMethodInfoPtr_SetInvincibilityTimer_Public_Void_Single_0;

	// Token: 0x0400119B RID: 4507
	private static readonly IntPtr NativeMethodInfoPtr_ToggleInvincibility_Public_Void_0;

	// Token: 0x0400119C RID: 4508
	private static readonly IntPtr NativeMethodInfoPtr_IsInvincible_Public_Boolean_0;

	// Token: 0x0400119D RID: 4509
	private static readonly IntPtr NativeMethodInfoPtr_GetExclusiveChildColliders_Public_ArrayOf_Collider_0;

	// Token: 0x0400119E RID: 4510
	private static readonly IntPtr NativeMethodInfoPtr_IsChildColliderExclusive_Protected_Boolean_Collider_0;

	// Token: 0x0400119F RID: 4511
	private static readonly IntPtr NativeMethodInfoPtr_AddDamageBody_Public_Void_DamageBody_0;

	// Token: 0x040011A0 RID: 4512
	private static readonly IntPtr NativeMethodInfoPtr_GetChestCollider_Public_Collider_0;

	// Token: 0x040011A1 RID: 4513
	private static readonly IntPtr NativeMethodInfoPtr_RegisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0;

	// Token: 0x040011A2 RID: 4514
	private static readonly IntPtr NativeMethodInfoPtr_UnregisterControllerColliders_Public_Static_Void_DamageController_ArrayOf_Collider_0;

	// Token: 0x040011A3 RID: 4515
	private static readonly IntPtr NativeMethodInfoPtr_RegisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0;

	// Token: 0x040011A4 RID: 4516
	private static readonly IntPtr NativeMethodInfoPtr_UnregisterBodyColliders_Public_Static_Void_DamageBody_ArrayOf_Collider_0;

	// Token: 0x040011A5 RID: 4517
	private static readonly IntPtr NativeMethodInfoPtr_ClearColliderCaches_Public_Static_Void_0;

	// Token: 0x040011A6 RID: 4518
	private static readonly IntPtr NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique_DPINetworkMessageInfo_0;

	// Token: 0x040011A7 RID: 4519
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_ArrayOf_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011A8 RID: 4520
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_DPIPlayer_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011A9 RID: 4521
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamageToChild_Public_Void_RpcTarget_Int32_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011AA RID: 4522
	private static readonly IntPtr NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique_DPINetworkMessageInfo_0;

	// Token: 0x040011AB RID: 4523
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_ArrayOf_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011AC RID: 4524
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_DPIPlayer_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011AD RID: 4525
	private static readonly IntPtr NativeMethodInfoPtr_RPC_ApplyDamage_Public_Void_RpcTarget_Single_Byte_Nullable_1_Vector3_DPIPlayer_Int32_0;

	// Token: 0x040011AE RID: 4526
	private static readonly IntPtr NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0;

	// Token: 0x040011AF RID: 4527
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000193 RID: 403
	[Serializable]
	public class DamageTypeMultiplier : Il2CppSystem.Object
	{
		// Token: 0x06001B65 RID: 7013 RVA: 0x0006DBE4 File Offset: 0x0006BDE4
		[CallerCount(0)]
		public unsafe DamageTypeMultiplier() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageTypeMultiplier.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B66 RID: 7014 RVA: 0x0006DC30 File Offset: 0x0006BE30
		// Note: this type is marked as 'beforefieldinit'.
		static DamageTypeMultiplier()
		{
			Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageTypeMultiplier");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr);
			DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr, "type");
			DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_multiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr, "multiplier");
			DamageController.DamageTypeMultiplier.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr, 100665484);
		}

		// Token: 0x06001B67 RID: 7015 RVA: 0x00002988 File Offset: 0x00000B88
		public DamageTypeMultiplier(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000983 RID: 2435
		// (get) Token: 0x06001B68 RID: 7016 RVA: 0x0006DC97 File Offset: 0x0006BE97
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.DamageTypeMultiplier>.NativeClassPtr));
			}
		}

		// Token: 0x17000984 RID: 2436
		// (get) Token: 0x06001B69 RID: 7017 RVA: 0x0006DCA8 File Offset: 0x0006BEA8
		// (set) Token: 0x06001B6A RID: 7018 RVA: 0x0006DCD0 File Offset: 0x0006BED0
		public unsafe DamageType type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_type)) = value;
			}
		}

		// Token: 0x17000985 RID: 2437
		// (get) Token: 0x06001B6B RID: 7019 RVA: 0x0006DCF4 File Offset: 0x0006BEF4
		// (set) Token: 0x06001B6C RID: 7020 RVA: 0x0006DD1C File Offset: 0x0006BF1C
		public unsafe float multiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_multiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageTypeMultiplier.NativeFieldInfoPtr_multiplier)) = value;
			}
		}

		// Token: 0x040011B0 RID: 4528
		private static readonly IntPtr NativeFieldInfoPtr_type;

		// Token: 0x040011B1 RID: 4529
		private static readonly IntPtr NativeFieldInfoPtr_multiplier;

		// Token: 0x040011B2 RID: 4530
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000194 RID: 404
	public sealed class DeathEvent : MulticastDelegate
	{
		// Token: 0x06001B6D RID: 7021 RVA: 0x0006DD40 File Offset: 0x0006BF40
		[CallerCount(0)]
		public unsafe DeathEvent(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DeathEvent.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B6E RID: 7022 RVA: 0x0006DDB8 File Offset: 0x0006BFB8
		[CallerCount(0)]
		public unsafe void Invoke(DPIPlayer source)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DeathEvent.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B6F RID: 7023 RVA: 0x0006DE14 File Offset: 0x0006C014
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(DPIPlayer source, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DeathEvent.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_DPIPlayer_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x06001B70 RID: 7024 RVA: 0x0006DEB4 File Offset: 0x0006C0B4
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DeathEvent.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B71 RID: 7025 RVA: 0x0006DF10 File Offset: 0x0006C110
		// Note: this type is marked as 'beforefieldinit'.
		static DeathEvent()
		{
			Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DeathEvent");
			DamageController.DeathEvent.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr, 100665485);
			DamageController.DeathEvent.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr, 100665486);
			DamageController.DeathEvent.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_DPIPlayer_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr, 100665487);
			DamageController.DeathEvent.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr, 100665488);
		}

		// Token: 0x06001B72 RID: 7026 RVA: 0x00005E35 File Offset: 0x00004035
		public DeathEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000986 RID: 2438
		// (get) Token: 0x06001B73 RID: 7027 RVA: 0x0006DF81 File Offset: 0x0006C181
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.DeathEvent>.NativeClassPtr));
			}
		}

		// Token: 0x06001B74 RID: 7028 RVA: 0x0006DF92 File Offset: 0x0006C192
		public static implicit operator DamageController.DeathEvent(Action<DPIPlayer> A_0)
		{
			return DelegateSupport.ConvertDelegate<DamageController.DeathEvent>(A_0);
		}

		// Token: 0x06001B75 RID: 7029 RVA: 0x0006DF9A File Offset: 0x0006C19A
		public static DamageController.DeathEvent operator +(DamageController.DeathEvent A_0, DamageController.DeathEvent A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DamageController.DeathEvent>();
		}

		// Token: 0x06001B76 RID: 7030 RVA: 0x0006DFA8 File Offset: 0x0006C1A8
		public static DamageController.DeathEvent operator -(DamageController.DeathEvent A_0, DamageController.DeathEvent A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DamageController.DeathEvent>();
			}
			return result;
		}

		// Token: 0x040011B3 RID: 4531
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x040011B4 RID: 4532
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_DPIPlayer_0;

		// Token: 0x040011B5 RID: 4533
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_DPIPlayer_AsyncCallback_Object_0;

		// Token: 0x040011B6 RID: 4534
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x02000195 RID: 405
	public sealed class DamageEvent : MulticastDelegate
	{
		// Token: 0x06001B77 RID: 7031 RVA: 0x0006DFBC File Offset: 0x0006C1BC
		[CallerCount(0)]
		public unsafe DamageEvent(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageEvent.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B78 RID: 7032 RVA: 0x0006E034 File Offset: 0x0006C234
		[CallerCount(0)]
		public unsafe void Invoke(float amount, DamageType damageType, DPIPlayer source)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref amount;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageEvent.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_DamageType_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B79 RID: 7033 RVA: 0x0006E0B4 File Offset: 0x0006C2B4
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(float amount, DamageType damageType, DPIPlayer source, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref amount;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageEvent.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_DamageType_DPIPlayer_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x06001B7A RID: 7034 RVA: 0x0006E178 File Offset: 0x0006C378
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageEvent.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B7B RID: 7035 RVA: 0x0006E1D4 File Offset: 0x0006C3D4
		// Note: this type is marked as 'beforefieldinit'.
		static DamageEvent()
		{
			Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageEvent");
			DamageController.DamageEvent.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr, 100665489);
			DamageController.DamageEvent.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_DamageType_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr, 100665490);
			DamageController.DamageEvent.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_DamageType_DPIPlayer_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr, 100665491);
			DamageController.DamageEvent.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr, 100665492);
		}

		// Token: 0x06001B7C RID: 7036 RVA: 0x00005E35 File Offset: 0x00004035
		public DamageEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000987 RID: 2439
		// (get) Token: 0x06001B7D RID: 7037 RVA: 0x0006E245 File Offset: 0x0006C445
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.DamageEvent>.NativeClassPtr));
			}
		}

		// Token: 0x06001B7E RID: 7038 RVA: 0x0006E256 File Offset: 0x0006C456
		public static implicit operator DamageController.DamageEvent(Action<float, DamageType, DPIPlayer> A_0)
		{
			return DelegateSupport.ConvertDelegate<DamageController.DamageEvent>(A_0);
		}

		// Token: 0x06001B7F RID: 7039 RVA: 0x0006E25E File Offset: 0x0006C45E
		public static DamageController.DamageEvent operator +(DamageController.DamageEvent A_0, DamageController.DamageEvent A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DamageController.DamageEvent>();
		}

		// Token: 0x06001B80 RID: 7040 RVA: 0x0006E26C File Offset: 0x0006C46C
		public static DamageController.DamageEvent operator -(DamageController.DamageEvent A_0, DamageController.DamageEvent A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DamageController.DamageEvent>();
			}
			return result;
		}

		// Token: 0x040011B7 RID: 4535
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x040011B8 RID: 4536
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_DamageType_DPIPlayer_0;

		// Token: 0x040011B9 RID: 4537
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_DamageType_DPIPlayer_AsyncCallback_Object_0;

		// Token: 0x040011BA RID: 4538
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x02000196 RID: 406
	[StructLayout(2)]
	public struct InvincibilityState
	{
		// Token: 0x06001B81 RID: 7041 RVA: 0x0006E280 File Offset: 0x0006C480
		[CallerCount(0)]
		public unsafe void SetTimedInvincibility(float duration)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.InvincibilityState.NativeMethodInfoPtr_SetTimedInvincibility_Public_Void_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B82 RID: 7042 RVA: 0x0006E2C8 File Offset: 0x0006C4C8
		[CallerCount(0)]
		public unsafe void SetInvincibility(bool isInvincible)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isInvincible;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.InvincibilityState.NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B83 RID: 7043 RVA: 0x0006E310 File Offset: 0x0006C510
		[CallerCount(0)]
		public unsafe void Toggle()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.InvincibilityState.NativeMethodInfoPtr_Toggle_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B84 RID: 7044 RVA: 0x0006E344 File Offset: 0x0006C544
		[CallerCount(0)]
		public unsafe bool IsActive()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.InvincibilityState.NativeMethodInfoPtr_IsActive_Public_Boolean_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06001B85 RID: 7045 RVA: 0x0006E388 File Offset: 0x0006C588
		// Note: this type is marked as 'beforefieldinit'.
		static InvincibilityState()
		{
			Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "InvincibilityState");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr);
			DamageController.InvincibilityState.NativeFieldInfoPtr_ENABLED_UNLIMITED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, "ENABLED_UNLIMITED");
			DamageController.InvincibilityState.NativeFieldInfoPtr_DISABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, "DISABLED");
			DamageController.InvincibilityState.NativeFieldInfoPtr__invincibilityTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, "_invincibilityTimer");
			DamageController.InvincibilityState.NativeMethodInfoPtr_SetTimedInvincibility_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, 100665493);
			DamageController.InvincibilityState.NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, 100665494);
			DamageController.InvincibilityState.NativeMethodInfoPtr_Toggle_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, 100665495);
			DamageController.InvincibilityState.NativeMethodInfoPtr_IsActive_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, 100665496);
		}

		// Token: 0x06001B86 RID: 7046 RVA: 0x0006E43F File Offset: 0x0006C63F
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr, ref this));
		}

		// Token: 0x17000988 RID: 2440
		// (get) Token: 0x06001B87 RID: 7047 RVA: 0x0006E451 File Offset: 0x0006C651
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.InvincibilityState>.NativeClassPtr));
			}
		}

		// Token: 0x17000989 RID: 2441
		// (get) Token: 0x06001B88 RID: 7048 RVA: 0x0006E464 File Offset: 0x0006C664
		// (set) Token: 0x06001B89 RID: 7049 RVA: 0x0006E482 File Offset: 0x0006C682
		public unsafe static float ENABLED_UNLIMITED
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(DamageController.InvincibilityState.NativeFieldInfoPtr_ENABLED_UNLIMITED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(DamageController.InvincibilityState.NativeFieldInfoPtr_ENABLED_UNLIMITED, (void*)(&value));
			}
		}

		// Token: 0x1700098A RID: 2442
		// (get) Token: 0x06001B8A RID: 7050 RVA: 0x0006E494 File Offset: 0x0006C694
		// (set) Token: 0x06001B8B RID: 7051 RVA: 0x0006E4B2 File Offset: 0x0006C6B2
		public unsafe static float DISABLED
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(DamageController.InvincibilityState.NativeFieldInfoPtr_DISABLED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(DamageController.InvincibilityState.NativeFieldInfoPtr_DISABLED, (void*)(&value));
			}
		}

		// Token: 0x040011BB RID: 4539
		private static readonly IntPtr NativeFieldInfoPtr_ENABLED_UNLIMITED;

		// Token: 0x040011BC RID: 4540
		private static readonly IntPtr NativeFieldInfoPtr_DISABLED;

		// Token: 0x040011BD RID: 4541
		private static readonly IntPtr NativeFieldInfoPtr__invincibilityTimer;

		// Token: 0x040011BE RID: 4542
		private static readonly IntPtr NativeMethodInfoPtr_SetTimedInvincibility_Public_Void_Single_0;

		// Token: 0x040011BF RID: 4543
		private static readonly IntPtr NativeMethodInfoPtr_SetInvincibility_Public_Void_Boolean_0;

		// Token: 0x040011C0 RID: 4544
		private static readonly IntPtr NativeMethodInfoPtr_Toggle_Public_Void_0;

		// Token: 0x040011C1 RID: 4545
		private static readonly IntPtr NativeMethodInfoPtr_IsActive_Public_Boolean_0;

		// Token: 0x040011C2 RID: 4546
		[FieldOffset(0)]
		public float _invincibilityTimer;
	}

	// Token: 0x02000197 RID: 407
	public class DamageColliderCache : Il2CppSystem.Object
	{
		// Token: 0x1700098E RID: 2446
		// (get) Token: 0x06001B8C RID: 7052 RVA: 0x0006E4C4 File Offset: 0x0006C6C4
		public unsafe bool IsClear
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageColliderCache.NativeMethodInfoPtr_get_IsClear_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06001B8D RID: 7053 RVA: 0x0006E514 File Offset: 0x0006C714
		[CallerCount(0)]
		public unsafe DamageColliderCache() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.DamageColliderCache.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B8E RID: 7054 RVA: 0x0006E560 File Offset: 0x0006C760
		// Note: this type is marked as 'beforefieldinit'.
		static DamageColliderCache()
		{
			Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "DamageColliderCache");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr);
			DamageController.DamageColliderCache.NativeFieldInfoPtr_damageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr, "damageController");
			DamageController.DamageColliderCache.NativeFieldInfoPtr_damageBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr, "damageBody");
			DamageController.DamageColliderCache.NativeMethodInfoPtr_get_IsClear_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr, 100665497);
			DamageController.DamageColliderCache.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr, 100665498);
		}

		// Token: 0x06001B8F RID: 7055 RVA: 0x00002988 File Offset: 0x00000B88
		public DamageColliderCache(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700098B RID: 2443
		// (get) Token: 0x06001B90 RID: 7056 RVA: 0x0006E5DB File Offset: 0x0006C7DB
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.DamageColliderCache>.NativeClassPtr));
			}
		}

		// Token: 0x1700098C RID: 2444
		// (get) Token: 0x06001B91 RID: 7057 RVA: 0x0006E5EC File Offset: 0x0006C7EC
		// (set) Token: 0x06001B92 RID: 7058 RVA: 0x0006E620 File Offset: 0x0006C820
		public unsafe DamageController damageController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageColliderCache.NativeFieldInfoPtr_damageController);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageColliderCache.NativeFieldInfoPtr_damageController), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700098D RID: 2445
		// (get) Token: 0x06001B93 RID: 7059 RVA: 0x0006E648 File Offset: 0x0006C848
		// (set) Token: 0x06001B94 RID: 7060 RVA: 0x0006E67C File Offset: 0x0006C87C
		public unsafe DamageBody damageBody
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageColliderCache.NativeFieldInfoPtr_damageBody);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageBody(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.DamageColliderCache.NativeFieldInfoPtr_damageBody), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040011C3 RID: 4547
		private static readonly IntPtr NativeFieldInfoPtr_damageController;

		// Token: 0x040011C4 RID: 4548
		private static readonly IntPtr NativeFieldInfoPtr_damageBody;

		// Token: 0x040011C5 RID: 4549
		private static readonly IntPtr NativeMethodInfoPtr_get_IsClear_Public_get_Boolean_0;

		// Token: 0x040011C6 RID: 4550
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000198 RID: 408
	[ObfuscatedName("DamageController/Δδδ_S_RPC_ApplyDamageToChild")]
	[StructLayout(0)]
	public sealed class ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique : ValueType
	{
		// Token: 0x06001B95 RID: 7061 RVA: 0x0006E6A4 File Offset: 0x0006C8A4
		[CallerCount(0)]
		public unsafe void Read(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B96 RID: 7062 RVA: 0x0006E6FC File Offset: 0x0006C8FC
		[CallerCount(0)]
		public unsafe void Write(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001B97 RID: 7063 RVA: 0x0006E754 File Offset: 0x0006C954
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique()
		{
			Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "Δδδ_S_RPC_ApplyDamageToChild");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr);
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_childIndex");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_amount");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_damageTypeByte");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_force");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_source");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_aiSourceID");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, 100665499);
			DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, 100665500);
		}

		// Token: 0x06001B98 RID: 7064 RVA: 0x0002717B File Offset: 0x0002537B
		public ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700098F RID: 2447
		// (get) Token: 0x06001B99 RID: 7065 RVA: 0x0006E81F File Offset: 0x0006CA1F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr));
			}
		}

		// Token: 0x06001B9A RID: 7066 RVA: 0x0006E830 File Offset: 0x0006CA30
		public unsafe ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique>.NativeClassPtr, data));
		}

		// Token: 0x17000990 RID: 2448
		// (get) Token: 0x06001B9B RID: 7067 RVA: 0x0006E860 File Offset: 0x0006CA60
		// (set) Token: 0x06001B9C RID: 7068 RVA: 0x0006E888 File Offset: 0x0006CA88
		public unsafe int field_Public_Int32_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0)) = value;
			}
		}

		// Token: 0x17000991 RID: 2449
		// (get) Token: 0x06001B9D RID: 7069 RVA: 0x0006E8AC File Offset: 0x0006CAAC
		// (set) Token: 0x06001B9E RID: 7070 RVA: 0x0006E8D4 File Offset: 0x0006CAD4
		public unsafe float field_Public_Single_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0)) = value;
			}
		}

		// Token: 0x17000992 RID: 2450
		// (get) Token: 0x06001B9F RID: 7071 RVA: 0x0006E8F8 File Offset: 0x0006CAF8
		// (set) Token: 0x06001BA0 RID: 7072 RVA: 0x0006E920 File Offset: 0x0006CB20
		public unsafe byte field_Public_Byte_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0)) = value;
			}
		}

		// Token: 0x17000993 RID: 2451
		// (get) Token: 0x06001BA1 RID: 7073 RVA: 0x0006E944 File Offset: 0x0006CB44
		// (set) Token: 0x06001BA2 RID: 7074 RVA: 0x0006E976 File Offset: 0x0006CB76
		public Nullable<Vector3> field_Public_Nullable_1_Vector3_0
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0);
				return new Nullable<Vector3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<Nullable<Vector3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<Nullable<Vector3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17000994 RID: 2452
		// (get) Token: 0x06001BA3 RID: 7075 RVA: 0x0006E9AC File Offset: 0x0006CBAC
		// (set) Token: 0x06001BA4 RID: 7076 RVA: 0x0006E9E0 File Offset: 0x0006CBE0
		public unsafe DPIPlayer field_Public_DPIPlayer_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DPIPlayer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000995 RID: 2453
		// (get) Token: 0x06001BA5 RID: 7077 RVA: 0x0006EA08 File Offset: 0x0006CC08
		// (set) Token: 0x06001BA6 RID: 7078 RVA: 0x0006EA30 File Offset: 0x0006CC30
		public unsafe int field_Public_Int32_1
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_1);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableInSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_1)) = value;
			}
		}

		// Token: 0x040011C7 RID: 4551
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Int32_0;

		// Token: 0x040011C8 RID: 4552
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Single_0;

		// Token: 0x040011C9 RID: 4553
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Byte_0;

		// Token: 0x040011CA RID: 4554
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0;

		// Token: 0x040011CB RID: 4555
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_DPIPlayer_0;

		// Token: 0x040011CC RID: 4556
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Int32_1;

		// Token: 0x040011CD RID: 4557
		private static readonly IntPtr NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0;

		// Token: 0x040011CE RID: 4558
		private static readonly IntPtr NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0;
	}

	// Token: 0x02000199 RID: 409
	[ObfuscatedName("DamageController/Δδδ_S_RPC_ApplyDamage")]
	[StructLayout(0)]
	public sealed class ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique : ValueType
	{
		// Token: 0x06001BA7 RID: 7079 RVA: 0x0006EA54 File Offset: 0x0006CC54
		[CallerCount(0)]
		public unsafe void Read(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001BA8 RID: 7080 RVA: 0x0006EAAC File Offset: 0x0006CCAC
		[CallerCount(0)]
		public unsafe void Write(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001BA9 RID: 7081 RVA: 0x0006EB04 File Offset: 0x0006CD04
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique()
		{
			Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageController>.NativeClassPtr, "Δδδ_S_RPC_ApplyDamage");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr);
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_amount");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_damageTypeByte");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_force");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_source");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, "Δδδ_I_aiSourceID");
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, 100665501);
			DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, 100665502);
		}

		// Token: 0x06001BAA RID: 7082 RVA: 0x0002717B File Offset: 0x0002537B
		public ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000996 RID: 2454
		// (get) Token: 0x06001BAB RID: 7083 RVA: 0x0006EBBB File Offset: 0x0006CDBB
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr));
			}
		}

		// Token: 0x06001BAC RID: 7084 RVA: 0x0006EBCC File Offset: 0x0006CDCC
		public unsafe ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique>.NativeClassPtr, data));
		}

		// Token: 0x17000997 RID: 2455
		// (get) Token: 0x06001BAD RID: 7085 RVA: 0x0006EBFC File Offset: 0x0006CDFC
		// (set) Token: 0x06001BAE RID: 7086 RVA: 0x0006EC24 File Offset: 0x0006CE24
		public unsafe float field_Public_Single_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Single_0)) = value;
			}
		}

		// Token: 0x17000998 RID: 2456
		// (get) Token: 0x06001BAF RID: 7087 RVA: 0x0006EC48 File Offset: 0x0006CE48
		// (set) Token: 0x06001BB0 RID: 7088 RVA: 0x0006EC70 File Offset: 0x0006CE70
		public unsafe byte field_Public_Byte_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Byte_0)) = value;
			}
		}

		// Token: 0x17000999 RID: 2457
		// (get) Token: 0x06001BB1 RID: 7089 RVA: 0x0006EC94 File Offset: 0x0006CE94
		// (set) Token: 0x06001BB2 RID: 7090 RVA: 0x0006ECC6 File Offset: 0x0006CEC6
		public Nullable<Vector3> field_Public_Nullable_1_Vector3_0
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0);
				return new Nullable<Vector3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<Nullable<Vector3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<Nullable<Vector3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x1700099A RID: 2458
		// (get) Token: 0x06001BB3 RID: 7091 RVA: 0x0006ECFC File Offset: 0x0006CEFC
		// (set) Token: 0x06001BB4 RID: 7092 RVA: 0x0006ED30 File Offset: 0x0006CF30
		public unsafe DPIPlayer field_Public_DPIPlayer_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DPIPlayer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_DPIPlayer_0), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700099B RID: 2459
		// (get) Token: 0x06001BB5 RID: 7093 RVA: 0x0006ED58 File Offset: 0x0006CF58
		// (set) Token: 0x06001BB6 RID: 7094 RVA: 0x0006ED80 File Offset: 0x0006CF80
		public unsafe int field_Public_Int32_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageController.ValueTypeNPrivateSealedINetworkStreamableSiByNu1VeDPInUnique.NativeFieldInfoPtr_field_Public_Int32_0)) = value;
			}
		}

		// Token: 0x040011CF RID: 4559
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Single_0;

		// Token: 0x040011D0 RID: 4560
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Byte_0;

		// Token: 0x040011D1 RID: 4561
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Nullable_1_Vector3_0;

		// Token: 0x040011D2 RID: 4562
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_DPIPlayer_0;

		// Token: 0x040011D3 RID: 4563
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Int32_0;

		// Token: 0x040011D4 RID: 4564
		private static readonly IntPtr NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0;

		// Token: 0x040011D5 RID: 4565
		private static readonly IntPtr NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0;
	}
}
