﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020001AE RID: 430
public class BleedBehavior : MonoBehaviour
{
	// Token: 0x06001D5A RID: 7514 RVA: 0x0007451C File Offset: 0x0007271C
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BleedBehavior.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D5B RID: 7515 RVA: 0x00074560 File Offset: 0x00072760
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BleedBehavior.NativeMethodInfoPtr_Update_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D5C RID: 7516 RVA: 0x000745A4 File Offset: 0x000727A4
	[CallerCount(0)]
	public unsafe void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(destination);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BleedBehavior.NativeMethodInfoPtr_OnRenderImage_Private_Void_RenderTexture_RenderTexture_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D5D RID: 7517 RVA: 0x00074618 File Offset: 0x00072818
	[CallerCount(0)]
	public unsafe BleedBehavior() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BleedBehavior.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001D5E RID: 7518 RVA: 0x00074664 File Offset: 0x00072864
	// Note: this type is marked as 'beforefieldinit'.
	static BleedBehavior()
	{
		Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BleedBehavior");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr);
		BleedBehavior.NativeFieldInfoPtr_BloodAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "BloodAmount");
		BleedBehavior.NativeFieldInfoPtr_TestingBloodAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "TestingBloodAmount");
		BleedBehavior.NativeFieldInfoPtr_minBloodAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "minBloodAmount");
		BleedBehavior.NativeFieldInfoPtr_EdgeSharpness = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "EdgeSharpness");
		BleedBehavior.NativeFieldInfoPtr_minAlpha = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "minAlpha");
		BleedBehavior.NativeFieldInfoPtr_maxAlpha = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "maxAlpha");
		BleedBehavior.NativeFieldInfoPtr_distortion = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "distortion");
		BleedBehavior.NativeFieldInfoPtr_autoFadeOut = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "autoFadeOut");
		BleedBehavior.NativeFieldInfoPtr_autoFadeOutAbsReduc = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "autoFadeOutAbsReduc");
		BleedBehavior.NativeFieldInfoPtr_autoFadeOutRelReduc = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "autoFadeOutRelReduc");
		BleedBehavior.NativeFieldInfoPtr_updateSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "updateSpeed");
		BleedBehavior.NativeFieldInfoPtr_prevBloodAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "prevBloodAmount");
		BleedBehavior.NativeFieldInfoPtr_Image = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "Image");
		BleedBehavior.NativeFieldInfoPtr_Normals = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "Normals");
		BleedBehavior.NativeFieldInfoPtr_Shader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "Shader");
		BleedBehavior.NativeFieldInfoPtr__material = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, "_material");
		BleedBehavior.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, 100665594);
		BleedBehavior.NativeMethodInfoPtr_Update_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, 100665595);
		BleedBehavior.NativeMethodInfoPtr_OnRenderImage_Private_Void_RenderTexture_RenderTexture_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, 100665596);
		BleedBehavior.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr, 100665597);
	}

	// Token: 0x06001D5F RID: 7519 RVA: 0x0000210C File Offset: 0x0000030C
	public BleedBehavior(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000A3E RID: 2622
	// (get) Token: 0x06001D60 RID: 7520 RVA: 0x00074824 File Offset: 0x00072A24
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BleedBehavior>.NativeClassPtr));
		}
	}

	// Token: 0x17000A3F RID: 2623
	// (get) Token: 0x06001D61 RID: 7521 RVA: 0x00074838 File Offset: 0x00072A38
	// (set) Token: 0x06001D62 RID: 7522 RVA: 0x00074856 File Offset: 0x00072A56
	public unsafe static float BloodAmount
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(BleedBehavior.NativeFieldInfoPtr_BloodAmount, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BleedBehavior.NativeFieldInfoPtr_BloodAmount, (void*)(&value));
		}
	}

	// Token: 0x17000A40 RID: 2624
	// (get) Token: 0x06001D63 RID: 7523 RVA: 0x00074868 File Offset: 0x00072A68
	// (set) Token: 0x06001D64 RID: 7524 RVA: 0x00074890 File Offset: 0x00072A90
	public unsafe float TestingBloodAmount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_TestingBloodAmount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_TestingBloodAmount)) = value;
		}
	}

	// Token: 0x17000A41 RID: 2625
	// (get) Token: 0x06001D65 RID: 7525 RVA: 0x000748B4 File Offset: 0x00072AB4
	// (set) Token: 0x06001D66 RID: 7526 RVA: 0x000748D2 File Offset: 0x00072AD2
	public unsafe static float minBloodAmount
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(BleedBehavior.NativeFieldInfoPtr_minBloodAmount, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BleedBehavior.NativeFieldInfoPtr_minBloodAmount, (void*)(&value));
		}
	}

	// Token: 0x17000A42 RID: 2626
	// (get) Token: 0x06001D67 RID: 7527 RVA: 0x000748E4 File Offset: 0x00072AE4
	// (set) Token: 0x06001D68 RID: 7528 RVA: 0x0007490C File Offset: 0x00072B0C
	public unsafe float EdgeSharpness
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_EdgeSharpness);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_EdgeSharpness)) = value;
		}
	}

	// Token: 0x17000A43 RID: 2627
	// (get) Token: 0x06001D69 RID: 7529 RVA: 0x00074930 File Offset: 0x00072B30
	// (set) Token: 0x06001D6A RID: 7530 RVA: 0x00074958 File Offset: 0x00072B58
	public unsafe float minAlpha
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_minAlpha);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_minAlpha)) = value;
		}
	}

	// Token: 0x17000A44 RID: 2628
	// (get) Token: 0x06001D6B RID: 7531 RVA: 0x0007497C File Offset: 0x00072B7C
	// (set) Token: 0x06001D6C RID: 7532 RVA: 0x000749A4 File Offset: 0x00072BA4
	public unsafe float maxAlpha
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_maxAlpha);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_maxAlpha)) = value;
		}
	}

	// Token: 0x17000A45 RID: 2629
	// (get) Token: 0x06001D6D RID: 7533 RVA: 0x000749C8 File Offset: 0x00072BC8
	// (set) Token: 0x06001D6E RID: 7534 RVA: 0x000749F0 File Offset: 0x00072BF0
	public unsafe float distortion
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_distortion);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_distortion)) = value;
		}
	}

	// Token: 0x17000A46 RID: 2630
	// (get) Token: 0x06001D6F RID: 7535 RVA: 0x00074A14 File Offset: 0x00072C14
	// (set) Token: 0x06001D70 RID: 7536 RVA: 0x00074A3C File Offset: 0x00072C3C
	public unsafe bool autoFadeOut
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOut);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOut)) = value;
		}
	}

	// Token: 0x17000A47 RID: 2631
	// (get) Token: 0x06001D71 RID: 7537 RVA: 0x00074A60 File Offset: 0x00072C60
	// (set) Token: 0x06001D72 RID: 7538 RVA: 0x00074A88 File Offset: 0x00072C88
	public unsafe float autoFadeOutAbsReduc
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOutAbsReduc);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOutAbsReduc)) = value;
		}
	}

	// Token: 0x17000A48 RID: 2632
	// (get) Token: 0x06001D73 RID: 7539 RVA: 0x00074AAC File Offset: 0x00072CAC
	// (set) Token: 0x06001D74 RID: 7540 RVA: 0x00074AD4 File Offset: 0x00072CD4
	public unsafe float autoFadeOutRelReduc
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOutRelReduc);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_autoFadeOutRelReduc)) = value;
		}
	}

	// Token: 0x17000A49 RID: 2633
	// (get) Token: 0x06001D75 RID: 7541 RVA: 0x00074AF8 File Offset: 0x00072CF8
	// (set) Token: 0x06001D76 RID: 7542 RVA: 0x00074B20 File Offset: 0x00072D20
	public unsafe float updateSpeed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_updateSpeed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_updateSpeed)) = value;
		}
	}

	// Token: 0x17000A4A RID: 2634
	// (get) Token: 0x06001D77 RID: 7543 RVA: 0x00074B44 File Offset: 0x00072D44
	// (set) Token: 0x06001D78 RID: 7544 RVA: 0x00074B6C File Offset: 0x00072D6C
	public unsafe float prevBloodAmount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_prevBloodAmount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_prevBloodAmount)) = value;
		}
	}

	// Token: 0x17000A4B RID: 2635
	// (get) Token: 0x06001D79 RID: 7545 RVA: 0x00074B90 File Offset: 0x00072D90
	// (set) Token: 0x06001D7A RID: 7546 RVA: 0x00074BC4 File Offset: 0x00072DC4
	public unsafe Texture2D Image
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Image);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Texture2D(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Image), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000A4C RID: 2636
	// (get) Token: 0x06001D7B RID: 7547 RVA: 0x00074BEC File Offset: 0x00072DEC
	// (set) Token: 0x06001D7C RID: 7548 RVA: 0x00074C20 File Offset: 0x00072E20
	public unsafe Texture2D Normals
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Normals);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Texture2D(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Normals), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000A4D RID: 2637
	// (get) Token: 0x06001D7D RID: 7549 RVA: 0x00074C48 File Offset: 0x00072E48
	// (set) Token: 0x06001D7E RID: 7550 RVA: 0x00074C7C File Offset: 0x00072E7C
	public unsafe Shader Shader
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Shader);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Shader(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr_Shader), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000A4E RID: 2638
	// (get) Token: 0x06001D7F RID: 7551 RVA: 0x00074CA4 File Offset: 0x00072EA4
	// (set) Token: 0x06001D80 RID: 7552 RVA: 0x00074CD8 File Offset: 0x00072ED8
	public unsafe Material _material
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr__material);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Material(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BleedBehavior.NativeFieldInfoPtr__material), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040012BC RID: 4796
	private static readonly IntPtr NativeFieldInfoPtr_BloodAmount;

	// Token: 0x040012BD RID: 4797
	private static readonly IntPtr NativeFieldInfoPtr_TestingBloodAmount;

	// Token: 0x040012BE RID: 4798
	private static readonly IntPtr NativeFieldInfoPtr_minBloodAmount;

	// Token: 0x040012BF RID: 4799
	private static readonly IntPtr NativeFieldInfoPtr_EdgeSharpness;

	// Token: 0x040012C0 RID: 4800
	private static readonly IntPtr NativeFieldInfoPtr_minAlpha;

	// Token: 0x040012C1 RID: 4801
	private static readonly IntPtr NativeFieldInfoPtr_maxAlpha;

	// Token: 0x040012C2 RID: 4802
	private static readonly IntPtr NativeFieldInfoPtr_distortion;

	// Token: 0x040012C3 RID: 4803
	private static readonly IntPtr NativeFieldInfoPtr_autoFadeOut;

	// Token: 0x040012C4 RID: 4804
	private static readonly IntPtr NativeFieldInfoPtr_autoFadeOutAbsReduc;

	// Token: 0x040012C5 RID: 4805
	private static readonly IntPtr NativeFieldInfoPtr_autoFadeOutRelReduc;

	// Token: 0x040012C6 RID: 4806
	private static readonly IntPtr NativeFieldInfoPtr_updateSpeed;

	// Token: 0x040012C7 RID: 4807
	private static readonly IntPtr NativeFieldInfoPtr_prevBloodAmount;

	// Token: 0x040012C8 RID: 4808
	private static readonly IntPtr NativeFieldInfoPtr_Image;

	// Token: 0x040012C9 RID: 4809
	private static readonly IntPtr NativeFieldInfoPtr_Normals;

	// Token: 0x040012CA RID: 4810
	private static readonly IntPtr NativeFieldInfoPtr_Shader;

	// Token: 0x040012CB RID: 4811
	private static readonly IntPtr NativeFieldInfoPtr__material;

	// Token: 0x040012CC RID: 4812
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x040012CD RID: 4813
	private static readonly IntPtr NativeMethodInfoPtr_Update_Public_Void_0;

	// Token: 0x040012CE RID: 4814
	private static readonly IntPtr NativeMethodInfoPtr_OnRenderImage_Private_Void_RenderTexture_RenderTexture_0;

	// Token: 0x040012CF RID: 4815
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
