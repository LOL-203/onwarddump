﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200006E RID: 110
public class BrushController : MonoBehaviour
{
	// Token: 0x06000679 RID: 1657 RVA: 0x0001C24C File Offset: 0x0001A44C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600067A RID: 1658 RVA: 0x0001C290 File Offset: 0x0001A490
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600067B RID: 1659 RVA: 0x0001C2D4 File Offset: 0x0001A4D4
	[CallerCount(0)]
	public unsafe void Grab(OVRInput.Controller grabHand)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref grabHand;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_Grab_Public_Void_Controller_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600067C RID: 1660 RVA: 0x0001C328 File Offset: 0x0001A528
	[CallerCount(0)]
	public unsafe void Release()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_Release_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600067D RID: 1661 RVA: 0x0001C36C File Offset: 0x0001A56C
	[CallerCount(0)]
	public unsafe IEnumerator FadeCameraClearColor(Color newColor, float fadeTime)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref newColor;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref fadeTime;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_FadeCameraClearColor_Private_IEnumerator_Color_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x0001C3E8 File Offset: 0x0001A5E8
	[CallerCount(0)]
	public unsafe IEnumerator FadeSphere(Color newColor, float fadeTime, bool disableOnFinish = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref newColor;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref fadeTime;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref disableOnFinish;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr_FadeSphere_Private_IEnumerator_Color_Single_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x0001C478 File Offset: 0x0001A678
	[CallerCount(0)]
	public unsafe BrushController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BrushController>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000680 RID: 1664 RVA: 0x0001C4C4 File Offset: 0x0001A6C4
	// Note: this type is marked as 'beforefieldinit'.
	static BrushController()
	{
		Il2CppClassPointerStore<BrushController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BrushController");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BrushController>.NativeClassPtr);
		BrushController.NativeFieldInfoPtr_brush = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "brush");
		BrushController.NativeFieldInfoPtr_backgroundSphere = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "backgroundSphere");
		BrushController.NativeFieldInfoPtr_grabRoutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "grabRoutine");
		BrushController.NativeFieldInfoPtr_releaseRoutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "releaseRoutine");
		BrushController.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663850);
		BrushController.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663851);
		BrushController.NativeMethodInfoPtr_Grab_Public_Void_Controller_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663852);
		BrushController.NativeMethodInfoPtr_Release_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663853);
		BrushController.NativeMethodInfoPtr_FadeCameraClearColor_Private_IEnumerator_Color_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663854);
		BrushController.NativeMethodInfoPtr_FadeSphere_Private_IEnumerator_Color_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663855);
		BrushController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController>.NativeClassPtr, 100663856);
	}

	// Token: 0x06000681 RID: 1665 RVA: 0x0000210C File Offset: 0x0000030C
	public BrushController(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700022D RID: 557
	// (get) Token: 0x06000682 RID: 1666 RVA: 0x0001C5D0 File Offset: 0x0001A7D0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BrushController>.NativeClassPtr));
		}
	}

	// Token: 0x1700022E RID: 558
	// (get) Token: 0x06000683 RID: 1667 RVA: 0x0001C5E4 File Offset: 0x0001A7E4
	// (set) Token: 0x06000684 RID: 1668 RVA: 0x0001C618 File Offset: 0x0001A818
	public unsafe PassthroughBrush brush
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_brush);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new PassthroughBrush(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_brush), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700022F RID: 559
	// (get) Token: 0x06000685 RID: 1669 RVA: 0x0001C640 File Offset: 0x0001A840
	// (set) Token: 0x06000686 RID: 1670 RVA: 0x0001C674 File Offset: 0x0001A874
	public unsafe MeshRenderer backgroundSphere
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_backgroundSphere);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_backgroundSphere), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000230 RID: 560
	// (get) Token: 0x06000687 RID: 1671 RVA: 0x0001C69C File Offset: 0x0001A89C
	// (set) Token: 0x06000688 RID: 1672 RVA: 0x0001C6D0 File Offset: 0x0001A8D0
	public unsafe IEnumerator grabRoutine
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_grabRoutine);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_grabRoutine), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000231 RID: 561
	// (get) Token: 0x06000689 RID: 1673 RVA: 0x0001C6F8 File Offset: 0x0001A8F8
	// (set) Token: 0x0600068A RID: 1674 RVA: 0x0001C72C File Offset: 0x0001A92C
	public unsafe IEnumerator releaseRoutine
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_releaseRoutine);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController.NativeFieldInfoPtr_releaseRoutine), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000414 RID: 1044
	private static readonly IntPtr NativeFieldInfoPtr_brush;

	// Token: 0x04000415 RID: 1045
	private static readonly IntPtr NativeFieldInfoPtr_backgroundSphere;

	// Token: 0x04000416 RID: 1046
	private static readonly IntPtr NativeFieldInfoPtr_grabRoutine;

	// Token: 0x04000417 RID: 1047
	private static readonly IntPtr NativeFieldInfoPtr_releaseRoutine;

	// Token: 0x04000418 RID: 1048
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000419 RID: 1049
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x0400041A RID: 1050
	private static readonly IntPtr NativeMethodInfoPtr_Grab_Public_Void_Controller_0;

	// Token: 0x0400041B RID: 1051
	private static readonly IntPtr NativeMethodInfoPtr_Release_Public_Void_0;

	// Token: 0x0400041C RID: 1052
	private static readonly IntPtr NativeMethodInfoPtr_FadeCameraClearColor_Private_IEnumerator_Color_Single_0;

	// Token: 0x0400041D RID: 1053
	private static readonly IntPtr NativeMethodInfoPtr_FadeSphere_Private_IEnumerator_Color_Single_Boolean_0;

	// Token: 0x0400041E RID: 1054
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200006F RID: 111
	[ObfuscatedName("BrushController/<FadeCameraClearColor>d__8")]
	public sealed class _FadeCameraClearColor_d__8 : Il2CppSystem.Object
	{
		// Token: 0x0600068B RID: 1675 RVA: 0x0001C754 File Offset: 0x0001A954
		[CallerCount(0)]
		public unsafe _FadeCameraClearColor_d__8(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x0001C7B4 File Offset: 0x0001A9B4
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x0001C7F8 File Offset: 0x0001A9F8
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x0600068E RID: 1678 RVA: 0x0001C848 File Offset: 0x0001AA48
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x0001C8A0 File Offset: 0x0001AAA0
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000690 RID: 1680 RVA: 0x0001C8E4 File Offset: 0x0001AAE4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x0001C93C File Offset: 0x0001AB3C
		// Note: this type is marked as 'beforefieldinit'.
		static _FadeCameraClearColor_d__8()
		{
			Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "<FadeCameraClearColor>d__8");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr);
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "<>1__state");
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "<>2__current");
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_fadeTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "fadeTime");
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_newColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "newColor");
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__timer_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "<timer>5__2");
			BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__currentColor_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, "<currentColor>5__3");
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663857);
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663858);
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663859);
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663860);
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663861);
			BrushController._FadeCameraClearColor_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr, 100663862);
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00002988 File Offset: 0x00000B88
		public _FadeCameraClearColor_d__8(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000693 RID: 1683 RVA: 0x0001CA57 File Offset: 0x0001AC57
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BrushController._FadeCameraClearColor_d__8>.NativeClassPtr));
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000694 RID: 1684 RVA: 0x0001CA68 File Offset: 0x0001AC68
		// (set) Token: 0x06000695 RID: 1685 RVA: 0x0001CA90 File Offset: 0x0001AC90
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x06000696 RID: 1686 RVA: 0x0001CAB4 File Offset: 0x0001ACB4
		// (set) Token: 0x06000697 RID: 1687 RVA: 0x0001CAE8 File Offset: 0x0001ACE8
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x06000698 RID: 1688 RVA: 0x0001CB10 File Offset: 0x0001AD10
		// (set) Token: 0x06000699 RID: 1689 RVA: 0x0001CB38 File Offset: 0x0001AD38
		public unsafe float fadeTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_fadeTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_fadeTime)) = value;
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x0600069A RID: 1690 RVA: 0x0001CB5C File Offset: 0x0001AD5C
		// (set) Token: 0x0600069B RID: 1691 RVA: 0x0001CB84 File Offset: 0x0001AD84
		public unsafe Color newColor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_newColor);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr_newColor)) = value;
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x0600069C RID: 1692 RVA: 0x0001CBA8 File Offset: 0x0001ADA8
		// (set) Token: 0x0600069D RID: 1693 RVA: 0x0001CBD0 File Offset: 0x0001ADD0
		public unsafe float _timer_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__timer_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__timer_5__2)) = value;
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x0600069E RID: 1694 RVA: 0x0001CBF4 File Offset: 0x0001ADF4
		// (set) Token: 0x0600069F RID: 1695 RVA: 0x0001CC1C File Offset: 0x0001AE1C
		public unsafe Color _currentColor_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__currentColor_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeCameraClearColor_d__8.NativeFieldInfoPtr__currentColor_5__3)) = value;
			}
		}

		// Token: 0x0400041F RID: 1055
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04000420 RID: 1056
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04000421 RID: 1057
		private static readonly IntPtr NativeFieldInfoPtr_fadeTime;

		// Token: 0x04000422 RID: 1058
		private static readonly IntPtr NativeFieldInfoPtr_newColor;

		// Token: 0x04000423 RID: 1059
		private static readonly IntPtr NativeFieldInfoPtr__timer_5__2;

		// Token: 0x04000424 RID: 1060
		private static readonly IntPtr NativeFieldInfoPtr__currentColor_5__3;

		// Token: 0x04000425 RID: 1061
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000426 RID: 1062
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000427 RID: 1063
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04000428 RID: 1064
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04000429 RID: 1065
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400042A RID: 1066
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x02000070 RID: 112
	[ObfuscatedName("BrushController/<FadeSphere>d__9")]
	public sealed class _FadeSphere_d__9 : Il2CppSystem.Object
	{
		// Token: 0x060006A0 RID: 1696 RVA: 0x0001CC40 File Offset: 0x0001AE40
		[CallerCount(0)]
		public unsafe _FadeSphere_d__9(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x0001CCA0 File Offset: 0x0001AEA0
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x0001CCE4 File Offset: 0x0001AEE4
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x060006A3 RID: 1699 RVA: 0x0001CD34 File Offset: 0x0001AF34
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060006A4 RID: 1700 RVA: 0x0001CD8C File Offset: 0x0001AF8C
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x060006A5 RID: 1701 RVA: 0x0001CDD0 File Offset: 0x0001AFD0
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060006A6 RID: 1702 RVA: 0x0001CE28 File Offset: 0x0001B028
		// Note: this type is marked as 'beforefieldinit'.
		static _FadeSphere_d__9()
		{
			Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BrushController>.NativeClassPtr, "<FadeSphere>d__9");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr);
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "<>1__state");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "<>2__current");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "<>4__this");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr_fadeTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "fadeTime");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr_newColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "newColor");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr_disableOnFinish = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "disableOnFinish");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr__timer_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "<timer>5__2");
			BrushController._FadeSphere_d__9.NativeFieldInfoPtr__currentColor_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, "<currentColor>5__3");
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663863);
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663864);
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663865);
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663866);
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663867);
			BrushController._FadeSphere_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr, 100663868);
		}

		// Token: 0x060006A7 RID: 1703 RVA: 0x00002988 File Offset: 0x00000B88
		public _FadeSphere_d__9(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x0001CF6B File Offset: 0x0001B16B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BrushController._FadeSphere_d__9>.NativeClassPtr));
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x060006A9 RID: 1705 RVA: 0x0001CF7C File Offset: 0x0001B17C
		// (set) Token: 0x060006AA RID: 1706 RVA: 0x0001CFA4 File Offset: 0x0001B1A4
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x060006AB RID: 1707 RVA: 0x0001CFC8 File Offset: 0x0001B1C8
		// (set) Token: 0x060006AC RID: 1708 RVA: 0x0001CFFC File Offset: 0x0001B1FC
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x060006AD RID: 1709 RVA: 0x0001D024 File Offset: 0x0001B224
		// (set) Token: 0x060006AE RID: 1710 RVA: 0x0001D058 File Offset: 0x0001B258
		public unsafe BrushController __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BrushController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x0001D080 File Offset: 0x0001B280
		// (set) Token: 0x060006B0 RID: 1712 RVA: 0x0001D0A8 File Offset: 0x0001B2A8
		public unsafe float fadeTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_fadeTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_fadeTime)) = value;
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x060006B1 RID: 1713 RVA: 0x0001D0CC File Offset: 0x0001B2CC
		// (set) Token: 0x060006B2 RID: 1714 RVA: 0x0001D0F4 File Offset: 0x0001B2F4
		public unsafe Color newColor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_newColor);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_newColor)) = value;
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x060006B3 RID: 1715 RVA: 0x0001D118 File Offset: 0x0001B318
		// (set) Token: 0x060006B4 RID: 1716 RVA: 0x0001D140 File Offset: 0x0001B340
		public unsafe bool disableOnFinish
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_disableOnFinish);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr_disableOnFinish)) = value;
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x060006B5 RID: 1717 RVA: 0x0001D164 File Offset: 0x0001B364
		// (set) Token: 0x060006B6 RID: 1718 RVA: 0x0001D18C File Offset: 0x0001B38C
		public unsafe float _timer_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr__timer_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr__timer_5__2)) = value;
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x060006B7 RID: 1719 RVA: 0x0001D1B0 File Offset: 0x0001B3B0
		// (set) Token: 0x060006B8 RID: 1720 RVA: 0x0001D1D8 File Offset: 0x0001B3D8
		public unsafe Color _currentColor_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr__currentColor_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BrushController._FadeSphere_d__9.NativeFieldInfoPtr__currentColor_5__3)) = value;
			}
		}

		// Token: 0x0400042B RID: 1067
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x0400042C RID: 1068
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x0400042D RID: 1069
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x0400042E RID: 1070
		private static readonly IntPtr NativeFieldInfoPtr_fadeTime;

		// Token: 0x0400042F RID: 1071
		private static readonly IntPtr NativeFieldInfoPtr_newColor;

		// Token: 0x04000430 RID: 1072
		private static readonly IntPtr NativeFieldInfoPtr_disableOnFinish;

		// Token: 0x04000431 RID: 1073
		private static readonly IntPtr NativeFieldInfoPtr__timer_5__2;

		// Token: 0x04000432 RID: 1074
		private static readonly IntPtr NativeFieldInfoPtr__currentColor_5__3;

		// Token: 0x04000433 RID: 1075
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000434 RID: 1076
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000435 RID: 1077
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04000436 RID: 1078
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04000437 RID: 1079
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000438 RID: 1080
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
