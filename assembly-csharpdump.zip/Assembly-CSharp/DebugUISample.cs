﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200005B RID: 91
public class DebugUISample : MonoBehaviour
{
	// Token: 0x060005B0 RID: 1456 RVA: 0x00019038 File Offset: 0x00017238
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x0001907C File Offset: 0x0001727C
	[CallerCount(0)]
	public unsafe void TogglePressed(Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_TogglePressed_Public_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x000190D8 File Offset: 0x000172D8
	[CallerCount(0)]
	public unsafe void RadioPressed(string radioLabel, string group, Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(radioLabel);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(group);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_RadioPressed_Public_Void_String_String_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x00019164 File Offset: 0x00017364
	[CallerCount(0)]
	public unsafe void SliderPressed(float f)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref f;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_SliderPressed_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x000191B8 File Offset: 0x000173B8
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x000191FC File Offset: 0x000173FC
	[CallerCount(0)]
	public unsafe void LogButtonPressed()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr_LogButtonPressed_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00019240 File Offset: 0x00017440
	[CallerCount(0)]
	public unsafe DebugUISample() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x0001928C File Offset: 0x0001748C
	[CallerCount(0)]
	public unsafe void _Start_b__2_0(Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr__Start_b__2_0_Private_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x000192E8 File Offset: 0x000174E8
	[CallerCount(0)]
	public unsafe void _Start_b__2_1(Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr__Start_b__2_1_Private_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00019344 File Offset: 0x00017544
	[CallerCount(0)]
	public unsafe void _Start_b__2_2(Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr__Start_b__2_2_Private_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x000193A0 File Offset: 0x000175A0
	[CallerCount(0)]
	public unsafe void _Start_b__2_3(Toggle t)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUISample.NativeMethodInfoPtr__Start_b__2_3_Private_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x000193FC File Offset: 0x000175FC
	// Note: this type is marked as 'beforefieldinit'.
	static DebugUISample()
	{
		Il2CppClassPointerStore<DebugUISample>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DebugUISample");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr);
		DebugUISample.NativeFieldInfoPtr_inMenu = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, "inMenu");
		DebugUISample.NativeFieldInfoPtr_sliderText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, "sliderText");
		DebugUISample.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663784);
		DebugUISample.NativeMethodInfoPtr_TogglePressed_Public_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663785);
		DebugUISample.NativeMethodInfoPtr_RadioPressed_Public_Void_String_String_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663786);
		DebugUISample.NativeMethodInfoPtr_SliderPressed_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663787);
		DebugUISample.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663788);
		DebugUISample.NativeMethodInfoPtr_LogButtonPressed_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663789);
		DebugUISample.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663790);
		DebugUISample.NativeMethodInfoPtr__Start_b__2_0_Private_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663791);
		DebugUISample.NativeMethodInfoPtr__Start_b__2_1_Private_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663792);
		DebugUISample.NativeMethodInfoPtr__Start_b__2_2_Private_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663793);
		DebugUISample.NativeMethodInfoPtr__Start_b__2_3_Private_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr, 100663794);
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x0000210C File Offset: 0x0000030C
	public DebugUISample(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170001EE RID: 494
	// (get) Token: 0x060005BD RID: 1469 RVA: 0x00019530 File Offset: 0x00017730
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUISample>.NativeClassPtr));
		}
	}

	// Token: 0x170001EF RID: 495
	// (get) Token: 0x060005BE RID: 1470 RVA: 0x00019544 File Offset: 0x00017744
	// (set) Token: 0x060005BF RID: 1471 RVA: 0x0001956C File Offset: 0x0001776C
	public unsafe bool inMenu
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUISample.NativeFieldInfoPtr_inMenu);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUISample.NativeFieldInfoPtr_inMenu)) = value;
		}
	}

	// Token: 0x170001F0 RID: 496
	// (get) Token: 0x060005C0 RID: 1472 RVA: 0x00019590 File Offset: 0x00017790
	// (set) Token: 0x060005C1 RID: 1473 RVA: 0x000195C4 File Offset: 0x000177C4
	public unsafe Text sliderText
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUISample.NativeFieldInfoPtr_sliderText);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Text(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUISample.NativeFieldInfoPtr_sliderText), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000396 RID: 918
	private static readonly IntPtr NativeFieldInfoPtr_inMenu;

	// Token: 0x04000397 RID: 919
	private static readonly IntPtr NativeFieldInfoPtr_sliderText;

	// Token: 0x04000398 RID: 920
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000399 RID: 921
	private static readonly IntPtr NativeMethodInfoPtr_TogglePressed_Public_Void_Toggle_0;

	// Token: 0x0400039A RID: 922
	private static readonly IntPtr NativeMethodInfoPtr_RadioPressed_Public_Void_String_String_Toggle_0;

	// Token: 0x0400039B RID: 923
	private static readonly IntPtr NativeMethodInfoPtr_SliderPressed_Public_Void_Single_0;

	// Token: 0x0400039C RID: 924
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x0400039D RID: 925
	private static readonly IntPtr NativeMethodInfoPtr_LogButtonPressed_Private_Void_0;

	// Token: 0x0400039E RID: 926
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0400039F RID: 927
	private static readonly IntPtr NativeMethodInfoPtr__Start_b__2_0_Private_Void_Toggle_0;

	// Token: 0x040003A0 RID: 928
	private static readonly IntPtr NativeMethodInfoPtr__Start_b__2_1_Private_Void_Toggle_0;

	// Token: 0x040003A1 RID: 929
	private static readonly IntPtr NativeMethodInfoPtr__Start_b__2_2_Private_Void_Toggle_0;

	// Token: 0x040003A2 RID: 930
	private static readonly IntPtr NativeMethodInfoPtr__Start_b__2_3_Private_Void_Toggle_0;
}
