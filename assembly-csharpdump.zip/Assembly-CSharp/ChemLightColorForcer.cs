﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.AddressableTools;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200027B RID: 635
public class ChemLightColorForcer : Il2CppSystem.Object
{
	// Token: 0x06002E85 RID: 11909 RVA: 0x000B7040 File Offset: 0x000B5240
	[CallerCount(0)]
	public unsafe ChemLightColorForcer(MonoBehaviour host, Renderer renderer, VisualLoader loader, int forceFrames) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(host);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(renderer);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(loader);
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref forceFrames;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer.NativeMethodInfoPtr__ctor_Public_Void_MonoBehaviour_Renderer_VisualLoader_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002E86 RID: 11910 RVA: 0x000B70E8 File Offset: 0x000B52E8
	[CallerCount(0)]
	public unsafe void StopForceRoutine()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer.NativeMethodInfoPtr_StopForceRoutine_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002E87 RID: 11911 RVA: 0x000B712C File Offset: 0x000B532C
	[CallerCount(0)]
	public unsafe void StartForceRoutine()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer.NativeMethodInfoPtr_StartForceRoutine_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002E88 RID: 11912 RVA: 0x000B7170 File Offset: 0x000B5370
	[CallerCount(0)]
	public unsafe IEnumerator ForceRoutine()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer.NativeMethodInfoPtr_ForceRoutine_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06002E89 RID: 11913 RVA: 0x000B71C8 File Offset: 0x000B53C8
	// Note: this type is marked as 'beforefieldinit'.
	static ChemLightColorForcer()
	{
		Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ChemLightColorForcer");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr);
		ChemLightColorForcer.NativeFieldInfoPtr_OnForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "OnForce");
		ChemLightColorForcer.NativeFieldInfoPtr__host = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "_host");
		ChemLightColorForcer.NativeFieldInfoPtr__renderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "_renderer");
		ChemLightColorForcer.NativeFieldInfoPtr__loader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "_loader");
		ChemLightColorForcer.NativeFieldInfoPtr__forceFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "_forceFrames");
		ChemLightColorForcer.NativeFieldInfoPtr__forceCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "_forceCoroutine");
		ChemLightColorForcer.NativeMethodInfoPtr__ctor_Public_Void_MonoBehaviour_Renderer_VisualLoader_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, 100666797);
		ChemLightColorForcer.NativeMethodInfoPtr_StopForceRoutine_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, 100666798);
		ChemLightColorForcer.NativeMethodInfoPtr_StartForceRoutine_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, 100666799);
		ChemLightColorForcer.NativeMethodInfoPtr_ForceRoutine_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, 100666800);
	}

	// Token: 0x06002E8A RID: 11914 RVA: 0x00002988 File Offset: 0x00000B88
	public ChemLightColorForcer(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170010A7 RID: 4263
	// (get) Token: 0x06002E8B RID: 11915 RVA: 0x000B72C0 File Offset: 0x000B54C0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr));
		}
	}

	// Token: 0x170010A8 RID: 4264
	// (get) Token: 0x06002E8C RID: 11916 RVA: 0x000B72D4 File Offset: 0x000B54D4
	// (set) Token: 0x06002E8D RID: 11917 RVA: 0x000B7308 File Offset: 0x000B5508
	public unsafe Action OnForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr_OnForce);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Action(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr_OnForce), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010A9 RID: 4265
	// (get) Token: 0x06002E8E RID: 11918 RVA: 0x000B7330 File Offset: 0x000B5530
	// (set) Token: 0x06002E8F RID: 11919 RVA: 0x000B7364 File Offset: 0x000B5564
	public unsafe MonoBehaviour _host
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__host);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MonoBehaviour(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__host), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010AA RID: 4266
	// (get) Token: 0x06002E90 RID: 11920 RVA: 0x000B738C File Offset: 0x000B558C
	// (set) Token: 0x06002E91 RID: 11921 RVA: 0x000B73C0 File Offset: 0x000B55C0
	public unsafe Renderer _renderer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__renderer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Renderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__renderer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010AB RID: 4267
	// (get) Token: 0x06002E92 RID: 11922 RVA: 0x000B73E8 File Offset: 0x000B55E8
	// (set) Token: 0x06002E93 RID: 11923 RVA: 0x000B741C File Offset: 0x000B561C
	public unsafe VisualLoader _loader
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__loader);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new VisualLoader(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__loader), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010AC RID: 4268
	// (get) Token: 0x06002E94 RID: 11924 RVA: 0x000B7444 File Offset: 0x000B5644
	// (set) Token: 0x06002E95 RID: 11925 RVA: 0x000B746C File Offset: 0x000B566C
	public unsafe int _forceFrames
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__forceFrames);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__forceFrames)) = value;
		}
	}

	// Token: 0x170010AD RID: 4269
	// (get) Token: 0x06002E96 RID: 11926 RVA: 0x000B7490 File Offset: 0x000B5690
	// (set) Token: 0x06002E97 RID: 11927 RVA: 0x000B74C4 File Offset: 0x000B56C4
	public unsafe Coroutine _forceCoroutine
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__forceCoroutine);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer.NativeFieldInfoPtr__forceCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04001D63 RID: 7523
	private static readonly IntPtr NativeFieldInfoPtr_OnForce;

	// Token: 0x04001D64 RID: 7524
	private static readonly IntPtr NativeFieldInfoPtr__host;

	// Token: 0x04001D65 RID: 7525
	private static readonly IntPtr NativeFieldInfoPtr__renderer;

	// Token: 0x04001D66 RID: 7526
	private static readonly IntPtr NativeFieldInfoPtr__loader;

	// Token: 0x04001D67 RID: 7527
	private static readonly IntPtr NativeFieldInfoPtr__forceFrames;

	// Token: 0x04001D68 RID: 7528
	private static readonly IntPtr NativeFieldInfoPtr__forceCoroutine;

	// Token: 0x04001D69 RID: 7529
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_MonoBehaviour_Renderer_VisualLoader_Int32_0;

	// Token: 0x04001D6A RID: 7530
	private static readonly IntPtr NativeMethodInfoPtr_StopForceRoutine_Public_Void_0;

	// Token: 0x04001D6B RID: 7531
	private static readonly IntPtr NativeMethodInfoPtr_StartForceRoutine_Public_Void_0;

	// Token: 0x04001D6C RID: 7532
	private static readonly IntPtr NativeMethodInfoPtr_ForceRoutine_Private_IEnumerator_0;

	// Token: 0x0200027C RID: 636
	[ObfuscatedName("ChemLightColorForcer/<ForceRoutine>d__9")]
	public sealed class _ForceRoutine_d__9 : Il2CppSystem.Object
	{
		// Token: 0x06002E98 RID: 11928 RVA: 0x000B74EC File Offset: 0x000B56EC
		[CallerCount(0)]
		public unsafe _ForceRoutine_d__9(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06002E99 RID: 11929 RVA: 0x000B754C File Offset: 0x000B574C
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06002E9A RID: 11930 RVA: 0x000B7590 File Offset: 0x000B5790
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x170010B3 RID: 4275
		// (get) Token: 0x06002E9B RID: 11931 RVA: 0x000B75E0 File Offset: 0x000B57E0
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06002E9C RID: 11932 RVA: 0x000B7638 File Offset: 0x000B5838
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170010B4 RID: 4276
		// (get) Token: 0x06002E9D RID: 11933 RVA: 0x000B767C File Offset: 0x000B587C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06002E9E RID: 11934 RVA: 0x000B76D4 File Offset: 0x000B58D4
		// Note: this type is marked as 'beforefieldinit'.
		static _ForceRoutine_d__9()
		{
			Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ChemLightColorForcer>.NativeClassPtr, "<ForceRoutine>d__9");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr);
			ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, "<>1__state");
			ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, "<>2__current");
			ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, "<>4__this");
			ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr__frameCounter_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, "<frameCounter>5__2");
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666801);
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666802);
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666803);
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666804);
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666805);
			ChemLightColorForcer._ForceRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr, 100666806);
		}

		// Token: 0x06002E9F RID: 11935 RVA: 0x00002988 File Offset: 0x00000B88
		public _ForceRoutine_d__9(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170010AE RID: 4270
		// (get) Token: 0x06002EA0 RID: 11936 RVA: 0x000B77C7 File Offset: 0x000B59C7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ChemLightColorForcer._ForceRoutine_d__9>.NativeClassPtr));
			}
		}

		// Token: 0x170010AF RID: 4271
		// (get) Token: 0x06002EA1 RID: 11937 RVA: 0x000B77D8 File Offset: 0x000B59D8
		// (set) Token: 0x06002EA2 RID: 11938 RVA: 0x000B7800 File Offset: 0x000B5A00
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x170010B0 RID: 4272
		// (get) Token: 0x06002EA3 RID: 11939 RVA: 0x000B7824 File Offset: 0x000B5A24
		// (set) Token: 0x06002EA4 RID: 11940 RVA: 0x000B7858 File Offset: 0x000B5A58
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170010B1 RID: 4273
		// (get) Token: 0x06002EA5 RID: 11941 RVA: 0x000B7880 File Offset: 0x000B5A80
		// (set) Token: 0x06002EA6 RID: 11942 RVA: 0x000B78B4 File Offset: 0x000B5AB4
		public unsafe ChemLightColorForcer __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ChemLightColorForcer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170010B2 RID: 4274
		// (get) Token: 0x06002EA7 RID: 11943 RVA: 0x000B78DC File Offset: 0x000B5ADC
		// (set) Token: 0x06002EA8 RID: 11944 RVA: 0x000B7904 File Offset: 0x000B5B04
		public unsafe int _frameCounter_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr__frameCounter_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightColorForcer._ForceRoutine_d__9.NativeFieldInfoPtr__frameCounter_5__2)) = value;
			}
		}

		// Token: 0x04001D6D RID: 7533
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04001D6E RID: 7534
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04001D6F RID: 7535
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04001D70 RID: 7536
		private static readonly IntPtr NativeFieldInfoPtr__frameCounter_5__2;

		// Token: 0x04001D71 RID: 7537
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04001D72 RID: 7538
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04001D73 RID: 7539
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04001D74 RID: 7540
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04001D75 RID: 7541
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04001D76 RID: 7542
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
