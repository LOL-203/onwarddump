﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200027D RID: 637
public class ChemLightLiquid : MonoBehaviour
{
	// Token: 0x170010D2 RID: 4306
	// (get) Token: 0x06002EA9 RID: 11945 RVA: 0x000B7928 File Offset: 0x000B5B28
	// (set) Token: 0x06002EAA RID: 11946 RVA: 0x000B7978 File Offset: 0x000B5B78
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06002EAB RID: 11947 RVA: 0x000B79CC File Offset: 0x000B5BCC
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EAC RID: 11948 RVA: 0x000B7A10 File Offset: 0x000B5C10
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EAD RID: 11949 RVA: 0x000B7A54 File Offset: 0x000B5C54
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EAE RID: 11950 RVA: 0x000B7A98 File Offset: 0x000B5C98
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EAF RID: 11951 RVA: 0x000B7ADC File Offset: 0x000B5CDC
	[CallerCount(0)]
	public unsafe void CacheHeights()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_CacheHeights_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EB0 RID: 11952 RVA: 0x000B7B20 File Offset: 0x000B5D20
	[CallerCount(0)]
	public unsafe float GetHeightScalar()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_GetHeightScalar_Private_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06002EB1 RID: 11953 RVA: 0x000B7B70 File Offset: 0x000B5D70
	[CallerCount(0)]
	public unsafe void UpdateFill(float dt)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_UpdateFill_Private_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EB2 RID: 11954 RVA: 0x000B7BC4 File Offset: 0x000B5DC4
	[CallerCount(0)]
	public unsafe void UpdateWobble(float dt)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref dt;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr_UpdateWobble_Private_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EB3 RID: 11955 RVA: 0x000B7C18 File Offset: 0x000B5E18
	[CallerCount(0)]
	public unsafe ChemLightLiquid() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChemLightLiquid.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06002EB4 RID: 11956 RVA: 0x000B7C64 File Offset: 0x000B5E64
	// Note: this type is marked as 'beforefieldinit'.
	static ChemLightLiquid()
	{
		Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ChemLightLiquid");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr);
		ChemLightLiquid.NativeFieldInfoPtr_FILL_KEYWORD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "FILL_KEYWORD");
		ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_X_KEYWORD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WOBBLE_X_KEYWORD");
		ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_Z_KEYWORD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WOBBLE_Z_KEYWORD");
		ChemLightLiquid.NativeFieldInfoPtr_Renderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "Renderer");
		ChemLightLiquid.NativeFieldInfoPtr_Pickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "Pickup");
		ChemLightLiquid.NativeFieldInfoPtr_Rigidbody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "Rigidbody");
		ChemLightLiquid.NativeFieldInfoPtr_FillRangeUp = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "FillRangeUp");
		ChemLightLiquid.NativeFieldInfoPtr_FillRangeDown = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "FillRangeDown");
		ChemLightLiquid.NativeFieldInfoPtr_FillRangeHorizontal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "FillRangeHorizontal");
		ChemLightLiquid.NativeFieldInfoPtr_FillScalar = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "FillScalar");
		ChemLightLiquid.NativeFieldInfoPtr_DebugFillDirect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "DebugFillDirect");
		ChemLightLiquid.NativeFieldInfoPtr_WobbleMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WobbleMax");
		ChemLightLiquid.NativeFieldInfoPtr_WobbleSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WobbleSpeed");
		ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryInHand = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WobbleRecoveryInHand");
		ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryOutOfHand = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WobbleRecoveryOutOfHand");
		ChemLightLiquid.NativeFieldInfoPtr_WobbleThickness = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "WobbleThickness");
		ChemLightLiquid.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		ChemLightLiquid.NativeFieldInfoPtr__transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_transform");
		ChemLightLiquid.NativeFieldInfoPtr__heightCacheHighest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_heightCacheHighest");
		ChemLightLiquid.NativeFieldInfoPtr__heightCacheLowest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_heightCacheLowest");
		ChemLightLiquid.NativeFieldInfoPtr__lastVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_lastVelocity");
		ChemLightLiquid.NativeFieldInfoPtr__lastAngularVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_lastAngularVelocity");
		ChemLightLiquid.NativeFieldInfoPtr__wobbleXCurrent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_wobbleXCurrent");
		ChemLightLiquid.NativeFieldInfoPtr__wobbleZCurrent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_wobbleZCurrent");
		ChemLightLiquid.NativeFieldInfoPtr__wobbleXToAdd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_wobbleXToAdd");
		ChemLightLiquid.NativeFieldInfoPtr__wobbleZToAdd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_wobbleZToAdd");
		ChemLightLiquid.NativeFieldInfoPtr__lastWave = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_lastWave");
		ChemLightLiquid.NativeFieldInfoPtr__timer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, "_timer");
		ChemLightLiquid.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666807);
		ChemLightLiquid.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666808);
		ChemLightLiquid.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666809);
		ChemLightLiquid.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666810);
		ChemLightLiquid.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666811);
		ChemLightLiquid.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666812);
		ChemLightLiquid.NativeMethodInfoPtr_CacheHeights_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666813);
		ChemLightLiquid.NativeMethodInfoPtr_GetHeightScalar_Private_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666814);
		ChemLightLiquid.NativeMethodInfoPtr_UpdateFill_Private_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666815);
		ChemLightLiquid.NativeMethodInfoPtr_UpdateWobble_Private_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666816);
		ChemLightLiquid.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr, 100666817);
	}

	// Token: 0x06002EB5 RID: 11957 RVA: 0x0000210C File Offset: 0x0000030C
	public ChemLightLiquid(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170010B5 RID: 4277
	// (get) Token: 0x06002EB6 RID: 11958 RVA: 0x000B7FA0 File Offset: 0x000B61A0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ChemLightLiquid>.NativeClassPtr));
		}
	}

	// Token: 0x170010B6 RID: 4278
	// (get) Token: 0x06002EB7 RID: 11959 RVA: 0x000B7FB4 File Offset: 0x000B61B4
	// (set) Token: 0x06002EB8 RID: 11960 RVA: 0x000B7FD2 File Offset: 0x000B61D2
	public unsafe static int FILL_KEYWORD
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(ChemLightLiquid.NativeFieldInfoPtr_FILL_KEYWORD, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ChemLightLiquid.NativeFieldInfoPtr_FILL_KEYWORD, (void*)(&value));
		}
	}

	// Token: 0x170010B7 RID: 4279
	// (get) Token: 0x06002EB9 RID: 11961 RVA: 0x000B7FE4 File Offset: 0x000B61E4
	// (set) Token: 0x06002EBA RID: 11962 RVA: 0x000B8002 File Offset: 0x000B6202
	public unsafe static int WOBBLE_X_KEYWORD
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_X_KEYWORD, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_X_KEYWORD, (void*)(&value));
		}
	}

	// Token: 0x170010B8 RID: 4280
	// (get) Token: 0x06002EBB RID: 11963 RVA: 0x000B8014 File Offset: 0x000B6214
	// (set) Token: 0x06002EBC RID: 11964 RVA: 0x000B8032 File Offset: 0x000B6232
	public unsafe static int WOBBLE_Z_KEYWORD
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_Z_KEYWORD, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ChemLightLiquid.NativeFieldInfoPtr_WOBBLE_Z_KEYWORD, (void*)(&value));
		}
	}

	// Token: 0x170010B9 RID: 4281
	// (get) Token: 0x06002EBD RID: 11965 RVA: 0x000B8044 File Offset: 0x000B6244
	// (set) Token: 0x06002EBE RID: 11966 RVA: 0x000B8078 File Offset: 0x000B6278
	public unsafe Renderer Renderer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Renderer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Renderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Renderer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010BA RID: 4282
	// (get) Token: 0x06002EBF RID: 11967 RVA: 0x000B80A0 File Offset: 0x000B62A0
	// (set) Token: 0x06002EC0 RID: 11968 RVA: 0x000B80D4 File Offset: 0x000B62D4
	public unsafe Pickup Pickup
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Pickup);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Pickup), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010BB RID: 4283
	// (get) Token: 0x06002EC1 RID: 11969 RVA: 0x000B80FC File Offset: 0x000B62FC
	// (set) Token: 0x06002EC2 RID: 11970 RVA: 0x000B8130 File Offset: 0x000B6330
	public unsafe Rigidbody Rigidbody
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Rigidbody);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_Rigidbody), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010BC RID: 4284
	// (get) Token: 0x06002EC3 RID: 11971 RVA: 0x000B8158 File Offset: 0x000B6358
	// (set) Token: 0x06002EC4 RID: 11972 RVA: 0x000B8180 File Offset: 0x000B6380
	public unsafe Vector2 FillRangeUp
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeUp);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeUp)) = value;
		}
	}

	// Token: 0x170010BD RID: 4285
	// (get) Token: 0x06002EC5 RID: 11973 RVA: 0x000B81A4 File Offset: 0x000B63A4
	// (set) Token: 0x06002EC6 RID: 11974 RVA: 0x000B81CC File Offset: 0x000B63CC
	public unsafe Vector2 FillRangeDown
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeDown);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeDown)) = value;
		}
	}

	// Token: 0x170010BE RID: 4286
	// (get) Token: 0x06002EC7 RID: 11975 RVA: 0x000B81F0 File Offset: 0x000B63F0
	// (set) Token: 0x06002EC8 RID: 11976 RVA: 0x000B8218 File Offset: 0x000B6418
	public unsafe Vector2 FillRangeHorizontal
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeHorizontal);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillRangeHorizontal)) = value;
		}
	}

	// Token: 0x170010BF RID: 4287
	// (get) Token: 0x06002EC9 RID: 11977 RVA: 0x000B823C File Offset: 0x000B643C
	// (set) Token: 0x06002ECA RID: 11978 RVA: 0x000B8264 File Offset: 0x000B6464
	public unsafe float FillScalar
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillScalar);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_FillScalar)) = value;
		}
	}

	// Token: 0x170010C0 RID: 4288
	// (get) Token: 0x06002ECB RID: 11979 RVA: 0x000B8288 File Offset: 0x000B6488
	// (set) Token: 0x06002ECC RID: 11980 RVA: 0x000B82B0 File Offset: 0x000B64B0
	public unsafe float DebugFillDirect
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_DebugFillDirect);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_DebugFillDirect)) = value;
		}
	}

	// Token: 0x170010C1 RID: 4289
	// (get) Token: 0x06002ECD RID: 11981 RVA: 0x000B82D4 File Offset: 0x000B64D4
	// (set) Token: 0x06002ECE RID: 11982 RVA: 0x000B82FC File Offset: 0x000B64FC
	public unsafe float WobbleMax
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleMax);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleMax)) = value;
		}
	}

	// Token: 0x170010C2 RID: 4290
	// (get) Token: 0x06002ECF RID: 11983 RVA: 0x000B8320 File Offset: 0x000B6520
	// (set) Token: 0x06002ED0 RID: 11984 RVA: 0x000B8348 File Offset: 0x000B6548
	public unsafe float WobbleSpeed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleSpeed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleSpeed)) = value;
		}
	}

	// Token: 0x170010C3 RID: 4291
	// (get) Token: 0x06002ED1 RID: 11985 RVA: 0x000B836C File Offset: 0x000B656C
	// (set) Token: 0x06002ED2 RID: 11986 RVA: 0x000B8394 File Offset: 0x000B6594
	public unsafe float WobbleRecoveryInHand
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryInHand);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryInHand)) = value;
		}
	}

	// Token: 0x170010C4 RID: 4292
	// (get) Token: 0x06002ED3 RID: 11987 RVA: 0x000B83B8 File Offset: 0x000B65B8
	// (set) Token: 0x06002ED4 RID: 11988 RVA: 0x000B83E0 File Offset: 0x000B65E0
	public unsafe float WobbleRecoveryOutOfHand
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryOutOfHand);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleRecoveryOutOfHand)) = value;
		}
	}

	// Token: 0x170010C5 RID: 4293
	// (get) Token: 0x06002ED5 RID: 11989 RVA: 0x000B8404 File Offset: 0x000B6604
	// (set) Token: 0x06002ED6 RID: 11990 RVA: 0x000B842C File Offset: 0x000B662C
	public unsafe float WobbleThickness
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleThickness);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr_WobbleThickness)) = value;
		}
	}

	// Token: 0x170010C6 RID: 4294
	// (get) Token: 0x06002ED7 RID: 11991 RVA: 0x000B8450 File Offset: 0x000B6650
	// (set) Token: 0x06002ED8 RID: 11992 RVA: 0x000B8478 File Offset: 0x000B6678
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x170010C7 RID: 4295
	// (get) Token: 0x06002ED9 RID: 11993 RVA: 0x000B849C File Offset: 0x000B669C
	// (set) Token: 0x06002EDA RID: 11994 RVA: 0x000B84D0 File Offset: 0x000B66D0
	public unsafe Transform _transform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__transform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__transform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170010C8 RID: 4296
	// (get) Token: 0x06002EDB RID: 11995 RVA: 0x000B84F8 File Offset: 0x000B66F8
	// (set) Token: 0x06002EDC RID: 11996 RVA: 0x000B8520 File Offset: 0x000B6720
	public unsafe float _heightCacheHighest
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__heightCacheHighest);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__heightCacheHighest)) = value;
		}
	}

	// Token: 0x170010C9 RID: 4297
	// (get) Token: 0x06002EDD RID: 11997 RVA: 0x000B8544 File Offset: 0x000B6744
	// (set) Token: 0x06002EDE RID: 11998 RVA: 0x000B856C File Offset: 0x000B676C
	public unsafe float _heightCacheLowest
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__heightCacheLowest);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__heightCacheLowest)) = value;
		}
	}

	// Token: 0x170010CA RID: 4298
	// (get) Token: 0x06002EDF RID: 11999 RVA: 0x000B8590 File Offset: 0x000B6790
	// (set) Token: 0x06002EE0 RID: 12000 RVA: 0x000B85B8 File Offset: 0x000B67B8
	public unsafe Vector3 _lastVelocity
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastVelocity);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastVelocity)) = value;
		}
	}

	// Token: 0x170010CB RID: 4299
	// (get) Token: 0x06002EE1 RID: 12001 RVA: 0x000B85DC File Offset: 0x000B67DC
	// (set) Token: 0x06002EE2 RID: 12002 RVA: 0x000B8604 File Offset: 0x000B6804
	public unsafe Vector3 _lastAngularVelocity
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastAngularVelocity);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastAngularVelocity)) = value;
		}
	}

	// Token: 0x170010CC RID: 4300
	// (get) Token: 0x06002EE3 RID: 12003 RVA: 0x000B8628 File Offset: 0x000B6828
	// (set) Token: 0x06002EE4 RID: 12004 RVA: 0x000B8650 File Offset: 0x000B6850
	public unsafe float _wobbleXCurrent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleXCurrent);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleXCurrent)) = value;
		}
	}

	// Token: 0x170010CD RID: 4301
	// (get) Token: 0x06002EE5 RID: 12005 RVA: 0x000B8674 File Offset: 0x000B6874
	// (set) Token: 0x06002EE6 RID: 12006 RVA: 0x000B869C File Offset: 0x000B689C
	public unsafe float _wobbleZCurrent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleZCurrent);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleZCurrent)) = value;
		}
	}

	// Token: 0x170010CE RID: 4302
	// (get) Token: 0x06002EE7 RID: 12007 RVA: 0x000B86C0 File Offset: 0x000B68C0
	// (set) Token: 0x06002EE8 RID: 12008 RVA: 0x000B86E8 File Offset: 0x000B68E8
	public unsafe float _wobbleXToAdd
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleXToAdd);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleXToAdd)) = value;
		}
	}

	// Token: 0x170010CF RID: 4303
	// (get) Token: 0x06002EE9 RID: 12009 RVA: 0x000B870C File Offset: 0x000B690C
	// (set) Token: 0x06002EEA RID: 12010 RVA: 0x000B8734 File Offset: 0x000B6934
	public unsafe float _wobbleZToAdd
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleZToAdd);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__wobbleZToAdd)) = value;
		}
	}

	// Token: 0x170010D0 RID: 4304
	// (get) Token: 0x06002EEB RID: 12011 RVA: 0x000B8758 File Offset: 0x000B6958
	// (set) Token: 0x06002EEC RID: 12012 RVA: 0x000B8780 File Offset: 0x000B6980
	public unsafe float _lastWave
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastWave);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__lastWave)) = value;
		}
	}

	// Token: 0x170010D1 RID: 4305
	// (get) Token: 0x06002EED RID: 12013 RVA: 0x000B87A4 File Offset: 0x000B69A4
	// (set) Token: 0x06002EEE RID: 12014 RVA: 0x000B87CC File Offset: 0x000B69CC
	public unsafe float _timer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__timer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChemLightLiquid.NativeFieldInfoPtr__timer)) = value;
		}
	}

	// Token: 0x04001D77 RID: 7543
	private static readonly IntPtr NativeFieldInfoPtr_FILL_KEYWORD;

	// Token: 0x04001D78 RID: 7544
	private static readonly IntPtr NativeFieldInfoPtr_WOBBLE_X_KEYWORD;

	// Token: 0x04001D79 RID: 7545
	private static readonly IntPtr NativeFieldInfoPtr_WOBBLE_Z_KEYWORD;

	// Token: 0x04001D7A RID: 7546
	private static readonly IntPtr NativeFieldInfoPtr_Renderer;

	// Token: 0x04001D7B RID: 7547
	private static readonly IntPtr NativeFieldInfoPtr_Pickup;

	// Token: 0x04001D7C RID: 7548
	private static readonly IntPtr NativeFieldInfoPtr_Rigidbody;

	// Token: 0x04001D7D RID: 7549
	private static readonly IntPtr NativeFieldInfoPtr_FillRangeUp;

	// Token: 0x04001D7E RID: 7550
	private static readonly IntPtr NativeFieldInfoPtr_FillRangeDown;

	// Token: 0x04001D7F RID: 7551
	private static readonly IntPtr NativeFieldInfoPtr_FillRangeHorizontal;

	// Token: 0x04001D80 RID: 7552
	private static readonly IntPtr NativeFieldInfoPtr_FillScalar;

	// Token: 0x04001D81 RID: 7553
	private static readonly IntPtr NativeFieldInfoPtr_DebugFillDirect;

	// Token: 0x04001D82 RID: 7554
	private static readonly IntPtr NativeFieldInfoPtr_WobbleMax;

	// Token: 0x04001D83 RID: 7555
	private static readonly IntPtr NativeFieldInfoPtr_WobbleSpeed;

	// Token: 0x04001D84 RID: 7556
	private static readonly IntPtr NativeFieldInfoPtr_WobbleRecoveryInHand;

	// Token: 0x04001D85 RID: 7557
	private static readonly IntPtr NativeFieldInfoPtr_WobbleRecoveryOutOfHand;

	// Token: 0x04001D86 RID: 7558
	private static readonly IntPtr NativeFieldInfoPtr_WobbleThickness;

	// Token: 0x04001D87 RID: 7559
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x04001D88 RID: 7560
	private static readonly IntPtr NativeFieldInfoPtr__transform;

	// Token: 0x04001D89 RID: 7561
	private static readonly IntPtr NativeFieldInfoPtr__heightCacheHighest;

	// Token: 0x04001D8A RID: 7562
	private static readonly IntPtr NativeFieldInfoPtr__heightCacheLowest;

	// Token: 0x04001D8B RID: 7563
	private static readonly IntPtr NativeFieldInfoPtr__lastVelocity;

	// Token: 0x04001D8C RID: 7564
	private static readonly IntPtr NativeFieldInfoPtr__lastAngularVelocity;

	// Token: 0x04001D8D RID: 7565
	private static readonly IntPtr NativeFieldInfoPtr__wobbleXCurrent;

	// Token: 0x04001D8E RID: 7566
	private static readonly IntPtr NativeFieldInfoPtr__wobbleZCurrent;

	// Token: 0x04001D8F RID: 7567
	private static readonly IntPtr NativeFieldInfoPtr__wobbleXToAdd;

	// Token: 0x04001D90 RID: 7568
	private static readonly IntPtr NativeFieldInfoPtr__wobbleZToAdd;

	// Token: 0x04001D91 RID: 7569
	private static readonly IntPtr NativeFieldInfoPtr__lastWave;

	// Token: 0x04001D92 RID: 7570
	private static readonly IntPtr NativeFieldInfoPtr__timer;

	// Token: 0x04001D93 RID: 7571
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04001D94 RID: 7572
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x04001D95 RID: 7573
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04001D96 RID: 7574
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04001D97 RID: 7575
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04001D98 RID: 7576
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04001D99 RID: 7577
	private static readonly IntPtr NativeMethodInfoPtr_CacheHeights_Private_Void_0;

	// Token: 0x04001D9A RID: 7578
	private static readonly IntPtr NativeMethodInfoPtr_GetHeightScalar_Private_Single_0;

	// Token: 0x04001D9B RID: 7579
	private static readonly IntPtr NativeMethodInfoPtr_UpdateFill_Private_Void_Single_0;

	// Token: 0x04001D9C RID: 7580
	private static readonly IntPtr NativeMethodInfoPtr_UpdateWobble_Private_Void_Single_0;

	// Token: 0x04001D9D RID: 7581
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
