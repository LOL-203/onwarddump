﻿using System;
using Il2CppSystem;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020003B3 RID: 947
public class DamageOverTimeStatus : StatusEffectBase
{
	// Token: 0x17001B12 RID: 6930
	// (get) Token: 0x06004B79 RID: 19321 RVA: 0x0012E584 File Offset: 0x0012C784
	public unsafe bool IsPlayer
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageOverTimeStatus.NativeMethodInfoPtr_get_IsPlayer_Protected_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06004B7A RID: 19322 RVA: 0x0012E5D4 File Offset: 0x0012C7D4
	[CallerCount(0)]
	public new unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageOverTimeStatus.NativeMethodInfoPtr_Awake_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B7B RID: 19323 RVA: 0x0012E624 File Offset: 0x0012C824
	[CallerCount(0)]
	public new unsafe void OnApply(OnwardPhotonPlayer otherPlayer, Il2CppReferenceArray<Object> values)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(otherPlayer);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(values);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageOverTimeStatus.NativeMethodInfoPtr_OnApply_Public_Virtual_Void_OnwardPhotonPlayer_ArrayOf_Object_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B7C RID: 19324 RVA: 0x0012E6A0 File Offset: 0x0012C8A0
	[CallerCount(0)]
	public new unsafe void OnRemove()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageOverTimeStatus.NativeMethodInfoPtr_OnRemove_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B7D RID: 19325 RVA: 0x0012E6F0 File Offset: 0x0012C8F0
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageOverTimeStatus.NativeMethodInfoPtr_Update_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B7E RID: 19326 RVA: 0x0012E740 File Offset: 0x0012C940
	[CallerCount(0)]
	public unsafe void OnDamageApplied()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DamageOverTimeStatus.NativeMethodInfoPtr_OnDamageApplied_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B7F RID: 19327 RVA: 0x0012E790 File Offset: 0x0012C990
	[CallerCount(0)]
	public unsafe DamageOverTimeStatus() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageOverTimeStatus.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004B80 RID: 19328 RVA: 0x0012E7DC File Offset: 0x0012C9DC
	// Note: this type is marked as 'beforefieldinit'.
	static DamageOverTimeStatus()
	{
		Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageOverTimeStatus");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr);
		DamageOverTimeStatus.NativeFieldInfoPtr_DamageInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "DamageInterval");
		DamageOverTimeStatus.NativeFieldInfoPtr_DamageAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "DamageAmount");
		DamageOverTimeStatus.NativeFieldInfoPtr_TypedDamage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "TypedDamage");
		DamageOverTimeStatus.NativeFieldInfoPtr_OtherPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "OtherPlayer");
		DamageOverTimeStatus.NativeFieldInfoPtr_ElapsedTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "ElapsedTime");
		DamageOverTimeStatus.NativeFieldInfoPtr_DmgController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, "DmgController");
		DamageOverTimeStatus.NativeMethodInfoPtr_get_IsPlayer_Protected_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669220);
		DamageOverTimeStatus.NativeMethodInfoPtr_Awake_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669221);
		DamageOverTimeStatus.NativeMethodInfoPtr_OnApply_Public_Virtual_Void_OnwardPhotonPlayer_ArrayOf_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669222);
		DamageOverTimeStatus.NativeMethodInfoPtr_OnRemove_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669223);
		DamageOverTimeStatus.NativeMethodInfoPtr_Update_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669224);
		DamageOverTimeStatus.NativeMethodInfoPtr_OnDamageApplied_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669225);
		DamageOverTimeStatus.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr, 100669226);
	}

	// Token: 0x06004B81 RID: 19329 RVA: 0x0012E910 File Offset: 0x0012CB10
	public DamageOverTimeStatus(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001B0B RID: 6923
	// (get) Token: 0x06004B82 RID: 19330 RVA: 0x0012E919 File Offset: 0x0012CB19
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageOverTimeStatus>.NativeClassPtr));
		}
	}

	// Token: 0x17001B0C RID: 6924
	// (get) Token: 0x06004B83 RID: 19331 RVA: 0x0012E92C File Offset: 0x0012CB2C
	// (set) Token: 0x06004B84 RID: 19332 RVA: 0x0012E954 File Offset: 0x0012CB54
	public unsafe float DamageInterval
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DamageInterval);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DamageInterval)) = value;
		}
	}

	// Token: 0x17001B0D RID: 6925
	// (get) Token: 0x06004B85 RID: 19333 RVA: 0x0012E978 File Offset: 0x0012CB78
	// (set) Token: 0x06004B86 RID: 19334 RVA: 0x0012E9A0 File Offset: 0x0012CBA0
	public unsafe float DamageAmount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DamageAmount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DamageAmount)) = value;
		}
	}

	// Token: 0x17001B0E RID: 6926
	// (get) Token: 0x06004B87 RID: 19335 RVA: 0x0012E9C4 File Offset: 0x0012CBC4
	// (set) Token: 0x06004B88 RID: 19336 RVA: 0x0012E9EC File Offset: 0x0012CBEC
	public unsafe DamageType TypedDamage
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_TypedDamage);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_TypedDamage)) = value;
		}
	}

	// Token: 0x17001B0F RID: 6927
	// (get) Token: 0x06004B89 RID: 19337 RVA: 0x0012EA10 File Offset: 0x0012CC10
	// (set) Token: 0x06004B8A RID: 19338 RVA: 0x0012EA44 File Offset: 0x0012CC44
	public unsafe OnwardPhotonPlayer OtherPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_OtherPlayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OnwardPhotonPlayer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_OtherPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001B10 RID: 6928
	// (get) Token: 0x06004B8B RID: 19339 RVA: 0x0012EA6C File Offset: 0x0012CC6C
	// (set) Token: 0x06004B8C RID: 19340 RVA: 0x0012EA94 File Offset: 0x0012CC94
	public unsafe float ElapsedTime
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_ElapsedTime);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_ElapsedTime)) = value;
		}
	}

	// Token: 0x17001B11 RID: 6929
	// (get) Token: 0x06004B8D RID: 19341 RVA: 0x0012EAB8 File Offset: 0x0012CCB8
	// (set) Token: 0x06004B8E RID: 19342 RVA: 0x0012EAEC File Offset: 0x0012CCEC
	public unsafe DamageController DmgController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DmgController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageOverTimeStatus.NativeFieldInfoPtr_DmgController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400300E RID: 12302
	private static readonly IntPtr NativeFieldInfoPtr_DamageInterval;

	// Token: 0x0400300F RID: 12303
	private static readonly IntPtr NativeFieldInfoPtr_DamageAmount;

	// Token: 0x04003010 RID: 12304
	private static readonly IntPtr NativeFieldInfoPtr_TypedDamage;

	// Token: 0x04003011 RID: 12305
	private static readonly IntPtr NativeFieldInfoPtr_OtherPlayer;

	// Token: 0x04003012 RID: 12306
	private static readonly IntPtr NativeFieldInfoPtr_ElapsedTime;

	// Token: 0x04003013 RID: 12307
	private static readonly IntPtr NativeFieldInfoPtr_DmgController;

	// Token: 0x04003014 RID: 12308
	private static readonly IntPtr NativeMethodInfoPtr_get_IsPlayer_Protected_get_Boolean_0;

	// Token: 0x04003015 RID: 12309
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Protected_Virtual_Void_0;

	// Token: 0x04003016 RID: 12310
	private static readonly IntPtr NativeMethodInfoPtr_OnApply_Public_Virtual_Void_OnwardPhotonPlayer_ArrayOf_Object_0;

	// Token: 0x04003017 RID: 12311
	private static readonly IntPtr NativeMethodInfoPtr_OnRemove_Public_Virtual_Void_0;

	// Token: 0x04003018 RID: 12312
	private static readonly IntPtr NativeMethodInfoPtr_Update_Protected_Virtual_New_Void_0;

	// Token: 0x04003019 RID: 12313
	private static readonly IntPtr NativeMethodInfoPtr_OnDamageApplied_Protected_Virtual_New_Void_0;

	// Token: 0x0400301A RID: 12314
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
}
