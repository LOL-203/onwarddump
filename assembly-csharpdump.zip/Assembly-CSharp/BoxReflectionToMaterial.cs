﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C4 RID: 196
public class BoxReflectionToMaterial : MonoBehaviour
{
	// Token: 0x06000C39 RID: 3129 RVA: 0x00031C2C File Offset: 0x0002FE2C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoxReflectionToMaterial.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x00031C70 File Offset: 0x0002FE70
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoxReflectionToMaterial.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x00031CB4 File Offset: 0x0002FEB4
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoxReflectionToMaterial.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x00031CF8 File Offset: 0x0002FEF8
	[CallerCount(0)]
	public unsafe BoxReflectionToMaterial() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoxReflectionToMaterial.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x00031D44 File Offset: 0x0002FF44
	// Note: this type is marked as 'beforefieldinit'.
	static BoxReflectionToMaterial()
	{
		Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BoxReflectionToMaterial");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr);
		BoxReflectionToMaterial.NativeFieldInfoPtr_TheProbe = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "TheProbe");
		BoxReflectionToMaterial.NativeFieldInfoPtr_theMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "theMaterial");
		BoxReflectionToMaterial.NativeFieldInfoPtr_probeCenter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "probeCenter");
		BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbeCenter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "oldProbeCenter");
		BoxReflectionToMaterial.NativeFieldInfoPtr_probePos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "probePos");
		BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbePos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "oldProbePos");
		BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "calculatedBoxMin");
		BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "oldCalculatedBoxMin");
		BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "calculatedBoxMax");
		BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, "oldCalculatedBoxMax");
		BoxReflectionToMaterial.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, 100664250);
		BoxReflectionToMaterial.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, 100664251);
		BoxReflectionToMaterial.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, 100664252);
		BoxReflectionToMaterial.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr, 100664253);
	}

	// Token: 0x06000C3E RID: 3134 RVA: 0x0000210C File Offset: 0x0000030C
	public BoxReflectionToMaterial(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000436 RID: 1078
	// (get) Token: 0x06000C3F RID: 3135 RVA: 0x00031E8C File Offset: 0x0003008C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BoxReflectionToMaterial>.NativeClassPtr));
		}
	}

	// Token: 0x17000437 RID: 1079
	// (get) Token: 0x06000C40 RID: 3136 RVA: 0x00031EA0 File Offset: 0x000300A0
	// (set) Token: 0x06000C41 RID: 3137 RVA: 0x00031ED4 File Offset: 0x000300D4
	public unsafe ReflectionProbe TheProbe
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_TheProbe);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ReflectionProbe(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_TheProbe), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000438 RID: 1080
	// (get) Token: 0x06000C42 RID: 3138 RVA: 0x00031EFC File Offset: 0x000300FC
	// (set) Token: 0x06000C43 RID: 3139 RVA: 0x00031F30 File Offset: 0x00030130
	public unsafe Material theMaterial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_theMaterial);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Material(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_theMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000439 RID: 1081
	// (get) Token: 0x06000C44 RID: 3140 RVA: 0x00031F58 File Offset: 0x00030158
	// (set) Token: 0x06000C45 RID: 3141 RVA: 0x00031F80 File Offset: 0x00030180
	public unsafe Vector3 probeCenter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_probeCenter);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_probeCenter)) = value;
		}
	}

	// Token: 0x1700043A RID: 1082
	// (get) Token: 0x06000C46 RID: 3142 RVA: 0x00031FA4 File Offset: 0x000301A4
	// (set) Token: 0x06000C47 RID: 3143 RVA: 0x00031FCC File Offset: 0x000301CC
	public unsafe Vector3 oldProbeCenter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbeCenter);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbeCenter)) = value;
		}
	}

	// Token: 0x1700043B RID: 1083
	// (get) Token: 0x06000C48 RID: 3144 RVA: 0x00031FF0 File Offset: 0x000301F0
	// (set) Token: 0x06000C49 RID: 3145 RVA: 0x00032018 File Offset: 0x00030218
	public unsafe Vector3 probePos
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_probePos);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_probePos)) = value;
		}
	}

	// Token: 0x1700043C RID: 1084
	// (get) Token: 0x06000C4A RID: 3146 RVA: 0x0003203C File Offset: 0x0003023C
	// (set) Token: 0x06000C4B RID: 3147 RVA: 0x00032064 File Offset: 0x00030264
	public unsafe Vector3 oldProbePos
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbePos);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldProbePos)) = value;
		}
	}

	// Token: 0x1700043D RID: 1085
	// (get) Token: 0x06000C4C RID: 3148 RVA: 0x00032088 File Offset: 0x00030288
	// (set) Token: 0x06000C4D RID: 3149 RVA: 0x000320B0 File Offset: 0x000302B0
	public unsafe Vector3 calculatedBoxMin
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMin);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMin)) = value;
		}
	}

	// Token: 0x1700043E RID: 1086
	// (get) Token: 0x06000C4E RID: 3150 RVA: 0x000320D4 File Offset: 0x000302D4
	// (set) Token: 0x06000C4F RID: 3151 RVA: 0x000320FC File Offset: 0x000302FC
	public unsafe Vector3 oldCalculatedBoxMin
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMin);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMin)) = value;
		}
	}

	// Token: 0x1700043F RID: 1087
	// (get) Token: 0x06000C50 RID: 3152 RVA: 0x00032120 File Offset: 0x00030320
	// (set) Token: 0x06000C51 RID: 3153 RVA: 0x00032148 File Offset: 0x00030348
	public unsafe Vector3 calculatedBoxMax
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMax);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_calculatedBoxMax)) = value;
		}
	}

	// Token: 0x17000440 RID: 1088
	// (get) Token: 0x06000C52 RID: 3154 RVA: 0x0003216C File Offset: 0x0003036C
	// (set) Token: 0x06000C53 RID: 3155 RVA: 0x00032194 File Offset: 0x00030394
	public unsafe Vector3 oldCalculatedBoxMax
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMax);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoxReflectionToMaterial.NativeFieldInfoPtr_oldCalculatedBoxMax)) = value;
		}
	}

	// Token: 0x04000766 RID: 1894
	private static readonly IntPtr NativeFieldInfoPtr_TheProbe;

	// Token: 0x04000767 RID: 1895
	private static readonly IntPtr NativeFieldInfoPtr_theMaterial;

	// Token: 0x04000768 RID: 1896
	private static readonly IntPtr NativeFieldInfoPtr_probeCenter;

	// Token: 0x04000769 RID: 1897
	private static readonly IntPtr NativeFieldInfoPtr_oldProbeCenter;

	// Token: 0x0400076A RID: 1898
	private static readonly IntPtr NativeFieldInfoPtr_probePos;

	// Token: 0x0400076B RID: 1899
	private static readonly IntPtr NativeFieldInfoPtr_oldProbePos;

	// Token: 0x0400076C RID: 1900
	private static readonly IntPtr NativeFieldInfoPtr_calculatedBoxMin;

	// Token: 0x0400076D RID: 1901
	private static readonly IntPtr NativeFieldInfoPtr_oldCalculatedBoxMin;

	// Token: 0x0400076E RID: 1902
	private static readonly IntPtr NativeFieldInfoPtr_calculatedBoxMax;

	// Token: 0x0400076F RID: 1903
	private static readonly IntPtr NativeFieldInfoPtr_oldCalculatedBoxMax;

	// Token: 0x04000770 RID: 1904
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000771 RID: 1905
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04000772 RID: 1906
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04000773 RID: 1907
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
