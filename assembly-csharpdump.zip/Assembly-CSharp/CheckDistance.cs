﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000B2 RID: 178
public class CheckDistance : MonoBehaviour
{
	// Token: 0x06000B24 RID: 2852 RVA: 0x0002DFA0 File Offset: 0x0002C1A0
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CheckDistance.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x0002DFE4 File Offset: 0x0002C1E4
	[CallerCount(0)]
	public unsafe CheckDistance() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CheckDistance.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x0002E030 File Offset: 0x0002C230
	// Note: this type is marked as 'beforefieldinit'.
	static CheckDistance()
	{
		Il2CppClassPointerStore<CheckDistance>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CheckDistance");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr);
		CheckDistance.NativeFieldInfoPtr_PositionA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr, "PositionA");
		CheckDistance.NativeFieldInfoPtr_PositionB = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr, "PositionB");
		CheckDistance.NativeFieldInfoPtr_TestDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr, "TestDistance");
		CheckDistance.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr, 100664184);
		CheckDistance.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr, 100664185);
	}

	// Token: 0x06000B27 RID: 2855 RVA: 0x0000210C File Offset: 0x0000030C
	public CheckDistance(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170003D1 RID: 977
	// (get) Token: 0x06000B28 RID: 2856 RVA: 0x0002E0C4 File Offset: 0x0002C2C4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CheckDistance>.NativeClassPtr));
		}
	}

	// Token: 0x170003D2 RID: 978
	// (get) Token: 0x06000B29 RID: 2857 RVA: 0x0002E0D8 File Offset: 0x0002C2D8
	// (set) Token: 0x06000B2A RID: 2858 RVA: 0x0002E10C File Offset: 0x0002C30C
	public unsafe Transform PositionA
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_PositionA);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_PositionA), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170003D3 RID: 979
	// (get) Token: 0x06000B2B RID: 2859 RVA: 0x0002E134 File Offset: 0x0002C334
	// (set) Token: 0x06000B2C RID: 2860 RVA: 0x0002E168 File Offset: 0x0002C368
	public unsafe Transform PositionB
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_PositionB);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_PositionB), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170003D4 RID: 980
	// (get) Token: 0x06000B2D RID: 2861 RVA: 0x0002E190 File Offset: 0x0002C390
	// (set) Token: 0x06000B2E RID: 2862 RVA: 0x0002E1B8 File Offset: 0x0002C3B8
	public unsafe bool TestDistance
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_TestDistance);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CheckDistance.NativeFieldInfoPtr_TestDistance)) = value;
		}
	}

	// Token: 0x040006CB RID: 1739
	private static readonly IntPtr NativeFieldInfoPtr_PositionA;

	// Token: 0x040006CC RID: 1740
	private static readonly IntPtr NativeFieldInfoPtr_PositionB;

	// Token: 0x040006CD RID: 1741
	private static readonly IntPtr NativeFieldInfoPtr_TestDistance;

	// Token: 0x040006CE RID: 1742
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x040006CF RID: 1743
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
