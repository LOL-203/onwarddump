﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004EF RID: 1263
public class BulletHole : MonoBehaviour
{
	// Token: 0x060066D3 RID: 26323 RVA: 0x0019D090 File Offset: 0x0019B290
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHole.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066D4 RID: 26324 RVA: 0x0019D0D4 File Offset: 0x0019B2D4
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHole.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066D5 RID: 26325 RVA: 0x0019D118 File Offset: 0x0019B318
	[CallerCount(0)]
	public unsafe BulletHole() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BulletHole>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHole.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066D6 RID: 26326 RVA: 0x0019D164 File Offset: 0x0019B364
	// Note: this type is marked as 'beforefieldinit'.
	static BulletHole()
	{
		Il2CppClassPointerStore<BulletHole>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BulletHole");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BulletHole>.NativeClassPtr);
		BulletHole.NativeFieldInfoPtr_MAX_ALLOWED_BULLET_HOLES = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, "MAX_ALLOWED_BULLET_HOLES");
		BulletHole.NativeFieldInfoPtr_AllHoles = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, "AllHoles");
		BulletHole.NativeFieldInfoPtr_HoleCycle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, "HoleCycle");
		BulletHole.NativeFieldInfoPtr_thisRend = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, "thisRend");
		BulletHole.NativeFieldInfoPtr_MHitEffect = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, "MHitEffect");
		BulletHole.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, 100671471);
		BulletHole.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, 100671472);
		BulletHole.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHole>.NativeClassPtr, 100671473);
	}

	// Token: 0x060066D7 RID: 26327 RVA: 0x0000210C File Offset: 0x0000030C
	public BulletHole(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700247C RID: 9340
	// (get) Token: 0x060066D8 RID: 26328 RVA: 0x0019D234 File Offset: 0x0019B434
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BulletHole>.NativeClassPtr));
		}
	}

	// Token: 0x1700247D RID: 9341
	// (get) Token: 0x060066D9 RID: 26329 RVA: 0x0019D248 File Offset: 0x0019B448
	// (set) Token: 0x060066DA RID: 26330 RVA: 0x0019D266 File Offset: 0x0019B466
	public unsafe static int MAX_ALLOWED_BULLET_HOLES
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(BulletHole.NativeFieldInfoPtr_MAX_ALLOWED_BULLET_HOLES, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BulletHole.NativeFieldInfoPtr_MAX_ALLOWED_BULLET_HOLES, (void*)(&value));
		}
	}

	// Token: 0x1700247E RID: 9342
	// (get) Token: 0x060066DB RID: 26331 RVA: 0x0019D278 File Offset: 0x0019B478
	// (set) Token: 0x060066DC RID: 26332 RVA: 0x0019D2A3 File Offset: 0x0019B4A3
	public unsafe static Il2CppReferenceArray<BulletHole> AllHoles
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(BulletHole.NativeFieldInfoPtr_AllHoles, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<BulletHole>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BulletHole.NativeFieldInfoPtr_AllHoles, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700247F RID: 9343
	// (get) Token: 0x060066DD RID: 26333 RVA: 0x0019D2B8 File Offset: 0x0019B4B8
	// (set) Token: 0x060066DE RID: 26334 RVA: 0x0019D2D6 File Offset: 0x0019B4D6
	public unsafe static int HoleCycle
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(BulletHole.NativeFieldInfoPtr_HoleCycle, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BulletHole.NativeFieldInfoPtr_HoleCycle, (void*)(&value));
		}
	}

	// Token: 0x17002480 RID: 9344
	// (get) Token: 0x060066DF RID: 26335 RVA: 0x0019D2E8 File Offset: 0x0019B4E8
	// (set) Token: 0x060066E0 RID: 26336 RVA: 0x0019D31C File Offset: 0x0019B51C
	public unsafe Renderer thisRend
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHole.NativeFieldInfoPtr_thisRend);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Renderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHole.NativeFieldInfoPtr_thisRend), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002481 RID: 9345
	// (get) Token: 0x060066E1 RID: 26337 RVA: 0x0019D344 File Offset: 0x0019B544
	// (set) Token: 0x060066E2 RID: 26338 RVA: 0x0019D378 File Offset: 0x0019B578
	public unsafe MasterHitEffect MHitEffect
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHole.NativeFieldInfoPtr_MHitEffect);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MasterHitEffect(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHole.NativeFieldInfoPtr_MHitEffect), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040040EC RID: 16620
	private static readonly IntPtr NativeFieldInfoPtr_MAX_ALLOWED_BULLET_HOLES;

	// Token: 0x040040ED RID: 16621
	private static readonly IntPtr NativeFieldInfoPtr_AllHoles;

	// Token: 0x040040EE RID: 16622
	private static readonly IntPtr NativeFieldInfoPtr_HoleCycle;

	// Token: 0x040040EF RID: 16623
	private static readonly IntPtr NativeFieldInfoPtr_thisRend;

	// Token: 0x040040F0 RID: 16624
	private static readonly IntPtr NativeFieldInfoPtr_MHitEffect;

	// Token: 0x040040F1 RID: 16625
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x040040F2 RID: 16626
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040040F3 RID: 16627
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
