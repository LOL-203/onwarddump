﻿using System;
using DPI.Services;
using Il2CppSystem;
using Oculus.Platform;
using Oculus.Platform.Models;
using Steamworks;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using _Game.PlatformSDK_Helpers;

// Token: 0x0200030A RID: 778
public class DeeplinkManager : MonoBehaviour
{
	// Token: 0x170015B9 RID: 5561
	// (get) Token: 0x06003D39 RID: 15673 RVA: 0x000F72F4 File Offset: 0x000F54F4
	// (set) Token: 0x06003D3A RID: 15674 RVA: 0x000F7344 File Offset: 0x000F5544
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06003D3B RID: 15675 RVA: 0x000F7398 File Offset: 0x000F5598
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D3C RID: 15676 RVA: 0x000F73DC File Offset: 0x000F55DC
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D3D RID: 15677 RVA: 0x000F7420 File Offset: 0x000F5620
	[CallerCount(0)]
	public unsafe void OnMainMenuReached()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnMainMenuReached_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D3E RID: 15678 RVA: 0x000F7464 File Offset: 0x000F5664
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D3F RID: 15679 RVA: 0x000F74A8 File Offset: 0x000F56A8
	[CallerCount(0)]
	public unsafe void Initialize()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_Initialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D40 RID: 15680 RVA: 0x000F74EC File Offset: 0x000F56EC
	[CallerCount(0)]
	public unsafe void SteamFriendsOnOnGameRichPresenceJoinRequested(Friend friend, string serverInfoString)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref friend;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(serverInfoString);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_SteamFriendsOnOnGameRichPresenceJoinRequested_Private_Void_Friend_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D41 RID: 15681 RVA: 0x000F7558 File Offset: 0x000F5758
	[CallerCount(0)]
	public unsafe void OnOculusJoinIntent(Message<GroupPresenceJoinIntent> message)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(message);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnOculusJoinIntent_Private_Void_Message_1_GroupPresenceJoinIntent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D42 RID: 15682 RVA: 0x000F75B4 File Offset: 0x000F57B4
	[CallerCount(0)]
	public unsafe void AcceptedDeepLinkJoinRequest(string sessionIdToJoin, string password)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(sessionIdToJoin);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(password);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_AcceptedDeepLinkJoinRequest_Private_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D43 RID: 15683 RVA: 0x000F7628 File Offset: 0x000F5828
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D44 RID: 15684 RVA: 0x000F766C File Offset: 0x000F586C
	[CallerCount(0)]
	public unsafe void OnDeeplinkSuccess()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnDeeplinkSuccess_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D45 RID: 15685 RVA: 0x000F76B0 File Offset: 0x000F58B0
	[CallerCount(0)]
	public unsafe void OnDeeplinkFailed(DeeplinkFailedReason reason)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref reason;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr_OnDeeplinkFailed_Public_Void_DeeplinkFailedReason_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D46 RID: 15686 RVA: 0x000F7704 File Offset: 0x000F5904
	[CallerCount(0)]
	public unsafe DeeplinkManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeeplinkManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003D47 RID: 15687 RVA: 0x000F7750 File Offset: 0x000F5950
	// Note: this type is marked as 'beforefieldinit'.
	static DeeplinkManager()
	{
		Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DeeplinkManager");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr);
		DeeplinkManager.NativeFieldInfoPtr_Instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "Instance");
		DeeplinkManager.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		DeeplinkManager.NativeFieldInfoPtr_OnJoinRoomIntent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "OnJoinRoomIntent");
		DeeplinkManager.NativeFieldInfoPtr_OnMainMenuLoaded = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "OnMainMenuLoaded");
		DeeplinkManager.NativeFieldInfoPtr__didProcessStartUpParameters = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_didProcessStartUpParameters");
		DeeplinkManager.NativeFieldInfoPtr__loginService = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_loginService");
		DeeplinkManager.NativeFieldInfoPtr__pendingJoinRequestActive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_pendingJoinRequestActive");
		DeeplinkManager.NativeFieldInfoPtr__pendingIdForRoomToJoin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_pendingIdForRoomToJoin");
		DeeplinkManager.NativeFieldInfoPtr__pendingPasswordForRoomToJoin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_pendingPasswordForRoomToJoin");
		DeeplinkManager.NativeFieldInfoPtr__fullyInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_fullyInitialized");
		DeeplinkManager.NativeFieldInfoPtr__initializedPlatformRequestEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_initializedPlatformRequestEvent");
		DeeplinkManager.NativeFieldInfoPtr__initializedMetaService = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, "_initializedMetaService");
		DeeplinkManager.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668191);
		DeeplinkManager.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668192);
		DeeplinkManager.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668193);
		DeeplinkManager.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668194);
		DeeplinkManager.NativeMethodInfoPtr_OnMainMenuReached_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668195);
		DeeplinkManager.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668196);
		DeeplinkManager.NativeMethodInfoPtr_Initialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668197);
		DeeplinkManager.NativeMethodInfoPtr_SteamFriendsOnOnGameRichPresenceJoinRequested_Private_Void_Friend_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668198);
		DeeplinkManager.NativeMethodInfoPtr_OnOculusJoinIntent_Private_Void_Message_1_GroupPresenceJoinIntent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668199);
		DeeplinkManager.NativeMethodInfoPtr_AcceptedDeepLinkJoinRequest_Private_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668200);
		DeeplinkManager.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668201);
		DeeplinkManager.NativeMethodInfoPtr_OnDeeplinkSuccess_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668202);
		DeeplinkManager.NativeMethodInfoPtr_OnDeeplinkFailed_Public_Void_DeeplinkFailedReason_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668203);
		DeeplinkManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr, 100668204);
	}

	// Token: 0x06003D48 RID: 15688 RVA: 0x0000210C File Offset: 0x0000030C
	public DeeplinkManager(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170015AC RID: 5548
	// (get) Token: 0x06003D49 RID: 15689 RVA: 0x000F7988 File Offset: 0x000F5B88
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DeeplinkManager>.NativeClassPtr));
		}
	}

	// Token: 0x170015AD RID: 5549
	// (get) Token: 0x06003D4A RID: 15690 RVA: 0x000F799C File Offset: 0x000F5B9C
	// (set) Token: 0x06003D4B RID: 15691 RVA: 0x000F79C7 File Offset: 0x000F5BC7
	public unsafe static DeeplinkManager Instance
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DeeplinkManager.NativeFieldInfoPtr_Instance, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DeeplinkManager(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DeeplinkManager.NativeFieldInfoPtr_Instance, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170015AE RID: 5550
	// (get) Token: 0x06003D4C RID: 15692 RVA: 0x000F79DC File Offset: 0x000F5BDC
	// (set) Token: 0x06003D4D RID: 15693 RVA: 0x000F7A04 File Offset: 0x000F5C04
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x170015AF RID: 5551
	// (get) Token: 0x06003D4E RID: 15694 RVA: 0x000F7A28 File Offset: 0x000F5C28
	// (set) Token: 0x06003D4F RID: 15695 RVA: 0x000F7A53 File Offset: 0x000F5C53
	public unsafe static Action<string, string> OnJoinRoomIntent
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DeeplinkManager.NativeFieldInfoPtr_OnJoinRoomIntent, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<string, string>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DeeplinkManager.NativeFieldInfoPtr_OnJoinRoomIntent, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170015B0 RID: 5552
	// (get) Token: 0x06003D50 RID: 15696 RVA: 0x000F7A68 File Offset: 0x000F5C68
	// (set) Token: 0x06003D51 RID: 15697 RVA: 0x000F7A93 File Offset: 0x000F5C93
	public unsafe static Action OnMainMenuLoaded
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DeeplinkManager.NativeFieldInfoPtr_OnMainMenuLoaded, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DeeplinkManager.NativeFieldInfoPtr_OnMainMenuLoaded, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170015B1 RID: 5553
	// (get) Token: 0x06003D52 RID: 15698 RVA: 0x000F7AA8 File Offset: 0x000F5CA8
	// (set) Token: 0x06003D53 RID: 15699 RVA: 0x000F7AC6 File Offset: 0x000F5CC6
	public unsafe static bool _didProcessStartUpParameters
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(DeeplinkManager.NativeFieldInfoPtr__didProcessStartUpParameters, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DeeplinkManager.NativeFieldInfoPtr__didProcessStartUpParameters, (void*)(&value));
		}
	}

	// Token: 0x170015B2 RID: 5554
	// (get) Token: 0x06003D54 RID: 15700 RVA: 0x000F7AD8 File Offset: 0x000F5CD8
	// (set) Token: 0x06003D55 RID: 15701 RVA: 0x000F7B0C File Offset: 0x000F5D0C
	public unsafe OnwardService _loginService
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__loginService);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OnwardService(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__loginService), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170015B3 RID: 5555
	// (get) Token: 0x06003D56 RID: 15702 RVA: 0x000F7B34 File Offset: 0x000F5D34
	// (set) Token: 0x06003D57 RID: 15703 RVA: 0x000F7B5C File Offset: 0x000F5D5C
	public unsafe bool _pendingJoinRequestActive
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingJoinRequestActive);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingJoinRequestActive)) = value;
		}
	}

	// Token: 0x170015B4 RID: 5556
	// (get) Token: 0x06003D58 RID: 15704 RVA: 0x000F7B80 File Offset: 0x000F5D80
	// (set) Token: 0x06003D59 RID: 15705 RVA: 0x000F7BA9 File Offset: 0x000F5DA9
	public unsafe string _pendingIdForRoomToJoin
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingIdForRoomToJoin);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingIdForRoomToJoin), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x170015B5 RID: 5557
	// (get) Token: 0x06003D5A RID: 15706 RVA: 0x000F7BD0 File Offset: 0x000F5DD0
	// (set) Token: 0x06003D5B RID: 15707 RVA: 0x000F7BF9 File Offset: 0x000F5DF9
	public unsafe string _pendingPasswordForRoomToJoin
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingPasswordForRoomToJoin);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__pendingPasswordForRoomToJoin), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x170015B6 RID: 5558
	// (get) Token: 0x06003D5C RID: 15708 RVA: 0x000F7C20 File Offset: 0x000F5E20
	// (set) Token: 0x06003D5D RID: 15709 RVA: 0x000F7C48 File Offset: 0x000F5E48
	public unsafe bool _fullyInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__fullyInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__fullyInitialized)) = value;
		}
	}

	// Token: 0x170015B7 RID: 5559
	// (get) Token: 0x06003D5E RID: 15710 RVA: 0x000F7C6C File Offset: 0x000F5E6C
	// (set) Token: 0x06003D5F RID: 15711 RVA: 0x000F7C94 File Offset: 0x000F5E94
	public unsafe bool _initializedPlatformRequestEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__initializedPlatformRequestEvent);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__initializedPlatformRequestEvent)) = value;
		}
	}

	// Token: 0x170015B8 RID: 5560
	// (get) Token: 0x06003D60 RID: 15712 RVA: 0x000F7CB8 File Offset: 0x000F5EB8
	// (set) Token: 0x06003D61 RID: 15713 RVA: 0x000F7CE0 File Offset: 0x000F5EE0
	public unsafe bool _initializedMetaService
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__initializedMetaService);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeeplinkManager.NativeFieldInfoPtr__initializedMetaService)) = value;
		}
	}

	// Token: 0x04002758 RID: 10072
	private static readonly IntPtr NativeFieldInfoPtr_Instance;

	// Token: 0x04002759 RID: 10073
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x0400275A RID: 10074
	private static readonly IntPtr NativeFieldInfoPtr_OnJoinRoomIntent;

	// Token: 0x0400275B RID: 10075
	private static readonly IntPtr NativeFieldInfoPtr_OnMainMenuLoaded;

	// Token: 0x0400275C RID: 10076
	private static readonly IntPtr NativeFieldInfoPtr__didProcessStartUpParameters;

	// Token: 0x0400275D RID: 10077
	private static readonly IntPtr NativeFieldInfoPtr__loginService;

	// Token: 0x0400275E RID: 10078
	private static readonly IntPtr NativeFieldInfoPtr__pendingJoinRequestActive;

	// Token: 0x0400275F RID: 10079
	private static readonly IntPtr NativeFieldInfoPtr__pendingIdForRoomToJoin;

	// Token: 0x04002760 RID: 10080
	private static readonly IntPtr NativeFieldInfoPtr__pendingPasswordForRoomToJoin;

	// Token: 0x04002761 RID: 10081
	private static readonly IntPtr NativeFieldInfoPtr__fullyInitialized;

	// Token: 0x04002762 RID: 10082
	private static readonly IntPtr NativeFieldInfoPtr__initializedPlatformRequestEvent;

	// Token: 0x04002763 RID: 10083
	private static readonly IntPtr NativeFieldInfoPtr__initializedMetaService;

	// Token: 0x04002764 RID: 10084
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04002765 RID: 10085
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x04002766 RID: 10086
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04002767 RID: 10087
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04002768 RID: 10088
	private static readonly IntPtr NativeMethodInfoPtr_OnMainMenuReached_Private_Void_0;

	// Token: 0x04002769 RID: 10089
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x0400276A RID: 10090
	private static readonly IntPtr NativeMethodInfoPtr_Initialize_Private_Void_0;

	// Token: 0x0400276B RID: 10091
	private static readonly IntPtr NativeMethodInfoPtr_SteamFriendsOnOnGameRichPresenceJoinRequested_Private_Void_Friend_String_0;

	// Token: 0x0400276C RID: 10092
	private static readonly IntPtr NativeMethodInfoPtr_OnOculusJoinIntent_Private_Void_Message_1_GroupPresenceJoinIntent_0;

	// Token: 0x0400276D RID: 10093
	private static readonly IntPtr NativeMethodInfoPtr_AcceptedDeepLinkJoinRequest_Private_Void_String_String_0;

	// Token: 0x0400276E RID: 10094
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x0400276F RID: 10095
	private static readonly IntPtr NativeMethodInfoPtr_OnDeeplinkSuccess_Public_Void_0;

	// Token: 0x04002770 RID: 10096
	private static readonly IntPtr NativeMethodInfoPtr_OnDeeplinkFailed_Public_Void_DeeplinkFailedReason_0;

	// Token: 0x04002771 RID: 10097
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
