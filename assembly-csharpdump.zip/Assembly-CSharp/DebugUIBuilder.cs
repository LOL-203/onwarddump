﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnhollowerRuntimeLib;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200000B RID: 11
public class DebugUIBuilder : MonoBehaviour
{
	// Token: 0x06000074 RID: 116 RVA: 0x000046E8 File Offset: 0x000028E8
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_Awake_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x0000472C File Offset: 0x0000292C
	[CallerCount(0)]
	public unsafe void Show()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_Show_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00004770 File Offset: 0x00002970
	[CallerCount(0)]
	public unsafe void Hide()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_Hide_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000047B4 File Offset: 0x000029B4
	[CallerCount(0)]
	public unsafe void StackedRelayout()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_StackedRelayout_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x000047F8 File Offset: 0x000029F8
	[CallerCount(0)]
	public unsafe void PanelCentricRelayout()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_PanelCentricRelayout_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000079 RID: 121 RVA: 0x0000483C File Offset: 0x00002A3C
	[CallerCount(0)]
	public unsafe void Relayout()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_Relayout_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00004880 File Offset: 0x00002A80
	[CallerCount(0)]
	public unsafe void AddRect(RectTransform r, int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(r);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddRect_Private_Void_RectTransform_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600007B RID: 123 RVA: 0x000048EC File Offset: 0x00002AEC
	[CallerCount(0)]
	public unsafe RectTransform AddButton(string label, [Optional] DebugUIBuilder.OnClick handler, [Optional] int buttonIndex, [Optional] int targetCanvas, bool highResolutionText = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(handler);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref buttonIndex;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref highResolutionText;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddButton_Public_RectTransform_String_OnClick_Int32_Int32_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x0600007C RID: 124 RVA: 0x000049AC File Offset: 0x00002BAC
	[CallerCount(0)]
	public unsafe RectTransform AddLabel(string label, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddLabel_Public_RectTransform_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00004A2C File Offset: 0x00002C2C
	[CallerCount(0)]
	public unsafe RectTransform AddSlider(string label, float min, float max, DebugUIBuilder.OnSlider onValueChanged, bool wholeNumbersOnly = false, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref min;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(onValueChanged);
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref wholeNumbersOnly;
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddSlider_Public_RectTransform_String_Single_Single_OnSlider_Boolean_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00004B00 File Offset: 0x00002D00
	[CallerCount(0)]
	public unsafe RectTransform AddDivider([Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddDivider_Public_RectTransform_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00004B68 File Offset: 0x00002D68
	[CallerCount(0)]
	public unsafe RectTransform AddToggle(string label, DebugUIBuilder.OnToggleValueChange onValueChanged, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(onValueChanged);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00004C00 File Offset: 0x00002E00
	[CallerCount(0)]
	public unsafe RectTransform AddToggle(string label, DebugUIBuilder.OnToggleValueChange onValueChanged, bool defaultValue, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(onValueChanged);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Boolean_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00004CAC File Offset: 0x00002EAC
	[CallerCount(0)]
	public unsafe RectTransform AddRadio(string label, string group, DebugUIBuilder.OnToggleValueChange handler, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(group);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(handler);
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddRadio_Public_RectTransform_String_String_OnToggleValueChange_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00004D5C File Offset: 0x00002F5C
	[CallerCount(0)]
	public unsafe RectTransform AddTextField(string label, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00004DDC File Offset: 0x00002FDC
	[CallerCount(0)]
	public unsafe void ToggleLaserPointer(bool isOn)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref isOn;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr_ToggleLaserPointer_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000084 RID: 132 RVA: 0x00004E30 File Offset: 0x00003030
	[CallerCount(0)]
	public unsafe DebugUIBuilder() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00004E7C File Offset: 0x0000307C
	// Note: this type is marked as 'beforefieldinit'.
	static DebugUIBuilder()
	{
		Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DebugUIBuilder");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr);
		DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_CENTER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "DEBUG_PANE_CENTER");
		DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_RIGHT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "DEBUG_PANE_RIGHT");
		DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_LEFT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "DEBUG_PANE_LEFT");
		DebugUIBuilder.NativeFieldInfoPtr_buttonPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "buttonPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_additionalButtonPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "additionalButtonPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_labelPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "labelPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_sliderPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "sliderPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_dividerPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "dividerPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_togglePrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "togglePrefab");
		DebugUIBuilder.NativeFieldInfoPtr_radioPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "radioPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_textPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "textPrefab");
		DebugUIBuilder.NativeFieldInfoPtr_uiHelpersToInstantiate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "uiHelpersToInstantiate");
		DebugUIBuilder.NativeFieldInfoPtr_targetContentPanels = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "targetContentPanels");
		DebugUIBuilder.NativeFieldInfoPtr_reEnable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "reEnable");
		DebugUIBuilder.NativeFieldInfoPtr_toEnable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "toEnable");
		DebugUIBuilder.NativeFieldInfoPtr_toDisable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "toDisable");
		DebugUIBuilder.NativeFieldInfoPtr_instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "instance");
		DebugUIBuilder.NativeFieldInfoPtr_elementSpacing = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "elementSpacing");
		DebugUIBuilder.NativeFieldInfoPtr_marginH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "marginH");
		DebugUIBuilder.NativeFieldInfoPtr_marginV = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "marginV");
		DebugUIBuilder.NativeFieldInfoPtr_insertPositions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "insertPositions");
		DebugUIBuilder.NativeFieldInfoPtr_insertedElements = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "insertedElements");
		DebugUIBuilder.NativeFieldInfoPtr_menuOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "menuOffset");
		DebugUIBuilder.NativeFieldInfoPtr_rig = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "rig");
		DebugUIBuilder.NativeFieldInfoPtr_radioGroups = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "radioGroups");
		DebugUIBuilder.NativeFieldInfoPtr_lp = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "lp");
		DebugUIBuilder.NativeFieldInfoPtr_lr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "lr");
		DebugUIBuilder.NativeFieldInfoPtr_laserBeamBehavior = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "laserBeamBehavior");
		DebugUIBuilder.NativeFieldInfoPtr_isHorizontal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "isHorizontal");
		DebugUIBuilder.NativeFieldInfoPtr_usePanelCentricRelayout = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "usePanelCentricRelayout");
		DebugUIBuilder.NativeMethodInfoPtr_Awake_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663362);
		DebugUIBuilder.NativeMethodInfoPtr_Show_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663363);
		DebugUIBuilder.NativeMethodInfoPtr_Hide_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663364);
		DebugUIBuilder.NativeMethodInfoPtr_StackedRelayout_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663365);
		DebugUIBuilder.NativeMethodInfoPtr_PanelCentricRelayout_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663366);
		DebugUIBuilder.NativeMethodInfoPtr_Relayout_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663367);
		DebugUIBuilder.NativeMethodInfoPtr_AddRect_Private_Void_RectTransform_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663368);
		DebugUIBuilder.NativeMethodInfoPtr_AddButton_Public_RectTransform_String_OnClick_Int32_Int32_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663369);
		DebugUIBuilder.NativeMethodInfoPtr_AddLabel_Public_RectTransform_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663370);
		DebugUIBuilder.NativeMethodInfoPtr_AddSlider_Public_RectTransform_String_Single_Single_OnSlider_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663371);
		DebugUIBuilder.NativeMethodInfoPtr_AddDivider_Public_RectTransform_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663372);
		DebugUIBuilder.NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663373);
		DebugUIBuilder.NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663374);
		DebugUIBuilder.NativeMethodInfoPtr_AddRadio_Public_RectTransform_String_String_OnToggleValueChange_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663375);
		DebugUIBuilder.NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663376);
		DebugUIBuilder.NativeMethodInfoPtr_ToggleLaserPointer_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663377);
		DebugUIBuilder.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, 100663378);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x0000210C File Offset: 0x0000030C
	public DebugUIBuilder(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000087 RID: 135 RVA: 0x00005258 File Offset: 0x00003458
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr));
		}
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000088 RID: 136 RVA: 0x0000526C File Offset: 0x0000346C
	// (set) Token: 0x06000089 RID: 137 RVA: 0x0000528A File Offset: 0x0000348A
	public unsafe static int DEBUG_PANE_CENTER
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_CENTER, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_CENTER, (void*)(&value));
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x0600008A RID: 138 RVA: 0x0000529C File Offset: 0x0000349C
	// (set) Token: 0x0600008B RID: 139 RVA: 0x000052BA File Offset: 0x000034BA
	public unsafe static int DEBUG_PANE_RIGHT
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_RIGHT, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_RIGHT, (void*)(&value));
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600008C RID: 140 RVA: 0x000052CC File Offset: 0x000034CC
	// (set) Token: 0x0600008D RID: 141 RVA: 0x000052EA File Offset: 0x000034EA
	public unsafe static int DEBUG_PANE_LEFT
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_LEFT, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugUIBuilder.NativeFieldInfoPtr_DEBUG_PANE_LEFT, (void*)(&value));
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600008E RID: 142 RVA: 0x000052FC File Offset: 0x000034FC
	// (set) Token: 0x0600008F RID: 143 RVA: 0x00005330 File Offset: 0x00003530
	public unsafe RectTransform buttonPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_buttonPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_buttonPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000090 RID: 144 RVA: 0x00005358 File Offset: 0x00003558
	// (set) Token: 0x06000091 RID: 145 RVA: 0x0000538C File Offset: 0x0000358C
	public unsafe Il2CppReferenceArray<RectTransform> additionalButtonPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_additionalButtonPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<RectTransform>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_additionalButtonPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000092 RID: 146 RVA: 0x000053B4 File Offset: 0x000035B4
	// (set) Token: 0x06000093 RID: 147 RVA: 0x000053E8 File Offset: 0x000035E8
	public unsafe RectTransform labelPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_labelPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_labelPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000094 RID: 148 RVA: 0x00005410 File Offset: 0x00003610
	// (set) Token: 0x06000095 RID: 149 RVA: 0x00005444 File Offset: 0x00003644
	public unsafe RectTransform sliderPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_sliderPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_sliderPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000096 RID: 150 RVA: 0x0000546C File Offset: 0x0000366C
	// (set) Token: 0x06000097 RID: 151 RVA: 0x000054A0 File Offset: 0x000036A0
	public unsafe RectTransform dividerPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_dividerPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_dividerPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000098 RID: 152 RVA: 0x000054C8 File Offset: 0x000036C8
	// (set) Token: 0x06000099 RID: 153 RVA: 0x000054FC File Offset: 0x000036FC
	public unsafe RectTransform togglePrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_togglePrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_togglePrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x0600009A RID: 154 RVA: 0x00005524 File Offset: 0x00003724
	// (set) Token: 0x0600009B RID: 155 RVA: 0x00005558 File Offset: 0x00003758
	public unsafe RectTransform radioPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_radioPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_radioPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x0600009C RID: 156 RVA: 0x00005580 File Offset: 0x00003780
	// (set) Token: 0x0600009D RID: 157 RVA: 0x000055B4 File Offset: 0x000037B4
	public unsafe RectTransform textPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_textPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_textPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600009E RID: 158 RVA: 0x000055DC File Offset: 0x000037DC
	// (set) Token: 0x0600009F RID: 159 RVA: 0x00005610 File Offset: 0x00003810
	public unsafe GameObject uiHelpersToInstantiate
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_uiHelpersToInstantiate);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_uiHelpersToInstantiate), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x060000A0 RID: 160 RVA: 0x00005638 File Offset: 0x00003838
	// (set) Token: 0x060000A1 RID: 161 RVA: 0x0000566C File Offset: 0x0000386C
	public unsafe Il2CppReferenceArray<Transform> targetContentPanels
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_targetContentPanels);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Transform>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_targetContentPanels), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x060000A2 RID: 162 RVA: 0x00005694 File Offset: 0x00003894
	// (set) Token: 0x060000A3 RID: 163 RVA: 0x000056C8 File Offset: 0x000038C8
	public unsafe Il2CppStructArray<bool> reEnable
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_reEnable);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<bool>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_reEnable), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x060000A4 RID: 164 RVA: 0x000056F0 File Offset: 0x000038F0
	// (set) Token: 0x060000A5 RID: 165 RVA: 0x00005724 File Offset: 0x00003924
	public unsafe List<GameObject> toEnable
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_toEnable);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_toEnable), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x060000A6 RID: 166 RVA: 0x0000574C File Offset: 0x0000394C
	// (set) Token: 0x060000A7 RID: 167 RVA: 0x00005780 File Offset: 0x00003980
	public unsafe List<GameObject> toDisable
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_toDisable);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_toDisable), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x060000A8 RID: 168 RVA: 0x000057A8 File Offset: 0x000039A8
	// (set) Token: 0x060000A9 RID: 169 RVA: 0x000057D3 File Offset: 0x000039D3
	public unsafe static DebugUIBuilder instance
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DebugUIBuilder.NativeFieldInfoPtr_instance, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DebugUIBuilder(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugUIBuilder.NativeFieldInfoPtr_instance, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x060000AA RID: 170 RVA: 0x000057E8 File Offset: 0x000039E8
	// (set) Token: 0x060000AB RID: 171 RVA: 0x00005810 File Offset: 0x00003A10
	public unsafe float elementSpacing
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_elementSpacing);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_elementSpacing)) = value;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x060000AC RID: 172 RVA: 0x00005834 File Offset: 0x00003A34
	// (set) Token: 0x060000AD RID: 173 RVA: 0x0000585C File Offset: 0x00003A5C
	public unsafe float marginH
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_marginH);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_marginH)) = value;
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x060000AE RID: 174 RVA: 0x00005880 File Offset: 0x00003A80
	// (set) Token: 0x060000AF RID: 175 RVA: 0x000058A8 File Offset: 0x00003AA8
	public unsafe float marginV
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_marginV);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_marginV)) = value;
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x060000B0 RID: 176 RVA: 0x000058CC File Offset: 0x00003ACC
	// (set) Token: 0x060000B1 RID: 177 RVA: 0x00005900 File Offset: 0x00003B00
	public unsafe Il2CppStructArray<Vector2> insertPositions
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_insertPositions);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_insertPositions), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x060000B2 RID: 178 RVA: 0x00005928 File Offset: 0x00003B28
	// (set) Token: 0x060000B3 RID: 179 RVA: 0x0000595C File Offset: 0x00003B5C
	public unsafe Il2CppReferenceArray<List<RectTransform>> insertedElements
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_insertedElements);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<List<RectTransform>>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_insertedElements), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x060000B4 RID: 180 RVA: 0x00005984 File Offset: 0x00003B84
	// (set) Token: 0x060000B5 RID: 181 RVA: 0x000059AC File Offset: 0x00003BAC
	public unsafe Vector3 menuOffset
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_menuOffset);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_menuOffset)) = value;
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x060000B6 RID: 182 RVA: 0x000059D0 File Offset: 0x00003BD0
	// (set) Token: 0x060000B7 RID: 183 RVA: 0x00005A04 File Offset: 0x00003C04
	public unsafe OVRCameraRig rig
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_rig);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OVRCameraRig(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_rig), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x060000B8 RID: 184 RVA: 0x00005A2C File Offset: 0x00003C2C
	// (set) Token: 0x060000B9 RID: 185 RVA: 0x00005A60 File Offset: 0x00003C60
	public unsafe Dictionary<string, ToggleGroup> radioGroups
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_radioGroups);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<string, ToggleGroup>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_radioGroups), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x060000BA RID: 186 RVA: 0x00005A88 File Offset: 0x00003C88
	// (set) Token: 0x060000BB RID: 187 RVA: 0x00005ABC File Offset: 0x00003CBC
	public unsafe LaserPointer lp
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_lp);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LaserPointer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_lp), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x060000BC RID: 188 RVA: 0x00005AE4 File Offset: 0x00003CE4
	// (set) Token: 0x060000BD RID: 189 RVA: 0x00005B18 File Offset: 0x00003D18
	public unsafe LineRenderer lr
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_lr);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LineRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_lr), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x060000BE RID: 190 RVA: 0x00005B40 File Offset: 0x00003D40
	// (set) Token: 0x060000BF RID: 191 RVA: 0x00005B68 File Offset: 0x00003D68
	public unsafe LaserPointer.LaserBeamBehavior laserBeamBehavior
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_laserBeamBehavior);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_laserBeamBehavior)) = value;
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x060000C0 RID: 192 RVA: 0x00005B8C File Offset: 0x00003D8C
	// (set) Token: 0x060000C1 RID: 193 RVA: 0x00005BB4 File Offset: 0x00003DB4
	public unsafe bool isHorizontal
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_isHorizontal);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_isHorizontal)) = value;
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x060000C2 RID: 194 RVA: 0x00005BD8 File Offset: 0x00003DD8
	// (set) Token: 0x060000C3 RID: 195 RVA: 0x00005C00 File Offset: 0x00003E00
	public unsafe bool usePanelCentricRelayout
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_usePanelCentricRelayout);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.NativeFieldInfoPtr_usePanelCentricRelayout)) = value;
		}
	}

	// Token: 0x0400004D RID: 77
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_PANE_CENTER;

	// Token: 0x0400004E RID: 78
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_PANE_RIGHT;

	// Token: 0x0400004F RID: 79
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_PANE_LEFT;

	// Token: 0x04000050 RID: 80
	private static readonly IntPtr NativeFieldInfoPtr_buttonPrefab;

	// Token: 0x04000051 RID: 81
	private static readonly IntPtr NativeFieldInfoPtr_additionalButtonPrefab;

	// Token: 0x04000052 RID: 82
	private static readonly IntPtr NativeFieldInfoPtr_labelPrefab;

	// Token: 0x04000053 RID: 83
	private static readonly IntPtr NativeFieldInfoPtr_sliderPrefab;

	// Token: 0x04000054 RID: 84
	private static readonly IntPtr NativeFieldInfoPtr_dividerPrefab;

	// Token: 0x04000055 RID: 85
	private static readonly IntPtr NativeFieldInfoPtr_togglePrefab;

	// Token: 0x04000056 RID: 86
	private static readonly IntPtr NativeFieldInfoPtr_radioPrefab;

	// Token: 0x04000057 RID: 87
	private static readonly IntPtr NativeFieldInfoPtr_textPrefab;

	// Token: 0x04000058 RID: 88
	private static readonly IntPtr NativeFieldInfoPtr_uiHelpersToInstantiate;

	// Token: 0x04000059 RID: 89
	private static readonly IntPtr NativeFieldInfoPtr_targetContentPanels;

	// Token: 0x0400005A RID: 90
	private static readonly IntPtr NativeFieldInfoPtr_reEnable;

	// Token: 0x0400005B RID: 91
	private static readonly IntPtr NativeFieldInfoPtr_toEnable;

	// Token: 0x0400005C RID: 92
	private static readonly IntPtr NativeFieldInfoPtr_toDisable;

	// Token: 0x0400005D RID: 93
	private static readonly IntPtr NativeFieldInfoPtr_instance;

	// Token: 0x0400005E RID: 94
	private static readonly IntPtr NativeFieldInfoPtr_elementSpacing;

	// Token: 0x0400005F RID: 95
	private static readonly IntPtr NativeFieldInfoPtr_marginH;

	// Token: 0x04000060 RID: 96
	private static readonly IntPtr NativeFieldInfoPtr_marginV;

	// Token: 0x04000061 RID: 97
	private static readonly IntPtr NativeFieldInfoPtr_insertPositions;

	// Token: 0x04000062 RID: 98
	private static readonly IntPtr NativeFieldInfoPtr_insertedElements;

	// Token: 0x04000063 RID: 99
	private static readonly IntPtr NativeFieldInfoPtr_menuOffset;

	// Token: 0x04000064 RID: 100
	private static readonly IntPtr NativeFieldInfoPtr_rig;

	// Token: 0x04000065 RID: 101
	private static readonly IntPtr NativeFieldInfoPtr_radioGroups;

	// Token: 0x04000066 RID: 102
	private static readonly IntPtr NativeFieldInfoPtr_lp;

	// Token: 0x04000067 RID: 103
	private static readonly IntPtr NativeFieldInfoPtr_lr;

	// Token: 0x04000068 RID: 104
	private static readonly IntPtr NativeFieldInfoPtr_laserBeamBehavior;

	// Token: 0x04000069 RID: 105
	private static readonly IntPtr NativeFieldInfoPtr_isHorizontal;

	// Token: 0x0400006A RID: 106
	private static readonly IntPtr NativeFieldInfoPtr_usePanelCentricRelayout;

	// Token: 0x0400006B RID: 107
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Public_Void_0;

	// Token: 0x0400006C RID: 108
	private static readonly IntPtr NativeMethodInfoPtr_Show_Public_Void_0;

	// Token: 0x0400006D RID: 109
	private static readonly IntPtr NativeMethodInfoPtr_Hide_Public_Void_0;

	// Token: 0x0400006E RID: 110
	private static readonly IntPtr NativeMethodInfoPtr_StackedRelayout_Private_Void_0;

	// Token: 0x0400006F RID: 111
	private static readonly IntPtr NativeMethodInfoPtr_PanelCentricRelayout_Private_Void_0;

	// Token: 0x04000070 RID: 112
	private static readonly IntPtr NativeMethodInfoPtr_Relayout_Private_Void_0;

	// Token: 0x04000071 RID: 113
	private static readonly IntPtr NativeMethodInfoPtr_AddRect_Private_Void_RectTransform_Int32_0;

	// Token: 0x04000072 RID: 114
	private static readonly IntPtr NativeMethodInfoPtr_AddButton_Public_RectTransform_String_OnClick_Int32_Int32_Boolean_0;

	// Token: 0x04000073 RID: 115
	private static readonly IntPtr NativeMethodInfoPtr_AddLabel_Public_RectTransform_String_Int32_0;

	// Token: 0x04000074 RID: 116
	private static readonly IntPtr NativeMethodInfoPtr_AddSlider_Public_RectTransform_String_Single_Single_OnSlider_Boolean_Int32_0;

	// Token: 0x04000075 RID: 117
	private static readonly IntPtr NativeMethodInfoPtr_AddDivider_Public_RectTransform_Int32_0;

	// Token: 0x04000076 RID: 118
	private static readonly IntPtr NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Int32_0;

	// Token: 0x04000077 RID: 119
	private static readonly IntPtr NativeMethodInfoPtr_AddToggle_Public_RectTransform_String_OnToggleValueChange_Boolean_Int32_0;

	// Token: 0x04000078 RID: 120
	private static readonly IntPtr NativeMethodInfoPtr_AddRadio_Public_RectTransform_String_String_OnToggleValueChange_Int32_0;

	// Token: 0x04000079 RID: 121
	private static readonly IntPtr NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0;

	// Token: 0x0400007A RID: 122
	private static readonly IntPtr NativeMethodInfoPtr_ToggleLaserPointer_Public_Void_Boolean_0;

	// Token: 0x0400007B RID: 123
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200000C RID: 12
	public sealed class OnClick : MulticastDelegate
	{
		// Token: 0x060000C4 RID: 196 RVA: 0x00005C24 File Offset: 0x00003E24
		[CallerCount(0)]
		public unsafe OnClick(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnClick.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x00005C9C File Offset: 0x00003E9C
		[CallerCount(0)]
		public unsafe void Invoke()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnClick.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x00005CE0 File Offset: 0x00003EE0
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnClick.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x00005D68 File Offset: 0x00003F68
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnClick.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00005DC4 File Offset: 0x00003FC4
		// Note: this type is marked as 'beforefieldinit'.
		static OnClick()
		{
			Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "OnClick");
			DebugUIBuilder.OnClick.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr, 100663379);
			DebugUIBuilder.OnClick.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr, 100663380);
			DebugUIBuilder.OnClick.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr, 100663381);
			DebugUIBuilder.OnClick.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr, 100663382);
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00005E35 File Offset: 0x00004035
		public OnClick(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000CA RID: 202 RVA: 0x00005E3E File Offset: 0x0000403E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.OnClick>.NativeClassPtr));
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00005E4F File Offset: 0x0000404F
		public static implicit operator DebugUIBuilder.OnClick(Action A_0)
		{
			return DelegateSupport.ConvertDelegate<DebugUIBuilder.OnClick>(A_0);
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00005E57 File Offset: 0x00004057
		public static DebugUIBuilder.OnClick operator +(DebugUIBuilder.OnClick A_0, DebugUIBuilder.OnClick A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DebugUIBuilder.OnClick>();
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00005E65 File Offset: 0x00004065
		public static DebugUIBuilder.OnClick operator -(DebugUIBuilder.OnClick A_0, DebugUIBuilder.OnClick A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DebugUIBuilder.OnClick>();
			}
			return result;
		}

		// Token: 0x0400007C RID: 124
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x0400007D RID: 125
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_0;

		// Token: 0x0400007E RID: 126
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0;

		// Token: 0x0400007F RID: 127
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x0200000D RID: 13
	public sealed class OnToggleValueChange : MulticastDelegate
	{
		// Token: 0x060000CE RID: 206 RVA: 0x00005E78 File Offset: 0x00004078
		[CallerCount(0)]
		public unsafe OnToggleValueChange(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00005EF0 File Offset: 0x000040F0
		[CallerCount(0)]
		public unsafe void Invoke(Toggle t)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Toggle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00005F4C File Offset: 0x0000414C
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(Toggle t, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Toggle_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00005FEC File Offset: 0x000041EC
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00006048 File Offset: 0x00004248
		// Note: this type is marked as 'beforefieldinit'.
		static OnToggleValueChange()
		{
			Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "OnToggleValueChange");
			DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr, 100663383);
			DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Toggle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr, 100663384);
			DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Toggle_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr, 100663385);
			DebugUIBuilder.OnToggleValueChange.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr, 100663386);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00005E35 File Offset: 0x00004035
		public OnToggleValueChange(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000D4 RID: 212 RVA: 0x000060B9 File Offset: 0x000042B9
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.OnToggleValueChange>.NativeClassPtr));
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x000060CA File Offset: 0x000042CA
		public static implicit operator DebugUIBuilder.OnToggleValueChange(Action<Toggle> A_0)
		{
			return DelegateSupport.ConvertDelegate<DebugUIBuilder.OnToggleValueChange>(A_0);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x000060D2 File Offset: 0x000042D2
		public static DebugUIBuilder.OnToggleValueChange operator +(DebugUIBuilder.OnToggleValueChange A_0, DebugUIBuilder.OnToggleValueChange A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DebugUIBuilder.OnToggleValueChange>();
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x000060E0 File Offset: 0x000042E0
		public static DebugUIBuilder.OnToggleValueChange operator -(DebugUIBuilder.OnToggleValueChange A_0, DebugUIBuilder.OnToggleValueChange A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DebugUIBuilder.OnToggleValueChange>();
			}
			return result;
		}

		// Token: 0x04000080 RID: 128
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x04000081 RID: 129
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Toggle_0;

		// Token: 0x04000082 RID: 130
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Toggle_AsyncCallback_Object_0;

		// Token: 0x04000083 RID: 131
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x0200000E RID: 14
	public sealed class OnSlider : MulticastDelegate
	{
		// Token: 0x060000D8 RID: 216 RVA: 0x000060F4 File Offset: 0x000042F4
		[CallerCount(0)]
		public unsafe OnSlider(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnSlider.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000616C File Offset: 0x0000436C
		[CallerCount(0)]
		public unsafe void Invoke(float f)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref f;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnSlider.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x000061C0 File Offset: 0x000043C0
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(float f, AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref f;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnSlider.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00006258 File Offset: 0x00004458
		[CallerCount(0)]
		public unsafe void EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.OnSlider.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x000062B4 File Offset: 0x000044B4
		// Note: this type is marked as 'beforefieldinit'.
		static OnSlider()
		{
			Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "OnSlider");
			DebugUIBuilder.OnSlider.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr, 100663387);
			DebugUIBuilder.OnSlider.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr, 100663388);
			DebugUIBuilder.OnSlider.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr, 100663389);
			DebugUIBuilder.OnSlider.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr, 100663390);
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00005E35 File Offset: 0x00004035
		public OnSlider(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060000DE RID: 222 RVA: 0x00006325 File Offset: 0x00004525
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.OnSlider>.NativeClassPtr));
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00006336 File Offset: 0x00004536
		public static implicit operator DebugUIBuilder.OnSlider(Action<float> A_0)
		{
			return DelegateSupport.ConvertDelegate<DebugUIBuilder.OnSlider>(A_0);
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000633E File Offset: 0x0000453E
		public static DebugUIBuilder.OnSlider operator +(DebugUIBuilder.OnSlider A_0, DebugUIBuilder.OnSlider A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DebugUIBuilder.OnSlider>();
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0000634C File Offset: 0x0000454C
		public static DebugUIBuilder.OnSlider operator -(DebugUIBuilder.OnSlider A_0, DebugUIBuilder.OnSlider A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DebugUIBuilder.OnSlider>();
			}
			return result;
		}

		// Token: 0x04000084 RID: 132
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x04000085 RID: 133
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Void_Single_0;

		// Token: 0x04000086 RID: 134
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_Single_AsyncCallback_Object_0;

		// Token: 0x04000087 RID: 135
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Void_IAsyncResult_0;
	}

	// Token: 0x0200000F RID: 15
	public sealed class ActiveUpdate : MulticastDelegate
	{
		// Token: 0x060000E2 RID: 226 RVA: 0x00006360 File Offset: 0x00004560
		[CallerCount(0)]
		public unsafe ActiveUpdate(Il2CppSystem.Object @object, IntPtr method) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(@object);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref method;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x000063D8 File Offset: 0x000045D8
		[CallerCount(0)]
		public unsafe bool Invoke()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00006428 File Offset: 0x00004628
		[CallerCount(0)]
		public unsafe IAsyncResult BeginInvoke(AsyncCallback callback, Il2CppSystem.Object @object)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(@object);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IAsyncResult(intPtr2) : null;
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x000064B0 File Offset: 0x000046B0
		[CallerCount(0)]
		public unsafe bool EndInvoke(IAsyncResult result)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(result);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Boolean_IAsyncResult_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x00006518 File Offset: 0x00004718
		// Note: this type is marked as 'beforefieldinit'.
		static ActiveUpdate()
		{
			Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "ActiveUpdate");
			DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr, 100663391);
			DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_Invoke_Public_Virtual_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr, 100663392);
			DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr, 100663393);
			DebugUIBuilder.ActiveUpdate.NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Boolean_IAsyncResult_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr, 100663394);
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x00005E35 File Offset: 0x00004035
		public ActiveUpdate(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x00006589 File Offset: 0x00004789
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.ActiveUpdate>.NativeClassPtr));
			}
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000659A File Offset: 0x0000479A
		public static implicit operator DebugUIBuilder.ActiveUpdate(Func<bool> A_0)
		{
			return DelegateSupport.ConvertDelegate<DebugUIBuilder.ActiveUpdate>(A_0);
		}

		// Token: 0x060000EA RID: 234 RVA: 0x000065A2 File Offset: 0x000047A2
		public static DebugUIBuilder.ActiveUpdate operator +(DebugUIBuilder.ActiveUpdate A_0, DebugUIBuilder.ActiveUpdate A_1)
		{
			return Delegate.Combine(A_0, A_1).Cast<DebugUIBuilder.ActiveUpdate>();
		}

		// Token: 0x060000EB RID: 235 RVA: 0x000065B0 File Offset: 0x000047B0
		public static DebugUIBuilder.ActiveUpdate operator -(DebugUIBuilder.ActiveUpdate A_0, DebugUIBuilder.ActiveUpdate A_1)
		{
			Delegate result;
			Delegate @delegate = result = Delegate.Remove(A_0, A_1);
			if (@delegate != null)
			{
				result = @delegate.Cast<DebugUIBuilder.ActiveUpdate>();
			}
			return result;
		}

		// Token: 0x04000088 RID: 136
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Object_IntPtr_0;

		// Token: 0x04000089 RID: 137
		private static readonly IntPtr NativeMethodInfoPtr_Invoke_Public_Virtual_New_Boolean_0;

		// Token: 0x0400008A RID: 138
		private static readonly IntPtr NativeMethodInfoPtr_BeginInvoke_Public_Virtual_New_IAsyncResult_AsyncCallback_Object_0;

		// Token: 0x0400008B RID: 139
		private static readonly IntPtr NativeMethodInfoPtr_EndInvoke_Public_Virtual_New_Boolean_IAsyncResult_0;
	}

	// Token: 0x02000010 RID: 16
	[ObfuscatedName("DebugUIBuilder/<>c__DisplayClass41_0")]
	public sealed class __c__DisplayClass41_0 : Il2CppSystem.Object
	{
		// Token: 0x060000EC RID: 236 RVA: 0x000065C4 File Offset: 0x000047C4
		[CallerCount(0)]
		public unsafe __c__DisplayClass41_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass41_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000ED RID: 237 RVA: 0x00006610 File Offset: 0x00004810
		[CallerCount(0)]
		public unsafe void _AddButton_b__0()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass41_0.NativeMethodInfoPtr__AddButton_b__0_Internal_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000EE RID: 238 RVA: 0x00006654 File Offset: 0x00004854
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass41_0()
		{
			Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "<>c__DisplayClass41_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr);
			DebugUIBuilder.__c__DisplayClass41_0.NativeFieldInfoPtr_handler = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr, "handler");
			DebugUIBuilder.__c__DisplayClass41_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr, 100663395);
			DebugUIBuilder.__c__DisplayClass41_0.NativeMethodInfoPtr__AddButton_b__0_Internal_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr, 100663396);
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass41_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x000066BB File Offset: 0x000048BB
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass41_0>.NativeClassPtr));
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060000F1 RID: 241 RVA: 0x000066CC File Offset: 0x000048CC
		// (set) Token: 0x060000F2 RID: 242 RVA: 0x00006700 File Offset: 0x00004900
		public unsafe DebugUIBuilder.OnClick handler
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass41_0.NativeFieldInfoPtr_handler);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DebugUIBuilder.OnClick(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass41_0.NativeFieldInfoPtr_handler), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400008C RID: 140
		private static readonly IntPtr NativeFieldInfoPtr_handler;

		// Token: 0x0400008D RID: 141
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0400008E RID: 142
		private static readonly IntPtr NativeMethodInfoPtr__AddButton_b__0_Internal_Void_0;
	}

	// Token: 0x02000011 RID: 17
	[ObfuscatedName("DebugUIBuilder/<>c__DisplayClass43_0")]
	public sealed class __c__DisplayClass43_0 : Il2CppSystem.Object
	{
		// Token: 0x060000F3 RID: 243 RVA: 0x00006728 File Offset: 0x00004928
		[CallerCount(0)]
		public unsafe __c__DisplayClass43_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass43_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00006774 File Offset: 0x00004974
		[CallerCount(0)]
		public unsafe void _AddSlider_b__0(float f)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref f;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass43_0.NativeMethodInfoPtr__AddSlider_b__0_Internal_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x000067C8 File Offset: 0x000049C8
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass43_0()
		{
			Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "<>c__DisplayClass43_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr);
			DebugUIBuilder.__c__DisplayClass43_0.NativeFieldInfoPtr_onValueChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr, "onValueChanged");
			DebugUIBuilder.__c__DisplayClass43_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr, 100663397);
			DebugUIBuilder.__c__DisplayClass43_0.NativeMethodInfoPtr__AddSlider_b__0_Internal_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr, 100663398);
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass43_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x0000682F File Offset: 0x00004A2F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass43_0>.NativeClassPtr));
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x00006840 File Offset: 0x00004A40
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x00006874 File Offset: 0x00004A74
		public unsafe DebugUIBuilder.OnSlider onValueChanged
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass43_0.NativeFieldInfoPtr_onValueChanged);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DebugUIBuilder.OnSlider(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass43_0.NativeFieldInfoPtr_onValueChanged), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400008F RID: 143
		private static readonly IntPtr NativeFieldInfoPtr_onValueChanged;

		// Token: 0x04000090 RID: 144
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04000091 RID: 145
		private static readonly IntPtr NativeMethodInfoPtr__AddSlider_b__0_Internal_Void_Single_0;
	}

	// Token: 0x02000012 RID: 18
	[ObfuscatedName("DebugUIBuilder/<>c__DisplayClass45_0")]
	public sealed class __c__DisplayClass45_0 : Il2CppSystem.Object
	{
		// Token: 0x060000FA RID: 250 RVA: 0x0000689C File Offset: 0x00004A9C
		[CallerCount(0)]
		public unsafe __c__DisplayClass45_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass45_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000FB RID: 251 RVA: 0x000068E8 File Offset: 0x00004AE8
		[CallerCount(0)]
		public unsafe void _AddToggle_b__0(bool <p0>)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <p0>;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass45_0.NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000FC RID: 252 RVA: 0x0000693C File Offset: 0x00004B3C
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass45_0()
		{
			Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "<>c__DisplayClass45_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr);
			DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_onValueChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr, "onValueChanged");
			DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_t = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr, "t");
			DebugUIBuilder.__c__DisplayClass45_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr, 100663399);
			DebugUIBuilder.__c__DisplayClass45_0.NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr, 100663400);
		}

		// Token: 0x060000FD RID: 253 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass45_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060000FE RID: 254 RVA: 0x000069B7 File Offset: 0x00004BB7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass45_0>.NativeClassPtr));
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060000FF RID: 255 RVA: 0x000069C8 File Offset: 0x00004BC8
		// (set) Token: 0x06000100 RID: 256 RVA: 0x000069FC File Offset: 0x00004BFC
		public unsafe DebugUIBuilder.OnToggleValueChange onValueChanged
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_onValueChanged);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DebugUIBuilder.OnToggleValueChange(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_onValueChanged), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000101 RID: 257 RVA: 0x00006A24 File Offset: 0x00004C24
		// (set) Token: 0x06000102 RID: 258 RVA: 0x00006A58 File Offset: 0x00004C58
		public unsafe Toggle t
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_t);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Toggle(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass45_0.NativeFieldInfoPtr_t), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000092 RID: 146
		private static readonly IntPtr NativeFieldInfoPtr_onValueChanged;

		// Token: 0x04000093 RID: 147
		private static readonly IntPtr NativeFieldInfoPtr_t;

		// Token: 0x04000094 RID: 148
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04000095 RID: 149
		private static readonly IntPtr NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0;
	}

	// Token: 0x02000013 RID: 19
	[ObfuscatedName("DebugUIBuilder/<>c__DisplayClass46_0")]
	public sealed class __c__DisplayClass46_0 : Il2CppSystem.Object
	{
		// Token: 0x06000103 RID: 259 RVA: 0x00006A80 File Offset: 0x00004C80
		[CallerCount(0)]
		public unsafe __c__DisplayClass46_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass46_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000104 RID: 260 RVA: 0x00006ACC File Offset: 0x00004CCC
		[CallerCount(0)]
		public unsafe void _AddToggle_b__0(bool <p0>)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <p0>;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass46_0.NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000105 RID: 261 RVA: 0x00006B20 File Offset: 0x00004D20
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass46_0()
		{
			Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "<>c__DisplayClass46_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr);
			DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_onValueChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr, "onValueChanged");
			DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_t = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr, "t");
			DebugUIBuilder.__c__DisplayClass46_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr, 100663401);
			DebugUIBuilder.__c__DisplayClass46_0.NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr, 100663402);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass46_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000107 RID: 263 RVA: 0x00006B9B File Offset: 0x00004D9B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass46_0>.NativeClassPtr));
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000108 RID: 264 RVA: 0x00006BAC File Offset: 0x00004DAC
		// (set) Token: 0x06000109 RID: 265 RVA: 0x00006BE0 File Offset: 0x00004DE0
		public unsafe DebugUIBuilder.OnToggleValueChange onValueChanged
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_onValueChanged);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DebugUIBuilder.OnToggleValueChange(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_onValueChanged), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600010A RID: 266 RVA: 0x00006C08 File Offset: 0x00004E08
		// (set) Token: 0x0600010B RID: 267 RVA: 0x00006C3C File Offset: 0x00004E3C
		public unsafe Toggle t
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_t);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Toggle(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass46_0.NativeFieldInfoPtr_t), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000096 RID: 150
		private static readonly IntPtr NativeFieldInfoPtr_onValueChanged;

		// Token: 0x04000097 RID: 151
		private static readonly IntPtr NativeFieldInfoPtr_t;

		// Token: 0x04000098 RID: 152
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04000099 RID: 153
		private static readonly IntPtr NativeMethodInfoPtr__AddToggle_b__0_Internal_Void_Boolean_0;
	}

	// Token: 0x02000014 RID: 20
	[ObfuscatedName("DebugUIBuilder/<>c__DisplayClass47_0")]
	public sealed class __c__DisplayClass47_0 : Il2CppSystem.Object
	{
		// Token: 0x0600010C RID: 268 RVA: 0x00006C64 File Offset: 0x00004E64
		[CallerCount(0)]
		public unsafe __c__DisplayClass47_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass47_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00006CB0 File Offset: 0x00004EB0
		[CallerCount(0)]
		public unsafe void _AddRadio_b__0(bool <p0>)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <p0>;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugUIBuilder.__c__DisplayClass47_0.NativeMethodInfoPtr__AddRadio_b__0_Internal_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600010E RID: 270 RVA: 0x00006D04 File Offset: 0x00004F04
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass47_0()
		{
			Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DebugUIBuilder>.NativeClassPtr, "<>c__DisplayClass47_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr);
			DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_handler = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr, "handler");
			DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_tb = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr, "tb");
			DebugUIBuilder.__c__DisplayClass47_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr, 100663403);
			DebugUIBuilder.__c__DisplayClass47_0.NativeMethodInfoPtr__AddRadio_b__0_Internal_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr, 100663404);
		}

		// Token: 0x0600010F RID: 271 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass47_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x06000110 RID: 272 RVA: 0x00006D7F File Offset: 0x00004F7F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugUIBuilder.__c__DisplayClass47_0>.NativeClassPtr));
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000111 RID: 273 RVA: 0x00006D90 File Offset: 0x00004F90
		// (set) Token: 0x06000112 RID: 274 RVA: 0x00006DC4 File Offset: 0x00004FC4
		public unsafe DebugUIBuilder.OnToggleValueChange handler
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_handler);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DebugUIBuilder.OnToggleValueChange(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_handler), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000113 RID: 275 RVA: 0x00006DEC File Offset: 0x00004FEC
		// (set) Token: 0x06000114 RID: 276 RVA: 0x00006E20 File Offset: 0x00005020
		public unsafe Toggle tb
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_tb);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Toggle(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DebugUIBuilder.__c__DisplayClass47_0.NativeFieldInfoPtr_tb), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400009A RID: 154
		private static readonly IntPtr NativeFieldInfoPtr_handler;

		// Token: 0x0400009B RID: 155
		private static readonly IntPtr NativeFieldInfoPtr_tb;

		// Token: 0x0400009C RID: 156
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0400009D RID: 157
		private static readonly IntPtr NativeMethodInfoPtr__AddRadio_b__0_Internal_Void_Boolean_0;
	}
}
