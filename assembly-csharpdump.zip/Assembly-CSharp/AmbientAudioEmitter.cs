﻿using System;
using AK.Wwise;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200012E RID: 302
public class AmbientAudioEmitter : MonoBehaviour
{
	// Token: 0x17000681 RID: 1665
	// (get) Token: 0x06001304 RID: 4868 RVA: 0x0004D10C File Offset: 0x0004B30C
	// (set) Token: 0x06001305 RID: 4869 RVA: 0x0004D15C File Offset: 0x0004B35C
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06001306 RID: 4870 RVA: 0x0004D1B0 File Offset: 0x0004B3B0
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001307 RID: 4871 RVA: 0x0004D1F4 File Offset: 0x0004B3F4
	[CallerCount(0)]
	public unsafe void SetFrameCounterStart()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_SetFrameCounterStart_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001308 RID: 4872 RVA: 0x0004D238 File Offset: 0x0004B438
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001309 RID: 4873 RVA: 0x0004D27C File Offset: 0x0004B47C
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130A RID: 4874 RVA: 0x0004D2C0 File Offset: 0x0004B4C0
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130B RID: 4875 RVA: 0x0004D304 File Offset: 0x0004B504
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130C RID: 4876 RVA: 0x0004D348 File Offset: 0x0004B548
	[CallerCount(0)]
	public unsafe void OnListenerReverbZoneChanged(AudioManager.ReverbBusType obj)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref obj;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnListenerReverbZoneChanged_Private_Void_ReverbBusType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130D RID: 4877 RVA: 0x0004D39C File Offset: 0x0004B59C
	[CallerCount(0)]
	public unsafe void OnListenerMuffleZoneChanged(int obj)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref obj;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_OnListenerMuffleZoneChanged_Private_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130E RID: 4878 RVA: 0x0004D3F0 File Offset: 0x0004B5F0
	[CallerCount(0)]
	public unsafe void StartUpdating()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_StartUpdating_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600130F RID: 4879 RVA: 0x0004D434 File Offset: 0x0004B634
	[CallerCount(0)]
	public unsafe void StopUpdating()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_StopUpdating_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x0004D478 File Offset: 0x0004B678
	[CallerCount(0)]
	public unsafe void UpdatePosition(bool reverbOcclusionObstruction)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref reverbOcclusionObstruction;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_UpdatePosition_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001311 RID: 4881 RVA: 0x0004D4CC File Offset: 0x0004B6CC
	[CallerCount(0)]
	public unsafe IEnumerator PostPlayDelayed()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x0004D524 File Offset: 0x0004B724
	[CallerCount(0)]
	public unsafe AmbientAudioEmitter() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001313 RID: 4883 RVA: 0x0004D570 File Offset: 0x0004B770
	// Note: this type is marked as 'beforefieldinit'.
	static AmbientAudioEmitter()
	{
		Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "AmbientAudioEmitter");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr);
		AmbientAudioEmitter.NativeFieldInfoPtr_SoundPlayEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "SoundPlayEvent");
		AmbientAudioEmitter.NativeFieldInfoPtr_SoundStopEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "SoundStopEvent");
		AmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "Is3DSound");
		AmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "PreDelaySeconds");
		AmbientAudioEmitter.NativeFieldInfoPtr_AreaTriggerColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "AreaTriggerColliders");
		AmbientAudioEmitter.NativeFieldInfoPtr_AreaBounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "AreaBounds");
		AmbientAudioEmitter.NativeFieldInfoPtr_AreaSphericalBounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "AreaSphericalBounds");
		AmbientAudioEmitter.NativeFieldInfoPtr_UpdateType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "UpdateType");
		AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "AudibleRange");
		AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRangeSquared = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "AudibleRangeSquared");
		AmbientAudioEmitter.NativeFieldInfoPtr_isInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "isInitialized");
		AmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "wasPlayEventPosted");
		AmbientAudioEmitter.NativeFieldInfoPtr_IsWithinAudibleRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "IsWithinAudibleRange");
		AmbientAudioEmitter.NativeFieldInfoPtr_isUpdating = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "isUpdating");
		AmbientAudioEmitter.NativeFieldInfoPtr_tr = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "tr");
		AmbientAudioEmitter.NativeFieldInfoPtr_FRAME_SKIP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "FRAME_SKIP");
		AmbientAudioEmitter.NativeFieldInfoPtr_frameCounterStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "frameCounterStart");
		AmbientAudioEmitter.NativeFieldInfoPtr_frameCounter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "frameCounter");
		AmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		AmbientAudioEmitter.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664885);
		AmbientAudioEmitter.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664886);
		AmbientAudioEmitter.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664887);
		AmbientAudioEmitter.NativeMethodInfoPtr_SetFrameCounterStart_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664888);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664889);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664890);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664891);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664892);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnListenerReverbZoneChanged_Private_Void_ReverbBusType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664893);
		AmbientAudioEmitter.NativeMethodInfoPtr_OnListenerMuffleZoneChanged_Private_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664894);
		AmbientAudioEmitter.NativeMethodInfoPtr_StartUpdating_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664895);
		AmbientAudioEmitter.NativeMethodInfoPtr_StopUpdating_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664896);
		AmbientAudioEmitter.NativeMethodInfoPtr_UpdatePosition_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664897);
		AmbientAudioEmitter.NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664898);
		AmbientAudioEmitter.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, 100664899);
	}

	// Token: 0x06001314 RID: 4884 RVA: 0x0000210C File Offset: 0x0000030C
	public AmbientAudioEmitter(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700066D RID: 1645
	// (get) Token: 0x06001315 RID: 4885 RVA: 0x0004D848 File Offset: 0x0004BA48
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr));
		}
	}

	// Token: 0x1700066E RID: 1646
	// (get) Token: 0x06001316 RID: 4886 RVA: 0x0004D85C File Offset: 0x0004BA5C
	// (set) Token: 0x06001317 RID: 4887 RVA: 0x0004D890 File Offset: 0x0004BA90
	public unsafe AK.Wwise.Event SoundPlayEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_SoundPlayEvent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_SoundPlayEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700066F RID: 1647
	// (get) Token: 0x06001318 RID: 4888 RVA: 0x0004D8B8 File Offset: 0x0004BAB8
	// (set) Token: 0x06001319 RID: 4889 RVA: 0x0004D8EC File Offset: 0x0004BAEC
	public unsafe AK.Wwise.Event SoundStopEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_SoundStopEvent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_SoundStopEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000670 RID: 1648
	// (get) Token: 0x0600131A RID: 4890 RVA: 0x0004D914 File Offset: 0x0004BB14
	// (set) Token: 0x0600131B RID: 4891 RVA: 0x0004D93C File Offset: 0x0004BB3C
	public unsafe bool Is3DSound
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound)) = value;
		}
	}

	// Token: 0x17000671 RID: 1649
	// (get) Token: 0x0600131C RID: 4892 RVA: 0x0004D960 File Offset: 0x0004BB60
	// (set) Token: 0x0600131D RID: 4893 RVA: 0x0004D988 File Offset: 0x0004BB88
	public unsafe float PreDelaySeconds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds)) = value;
		}
	}

	// Token: 0x17000672 RID: 1650
	// (get) Token: 0x0600131E RID: 4894 RVA: 0x0004D9AC File Offset: 0x0004BBAC
	// (set) Token: 0x0600131F RID: 4895 RVA: 0x0004D9E0 File Offset: 0x0004BBE0
	public unsafe List<Collider> AreaTriggerColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaTriggerColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Collider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaTriggerColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000673 RID: 1651
	// (get) Token: 0x06001320 RID: 4896 RVA: 0x0004DA08 File Offset: 0x0004BC08
	// (set) Token: 0x06001321 RID: 4897 RVA: 0x0004DA3C File Offset: 0x0004BC3C
	public unsafe List<Bounds> AreaBounds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaBounds);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Bounds>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaBounds), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000674 RID: 1652
	// (get) Token: 0x06001322 RID: 4898 RVA: 0x0004DA64 File Offset: 0x0004BC64
	// (set) Token: 0x06001323 RID: 4899 RVA: 0x0004DA98 File Offset: 0x0004BC98
	public unsafe List<Vector4> AreaSphericalBounds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaSphericalBounds);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Vector4>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AreaSphericalBounds), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000675 RID: 1653
	// (get) Token: 0x06001324 RID: 4900 RVA: 0x0004DAC0 File Offset: 0x0004BCC0
	// (set) Token: 0x06001325 RID: 4901 RVA: 0x0004DAE8 File Offset: 0x0004BCE8
	public unsafe AudioEmitterUpdateType UpdateType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_UpdateType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_UpdateType)) = value;
		}
	}

	// Token: 0x17000676 RID: 1654
	// (get) Token: 0x06001326 RID: 4902 RVA: 0x0004DB0C File Offset: 0x0004BD0C
	// (set) Token: 0x06001327 RID: 4903 RVA: 0x0004DB34 File Offset: 0x0004BD34
	public unsafe float AudibleRange
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRange);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRange)) = value;
		}
	}

	// Token: 0x17000677 RID: 1655
	// (get) Token: 0x06001328 RID: 4904 RVA: 0x0004DB58 File Offset: 0x0004BD58
	// (set) Token: 0x06001329 RID: 4905 RVA: 0x0004DB80 File Offset: 0x0004BD80
	public unsafe float AudibleRangeSquared
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRangeSquared);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_AudibleRangeSquared)) = value;
		}
	}

	// Token: 0x17000678 RID: 1656
	// (get) Token: 0x0600132A RID: 4906 RVA: 0x0004DBA4 File Offset: 0x0004BDA4
	// (set) Token: 0x0600132B RID: 4907 RVA: 0x0004DBCC File Offset: 0x0004BDCC
	public unsafe bool isInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_isInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_isInitialized)) = value;
		}
	}

	// Token: 0x17000679 RID: 1657
	// (get) Token: 0x0600132C RID: 4908 RVA: 0x0004DBF0 File Offset: 0x0004BDF0
	// (set) Token: 0x0600132D RID: 4909 RVA: 0x0004DC18 File Offset: 0x0004BE18
	public unsafe bool wasPlayEventPosted
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted)) = value;
		}
	}

	// Token: 0x1700067A RID: 1658
	// (get) Token: 0x0600132E RID: 4910 RVA: 0x0004DC3C File Offset: 0x0004BE3C
	// (set) Token: 0x0600132F RID: 4911 RVA: 0x0004DC64 File Offset: 0x0004BE64
	public unsafe bool IsWithinAudibleRange
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_IsWithinAudibleRange);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_IsWithinAudibleRange)) = value;
		}
	}

	// Token: 0x1700067B RID: 1659
	// (get) Token: 0x06001330 RID: 4912 RVA: 0x0004DC88 File Offset: 0x0004BE88
	// (set) Token: 0x06001331 RID: 4913 RVA: 0x0004DCB0 File Offset: 0x0004BEB0
	public unsafe bool isUpdating
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_isUpdating);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_isUpdating)) = value;
		}
	}

	// Token: 0x1700067C RID: 1660
	// (get) Token: 0x06001332 RID: 4914 RVA: 0x0004DCD4 File Offset: 0x0004BED4
	// (set) Token: 0x06001333 RID: 4915 RVA: 0x0004DD08 File Offset: 0x0004BF08
	public unsafe Transform tr
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_tr);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_tr), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700067D RID: 1661
	// (get) Token: 0x06001334 RID: 4916 RVA: 0x0004DD30 File Offset: 0x0004BF30
	// (set) Token: 0x06001335 RID: 4917 RVA: 0x0004DD4E File Offset: 0x0004BF4E
	public unsafe static int FRAME_SKIP
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(AmbientAudioEmitter.NativeFieldInfoPtr_FRAME_SKIP, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(AmbientAudioEmitter.NativeFieldInfoPtr_FRAME_SKIP, (void*)(&value));
		}
	}

	// Token: 0x1700067E RID: 1662
	// (get) Token: 0x06001336 RID: 4918 RVA: 0x0004DD60 File Offset: 0x0004BF60
	// (set) Token: 0x06001337 RID: 4919 RVA: 0x0004DD7E File Offset: 0x0004BF7E
	public unsafe static int frameCounterStart
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(AmbientAudioEmitter.NativeFieldInfoPtr_frameCounterStart, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(AmbientAudioEmitter.NativeFieldInfoPtr_frameCounterStart, (void*)(&value));
		}
	}

	// Token: 0x1700067F RID: 1663
	// (get) Token: 0x06001338 RID: 4920 RVA: 0x0004DD90 File Offset: 0x0004BF90
	// (set) Token: 0x06001339 RID: 4921 RVA: 0x0004DDB8 File Offset: 0x0004BFB8
	public unsafe int frameCounter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_frameCounter);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr_frameCounter)) = value;
		}
	}

	// Token: 0x17000680 RID: 1664
	// (get) Token: 0x0600133A RID: 4922 RVA: 0x0004DDDC File Offset: 0x0004BFDC
	// (set) Token: 0x0600133B RID: 4923 RVA: 0x0004DE04 File Offset: 0x0004C004
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x04000C27 RID: 3111
	private static readonly IntPtr NativeFieldInfoPtr_SoundPlayEvent;

	// Token: 0x04000C28 RID: 3112
	private static readonly IntPtr NativeFieldInfoPtr_SoundStopEvent;

	// Token: 0x04000C29 RID: 3113
	private static readonly IntPtr NativeFieldInfoPtr_Is3DSound;

	// Token: 0x04000C2A RID: 3114
	private static readonly IntPtr NativeFieldInfoPtr_PreDelaySeconds;

	// Token: 0x04000C2B RID: 3115
	private static readonly IntPtr NativeFieldInfoPtr_AreaTriggerColliders;

	// Token: 0x04000C2C RID: 3116
	private static readonly IntPtr NativeFieldInfoPtr_AreaBounds;

	// Token: 0x04000C2D RID: 3117
	private static readonly IntPtr NativeFieldInfoPtr_AreaSphericalBounds;

	// Token: 0x04000C2E RID: 3118
	private static readonly IntPtr NativeFieldInfoPtr_UpdateType;

	// Token: 0x04000C2F RID: 3119
	private static readonly IntPtr NativeFieldInfoPtr_AudibleRange;

	// Token: 0x04000C30 RID: 3120
	private static readonly IntPtr NativeFieldInfoPtr_AudibleRangeSquared;

	// Token: 0x04000C31 RID: 3121
	private static readonly IntPtr NativeFieldInfoPtr_isInitialized;

	// Token: 0x04000C32 RID: 3122
	private static readonly IntPtr NativeFieldInfoPtr_wasPlayEventPosted;

	// Token: 0x04000C33 RID: 3123
	private static readonly IntPtr NativeFieldInfoPtr_IsWithinAudibleRange;

	// Token: 0x04000C34 RID: 3124
	private static readonly IntPtr NativeFieldInfoPtr_isUpdating;

	// Token: 0x04000C35 RID: 3125
	private static readonly IntPtr NativeFieldInfoPtr_tr;

	// Token: 0x04000C36 RID: 3126
	private static readonly IntPtr NativeFieldInfoPtr_FRAME_SKIP;

	// Token: 0x04000C37 RID: 3127
	private static readonly IntPtr NativeFieldInfoPtr_frameCounterStart;

	// Token: 0x04000C38 RID: 3128
	private static readonly IntPtr NativeFieldInfoPtr_frameCounter;

	// Token: 0x04000C39 RID: 3129
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x04000C3A RID: 3130
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04000C3B RID: 3131
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x04000C3C RID: 3132
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04000C3D RID: 3133
	private static readonly IntPtr NativeMethodInfoPtr_SetFrameCounterStart_Private_Void_0;

	// Token: 0x04000C3E RID: 3134
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04000C3F RID: 3135
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04000C40 RID: 3136
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04000C41 RID: 3137
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04000C42 RID: 3138
	private static readonly IntPtr NativeMethodInfoPtr_OnListenerReverbZoneChanged_Private_Void_ReverbBusType_0;

	// Token: 0x04000C43 RID: 3139
	private static readonly IntPtr NativeMethodInfoPtr_OnListenerMuffleZoneChanged_Private_Void_Int32_0;

	// Token: 0x04000C44 RID: 3140
	private static readonly IntPtr NativeMethodInfoPtr_StartUpdating_Private_Void_0;

	// Token: 0x04000C45 RID: 3141
	private static readonly IntPtr NativeMethodInfoPtr_StopUpdating_Private_Void_0;

	// Token: 0x04000C46 RID: 3142
	private static readonly IntPtr NativeMethodInfoPtr_UpdatePosition_Private_Void_Boolean_0;

	// Token: 0x04000C47 RID: 3143
	private static readonly IntPtr NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0;

	// Token: 0x04000C48 RID: 3144
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200012F RID: 303
	[ObfuscatedName("AmbientAudioEmitter/<PostPlayDelayed>d__33")]
	public sealed class _PostPlayDelayed_d__33 : Il2CppSystem.Object
	{
		// Token: 0x0600133C RID: 4924 RVA: 0x0004DE28 File Offset: 0x0004C028
		[CallerCount(0)]
		public unsafe _PostPlayDelayed_d__33(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600133D RID: 4925 RVA: 0x0004DE88 File Offset: 0x0004C088
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600133E RID: 4926 RVA: 0x0004DECC File Offset: 0x0004C0CC
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17000686 RID: 1670
		// (get) Token: 0x0600133F RID: 4927 RVA: 0x0004DF1C File Offset: 0x0004C11C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06001340 RID: 4928 RVA: 0x0004DF74 File Offset: 0x0004C174
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17000687 RID: 1671
		// (get) Token: 0x06001341 RID: 4929 RVA: 0x0004DFB8 File Offset: 0x0004C1B8
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06001342 RID: 4930 RVA: 0x0004E010 File Offset: 0x0004C210
		// Note: this type is marked as 'beforefieldinit'.
		static _PostPlayDelayed_d__33()
		{
			Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AmbientAudioEmitter>.NativeClassPtr, "<PostPlayDelayed>d__33");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, "<>1__state");
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, "<>2__current");
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, "<>4__this");
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664900);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664901);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664902);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664903);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664904);
			AmbientAudioEmitter._PostPlayDelayed_d__33.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr, 100664905);
		}

		// Token: 0x06001343 RID: 4931 RVA: 0x00002988 File Offset: 0x00000B88
		public _PostPlayDelayed_d__33(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000682 RID: 1666
		// (get) Token: 0x06001344 RID: 4932 RVA: 0x0004E0EF File Offset: 0x0004C2EF
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmbientAudioEmitter._PostPlayDelayed_d__33>.NativeClassPtr));
			}
		}

		// Token: 0x17000683 RID: 1667
		// (get) Token: 0x06001345 RID: 4933 RVA: 0x0004E100 File Offset: 0x0004C300
		// (set) Token: 0x06001346 RID: 4934 RVA: 0x0004E128 File Offset: 0x0004C328
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17000684 RID: 1668
		// (get) Token: 0x06001347 RID: 4935 RVA: 0x0004E14C File Offset: 0x0004C34C
		// (set) Token: 0x06001348 RID: 4936 RVA: 0x0004E180 File Offset: 0x0004C380
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000685 RID: 1669
		// (get) Token: 0x06001349 RID: 4937 RVA: 0x0004E1A8 File Offset: 0x0004C3A8
		// (set) Token: 0x0600134A RID: 4938 RVA: 0x0004E1DC File Offset: 0x0004C3DC
		public unsafe AmbientAudioEmitter __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AmbientAudioEmitter(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmbientAudioEmitter._PostPlayDelayed_d__33.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000C49 RID: 3145
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04000C4A RID: 3146
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04000C4B RID: 3147
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04000C4C RID: 3148
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000C4D RID: 3149
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000C4E RID: 3150
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04000C4F RID: 3151
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04000C50 RID: 3152
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000C51 RID: 3153
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
