﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200001B RID: 27
public class CharacterCameraConstraint : MonoBehaviour
{
	// Token: 0x06000174 RID: 372 RVA: 0x000084EC File Offset: 0x000066EC
	[CallerCount(0)]
	public unsafe CharacterCameraConstraint() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000175 RID: 373 RVA: 0x00008538 File Offset: 0x00006738
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000176 RID: 374 RVA: 0x0000857C File Offset: 0x0000677C
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000177 RID: 375 RVA: 0x000085C0 File Offset: 0x000067C0
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000178 RID: 376 RVA: 0x00008604 File Offset: 0x00006804
	[CallerCount(0)]
	public unsafe void CameraUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_CameraUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000179 RID: 377 RVA: 0x00008648 File Offset: 0x00006848
	[CallerCount(0)]
	public unsafe bool CheckCameraOverlapped()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_CheckCameraOverlapped_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x0600017A RID: 378 RVA: 0x00008698 File Offset: 0x00006898
	[CallerCount(0)]
	public unsafe bool CheckCameraNearClipping(out float result)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &result;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CharacterCameraConstraint.NativeMethodInfoPtr_CheckCameraNearClipping_Private_Boolean_byref_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x0600017B RID: 379 RVA: 0x000086FC File Offset: 0x000068FC
	// Note: this type is marked as 'beforefieldinit'.
	static CharacterCameraConstraint()
	{
		Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CharacterCameraConstraint");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr);
		CharacterCameraConstraint.NativeFieldInfoPtr_FADE_RAY_LENGTH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "FADE_RAY_LENGTH");
		CharacterCameraConstraint.NativeFieldInfoPtr_FADE_OVERLAP_MAXIMUM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "FADE_OVERLAP_MAXIMUM");
		CharacterCameraConstraint.NativeFieldInfoPtr_FADE_AMOUNT_MAXIMUM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "FADE_AMOUNT_MAXIMUM");
		CharacterCameraConstraint.NativeFieldInfoPtr_CameraRig = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "CameraRig");
		CharacterCameraConstraint.NativeFieldInfoPtr_CollideLayers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "CollideLayers");
		CharacterCameraConstraint.NativeFieldInfoPtr_HeightOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "HeightOffset");
		CharacterCameraConstraint.NativeFieldInfoPtr_MinimumHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "MinimumHeight");
		CharacterCameraConstraint.NativeFieldInfoPtr_MaximumHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "MaximumHeight");
		CharacterCameraConstraint.NativeFieldInfoPtr__character = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "_character");
		CharacterCameraConstraint.NativeFieldInfoPtr__simplePlayerController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, "_simplePlayerController");
		CharacterCameraConstraint.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663435);
		CharacterCameraConstraint.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663436);
		CharacterCameraConstraint.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663437);
		CharacterCameraConstraint.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663438);
		CharacterCameraConstraint.NativeMethodInfoPtr_CameraUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663439);
		CharacterCameraConstraint.NativeMethodInfoPtr_CheckCameraOverlapped_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663440);
		CharacterCameraConstraint.NativeMethodInfoPtr_CheckCameraNearClipping_Private_Boolean_byref_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr, 100663441);
	}

	// Token: 0x0600017C RID: 380 RVA: 0x0000210C File Offset: 0x0000030C
	public CharacterCameraConstraint(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x0600017D RID: 381 RVA: 0x00008880 File Offset: 0x00006A80
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CharacterCameraConstraint>.NativeClassPtr));
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x0600017E RID: 382 RVA: 0x00008894 File Offset: 0x00006A94
	// (set) Token: 0x0600017F RID: 383 RVA: 0x000088B2 File Offset: 0x00006AB2
	public unsafe static float FADE_RAY_LENGTH
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_RAY_LENGTH, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_RAY_LENGTH, (void*)(&value));
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x06000180 RID: 384 RVA: 0x000088C4 File Offset: 0x00006AC4
	// (set) Token: 0x06000181 RID: 385 RVA: 0x000088E2 File Offset: 0x00006AE2
	public unsafe static float FADE_OVERLAP_MAXIMUM
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_OVERLAP_MAXIMUM, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_OVERLAP_MAXIMUM, (void*)(&value));
		}
	}

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x06000182 RID: 386 RVA: 0x000088F4 File Offset: 0x00006AF4
	// (set) Token: 0x06000183 RID: 387 RVA: 0x00008912 File Offset: 0x00006B12
	public unsafe static float FADE_AMOUNT_MAXIMUM
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_AMOUNT_MAXIMUM, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CharacterCameraConstraint.NativeFieldInfoPtr_FADE_AMOUNT_MAXIMUM, (void*)(&value));
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x06000184 RID: 388 RVA: 0x00008924 File Offset: 0x00006B24
	// (set) Token: 0x06000185 RID: 389 RVA: 0x00008958 File Offset: 0x00006B58
	public unsafe OVRCameraRig CameraRig
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_CameraRig);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OVRCameraRig(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_CameraRig), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x06000186 RID: 390 RVA: 0x00008980 File Offset: 0x00006B80
	// (set) Token: 0x06000187 RID: 391 RVA: 0x000089A8 File Offset: 0x00006BA8
	public unsafe LayerMask CollideLayers
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_CollideLayers);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_CollideLayers)) = value;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x06000188 RID: 392 RVA: 0x000089CC File Offset: 0x00006BCC
	// (set) Token: 0x06000189 RID: 393 RVA: 0x000089F4 File Offset: 0x00006BF4
	public unsafe float HeightOffset
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_HeightOffset);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_HeightOffset)) = value;
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x0600018A RID: 394 RVA: 0x00008A18 File Offset: 0x00006C18
	// (set) Token: 0x0600018B RID: 395 RVA: 0x00008A40 File Offset: 0x00006C40
	public unsafe float MinimumHeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_MinimumHeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_MinimumHeight)) = value;
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x0600018C RID: 396 RVA: 0x00008A64 File Offset: 0x00006C64
	// (set) Token: 0x0600018D RID: 397 RVA: 0x00008A8C File Offset: 0x00006C8C
	public unsafe float MaximumHeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_MaximumHeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr_MaximumHeight)) = value;
		}
	}

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x0600018E RID: 398 RVA: 0x00008AB0 File Offset: 0x00006CB0
	// (set) Token: 0x0600018F RID: 399 RVA: 0x00008AE4 File Offset: 0x00006CE4
	public unsafe CapsuleCollider _character
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr__character);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new CapsuleCollider(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr__character), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x06000190 RID: 400 RVA: 0x00008B0C File Offset: 0x00006D0C
	// (set) Token: 0x06000191 RID: 401 RVA: 0x00008B40 File Offset: 0x00006D40
	public unsafe SimpleCapsuleWithStickMovement _simplePlayerController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr__simplePlayerController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new SimpleCapsuleWithStickMovement(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCameraConstraint.NativeFieldInfoPtr__simplePlayerController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040000D8 RID: 216
	private static readonly IntPtr NativeFieldInfoPtr_FADE_RAY_LENGTH;

	// Token: 0x040000D9 RID: 217
	private static readonly IntPtr NativeFieldInfoPtr_FADE_OVERLAP_MAXIMUM;

	// Token: 0x040000DA RID: 218
	private static readonly IntPtr NativeFieldInfoPtr_FADE_AMOUNT_MAXIMUM;

	// Token: 0x040000DB RID: 219
	private static readonly IntPtr NativeFieldInfoPtr_CameraRig;

	// Token: 0x040000DC RID: 220
	private static readonly IntPtr NativeFieldInfoPtr_CollideLayers;

	// Token: 0x040000DD RID: 221
	private static readonly IntPtr NativeFieldInfoPtr_HeightOffset;

	// Token: 0x040000DE RID: 222
	private static readonly IntPtr NativeFieldInfoPtr_MinimumHeight;

	// Token: 0x040000DF RID: 223
	private static readonly IntPtr NativeFieldInfoPtr_MaximumHeight;

	// Token: 0x040000E0 RID: 224
	private static readonly IntPtr NativeFieldInfoPtr__character;

	// Token: 0x040000E1 RID: 225
	private static readonly IntPtr NativeFieldInfoPtr__simplePlayerController;

	// Token: 0x040000E2 RID: 226
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

	// Token: 0x040000E3 RID: 227
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x040000E4 RID: 228
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x040000E5 RID: 229
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040000E6 RID: 230
	private static readonly IntPtr NativeMethodInfoPtr_CameraUpdate_Private_Void_0;

	// Token: 0x040000E7 RID: 231
	private static readonly IntPtr NativeMethodInfoPtr_CheckCameraOverlapped_Private_Boolean_0;

	// Token: 0x040000E8 RID: 232
	private static readonly IntPtr NativeMethodInfoPtr_CheckCameraNearClipping_Private_Boolean_byref_Single_0;
}
