﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x020005B4 RID: 1460
public class ButtonState : MonoBehaviour
{
	// Token: 0x17002A8F RID: 10895
	// (get) Token: 0x060076FE RID: 30462 RVA: 0x001DFA70 File Offset: 0x001DDC70
	public unsafe bool isPressed
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr_get_isPressed_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002A90 RID: 10896
	// (get) Token: 0x060076FF RID: 30463 RVA: 0x001DFAC0 File Offset: 0x001DDCC0
	public unsafe bool isDown
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr_get_isDown_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002A91 RID: 10897
	// (get) Token: 0x06007700 RID: 30464 RVA: 0x001DFB10 File Offset: 0x001DDD10
	public unsafe bool isUp
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr_get_isUp_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06007701 RID: 30465 RVA: 0x001DFB60 File Offset: 0x001DDD60
	[CallerCount(0)]
	public unsafe void OnPointerDown(PointerEventData eventData)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(eventData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06007702 RID: 30466 RVA: 0x001DFBBC File Offset: 0x001DDDBC
	[CallerCount(0)]
	public unsafe void OnPointerUp(PointerEventData eventData)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(eventData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr_OnPointerUp_Public_Virtual_Final_New_Void_PointerEventData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06007703 RID: 30467 RVA: 0x001DFC18 File Offset: 0x001DDE18
	[CallerCount(0)]
	public unsafe ButtonState() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ButtonState>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonState.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06007704 RID: 30468 RVA: 0x001DFC64 File Offset: 0x001DDE64
	// Note: this type is marked as 'beforefieldinit'.
	static ButtonState()
	{
		Il2CppClassPointerStore<ButtonState>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ButtonState");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ButtonState>.NativeClassPtr);
		ButtonState.NativeFieldInfoPtr__isPressed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, "_isPressed");
		ButtonState.NativeFieldInfoPtr__isDown = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, "_isDown");
		ButtonState.NativeFieldInfoPtr__isUp = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, "_isUp");
		ButtonState.NativeMethodInfoPtr_get_isPressed_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672788);
		ButtonState.NativeMethodInfoPtr_get_isDown_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672789);
		ButtonState.NativeMethodInfoPtr_get_isUp_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672790);
		ButtonState.NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672791);
		ButtonState.NativeMethodInfoPtr_OnPointerUp_Public_Virtual_Final_New_Void_PointerEventData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672792);
		ButtonState.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonState>.NativeClassPtr, 100672793);
	}

	// Token: 0x06007705 RID: 30469 RVA: 0x0000210C File Offset: 0x0000030C
	public ButtonState(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002A8B RID: 10891
	// (get) Token: 0x06007706 RID: 30470 RVA: 0x001DFD48 File Offset: 0x001DDF48
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ButtonState>.NativeClassPtr));
		}
	}

	// Token: 0x17002A8C RID: 10892
	// (get) Token: 0x06007707 RID: 30471 RVA: 0x001DFD5C File Offset: 0x001DDF5C
	// (set) Token: 0x06007708 RID: 30472 RVA: 0x001DFD84 File Offset: 0x001DDF84
	public unsafe bool _isPressed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isPressed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isPressed)) = value;
		}
	}

	// Token: 0x17002A8D RID: 10893
	// (get) Token: 0x06007709 RID: 30473 RVA: 0x001DFDA8 File Offset: 0x001DDFA8
	// (set) Token: 0x0600770A RID: 30474 RVA: 0x001DFDD0 File Offset: 0x001DDFD0
	public unsafe bool _isDown
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isDown);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isDown)) = value;
		}
	}

	// Token: 0x17002A8E RID: 10894
	// (get) Token: 0x0600770B RID: 30475 RVA: 0x001DFDF4 File Offset: 0x001DDFF4
	// (set) Token: 0x0600770C RID: 30476 RVA: 0x001DFE1C File Offset: 0x001DE01C
	public unsafe bool _isUp
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isUp);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonState.NativeFieldInfoPtr__isUp)) = value;
		}
	}

	// Token: 0x04004C24 RID: 19492
	private static readonly IntPtr NativeFieldInfoPtr__isPressed;

	// Token: 0x04004C25 RID: 19493
	private static readonly IntPtr NativeFieldInfoPtr__isDown;

	// Token: 0x04004C26 RID: 19494
	private static readonly IntPtr NativeFieldInfoPtr__isUp;

	// Token: 0x04004C27 RID: 19495
	private static readonly IntPtr NativeMethodInfoPtr_get_isPressed_Public_get_Boolean_0;

	// Token: 0x04004C28 RID: 19496
	private static readonly IntPtr NativeMethodInfoPtr_get_isDown_Public_get_Boolean_0;

	// Token: 0x04004C29 RID: 19497
	private static readonly IntPtr NativeMethodInfoPtr_get_isUp_Public_get_Boolean_0;

	// Token: 0x04004C2A RID: 19498
	private static readonly IntPtr NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0;

	// Token: 0x04004C2B RID: 19499
	private static readonly IntPtr NativeMethodInfoPtr_OnPointerUp_Public_Virtual_Final_New_Void_PointerEventData_0;

	// Token: 0x04004C2C RID: 19500
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
