﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200008C RID: 140
public class BouncingBallMgr : MonoBehaviour
{
	// Token: 0x060008BF RID: 2239 RVA: 0x00024B84 File Offset: 0x00022D84
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallMgr.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00024BC8 File Offset: 0x00022DC8
	[CallerCount(0)]
	public unsafe BouncingBallMgr() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallMgr.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00024C14 File Offset: 0x00022E14
	// Note: this type is marked as 'beforefieldinit'.
	static BouncingBallMgr()
	{
		Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BouncingBallMgr");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr);
		BouncingBallMgr.NativeFieldInfoPtr_trackingspace = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "trackingspace");
		BouncingBallMgr.NativeFieldInfoPtr_rightControllerPivot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "rightControllerPivot");
		BouncingBallMgr.NativeFieldInfoPtr_actionBtn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "actionBtn");
		BouncingBallMgr.NativeFieldInfoPtr_ball = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "ball");
		BouncingBallMgr.NativeFieldInfoPtr_currentBall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "currentBall");
		BouncingBallMgr.NativeFieldInfoPtr_ballGrabbed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, "ballGrabbed");
		BouncingBallMgr.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, 100664003);
		BouncingBallMgr.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr, 100664004);
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x0000210C File Offset: 0x0000030C
	public BouncingBallMgr(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170002FF RID: 767
	// (get) Token: 0x060008C3 RID: 2243 RVA: 0x00024CE4 File Offset: 0x00022EE4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BouncingBallMgr>.NativeClassPtr));
		}
	}

	// Token: 0x17000300 RID: 768
	// (get) Token: 0x060008C4 RID: 2244 RVA: 0x00024CF8 File Offset: 0x00022EF8
	// (set) Token: 0x060008C5 RID: 2245 RVA: 0x00024D2C File Offset: 0x00022F2C
	public unsafe Transform trackingspace
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_trackingspace);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_trackingspace), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000301 RID: 769
	// (get) Token: 0x060008C6 RID: 2246 RVA: 0x00024D54 File Offset: 0x00022F54
	// (set) Token: 0x060008C7 RID: 2247 RVA: 0x00024D88 File Offset: 0x00022F88
	public unsafe GameObject rightControllerPivot
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_rightControllerPivot);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_rightControllerPivot), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000302 RID: 770
	// (get) Token: 0x060008C8 RID: 2248 RVA: 0x00024DB0 File Offset: 0x00022FB0
	// (set) Token: 0x060008C9 RID: 2249 RVA: 0x00024DD8 File Offset: 0x00022FD8
	public unsafe OVRInput.RawButton actionBtn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_actionBtn);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_actionBtn)) = value;
		}
	}

	// Token: 0x17000303 RID: 771
	// (get) Token: 0x060008CA RID: 2250 RVA: 0x00024DFC File Offset: 0x00022FFC
	// (set) Token: 0x060008CB RID: 2251 RVA: 0x00024E30 File Offset: 0x00023030
	public unsafe GameObject ball
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_ball);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_ball), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000304 RID: 772
	// (get) Token: 0x060008CC RID: 2252 RVA: 0x00024E58 File Offset: 0x00023058
	// (set) Token: 0x060008CD RID: 2253 RVA: 0x00024E8C File Offset: 0x0002308C
	public unsafe GameObject currentBall
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_currentBall);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_currentBall), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000305 RID: 773
	// (get) Token: 0x060008CE RID: 2254 RVA: 0x00024EB4 File Offset: 0x000230B4
	// (set) Token: 0x060008CF RID: 2255 RVA: 0x00024EDC File Offset: 0x000230DC
	public unsafe bool ballGrabbed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_ballGrabbed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallMgr.NativeFieldInfoPtr_ballGrabbed)) = value;
		}
	}

	// Token: 0x0400055E RID: 1374
	private static readonly IntPtr NativeFieldInfoPtr_trackingspace;

	// Token: 0x0400055F RID: 1375
	private static readonly IntPtr NativeFieldInfoPtr_rightControllerPivot;

	// Token: 0x04000560 RID: 1376
	private static readonly IntPtr NativeFieldInfoPtr_actionBtn;

	// Token: 0x04000561 RID: 1377
	private static readonly IntPtr NativeFieldInfoPtr_ball;

	// Token: 0x04000562 RID: 1378
	private static readonly IntPtr NativeFieldInfoPtr_currentBall;

	// Token: 0x04000563 RID: 1379
	private static readonly IntPtr NativeFieldInfoPtr_ballGrabbed;

	// Token: 0x04000564 RID: 1380
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04000565 RID: 1381
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
