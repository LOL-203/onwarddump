﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020000AC RID: 172
[Serializable]
public class ColliderList : Object
{
	// Token: 0x06000ACD RID: 2765 RVA: 0x0002CA04 File Offset: 0x0002AC04
	[CallerCount(0)]
	public unsafe ColliderList(List<ColliderData> list) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColliderList>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(list);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColliderList.NativeMethodInfoPtr__ctor_Public_Void_List_1_ColliderData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000ACE RID: 2766 RVA: 0x0002CA68 File Offset: 0x0002AC68
	// Note: this type is marked as 'beforefieldinit'.
	static ColliderList()
	{
		Il2CppClassPointerStore<ColliderList>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ColliderList");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColliderList>.NativeClassPtr);
		ColliderList.NativeFieldInfoPtr_colliderList = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderList>.NativeClassPtr, "colliderList");
		ColliderList.NativeMethodInfoPtr__ctor_Public_Void_List_1_ColliderData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColliderList>.NativeClassPtr, 100664154);
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x00002988 File Offset: 0x00000B88
	public ColliderList(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170003B4 RID: 948
	// (get) Token: 0x06000AD0 RID: 2768 RVA: 0x0002CAC0 File Offset: 0x0002ACC0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColliderList>.NativeClassPtr));
		}
	}

	// Token: 0x170003B5 RID: 949
	// (get) Token: 0x06000AD1 RID: 2769 RVA: 0x0002CAD4 File Offset: 0x0002ACD4
	// (set) Token: 0x06000AD2 RID: 2770 RVA: 0x0002CB08 File Offset: 0x0002AD08
	public unsafe List<ColliderData> colliderList
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColliderList.NativeFieldInfoPtr_colliderList);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<ColliderData>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColliderList.NativeFieldInfoPtr_colliderList), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000695 RID: 1685
	private static readonly IntPtr NativeFieldInfoPtr_colliderList;

	// Token: 0x04000696 RID: 1686
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_List_1_ColliderData_0;
}
