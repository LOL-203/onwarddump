﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000243 RID: 579
public class ColorScheme : ScriptableObject
{
	// Token: 0x060029BD RID: 10685 RVA: 0x000A53AC File Offset: 0x000A35AC
	[CallerCount(0)]
	public unsafe ColorScheme.FactionColor GetFactionColors(Faction faction)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref faction;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColorScheme.NativeMethodInfoPtr_GetFactionColors_Public_FactionColor_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new ColorScheme.FactionColor(intPtr2) : null;
	}

	// Token: 0x060029BE RID: 10686 RVA: 0x000A5414 File Offset: 0x000A3614
	[CallerCount(0)]
	public unsafe ColorScheme() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColorScheme.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060029BF RID: 10687 RVA: 0x000A5460 File Offset: 0x000A3660
	// Note: this type is marked as 'beforefieldinit'.
	static ColorScheme()
	{
		Il2CppClassPointerStore<ColorScheme>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ColorScheme");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr);
		ColorScheme.NativeFieldInfoPtr_friendlyTeamColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "friendlyTeamColors");
		ColorScheme.NativeFieldInfoPtr_enemyTeamColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "enemyTeamColors");
		ColorScheme.NativeFieldInfoPtr_desktopSpectateMarsocColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "desktopSpectateMarsocColors");
		ColorScheme.NativeFieldInfoPtr_desktopSpectateVolkColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "desktopSpectateVolkColors");
		ColorScheme.NativeFieldInfoPtr_vrSpectateMarsocColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "vrSpectateMarsocColors");
		ColorScheme.NativeFieldInfoPtr_vrSpectateVolkColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "vrSpectateVolkColors");
		ColorScheme.NativeFieldInfoPtr_marsocOutlineColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "marsocOutlineColor");
		ColorScheme.NativeFieldInfoPtr_volkOutlineColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "volkOutlineColor");
		ColorScheme.NativeFieldInfoPtr_FactionColors = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "FactionColors");
		ColorScheme.NativeMethodInfoPtr_GetFactionColors_Public_FactionColor_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, 100666514);
		ColorScheme.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, 100666515);
	}

	// Token: 0x060029C0 RID: 10688 RVA: 0x0002DD3C File Offset: 0x0002BF3C
	public ColorScheme(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000EC8 RID: 3784
	// (get) Token: 0x060029C1 RID: 10689 RVA: 0x000A556C File Offset: 0x000A376C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr));
		}
	}

	// Token: 0x17000EC9 RID: 3785
	// (get) Token: 0x060029C2 RID: 10690 RVA: 0x000A5580 File Offset: 0x000A3780
	// (set) Token: 0x060029C3 RID: 10691 RVA: 0x000A55B4 File Offset: 0x000A37B4
	public unsafe ColorScheme.dotColorScheme friendlyTeamColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_friendlyTeamColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_friendlyTeamColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECA RID: 3786
	// (get) Token: 0x060029C4 RID: 10692 RVA: 0x000A55DC File Offset: 0x000A37DC
	// (set) Token: 0x060029C5 RID: 10693 RVA: 0x000A5610 File Offset: 0x000A3810
	public unsafe ColorScheme.dotColorScheme enemyTeamColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_enemyTeamColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_enemyTeamColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECB RID: 3787
	// (get) Token: 0x060029C6 RID: 10694 RVA: 0x000A5638 File Offset: 0x000A3838
	// (set) Token: 0x060029C7 RID: 10695 RVA: 0x000A566C File Offset: 0x000A386C
	public unsafe ColorScheme.dotColorScheme desktopSpectateMarsocColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_desktopSpectateMarsocColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_desktopSpectateMarsocColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECC RID: 3788
	// (get) Token: 0x060029C8 RID: 10696 RVA: 0x000A5694 File Offset: 0x000A3894
	// (set) Token: 0x060029C9 RID: 10697 RVA: 0x000A56C8 File Offset: 0x000A38C8
	public unsafe ColorScheme.dotColorScheme desktopSpectateVolkColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_desktopSpectateVolkColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_desktopSpectateVolkColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECD RID: 3789
	// (get) Token: 0x060029CA RID: 10698 RVA: 0x000A56F0 File Offset: 0x000A38F0
	// (set) Token: 0x060029CB RID: 10699 RVA: 0x000A5724 File Offset: 0x000A3924
	public unsafe ColorScheme.dotColorScheme vrSpectateMarsocColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_vrSpectateMarsocColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_vrSpectateMarsocColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECE RID: 3790
	// (get) Token: 0x060029CC RID: 10700 RVA: 0x000A574C File Offset: 0x000A394C
	// (set) Token: 0x060029CD RID: 10701 RVA: 0x000A5780 File Offset: 0x000A3980
	public unsafe ColorScheme.dotColorScheme vrSpectateVolkColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_vrSpectateVolkColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ColorScheme.dotColorScheme(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_vrSpectateVolkColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000ECF RID: 3791
	// (get) Token: 0x060029CE RID: 10702 RVA: 0x000A57A8 File Offset: 0x000A39A8
	// (set) Token: 0x060029CF RID: 10703 RVA: 0x000A57D0 File Offset: 0x000A39D0
	public unsafe Color marsocOutlineColor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_marsocOutlineColor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_marsocOutlineColor)) = value;
		}
	}

	// Token: 0x17000ED0 RID: 3792
	// (get) Token: 0x060029D0 RID: 10704 RVA: 0x000A57F4 File Offset: 0x000A39F4
	// (set) Token: 0x060029D1 RID: 10705 RVA: 0x000A581C File Offset: 0x000A3A1C
	public unsafe Color volkOutlineColor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_volkOutlineColor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_volkOutlineColor)) = value;
		}
	}

	// Token: 0x17000ED1 RID: 3793
	// (get) Token: 0x060029D2 RID: 10706 RVA: 0x000A5840 File Offset: 0x000A3A40
	// (set) Token: 0x060029D3 RID: 10707 RVA: 0x000A5874 File Offset: 0x000A3A74
	public unsafe Il2CppReferenceArray<ColorScheme.FactionColor> FactionColors
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_FactionColors);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ColorScheme.FactionColor>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.NativeFieldInfoPtr_FactionColors), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04001AB6 RID: 6838
	private static readonly IntPtr NativeFieldInfoPtr_friendlyTeamColors;

	// Token: 0x04001AB7 RID: 6839
	private static readonly IntPtr NativeFieldInfoPtr_enemyTeamColors;

	// Token: 0x04001AB8 RID: 6840
	private static readonly IntPtr NativeFieldInfoPtr_desktopSpectateMarsocColors;

	// Token: 0x04001AB9 RID: 6841
	private static readonly IntPtr NativeFieldInfoPtr_desktopSpectateVolkColors;

	// Token: 0x04001ABA RID: 6842
	private static readonly IntPtr NativeFieldInfoPtr_vrSpectateMarsocColors;

	// Token: 0x04001ABB RID: 6843
	private static readonly IntPtr NativeFieldInfoPtr_vrSpectateVolkColors;

	// Token: 0x04001ABC RID: 6844
	private static readonly IntPtr NativeFieldInfoPtr_marsocOutlineColor;

	// Token: 0x04001ABD RID: 6845
	private static readonly IntPtr NativeFieldInfoPtr_volkOutlineColor;

	// Token: 0x04001ABE RID: 6846
	private static readonly IntPtr NativeFieldInfoPtr_FactionColors;

	// Token: 0x04001ABF RID: 6847
	private static readonly IntPtr NativeMethodInfoPtr_GetFactionColors_Public_FactionColor_Faction_0;

	// Token: 0x04001AC0 RID: 6848
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000244 RID: 580
	[Serializable]
	public class dotColorScheme : Il2CppSystem.Object
	{
		// Token: 0x060029D4 RID: 10708 RVA: 0x000A589C File Offset: 0x000A3A9C
		[CallerCount(0)]
		public unsafe dotColorScheme() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColorScheme.dotColorScheme.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060029D5 RID: 10709 RVA: 0x000A58E8 File Offset: 0x000A3AE8
		// Note: this type is marked as 'beforefieldinit'.
		static dotColorScheme()
		{
			Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "dotColorScheme");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr);
			ColorScheme.dotColorScheme.NativeFieldInfoPtr_fullHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr, "fullHealth");
			ColorScheme.dotColorScheme.NativeFieldInfoPtr_midHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr, "midHealth");
			ColorScheme.dotColorScheme.NativeFieldInfoPtr_lowHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr, "lowHealth");
			ColorScheme.dotColorScheme.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr, 100666516);
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x00002988 File Offset: 0x00000B88
		public dotColorScheme(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000ED2 RID: 3794
		// (get) Token: 0x060029D7 RID: 10711 RVA: 0x000A5963 File Offset: 0x000A3B63
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColorScheme.dotColorScheme>.NativeClassPtr));
			}
		}

		// Token: 0x17000ED3 RID: 3795
		// (get) Token: 0x060029D8 RID: 10712 RVA: 0x000A5974 File Offset: 0x000A3B74
		// (set) Token: 0x060029D9 RID: 10713 RVA: 0x000A599C File Offset: 0x000A3B9C
		public unsafe Color fullHealth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_fullHealth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_fullHealth)) = value;
			}
		}

		// Token: 0x17000ED4 RID: 3796
		// (get) Token: 0x060029DA RID: 10714 RVA: 0x000A59C0 File Offset: 0x000A3BC0
		// (set) Token: 0x060029DB RID: 10715 RVA: 0x000A59E8 File Offset: 0x000A3BE8
		public unsafe Color midHealth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_midHealth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_midHealth)) = value;
			}
		}

		// Token: 0x17000ED5 RID: 3797
		// (get) Token: 0x060029DC RID: 10716 RVA: 0x000A5A0C File Offset: 0x000A3C0C
		// (set) Token: 0x060029DD RID: 10717 RVA: 0x000A5A34 File Offset: 0x000A3C34
		public unsafe Color lowHealth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_lowHealth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.dotColorScheme.NativeFieldInfoPtr_lowHealth)) = value;
			}
		}

		// Token: 0x04001AC1 RID: 6849
		private static readonly IntPtr NativeFieldInfoPtr_fullHealth;

		// Token: 0x04001AC2 RID: 6850
		private static readonly IntPtr NativeFieldInfoPtr_midHealth;

		// Token: 0x04001AC3 RID: 6851
		private static readonly IntPtr NativeFieldInfoPtr_lowHealth;

		// Token: 0x04001AC4 RID: 6852
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000245 RID: 581
	[Serializable]
	public class FactionColor : Il2CppSystem.Object
	{
		// Token: 0x060029DE RID: 10718 RVA: 0x000A5A58 File Offset: 0x000A3C58
		[CallerCount(0)]
		public unsafe FactionColor() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColorScheme.FactionColor.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060029DF RID: 10719 RVA: 0x000A5AA4 File Offset: 0x000A3CA4
		// Note: this type is marked as 'beforefieldinit'.
		static FactionColor()
		{
			Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ColorScheme>.NativeClassPtr, "FactionColor");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr);
			ColorScheme.FactionColor.NativeFieldInfoPtr_m_Faction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr, "m_Faction");
			ColorScheme.FactionColor.NativeFieldInfoPtr_UIColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr, "UIColor");
			ColorScheme.FactionColor.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr, 100666517);
		}

		// Token: 0x060029E0 RID: 10720 RVA: 0x00002988 File Offset: 0x00000B88
		public FactionColor(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000ED6 RID: 3798
		// (get) Token: 0x060029E1 RID: 10721 RVA: 0x000A5B0B File Offset: 0x000A3D0B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColorScheme.FactionColor>.NativeClassPtr));
			}
		}

		// Token: 0x17000ED7 RID: 3799
		// (get) Token: 0x060029E2 RID: 10722 RVA: 0x000A5B1C File Offset: 0x000A3D1C
		// (set) Token: 0x060029E3 RID: 10723 RVA: 0x000A5B44 File Offset: 0x000A3D44
		public unsafe Faction m_Faction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.FactionColor.NativeFieldInfoPtr_m_Faction);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.FactionColor.NativeFieldInfoPtr_m_Faction)) = value;
			}
		}

		// Token: 0x17000ED8 RID: 3800
		// (get) Token: 0x060029E4 RID: 10724 RVA: 0x000A5B68 File Offset: 0x000A3D68
		// (set) Token: 0x060029E5 RID: 10725 RVA: 0x000A5B90 File Offset: 0x000A3D90
		public unsafe Color UIColor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.FactionColor.NativeFieldInfoPtr_UIColor);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ColorScheme.FactionColor.NativeFieldInfoPtr_UIColor)) = value;
			}
		}

		// Token: 0x04001AC5 RID: 6853
		private static readonly IntPtr NativeFieldInfoPtr_m_Faction;

		// Token: 0x04001AC6 RID: 6854
		private static readonly IntPtr NativeFieldInfoPtr_UIColor;

		// Token: 0x04001AC7 RID: 6855
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
