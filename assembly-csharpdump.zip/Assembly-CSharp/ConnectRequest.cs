﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020004A7 RID: 1191
[Serializable]
public class ConnectRequest : BaseRequest<ConnectParams>
{
	// Token: 0x06005EC5 RID: 24261 RVA: 0x0017B03C File Offset: 0x0017923C
	[CallerCount(0)]
	public unsafe ConnectRequest() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConnectRequest>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectRequest.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005EC6 RID: 24262 RVA: 0x0017B087 File Offset: 0x00179287
	// Note: this type is marked as 'beforefieldinit'.
	static ConnectRequest()
	{
		Il2CppClassPointerStore<ConnectRequest>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConnectRequest");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConnectRequest>.NativeClassPtr);
		ConnectRequest.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectRequest>.NativeClassPtr, 100670787);
	}

	// Token: 0x06005EC7 RID: 24263 RVA: 0x0017B0C0 File Offset: 0x001792C0
	public ConnectRequest(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170021AC RID: 8620
	// (get) Token: 0x06005EC8 RID: 24264 RVA: 0x0017B0C9 File Offset: 0x001792C9
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConnectRequest>.NativeClassPtr));
		}
	}

	// Token: 0x04003BD9 RID: 15321
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
