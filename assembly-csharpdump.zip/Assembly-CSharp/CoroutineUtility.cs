﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C9 RID: 201
public static class CoroutineUtility : Il2CppSystem.Object
{
	// Token: 0x1700045C RID: 1116
	// (get) Token: 0x06000C8E RID: 3214 RVA: 0x00032EB0 File Offset: 0x000310B0
	// (set) Token: 0x06000C8F RID: 3215 RVA: 0x00032EF8 File Offset: 0x000310F8
	public unsafe static WaitForEndOfFrame WaitEndOfFrame
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_get_WaitEndOfFrame_Public_Static_get_WaitForEndOfFrame_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new WaitForEndOfFrame(intPtr2) : null;
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_set_WaitEndOfFrame_Private_Static_set_Void_WaitForEndOfFrame_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x1700045D RID: 1117
	// (get) Token: 0x06000C90 RID: 3216 RVA: 0x00032F44 File Offset: 0x00031144
	// (set) Token: 0x06000C91 RID: 3217 RVA: 0x00032F8C File Offset: 0x0003118C
	public unsafe static WaitForFixedUpdate WaitFixedUpdate
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_get_WaitFixedUpdate_Public_Static_get_WaitForFixedUpdate_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new WaitForFixedUpdate(intPtr2) : null;
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_set_WaitFixedUpdate_Private_Static_set_Void_WaitForFixedUpdate_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06000C92 RID: 3218 RVA: 0x00032FD8 File Offset: 0x000311D8
	[CallerCount(0)]
	public unsafe static WaitForSeconds WaitSeconds(float seconds)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref seconds;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_WaitSeconds_Public_Static_WaitForSeconds_Single_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new WaitForSeconds(intPtr2) : null;
	}

	// Token: 0x06000C93 RID: 3219 RVA: 0x00033034 File Offset: 0x00031234
	[CallerCount(0)]
	public unsafe static WaitForSecondsRealtime WaitSecondsRealtime(float seconds)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref seconds;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_WaitSecondsRealtime_Public_Static_WaitForSecondsRealtime_Single_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new WaitForSecondsRealtime(intPtr2) : null;
	}

	// Token: 0x06000C94 RID: 3220 RVA: 0x00033090 File Offset: 0x00031290
	[CallerCount(0)]
	public unsafe static WaitForSecondsNetwork WaitSecondsNetwork([In] ref double seconds)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &seconds;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_WaitSecondsNetwork_Public_Static_WaitForSecondsNetwork_byref_Double_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new WaitForSecondsNetwork(intPtr2) : null;
	}

	// Token: 0x06000C95 RID: 3221 RVA: 0x000330EC File Offset: 0x000312EC
	[CallerCount(0)]
	public unsafe static WaitForPermission WaitPermission(string permission)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(permission);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoroutineUtility.NativeMethodInfoPtr_WaitPermission_Public_Static_WaitForPermission_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new WaitForPermission(intPtr2) : null;
	}

	// Token: 0x06000C96 RID: 3222 RVA: 0x0003314C File Offset: 0x0003134C
	// Note: this type is marked as 'beforefieldinit'.
	static CoroutineUtility()
	{
		Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CoroutineUtility");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr);
		CoroutineUtility.NativeFieldInfoPtr__WaitEndOfFrame_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "<WaitEndOfFrame>k__BackingField");
		CoroutineUtility.NativeFieldInfoPtr__WaitFixedUpdate_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "<WaitFixedUpdate>k__BackingField");
		CoroutineUtility.NativeFieldInfoPtr__waitForSecondsDict = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "_waitForSecondsDict");
		CoroutineUtility.NativeFieldInfoPtr__waitForSecondsRealtimeDict = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "_waitForSecondsRealtimeDict");
		CoroutineUtility.NativeFieldInfoPtr_WaitForSecondsNetworkPool = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "WaitForSecondsNetworkPool");
		CoroutineUtility.NativeFieldInfoPtr_WaitPermissionPool = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, "WaitPermissionPool");
		CoroutineUtility.NativeMethodInfoPtr_get_WaitEndOfFrame_Public_Static_get_WaitForEndOfFrame_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664269);
		CoroutineUtility.NativeMethodInfoPtr_set_WaitEndOfFrame_Private_Static_set_Void_WaitForEndOfFrame_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664270);
		CoroutineUtility.NativeMethodInfoPtr_get_WaitFixedUpdate_Public_Static_get_WaitForFixedUpdate_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664271);
		CoroutineUtility.NativeMethodInfoPtr_set_WaitFixedUpdate_Private_Static_set_Void_WaitForFixedUpdate_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664272);
		CoroutineUtility.NativeMethodInfoPtr_WaitSeconds_Public_Static_WaitForSeconds_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664273);
		CoroutineUtility.NativeMethodInfoPtr_WaitSecondsRealtime_Public_Static_WaitForSecondsRealtime_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664274);
		CoroutineUtility.NativeMethodInfoPtr_WaitSecondsNetwork_Public_Static_WaitForSecondsNetwork_byref_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664275);
		CoroutineUtility.NativeMethodInfoPtr_WaitPermission_Public_Static_WaitForPermission_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr, 100664276);
	}

	// Token: 0x06000C97 RID: 3223 RVA: 0x00002988 File Offset: 0x00000B88
	public CoroutineUtility(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000455 RID: 1109
	// (get) Token: 0x06000C98 RID: 3224 RVA: 0x00033294 File Offset: 0x00031494
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoroutineUtility>.NativeClassPtr));
		}
	}

	// Token: 0x17000456 RID: 1110
	// (get) Token: 0x06000C99 RID: 3225 RVA: 0x000332A8 File Offset: 0x000314A8
	// (set) Token: 0x06000C9A RID: 3226 RVA: 0x000332D3 File Offset: 0x000314D3
	public unsafe static WaitForEndOfFrame _WaitEndOfFrame_k__BackingField
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr__WaitEndOfFrame_k__BackingField, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new WaitForEndOfFrame(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr__WaitEndOfFrame_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000457 RID: 1111
	// (get) Token: 0x06000C9B RID: 3227 RVA: 0x000332E8 File Offset: 0x000314E8
	// (set) Token: 0x06000C9C RID: 3228 RVA: 0x00033313 File Offset: 0x00031513
	public unsafe static WaitForFixedUpdate _WaitFixedUpdate_k__BackingField
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr__WaitFixedUpdate_k__BackingField, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new WaitForFixedUpdate(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr__WaitFixedUpdate_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000458 RID: 1112
	// (get) Token: 0x06000C9D RID: 3229 RVA: 0x00033328 File Offset: 0x00031528
	// (set) Token: 0x06000C9E RID: 3230 RVA: 0x00033353 File Offset: 0x00031553
	public unsafe static Dictionary<int, WaitForSeconds> _waitForSecondsDict
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr__waitForSecondsDict, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<int, WaitForSeconds>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr__waitForSecondsDict, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000459 RID: 1113
	// (get) Token: 0x06000C9F RID: 3231 RVA: 0x00033368 File Offset: 0x00031568
	// (set) Token: 0x06000CA0 RID: 3232 RVA: 0x00033393 File Offset: 0x00031593
	public unsafe static Dictionary<int, WaitForSecondsRealtime> _waitForSecondsRealtimeDict
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr__waitForSecondsRealtimeDict, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<int, WaitForSecondsRealtime>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr__waitForSecondsRealtimeDict, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700045A RID: 1114
	// (get) Token: 0x06000CA1 RID: 3233 RVA: 0x000333A8 File Offset: 0x000315A8
	// (set) Token: 0x06000CA2 RID: 3234 RVA: 0x000333D3 File Offset: 0x000315D3
	public unsafe static List<WaitForSecondsNetwork> WaitForSecondsNetworkPool
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr_WaitForSecondsNetworkPool, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<WaitForSecondsNetwork>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr_WaitForSecondsNetworkPool, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700045B RID: 1115
	// (get) Token: 0x06000CA3 RID: 3235 RVA: 0x000333E8 File Offset: 0x000315E8
	// (set) Token: 0x06000CA4 RID: 3236 RVA: 0x00033413 File Offset: 0x00031613
	public unsafe static List<WaitForPermission> WaitPermissionPool
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CoroutineUtility.NativeFieldInfoPtr_WaitPermissionPool, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<WaitForPermission>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CoroutineUtility.NativeFieldInfoPtr_WaitPermissionPool, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000796 RID: 1942
	private static readonly IntPtr NativeFieldInfoPtr__WaitEndOfFrame_k__BackingField;

	// Token: 0x04000797 RID: 1943
	private static readonly IntPtr NativeFieldInfoPtr__WaitFixedUpdate_k__BackingField;

	// Token: 0x04000798 RID: 1944
	private static readonly IntPtr NativeFieldInfoPtr__waitForSecondsDict;

	// Token: 0x04000799 RID: 1945
	private static readonly IntPtr NativeFieldInfoPtr__waitForSecondsRealtimeDict;

	// Token: 0x0400079A RID: 1946
	private static readonly IntPtr NativeFieldInfoPtr_WaitForSecondsNetworkPool;

	// Token: 0x0400079B RID: 1947
	private static readonly IntPtr NativeFieldInfoPtr_WaitPermissionPool;

	// Token: 0x0400079C RID: 1948
	private static readonly IntPtr NativeMethodInfoPtr_get_WaitEndOfFrame_Public_Static_get_WaitForEndOfFrame_0;

	// Token: 0x0400079D RID: 1949
	private static readonly IntPtr NativeMethodInfoPtr_set_WaitEndOfFrame_Private_Static_set_Void_WaitForEndOfFrame_0;

	// Token: 0x0400079E RID: 1950
	private static readonly IntPtr NativeMethodInfoPtr_get_WaitFixedUpdate_Public_Static_get_WaitForFixedUpdate_0;

	// Token: 0x0400079F RID: 1951
	private static readonly IntPtr NativeMethodInfoPtr_set_WaitFixedUpdate_Private_Static_set_Void_WaitForFixedUpdate_0;

	// Token: 0x040007A0 RID: 1952
	private static readonly IntPtr NativeMethodInfoPtr_WaitSeconds_Public_Static_WaitForSeconds_Single_0;

	// Token: 0x040007A1 RID: 1953
	private static readonly IntPtr NativeMethodInfoPtr_WaitSecondsRealtime_Public_Static_WaitForSecondsRealtime_Single_0;

	// Token: 0x040007A2 RID: 1954
	private static readonly IntPtr NativeMethodInfoPtr_WaitSecondsNetwork_Public_Static_WaitForSecondsNetwork_byref_Double_0;

	// Token: 0x040007A3 RID: 1955
	private static readonly IntPtr NativeMethodInfoPtr_WaitPermission_Public_Static_WaitForPermission_String_0;
}
