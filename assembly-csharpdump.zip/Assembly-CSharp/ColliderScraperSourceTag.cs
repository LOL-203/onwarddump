﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000181 RID: 385
public class ColliderScraperSourceTag : MonoBehaviour
{
	// Token: 0x060019D7 RID: 6615 RVA: 0x00067008 File Offset: 0x00065208
	[CallerCount(0)]
	public unsafe ColliderScraperSourceTag() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ColliderScraperSourceTag>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColliderScraperSourceTag.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019D8 RID: 6616 RVA: 0x00067053 File Offset: 0x00065253
	// Note: this type is marked as 'beforefieldinit'.
	static ColliderScraperSourceTag()
	{
		Il2CppClassPointerStore<ColliderScraperSourceTag>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ColliderScraperSourceTag");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColliderScraperSourceTag>.NativeClassPtr);
		ColliderScraperSourceTag.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColliderScraperSourceTag>.NativeClassPtr, 100665350);
	}

	// Token: 0x060019D9 RID: 6617 RVA: 0x0000210C File Offset: 0x0000030C
	public ColliderScraperSourceTag(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170008F7 RID: 2295
	// (get) Token: 0x060019DA RID: 6618 RVA: 0x0006708C File Offset: 0x0006528C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColliderScraperSourceTag>.NativeClassPtr));
		}
	}

	// Token: 0x04001092 RID: 4242
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
