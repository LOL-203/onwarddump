﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200005A RID: 90
public class CustomDebugUI : MonoBehaviour
{
	// Token: 0x060005A1 RID: 1441 RVA: 0x00018C70 File Offset: 0x00016E70
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x00018CB4 File Offset: 0x00016EB4
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00018CF8 File Offset: 0x00016EF8
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x00018D3C File Offset: 0x00016F3C
	[CallerCount(0)]
	public unsafe RectTransform AddTextField(string label, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(label);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x00018DBC File Offset: 0x00016FBC
	[CallerCount(0)]
	public unsafe void RemoveFromCanvas(RectTransform element, [Optional] int targetCanvas)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(element);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetCanvas;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr_RemoveFromCanvas_Public_Void_RectTransform_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x00018E28 File Offset: 0x00017028
	[CallerCount(0)]
	public unsafe CustomDebugUI() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomDebugUI.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x00018E74 File Offset: 0x00017074
	// Note: this type is marked as 'beforefieldinit'.
	static CustomDebugUI()
	{
		Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomDebugUI");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr);
		CustomDebugUI.NativeFieldInfoPtr_textPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, "textPrefab");
		CustomDebugUI.NativeFieldInfoPtr_instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, "instance");
		CustomDebugUI.NativeFieldInfoPtr_privateFlags = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, "privateFlags");
		CustomDebugUI.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663778);
		CustomDebugUI.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663779);
		CustomDebugUI.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663780);
		CustomDebugUI.NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663781);
		CustomDebugUI.NativeMethodInfoPtr_RemoveFromCanvas_Public_Void_RectTransform_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663782);
		CustomDebugUI.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr, 100663783);
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x0000210C File Offset: 0x0000030C
	public CustomDebugUI(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170001EA RID: 490
	// (get) Token: 0x060005A9 RID: 1449 RVA: 0x00018F58 File Offset: 0x00017158
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomDebugUI>.NativeClassPtr));
		}
	}

	// Token: 0x170001EB RID: 491
	// (get) Token: 0x060005AA RID: 1450 RVA: 0x00018F6C File Offset: 0x0001716C
	// (set) Token: 0x060005AB RID: 1451 RVA: 0x00018FA0 File Offset: 0x000171A0
	public unsafe RectTransform textPrefab
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomDebugUI.NativeFieldInfoPtr_textPrefab);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new RectTransform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomDebugUI.NativeFieldInfoPtr_textPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170001EC RID: 492
	// (get) Token: 0x060005AC RID: 1452 RVA: 0x00018FC8 File Offset: 0x000171C8
	// (set) Token: 0x060005AD RID: 1453 RVA: 0x00018FF3 File Offset: 0x000171F3
	public unsafe static CustomDebugUI instance
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CustomDebugUI.NativeFieldInfoPtr_instance, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new CustomDebugUI(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomDebugUI.NativeFieldInfoPtr_instance, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170001ED RID: 493
	// (get) Token: 0x060005AE RID: 1454 RVA: 0x00019008 File Offset: 0x00017208
	// (set) Token: 0x060005AF RID: 1455 RVA: 0x00019026 File Offset: 0x00017226
	public unsafe static BindingFlags privateFlags
	{
		get
		{
			BindingFlags result;
			IL2CPP.il2cpp_field_static_get_value(CustomDebugUI.NativeFieldInfoPtr_privateFlags, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomDebugUI.NativeFieldInfoPtr_privateFlags, (void*)(&value));
		}
	}

	// Token: 0x0400038D RID: 909
	private static readonly IntPtr NativeFieldInfoPtr_textPrefab;

	// Token: 0x0400038E RID: 910
	private static readonly IntPtr NativeFieldInfoPtr_instance;

	// Token: 0x0400038F RID: 911
	private static readonly IntPtr NativeFieldInfoPtr_privateFlags;

	// Token: 0x04000390 RID: 912
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04000391 RID: 913
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000392 RID: 914
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04000393 RID: 915
	private static readonly IntPtr NativeMethodInfoPtr_AddTextField_Public_RectTransform_String_Int32_0;

	// Token: 0x04000394 RID: 916
	private static readonly IntPtr NativeMethodInfoPtr_RemoveFromCanvas_Public_Void_RectTransform_Int32_0;

	// Token: 0x04000395 RID: 917
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
