﻿using System;

// Token: 0x020004EB RID: 1259
public enum AmmoType
{
	// Token: 0x04004075 RID: 16501
	NULL,
	// Token: 0x04004076 RID: 16502
	Brass9mm,
	// Token: 0x04004077 RID: 16503
	Brass45ACP,
	// Token: 0x04004078 RID: 16504
	Brass556,
	// Token: 0x04004079 RID: 16505
	Brass762,
	// Token: 0x0400407A RID: 16506
	Brass762x39,
	// Token: 0x0400407B RID: 16507
	Link,
	// Token: 0x0400407C RID: 16508
	Shotgun
}
