﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using Onward.CustomContent.Assets;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000143 RID: 323
public class CustomContentAmbientAudioEmitter : MonoBehaviour
{
	// Token: 0x17000753 RID: 1875
	// (get) Token: 0x06001533 RID: 5427 RVA: 0x00055AFC File Offset: 0x00053CFC
	// (set) Token: 0x06001534 RID: 5428 RVA: 0x00055B4C File Offset: 0x00053D4C
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06001535 RID: 5429 RVA: 0x00055BA0 File Offset: 0x00053DA0
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001536 RID: 5430 RVA: 0x00055BE4 File Offset: 0x00053DE4
	[CallerCount(0)]
	public unsafe void ImportAudioCLipData(AudioClip clip, bool normalize)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(clip);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref normalize;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_ImportAudioCLipData_Public_Void_AudioClip_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001537 RID: 5431 RVA: 0x00055C50 File Offset: 0x00053E50
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001538 RID: 5432 RVA: 0x00055C94 File Offset: 0x00053E94
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001539 RID: 5433 RVA: 0x00055CD8 File Offset: 0x00053ED8
	[CallerCount(0)]
	public unsafe IEnumerator PostPlayDelayed()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x0600153A RID: 5434 RVA: 0x00055D30 File Offset: 0x00053F30
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600153B RID: 5435 RVA: 0x00055D74 File Offset: 0x00053F74
	[CallerCount(0)]
	public unsafe void InternalStop()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_InternalStop_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600153C RID: 5436 RVA: 0x00055DB8 File Offset: 0x00053FB8
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600153D RID: 5437 RVA: 0x00055DFC File Offset: 0x00053FFC
	[CallerCount(0)]
	public unsafe bool AudioEmitterAudioSamplesDelegate(uint playingID, uint channelIndex, Il2CppStructArray<float> samples)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref playingID;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref channelIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(samples);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_AudioEmitterAudioSamplesDelegate_Private_Boolean_UInt32_UInt32_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x0600153E RID: 5438 RVA: 0x00055E8C File Offset: 0x0005408C
	[CallerCount(0)]
	public unsafe void AudioEmitterAudioFormatDelegate(uint playingID, AkAudioFormat format)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref playingID;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(format);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_AudioEmitterAudioFormatDelegate_Private_Void_UInt32_AkAudioFormat_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600153F RID: 5439 RVA: 0x00055EF8 File Offset: 0x000540F8
	[CallerCount(0)]
	public unsafe CustomContentAmbientAudioEmitter() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001540 RID: 5440 RVA: 0x00055F44 File Offset: 0x00054144
	// Note: this type is marked as 'beforefieldinit'.
	static CustomContentAmbientAudioEmitter()
	{
		Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomContentAmbientAudioEmitter");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr);
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Loop = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "Loop");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "Is3DSound");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "PreDelaySeconds");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Volume = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "Volume");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_AttenuationType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "AttenuationType");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_OutdoornessType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "OutdoornessType");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "wasPlayEventPosted");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_isInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "isInitialized");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_playEventToUse = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "playEventToUse");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_stopEventToUse = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "stopEventToUse");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_attenuationSwitchToUse = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "attenuationSwitchToUse");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleRate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "sampleRate");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "sampleCount");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelReadPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "channelReadPosition");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelSampleData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "channelSampleData");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasValidAudioData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "hasValidAudioData");
		CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasAudioStreamEnded = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "hasAudioStreamEnded");
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665029);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665030);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665031);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_ImportAudioCLipData_Public_Void_AudioClip_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665032);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665033);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665034);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665035);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665036);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_InternalStop_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665037);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665038);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_AudioEmitterAudioSamplesDelegate_Private_Boolean_UInt32_UInt32_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665039);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr_AudioEmitterAudioFormatDelegate_Private_Void_UInt32_AkAudioFormat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665040);
		CustomContentAmbientAudioEmitter.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, 100665041);
	}

	// Token: 0x06001541 RID: 5441 RVA: 0x0000210C File Offset: 0x0000030C
	public CustomContentAmbientAudioEmitter(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000740 RID: 1856
	// (get) Token: 0x06001542 RID: 5442 RVA: 0x000561E0 File Offset: 0x000543E0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr));
		}
	}

	// Token: 0x17000741 RID: 1857
	// (get) Token: 0x06001543 RID: 5443 RVA: 0x000561F4 File Offset: 0x000543F4
	// (set) Token: 0x06001544 RID: 5444 RVA: 0x0005621C File Offset: 0x0005441C
	public unsafe bool Loop
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Loop);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Loop)) = value;
		}
	}

	// Token: 0x17000742 RID: 1858
	// (get) Token: 0x06001545 RID: 5445 RVA: 0x00056240 File Offset: 0x00054440
	// (set) Token: 0x06001546 RID: 5446 RVA: 0x00056268 File Offset: 0x00054468
	public unsafe bool Is3DSound
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Is3DSound)) = value;
		}
	}

	// Token: 0x17000743 RID: 1859
	// (get) Token: 0x06001547 RID: 5447 RVA: 0x0005628C File Offset: 0x0005448C
	// (set) Token: 0x06001548 RID: 5448 RVA: 0x000562B4 File Offset: 0x000544B4
	public unsafe float PreDelaySeconds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_PreDelaySeconds)) = value;
		}
	}

	// Token: 0x17000744 RID: 1860
	// (get) Token: 0x06001549 RID: 5449 RVA: 0x000562D8 File Offset: 0x000544D8
	// (set) Token: 0x0600154A RID: 5450 RVA: 0x00056300 File Offset: 0x00054500
	public unsafe float Volume
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Volume);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_Volume)) = value;
		}
	}

	// Token: 0x17000745 RID: 1861
	// (get) Token: 0x0600154B RID: 5451 RVA: 0x00056324 File Offset: 0x00054524
	// (set) Token: 0x0600154C RID: 5452 RVA: 0x0005634C File Offset: 0x0005454C
	public unsafe OnwardAudioAttenuationType AttenuationType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_AttenuationType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_AttenuationType)) = value;
		}
	}

	// Token: 0x17000746 RID: 1862
	// (get) Token: 0x0600154D RID: 5453 RVA: 0x00056370 File Offset: 0x00054570
	// (set) Token: 0x0600154E RID: 5454 RVA: 0x00056398 File Offset: 0x00054598
	public unsafe OnwardAudioOutdoornessType OutdoornessType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_OutdoornessType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_OutdoornessType)) = value;
		}
	}

	// Token: 0x17000747 RID: 1863
	// (get) Token: 0x0600154F RID: 5455 RVA: 0x000563BC File Offset: 0x000545BC
	// (set) Token: 0x06001550 RID: 5456 RVA: 0x000563E4 File Offset: 0x000545E4
	public unsafe bool wasPlayEventPosted
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_wasPlayEventPosted)) = value;
		}
	}

	// Token: 0x17000748 RID: 1864
	// (get) Token: 0x06001551 RID: 5457 RVA: 0x00056408 File Offset: 0x00054608
	// (set) Token: 0x06001552 RID: 5458 RVA: 0x00056430 File Offset: 0x00054630
	public unsafe bool isInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_isInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_isInitialized)) = value;
		}
	}

	// Token: 0x17000749 RID: 1865
	// (get) Token: 0x06001553 RID: 5459 RVA: 0x00056454 File Offset: 0x00054654
	// (set) Token: 0x06001554 RID: 5460 RVA: 0x0005647C File Offset: 0x0005467C
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x1700074A RID: 1866
	// (get) Token: 0x06001555 RID: 5461 RVA: 0x000564A0 File Offset: 0x000546A0
	// (set) Token: 0x06001556 RID: 5462 RVA: 0x000564C8 File Offset: 0x000546C8
	public unsafe uint playEventToUse
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_playEventToUse);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_playEventToUse)) = value;
		}
	}

	// Token: 0x1700074B RID: 1867
	// (get) Token: 0x06001557 RID: 5463 RVA: 0x000564EC File Offset: 0x000546EC
	// (set) Token: 0x06001558 RID: 5464 RVA: 0x00056514 File Offset: 0x00054714
	public unsafe uint stopEventToUse
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_stopEventToUse);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_stopEventToUse)) = value;
		}
	}

	// Token: 0x1700074C RID: 1868
	// (get) Token: 0x06001559 RID: 5465 RVA: 0x00056538 File Offset: 0x00054738
	// (set) Token: 0x0600155A RID: 5466 RVA: 0x00056560 File Offset: 0x00054760
	public unsafe uint attenuationSwitchToUse
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_attenuationSwitchToUse);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_attenuationSwitchToUse)) = value;
		}
	}

	// Token: 0x1700074D RID: 1869
	// (get) Token: 0x0600155B RID: 5467 RVA: 0x00056584 File Offset: 0x00054784
	// (set) Token: 0x0600155C RID: 5468 RVA: 0x000565AC File Offset: 0x000547AC
	public unsafe int sampleRate
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleRate);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleRate)) = value;
		}
	}

	// Token: 0x1700074E RID: 1870
	// (get) Token: 0x0600155D RID: 5469 RVA: 0x000565D0 File Offset: 0x000547D0
	// (set) Token: 0x0600155E RID: 5470 RVA: 0x000565F8 File Offset: 0x000547F8
	public unsafe int sampleCount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleCount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_sampleCount)) = value;
		}
	}

	// Token: 0x1700074F RID: 1871
	// (get) Token: 0x0600155F RID: 5471 RVA: 0x0005661C File Offset: 0x0005481C
	// (set) Token: 0x06001560 RID: 5472 RVA: 0x00056650 File Offset: 0x00054850
	public unsafe List<int> channelReadPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelReadPosition);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<int>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelReadPosition), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000750 RID: 1872
	// (get) Token: 0x06001561 RID: 5473 RVA: 0x00056678 File Offset: 0x00054878
	// (set) Token: 0x06001562 RID: 5474 RVA: 0x000566AC File Offset: 0x000548AC
	public unsafe List<Il2CppStructArray<float>> channelSampleData
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelSampleData);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Il2CppStructArray<float>>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_channelSampleData), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000751 RID: 1873
	// (get) Token: 0x06001563 RID: 5475 RVA: 0x000566D4 File Offset: 0x000548D4
	// (set) Token: 0x06001564 RID: 5476 RVA: 0x000566FC File Offset: 0x000548FC
	public unsafe bool hasValidAudioData
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasValidAudioData);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasValidAudioData)) = value;
		}
	}

	// Token: 0x17000752 RID: 1874
	// (get) Token: 0x06001565 RID: 5477 RVA: 0x00056720 File Offset: 0x00054920
	// (set) Token: 0x06001566 RID: 5478 RVA: 0x00056748 File Offset: 0x00054948
	public unsafe bool hasAudioStreamEnded
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasAudioStreamEnded);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter.NativeFieldInfoPtr_hasAudioStreamEnded)) = value;
		}
	}

	// Token: 0x04000D7F RID: 3455
	private static readonly IntPtr NativeFieldInfoPtr_Loop;

	// Token: 0x04000D80 RID: 3456
	private static readonly IntPtr NativeFieldInfoPtr_Is3DSound;

	// Token: 0x04000D81 RID: 3457
	private static readonly IntPtr NativeFieldInfoPtr_PreDelaySeconds;

	// Token: 0x04000D82 RID: 3458
	private static readonly IntPtr NativeFieldInfoPtr_Volume;

	// Token: 0x04000D83 RID: 3459
	private static readonly IntPtr NativeFieldInfoPtr_AttenuationType;

	// Token: 0x04000D84 RID: 3460
	private static readonly IntPtr NativeFieldInfoPtr_OutdoornessType;

	// Token: 0x04000D85 RID: 3461
	private static readonly IntPtr NativeFieldInfoPtr_wasPlayEventPosted;

	// Token: 0x04000D86 RID: 3462
	private static readonly IntPtr NativeFieldInfoPtr_isInitialized;

	// Token: 0x04000D87 RID: 3463
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x04000D88 RID: 3464
	private static readonly IntPtr NativeFieldInfoPtr_playEventToUse;

	// Token: 0x04000D89 RID: 3465
	private static readonly IntPtr NativeFieldInfoPtr_stopEventToUse;

	// Token: 0x04000D8A RID: 3466
	private static readonly IntPtr NativeFieldInfoPtr_attenuationSwitchToUse;

	// Token: 0x04000D8B RID: 3467
	private static readonly IntPtr NativeFieldInfoPtr_sampleRate;

	// Token: 0x04000D8C RID: 3468
	private static readonly IntPtr NativeFieldInfoPtr_sampleCount;

	// Token: 0x04000D8D RID: 3469
	private static readonly IntPtr NativeFieldInfoPtr_channelReadPosition;

	// Token: 0x04000D8E RID: 3470
	private static readonly IntPtr NativeFieldInfoPtr_channelSampleData;

	// Token: 0x04000D8F RID: 3471
	private static readonly IntPtr NativeFieldInfoPtr_hasValidAudioData;

	// Token: 0x04000D90 RID: 3472
	private static readonly IntPtr NativeFieldInfoPtr_hasAudioStreamEnded;

	// Token: 0x04000D91 RID: 3473
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04000D92 RID: 3474
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x04000D93 RID: 3475
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04000D94 RID: 3476
	private static readonly IntPtr NativeMethodInfoPtr_ImportAudioCLipData_Public_Void_AudioClip_Boolean_0;

	// Token: 0x04000D95 RID: 3477
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04000D96 RID: 3478
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04000D97 RID: 3479
	private static readonly IntPtr NativeMethodInfoPtr_PostPlayDelayed_Public_IEnumerator_0;

	// Token: 0x04000D98 RID: 3480
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04000D99 RID: 3481
	private static readonly IntPtr NativeMethodInfoPtr_InternalStop_Private_Void_0;

	// Token: 0x04000D9A RID: 3482
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04000D9B RID: 3483
	private static readonly IntPtr NativeMethodInfoPtr_AudioEmitterAudioSamplesDelegate_Private_Boolean_UInt32_UInt32_ArrayOf_Single_0;

	// Token: 0x04000D9C RID: 3484
	private static readonly IntPtr NativeMethodInfoPtr_AudioEmitterAudioFormatDelegate_Private_Void_UInt32_AkAudioFormat_0;

	// Token: 0x04000D9D RID: 3485
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000144 RID: 324
	[ObfuscatedName("CustomContentAmbientAudioEmitter/<PostPlayDelayed>d__25")]
	public sealed class _PostPlayDelayed_d__25 : Il2CppSystem.Object
	{
		// Token: 0x06001567 RID: 5479 RVA: 0x0005676C File Offset: 0x0005496C
		[CallerCount(0)]
		public unsafe _PostPlayDelayed_d__25(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001568 RID: 5480 RVA: 0x000567CC File Offset: 0x000549CC
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06001569 RID: 5481 RVA: 0x00056810 File Offset: 0x00054A10
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17000758 RID: 1880
		// (get) Token: 0x0600156A RID: 5482 RVA: 0x00056860 File Offset: 0x00054A60
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600156B RID: 5483 RVA: 0x000568B8 File Offset: 0x00054AB8
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17000759 RID: 1881
		// (get) Token: 0x0600156C RID: 5484 RVA: 0x000568FC File Offset: 0x00054AFC
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600156D RID: 5485 RVA: 0x00056954 File Offset: 0x00054B54
		// Note: this type is marked as 'beforefieldinit'.
		static _PostPlayDelayed_d__25()
		{
			Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter>.NativeClassPtr, "<PostPlayDelayed>d__25");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, "<>1__state");
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, "<>2__current");
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, "<>4__this");
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665042);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665043);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665044);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665045);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665046);
			CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr, 100665047);
		}

		// Token: 0x0600156E RID: 5486 RVA: 0x00002988 File Offset: 0x00000B88
		public _PostPlayDelayed_d__25(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000754 RID: 1876
		// (get) Token: 0x0600156F RID: 5487 RVA: 0x00056A33 File Offset: 0x00054C33
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25>.NativeClassPtr));
			}
		}

		// Token: 0x17000755 RID: 1877
		// (get) Token: 0x06001570 RID: 5488 RVA: 0x00056A44 File Offset: 0x00054C44
		// (set) Token: 0x06001571 RID: 5489 RVA: 0x00056A6C File Offset: 0x00054C6C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17000756 RID: 1878
		// (get) Token: 0x06001572 RID: 5490 RVA: 0x00056A90 File Offset: 0x00054C90
		// (set) Token: 0x06001573 RID: 5491 RVA: 0x00056AC4 File Offset: 0x00054CC4
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000757 RID: 1879
		// (get) Token: 0x06001574 RID: 5492 RVA: 0x00056AEC File Offset: 0x00054CEC
		// (set) Token: 0x06001575 RID: 5493 RVA: 0x00056B20 File Offset: 0x00054D20
		public unsafe CustomContentAmbientAudioEmitter __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CustomContentAmbientAudioEmitter(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentAmbientAudioEmitter._PostPlayDelayed_d__25.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000D9E RID: 3486
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04000D9F RID: 3487
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04000DA0 RID: 3488
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04000DA1 RID: 3489
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000DA2 RID: 3490
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000DA3 RID: 3491
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04000DA4 RID: 3492
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04000DA5 RID: 3493
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04000DA6 RID: 3494
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
