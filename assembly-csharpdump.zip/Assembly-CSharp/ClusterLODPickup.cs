﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003A8 RID: 936
public class ClusterLODPickup : MonoBehaviour
{
	// Token: 0x06004A94 RID: 19092 RVA: 0x0012AFF4 File Offset: 0x001291F4
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr_OnEnable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A95 RID: 19093 RVA: 0x0012B038 File Offset: 0x00129238
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr_OnDisable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A96 RID: 19094 RVA: 0x0012B07C File Offset: 0x0012927C
	[CallerCount(0)]
	public unsafe void OnEffectsContextChanged(Pickup.EffectsContext context)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref context;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr_OnEffectsContextChanged_Protected_Void_EffectsContext_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A97 RID: 19095 RVA: 0x0012B0D0 File Offset: 0x001292D0
	[CallerCount(0)]
	public unsafe void RefreshLODs(bool force = false)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref force;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr_RefreshLODs_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A98 RID: 19096 RVA: 0x0012B124 File Offset: 0x00129324
	[CallerCount(0)]
	public unsafe bool IsPickupFirst()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr_IsPickupFirst_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06004A99 RID: 19097 RVA: 0x0012B174 File Offset: 0x00129374
	[CallerCount(0)]
	public unsafe ClusterLODPickup() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODPickup.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A9A RID: 19098 RVA: 0x0012B1C0 File Offset: 0x001293C0
	// Note: this type is marked as 'beforefieldinit'.
	static ClusterLODPickup()
	{
		Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ClusterLODPickup");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr);
		ClusterLODPickup.NativeFieldInfoPtr_FirstLOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "FirstLOD");
		ClusterLODPickup.NativeFieldInfoPtr_ThirdLOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "ThirdLOD");
		ClusterLODPickup.NativeFieldInfoPtr_Pickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "Pickup");
		ClusterLODPickup.NativeFieldInfoPtr_OriginalLOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "OriginalLOD");
		ClusterLODPickup.NativeFieldInfoPtr_isFirst = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "isFirst");
		ClusterLODPickup.NativeFieldInfoPtr_FIRST_LOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "FIRST_LOD");
		ClusterLODPickup.NativeFieldInfoPtr_THIRD_LOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, "THIRD_LOD");
		ClusterLODPickup.NativeMethodInfoPtr_OnEnable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669161);
		ClusterLODPickup.NativeMethodInfoPtr_OnDisable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669162);
		ClusterLODPickup.NativeMethodInfoPtr_OnEffectsContextChanged_Protected_Void_EffectsContext_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669163);
		ClusterLODPickup.NativeMethodInfoPtr_RefreshLODs_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669164);
		ClusterLODPickup.NativeMethodInfoPtr_IsPickupFirst_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669165);
		ClusterLODPickup.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr, 100669166);
	}

	// Token: 0x06004A9B RID: 19099 RVA: 0x0000210C File Offset: 0x0000030C
	public ClusterLODPickup(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001AAC RID: 6828
	// (get) Token: 0x06004A9C RID: 19100 RVA: 0x0012B2F4 File Offset: 0x001294F4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClusterLODPickup>.NativeClassPtr));
		}
	}

	// Token: 0x17001AAD RID: 6829
	// (get) Token: 0x06004A9D RID: 19101 RVA: 0x0012B308 File Offset: 0x00129508
	// (set) Token: 0x06004A9E RID: 19102 RVA: 0x0012B33C File Offset: 0x0012953C
	public unsafe LODGroup FirstLOD
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_FirstLOD);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_FirstLOD), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AAE RID: 6830
	// (get) Token: 0x06004A9F RID: 19103 RVA: 0x0012B364 File Offset: 0x00129564
	// (set) Token: 0x06004AA0 RID: 19104 RVA: 0x0012B398 File Offset: 0x00129598
	public unsafe LODGroup ThirdLOD
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_ThirdLOD);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_ThirdLOD), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AAF RID: 6831
	// (get) Token: 0x06004AA1 RID: 19105 RVA: 0x0012B3C0 File Offset: 0x001295C0
	// (set) Token: 0x06004AA2 RID: 19106 RVA: 0x0012B3F4 File Offset: 0x001295F4
	public unsafe Pickup Pickup
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_Pickup);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_Pickup), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AB0 RID: 6832
	// (get) Token: 0x06004AA3 RID: 19107 RVA: 0x0012B41C File Offset: 0x0012961C
	// (set) Token: 0x06004AA4 RID: 19108 RVA: 0x0012B450 File Offset: 0x00129650
	public unsafe LODGroup OriginalLOD
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_OriginalLOD);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_OriginalLOD), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AB1 RID: 6833
	// (get) Token: 0x06004AA5 RID: 19109 RVA: 0x0012B478 File Offset: 0x00129678
	// (set) Token: 0x06004AA6 RID: 19110 RVA: 0x0012B4A0 File Offset: 0x001296A0
	public unsafe bool isFirst
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_isFirst);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODPickup.NativeFieldInfoPtr_isFirst)) = value;
		}
	}

	// Token: 0x17001AB2 RID: 6834
	// (get) Token: 0x06004AA7 RID: 19111 RVA: 0x0012B4C4 File Offset: 0x001296C4
	// (set) Token: 0x06004AA8 RID: 19112 RVA: 0x0012B4E4 File Offset: 0x001296E4
	public unsafe static string FIRST_LOD
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClusterLODPickup.NativeFieldInfoPtr_FIRST_LOD, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClusterLODPickup.NativeFieldInfoPtr_FIRST_LOD, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001AB3 RID: 6835
	// (get) Token: 0x06004AA9 RID: 19113 RVA: 0x0012B4FC File Offset: 0x001296FC
	// (set) Token: 0x06004AAA RID: 19114 RVA: 0x0012B51C File Offset: 0x0012971C
	public unsafe static string THIRD_LOD
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClusterLODPickup.NativeFieldInfoPtr_THIRD_LOD, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClusterLODPickup.NativeFieldInfoPtr_THIRD_LOD, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x04002F8F RID: 12175
	private static readonly IntPtr NativeFieldInfoPtr_FirstLOD;

	// Token: 0x04002F90 RID: 12176
	private static readonly IntPtr NativeFieldInfoPtr_ThirdLOD;

	// Token: 0x04002F91 RID: 12177
	private static readonly IntPtr NativeFieldInfoPtr_Pickup;

	// Token: 0x04002F92 RID: 12178
	private static readonly IntPtr NativeFieldInfoPtr_OriginalLOD;

	// Token: 0x04002F93 RID: 12179
	private static readonly IntPtr NativeFieldInfoPtr_isFirst;

	// Token: 0x04002F94 RID: 12180
	private static readonly IntPtr NativeFieldInfoPtr_FIRST_LOD;

	// Token: 0x04002F95 RID: 12181
	private static readonly IntPtr NativeFieldInfoPtr_THIRD_LOD;

	// Token: 0x04002F96 RID: 12182
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Void_0;

	// Token: 0x04002F97 RID: 12183
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Protected_Void_0;

	// Token: 0x04002F98 RID: 12184
	private static readonly IntPtr NativeMethodInfoPtr_OnEffectsContextChanged_Protected_Void_EffectsContext_0;

	// Token: 0x04002F99 RID: 12185
	private static readonly IntPtr NativeMethodInfoPtr_RefreshLODs_Protected_Void_Boolean_0;

	// Token: 0x04002F9A RID: 12186
	private static readonly IntPtr NativeMethodInfoPtr_IsPickupFirst_Protected_Boolean_0;

	// Token: 0x04002F9B RID: 12187
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
