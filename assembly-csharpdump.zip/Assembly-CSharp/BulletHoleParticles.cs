﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004F0 RID: 1264
public class BulletHoleParticles : MonoBehaviour
{
	// Token: 0x17002488 RID: 9352
	// (get) Token: 0x060066E3 RID: 26339 RVA: 0x0019D3A0 File Offset: 0x0019B5A0
	public unsafe int RandomDirtIndex
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_get_RandomDirtIndex_Protected_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002489 RID: 9353
	// (get) Token: 0x060066E4 RID: 26340 RVA: 0x0019D3F0 File Offset: 0x0019B5F0
	public unsafe int RandomWoodIndex
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_get_RandomWoodIndex_Protected_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700248A RID: 9354
	// (get) Token: 0x060066E5 RID: 26341 RVA: 0x0019D440 File Offset: 0x0019B640
	public unsafe int RandomMetalIndex
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_get_RandomMetalIndex_Protected_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700248B RID: 9355
	// (get) Token: 0x060066E6 RID: 26342 RVA: 0x0019D490 File Offset: 0x0019B690
	public unsafe int RandomConcreteIndex
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_get_RandomConcreteIndex_Protected_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700248C RID: 9356
	// (get) Token: 0x060066E7 RID: 26343 RVA: 0x0019D4E0 File Offset: 0x0019B6E0
	public unsafe int RandomGlassIndex
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_get_RandomGlassIndex_Protected_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x060066E8 RID: 26344 RVA: 0x0019D530 File Offset: 0x0019B730
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_Awake_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066E9 RID: 26345 RVA: 0x0019D574 File Offset: 0x0019B774
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_OnDestroy_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066EA RID: 26346 RVA: 0x0019D5B8 File Offset: 0x0019B7B8
	[CallerCount(0)]
	public unsafe void Spawn(BulletHoleParticles.BulletHoleParticleType type, Vector3 position, Vector3 normal, int hitLayer)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref type;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref normal;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hitLayer;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr_Spawn_Public_Void_BulletHoleParticleType_Vector3_Vector3_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066EB RID: 26347 RVA: 0x0019D648 File Offset: 0x0019B848
	[CallerCount(0)]
	public unsafe BulletHoleParticles() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHoleParticles.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066EC RID: 26348 RVA: 0x0019D694 File Offset: 0x0019B894
	// Note: this type is marked as 'beforefieldinit'.
	static BulletHoleParticles()
	{
		Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BulletHoleParticles");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr);
		BulletHoleParticles.NativeFieldInfoPtr_Singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, "Singleton");
		BulletHoleParticles.NativeFieldInfoPtr_System = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, "System");
		BulletHoleParticles.NativeFieldInfoPtr_ExclusionMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, "ExclusionMask");
		BulletHoleParticles.NativeFieldInfoPtr_parameters = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, "parameters");
		BulletHoleParticles.NativeFieldInfoPtr_customData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, "customData");
		BulletHoleParticles.NativeMethodInfoPtr_get_RandomDirtIndex_Protected_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671475);
		BulletHoleParticles.NativeMethodInfoPtr_get_RandomWoodIndex_Protected_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671476);
		BulletHoleParticles.NativeMethodInfoPtr_get_RandomMetalIndex_Protected_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671477);
		BulletHoleParticles.NativeMethodInfoPtr_get_RandomConcreteIndex_Protected_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671478);
		BulletHoleParticles.NativeMethodInfoPtr_get_RandomGlassIndex_Protected_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671479);
		BulletHoleParticles.NativeMethodInfoPtr_Awake_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671480);
		BulletHoleParticles.NativeMethodInfoPtr_OnDestroy_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671481);
		BulletHoleParticles.NativeMethodInfoPtr_Spawn_Public_Void_BulletHoleParticleType_Vector3_Vector3_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671482);
		BulletHoleParticles.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr, 100671483);
	}

	// Token: 0x060066ED RID: 26349 RVA: 0x0000210C File Offset: 0x0000030C
	public BulletHoleParticles(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002482 RID: 9346
	// (get) Token: 0x060066EE RID: 26350 RVA: 0x0019D7DC File Offset: 0x0019B9DC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BulletHoleParticles>.NativeClassPtr));
		}
	}

	// Token: 0x17002483 RID: 9347
	// (get) Token: 0x060066EF RID: 26351 RVA: 0x0019D7F0 File Offset: 0x0019B9F0
	// (set) Token: 0x060066F0 RID: 26352 RVA: 0x0019D81B File Offset: 0x0019BA1B
	public unsafe static BulletHoleParticles Singleton
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(BulletHoleParticles.NativeFieldInfoPtr_Singleton, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new BulletHoleParticles(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BulletHoleParticles.NativeFieldInfoPtr_Singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002484 RID: 9348
	// (get) Token: 0x060066F1 RID: 26353 RVA: 0x0019D830 File Offset: 0x0019BA30
	// (set) Token: 0x060066F2 RID: 26354 RVA: 0x0019D864 File Offset: 0x0019BA64
	public unsafe ParticleSystem System
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_System);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ParticleSystem(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_System), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002485 RID: 9349
	// (get) Token: 0x060066F3 RID: 26355 RVA: 0x0019D88C File Offset: 0x0019BA8C
	// (set) Token: 0x060066F4 RID: 26356 RVA: 0x0019D8B4 File Offset: 0x0019BAB4
	public unsafe LayerMask ExclusionMask
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_ExclusionMask);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_ExclusionMask)) = value;
		}
	}

	// Token: 0x17002486 RID: 9350
	// (get) Token: 0x060066F5 RID: 26357 RVA: 0x0019D8D8 File Offset: 0x0019BAD8
	// (set) Token: 0x060066F6 RID: 26358 RVA: 0x0019D900 File Offset: 0x0019BB00
	public unsafe ParticleSystem.EmitParams parameters
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_parameters);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_parameters)) = value;
		}
	}

	// Token: 0x17002487 RID: 9351
	// (get) Token: 0x060066F7 RID: 26359 RVA: 0x0019D924 File Offset: 0x0019BB24
	// (set) Token: 0x060066F8 RID: 26360 RVA: 0x0019D958 File Offset: 0x0019BB58
	public unsafe List<Vector4> customData
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_customData);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Vector4>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHoleParticles.NativeFieldInfoPtr_customData), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040040F4 RID: 16628
	private static readonly IntPtr NativeFieldInfoPtr_Singleton;

	// Token: 0x040040F5 RID: 16629
	private static readonly IntPtr NativeFieldInfoPtr_System;

	// Token: 0x040040F6 RID: 16630
	private static readonly IntPtr NativeFieldInfoPtr_ExclusionMask;

	// Token: 0x040040F7 RID: 16631
	private static readonly IntPtr NativeFieldInfoPtr_parameters;

	// Token: 0x040040F8 RID: 16632
	private static readonly IntPtr NativeFieldInfoPtr_customData;

	// Token: 0x040040F9 RID: 16633
	private static readonly IntPtr NativeMethodInfoPtr_get_RandomDirtIndex_Protected_get_Int32_0;

	// Token: 0x040040FA RID: 16634
	private static readonly IntPtr NativeMethodInfoPtr_get_RandomWoodIndex_Protected_get_Int32_0;

	// Token: 0x040040FB RID: 16635
	private static readonly IntPtr NativeMethodInfoPtr_get_RandomMetalIndex_Protected_get_Int32_0;

	// Token: 0x040040FC RID: 16636
	private static readonly IntPtr NativeMethodInfoPtr_get_RandomConcreteIndex_Protected_get_Int32_0;

	// Token: 0x040040FD RID: 16637
	private static readonly IntPtr NativeMethodInfoPtr_get_RandomGlassIndex_Protected_get_Int32_0;

	// Token: 0x040040FE RID: 16638
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Protected_Void_0;

	// Token: 0x040040FF RID: 16639
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Void_0;

	// Token: 0x04004100 RID: 16640
	private static readonly IntPtr NativeMethodInfoPtr_Spawn_Public_Void_BulletHoleParticleType_Vector3_Vector3_Int32_0;

	// Token: 0x04004101 RID: 16641
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020004F1 RID: 1265
	public enum BulletHoleParticleType
	{
		// Token: 0x04004103 RID: 16643
		Dirt,
		// Token: 0x04004104 RID: 16644
		Wood,
		// Token: 0x04004105 RID: 16645
		Metal,
		// Token: 0x04004106 RID: 16646
		Concrete,
		// Token: 0x04004107 RID: 16647
		Glass
	}
}
