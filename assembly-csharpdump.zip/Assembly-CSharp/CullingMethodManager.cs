﻿using System;
using Il2CppSystem;
using Koenigz.PerfectCulling;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000177 RID: 375
public class CullingMethodManager : MonoBehaviour
{
	// Token: 0x060018F3 RID: 6387 RVA: 0x00063C24 File Offset: 0x00061E24
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CullingMethodManager.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018F4 RID: 6388 RVA: 0x00063C68 File Offset: 0x00061E68
	[CallerCount(0)]
	public unsafe CullingMethodManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CullingMethodManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018F5 RID: 6389 RVA: 0x00063CB4 File Offset: 0x00061EB4
	// Note: this type is marked as 'beforefieldinit'.
	static CullingMethodManager()
	{
		Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CullingMethodManager");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr);
		CullingMethodManager.NativeFieldInfoPtr_camera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr, "camera");
		CullingMethodManager.NativeFieldInfoPtr_perfectCulling = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr, "perfectCulling");
		CullingMethodManager.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr, 100665298);
		CullingMethodManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr, 100665299);
	}

	// Token: 0x060018F6 RID: 6390 RVA: 0x0000210C File Offset: 0x0000030C
	public CullingMethodManager(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700089C RID: 2204
	// (get) Token: 0x060018F7 RID: 6391 RVA: 0x00063D34 File Offset: 0x00061F34
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CullingMethodManager>.NativeClassPtr));
		}
	}

	// Token: 0x1700089D RID: 2205
	// (get) Token: 0x060018F8 RID: 6392 RVA: 0x00063D48 File Offset: 0x00061F48
	// (set) Token: 0x060018F9 RID: 6393 RVA: 0x00063D7C File Offset: 0x00061F7C
	public unsafe Camera camera
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullingMethodManager.NativeFieldInfoPtr_camera);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullingMethodManager.NativeFieldInfoPtr_camera), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700089E RID: 2206
	// (get) Token: 0x060018FA RID: 6394 RVA: 0x00063DA4 File Offset: 0x00061FA4
	// (set) Token: 0x060018FB RID: 6395 RVA: 0x00063DD8 File Offset: 0x00061FD8
	public unsafe PerfectCullingCamera perfectCulling
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullingMethodManager.NativeFieldInfoPtr_perfectCulling);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new PerfectCullingCamera(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullingMethodManager.NativeFieldInfoPtr_perfectCulling), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04001015 RID: 4117
	private static readonly IntPtr NativeFieldInfoPtr_camera;

	// Token: 0x04001016 RID: 4118
	private static readonly IntPtr NativeFieldInfoPtr_perfectCulling;

	// Token: 0x04001017 RID: 4119
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04001018 RID: 4120
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
