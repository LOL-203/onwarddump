﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000352 RID: 850
public static class CompressedQuaternion : Il2CppSystem.Object
{
	// Token: 0x060042ED RID: 17133 RVA: 0x0010D968 File Offset: 0x0010BB68
	[CallerCount(0)]
	public unsafe static uint Compress(Quaternion q)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref q;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_Compress_Public_Static_UInt32_Quaternion_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060042EE RID: 17134 RVA: 0x0010D9BC File Offset: 0x0010BBBC
	[CallerCount(0)]
	public unsafe static void FindLargestIndex(uint i, ref uint largestIndex)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref i;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &largestIndex;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_FindLargestIndex_Private_Static_Void_UInt32_byref_UInt32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042EF RID: 17135 RVA: 0x0010DA18 File Offset: 0x0010BC18
	[CallerCount(0)]
	public unsafe static void CompressComponent(ref uint comp, float value, int i, uint largestIndex, uint negate)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &comp;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref largestIndex;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref negate;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_CompressComponent_Private_Static_Void_byref_UInt32_Single_Int32_UInt32_UInt32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042F0 RID: 17136 RVA: 0x0010DAAC File Offset: 0x0010BCAC
	[CallerCount(0)]
	public unsafe static Quaternion Decompress(uint comp)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref comp;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_Decompress_Public_Static_Quaternion_UInt32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060042F1 RID: 17137 RVA: 0x0010DB00 File Offset: 0x0010BD00
	[CallerCount(0)]
	public unsafe static void Decompress(uint comp, ref Quaternion q)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref comp;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &q;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_Decompress_Public_Static_Void_UInt32_byref_Quaternion_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042F2 RID: 17138 RVA: 0x0010DB5C File Offset: 0x0010BD5C
	[CallerCount(0)]
	public unsafe static float DecompressComponent(ref uint comp, ref float value, int i, uint largestIndex)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &comp;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &value;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref largestIndex;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CompressedQuaternion.NativeMethodInfoPtr_DecompressComponent_Private_Static_Single_byref_UInt32_byref_Single_Int32_UInt32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060042F3 RID: 17139 RVA: 0x0010DBEC File Offset: 0x0010BDEC
	// Note: this type is marked as 'beforefieldinit'.
	static CompressedQuaternion()
	{
		Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CompressedQuaternion");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr);
		CompressedQuaternion.NativeFieldInfoPtr_CompressionEnabled = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, "CompressionEnabled");
		CompressedQuaternion.NativeFieldInfoPtr_SQRT_1_2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, "SQRT_1_2");
		CompressedQuaternion.NativeFieldInfoPtr_components = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, "components");
		CompressedQuaternion.NativeMethodInfoPtr_Compress_Public_Static_UInt32_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668621);
		CompressedQuaternion.NativeMethodInfoPtr_FindLargestIndex_Private_Static_Void_UInt32_byref_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668622);
		CompressedQuaternion.NativeMethodInfoPtr_CompressComponent_Private_Static_Void_byref_UInt32_Single_Int32_UInt32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668623);
		CompressedQuaternion.NativeMethodInfoPtr_Decompress_Public_Static_Quaternion_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668624);
		CompressedQuaternion.NativeMethodInfoPtr_Decompress_Public_Static_Void_UInt32_byref_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668625);
		CompressedQuaternion.NativeMethodInfoPtr_DecompressComponent_Private_Static_Single_byref_UInt32_byref_Single_Int32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr, 100668626);
	}

	// Token: 0x060042F4 RID: 17140 RVA: 0x00002988 File Offset: 0x00000B88
	public CompressedQuaternion(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170017BE RID: 6078
	// (get) Token: 0x060042F5 RID: 17141 RVA: 0x0010DCD0 File Offset: 0x0010BED0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CompressedQuaternion>.NativeClassPtr));
		}
	}

	// Token: 0x170017BF RID: 6079
	// (get) Token: 0x060042F6 RID: 17142 RVA: 0x0010DCE4 File Offset: 0x0010BEE4
	// (set) Token: 0x060042F7 RID: 17143 RVA: 0x0010DD02 File Offset: 0x0010BF02
	public unsafe static bool CompressionEnabled
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(CompressedQuaternion.NativeFieldInfoPtr_CompressionEnabled, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CompressedQuaternion.NativeFieldInfoPtr_CompressionEnabled, (void*)(&value));
		}
	}

	// Token: 0x170017C0 RID: 6080
	// (get) Token: 0x060042F8 RID: 17144 RVA: 0x0010DD14 File Offset: 0x0010BF14
	// (set) Token: 0x060042F9 RID: 17145 RVA: 0x0010DD32 File Offset: 0x0010BF32
	public unsafe static float SQRT_1_2
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CompressedQuaternion.NativeFieldInfoPtr_SQRT_1_2, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CompressedQuaternion.NativeFieldInfoPtr_SQRT_1_2, (void*)(&value));
		}
	}

	// Token: 0x170017C1 RID: 6081
	// (get) Token: 0x060042FA RID: 17146 RVA: 0x0010DD44 File Offset: 0x0010BF44
	// (set) Token: 0x060042FB RID: 17147 RVA: 0x0010DD6F File Offset: 0x0010BF6F
	public unsafe static Il2CppStructArray<float> components
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CompressedQuaternion.NativeFieldInfoPtr_components, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<float>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CompressedQuaternion.NativeFieldInfoPtr_components, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002AE2 RID: 10978
	private static readonly IntPtr NativeFieldInfoPtr_CompressionEnabled;

	// Token: 0x04002AE3 RID: 10979
	private static readonly IntPtr NativeFieldInfoPtr_SQRT_1_2;

	// Token: 0x04002AE4 RID: 10980
	private static readonly IntPtr NativeFieldInfoPtr_components;

	// Token: 0x04002AE5 RID: 10981
	private static readonly IntPtr NativeMethodInfoPtr_Compress_Public_Static_UInt32_Quaternion_0;

	// Token: 0x04002AE6 RID: 10982
	private static readonly IntPtr NativeMethodInfoPtr_FindLargestIndex_Private_Static_Void_UInt32_byref_UInt32_0;

	// Token: 0x04002AE7 RID: 10983
	private static readonly IntPtr NativeMethodInfoPtr_CompressComponent_Private_Static_Void_byref_UInt32_Single_Int32_UInt32_UInt32_0;

	// Token: 0x04002AE8 RID: 10984
	private static readonly IntPtr NativeMethodInfoPtr_Decompress_Public_Static_Quaternion_UInt32_0;

	// Token: 0x04002AE9 RID: 10985
	private static readonly IntPtr NativeMethodInfoPtr_Decompress_Public_Static_Void_UInt32_byref_Quaternion_0;

	// Token: 0x04002AEA RID: 10986
	private static readonly IntPtr NativeMethodInfoPtr_DecompressComponent_Private_Static_Single_byref_UInt32_byref_Single_Int32_UInt32_0;
}
