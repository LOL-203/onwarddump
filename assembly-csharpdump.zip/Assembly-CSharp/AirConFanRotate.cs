﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020001A9 RID: 425
public class AirConFanRotate : MonoBehaviour
{
	// Token: 0x06001CF6 RID: 7414 RVA: 0x00073048 File Offset: 0x00071248
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AirConFanRotate.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001CF7 RID: 7415 RVA: 0x0007308C File Offset: 0x0007128C
	[CallerCount(0)]
	public unsafe AirConFanRotate() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AirConFanRotate.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001CF8 RID: 7416 RVA: 0x000730D8 File Offset: 0x000712D8
	// Note: this type is marked as 'beforefieldinit'.
	static AirConFanRotate()
	{
		Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "AirConFanRotate");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr);
		AirConFanRotate.NativeFieldInfoPtr_speed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr, "speed");
		AirConFanRotate.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr, 100665571);
		AirConFanRotate.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr, 100665572);
	}

	// Token: 0x06001CF9 RID: 7417 RVA: 0x0000210C File Offset: 0x0000030C
	public AirConFanRotate(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000A17 RID: 2583
	// (get) Token: 0x06001CFA RID: 7418 RVA: 0x00073144 File Offset: 0x00071344
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AirConFanRotate>.NativeClassPtr));
		}
	}

	// Token: 0x17000A18 RID: 2584
	// (get) Token: 0x06001CFB RID: 7419 RVA: 0x00073158 File Offset: 0x00071358
	// (set) Token: 0x06001CFC RID: 7420 RVA: 0x00073180 File Offset: 0x00071380
	public unsafe float speed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AirConFanRotate.NativeFieldInfoPtr_speed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AirConFanRotate.NativeFieldInfoPtr_speed)) = value;
		}
	}

	// Token: 0x04001286 RID: 4742
	private static readonly IntPtr NativeFieldInfoPtr_speed;

	// Token: 0x04001287 RID: 4743
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04001288 RID: 4744
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
