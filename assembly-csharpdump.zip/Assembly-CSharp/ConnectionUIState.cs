﻿using System;

// Token: 0x020003FB RID: 1019
public enum ConnectionUIState
{
	// Token: 0x0400328F RID: 12943
	ServerTextOnline,
	// Token: 0x04003290 RID: 12944
	ServerTextOffline,
	// Token: 0x04003291 RID: 12945
	ServerTextBanned,
	// Token: 0x04003292 RID: 12946
	ServerTextIsolated,
	// Token: 0x04003293 RID: 12947
	ServerTextRestricted,
	// Token: 0x04003294 RID: 12948
	PlatformTextSteamActive,
	// Token: 0x04003295 RID: 12949
	PlatformTextSteamInactive,
	// Token: 0x04003296 RID: 12950
	PlatformTextOculusActive,
	// Token: 0x04003297 RID: 12951
	PlatformTextOculusInactive,
	// Token: 0x04003298 RID: 12952
	DeveloperTextOn,
	// Token: 0x04003299 RID: 12953
	DeveloperTextOff,
	// Token: 0x0400329A RID: 12954
	InternetTextOnline,
	// Token: 0x0400329B RID: 12955
	InternetTextOffline,
	// Token: 0x0400329C RID: 12956
	VoiceTextOnline,
	// Token: 0x0400329D RID: 12957
	VoiceTextOffline,
	// Token: 0x0400329E RID: 12958
	RestrictionTextOn,
	// Token: 0x0400329F RID: 12959
	RestrictionTextOff,
	// Token: 0x040032A0 RID: 12960
	ExpirationTextOn,
	// Token: 0x040032A1 RID: 12961
	ExpirationTextOff
}
