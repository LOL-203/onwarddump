﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x0200004C RID: 76
public class ButtonDownListener : MonoBehaviour
{
	// Token: 0x060004A5 RID: 1189 RVA: 0x00014E90 File Offset: 0x00013090
	[CallerCount(0)]
	public unsafe void add_onButtonDown(Action value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonDownListener.NativeMethodInfoPtr_add_onButtonDown_Public_add_Void_Action_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x00014EEC File Offset: 0x000130EC
	[CallerCount(0)]
	public unsafe void remove_onButtonDown(Action value)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonDownListener.NativeMethodInfoPtr_remove_onButtonDown_Public_rem_Void_Action_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x00014F48 File Offset: 0x00013148
	[CallerCount(0)]
	public unsafe void OnPointerDown(PointerEventData eventData)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(eventData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonDownListener.NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x00014FA4 File Offset: 0x000131A4
	[CallerCount(0)]
	public unsafe ButtonDownListener() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ButtonDownListener.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x00014FF0 File Offset: 0x000131F0
	// Note: this type is marked as 'beforefieldinit'.
	static ButtonDownListener()
	{
		Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ButtonDownListener");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr);
		ButtonDownListener.NativeFieldInfoPtr_onButtonDown = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr, "onButtonDown");
		ButtonDownListener.NativeMethodInfoPtr_add_onButtonDown_Public_add_Void_Action_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr, 100663712);
		ButtonDownListener.NativeMethodInfoPtr_remove_onButtonDown_Public_rem_Void_Action_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr, 100663713);
		ButtonDownListener.NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr, 100663714);
		ButtonDownListener.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr, 100663715);
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x0000210C File Offset: 0x0000030C
	public ButtonDownListener(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700018B RID: 395
	// (get) Token: 0x060004AB RID: 1195 RVA: 0x00015084 File Offset: 0x00013284
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ButtonDownListener>.NativeClassPtr));
		}
	}

	// Token: 0x1700018C RID: 396
	// (get) Token: 0x060004AC RID: 1196 RVA: 0x00015098 File Offset: 0x00013298
	// (set) Token: 0x060004AD RID: 1197 RVA: 0x000150CC File Offset: 0x000132CC
	public unsafe Action onButtonDown
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonDownListener.NativeFieldInfoPtr_onButtonDown);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Action(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ButtonDownListener.NativeFieldInfoPtr_onButtonDown), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040002E3 RID: 739
	private static readonly IntPtr NativeFieldInfoPtr_onButtonDown;

	// Token: 0x040002E4 RID: 740
	private static readonly IntPtr NativeMethodInfoPtr_add_onButtonDown_Public_add_Void_Action_0;

	// Token: 0x040002E5 RID: 741
	private static readonly IntPtr NativeMethodInfoPtr_remove_onButtonDown_Public_rem_Void_Action_0;

	// Token: 0x040002E6 RID: 742
	private static readonly IntPtr NativeMethodInfoPtr_OnPointerDown_Public_Virtual_Final_New_Void_PointerEventData_0;

	// Token: 0x040002E7 RID: 743
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
