﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x02000163 RID: 355
public static class BuildSettings : Object
{
	// Token: 0x17000853 RID: 2131
	// (get) Token: 0x0600180F RID: 6159 RVA: 0x00060B48 File Offset: 0x0005ED48
	public unsafe static BuildSettings.StorePlatformSDK StorePlatform
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_get_StorePlatform_Public_Static_get_StorePlatformSDK_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06001810 RID: 6160 RVA: 0x00060B8C File Offset: 0x0005ED8C
	[CallerCount(0)]
	public unsafe static void InitializePlatformSDK()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_InitializePlatformSDK_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001811 RID: 6161 RVA: 0x00060BC0 File Offset: 0x0005EDC0
	[CallerCount(0)]
	public unsafe static void ReadCommandLineArgs()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_ReadCommandLineArgs_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001812 RID: 6162 RVA: 0x00060BF4 File Offset: 0x0005EDF4
	[CallerCount(0)]
	public unsafe static bool TryGetCommandLineValue(string key, out string value)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
		ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
		IntPtr il2CppString = IL2CPP.ManagedStringToIl2Cpp(value);
		ptr2 = &il2CppString;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_TryGetCommandLineValue_Public_Static_Boolean_String_byref_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		value = IL2CPP.Il2CppStringToManaged(il2CppString);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001813 RID: 6163 RVA: 0x00060C7C File Offset: 0x0005EE7C
	[CallerCount(0)]
	public unsafe static void TryInitSteamClient()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_TryInitSteamClient_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001814 RID: 6164 RVA: 0x00060CB0 File Offset: 0x0005EEB0
	[CallerCount(0)]
	public unsafe static bool TryGetCommandLineFlag(string key)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_TryGetCommandLineFlag_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001815 RID: 6165 RVA: 0x00060D08 File Offset: 0x0005EF08
	[CallerCount(0)]
	public unsafe static bool IsFlag(string arg)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(arg);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_IsFlag_Private_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001816 RID: 6166 RVA: 0x00060D60 File Offset: 0x0005EF60
	[CallerCount(0)]
	public unsafe static void Parse(Il2CppStringArray args)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(args);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BuildSettings.NativeMethodInfoPtr_Parse_Private_Static_Void_ArrayOf_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001817 RID: 6167 RVA: 0x00060DAC File Offset: 0x0005EFAC
	// Note: this type is marked as 'beforefieldinit'.
	static BuildSettings()
	{
		Il2CppClassPointerStore<BuildSettings>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BuildSettings");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr);
		BuildSettings.NativeFieldInfoPtr_m_StorePlatformSDK = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "m_StorePlatformSDK");
		BuildSettings.NativeFieldInfoPtr_PLAYER_PREFS_VERSION_LOADOUT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "PLAYER_PREFS_VERSION_LOADOUT");
		BuildSettings.NativeFieldInfoPtr_IsLocalServer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "IsLocalServer");
		BuildSettings.NativeFieldInfoPtr_IsStageShow = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "IsStageShow");
		BuildSettings.NativeFieldInfoPtr_argDictionary = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "argDictionary");
		BuildSettings.NativeFieldInfoPtr_FLAG_INDICATOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "FLAG_INDICATOR");
		BuildSettings.NativeFieldInfoPtr_commandlineInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "commandlineInitialized");
		BuildSettings.NativeFieldInfoPtr_SteamAppId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "SteamAppId");
		BuildSettings.NativeFieldInfoPtr_SteamBuildID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "SteamBuildID");
		BuildSettings.NativeMethodInfoPtr_get_StorePlatform_Public_Static_get_StorePlatformSDK_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665230);
		BuildSettings.NativeMethodInfoPtr_InitializePlatformSDK_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665231);
		BuildSettings.NativeMethodInfoPtr_ReadCommandLineArgs_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665232);
		BuildSettings.NativeMethodInfoPtr_TryGetCommandLineValue_Public_Static_Boolean_String_byref_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665233);
		BuildSettings.NativeMethodInfoPtr_TryInitSteamClient_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665234);
		BuildSettings.NativeMethodInfoPtr_TryGetCommandLineFlag_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665235);
		BuildSettings.NativeMethodInfoPtr_IsFlag_Private_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665236);
		BuildSettings.NativeMethodInfoPtr_Parse_Private_Static_Void_ArrayOf_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, 100665237);
	}

	// Token: 0x06001818 RID: 6168 RVA: 0x00002988 File Offset: 0x00000B88
	public BuildSettings(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000849 RID: 2121
	// (get) Token: 0x06001819 RID: 6169 RVA: 0x00060F30 File Offset: 0x0005F130
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr));
		}
	}

	// Token: 0x1700084A RID: 2122
	// (get) Token: 0x0600181A RID: 6170 RVA: 0x00060F44 File Offset: 0x0005F144
	// (set) Token: 0x0600181B RID: 6171 RVA: 0x00060F62 File Offset: 0x0005F162
	public unsafe static BuildSettings.StorePlatformSDK m_StorePlatformSDK
	{
		get
		{
			BuildSettings.StorePlatformSDK result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_m_StorePlatformSDK, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_m_StorePlatformSDK, (void*)(&value));
		}
	}

	// Token: 0x1700084B RID: 2123
	// (get) Token: 0x0600181C RID: 6172 RVA: 0x00060F74 File Offset: 0x0005F174
	// (set) Token: 0x0600181D RID: 6173 RVA: 0x00060F92 File Offset: 0x0005F192
	public unsafe static int PLAYER_PREFS_VERSION_LOADOUT
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_PLAYER_PREFS_VERSION_LOADOUT, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_PLAYER_PREFS_VERSION_LOADOUT, (void*)(&value));
		}
	}

	// Token: 0x1700084C RID: 2124
	// (get) Token: 0x0600181E RID: 6174 RVA: 0x00060FA4 File Offset: 0x0005F1A4
	// (set) Token: 0x0600181F RID: 6175 RVA: 0x00060FC2 File Offset: 0x0005F1C2
	public unsafe static bool IsLocalServer
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_IsLocalServer, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_IsLocalServer, (void*)(&value));
		}
	}

	// Token: 0x1700084D RID: 2125
	// (get) Token: 0x06001820 RID: 6176 RVA: 0x00060FD4 File Offset: 0x0005F1D4
	// (set) Token: 0x06001821 RID: 6177 RVA: 0x00060FF2 File Offset: 0x0005F1F2
	public unsafe static bool IsStageShow
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_IsStageShow, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_IsStageShow, (void*)(&value));
		}
	}

	// Token: 0x1700084E RID: 2126
	// (get) Token: 0x06001822 RID: 6178 RVA: 0x00061004 File Offset: 0x0005F204
	// (set) Token: 0x06001823 RID: 6179 RVA: 0x0006102F File Offset: 0x0005F22F
	public unsafe static Dictionary<string, string> argDictionary
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_argDictionary, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<string, string>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_argDictionary, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700084F RID: 2127
	// (get) Token: 0x06001824 RID: 6180 RVA: 0x00061044 File Offset: 0x0005F244
	// (set) Token: 0x06001825 RID: 6181 RVA: 0x00061062 File Offset: 0x0005F262
	public unsafe static char FLAG_INDICATOR
	{
		get
		{
			char result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_FLAG_INDICATOR, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_FLAG_INDICATOR, (void*)(&value));
		}
	}

	// Token: 0x17000850 RID: 2128
	// (get) Token: 0x06001826 RID: 6182 RVA: 0x00061074 File Offset: 0x0005F274
	// (set) Token: 0x06001827 RID: 6183 RVA: 0x00061092 File Offset: 0x0005F292
	public unsafe static bool commandlineInitialized
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_commandlineInitialized, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_commandlineInitialized, (void*)(&value));
		}
	}

	// Token: 0x17000851 RID: 2129
	// (get) Token: 0x06001828 RID: 6184 RVA: 0x000610A4 File Offset: 0x0005F2A4
	// (set) Token: 0x06001829 RID: 6185 RVA: 0x000610C2 File Offset: 0x0005F2C2
	public unsafe static uint SteamAppId
	{
		get
		{
			uint result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_SteamAppId, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_SteamAppId, (void*)(&value));
		}
	}

	// Token: 0x17000852 RID: 2130
	// (get) Token: 0x0600182A RID: 6186 RVA: 0x000610D4 File Offset: 0x0005F2D4
	// (set) Token: 0x0600182B RID: 6187 RVA: 0x000610F2 File Offset: 0x0005F2F2
	public unsafe static int SteamBuildID
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(BuildSettings.NativeFieldInfoPtr_SteamBuildID, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(BuildSettings.NativeFieldInfoPtr_SteamBuildID, (void*)(&value));
		}
	}

	// Token: 0x04000F5D RID: 3933
	private static readonly IntPtr NativeFieldInfoPtr_m_StorePlatformSDK;

	// Token: 0x04000F5E RID: 3934
	private static readonly IntPtr NativeFieldInfoPtr_PLAYER_PREFS_VERSION_LOADOUT;

	// Token: 0x04000F5F RID: 3935
	private static readonly IntPtr NativeFieldInfoPtr_IsLocalServer;

	// Token: 0x04000F60 RID: 3936
	private static readonly IntPtr NativeFieldInfoPtr_IsStageShow;

	// Token: 0x04000F61 RID: 3937
	private static readonly IntPtr NativeFieldInfoPtr_argDictionary;

	// Token: 0x04000F62 RID: 3938
	private static readonly IntPtr NativeFieldInfoPtr_FLAG_INDICATOR;

	// Token: 0x04000F63 RID: 3939
	private static readonly IntPtr NativeFieldInfoPtr_commandlineInitialized;

	// Token: 0x04000F64 RID: 3940
	private static readonly IntPtr NativeFieldInfoPtr_SteamAppId;

	// Token: 0x04000F65 RID: 3941
	private static readonly IntPtr NativeFieldInfoPtr_SteamBuildID;

	// Token: 0x04000F66 RID: 3942
	private static readonly IntPtr NativeMethodInfoPtr_get_StorePlatform_Public_Static_get_StorePlatformSDK_0;

	// Token: 0x04000F67 RID: 3943
	private static readonly IntPtr NativeMethodInfoPtr_InitializePlatformSDK_Public_Static_Void_0;

	// Token: 0x04000F68 RID: 3944
	private static readonly IntPtr NativeMethodInfoPtr_ReadCommandLineArgs_Private_Static_Void_0;

	// Token: 0x04000F69 RID: 3945
	private static readonly IntPtr NativeMethodInfoPtr_TryGetCommandLineValue_Public_Static_Boolean_String_byref_String_0;

	// Token: 0x04000F6A RID: 3946
	private static readonly IntPtr NativeMethodInfoPtr_TryInitSteamClient_Private_Static_Void_0;

	// Token: 0x04000F6B RID: 3947
	private static readonly IntPtr NativeMethodInfoPtr_TryGetCommandLineFlag_Public_Static_Boolean_String_0;

	// Token: 0x04000F6C RID: 3948
	private static readonly IntPtr NativeMethodInfoPtr_IsFlag_Private_Static_Boolean_String_0;

	// Token: 0x04000F6D RID: 3949
	private static readonly IntPtr NativeMethodInfoPtr_Parse_Private_Static_Void_ArrayOf_0;

	// Token: 0x02000164 RID: 356
	public enum StorePlatformSDK
	{
		// Token: 0x04000F6F RID: 3951
		NULL,
		// Token: 0x04000F70 RID: 3952
		SteamStore,
		// Token: 0x04000F71 RID: 3953
		OculusStore
	}

	// Token: 0x02000165 RID: 357
	[StructLayout(2, Size = 1)]
	public struct CommandLineArguments
	{
		// Token: 0x0600182E RID: 6190 RVA: 0x0006112C File Offset: 0x0005F32C
		// Note: this type is marked as 'beforefieldinit'.
		static CommandLineArguments()
		{
			Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BuildSettings>.NativeClassPtr, "CommandLineArguments");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr);
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NOVR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "NOVR");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "OCULUS");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS_STORE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "OCULUS_STORE");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_VANILLA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "INPUT_THROWINGMODE_VANILLA");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_PHYSICS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "INPUT_THROWINGMODE_PHYSICS");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_TRAILERMODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "TRAILERMODE");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_FORCE_LOW_QUALITY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "FORCE_LOW_QUALITY");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_VRMODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "VRMODE");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_SEQUENTIAL_WARMING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "SEQUENTIAL_WARMING");
			BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NO_WARMING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, "NO_WARMING");
		}

		// Token: 0x0600182F RID: 6191 RVA: 0x0006121F File Offset: 0x0005F41F
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr, ref this));
		}

		// Token: 0x17000855 RID: 2133
		// (get) Token: 0x06001830 RID: 6192 RVA: 0x00061231 File Offset: 0x0005F431
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BuildSettings.CommandLineArguments>.NativeClassPtr));
			}
		}

		// Token: 0x17000856 RID: 2134
		// (get) Token: 0x06001831 RID: 6193 RVA: 0x00061244 File Offset: 0x0005F444
		// (set) Token: 0x06001832 RID: 6194 RVA: 0x00061264 File Offset: 0x0005F464
		public unsafe static string NOVR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NOVR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NOVR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000857 RID: 2135
		// (get) Token: 0x06001833 RID: 6195 RVA: 0x0006127C File Offset: 0x0005F47C
		// (set) Token: 0x06001834 RID: 6196 RVA: 0x0006129C File Offset: 0x0005F49C
		public unsafe static string OCULUS
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000858 RID: 2136
		// (get) Token: 0x06001835 RID: 6197 RVA: 0x000612B4 File Offset: 0x0005F4B4
		// (set) Token: 0x06001836 RID: 6198 RVA: 0x000612D4 File Offset: 0x0005F4D4
		public unsafe static string OCULUS_STORE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS_STORE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_OCULUS_STORE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000859 RID: 2137
		// (get) Token: 0x06001837 RID: 6199 RVA: 0x000612EC File Offset: 0x0005F4EC
		// (set) Token: 0x06001838 RID: 6200 RVA: 0x0006130C File Offset: 0x0005F50C
		public unsafe static string INPUT_THROWINGMODE_VANILLA
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_VANILLA, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_VANILLA, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085A RID: 2138
		// (get) Token: 0x06001839 RID: 6201 RVA: 0x00061324 File Offset: 0x0005F524
		// (set) Token: 0x0600183A RID: 6202 RVA: 0x00061344 File Offset: 0x0005F544
		public unsafe static string INPUT_THROWINGMODE_PHYSICS
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_PHYSICS, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_INPUT_THROWINGMODE_PHYSICS, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085B RID: 2139
		// (get) Token: 0x0600183B RID: 6203 RVA: 0x0006135C File Offset: 0x0005F55C
		// (set) Token: 0x0600183C RID: 6204 RVA: 0x0006137C File Offset: 0x0005F57C
		public unsafe static string TRAILERMODE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_TRAILERMODE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_TRAILERMODE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085C RID: 2140
		// (get) Token: 0x0600183D RID: 6205 RVA: 0x00061394 File Offset: 0x0005F594
		// (set) Token: 0x0600183E RID: 6206 RVA: 0x000613B4 File Offset: 0x0005F5B4
		public unsafe static string FORCE_LOW_QUALITY
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_FORCE_LOW_QUALITY, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_FORCE_LOW_QUALITY, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085D RID: 2141
		// (get) Token: 0x0600183F RID: 6207 RVA: 0x000613CC File Offset: 0x0005F5CC
		// (set) Token: 0x06001840 RID: 6208 RVA: 0x000613EC File Offset: 0x0005F5EC
		public unsafe static string VRMODE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_VRMODE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_VRMODE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085E RID: 2142
		// (get) Token: 0x06001841 RID: 6209 RVA: 0x00061404 File Offset: 0x0005F604
		// (set) Token: 0x06001842 RID: 6210 RVA: 0x00061424 File Offset: 0x0005F624
		public unsafe static string SEQUENTIAL_WARMING
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_SEQUENTIAL_WARMING, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_SEQUENTIAL_WARMING, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700085F RID: 2143
		// (get) Token: 0x06001843 RID: 6211 RVA: 0x0006143C File Offset: 0x0005F63C
		// (set) Token: 0x06001844 RID: 6212 RVA: 0x0006145C File Offset: 0x0005F65C
		public unsafe static string NO_WARMING
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NO_WARMING, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BuildSettings.CommandLineArguments.NativeFieldInfoPtr_NO_WARMING, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x04000F72 RID: 3954
		private static readonly IntPtr NativeFieldInfoPtr_NOVR;

		// Token: 0x04000F73 RID: 3955
		private static readonly IntPtr NativeFieldInfoPtr_OCULUS;

		// Token: 0x04000F74 RID: 3956
		private static readonly IntPtr NativeFieldInfoPtr_OCULUS_STORE;

		// Token: 0x04000F75 RID: 3957
		private static readonly IntPtr NativeFieldInfoPtr_INPUT_THROWINGMODE_VANILLA;

		// Token: 0x04000F76 RID: 3958
		private static readonly IntPtr NativeFieldInfoPtr_INPUT_THROWINGMODE_PHYSICS;

		// Token: 0x04000F77 RID: 3959
		private static readonly IntPtr NativeFieldInfoPtr_TRAILERMODE;

		// Token: 0x04000F78 RID: 3960
		private static readonly IntPtr NativeFieldInfoPtr_FORCE_LOW_QUALITY;

		// Token: 0x04000F79 RID: 3961
		private static readonly IntPtr NativeFieldInfoPtr_VRMODE;

		// Token: 0x04000F7A RID: 3962
		private static readonly IntPtr NativeFieldInfoPtr_SEQUENTIAL_WARMING;

		// Token: 0x04000F7B RID: 3963
		private static readonly IntPtr NativeFieldInfoPtr_NO_WARMING;
	}
}
