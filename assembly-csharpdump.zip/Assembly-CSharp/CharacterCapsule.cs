﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000061 RID: 97
public class CharacterCapsule : MonoBehaviour
{
	// Token: 0x060005F7 RID: 1527 RVA: 0x0001A1DC File Offset: 0x000183DC
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCapsule.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x0001A220 File Offset: 0x00018420
	[CallerCount(0)]
	public unsafe CharacterCapsule() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterCapsule.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x0001A26C File Offset: 0x0001846C
	// Note: this type is marked as 'beforefieldinit'.
	static CharacterCapsule()
	{
		Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CharacterCapsule");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr);
		CharacterCapsule.NativeFieldInfoPtr__character = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_character");
		CharacterCapsule.NativeFieldInfoPtr__meshFilter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_meshFilter");
		CharacterCapsule.NativeFieldInfoPtr__height = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_height");
		CharacterCapsule.NativeFieldInfoPtr__radius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_radius");
		CharacterCapsule.NativeFieldInfoPtr_SubdivisionsU = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "SubdivisionsU");
		CharacterCapsule.NativeFieldInfoPtr_SubdivisionsV = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "SubdivisionsV");
		CharacterCapsule.NativeFieldInfoPtr__subdivisionU = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_subdivisionU");
		CharacterCapsule.NativeFieldInfoPtr__subdivisionV = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_subdivisionV");
		CharacterCapsule.NativeFieldInfoPtr__vertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_vertices");
		CharacterCapsule.NativeFieldInfoPtr__triangles = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, "_triangles");
		CharacterCapsule.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, 100663811);
		CharacterCapsule.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr, 100663812);
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x0000210C File Offset: 0x0000030C
	public CharacterCapsule(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000203 RID: 515
	// (get) Token: 0x060005FB RID: 1531 RVA: 0x0001A38C File Offset: 0x0001858C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CharacterCapsule>.NativeClassPtr));
		}
	}

	// Token: 0x17000204 RID: 516
	// (get) Token: 0x060005FC RID: 1532 RVA: 0x0001A3A0 File Offset: 0x000185A0
	// (set) Token: 0x060005FD RID: 1533 RVA: 0x0001A3D4 File Offset: 0x000185D4
	public unsafe CharacterController _character
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__character);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new CharacterController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__character), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000205 RID: 517
	// (get) Token: 0x060005FE RID: 1534 RVA: 0x0001A3FC File Offset: 0x000185FC
	// (set) Token: 0x060005FF RID: 1535 RVA: 0x0001A430 File Offset: 0x00018630
	public unsafe MeshFilter _meshFilter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__meshFilter);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshFilter(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__meshFilter), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000206 RID: 518
	// (get) Token: 0x06000600 RID: 1536 RVA: 0x0001A458 File Offset: 0x00018658
	// (set) Token: 0x06000601 RID: 1537 RVA: 0x0001A480 File Offset: 0x00018680
	public unsafe float _height
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__height);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__height)) = value;
		}
	}

	// Token: 0x17000207 RID: 519
	// (get) Token: 0x06000602 RID: 1538 RVA: 0x0001A4A4 File Offset: 0x000186A4
	// (set) Token: 0x06000603 RID: 1539 RVA: 0x0001A4CC File Offset: 0x000186CC
	public unsafe float _radius
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__radius);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__radius)) = value;
		}
	}

	// Token: 0x17000208 RID: 520
	// (get) Token: 0x06000604 RID: 1540 RVA: 0x0001A4F0 File Offset: 0x000186F0
	// (set) Token: 0x06000605 RID: 1541 RVA: 0x0001A518 File Offset: 0x00018718
	public unsafe int SubdivisionsU
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr_SubdivisionsU);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr_SubdivisionsU)) = value;
		}
	}

	// Token: 0x17000209 RID: 521
	// (get) Token: 0x06000606 RID: 1542 RVA: 0x0001A53C File Offset: 0x0001873C
	// (set) Token: 0x06000607 RID: 1543 RVA: 0x0001A564 File Offset: 0x00018764
	public unsafe int SubdivisionsV
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr_SubdivisionsV);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr_SubdivisionsV)) = value;
		}
	}

	// Token: 0x1700020A RID: 522
	// (get) Token: 0x06000608 RID: 1544 RVA: 0x0001A588 File Offset: 0x00018788
	// (set) Token: 0x06000609 RID: 1545 RVA: 0x0001A5B0 File Offset: 0x000187B0
	public unsafe int _subdivisionU
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__subdivisionU);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__subdivisionU)) = value;
		}
	}

	// Token: 0x1700020B RID: 523
	// (get) Token: 0x0600060A RID: 1546 RVA: 0x0001A5D4 File Offset: 0x000187D4
	// (set) Token: 0x0600060B RID: 1547 RVA: 0x0001A5FC File Offset: 0x000187FC
	public unsafe int _subdivisionV
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__subdivisionV);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__subdivisionV)) = value;
		}
	}

	// Token: 0x1700020C RID: 524
	// (get) Token: 0x0600060C RID: 1548 RVA: 0x0001A620 File Offset: 0x00018820
	// (set) Token: 0x0600060D RID: 1549 RVA: 0x0001A654 File Offset: 0x00018854
	public unsafe Il2CppStructArray<Vector3> _vertices
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__vertices);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector3>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__vertices), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700020D RID: 525
	// (get) Token: 0x0600060E RID: 1550 RVA: 0x0001A67C File Offset: 0x0001887C
	// (set) Token: 0x0600060F RID: 1551 RVA: 0x0001A6B0 File Offset: 0x000188B0
	public unsafe Il2CppStructArray<int> _triangles
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__triangles);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterCapsule.NativeFieldInfoPtr__triangles), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040003BE RID: 958
	private static readonly IntPtr NativeFieldInfoPtr__character;

	// Token: 0x040003BF RID: 959
	private static readonly IntPtr NativeFieldInfoPtr__meshFilter;

	// Token: 0x040003C0 RID: 960
	private static readonly IntPtr NativeFieldInfoPtr__height;

	// Token: 0x040003C1 RID: 961
	private static readonly IntPtr NativeFieldInfoPtr__radius;

	// Token: 0x040003C2 RID: 962
	private static readonly IntPtr NativeFieldInfoPtr_SubdivisionsU;

	// Token: 0x040003C3 RID: 963
	private static readonly IntPtr NativeFieldInfoPtr_SubdivisionsV;

	// Token: 0x040003C4 RID: 964
	private static readonly IntPtr NativeFieldInfoPtr__subdivisionU;

	// Token: 0x040003C5 RID: 965
	private static readonly IntPtr NativeFieldInfoPtr__subdivisionV;

	// Token: 0x040003C6 RID: 966
	private static readonly IntPtr NativeFieldInfoPtr__vertices;

	// Token: 0x040003C7 RID: 967
	private static readonly IntPtr NativeFieldInfoPtr__triangles;

	// Token: 0x040003C8 RID: 968
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x040003C9 RID: 969
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
