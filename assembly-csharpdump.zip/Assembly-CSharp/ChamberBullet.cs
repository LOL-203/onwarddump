﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004F3 RID: 1267
public class ChamberBullet : MonoBehaviour
{
	// Token: 0x06006733 RID: 26419 RVA: 0x0019E5C0 File Offset: 0x0019C7C0
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChamberBullet.NativeMethodInfoPtr_Awake_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006734 RID: 26420 RVA: 0x0019E604 File Offset: 0x0019C804
	[CallerCount(0)]
	public unsafe void SetupAmmoType(ClassLoadout.AmmoType type)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref type;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChamberBullet.NativeMethodInfoPtr_SetupAmmoType_Public_Void_AmmoType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006735 RID: 26421 RVA: 0x0019E658 File Offset: 0x0019C858
	[CallerCount(0)]
	public unsafe ChamberBullet() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChamberBullet.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006736 RID: 26422 RVA: 0x0019E6A4 File Offset: 0x0019C8A4
	// Note: this type is marked as 'beforefieldinit'.
	static ChamberBullet()
	{
		Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ChamberBullet");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr);
		ChamberBullet.NativeFieldInfoPtr_Groups = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, "Groups");
		ChamberBullet.NativeFieldInfoPtr_groupList = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, "groupList");
		ChamberBullet.NativeMethodInfoPtr_Awake_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, 100671495);
		ChamberBullet.NativeMethodInfoPtr_SetupAmmoType_Public_Void_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, 100671496);
		ChamberBullet.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, 100671497);
	}

	// Token: 0x06006737 RID: 26423 RVA: 0x0000210C File Offset: 0x0000030C
	public ChamberBullet(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170024A5 RID: 9381
	// (get) Token: 0x06006738 RID: 26424 RVA: 0x0019E738 File Offset: 0x0019C938
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr));
		}
	}

	// Token: 0x170024A6 RID: 9382
	// (get) Token: 0x06006739 RID: 26425 RVA: 0x0019E74C File Offset: 0x0019C94C
	// (set) Token: 0x0600673A RID: 26426 RVA: 0x0019E780 File Offset: 0x0019C980
	public unsafe Il2CppReferenceArray<ChamberBullet.ChamberBulletGroup> Groups
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.NativeFieldInfoPtr_Groups);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ChamberBullet.ChamberBulletGroup>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.NativeFieldInfoPtr_Groups), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024A7 RID: 9383
	// (get) Token: 0x0600673B RID: 26427 RVA: 0x0019E7A8 File Offset: 0x0019C9A8
	// (set) Token: 0x0600673C RID: 26428 RVA: 0x0019E7DC File Offset: 0x0019C9DC
	public unsafe List<LODGroup> groupList
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.NativeFieldInfoPtr_groupList);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<LODGroup>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.NativeFieldInfoPtr_groupList), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04004128 RID: 16680
	private static readonly IntPtr NativeFieldInfoPtr_Groups;

	// Token: 0x04004129 RID: 16681
	private static readonly IntPtr NativeFieldInfoPtr_groupList;

	// Token: 0x0400412A RID: 16682
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Protected_Void_0;

	// Token: 0x0400412B RID: 16683
	private static readonly IntPtr NativeMethodInfoPtr_SetupAmmoType_Public_Void_AmmoType_0;

	// Token: 0x0400412C RID: 16684
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020004F4 RID: 1268
	[Serializable]
	public class ChamberBulletGroup : Il2CppSystem.Object
	{
		// Token: 0x0600673D RID: 26429 RVA: 0x0019E804 File Offset: 0x0019CA04
		[CallerCount(0)]
		public unsafe ChamberBulletGroup() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ChamberBullet.ChamberBulletGroup.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600673E RID: 26430 RVA: 0x0019E850 File Offset: 0x0019CA50
		// Note: this type is marked as 'beforefieldinit'.
		static ChamberBulletGroup()
		{
			Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ChamberBullet>.NativeClassPtr, "ChamberBulletGroup");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr);
			ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr, "Type");
			ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Group = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr, "Group");
			ChamberBullet.ChamberBulletGroup.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr, 100671498);
		}

		// Token: 0x0600673F RID: 26431 RVA: 0x00002988 File Offset: 0x00000B88
		public ChamberBulletGroup(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170024A8 RID: 9384
		// (get) Token: 0x06006740 RID: 26432 RVA: 0x0019E8B7 File Offset: 0x0019CAB7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ChamberBullet.ChamberBulletGroup>.NativeClassPtr));
			}
		}

		// Token: 0x170024A9 RID: 9385
		// (get) Token: 0x06006741 RID: 26433 RVA: 0x0019E8C8 File Offset: 0x0019CAC8
		// (set) Token: 0x06006742 RID: 26434 RVA: 0x0019E8F0 File Offset: 0x0019CAF0
		public unsafe ClassLoadout.AmmoType Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x170024AA RID: 9386
		// (get) Token: 0x06006743 RID: 26435 RVA: 0x0019E914 File Offset: 0x0019CB14
		// (set) Token: 0x06006744 RID: 26436 RVA: 0x0019E948 File Offset: 0x0019CB48
		public unsafe LODGroup Group
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Group);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ChamberBullet.ChamberBulletGroup.NativeFieldInfoPtr_Group), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400412D RID: 16685
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x0400412E RID: 16686
		private static readonly IntPtr NativeFieldInfoPtr_Group;

		// Token: 0x0400412F RID: 16687
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
