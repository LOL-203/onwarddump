﻿using System;

// Token: 0x02000170 RID: 368
public enum AllowCustomMapsServerSetting
{
	// Token: 0x04000FB0 RID: 4016
	Disabled,
	// Token: 0x04000FB1 RID: 4017
	TwoMaps,
	// Token: 0x04000FB2 RID: 4018
	FourMaps,
	// Token: 0x04000FB3 RID: 4019
	CustomMapsOnly,
	// Token: 0x04000FB4 RID: 4020
	Enabled
}
