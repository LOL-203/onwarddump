﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C5 RID: 197
public class BulletHit : MonoBehaviour
{
	// Token: 0x06000C54 RID: 3156 RVA: 0x000321B8 File Offset: 0x000303B8
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHit.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C55 RID: 3157 RVA: 0x000321FC File Offset: 0x000303FC
	[CallerCount(0)]
	public unsafe void TurnOnCollider()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHit.NativeMethodInfoPtr_TurnOnCollider_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C56 RID: 3158 RVA: 0x00032240 File Offset: 0x00030440
	[CallerCount(0)]
	public unsafe void PlayHitSound()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHit.NativeMethodInfoPtr_PlayHitSound_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C57 RID: 3159 RVA: 0x00032284 File Offset: 0x00030484
	[CallerCount(0)]
	public unsafe void OnCollisionEnter(Collision collision)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(collision);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHit.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C58 RID: 3160 RVA: 0x000322E0 File Offset: 0x000304E0
	[CallerCount(0)]
	public unsafe BulletHit() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BulletHit>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletHit.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C59 RID: 3161 RVA: 0x0003232C File Offset: 0x0003052C
	// Note: this type is marked as 'beforefieldinit'.
	static BulletHit()
	{
		Il2CppClassPointerStore<BulletHit>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BulletHit");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BulletHit>.NativeClassPtr);
		BulletHit.NativeFieldInfoPtr_PF_OnHit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, "PF_OnHit");
		BulletHit.NativeFieldInfoPtr_isPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, "isPlayer");
		BulletHit.NativeFieldInfoPtr_Gun_Ricochets = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, "Gun_Ricochets");
		BulletHit.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, 100664254);
		BulletHit.NativeMethodInfoPtr_TurnOnCollider_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, 100664255);
		BulletHit.NativeMethodInfoPtr_PlayHitSound_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, 100664256);
		BulletHit.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, 100664257);
		BulletHit.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletHit>.NativeClassPtr, 100664258);
	}

	// Token: 0x06000C5A RID: 3162 RVA: 0x0000210C File Offset: 0x0000030C
	public BulletHit(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000441 RID: 1089
	// (get) Token: 0x06000C5B RID: 3163 RVA: 0x000323FC File Offset: 0x000305FC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BulletHit>.NativeClassPtr));
		}
	}

	// Token: 0x17000442 RID: 1090
	// (get) Token: 0x06000C5C RID: 3164 RVA: 0x00032410 File Offset: 0x00030610
	// (set) Token: 0x06000C5D RID: 3165 RVA: 0x00032444 File Offset: 0x00030644
	public unsafe GameObject PF_OnHit
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_PF_OnHit);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_PF_OnHit), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000443 RID: 1091
	// (get) Token: 0x06000C5E RID: 3166 RVA: 0x0003246C File Offset: 0x0003066C
	// (set) Token: 0x06000C5F RID: 3167 RVA: 0x00032494 File Offset: 0x00030694
	public unsafe bool isPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_isPlayer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_isPlayer)) = value;
		}
	}

	// Token: 0x17000444 RID: 1092
	// (get) Token: 0x06000C60 RID: 3168 RVA: 0x000324B8 File Offset: 0x000306B8
	// (set) Token: 0x06000C61 RID: 3169 RVA: 0x000324EC File Offset: 0x000306EC
	public unsafe Il2CppReferenceArray<AudioClip> Gun_Ricochets
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_Gun_Ricochets);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<AudioClip>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletHit.NativeFieldInfoPtr_Gun_Ricochets), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000774 RID: 1908
	private static readonly IntPtr NativeFieldInfoPtr_PF_OnHit;

	// Token: 0x04000775 RID: 1909
	private static readonly IntPtr NativeFieldInfoPtr_isPlayer;

	// Token: 0x04000776 RID: 1910
	private static readonly IntPtr NativeFieldInfoPtr_Gun_Ricochets;

	// Token: 0x04000777 RID: 1911
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000778 RID: 1912
	private static readonly IntPtr NativeMethodInfoPtr_TurnOnCollider_Private_Void_0;

	// Token: 0x04000779 RID: 1913
	private static readonly IntPtr NativeMethodInfoPtr_PlayHitSound_Public_Void_0;

	// Token: 0x0400077A RID: 1914
	private static readonly IntPtr NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0;

	// Token: 0x0400077B RID: 1915
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
