﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000D0 RID: 208
public sealed class DisableFogInTent : MonoBehaviour
{
	// Token: 0x06000CCF RID: 3279 RVA: 0x00033E54 File Offset: 0x00032054
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x00033E98 File Offset: 0x00032098
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x00033EDC File Offset: 0x000320DC
	[CallerCount(0)]
	public unsafe void OnBackToTent(bool tentActive)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref tentActive;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_OnBackToTent_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00033F30 File Offset: 0x00032130
	[CallerCount(0)]
	public unsafe void OnPlayerSpawned()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_OnPlayerSpawned_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD3 RID: 3283 RVA: 0x00033F74 File Offset: 0x00032174
	[CallerCount(0)]
	public unsafe void OnStartVRSpectate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_OnStartVRSpectate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD4 RID: 3284 RVA: 0x00033FB8 File Offset: 0x000321B8
	[CallerCount(0)]
	public unsafe void OnEndVRSpectate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr_OnEndVRSpectate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD5 RID: 3285 RVA: 0x00033FFC File Offset: 0x000321FC
	[CallerCount(0)]
	public unsafe DisableFogInTent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableFogInTent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CD6 RID: 3286 RVA: 0x00034048 File Offset: 0x00032248
	// Note: this type is marked as 'beforefieldinit'.
	static DisableFogInTent()
	{
		Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DisableFogInTent");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr);
		DisableFogInTent.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664296);
		DisableFogInTent.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664297);
		DisableFogInTent.NativeMethodInfoPtr_OnBackToTent_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664298);
		DisableFogInTent.NativeMethodInfoPtr_OnPlayerSpawned_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664299);
		DisableFogInTent.NativeMethodInfoPtr_OnStartVRSpectate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664300);
		DisableFogInTent.NativeMethodInfoPtr_OnEndVRSpectate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664301);
		DisableFogInTent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr, 100664302);
	}

	// Token: 0x06000CD7 RID: 3287 RVA: 0x0000210C File Offset: 0x0000030C
	public DisableFogInTent(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700046B RID: 1131
	// (get) Token: 0x06000CD8 RID: 3288 RVA: 0x00034104 File Offset: 0x00032304
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DisableFogInTent>.NativeClassPtr));
		}
	}

	// Token: 0x040007BE RID: 1982
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x040007BF RID: 1983
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x040007C0 RID: 1984
	private static readonly IntPtr NativeMethodInfoPtr_OnBackToTent_Private_Void_Boolean_0;

	// Token: 0x040007C1 RID: 1985
	private static readonly IntPtr NativeMethodInfoPtr_OnPlayerSpawned_Private_Void_0;

	// Token: 0x040007C2 RID: 1986
	private static readonly IntPtr NativeMethodInfoPtr_OnStartVRSpectate_Private_Void_0;

	// Token: 0x040007C3 RID: 1987
	private static readonly IntPtr NativeMethodInfoPtr_OnEndVRSpectate_Private_Void_0;

	// Token: 0x040007C4 RID: 1988
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
