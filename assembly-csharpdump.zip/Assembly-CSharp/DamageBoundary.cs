﻿using System;
using System.Runtime.InteropServices;
using DPI.Networking;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000189 RID: 393
public class DamageBoundary : MonoBehaviour
{
	// Token: 0x06001A57 RID: 6743 RVA: 0x00068F7C File Offset: 0x0006717C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A58 RID: 6744 RVA: 0x00068FC0 File Offset: 0x000671C0
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A59 RID: 6745 RVA: 0x00069004 File Offset: 0x00067204
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A5A RID: 6746 RVA: 0x00069048 File Offset: 0x00067248
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A5B RID: 6747 RVA: 0x0006908C File Offset: 0x0006728C
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A5C RID: 6748 RVA: 0x000690D0 File Offset: 0x000672D0
	[CallerCount(0)]
	public unsafe void OnTriggerEnter(Collider col)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A5D RID: 6749 RVA: 0x0006912C File Offset: 0x0006732C
	[CallerCount(0)]
	public unsafe bool TryGetDamageControllerOwnedByLocalPlayer(Collider col, out DamageController damageController)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(damageController);
		ptr2 = &intPtr;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_TryGetDamageControllerOwnedByLocalPlayer_Private_Boolean_Collider_byref_DamageController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		damageController = ((intPtr2 == 0) ? null : new DamageController(intPtr2));
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001A5E RID: 6750 RVA: 0x000691CC File Offset: 0x000673CC
	[CallerCount(0)]
	public unsafe void OnTriggerExit(Collider col)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_OnTriggerExit_Private_Void_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A5F RID: 6751 RVA: 0x00069228 File Offset: 0x00067428
	[CallerCount(0)]
	public unsafe void CleanCollider(Collider col)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_CleanCollider_Private_Void_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A60 RID: 6752 RVA: 0x00069284 File Offset: 0x00067484
	[CallerCount(0)]
	public unsafe void ResetThis()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_ResetThis_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A61 RID: 6753 RVA: 0x000692C8 File Offset: 0x000674C8
	[CallerCount(0)]
	public unsafe static bool IsDamageControllerOutOfBounds(DamageController controller)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(controller);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_IsDamageControllerOutOfBounds_Public_Static_Boolean_DamageController_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001A62 RID: 6754 RVA: 0x00069320 File Offset: 0x00067520
	[CallerCount(0)]
	public unsafe bool IsDamageControllerInside(DamageController controller)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(controller);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr_IsDamageControllerInside_Public_Boolean_DamageController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001A63 RID: 6755 RVA: 0x00069388 File Offset: 0x00067588
	[CallerCount(0)]
	public unsafe DamageBoundary() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundary.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A64 RID: 6756 RVA: 0x000693D4 File Offset: 0x000675D4
	// Note: this type is marked as 'beforefieldinit'.
	static DamageBoundary()
	{
		Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageBoundary");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr);
		DamageBoundary.NativeFieldInfoPtr_OnReset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "OnReset");
		DamageBoundary.NativeFieldInfoPtr_AllBoundaries = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "AllBoundaries");
		DamageBoundary.NativeFieldInfoPtr_damageAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "damageAmount");
		DamageBoundary.NativeFieldInfoPtr_periodicintervals = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "periodicintervals");
		DamageBoundary.NativeFieldInfoPtr_ignoreFirstTick = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "ignoreFirstTick");
		DamageBoundary.NativeFieldInfoPtr_showUIWarning = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "showUIWarning");
		DamageBoundary.NativeFieldInfoPtr_damageType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "damageType");
		DamageBoundary.NativeFieldInfoPtr_CanCheckBounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "CanCheckBounds");
		DamageBoundary.NativeFieldInfoPtr_TargetFaction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "TargetFaction");
		DamageBoundary.NativeFieldInfoPtr_BoxColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "BoxColliders");
		DamageBoundary.NativeFieldInfoPtr_OwningPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "OwningPlayer");
		DamageBoundary.NativeFieldInfoPtr_AllCollidersInside = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "AllCollidersInside");
		DamageBoundary.NativeFieldInfoPtr_BadColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "BadColliders");
		DamageBoundary.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665388);
		DamageBoundary.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665389);
		DamageBoundary.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665390);
		DamageBoundary.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665391);
		DamageBoundary.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665392);
		DamageBoundary.NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665393);
		DamageBoundary.NativeMethodInfoPtr_TryGetDamageControllerOwnedByLocalPlayer_Private_Boolean_Collider_byref_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665394);
		DamageBoundary.NativeMethodInfoPtr_OnTriggerExit_Private_Void_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665395);
		DamageBoundary.NativeMethodInfoPtr_CleanCollider_Private_Void_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665396);
		DamageBoundary.NativeMethodInfoPtr_ResetThis_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665397);
		DamageBoundary.NativeMethodInfoPtr_IsDamageControllerOutOfBounds_Public_Static_Boolean_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665398);
		DamageBoundary.NativeMethodInfoPtr_IsDamageControllerInside_Public_Boolean_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665399);
		DamageBoundary.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, 100665400);
	}

	// Token: 0x06001A65 RID: 6757 RVA: 0x0000210C File Offset: 0x0000030C
	public DamageBoundary(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000924 RID: 2340
	// (get) Token: 0x06001A66 RID: 6758 RVA: 0x0006960C File Offset: 0x0006780C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr));
		}
	}

	// Token: 0x17000925 RID: 2341
	// (get) Token: 0x06001A67 RID: 6759 RVA: 0x00069620 File Offset: 0x00067820
	// (set) Token: 0x06001A68 RID: 6760 RVA: 0x0006964B File Offset: 0x0006784B
	public unsafe static Action OnReset
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageBoundary.NativeFieldInfoPtr_OnReset, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBoundary.NativeFieldInfoPtr_OnReset, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000926 RID: 2342
	// (get) Token: 0x06001A69 RID: 6761 RVA: 0x00069660 File Offset: 0x00067860
	// (set) Token: 0x06001A6A RID: 6762 RVA: 0x0006968B File Offset: 0x0006788B
	public unsafe static HashSet<DamageBoundary> AllBoundaries
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageBoundary.NativeFieldInfoPtr_AllBoundaries, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HashSet<DamageBoundary>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBoundary.NativeFieldInfoPtr_AllBoundaries, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000927 RID: 2343
	// (get) Token: 0x06001A6B RID: 6763 RVA: 0x000696A0 File Offset: 0x000678A0
	// (set) Token: 0x06001A6C RID: 6764 RVA: 0x000696C8 File Offset: 0x000678C8
	public unsafe float damageAmount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_damageAmount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_damageAmount)) = value;
		}
	}

	// Token: 0x17000928 RID: 2344
	// (get) Token: 0x06001A6D RID: 6765 RVA: 0x000696EC File Offset: 0x000678EC
	// (set) Token: 0x06001A6E RID: 6766 RVA: 0x00069714 File Offset: 0x00067914
	public unsafe float periodicintervals
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_periodicintervals);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_periodicintervals)) = value;
		}
	}

	// Token: 0x17000929 RID: 2345
	// (get) Token: 0x06001A6F RID: 6767 RVA: 0x00069738 File Offset: 0x00067938
	// (set) Token: 0x06001A70 RID: 6768 RVA: 0x00069760 File Offset: 0x00067960
	public unsafe bool ignoreFirstTick
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_ignoreFirstTick);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_ignoreFirstTick)) = value;
		}
	}

	// Token: 0x1700092A RID: 2346
	// (get) Token: 0x06001A71 RID: 6769 RVA: 0x00069784 File Offset: 0x00067984
	// (set) Token: 0x06001A72 RID: 6770 RVA: 0x000697AC File Offset: 0x000679AC
	public unsafe bool showUIWarning
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_showUIWarning);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_showUIWarning)) = value;
		}
	}

	// Token: 0x1700092B RID: 2347
	// (get) Token: 0x06001A73 RID: 6771 RVA: 0x000697D0 File Offset: 0x000679D0
	// (set) Token: 0x06001A74 RID: 6772 RVA: 0x000697F8 File Offset: 0x000679F8
	public unsafe DamageType damageType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_damageType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_damageType)) = value;
		}
	}

	// Token: 0x1700092C RID: 2348
	// (get) Token: 0x06001A75 RID: 6773 RVA: 0x0006981C File Offset: 0x00067A1C
	// (set) Token: 0x06001A76 RID: 6774 RVA: 0x0006983A File Offset: 0x00067A3A
	public unsafe static bool CanCheckBounds
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(DamageBoundary.NativeFieldInfoPtr_CanCheckBounds, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBoundary.NativeFieldInfoPtr_CanCheckBounds, (void*)(&value));
		}
	}

	// Token: 0x1700092D RID: 2349
	// (get) Token: 0x06001A77 RID: 6775 RVA: 0x0006984C File Offset: 0x00067A4C
	// (set) Token: 0x06001A78 RID: 6776 RVA: 0x00069874 File Offset: 0x00067A74
	public unsafe Faction TargetFaction
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_TargetFaction);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_TargetFaction)) = value;
		}
	}

	// Token: 0x1700092E RID: 2350
	// (get) Token: 0x06001A79 RID: 6777 RVA: 0x00069898 File Offset: 0x00067A98
	// (set) Token: 0x06001A7A RID: 6778 RVA: 0x000698CC File Offset: 0x00067ACC
	public unsafe List<BoxCollider> BoxColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_BoxColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<BoxCollider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_BoxColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700092F RID: 2351
	// (get) Token: 0x06001A7B RID: 6779 RVA: 0x000698F4 File Offset: 0x00067AF4
	// (set) Token: 0x06001A7C RID: 6780 RVA: 0x00069928 File Offset: 0x00067B28
	public unsafe DPIPlayer OwningPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_OwningPlayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DPIPlayer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_OwningPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000930 RID: 2352
	// (get) Token: 0x06001A7D RID: 6781 RVA: 0x00069950 File Offset: 0x00067B50
	// (set) Token: 0x06001A7E RID: 6782 RVA: 0x00069984 File Offset: 0x00067B84
	public unsafe Dictionary<Collider, DamageController> AllCollidersInside
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_AllCollidersInside);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<Collider, DamageController>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_AllCollidersInside), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000931 RID: 2353
	// (get) Token: 0x06001A7F RID: 6783 RVA: 0x000699AC File Offset: 0x00067BAC
	// (set) Token: 0x06001A80 RID: 6784 RVA: 0x000699E0 File Offset: 0x00067BE0
	public unsafe List<Collider> BadColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_BadColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<Collider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.NativeFieldInfoPtr_BadColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040010E1 RID: 4321
	private static readonly IntPtr NativeFieldInfoPtr_OnReset;

	// Token: 0x040010E2 RID: 4322
	private static readonly IntPtr NativeFieldInfoPtr_AllBoundaries;

	// Token: 0x040010E3 RID: 4323
	private static readonly IntPtr NativeFieldInfoPtr_damageAmount;

	// Token: 0x040010E4 RID: 4324
	private static readonly IntPtr NativeFieldInfoPtr_periodicintervals;

	// Token: 0x040010E5 RID: 4325
	private static readonly IntPtr NativeFieldInfoPtr_ignoreFirstTick;

	// Token: 0x040010E6 RID: 4326
	private static readonly IntPtr NativeFieldInfoPtr_showUIWarning;

	// Token: 0x040010E7 RID: 4327
	private static readonly IntPtr NativeFieldInfoPtr_damageType;

	// Token: 0x040010E8 RID: 4328
	private static readonly IntPtr NativeFieldInfoPtr_CanCheckBounds;

	// Token: 0x040010E9 RID: 4329
	private static readonly IntPtr NativeFieldInfoPtr_TargetFaction;

	// Token: 0x040010EA RID: 4330
	private static readonly IntPtr NativeFieldInfoPtr_BoxColliders;

	// Token: 0x040010EB RID: 4331
	private static readonly IntPtr NativeFieldInfoPtr_OwningPlayer;

	// Token: 0x040010EC RID: 4332
	private static readonly IntPtr NativeFieldInfoPtr_AllCollidersInside;

	// Token: 0x040010ED RID: 4333
	private static readonly IntPtr NativeFieldInfoPtr_BadColliders;

	// Token: 0x040010EE RID: 4334
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x040010EF RID: 4335
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x040010F0 RID: 4336
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040010F1 RID: 4337
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x040010F2 RID: 4338
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x040010F3 RID: 4339
	private static readonly IntPtr NativeMethodInfoPtr_OnTriggerEnter_Private_Void_Collider_0;

	// Token: 0x040010F4 RID: 4340
	private static readonly IntPtr NativeMethodInfoPtr_TryGetDamageControllerOwnedByLocalPlayer_Private_Boolean_Collider_byref_DamageController_0;

	// Token: 0x040010F5 RID: 4341
	private static readonly IntPtr NativeMethodInfoPtr_OnTriggerExit_Private_Void_Collider_0;

	// Token: 0x040010F6 RID: 4342
	private static readonly IntPtr NativeMethodInfoPtr_CleanCollider_Private_Void_Collider_0;

	// Token: 0x040010F7 RID: 4343
	private static readonly IntPtr NativeMethodInfoPtr_ResetThis_Private_Void_0;

	// Token: 0x040010F8 RID: 4344
	private static readonly IntPtr NativeMethodInfoPtr_IsDamageControllerOutOfBounds_Public_Static_Boolean_DamageController_0;

	// Token: 0x040010F9 RID: 4345
	private static readonly IntPtr NativeMethodInfoPtr_IsDamageControllerInside_Public_Boolean_DamageController_0;

	// Token: 0x040010FA RID: 4346
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200018A RID: 394
	[StructLayout(0)]
	public sealed class ColliderComponents : ValueType
	{
		// Token: 0x06001A81 RID: 6785 RVA: 0x00069A08 File Offset: 0x00067C08
		// Note: this type is marked as 'beforefieldinit'.
		static ColliderComponents()
		{
			Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageBoundary>.NativeClassPtr, "ColliderComponents");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr);
			DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Body = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr, "Body");
			DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Controller = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr, "Controller");
			DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Player = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr, "Player");
		}

		// Token: 0x06001A82 RID: 6786 RVA: 0x0002717B File Offset: 0x0002537B
		public ColliderComponents(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000932 RID: 2354
		// (get) Token: 0x06001A83 RID: 6787 RVA: 0x00069A6F File Offset: 0x00067C6F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr));
			}
		}

		// Token: 0x06001A84 RID: 6788 RVA: 0x00069A80 File Offset: 0x00067C80
		public unsafe ColliderComponents()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<DamageBoundary.ColliderComponents>.NativeClassPtr, data));
		}

		// Token: 0x17000933 RID: 2355
		// (get) Token: 0x06001A85 RID: 6789 RVA: 0x00069AB0 File Offset: 0x00067CB0
		// (set) Token: 0x06001A86 RID: 6790 RVA: 0x00069AE4 File Offset: 0x00067CE4
		public unsafe DamageBody Body
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Body);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageBody(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Body), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000934 RID: 2356
		// (get) Token: 0x06001A87 RID: 6791 RVA: 0x00069B0C File Offset: 0x00067D0C
		// (set) Token: 0x06001A88 RID: 6792 RVA: 0x00069B40 File Offset: 0x00067D40
		public unsafe DamageController Controller
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Controller);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Controller), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000935 RID: 2357
		// (get) Token: 0x06001A89 RID: 6793 RVA: 0x00069B68 File Offset: 0x00067D68
		// (set) Token: 0x06001A8A RID: 6794 RVA: 0x00069B9C File Offset: 0x00067D9C
		public unsafe WarPlayerScript Player
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Player);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundary.ColliderComponents.NativeFieldInfoPtr_Player), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040010FB RID: 4347
		private static readonly IntPtr NativeFieldInfoPtr_Body;

		// Token: 0x040010FC RID: 4348
		private static readonly IntPtr NativeFieldInfoPtr_Controller;

		// Token: 0x040010FD RID: 4349
		private static readonly IntPtr NativeFieldInfoPtr_Player;
	}
}
