﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x020004A4 RID: 1188
[Serializable]
public class ConnectParams : Object
{
	// Token: 0x06005EAD RID: 24237 RVA: 0x0017AB28 File Offset: 0x00178D28
	[CallerCount(0)]
	public unsafe ConnectParams() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectParams.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005EAE RID: 24238 RVA: 0x0017AB74 File Offset: 0x00178D74
	// Note: this type is marked as 'beforefieldinit'.
	static ConnectParams()
	{
		Il2CppClassPointerStore<ConnectParams>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConnectParams");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr);
		ConnectParams.NativeFieldInfoPtr_username = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr, "username");
		ConnectParams.NativeFieldInfoPtr_lobby = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr, "lobby");
		ConnectParams.NativeFieldInfoPtr_type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr, "type");
		ConnectParams.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr, 100670784);
	}

	// Token: 0x06005EAF RID: 24239 RVA: 0x00002988 File Offset: 0x00000B88
	public ConnectParams(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170021A3 RID: 8611
	// (get) Token: 0x06005EB0 RID: 24240 RVA: 0x0017ABF4 File Offset: 0x00178DF4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConnectParams>.NativeClassPtr));
		}
	}

	// Token: 0x170021A4 RID: 8612
	// (get) Token: 0x06005EB1 RID: 24241 RVA: 0x0017AC08 File Offset: 0x00178E08
	// (set) Token: 0x06005EB2 RID: 24242 RVA: 0x0017AC31 File Offset: 0x00178E31
	public unsafe string username
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_username);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_username), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x170021A5 RID: 8613
	// (get) Token: 0x06005EB3 RID: 24243 RVA: 0x0017AC58 File Offset: 0x00178E58
	// (set) Token: 0x06005EB4 RID: 24244 RVA: 0x0017AC81 File Offset: 0x00178E81
	public unsafe string lobby
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_lobby);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_lobby), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x170021A6 RID: 8614
	// (get) Token: 0x06005EB5 RID: 24245 RVA: 0x0017ACA8 File Offset: 0x00178EA8
	// (set) Token: 0x06005EB6 RID: 24246 RVA: 0x0017ACD1 File Offset: 0x00178ED1
	public unsafe string type
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_type);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectParams.NativeFieldInfoPtr_type), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x04003BD0 RID: 15312
	private static readonly IntPtr NativeFieldInfoPtr_username;

	// Token: 0x04003BD1 RID: 15313
	private static readonly IntPtr NativeFieldInfoPtr_lobby;

	// Token: 0x04003BD2 RID: 15314
	private static readonly IntPtr NativeFieldInfoPtr_type;

	// Token: 0x04003BD3 RID: 15315
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
