﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200048A RID: 1162
public class ConstantList<T> : Object
{
	// Token: 0x1700211C RID: 8476
	// (get) Token: 0x06005D10 RID: 23824 RVA: 0x00173E0C File Offset: 0x0017200C
	public unsafe List<T> List
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_get_List_Public_get_List_1_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<T>(intPtr2) : null;
		}
	}

	// Token: 0x1700211D RID: 8477
	// (get) Token: 0x06005D11 RID: 23825 RVA: 0x00173E64 File Offset: 0x00172064
	public unsafe int Count
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_get_Count_Public_Virtual_Final_New_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x1700211E RID: 8478
	// (get) Token: 0x06005D12 RID: 23826 RVA: 0x00173EB4 File Offset: 0x001720B4
	public unsafe bool IsReadOnly
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_get_IsReadOnly_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06005D13 RID: 23827 RVA: 0x00173F04 File Offset: 0x00172104
	[CallerCount(0)]
	public unsafe ConstantList() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D14 RID: 23828 RVA: 0x00173F50 File Offset: 0x00172150
	[CallerCount(0)]
	public unsafe ConstantList(int initialSize) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref initialSize;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x1700211F RID: 8479
	public unsafe T this[int index]
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref index;
			IntPtr returnedException;
			IntPtr objectPointer = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_get_Item_Public_Virtual_Final_New_get_T_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.PointerToValueGeneric<T>(objectPointer, false, true);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref index;
			IntPtr* ptr2 = ptr + checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr);
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = value;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref value;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_set_Item_Public_Virtual_Final_New_set_Void_Int32_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06005D17 RID: 23831 RVA: 0x001740D0 File Offset: 0x001722D0
	[CallerCount(0)]
	public unsafe IEnumerator<T> GetEnumerator()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_GetEnumerator_Public_Virtual_Final_New_IEnumerator_1_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator<T>(intPtr2) : null;
	}

	// Token: 0x06005D18 RID: 23832 RVA: 0x00174128 File Offset: 0x00172328
	[CallerCount(0)]
	public unsafe IEnumerator System_Collections_IEnumerable_GetEnumerator()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06005D19 RID: 23833 RVA: 0x00174180 File Offset: 0x00172380
	[CallerCount(0)]
	public unsafe void Add(T item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		IntPtr* ptr2 = ptr;
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = item;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref item;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_Add_Public_Virtual_Final_New_Void_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D1A RID: 23834 RVA: 0x0017422C File Offset: 0x0017242C
	[CallerCount(0)]
	public unsafe void Insert(int index, T item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref index;
		IntPtr* ptr2 = ptr + checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr);
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = item;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref item;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_Insert_Public_Virtual_Final_New_Void_Int32_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D1B RID: 23835 RVA: 0x001742EC File Offset: 0x001724EC
	[CallerCount(0)]
	public unsafe bool Remove(T item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		IntPtr* ptr2 = ptr;
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = item;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref item;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_Remove_Public_Virtual_Final_New_Boolean_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005D1C RID: 23836 RVA: 0x001743A8 File Offset: 0x001725A8
	[CallerCount(0)]
	public unsafe void RemoveAt(int index)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref index;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_RemoveAt_Public_Virtual_Final_New_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D1D RID: 23837 RVA: 0x001743FC File Offset: 0x001725FC
	[CallerCount(0)]
	public unsafe void Clear()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_Clear_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D1E RID: 23838 RVA: 0x00174440 File Offset: 0x00172640
	[CallerCount(0)]
	public unsafe bool Contains(T item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		IntPtr* ptr2 = ptr;
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = item;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref item;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_Contains_Public_Virtual_Final_New_Boolean_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005D1F RID: 23839 RVA: 0x001744FC File Offset: 0x001726FC
	[CallerCount(0)]
	public unsafe int IndexOf(T item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		IntPtr* ptr2 = ptr;
		T ptr4;
		if (!typeof(T).IsValueType)
		{
			T t = item;
			if (!(t is string))
			{
				ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
				if (ref ptr3 != null)
				{
					ptr4 = ref ptr3;
					if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
					{
						ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
					}
				}
			}
			else
			{
				ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
			}
		}
		else
		{
			ptr4 = ref item;
		}
		*ptr2 = ref ptr4;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_IndexOf_Public_Virtual_Final_New_Int32_T_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005D20 RID: 23840 RVA: 0x001745B8 File Offset: 0x001727B8
	[CallerCount(0)]
	public unsafe void CopyTo(Il2CppArrayBase<T> array, int arrayIndex)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(array);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref arrayIndex;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConstantList<T>.NativeMethodInfoPtr_CopyTo_Public_Virtual_Final_New_Void_ArrayOf_T_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005D21 RID: 23841 RVA: 0x00174624 File Offset: 0x00172824
	// Note: this type is marked as 'beforefieldinit'.
	static ConstantList()
	{
		Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr = IL2CPP.il2cpp_class_from_type(Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConstantList`1"))).MakeGenericType(new Il2CppReferenceArray<Type>(new Type[]
		{
			Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
		})).TypeHandle.value);
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr);
		ConstantList<T>.NativeFieldInfoPtr_indexed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, "indexed");
		ConstantList<T>.NativeFieldInfoPtr_keyed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, "keyed");
		ConstantList<T>.NativeMethodInfoPtr_get_List_Public_get_List_1_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670621);
		ConstantList<T>.NativeMethodInfoPtr_get_Count_Public_Virtual_Final_New_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670622);
		ConstantList<T>.NativeMethodInfoPtr_get_IsReadOnly_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670623);
		ConstantList<T>.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670624);
		ConstantList<T>.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670625);
		ConstantList<T>.NativeMethodInfoPtr_get_Item_Public_Virtual_Final_New_get_T_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670626);
		ConstantList<T>.NativeMethodInfoPtr_set_Item_Public_Virtual_Final_New_set_Void_Int32_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670627);
		ConstantList<T>.NativeMethodInfoPtr_GetEnumerator_Public_Virtual_Final_New_IEnumerator_1_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670628);
		ConstantList<T>.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670629);
		ConstantList<T>.NativeMethodInfoPtr_Add_Public_Virtual_Final_New_Void_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670630);
		ConstantList<T>.NativeMethodInfoPtr_Insert_Public_Virtual_Final_New_Void_Int32_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670631);
		ConstantList<T>.NativeMethodInfoPtr_Remove_Public_Virtual_Final_New_Boolean_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670632);
		ConstantList<T>.NativeMethodInfoPtr_RemoveAt_Public_Virtual_Final_New_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670633);
		ConstantList<T>.NativeMethodInfoPtr_Clear_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670634);
		ConstantList<T>.NativeMethodInfoPtr_Contains_Public_Virtual_Final_New_Boolean_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670635);
		ConstantList<T>.NativeMethodInfoPtr_IndexOf_Public_Virtual_Final_New_Int32_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670636);
		ConstantList<T>.NativeMethodInfoPtr_CopyTo_Public_Virtual_Final_New_Void_ArrayOf_T_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr, 100670637);
	}

	// Token: 0x06005D22 RID: 23842 RVA: 0x00002988 File Offset: 0x00000B88
	public ConstantList(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002119 RID: 8473
	// (get) Token: 0x06005D23 RID: 23843 RVA: 0x0017480B File Offset: 0x00172A0B
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConstantList<T>>.NativeClassPtr));
		}
	}

	// Token: 0x1700211A RID: 8474
	// (get) Token: 0x06005D24 RID: 23844 RVA: 0x0017481C File Offset: 0x00172A1C
	// (set) Token: 0x06005D25 RID: 23845 RVA: 0x00174850 File Offset: 0x00172A50
	public unsafe List<T> indexed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConstantList<T>.NativeFieldInfoPtr_indexed);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<T>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConstantList<T>.NativeFieldInfoPtr_indexed), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700211B RID: 8475
	// (get) Token: 0x06005D26 RID: 23846 RVA: 0x00174878 File Offset: 0x00172A78
	// (set) Token: 0x06005D27 RID: 23847 RVA: 0x001748AC File Offset: 0x00172AAC
	public unsafe Dictionary<T, int> keyed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConstantList<T>.NativeFieldInfoPtr_keyed);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<T, int>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConstantList<T>.NativeFieldInfoPtr_keyed), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04003AC5 RID: 15045
	private static readonly IntPtr NativeFieldInfoPtr_indexed;

	// Token: 0x04003AC6 RID: 15046
	private static readonly IntPtr NativeFieldInfoPtr_keyed;

	// Token: 0x04003AC7 RID: 15047
	private static readonly IntPtr NativeMethodInfoPtr_get_List_Public_get_List_1_T_0;

	// Token: 0x04003AC8 RID: 15048
	private static readonly IntPtr NativeMethodInfoPtr_get_Count_Public_Virtual_Final_New_get_Int32_0;

	// Token: 0x04003AC9 RID: 15049
	private static readonly IntPtr NativeMethodInfoPtr_get_IsReadOnly_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04003ACA RID: 15050
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x04003ACB RID: 15051
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

	// Token: 0x04003ACC RID: 15052
	private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_Virtual_Final_New_get_T_Int32_0;

	// Token: 0x04003ACD RID: 15053
	private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_Virtual_Final_New_set_Void_Int32_T_0;

	// Token: 0x04003ACE RID: 15054
	private static readonly IntPtr NativeMethodInfoPtr_GetEnumerator_Public_Virtual_Final_New_IEnumerator_1_T_0;

	// Token: 0x04003ACF RID: 15055
	private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0;

	// Token: 0x04003AD0 RID: 15056
	private static readonly IntPtr NativeMethodInfoPtr_Add_Public_Virtual_Final_New_Void_T_0;

	// Token: 0x04003AD1 RID: 15057
	private static readonly IntPtr NativeMethodInfoPtr_Insert_Public_Virtual_Final_New_Void_Int32_T_0;

	// Token: 0x04003AD2 RID: 15058
	private static readonly IntPtr NativeMethodInfoPtr_Remove_Public_Virtual_Final_New_Boolean_T_0;

	// Token: 0x04003AD3 RID: 15059
	private static readonly IntPtr NativeMethodInfoPtr_RemoveAt_Public_Virtual_Final_New_Void_Int32_0;

	// Token: 0x04003AD4 RID: 15060
	private static readonly IntPtr NativeMethodInfoPtr_Clear_Public_Virtual_Final_New_Void_0;

	// Token: 0x04003AD5 RID: 15061
	private static readonly IntPtr NativeMethodInfoPtr_Contains_Public_Virtual_Final_New_Boolean_T_0;

	// Token: 0x04003AD6 RID: 15062
	private static readonly IntPtr NativeMethodInfoPtr_IndexOf_Public_Virtual_Final_New_Int32_T_0;

	// Token: 0x04003AD7 RID: 15063
	private static readonly IntPtr NativeMethodInfoPtr_CopyTo_Public_Virtual_Final_New_Void_ArrayOf_T_Int32_0;
}
