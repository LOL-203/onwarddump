﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004F7 RID: 1271
public class DamageLibrary : MonoBehaviour
{
	// Token: 0x170024BB RID: 9403
	// (get) Token: 0x06006756 RID: 26454 RVA: 0x0019ECAC File Offset: 0x0019CEAC
	// (set) Token: 0x06006757 RID: 26455 RVA: 0x0019ECF4 File Offset: 0x0019CEF4
	public unsafe static DamageLibrary Singleton
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_get_Singleton_Public_Static_get_DamageLibrary_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DamageLibrary(intPtr2) : null;
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_DamageLibrary_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06006758 RID: 26456 RVA: 0x0019ED40 File Offset: 0x0019CF40
	[CallerCount(0)]
	public unsafe static float GetDamageFalloff(float distance, ClassLoadout.AmmoType ammoType)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref distance;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref ammoType;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetDamageFalloff_Public_Static_Single_Single_AmmoType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06006759 RID: 26457 RVA: 0x0019EDA8 File Offset: 0x0019CFA8
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600675A RID: 26458 RVA: 0x0019EDEC File Offset: 0x0019CFEC
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600675B RID: 26459 RVA: 0x0019EE30 File Offset: 0x0019D030
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600675C RID: 26460 RVA: 0x0019EE74 File Offset: 0x0019D074
	[CallerCount(0)]
	public unsafe void Initialize()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600675D RID: 26461 RVA: 0x0019EEB8 File Offset: 0x0019D0B8
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600675E RID: 26462 RVA: 0x0019EEFC File Offset: 0x0019D0FC
	[CallerCount(0)]
	public unsafe static float GetDamageModifier(PhysicMaterial material, [In] ref ClassLoadout.AmmoType ammoType, out bool foundMaterial)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &ammoType;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &foundMaterial;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetDamageModifier_Public_Static_Single_PhysicMaterial_byref_AmmoType_byref_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x0600675F RID: 26463 RVA: 0x0019EF7C File Offset: 0x0019D17C
	[CallerCount(0)]
	public unsafe static float GetGrenadeDamageModifier(PhysicMaterial material)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetGrenadeDamageModifier_Public_Static_Single_PhysicMaterial_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06006760 RID: 26464 RVA: 0x0019EFD4 File Offset: 0x0019D1D4
	[CallerCount(0)]
	public unsafe static bool CanRicochetOffMaterial(PhysicMaterial material)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_CanRicochetOffMaterial_Public_Static_Boolean_PhysicMaterial_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06006761 RID: 26465 RVA: 0x0019F02C File Offset: 0x0019D22C
	[CallerCount(0)]
	public unsafe static DamageLibrary.PenetrationInfo GetPenetrationInfo(PhysicMaterial material)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetPenetrationInfo_Public_Static_PenetrationInfo_PhysicMaterial_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new DamageLibrary.PenetrationInfo(intPtr2) : null;
	}

	// Token: 0x06006762 RID: 26466 RVA: 0x0019F08C File Offset: 0x0019D28C
	[CallerCount(0)]
	public unsafe static DamageLibrary.MaterialType GetMaterialType(PhysicMaterial material, ref bool bulletHolesAllowed, ref bool bulletImpactAllowed)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &bulletHolesAllowed;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &bulletImpactAllowed;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_byref_Boolean_byref_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06006763 RID: 26467 RVA: 0x0019F10C File Offset: 0x0019D30C
	[CallerCount(0)]
	public unsafe static DamageLibrary.MaterialType GetMaterialType(PhysicMaterial material)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(material);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06006764 RID: 26468 RVA: 0x0019F164 File Offset: 0x0019D364
	[CallerCount(0)]
	public unsafe DamageLibrary() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006765 RID: 26469 RVA: 0x0019F1B0 File Offset: 0x0019D3B0
	// Note: this type is marked as 'beforefieldinit'.
	static DamageLibrary()
	{
		Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageLibrary");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr);
		DamageLibrary.NativeFieldInfoPtr__Singleton_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "<Singleton>k__BackingField");
		DamageLibrary.NativeFieldInfoPtr_EnableDebugLogs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "EnableDebugLogs");
		DamageLibrary.NativeFieldInfoPtr_HasInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "HasInitialized");
		DamageLibrary.NativeFieldInfoPtr_DamageCurveMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "DamageCurveMultiplier");
		DamageLibrary.NativeFieldInfoPtr_FalloffData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "FalloffData");
		DamageLibrary.NativeFieldInfoPtr_Library = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "Library");
		DamageLibrary.NativeFieldInfoPtr_LibraryDict = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "LibraryDict");
		DamageLibrary.NativeFieldInfoPtr_MaxNumObjectsPenetrate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "MaxNumObjectsPenetrate");
		DamageLibrary.NativeFieldInfoPtr_MinDamagePercentage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "MinDamagePercentage");
		DamageLibrary.NativeMethodInfoPtr_get_Singleton_Public_Static_get_DamageLibrary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671502);
		DamageLibrary.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_DamageLibrary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671503);
		DamageLibrary.NativeMethodInfoPtr_GetDamageFalloff_Public_Static_Single_Single_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671504);
		DamageLibrary.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671505);
		DamageLibrary.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671506);
		DamageLibrary.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671507);
		DamageLibrary.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671508);
		DamageLibrary.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671509);
		DamageLibrary.NativeMethodInfoPtr_GetDamageModifier_Public_Static_Single_PhysicMaterial_byref_AmmoType_byref_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671510);
		DamageLibrary.NativeMethodInfoPtr_GetGrenadeDamageModifier_Public_Static_Single_PhysicMaterial_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671511);
		DamageLibrary.NativeMethodInfoPtr_CanRicochetOffMaterial_Public_Static_Boolean_PhysicMaterial_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671512);
		DamageLibrary.NativeMethodInfoPtr_GetPenetrationInfo_Public_Static_PenetrationInfo_PhysicMaterial_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671513);
		DamageLibrary.NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_byref_Boolean_byref_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671514);
		DamageLibrary.NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671515);
		DamageLibrary.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, 100671516);
	}

	// Token: 0x06006766 RID: 26470 RVA: 0x0000210C File Offset: 0x0000030C
	public DamageLibrary(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170024B1 RID: 9393
	// (get) Token: 0x06006767 RID: 26471 RVA: 0x0019F3C0 File Offset: 0x0019D5C0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr));
		}
	}

	// Token: 0x170024B2 RID: 9394
	// (get) Token: 0x06006768 RID: 26472 RVA: 0x0019F3D4 File Offset: 0x0019D5D4
	// (set) Token: 0x06006769 RID: 26473 RVA: 0x0019F3FF File Offset: 0x0019D5FF
	public unsafe static DamageLibrary _Singleton_k__BackingField
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DamageLibrary.NativeFieldInfoPtr__Singleton_k__BackingField, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DamageLibrary(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageLibrary.NativeFieldInfoPtr__Singleton_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024B3 RID: 9395
	// (get) Token: 0x0600676A RID: 26474 RVA: 0x0019F414 File Offset: 0x0019D614
	// (set) Token: 0x0600676B RID: 26475 RVA: 0x0019F43C File Offset: 0x0019D63C
	public unsafe bool EnableDebugLogs
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_EnableDebugLogs);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_EnableDebugLogs)) = value;
		}
	}

	// Token: 0x170024B4 RID: 9396
	// (get) Token: 0x0600676C RID: 26476 RVA: 0x0019F460 File Offset: 0x0019D660
	// (set) Token: 0x0600676D RID: 26477 RVA: 0x0019F488 File Offset: 0x0019D688
	public unsafe bool HasInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_HasInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_HasInitialized)) = value;
		}
	}

	// Token: 0x170024B5 RID: 9397
	// (get) Token: 0x0600676E RID: 26478 RVA: 0x0019F4AC File Offset: 0x0019D6AC
	// (set) Token: 0x0600676F RID: 26479 RVA: 0x0019F4CA File Offset: 0x0019D6CA
	public unsafe static float DamageCurveMultiplier
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(DamageLibrary.NativeFieldInfoPtr_DamageCurveMultiplier, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageLibrary.NativeFieldInfoPtr_DamageCurveMultiplier, (void*)(&value));
		}
	}

	// Token: 0x170024B6 RID: 9398
	// (get) Token: 0x06006770 RID: 26480 RVA: 0x0019F4DC File Offset: 0x0019D6DC
	// (set) Token: 0x06006771 RID: 26481 RVA: 0x0019F510 File Offset: 0x0019D710
	public unsafe DamageFalloffData FalloffData
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_FalloffData);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageFalloffData(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_FalloffData), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024B7 RID: 9399
	// (get) Token: 0x06006772 RID: 26482 RVA: 0x0019F538 File Offset: 0x0019D738
	// (set) Token: 0x06006773 RID: 26483 RVA: 0x0019F56C File Offset: 0x0019D76C
	public unsafe Il2CppReferenceArray<DamageLibrary.PenetrationInfo> Library
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_Library);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<DamageLibrary.PenetrationInfo>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_Library), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024B8 RID: 9400
	// (get) Token: 0x06006774 RID: 26484 RVA: 0x0019F594 File Offset: 0x0019D794
	// (set) Token: 0x06006775 RID: 26485 RVA: 0x0019F5C8 File Offset: 0x0019D7C8
	public unsafe Dictionary<PhysicMaterial, DamageLibrary.PenetrationInfo> LibraryDict
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_LibraryDict);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<PhysicMaterial, DamageLibrary.PenetrationInfo>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_LibraryDict), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024B9 RID: 9401
	// (get) Token: 0x06006776 RID: 26486 RVA: 0x0019F5F0 File Offset: 0x0019D7F0
	// (set) Token: 0x06006777 RID: 26487 RVA: 0x0019F618 File Offset: 0x0019D818
	public unsafe int MaxNumObjectsPenetrate
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_MaxNumObjectsPenetrate);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_MaxNumObjectsPenetrate)) = value;
		}
	}

	// Token: 0x170024BA RID: 9402
	// (get) Token: 0x06006778 RID: 26488 RVA: 0x0019F63C File Offset: 0x0019D83C
	// (set) Token: 0x06006779 RID: 26489 RVA: 0x0019F664 File Offset: 0x0019D864
	public unsafe float MinDamagePercentage
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_MinDamagePercentage);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.NativeFieldInfoPtr_MinDamagePercentage)) = value;
		}
	}

	// Token: 0x04004137 RID: 16695
	private static readonly IntPtr NativeFieldInfoPtr__Singleton_k__BackingField;

	// Token: 0x04004138 RID: 16696
	private static readonly IntPtr NativeFieldInfoPtr_EnableDebugLogs;

	// Token: 0x04004139 RID: 16697
	private static readonly IntPtr NativeFieldInfoPtr_HasInitialized;

	// Token: 0x0400413A RID: 16698
	private static readonly IntPtr NativeFieldInfoPtr_DamageCurveMultiplier;

	// Token: 0x0400413B RID: 16699
	private static readonly IntPtr NativeFieldInfoPtr_FalloffData;

	// Token: 0x0400413C RID: 16700
	private static readonly IntPtr NativeFieldInfoPtr_Library;

	// Token: 0x0400413D RID: 16701
	private static readonly IntPtr NativeFieldInfoPtr_LibraryDict;

	// Token: 0x0400413E RID: 16702
	private static readonly IntPtr NativeFieldInfoPtr_MaxNumObjectsPenetrate;

	// Token: 0x0400413F RID: 16703
	private static readonly IntPtr NativeFieldInfoPtr_MinDamagePercentage;

	// Token: 0x04004140 RID: 16704
	private static readonly IntPtr NativeMethodInfoPtr_get_Singleton_Public_Static_get_DamageLibrary_0;

	// Token: 0x04004141 RID: 16705
	private static readonly IntPtr NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_DamageLibrary_0;

	// Token: 0x04004142 RID: 16706
	private static readonly IntPtr NativeMethodInfoPtr_GetDamageFalloff_Public_Static_Single_Single_AmmoType_0;

	// Token: 0x04004143 RID: 16707
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04004144 RID: 16708
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04004145 RID: 16709
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04004146 RID: 16710
	private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

	// Token: 0x04004147 RID: 16711
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x04004148 RID: 16712
	private static readonly IntPtr NativeMethodInfoPtr_GetDamageModifier_Public_Static_Single_PhysicMaterial_byref_AmmoType_byref_Boolean_0;

	// Token: 0x04004149 RID: 16713
	private static readonly IntPtr NativeMethodInfoPtr_GetGrenadeDamageModifier_Public_Static_Single_PhysicMaterial_0;

	// Token: 0x0400414A RID: 16714
	private static readonly IntPtr NativeMethodInfoPtr_CanRicochetOffMaterial_Public_Static_Boolean_PhysicMaterial_0;

	// Token: 0x0400414B RID: 16715
	private static readonly IntPtr NativeMethodInfoPtr_GetPenetrationInfo_Public_Static_PenetrationInfo_PhysicMaterial_0;

	// Token: 0x0400414C RID: 16716
	private static readonly IntPtr NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_byref_Boolean_byref_Boolean_0;

	// Token: 0x0400414D RID: 16717
	private static readonly IntPtr NativeMethodInfoPtr_GetMaterialType_Public_Static_MaterialType_PhysicMaterial_0;

	// Token: 0x0400414E RID: 16718
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020004F8 RID: 1272
	public enum MaterialType
	{
		// Token: 0x04004150 RID: 16720
		NULL,
		// Token: 0x04004151 RID: 16721
		Metal,
		// Token: 0x04004152 RID: 16722
		Concrete,
		// Token: 0x04004153 RID: 16723
		Wood,
		// Token: 0x04004154 RID: 16724
		AIHitbox,
		// Token: 0x04004155 RID: 16725
		Dirt,
		// Token: 0x04004156 RID: 16726
		Glass,
		// Token: 0x04004157 RID: 16727
		Water,
		// Token: 0x04004158 RID: 16728
		Cloth,
		// Token: 0x04004159 RID: 16729
		Taser,
		// Token: 0x0400415A RID: 16730
		Grass,
		// Token: 0x0400415B RID: 16731
		Body,
		// Token: 0x0400415C RID: 16732
		Snow,
		// Token: 0x0400415D RID: 16733
		Ice,
		// Token: 0x0400415E RID: 16734
		WoodOld
	}

	// Token: 0x020004F9 RID: 1273
	[Serializable]
	public class PenetrationInfo : Il2CppSystem.Object
	{
		// Token: 0x0600677C RID: 26492 RVA: 0x0019F6AC File Offset: 0x0019D8AC
		[CallerCount(0)]
		public unsafe PenetrationInfo() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageLibrary.PenetrationInfo.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600677D RID: 26493 RVA: 0x0019F6F8 File Offset: 0x0019D8F8
		// Note: this type is marked as 'beforefieldinit'.
		static PenetrationInfo()
		{
			Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageLibrary>.NativeClassPtr, "PenetrationInfo");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr);
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "Name");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_material = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "material");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_bulletDamageModifier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "bulletDamageModifier");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_grenadeDamageModifier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "grenadeDamageModifier");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_materialType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "materialType");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_FMJ = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "Penetrable_FMJ");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_AP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "Penetrable_AP");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_BulletsDamageAndIgnore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "BulletsDamageAndIgnore");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnImpactFX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "SpawnImpactFX");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnBulletHoleFX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "SpawnBulletHoleFX");
			DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_FragmentRicochets = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, "FragmentRicochets");
			DamageLibrary.PenetrationInfo.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr, 100671517);
		}

		// Token: 0x0600677E RID: 26494 RVA: 0x00002988 File Offset: 0x00000B88
		public PenetrationInfo(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170024BD RID: 9405
		// (get) Token: 0x0600677F RID: 26495 RVA: 0x0019F813 File Offset: 0x0019DA13
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageLibrary.PenetrationInfo>.NativeClassPtr));
			}
		}

		// Token: 0x170024BE RID: 9406
		// (get) Token: 0x06006780 RID: 26496 RVA: 0x0019F824 File Offset: 0x0019DA24
		// (set) Token: 0x06006781 RID: 26497 RVA: 0x0019F84D File Offset: 0x0019DA4D
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170024BF RID: 9407
		// (get) Token: 0x06006782 RID: 26498 RVA: 0x0019F874 File Offset: 0x0019DA74
		// (set) Token: 0x06006783 RID: 26499 RVA: 0x0019F8A8 File Offset: 0x0019DAA8
		public unsafe PhysicMaterial material
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_material);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PhysicMaterial(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_material), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170024C0 RID: 9408
		// (get) Token: 0x06006784 RID: 26500 RVA: 0x0019F8D0 File Offset: 0x0019DAD0
		// (set) Token: 0x06006785 RID: 26501 RVA: 0x0019F8F8 File Offset: 0x0019DAF8
		public unsafe float bulletDamageModifier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_bulletDamageModifier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_bulletDamageModifier)) = value;
			}
		}

		// Token: 0x170024C1 RID: 9409
		// (get) Token: 0x06006786 RID: 26502 RVA: 0x0019F91C File Offset: 0x0019DB1C
		// (set) Token: 0x06006787 RID: 26503 RVA: 0x0019F944 File Offset: 0x0019DB44
		public unsafe float grenadeDamageModifier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_grenadeDamageModifier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_grenadeDamageModifier)) = value;
			}
		}

		// Token: 0x170024C2 RID: 9410
		// (get) Token: 0x06006788 RID: 26504 RVA: 0x0019F968 File Offset: 0x0019DB68
		// (set) Token: 0x06006789 RID: 26505 RVA: 0x0019F990 File Offset: 0x0019DB90
		public unsafe DamageLibrary.MaterialType materialType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_materialType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_materialType)) = value;
			}
		}

		// Token: 0x170024C3 RID: 9411
		// (get) Token: 0x0600678A RID: 26506 RVA: 0x0019F9B4 File Offset: 0x0019DBB4
		// (set) Token: 0x0600678B RID: 26507 RVA: 0x0019F9DC File Offset: 0x0019DBDC
		public unsafe bool Penetrable_FMJ
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_FMJ);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_FMJ)) = value;
			}
		}

		// Token: 0x170024C4 RID: 9412
		// (get) Token: 0x0600678C RID: 26508 RVA: 0x0019FA00 File Offset: 0x0019DC00
		// (set) Token: 0x0600678D RID: 26509 RVA: 0x0019FA28 File Offset: 0x0019DC28
		public unsafe bool Penetrable_AP
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_AP);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_Penetrable_AP)) = value;
			}
		}

		// Token: 0x170024C5 RID: 9413
		// (get) Token: 0x0600678E RID: 26510 RVA: 0x0019FA4C File Offset: 0x0019DC4C
		// (set) Token: 0x0600678F RID: 26511 RVA: 0x0019FA74 File Offset: 0x0019DC74
		public unsafe bool BulletsDamageAndIgnore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_BulletsDamageAndIgnore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_BulletsDamageAndIgnore)) = value;
			}
		}

		// Token: 0x170024C6 RID: 9414
		// (get) Token: 0x06006790 RID: 26512 RVA: 0x0019FA98 File Offset: 0x0019DC98
		// (set) Token: 0x06006791 RID: 26513 RVA: 0x0019FAC0 File Offset: 0x0019DCC0
		public unsafe bool SpawnImpactFX
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnImpactFX);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnImpactFX)) = value;
			}
		}

		// Token: 0x170024C7 RID: 9415
		// (get) Token: 0x06006792 RID: 26514 RVA: 0x0019FAE4 File Offset: 0x0019DCE4
		// (set) Token: 0x06006793 RID: 26515 RVA: 0x0019FB0C File Offset: 0x0019DD0C
		public unsafe bool SpawnBulletHoleFX
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnBulletHoleFX);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_SpawnBulletHoleFX)) = value;
			}
		}

		// Token: 0x170024C8 RID: 9416
		// (get) Token: 0x06006794 RID: 26516 RVA: 0x0019FB30 File Offset: 0x0019DD30
		// (set) Token: 0x06006795 RID: 26517 RVA: 0x0019FB58 File Offset: 0x0019DD58
		public unsafe bool FragmentRicochets
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_FragmentRicochets);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageLibrary.PenetrationInfo.NativeFieldInfoPtr_FragmentRicochets)) = value;
			}
		}

		// Token: 0x0400415F RID: 16735
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x04004160 RID: 16736
		private static readonly IntPtr NativeFieldInfoPtr_material;

		// Token: 0x04004161 RID: 16737
		private static readonly IntPtr NativeFieldInfoPtr_bulletDamageModifier;

		// Token: 0x04004162 RID: 16738
		private static readonly IntPtr NativeFieldInfoPtr_grenadeDamageModifier;

		// Token: 0x04004163 RID: 16739
		private static readonly IntPtr NativeFieldInfoPtr_materialType;

		// Token: 0x04004164 RID: 16740
		private static readonly IntPtr NativeFieldInfoPtr_Penetrable_FMJ;

		// Token: 0x04004165 RID: 16741
		private static readonly IntPtr NativeFieldInfoPtr_Penetrable_AP;

		// Token: 0x04004166 RID: 16742
		private static readonly IntPtr NativeFieldInfoPtr_BulletsDamageAndIgnore;

		// Token: 0x04004167 RID: 16743
		private static readonly IntPtr NativeFieldInfoPtr_SpawnImpactFX;

		// Token: 0x04004168 RID: 16744
		private static readonly IntPtr NativeFieldInfoPtr_SpawnBulletHoleFX;

		// Token: 0x04004169 RID: 16745
		private static readonly IntPtr NativeFieldInfoPtr_FragmentRicochets;

		// Token: 0x0400416A RID: 16746
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
