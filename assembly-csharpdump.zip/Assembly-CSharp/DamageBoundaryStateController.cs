﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200018C RID: 396
public class DamageBoundaryStateController : Il2CppSystem.Object
{
	// Token: 0x06001AA1 RID: 6817 RVA: 0x0006A1A4 File Offset: 0x000683A4
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryStateController.NativeMethodInfoPtr_Update_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AA2 RID: 6818 RVA: 0x0006A1E8 File Offset: 0x000683E8
	[CallerCount(0)]
	public unsafe void ColliderEnteredDamageBoundary(Collider col, DamageBoundary damageBoundaries)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageBoundaries);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryStateController.NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AA3 RID: 6819 RVA: 0x0006A25C File Offset: 0x0006845C
	[CallerCount(0)]
	public unsafe void ColliderExitedDamageBoundary(Collider col, DamageBoundary damageBoundaries)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageBoundaries);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryStateController.NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AA4 RID: 6820 RVA: 0x0006A2D0 File Offset: 0x000684D0
	[CallerCount(0)]
	public unsafe DamageBoundaryStateController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryStateController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001AA5 RID: 6821 RVA: 0x0006A31C File Offset: 0x0006851C
	// Note: this type is marked as 'beforefieldinit'.
	static DamageBoundaryStateController()
	{
		Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageBoundaryStateController");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr);
		DamageBoundaryStateController.NativeFieldInfoPtr_DamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, "DamageController");
		DamageBoundaryStateController.NativeFieldInfoPtr_damageBoundaryStates = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, "damageBoundaryStates");
		DamageBoundaryStateController.NativeMethodInfoPtr_Update_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, 100665409);
		DamageBoundaryStateController.NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, 100665410);
		DamageBoundaryStateController.NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, 100665411);
		DamageBoundaryStateController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr, 100665412);
	}

	// Token: 0x06001AA6 RID: 6822 RVA: 0x00002988 File Offset: 0x00000B88
	public DamageBoundaryStateController(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700093D RID: 2365
	// (get) Token: 0x06001AA7 RID: 6823 RVA: 0x0006A3C4 File Offset: 0x000685C4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageBoundaryStateController>.NativeClassPtr));
		}
	}

	// Token: 0x1700093E RID: 2366
	// (get) Token: 0x06001AA8 RID: 6824 RVA: 0x0006A3D8 File Offset: 0x000685D8
	// (set) Token: 0x06001AA9 RID: 6825 RVA: 0x0006A40C File Offset: 0x0006860C
	public unsafe DamageController DamageController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryStateController.NativeFieldInfoPtr_DamageController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryStateController.NativeFieldInfoPtr_DamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700093F RID: 2367
	// (get) Token: 0x06001AAA RID: 6826 RVA: 0x0006A434 File Offset: 0x00068634
	// (set) Token: 0x06001AAB RID: 6827 RVA: 0x0006A468 File Offset: 0x00068668
	public unsafe Dictionary<DamageType, DamageBoundaryState> damageBoundaryStates
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryStateController.NativeFieldInfoPtr_damageBoundaryStates);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<DamageType, DamageBoundaryState>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryStateController.NativeFieldInfoPtr_damageBoundaryStates), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400110B RID: 4363
	private static readonly IntPtr NativeFieldInfoPtr_DamageController;

	// Token: 0x0400110C RID: 4364
	private static readonly IntPtr NativeFieldInfoPtr_damageBoundaryStates;

	// Token: 0x0400110D RID: 4365
	private static readonly IntPtr NativeMethodInfoPtr_Update_Public_Void_0;

	// Token: 0x0400110E RID: 4366
	private static readonly IntPtr NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0;

	// Token: 0x0400110F RID: 4367
	private static readonly IntPtr NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0;

	// Token: 0x04001110 RID: 4368
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
