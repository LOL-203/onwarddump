﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.Rendering.Universal;

// Token: 0x02000171 RID: 369
public class CameraCache : MonoBehaviour
{
	// Token: 0x0600185B RID: 6235 RVA: 0x00061658 File Offset: 0x0005F858
	[CallerCount(0)]
	public unsafe static void ToggleCulling(bool on)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref on;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_ToggleCulling_Public_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17000877 RID: 2167
	// (get) Token: 0x0600185C RID: 6236 RVA: 0x000616A0 File Offset: 0x0005F8A0
	public unsafe static Camera MainCamera
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_get_MainCamera_Public_Static_get_Camera_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
	}

	// Token: 0x17000878 RID: 2168
	// (get) Token: 0x0600185D RID: 6237 RVA: 0x000616E8 File Offset: 0x0005F8E8
	public unsafe static Camera RelevantCamera
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_get_RelevantCamera_Public_Static_get_Camera_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
	}

	// Token: 0x0600185E RID: 6238 RVA: 0x00061730 File Offset: 0x0005F930
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_OnEnable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600185F RID: 6239 RVA: 0x00061774 File Offset: 0x0005F974
	[CallerCount(0)]
	public unsafe void OnLocalToggleCulling(bool on)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref on;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_OnLocalToggleCulling_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001860 RID: 6240 RVA: 0x000617C8 File Offset: 0x0005F9C8
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_OnDisable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001861 RID: 6241 RVA: 0x0006180C File Offset: 0x0005FA0C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_Start_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001862 RID: 6242 RVA: 0x00061850 File Offset: 0x0005FA50
	[CallerCount(0)]
	public unsafe static void ForceToActiveCamera(Camera cam)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(cam);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_ForceToActiveCamera_Public_Static_Void_Camera_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001863 RID: 6243 RVA: 0x0006189C File Offset: 0x0005FA9C
	[CallerCount(0)]
	public unsafe static void ClearReferences()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_ClearReferences_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001864 RID: 6244 RVA: 0x000618D0 File Offset: 0x0005FAD0
	[CallerCount(0)]
	public unsafe static void RefreshReferences()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_RefreshReferences_Protected_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001865 RID: 6245 RVA: 0x00061904 File Offset: 0x0005FB04
	[CallerCount(0)]
	public unsafe static void UpdateReference(ref Camera reference, Action<Camera> action, bool desktop, bool requireActiveDesktop)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		ref IntPtr ptr2 = ref *ptr;
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(reference);
		ptr2 = &intPtr;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(action);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref desktop;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref requireActiveDesktop;
		IntPtr returnedException;
		IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_UpdateReference_Protected_Static_Void_byref_Camera_Action_1_Camera_Boolean_Boolean_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr3 = intPtr;
		reference = ((intPtr3 == 0) ? null : new Camera(intPtr3));
	}

	// Token: 0x06001866 RID: 6246 RVA: 0x000619AC File Offset: 0x0005FBAC
	[CallerCount(0)]
	public unsafe static CameraCache GetBestAvailableCache()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_GetBestAvailableCache_Protected_Static_CameraCache_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new CameraCache(intPtr2) : null;
	}

	// Token: 0x06001867 RID: 6247 RVA: 0x000619F4 File Offset: 0x0005FBF4
	[CallerCount(0)]
	public unsafe static void ChangeMain()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_ChangeMain_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001868 RID: 6248 RVA: 0x00061A28 File Offset: 0x0005FC28
	[CallerCount(0)]
	public unsafe static void PrintCaches()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_PrintCaches_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001869 RID: 6249 RVA: 0x00061A5C File Offset: 0x0005FC5C
	[CallerCount(0)]
	public unsafe void OnUsingPostprocessingChanged(bool used)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref used;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_OnUsingPostprocessingChanged_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186A RID: 6250 RVA: 0x00061AB0 File Offset: 0x0005FCB0
	[CallerCount(0)]
	public unsafe void SetDisablePostprocessingOverride(bool disable)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref disable;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_SetDisablePostprocessingOverride_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186B RID: 6251 RVA: 0x00061B04 File Offset: 0x0005FD04
	[CallerCount(0)]
	public unsafe void RefreshPostProcessing()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_RefreshPostProcessing_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186C RID: 6252 RVA: 0x00061B48 File Offset: 0x0005FD48
	[CallerCount(0)]
	public unsafe void RefreshFarClipPlane()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_RefreshFarClipPlane_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186D RID: 6253 RVA: 0x00061B8C File Offset: 0x0005FD8C
	[CallerCount(0)]
	public unsafe void SetPostProcessing(bool active)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref active;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_SetPostProcessing_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186E RID: 6254 RVA: 0x00061BE0 File Offset: 0x0005FDE0
	[CallerCount(0)]
	public unsafe void SetSkyboxesEnabled(bool skyboxesEnabled)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref skyboxesEnabled;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_SetSkyboxesEnabled_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600186F RID: 6255 RVA: 0x00061C34 File Offset: 0x0005FE34
	[CallerCount(0)]
	public unsafe void RefreshSkyboxesEnabled()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_RefreshSkyboxesEnabled_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001870 RID: 6256 RVA: 0x00061C78 File Offset: 0x0005FE78
	[CallerCount(0)]
	public unsafe void OnSkyboxesEnabledChanged(bool skyboxesEnabled)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref skyboxesEnabled;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr_OnSkyboxesEnabledChanged_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001871 RID: 6257 RVA: 0x00061CCC File Offset: 0x0005FECC
	[CallerCount(0)]
	public unsafe CameraCache() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraCache>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraCache.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001872 RID: 6258 RVA: 0x00061D18 File Offset: 0x0005FF18
	// Note: this type is marked as 'beforefieldinit'.
	static CameraCache()
	{
		Il2CppClassPointerStore<CameraCache>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraCache");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraCache>.NativeClassPtr);
		CameraCache.NativeFieldInfoPtr_OnToggleCulling = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "OnToggleCulling");
		CameraCache.NativeFieldInfoPtr_Cache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "Cache");
		CameraCache.NativeFieldInfoPtr_Data = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "Data");
		CameraCache.NativeFieldInfoPtr_ProximityTintImmunity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "ProximityTintImmunity");
		CameraCache.NativeFieldInfoPtr_UpdatesFarClipPlane = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "UpdatesFarClipPlane");
		CameraCache.NativeFieldInfoPtr_ForceActivateOcclusion = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "ForceActivateOcclusion");
		CameraCache.NativeFieldInfoPtr__mainCamera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "_mainCamera");
		CameraCache.NativeFieldInfoPtr_hasCamera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "hasCamera");
		CameraCache.NativeFieldInfoPtr_disablePostProcessingOverride = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "disablePostProcessingOverride");
		CameraCache.NativeFieldInfoPtr_OnMainCameraChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "OnMainCameraChanged");
		CameraCache.NativeFieldInfoPtr_Caches = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, "Caches");
		CameraCache.NativeMethodInfoPtr_ToggleCulling_Public_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665239);
		CameraCache.NativeMethodInfoPtr_get_MainCamera_Public_Static_get_Camera_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665240);
		CameraCache.NativeMethodInfoPtr_get_RelevantCamera_Public_Static_get_Camera_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665241);
		CameraCache.NativeMethodInfoPtr_OnEnable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665242);
		CameraCache.NativeMethodInfoPtr_OnLocalToggleCulling_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665243);
		CameraCache.NativeMethodInfoPtr_OnDisable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665244);
		CameraCache.NativeMethodInfoPtr_Start_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665245);
		CameraCache.NativeMethodInfoPtr_ForceToActiveCamera_Public_Static_Void_Camera_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665246);
		CameraCache.NativeMethodInfoPtr_ClearReferences_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665247);
		CameraCache.NativeMethodInfoPtr_RefreshReferences_Protected_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665248);
		CameraCache.NativeMethodInfoPtr_UpdateReference_Protected_Static_Void_byref_Camera_Action_1_Camera_Boolean_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665249);
		CameraCache.NativeMethodInfoPtr_GetBestAvailableCache_Protected_Static_CameraCache_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665250);
		CameraCache.NativeMethodInfoPtr_ChangeMain_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665251);
		CameraCache.NativeMethodInfoPtr_PrintCaches_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665252);
		CameraCache.NativeMethodInfoPtr_OnUsingPostprocessingChanged_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665253);
		CameraCache.NativeMethodInfoPtr_SetDisablePostprocessingOverride_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665254);
		CameraCache.NativeMethodInfoPtr_RefreshPostProcessing_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665255);
		CameraCache.NativeMethodInfoPtr_RefreshFarClipPlane_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665256);
		CameraCache.NativeMethodInfoPtr_SetPostProcessing_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665257);
		CameraCache.NativeMethodInfoPtr_SetSkyboxesEnabled_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665258);
		CameraCache.NativeMethodInfoPtr_RefreshSkyboxesEnabled_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665259);
		CameraCache.NativeMethodInfoPtr_OnSkyboxesEnabledChanged_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665260);
		CameraCache.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraCache>.NativeClassPtr, 100665261);
	}

	// Token: 0x06001873 RID: 6259 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraCache(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700086B RID: 2155
	// (get) Token: 0x06001874 RID: 6260 RVA: 0x00061FF0 File Offset: 0x000601F0
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraCache>.NativeClassPtr));
		}
	}

	// Token: 0x1700086C RID: 2156
	// (get) Token: 0x06001875 RID: 6261 RVA: 0x00062004 File Offset: 0x00060204
	// (set) Token: 0x06001876 RID: 6262 RVA: 0x0006202F File Offset: 0x0006022F
	public unsafe static Action<bool> OnToggleCulling
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CameraCache.NativeFieldInfoPtr_OnToggleCulling, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<bool>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CameraCache.NativeFieldInfoPtr_OnToggleCulling, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700086D RID: 2157
	// (get) Token: 0x06001877 RID: 6263 RVA: 0x00062044 File Offset: 0x00060244
	// (set) Token: 0x06001878 RID: 6264 RVA: 0x00062078 File Offset: 0x00060278
	public unsafe Camera Cache
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_Cache);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_Cache), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700086E RID: 2158
	// (get) Token: 0x06001879 RID: 6265 RVA: 0x000620A0 File Offset: 0x000602A0
	// (set) Token: 0x0600187A RID: 6266 RVA: 0x000620D4 File Offset: 0x000602D4
	public unsafe UniversalAdditionalCameraData Data
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_Data);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new UniversalAdditionalCameraData(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_Data), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700086F RID: 2159
	// (get) Token: 0x0600187B RID: 6267 RVA: 0x000620FC File Offset: 0x000602FC
	// (set) Token: 0x0600187C RID: 6268 RVA: 0x00062130 File Offset: 0x00060330
	public unsafe ProximityTintImmunity ProximityTintImmunity
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_ProximityTintImmunity);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ProximityTintImmunity(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_ProximityTintImmunity), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000870 RID: 2160
	// (get) Token: 0x0600187D RID: 6269 RVA: 0x00062158 File Offset: 0x00060358
	// (set) Token: 0x0600187E RID: 6270 RVA: 0x00062180 File Offset: 0x00060380
	public unsafe bool UpdatesFarClipPlane
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_UpdatesFarClipPlane);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_UpdatesFarClipPlane)) = value;
		}
	}

	// Token: 0x17000871 RID: 2161
	// (get) Token: 0x0600187F RID: 6271 RVA: 0x000621A4 File Offset: 0x000603A4
	// (set) Token: 0x06001880 RID: 6272 RVA: 0x000621CC File Offset: 0x000603CC
	public unsafe bool ForceActivateOcclusion
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_ForceActivateOcclusion);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_ForceActivateOcclusion)) = value;
		}
	}

	// Token: 0x17000872 RID: 2162
	// (get) Token: 0x06001881 RID: 6273 RVA: 0x000621F0 File Offset: 0x000603F0
	// (set) Token: 0x06001882 RID: 6274 RVA: 0x0006221B File Offset: 0x0006041B
	public unsafe static Camera _mainCamera
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CameraCache.NativeFieldInfoPtr__mainCamera, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Camera(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CameraCache.NativeFieldInfoPtr__mainCamera, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000873 RID: 2163
	// (get) Token: 0x06001883 RID: 6275 RVA: 0x00062230 File Offset: 0x00060430
	// (set) Token: 0x06001884 RID: 6276 RVA: 0x0006224E File Offset: 0x0006044E
	public unsafe static bool hasCamera
	{
		get
		{
			bool result;
			IL2CPP.il2cpp_field_static_get_value(CameraCache.NativeFieldInfoPtr_hasCamera, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CameraCache.NativeFieldInfoPtr_hasCamera, (void*)(&value));
		}
	}

	// Token: 0x17000874 RID: 2164
	// (get) Token: 0x06001885 RID: 6277 RVA: 0x00062260 File Offset: 0x00060460
	// (set) Token: 0x06001886 RID: 6278 RVA: 0x00062288 File Offset: 0x00060488
	public unsafe bool disablePostProcessingOverride
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_disablePostProcessingOverride);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraCache.NativeFieldInfoPtr_disablePostProcessingOverride)) = value;
		}
	}

	// Token: 0x17000875 RID: 2165
	// (get) Token: 0x06001887 RID: 6279 RVA: 0x000622AC File Offset: 0x000604AC
	// (set) Token: 0x06001888 RID: 6280 RVA: 0x000622D7 File Offset: 0x000604D7
	public unsafe static Action<Camera> OnMainCameraChanged
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CameraCache.NativeFieldInfoPtr_OnMainCameraChanged, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action<Camera>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CameraCache.NativeFieldInfoPtr_OnMainCameraChanged, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000876 RID: 2166
	// (get) Token: 0x06001889 RID: 6281 RVA: 0x000622EC File Offset: 0x000604EC
	// (set) Token: 0x0600188A RID: 6282 RVA: 0x00062317 File Offset: 0x00060517
	public unsafe static HashSet<CameraCache> Caches
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CameraCache.NativeFieldInfoPtr_Caches, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HashSet<CameraCache>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CameraCache.NativeFieldInfoPtr_Caches, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000FB5 RID: 4021
	private static readonly IntPtr NativeFieldInfoPtr_OnToggleCulling;

	// Token: 0x04000FB6 RID: 4022
	private static readonly IntPtr NativeFieldInfoPtr_Cache;

	// Token: 0x04000FB7 RID: 4023
	private static readonly IntPtr NativeFieldInfoPtr_Data;

	// Token: 0x04000FB8 RID: 4024
	private static readonly IntPtr NativeFieldInfoPtr_ProximityTintImmunity;

	// Token: 0x04000FB9 RID: 4025
	private static readonly IntPtr NativeFieldInfoPtr_UpdatesFarClipPlane;

	// Token: 0x04000FBA RID: 4026
	private static readonly IntPtr NativeFieldInfoPtr_ForceActivateOcclusion;

	// Token: 0x04000FBB RID: 4027
	private static readonly IntPtr NativeFieldInfoPtr__mainCamera;

	// Token: 0x04000FBC RID: 4028
	private static readonly IntPtr NativeFieldInfoPtr_hasCamera;

	// Token: 0x04000FBD RID: 4029
	private static readonly IntPtr NativeFieldInfoPtr_disablePostProcessingOverride;

	// Token: 0x04000FBE RID: 4030
	private static readonly IntPtr NativeFieldInfoPtr_OnMainCameraChanged;

	// Token: 0x04000FBF RID: 4031
	private static readonly IntPtr NativeFieldInfoPtr_Caches;

	// Token: 0x04000FC0 RID: 4032
	private static readonly IntPtr NativeMethodInfoPtr_ToggleCulling_Public_Static_Void_Boolean_0;

	// Token: 0x04000FC1 RID: 4033
	private static readonly IntPtr NativeMethodInfoPtr_get_MainCamera_Public_Static_get_Camera_0;

	// Token: 0x04000FC2 RID: 4034
	private static readonly IntPtr NativeMethodInfoPtr_get_RelevantCamera_Public_Static_get_Camera_0;

	// Token: 0x04000FC3 RID: 4035
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Void_0;

	// Token: 0x04000FC4 RID: 4036
	private static readonly IntPtr NativeMethodInfoPtr_OnLocalToggleCulling_Private_Void_Boolean_0;

	// Token: 0x04000FC5 RID: 4037
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Protected_Void_0;

	// Token: 0x04000FC6 RID: 4038
	private static readonly IntPtr NativeMethodInfoPtr_Start_Protected_Void_0;

	// Token: 0x04000FC7 RID: 4039
	private static readonly IntPtr NativeMethodInfoPtr_ForceToActiveCamera_Public_Static_Void_Camera_0;

	// Token: 0x04000FC8 RID: 4040
	private static readonly IntPtr NativeMethodInfoPtr_ClearReferences_Public_Static_Void_0;

	// Token: 0x04000FC9 RID: 4041
	private static readonly IntPtr NativeMethodInfoPtr_RefreshReferences_Protected_Static_Void_0;

	// Token: 0x04000FCA RID: 4042
	private static readonly IntPtr NativeMethodInfoPtr_UpdateReference_Protected_Static_Void_byref_Camera_Action_1_Camera_Boolean_Boolean_0;

	// Token: 0x04000FCB RID: 4043
	private static readonly IntPtr NativeMethodInfoPtr_GetBestAvailableCache_Protected_Static_CameraCache_0;

	// Token: 0x04000FCC RID: 4044
	private static readonly IntPtr NativeMethodInfoPtr_ChangeMain_Public_Static_Void_0;

	// Token: 0x04000FCD RID: 4045
	private static readonly IntPtr NativeMethodInfoPtr_PrintCaches_Public_Static_Void_0;

	// Token: 0x04000FCE RID: 4046
	private static readonly IntPtr NativeMethodInfoPtr_OnUsingPostprocessingChanged_Protected_Void_Boolean_0;

	// Token: 0x04000FCF RID: 4047
	private static readonly IntPtr NativeMethodInfoPtr_SetDisablePostprocessingOverride_Public_Void_Boolean_0;

	// Token: 0x04000FD0 RID: 4048
	private static readonly IntPtr NativeMethodInfoPtr_RefreshPostProcessing_Protected_Void_0;

	// Token: 0x04000FD1 RID: 4049
	private static readonly IntPtr NativeMethodInfoPtr_RefreshFarClipPlane_Private_Void_0;

	// Token: 0x04000FD2 RID: 4050
	private static readonly IntPtr NativeMethodInfoPtr_SetPostProcessing_Protected_Void_Boolean_0;

	// Token: 0x04000FD3 RID: 4051
	private static readonly IntPtr NativeMethodInfoPtr_SetSkyboxesEnabled_Protected_Void_Boolean_0;

	// Token: 0x04000FD4 RID: 4052
	private static readonly IntPtr NativeMethodInfoPtr_RefreshSkyboxesEnabled_Protected_Void_0;

	// Token: 0x04000FD5 RID: 4053
	private static readonly IntPtr NativeMethodInfoPtr_OnSkyboxesEnabledChanged_Protected_Void_Boolean_0;

	// Token: 0x04000FD6 RID: 4054
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
