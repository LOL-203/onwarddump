﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace com.ootii.MeshMerge
{
	// Token: 0x0200079F RID: 1951
	public class MergedMesh : MonoBehaviour
	{
		// Token: 0x0600A215 RID: 41493 RVA: 0x0028FEA8 File Offset: 0x0028E0A8
		[CallerCount(0)]
		public unsafe MergedMesh() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MergedMesh>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MergedMesh.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600A216 RID: 41494 RVA: 0x0028FEF4 File Offset: 0x0028E0F4
		// Note: this type is marked as 'beforefieldinit'.
		static MergedMesh()
		{
			Il2CppClassPointerStore<MergedMesh>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "com.ootii.MeshMerge", "MergedMesh");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MergedMesh>.NativeClassPtr);
			MergedMesh.NativeFieldInfoPtr_MeshFilterIDs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MergedMesh>.NativeClassPtr, "MeshFilterIDs");
			MergedMesh.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MergedMesh>.NativeClassPtr, 100676136);
		}

		// Token: 0x0600A217 RID: 41495 RVA: 0x0000210C File Offset: 0x0000030C
		public MergedMesh(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17003A1F RID: 14879
		// (get) Token: 0x0600A218 RID: 41496 RVA: 0x0028FF4C File Offset: 0x0028E14C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MergedMesh>.NativeClassPtr));
			}
		}

		// Token: 0x17003A20 RID: 14880
		// (get) Token: 0x0600A219 RID: 41497 RVA: 0x0028FF60 File Offset: 0x0028E160
		// (set) Token: 0x0600A21A RID: 41498 RVA: 0x0028FF94 File Offset: 0x0028E194
		public unsafe Il2CppStructArray<int> MeshFilterIDs
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MergedMesh.NativeFieldInfoPtr_MeshFilterIDs);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MergedMesh.NativeFieldInfoPtr_MeshFilterIDs), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040066EF RID: 26351
		private static readonly IntPtr NativeFieldInfoPtr_MeshFilterIDs;

		// Token: 0x040066F0 RID: 26352
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
