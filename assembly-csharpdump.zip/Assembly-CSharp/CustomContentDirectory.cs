﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.IO;
using Il2CppSystem.Runtime.CompilerServices;
using Il2CppSystem.Threading.Tasks;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003F2 RID: 1010
public class CustomContentDirectory : MonoBehaviour
{
	// Token: 0x17001C43 RID: 7235
	// (get) Token: 0x06004F05 RID: 20229 RVA: 0x0013C958 File Offset: 0x0013AB58
	// (set) Token: 0x06004F06 RID: 20230 RVA: 0x0013C9A8 File Offset: 0x0013ABA8
	public unsafe bool MoveInProgress
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_get_MoveInProgress_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_set_MoveInProgress_Protected_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x17001C44 RID: 7236
	// (get) Token: 0x06004F07 RID: 20231 RVA: 0x0013C9FC File Offset: 0x0013ABFC
	public unsafe static string Location
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_get_Location_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
	}

	// Token: 0x06004F08 RID: 20232 RVA: 0x0013CA38 File Offset: 0x0013AC38
	[CallerCount(0)]
	public unsafe static bool IsDirectoryValidForCustomContent(string directory)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(directory);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_IsDirectoryValidForCustomContent_Protected_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06004F09 RID: 20233 RVA: 0x0013CA90 File Offset: 0x0013AC90
	[CallerCount(0)]
	public unsafe static bool IsDirectoryWritable(string directory)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(directory);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_IsDirectoryWritable_Protected_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06004F0A RID: 20234 RVA: 0x0013CAE8 File Offset: 0x0013ACE8
	[CallerCount(0)]
	public unsafe void MoveCustomContent(string newLocation)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(newLocation);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_MoveCustomContent_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F0B RID: 20235 RVA: 0x0013CB44 File Offset: 0x0013AD44
	[CallerCount(0)]
	public unsafe void MoveDirectory(string sourceDirectory, string destinationDirectory)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(sourceDirectory);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(destinationDirectory);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_MoveDirectory_Protected_Void_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F0C RID: 20236 RVA: 0x0013CBB8 File Offset: 0x0013ADB8
	[CallerCount(0)]
	public unsafe Task<bool> CopyFileAsync(string oldFile, string newDirectory)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(oldFile);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(newDirectory);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_CopyFileAsync_Protected_Task_1_Boolean_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Task<bool>(intPtr2) : null;
	}

	// Token: 0x06004F0D RID: 20237 RVA: 0x0013CC40 File Offset: 0x0013AE40
	[CallerCount(0)]
	public unsafe Task<bool> DeleteFileAsync(string filePath)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(filePath);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr_DeleteFileAsync_Protected_Task_1_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Task<bool>(intPtr2) : null;
	}

	// Token: 0x06004F0E RID: 20238 RVA: 0x0013CCB0 File Offset: 0x0013AEB0
	[CallerCount(0)]
	public unsafe CustomContentDirectory() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F0F RID: 20239 RVA: 0x0013CCFC File Offset: 0x0013AEFC
	// Note: this type is marked as 'beforefieldinit'.
	static CustomContentDirectory()
	{
		Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomContentDirectory");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr);
		CustomContentDirectory.NativeFieldInfoPtr_OnLocationChangeFinished = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "OnLocationChangeFinished");
		CustomContentDirectory.NativeFieldInfoPtr_TestMoveDestination = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "TestMoveDestination");
		CustomContentDirectory.NativeFieldInfoPtr__MoveInProgress_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "<MoveInProgress>k__BackingField");
		CustomContentDirectory.NativeFieldInfoPtr_MovableExtensions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "MovableExtensions");
		CustomContentDirectory.NativeFieldInfoPtr_FilePaths = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "FilePaths");
		CustomContentDirectory.NativeFieldInfoPtr__location = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "_location");
		CustomContentDirectory.NativeMethodInfoPtr_get_MoveInProgress_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669521);
		CustomContentDirectory.NativeMethodInfoPtr_set_MoveInProgress_Protected_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669522);
		CustomContentDirectory.NativeMethodInfoPtr_get_Location_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669523);
		CustomContentDirectory.NativeMethodInfoPtr_IsDirectoryValidForCustomContent_Protected_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669524);
		CustomContentDirectory.NativeMethodInfoPtr_IsDirectoryWritable_Protected_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669525);
		CustomContentDirectory.NativeMethodInfoPtr_MoveCustomContent_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669526);
		CustomContentDirectory.NativeMethodInfoPtr_MoveDirectory_Protected_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669527);
		CustomContentDirectory.NativeMethodInfoPtr_CopyFileAsync_Protected_Task_1_Boolean_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669528);
		CustomContentDirectory.NativeMethodInfoPtr_DeleteFileAsync_Protected_Task_1_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669529);
		CustomContentDirectory.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, 100669530);
	}

	// Token: 0x06004F10 RID: 20240 RVA: 0x0000210C File Offset: 0x0000030C
	public CustomContentDirectory(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001C3C RID: 7228
	// (get) Token: 0x06004F11 RID: 20241 RVA: 0x0013CE6C File Offset: 0x0013B06C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr));
		}
	}

	// Token: 0x17001C3D RID: 7229
	// (get) Token: 0x06004F12 RID: 20242 RVA: 0x0013CE80 File Offset: 0x0013B080
	// (set) Token: 0x06004F13 RID: 20243 RVA: 0x0013CEAB File Offset: 0x0013B0AB
	public unsafe static Action OnLocationChangeFinished
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CustomContentDirectory.NativeFieldInfoPtr_OnLocationChangeFinished, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Action(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomContentDirectory.NativeFieldInfoPtr_OnLocationChangeFinished, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C3E RID: 7230
	// (get) Token: 0x06004F14 RID: 20244 RVA: 0x0013CEC0 File Offset: 0x0013B0C0
	// (set) Token: 0x06004F15 RID: 20245 RVA: 0x0013CEE9 File Offset: 0x0013B0E9
	public unsafe string TestMoveDestination
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_TestMoveDestination);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_TestMoveDestination), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001C3F RID: 7231
	// (get) Token: 0x06004F16 RID: 20246 RVA: 0x0013CF10 File Offset: 0x0013B110
	// (set) Token: 0x06004F17 RID: 20247 RVA: 0x0013CF38 File Offset: 0x0013B138
	public unsafe bool _MoveInProgress_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr__MoveInProgress_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr__MoveInProgress_k__BackingField)) = value;
		}
	}

	// Token: 0x17001C40 RID: 7232
	// (get) Token: 0x06004F18 RID: 20248 RVA: 0x0013CF5C File Offset: 0x0013B15C
	// (set) Token: 0x06004F19 RID: 20249 RVA: 0x0013CF90 File Offset: 0x0013B190
	public unsafe HashSet<string> MovableExtensions
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_MovableExtensions);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new HashSet<string>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_MovableExtensions), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C41 RID: 7233
	// (get) Token: 0x06004F1A RID: 20250 RVA: 0x0013CFB8 File Offset: 0x0013B1B8
	// (set) Token: 0x06004F1B RID: 20251 RVA: 0x0013CFEC File Offset: 0x0013B1EC
	public unsafe List<string> FilePaths
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_FilePaths);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<string>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory.NativeFieldInfoPtr_FilePaths), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C42 RID: 7234
	// (get) Token: 0x06004F1C RID: 20252 RVA: 0x0013D014 File Offset: 0x0013B214
	// (set) Token: 0x06004F1D RID: 20253 RVA: 0x0013D034 File Offset: 0x0013B234
	public unsafe static string _location
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(CustomContentDirectory.NativeFieldInfoPtr__location, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomContentDirectory.NativeFieldInfoPtr__location, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x0400322A RID: 12842
	private static readonly IntPtr NativeFieldInfoPtr_OnLocationChangeFinished;

	// Token: 0x0400322B RID: 12843
	private static readonly IntPtr NativeFieldInfoPtr_TestMoveDestination;

	// Token: 0x0400322C RID: 12844
	private static readonly IntPtr NativeFieldInfoPtr__MoveInProgress_k__BackingField;

	// Token: 0x0400322D RID: 12845
	private static readonly IntPtr NativeFieldInfoPtr_MovableExtensions;

	// Token: 0x0400322E RID: 12846
	private static readonly IntPtr NativeFieldInfoPtr_FilePaths;

	// Token: 0x0400322F RID: 12847
	private static readonly IntPtr NativeFieldInfoPtr__location;

	// Token: 0x04003230 RID: 12848
	private static readonly IntPtr NativeMethodInfoPtr_get_MoveInProgress_Public_get_Boolean_0;

	// Token: 0x04003231 RID: 12849
	private static readonly IntPtr NativeMethodInfoPtr_set_MoveInProgress_Protected_set_Void_Boolean_0;

	// Token: 0x04003232 RID: 12850
	private static readonly IntPtr NativeMethodInfoPtr_get_Location_Public_Static_get_String_0;

	// Token: 0x04003233 RID: 12851
	private static readonly IntPtr NativeMethodInfoPtr_IsDirectoryValidForCustomContent_Protected_Static_Boolean_String_0;

	// Token: 0x04003234 RID: 12852
	private static readonly IntPtr NativeMethodInfoPtr_IsDirectoryWritable_Protected_Static_Boolean_String_0;

	// Token: 0x04003235 RID: 12853
	private static readonly IntPtr NativeMethodInfoPtr_MoveCustomContent_Public_Void_String_0;

	// Token: 0x04003236 RID: 12854
	private static readonly IntPtr NativeMethodInfoPtr_MoveDirectory_Protected_Void_String_String_0;

	// Token: 0x04003237 RID: 12855
	private static readonly IntPtr NativeMethodInfoPtr_CopyFileAsync_Protected_Task_1_Boolean_String_String_0;

	// Token: 0x04003238 RID: 12856
	private static readonly IntPtr NativeMethodInfoPtr_DeleteFileAsync_Protected_Task_1_Boolean_String_0;

	// Token: 0x04003239 RID: 12857
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003F3 RID: 1011
	[ObfuscatedName("CustomContentDirectory/<MoveDirectory>d__14")]
	public sealed class _MoveDirectory_d__14 : ValueType
	{
		// Token: 0x06004F1E RID: 20254 RVA: 0x0013D04C File Offset: 0x0013B24C
		[CallerCount(0)]
		public unsafe void MoveNext()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._MoveDirectory_d__14.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F1F RID: 20255 RVA: 0x0013D08C File Offset: 0x0013B28C
		[CallerCount(0)]
		public unsafe void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(stateMachine);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._MoveDirectory_d__14.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F20 RID: 20256 RVA: 0x0013D0E4 File Offset: 0x0013B2E4
		// Note: this type is marked as 'beforefieldinit'.
		static _MoveDirectory_d__14()
		{
			Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "<MoveDirectory>d__14");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr);
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<>1__state");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___t__builder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<>t__builder");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<>4__this");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_sourceDirectory = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "sourceDirectory");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_destinationDirectory = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "destinationDirectory");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__iC_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<iC>5__2");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__i_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<i>5__3");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__filePath_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<filePath>5__4");
			CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___u__1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, "<>u__1");
			CustomContentDirectory._MoveDirectory_d__14.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, 100669531);
			CustomContentDirectory._MoveDirectory_d__14.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, 100669532);
		}

		// Token: 0x06004F21 RID: 20257 RVA: 0x0002717B File Offset: 0x0002537B
		public _MoveDirectory_d__14(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C45 RID: 7237
		// (get) Token: 0x06004F22 RID: 20258 RVA: 0x0013D1EB File Offset: 0x0013B3EB
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr));
			}
		}

		// Token: 0x06004F23 RID: 20259 RVA: 0x0013D1FC File Offset: 0x0013B3FC
		public unsafe _MoveDirectory_d__14()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CustomContentDirectory._MoveDirectory_d__14>.NativeClassPtr, data));
		}

		// Token: 0x17001C46 RID: 7238
		// (get) Token: 0x06004F24 RID: 20260 RVA: 0x0013D22C File Offset: 0x0013B42C
		// (set) Token: 0x06004F25 RID: 20261 RVA: 0x0013D254 File Offset: 0x0013B454
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C47 RID: 7239
		// (get) Token: 0x06004F26 RID: 20262 RVA: 0x0013D278 File Offset: 0x0013B478
		// (set) Token: 0x06004F27 RID: 20263 RVA: 0x0013D2AA File Offset: 0x0013B4AA
		public AsyncVoidMethodBuilder __t__builder
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___t__builder);
				return new AsyncVoidMethodBuilder(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncVoidMethodBuilder>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___t__builder), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncVoidMethodBuilder>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17001C48 RID: 7240
		// (get) Token: 0x06004F28 RID: 20264 RVA: 0x0013D2E0 File Offset: 0x0013B4E0
		// (set) Token: 0x06004F29 RID: 20265 RVA: 0x0013D314 File Offset: 0x0013B514
		public unsafe CustomContentDirectory __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CustomContentDirectory(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C49 RID: 7241
		// (get) Token: 0x06004F2A RID: 20266 RVA: 0x0013D33C File Offset: 0x0013B53C
		// (set) Token: 0x06004F2B RID: 20267 RVA: 0x0013D365 File Offset: 0x0013B565
		public unsafe string sourceDirectory
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_sourceDirectory);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_sourceDirectory), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C4A RID: 7242
		// (get) Token: 0x06004F2C RID: 20268 RVA: 0x0013D38C File Offset: 0x0013B58C
		// (set) Token: 0x06004F2D RID: 20269 RVA: 0x0013D3B5 File Offset: 0x0013B5B5
		public unsafe string destinationDirectory
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_destinationDirectory);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr_destinationDirectory), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C4B RID: 7243
		// (get) Token: 0x06004F2E RID: 20270 RVA: 0x0013D3DC File Offset: 0x0013B5DC
		// (set) Token: 0x06004F2F RID: 20271 RVA: 0x0013D404 File Offset: 0x0013B604
		public unsafe int _iC_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__iC_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__iC_5__2)) = value;
			}
		}

		// Token: 0x17001C4C RID: 7244
		// (get) Token: 0x06004F30 RID: 20272 RVA: 0x0013D428 File Offset: 0x0013B628
		// (set) Token: 0x06004F31 RID: 20273 RVA: 0x0013D450 File Offset: 0x0013B650
		public unsafe int _i_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__i_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__i_5__3)) = value;
			}
		}

		// Token: 0x17001C4D RID: 7245
		// (get) Token: 0x06004F32 RID: 20274 RVA: 0x0013D474 File Offset: 0x0013B674
		// (set) Token: 0x06004F33 RID: 20275 RVA: 0x0013D49D File Offset: 0x0013B69D
		public unsafe string _filePath_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__filePath_5__4);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr__filePath_5__4), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C4E RID: 7246
		// (get) Token: 0x06004F34 RID: 20276 RVA: 0x0013D4C4 File Offset: 0x0013B6C4
		// (set) Token: 0x06004F35 RID: 20277 RVA: 0x0013D4F6 File Offset: 0x0013B6F6
		public TaskAwaiter<bool> __u__1
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___u__1);
				return new TaskAwaiter<bool>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<TaskAwaiter<bool>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._MoveDirectory_d__14.NativeFieldInfoPtr___u__1), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<TaskAwaiter<bool>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x0400323A RID: 12858
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x0400323B RID: 12859
		private static readonly IntPtr NativeFieldInfoPtr___t__builder;

		// Token: 0x0400323C RID: 12860
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x0400323D RID: 12861
		private static readonly IntPtr NativeFieldInfoPtr_sourceDirectory;

		// Token: 0x0400323E RID: 12862
		private static readonly IntPtr NativeFieldInfoPtr_destinationDirectory;

		// Token: 0x0400323F RID: 12863
		private static readonly IntPtr NativeFieldInfoPtr__iC_5__2;

		// Token: 0x04003240 RID: 12864
		private static readonly IntPtr NativeFieldInfoPtr__i_5__3;

		// Token: 0x04003241 RID: 12865
		private static readonly IntPtr NativeFieldInfoPtr__filePath_5__4;

		// Token: 0x04003242 RID: 12866
		private static readonly IntPtr NativeFieldInfoPtr___u__1;

		// Token: 0x04003243 RID: 12867
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003244 RID: 12868
		private static readonly IntPtr NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0;
	}

	// Token: 0x020003F4 RID: 1012
	[ObfuscatedName("CustomContentDirectory/<CopyFileAsync>d__15")]
	public sealed class _CopyFileAsync_d__15 : ValueType
	{
		// Token: 0x06004F36 RID: 20278 RVA: 0x0013D52C File Offset: 0x0013B72C
		[CallerCount(0)]
		public unsafe void MoveNext()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._CopyFileAsync_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F37 RID: 20279 RVA: 0x0013D56C File Offset: 0x0013B76C
		[CallerCount(0)]
		public unsafe void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(stateMachine);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._CopyFileAsync_d__15.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F38 RID: 20280 RVA: 0x0013D5C4 File Offset: 0x0013B7C4
		// Note: this type is marked as 'beforefieldinit'.
		static _CopyFileAsync_d__15()
		{
			Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "<CopyFileAsync>d__15");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr);
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "<>1__state");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___t__builder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "<>t__builder");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_oldFile = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "oldFile");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_newDirectory = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "newDirectory");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__SourceStream_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "<SourceStream>5__2");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__DestinationStream_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "<DestinationStream>5__3");
			CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___u__1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, "<>u__1");
			CustomContentDirectory._CopyFileAsync_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, 100669533);
			CustomContentDirectory._CopyFileAsync_d__15.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, 100669534);
		}

		// Token: 0x06004F39 RID: 20281 RVA: 0x0002717B File Offset: 0x0002537B
		public _CopyFileAsync_d__15(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C4F RID: 7247
		// (get) Token: 0x06004F3A RID: 20282 RVA: 0x0013D6A3 File Offset: 0x0013B8A3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr));
			}
		}

		// Token: 0x06004F3B RID: 20283 RVA: 0x0013D6B4 File Offset: 0x0013B8B4
		public unsafe _CopyFileAsync_d__15()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CustomContentDirectory._CopyFileAsync_d__15>.NativeClassPtr, data));
		}

		// Token: 0x17001C50 RID: 7248
		// (get) Token: 0x06004F3C RID: 20284 RVA: 0x0013D6E4 File Offset: 0x0013B8E4
		// (set) Token: 0x06004F3D RID: 20285 RVA: 0x0013D70C File Offset: 0x0013B90C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C51 RID: 7249
		// (get) Token: 0x06004F3E RID: 20286 RVA: 0x0013D730 File Offset: 0x0013B930
		// (set) Token: 0x06004F3F RID: 20287 RVA: 0x0013D762 File Offset: 0x0013B962
		public AsyncTaskMethodBuilder<bool> __t__builder
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___t__builder);
				return new AsyncTaskMethodBuilder<bool>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncTaskMethodBuilder<bool>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___t__builder), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncTaskMethodBuilder<bool>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17001C52 RID: 7250
		// (get) Token: 0x06004F40 RID: 20288 RVA: 0x0013D798 File Offset: 0x0013B998
		// (set) Token: 0x06004F41 RID: 20289 RVA: 0x0013D7C1 File Offset: 0x0013B9C1
		public unsafe string oldFile
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_oldFile);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_oldFile), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C53 RID: 7251
		// (get) Token: 0x06004F42 RID: 20290 RVA: 0x0013D7E8 File Offset: 0x0013B9E8
		// (set) Token: 0x06004F43 RID: 20291 RVA: 0x0013D811 File Offset: 0x0013BA11
		public unsafe string newDirectory
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_newDirectory);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr_newDirectory), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C54 RID: 7252
		// (get) Token: 0x06004F44 RID: 20292 RVA: 0x0013D838 File Offset: 0x0013BA38
		// (set) Token: 0x06004F45 RID: 20293 RVA: 0x0013D86C File Offset: 0x0013BA6C
		public unsafe FileStream _SourceStream_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__SourceStream_5__2);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new FileStream(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__SourceStream_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C55 RID: 7253
		// (get) Token: 0x06004F46 RID: 20294 RVA: 0x0013D894 File Offset: 0x0013BA94
		// (set) Token: 0x06004F47 RID: 20295 RVA: 0x0013D8C8 File Offset: 0x0013BAC8
		public unsafe FileStream _DestinationStream_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__DestinationStream_5__3);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new FileStream(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr__DestinationStream_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C56 RID: 7254
		// (get) Token: 0x06004F48 RID: 20296 RVA: 0x0013D8F0 File Offset: 0x0013BAF0
		// (set) Token: 0x06004F49 RID: 20297 RVA: 0x0013D922 File Offset: 0x0013BB22
		public TaskAwaiter __u__1
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___u__1);
				return new TaskAwaiter(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<TaskAwaiter>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._CopyFileAsync_d__15.NativeFieldInfoPtr___u__1), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<TaskAwaiter>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x04003245 RID: 12869
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04003246 RID: 12870
		private static readonly IntPtr NativeFieldInfoPtr___t__builder;

		// Token: 0x04003247 RID: 12871
		private static readonly IntPtr NativeFieldInfoPtr_oldFile;

		// Token: 0x04003248 RID: 12872
		private static readonly IntPtr NativeFieldInfoPtr_newDirectory;

		// Token: 0x04003249 RID: 12873
		private static readonly IntPtr NativeFieldInfoPtr__SourceStream_5__2;

		// Token: 0x0400324A RID: 12874
		private static readonly IntPtr NativeFieldInfoPtr__DestinationStream_5__3;

		// Token: 0x0400324B RID: 12875
		private static readonly IntPtr NativeFieldInfoPtr___u__1;

		// Token: 0x0400324C RID: 12876
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400324D RID: 12877
		private static readonly IntPtr NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0;
	}

	// Token: 0x020003F5 RID: 1013
	[ObfuscatedName("CustomContentDirectory/<DeleteFileAsync>d__16")]
	public sealed class _DeleteFileAsync_d__16 : ValueType
	{
		// Token: 0x06004F4A RID: 20298 RVA: 0x0013D958 File Offset: 0x0013BB58
		[CallerCount(0)]
		public unsafe void MoveNext()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._DeleteFileAsync_d__16.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F4B RID: 20299 RVA: 0x0013D998 File Offset: 0x0013BB98
		[CallerCount(0)]
		public unsafe void SetStateMachine(IAsyncStateMachine stateMachine)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(stateMachine);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentDirectory._DeleteFileAsync_d__16.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004F4C RID: 20300 RVA: 0x0013D9F0 File Offset: 0x0013BBF0
		// Note: this type is marked as 'beforefieldinit'.
		static _DeleteFileAsync_d__16()
		{
			Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CustomContentDirectory>.NativeClassPtr, "<DeleteFileAsync>d__16");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr);
			CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, "<>1__state");
			CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___t__builder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, "<>t__builder");
			CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr_filePath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, "filePath");
			CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr__stream_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, "<stream>5__2");
			CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___u__1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, "<>u__1");
			CustomContentDirectory._DeleteFileAsync_d__16.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, 100669535);
			CustomContentDirectory._DeleteFileAsync_d__16.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, 100669536);
		}

		// Token: 0x06004F4D RID: 20301 RVA: 0x0002717B File Offset: 0x0002537B
		public _DeleteFileAsync_d__16(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C57 RID: 7255
		// (get) Token: 0x06004F4E RID: 20302 RVA: 0x0013DAA7 File Offset: 0x0013BCA7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr));
			}
		}

		// Token: 0x06004F4F RID: 20303 RVA: 0x0013DAB8 File Offset: 0x0013BCB8
		public unsafe _DeleteFileAsync_d__16()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CustomContentDirectory._DeleteFileAsync_d__16>.NativeClassPtr, data));
		}

		// Token: 0x17001C58 RID: 7256
		// (get) Token: 0x06004F50 RID: 20304 RVA: 0x0013DAE8 File Offset: 0x0013BCE8
		// (set) Token: 0x06004F51 RID: 20305 RVA: 0x0013DB10 File Offset: 0x0013BD10
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C59 RID: 7257
		// (get) Token: 0x06004F52 RID: 20306 RVA: 0x0013DB34 File Offset: 0x0013BD34
		// (set) Token: 0x06004F53 RID: 20307 RVA: 0x0013DB66 File Offset: 0x0013BD66
		public AsyncTaskMethodBuilder<bool> __t__builder
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___t__builder);
				return new AsyncTaskMethodBuilder<bool>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncTaskMethodBuilder<bool>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___t__builder), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncTaskMethodBuilder<bool>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17001C5A RID: 7258
		// (get) Token: 0x06004F54 RID: 20308 RVA: 0x0013DB9C File Offset: 0x0013BD9C
		// (set) Token: 0x06004F55 RID: 20309 RVA: 0x0013DBC5 File Offset: 0x0013BDC5
		public unsafe string filePath
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr_filePath);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr_filePath), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17001C5B RID: 7259
		// (get) Token: 0x06004F56 RID: 20310 RVA: 0x0013DBEC File Offset: 0x0013BDEC
		// (set) Token: 0x06004F57 RID: 20311 RVA: 0x0013DC20 File Offset: 0x0013BE20
		public unsafe FileStream _stream_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr__stream_5__2);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new FileStream(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr__stream_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C5C RID: 7260
		// (get) Token: 0x06004F58 RID: 20312 RVA: 0x0013DC48 File Offset: 0x0013BE48
		// (set) Token: 0x06004F59 RID: 20313 RVA: 0x0013DC7A File Offset: 0x0013BE7A
		public TaskAwaiter __u__1
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___u__1);
				return new TaskAwaiter(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<TaskAwaiter>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentDirectory._DeleteFileAsync_d__16.NativeFieldInfoPtr___u__1), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<TaskAwaiter>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x0400324E RID: 12878
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x0400324F RID: 12879
		private static readonly IntPtr NativeFieldInfoPtr___t__builder;

		// Token: 0x04003250 RID: 12880
		private static readonly IntPtr NativeFieldInfoPtr_filePath;

		// Token: 0x04003251 RID: 12881
		private static readonly IntPtr NativeFieldInfoPtr__stream_5__2;

		// Token: 0x04003252 RID: 12882
		private static readonly IntPtr NativeFieldInfoPtr___u__1;

		// Token: 0x04003253 RID: 12883
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003254 RID: 12884
		private static readonly IntPtr NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0;
	}
}
