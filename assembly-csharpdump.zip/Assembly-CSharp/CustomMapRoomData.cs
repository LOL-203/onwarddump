﻿using System;
using System.Runtime.InteropServices;
using DPI.Networking;
using Il2CppSystem;
using Onward.CustomMaps;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x02000185 RID: 389
[StructLayout(0)]
public sealed class CustomMapRoomData : ValueType
{
	// Token: 0x17000905 RID: 2309
	// (get) Token: 0x060019F9 RID: 6649 RVA: 0x00067810 File Offset: 0x00065A10
	public unsafe static CustomMapRoomData Default
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_get_Default_Public_Static_get_CustomMapRoomData_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new CustomMapRoomData(intPtr);
		}
	}

	// Token: 0x060019FA RID: 6650 RVA: 0x0006784C File Offset: 0x00065A4C
	[CallerCount(0)]
	public unsafe static bool TryGetRoomData(out CustomMapRoomData data)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtrNotNull(data);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_byref_CustomMapRoomData_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060019FB RID: 6651 RVA: 0x000678A8 File Offset: 0x00065AA8
	[CallerCount(0)]
	public unsafe static bool TryGetRoomData(RoomInfo info, out CustomMapRoomData data)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(info);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(data);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_RoomInfo_byref_CustomMapRoomData_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060019FC RID: 6652 RVA: 0x0006791C File Offset: 0x00065B1C
	[CallerCount(0)]
	public unsafe static bool TryGetRoomData(string property, out CustomMapRoomData data)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(property);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(data);
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Private_Static_Boolean_String_byref_CustomMapRoomData_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060019FD RID: 6653 RVA: 0x00067990 File Offset: 0x00065B90
	[CallerCount(0)]
	public unsafe CustomMapRoomData(string mapID, string hash, string displayName, string liveVersionId)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(mapID);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(hash);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(displayName);
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(liveVersionId);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr__ctor_Public_Void_String_String_String_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019FE RID: 6654 RVA: 0x00067A30 File Offset: 0x00065C30
	[CallerCount(0)]
	public unsafe static CustomMapRoomData GetFromWorkshopData(WorkshopItem workshopItem)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(workshopItem);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_GetFromWorkshopData_Public_Static_CustomMapRoomData_WorkshopItem_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return new CustomMapRoomData(intPtr);
	}

	// Token: 0x060019FF RID: 6655 RVA: 0x00067A84 File Offset: 0x00065C84
	[CallerCount(0)]
	public new unsafe string ToString()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(CustomMapRoomData.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x06001A00 RID: 6656 RVA: 0x00067AD0 File Offset: 0x00065CD0
	// Note: this type is marked as 'beforefieldinit'.
	static CustomMapRoomData()
	{
		Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomMapRoomData");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr);
		CustomMapRoomData.NativeFieldInfoPtr_MapID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, "MapID");
		CustomMapRoomData.NativeFieldInfoPtr_Hash = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, "Hash");
		CustomMapRoomData.NativeFieldInfoPtr_DisplayName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, "DisplayName");
		CustomMapRoomData.NativeFieldInfoPtr_LiveVersionId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, "LiveVersionId");
		CustomMapRoomData.NativeMethodInfoPtr_get_Default_Public_Static_get_CustomMapRoomData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665365);
		CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_byref_CustomMapRoomData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665366);
		CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_RoomInfo_byref_CustomMapRoomData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665367);
		CustomMapRoomData.NativeMethodInfoPtr_TryGetRoomData_Private_Static_Boolean_String_byref_CustomMapRoomData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665368);
		CustomMapRoomData.NativeMethodInfoPtr__ctor_Public_Void_String_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665369);
		CustomMapRoomData.NativeMethodInfoPtr_GetFromWorkshopData_Public_Static_CustomMapRoomData_WorkshopItem_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665370);
		CustomMapRoomData.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, 100665371);
	}

	// Token: 0x06001A01 RID: 6657 RVA: 0x0002717B File Offset: 0x0002537B
	public CustomMapRoomData(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000900 RID: 2304
	// (get) Token: 0x06001A02 RID: 6658 RVA: 0x00067BDC File Offset: 0x00065DDC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr));
		}
	}

	// Token: 0x06001A03 RID: 6659 RVA: 0x00067BF0 File Offset: 0x00065DF0
	public unsafe CustomMapRoomData()
	{
		IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, (UIntPtr)0)];
		base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CustomMapRoomData>.NativeClassPtr, data));
	}

	// Token: 0x17000901 RID: 2305
	// (get) Token: 0x06001A04 RID: 6660 RVA: 0x00067C20 File Offset: 0x00065E20
	// (set) Token: 0x06001A05 RID: 6661 RVA: 0x00067C49 File Offset: 0x00065E49
	public unsafe string MapID
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_MapID);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_MapID), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000902 RID: 2306
	// (get) Token: 0x06001A06 RID: 6662 RVA: 0x00067C70 File Offset: 0x00065E70
	// (set) Token: 0x06001A07 RID: 6663 RVA: 0x00067C99 File Offset: 0x00065E99
	public unsafe string Hash
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_Hash);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_Hash), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000903 RID: 2307
	// (get) Token: 0x06001A08 RID: 6664 RVA: 0x00067CC0 File Offset: 0x00065EC0
	// (set) Token: 0x06001A09 RID: 6665 RVA: 0x00067CE9 File Offset: 0x00065EE9
	public unsafe string DisplayName
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_DisplayName);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_DisplayName), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000904 RID: 2308
	// (get) Token: 0x06001A0A RID: 6666 RVA: 0x00067D10 File Offset: 0x00065F10
	// (set) Token: 0x06001A0B RID: 6667 RVA: 0x00067D39 File Offset: 0x00065F39
	public unsafe string LiveVersionId
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_LiveVersionId);
			return IL2CPP.Il2CppStringToManaged(*intPtr);
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapRoomData.NativeFieldInfoPtr_LiveVersionId), IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x040010A4 RID: 4260
	private static readonly IntPtr NativeFieldInfoPtr_MapID;

	// Token: 0x040010A5 RID: 4261
	private static readonly IntPtr NativeFieldInfoPtr_Hash;

	// Token: 0x040010A6 RID: 4262
	private static readonly IntPtr NativeFieldInfoPtr_DisplayName;

	// Token: 0x040010A7 RID: 4263
	private static readonly IntPtr NativeFieldInfoPtr_LiveVersionId;

	// Token: 0x040010A8 RID: 4264
	private static readonly IntPtr NativeMethodInfoPtr_get_Default_Public_Static_get_CustomMapRoomData_0;

	// Token: 0x040010A9 RID: 4265
	private static readonly IntPtr NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_byref_CustomMapRoomData_0;

	// Token: 0x040010AA RID: 4266
	private static readonly IntPtr NativeMethodInfoPtr_TryGetRoomData_Public_Static_Boolean_RoomInfo_byref_CustomMapRoomData_0;

	// Token: 0x040010AB RID: 4267
	private static readonly IntPtr NativeMethodInfoPtr_TryGetRoomData_Private_Static_Boolean_String_byref_CustomMapRoomData_0;

	// Token: 0x040010AC RID: 4268
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_String_String_String_0;

	// Token: 0x040010AD RID: 4269
	private static readonly IntPtr NativeMethodInfoPtr_GetFromWorkshopData_Public_Static_CustomMapRoomData_WorkshopItem_0;

	// Token: 0x040010AE RID: 4270
	private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;
}
