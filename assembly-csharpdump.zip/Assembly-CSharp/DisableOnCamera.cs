﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000343 RID: 835
public class DisableOnCamera : MonoBehaviour
{
	// Token: 0x06004207 RID: 16903 RVA: 0x0010A6CC File Offset: 0x001088CC
	[CallerCount(0)]
	public unsafe DisableOnCamera() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableOnCamera.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004208 RID: 16904 RVA: 0x0010A718 File Offset: 0x00108918
	// Note: this type is marked as 'beforefieldinit'.
	static DisableOnCamera()
	{
		Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DisableOnCamera");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr);
		DisableOnCamera.NativeFieldInfoPtr_ObjectsToDisable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr, "ObjectsToDisable");
		DisableOnCamera.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr, 100668575);
	}

	// Token: 0x06004209 RID: 16905 RVA: 0x0000210C File Offset: 0x0000030C
	public DisableOnCamera(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001767 RID: 5991
	// (get) Token: 0x0600420A RID: 16906 RVA: 0x0010A770 File Offset: 0x00108970
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DisableOnCamera>.NativeClassPtr));
		}
	}

	// Token: 0x17001768 RID: 5992
	// (get) Token: 0x0600420B RID: 16907 RVA: 0x0010A784 File Offset: 0x00108984
	// (set) Token: 0x0600420C RID: 16908 RVA: 0x0010A7B8 File Offset: 0x001089B8
	public unsafe List<GameObject> ObjectsToDisable
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnCamera.NativeFieldInfoPtr_ObjectsToDisable);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableOnCamera.NativeFieldInfoPtr_ObjectsToDisable), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002A64 RID: 10852
	private static readonly IntPtr NativeFieldInfoPtr_ObjectsToDisable;

	// Token: 0x04002A65 RID: 10853
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
