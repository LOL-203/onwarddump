﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000923 RID: 2339
	public class SWITCHES : Object
	{
		// Token: 0x0600C569 RID: 50537 RVA: 0x00317D60 File Offset: 0x00315F60
		[CallerCount(0)]
		public unsafe SWITCHES() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C56A RID: 50538 RVA: 0x00317DAB File Offset: 0x00315FAB
		// Note: this type is marked as 'beforefieldinit'.
		static SWITCHES()
		{
			Il2CppClassPointerStore<SWITCHES>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "SWITCHES");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr);
			SWITCHES.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, 100678723);
		}

		// Token: 0x0600C56B RID: 50539 RVA: 0x00002988 File Offset: 0x00000B88
		public SWITCHES(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004788 RID: 18312
		// (get) Token: 0x0600C56C RID: 50540 RVA: 0x00317DE4 File Offset: 0x00315FE4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr));
			}
		}

		// Token: 0x04007D4A RID: 32074
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000924 RID: 2340
		public class CHARACTER_ROLE_SWITCH : Object
		{
			// Token: 0x0600C56D RID: 50541 RVA: 0x00317DF8 File Offset: 0x00315FF8
			[CallerCount(0)]
			public unsafe CHARACTER_ROLE_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.CHARACTER_ROLE_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C56E RID: 50542 RVA: 0x00317E44 File Offset: 0x00316044
			// Note: this type is marked as 'beforefieldinit'.
			static CHARACTER_ROLE_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "CHARACTER_ROLE_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr);
				SWITCHES.CHARACTER_ROLE_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.CHARACTER_ROLE_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr, 100678724);
			}

			// Token: 0x0600C56F RID: 50543 RVA: 0x00002988 File Offset: 0x00000B88
			public CHARACTER_ROLE_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004789 RID: 18313
			// (get) Token: 0x0600C570 RID: 50544 RVA: 0x00317E97 File Offset: 0x00316097
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x1700478A RID: 18314
			// (get) Token: 0x0600C571 RID: 50545 RVA: 0x00317EA8 File Offset: 0x003160A8
			// (set) Token: 0x0600C572 RID: 50546 RVA: 0x00317EC6 File Offset: 0x003160C6
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.CHARACTER_ROLE_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.CHARACTER_ROLE_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D4B RID: 32075
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D4C RID: 32076
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000925 RID: 2341
			public class SWITCH : Object
			{
				// Token: 0x0600C573 RID: 50547 RVA: 0x00317ED8 File Offset: 0x003160D8
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C574 RID: 50548 RVA: 0x00317F24 File Offset: 0x00316124
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_AIPLAYER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr, "AIPLAYER");
					SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_LOCALPLAYER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr, "LOCALPLAYER");
					SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_REMOTEPLAYER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr, "REMOTEPLAYER");
					SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr, 100678726);
				}

				// Token: 0x0600C575 RID: 50549 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x1700478B RID: 18315
				// (get) Token: 0x0600C576 RID: 50550 RVA: 0x00317F9F File Offset: 0x0031619F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x1700478C RID: 18316
				// (get) Token: 0x0600C577 RID: 50551 RVA: 0x00317FB0 File Offset: 0x003161B0
				// (set) Token: 0x0600C578 RID: 50552 RVA: 0x00317FCE File Offset: 0x003161CE
				public unsafe static uint AIPLAYER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_AIPLAYER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_AIPLAYER, (void*)(&value));
					}
				}

				// Token: 0x1700478D RID: 18317
				// (get) Token: 0x0600C579 RID: 50553 RVA: 0x00317FE0 File Offset: 0x003161E0
				// (set) Token: 0x0600C57A RID: 50554 RVA: 0x00317FFE File Offset: 0x003161FE
				public unsafe static uint LOCALPLAYER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_LOCALPLAYER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_LOCALPLAYER, (void*)(&value));
					}
				}

				// Token: 0x1700478E RID: 18318
				// (get) Token: 0x0600C57B RID: 50555 RVA: 0x00318010 File Offset: 0x00316210
				// (set) Token: 0x0600C57C RID: 50556 RVA: 0x0031802E File Offset: 0x0031622E
				public unsafe static uint REMOTEPLAYER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_REMOTEPLAYER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.CHARACTER_ROLE_SWITCH.SWITCH.NativeFieldInfoPtr_REMOTEPLAYER, (void*)(&value));
					}
				}

				// Token: 0x04007D4D RID: 32077
				private static readonly IntPtr NativeFieldInfoPtr_AIPLAYER;

				// Token: 0x04007D4E RID: 32078
				private static readonly IntPtr NativeFieldInfoPtr_LOCALPLAYER;

				// Token: 0x04007D4F RID: 32079
				private static readonly IntPtr NativeFieldInfoPtr_REMOTEPLAYER;

				// Token: 0x04007D50 RID: 32080
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000926 RID: 2342
		public class DAMAGELIBRARY_MATERIAL_SWITCH : Object
		{
			// Token: 0x0600C57D RID: 50557 RVA: 0x00318040 File Offset: 0x00316240
			[CallerCount(0)]
			public unsafe DAMAGELIBRARY_MATERIAL_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C57E RID: 50558 RVA: 0x0031808C File Offset: 0x0031628C
			// Note: this type is marked as 'beforefieldinit'.
			static DAMAGELIBRARY_MATERIAL_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "DAMAGELIBRARY_MATERIAL_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr);
				SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr, 100678728);
			}

			// Token: 0x0600C57F RID: 50559 RVA: 0x00002988 File Offset: 0x00000B88
			public DAMAGELIBRARY_MATERIAL_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700478F RID: 18319
			// (get) Token: 0x0600C580 RID: 50560 RVA: 0x003180DF File Offset: 0x003162DF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x17004790 RID: 18320
			// (get) Token: 0x0600C581 RID: 50561 RVA: 0x003180F0 File Offset: 0x003162F0
			// (set) Token: 0x0600C582 RID: 50562 RVA: 0x0031810E File Offset: 0x0031630E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D51 RID: 32081
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D52 RID: 32082
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000927 RID: 2343
			public class SWITCH : Object
			{
				// Token: 0x0600C583 RID: 50563 RVA: 0x00318120 File Offset: 0x00316320
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C584 RID: 50564 RVA: 0x0031816C File Offset: 0x0031636C
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_BODY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "BODY");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CLOTH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "CLOTH");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CONCRETE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "CONCRETE");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_DIRT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "DIRT");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GLASS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "GLASS");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GRASS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "GRASS");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_ICE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "ICE");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_METAL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "METAL");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_NULL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "NULL");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_SNOW = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "SNOW");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_TASER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "TASER");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WATER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "WATER");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "WOOD");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD_OLD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, "WOOD_OLD");
					SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr, 100678730);
				}

				// Token: 0x0600C585 RID: 50565 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004791 RID: 18321
				// (get) Token: 0x0600C586 RID: 50566 RVA: 0x003182C3 File Offset: 0x003164C3
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x17004792 RID: 18322
				// (get) Token: 0x0600C587 RID: 50567 RVA: 0x003182D4 File Offset: 0x003164D4
				// (set) Token: 0x0600C588 RID: 50568 RVA: 0x003182F2 File Offset: 0x003164F2
				public unsafe static uint BODY
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_BODY, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_BODY, (void*)(&value));
					}
				}

				// Token: 0x17004793 RID: 18323
				// (get) Token: 0x0600C589 RID: 50569 RVA: 0x00318304 File Offset: 0x00316504
				// (set) Token: 0x0600C58A RID: 50570 RVA: 0x00318322 File Offset: 0x00316522
				public unsafe static uint CLOTH
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CLOTH, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CLOTH, (void*)(&value));
					}
				}

				// Token: 0x17004794 RID: 18324
				// (get) Token: 0x0600C58B RID: 50571 RVA: 0x00318334 File Offset: 0x00316534
				// (set) Token: 0x0600C58C RID: 50572 RVA: 0x00318352 File Offset: 0x00316552
				public unsafe static uint CONCRETE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CONCRETE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_CONCRETE, (void*)(&value));
					}
				}

				// Token: 0x17004795 RID: 18325
				// (get) Token: 0x0600C58D RID: 50573 RVA: 0x00318364 File Offset: 0x00316564
				// (set) Token: 0x0600C58E RID: 50574 RVA: 0x00318382 File Offset: 0x00316582
				public unsafe static uint DIRT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_DIRT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_DIRT, (void*)(&value));
					}
				}

				// Token: 0x17004796 RID: 18326
				// (get) Token: 0x0600C58F RID: 50575 RVA: 0x00318394 File Offset: 0x00316594
				// (set) Token: 0x0600C590 RID: 50576 RVA: 0x003183B2 File Offset: 0x003165B2
				public unsafe static uint GLASS
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GLASS, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GLASS, (void*)(&value));
					}
				}

				// Token: 0x17004797 RID: 18327
				// (get) Token: 0x0600C591 RID: 50577 RVA: 0x003183C4 File Offset: 0x003165C4
				// (set) Token: 0x0600C592 RID: 50578 RVA: 0x003183E2 File Offset: 0x003165E2
				public unsafe static uint GRASS
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GRASS, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_GRASS, (void*)(&value));
					}
				}

				// Token: 0x17004798 RID: 18328
				// (get) Token: 0x0600C593 RID: 50579 RVA: 0x003183F4 File Offset: 0x003165F4
				// (set) Token: 0x0600C594 RID: 50580 RVA: 0x00318412 File Offset: 0x00316612
				public unsafe static uint ICE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_ICE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_ICE, (void*)(&value));
					}
				}

				// Token: 0x17004799 RID: 18329
				// (get) Token: 0x0600C595 RID: 50581 RVA: 0x00318424 File Offset: 0x00316624
				// (set) Token: 0x0600C596 RID: 50582 RVA: 0x00318442 File Offset: 0x00316642
				public unsafe static uint METAL
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_METAL, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_METAL, (void*)(&value));
					}
				}

				// Token: 0x1700479A RID: 18330
				// (get) Token: 0x0600C597 RID: 50583 RVA: 0x00318454 File Offset: 0x00316654
				// (set) Token: 0x0600C598 RID: 50584 RVA: 0x00318472 File Offset: 0x00316672
				public unsafe static uint NULL
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_NULL, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_NULL, (void*)(&value));
					}
				}

				// Token: 0x1700479B RID: 18331
				// (get) Token: 0x0600C599 RID: 50585 RVA: 0x00318484 File Offset: 0x00316684
				// (set) Token: 0x0600C59A RID: 50586 RVA: 0x003184A2 File Offset: 0x003166A2
				public unsafe static uint SNOW
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_SNOW, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_SNOW, (void*)(&value));
					}
				}

				// Token: 0x1700479C RID: 18332
				// (get) Token: 0x0600C59B RID: 50587 RVA: 0x003184B4 File Offset: 0x003166B4
				// (set) Token: 0x0600C59C RID: 50588 RVA: 0x003184D2 File Offset: 0x003166D2
				public unsafe static uint TASER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_TASER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_TASER, (void*)(&value));
					}
				}

				// Token: 0x1700479D RID: 18333
				// (get) Token: 0x0600C59D RID: 50589 RVA: 0x003184E4 File Offset: 0x003166E4
				// (set) Token: 0x0600C59E RID: 50590 RVA: 0x00318502 File Offset: 0x00316702
				public unsafe static uint WATER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WATER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WATER, (void*)(&value));
					}
				}

				// Token: 0x1700479E RID: 18334
				// (get) Token: 0x0600C59F RID: 50591 RVA: 0x00318514 File Offset: 0x00316714
				// (set) Token: 0x0600C5A0 RID: 50592 RVA: 0x00318532 File Offset: 0x00316732
				public unsafe static uint WOOD
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD, (void*)(&value));
					}
				}

				// Token: 0x1700479F RID: 18335
				// (get) Token: 0x0600C5A1 RID: 50593 RVA: 0x00318544 File Offset: 0x00316744
				// (set) Token: 0x0600C5A2 RID: 50594 RVA: 0x00318562 File Offset: 0x00316762
				public unsafe static uint WOOD_OLD
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD_OLD, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.DAMAGELIBRARY_MATERIAL_SWITCH.SWITCH.NativeFieldInfoPtr_WOOD_OLD, (void*)(&value));
					}
				}

				// Token: 0x04007D53 RID: 32083
				private static readonly IntPtr NativeFieldInfoPtr_BODY;

				// Token: 0x04007D54 RID: 32084
				private static readonly IntPtr NativeFieldInfoPtr_CLOTH;

				// Token: 0x04007D55 RID: 32085
				private static readonly IntPtr NativeFieldInfoPtr_CONCRETE;

				// Token: 0x04007D56 RID: 32086
				private static readonly IntPtr NativeFieldInfoPtr_DIRT;

				// Token: 0x04007D57 RID: 32087
				private static readonly IntPtr NativeFieldInfoPtr_GLASS;

				// Token: 0x04007D58 RID: 32088
				private static readonly IntPtr NativeFieldInfoPtr_GRASS;

				// Token: 0x04007D59 RID: 32089
				private static readonly IntPtr NativeFieldInfoPtr_ICE;

				// Token: 0x04007D5A RID: 32090
				private static readonly IntPtr NativeFieldInfoPtr_METAL;

				// Token: 0x04007D5B RID: 32091
				private static readonly IntPtr NativeFieldInfoPtr_NULL;

				// Token: 0x04007D5C RID: 32092
				private static readonly IntPtr NativeFieldInfoPtr_SNOW;

				// Token: 0x04007D5D RID: 32093
				private static readonly IntPtr NativeFieldInfoPtr_TASER;

				// Token: 0x04007D5E RID: 32094
				private static readonly IntPtr NativeFieldInfoPtr_WATER;

				// Token: 0x04007D5F RID: 32095
				private static readonly IntPtr NativeFieldInfoPtr_WOOD;

				// Token: 0x04007D60 RID: 32096
				private static readonly IntPtr NativeFieldInfoPtr_WOOD_OLD;

				// Token: 0x04007D61 RID: 32097
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000928 RID: 2344
		public class ENV_AUDIOINPUT_DISTANCE_SWITCH : Object
		{
			// Token: 0x0600C5A3 RID: 50595 RVA: 0x00318574 File Offset: 0x00316774
			[CallerCount(0)]
			public unsafe ENV_AUDIOINPUT_DISTANCE_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C5A4 RID: 50596 RVA: 0x003185C0 File Offset: 0x003167C0
			// Note: this type is marked as 'beforefieldinit'.
			static ENV_AUDIOINPUT_DISTANCE_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "ENV_AUDIOINPUT_DISTANCE_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr);
				SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr, 100678732);
			}

			// Token: 0x0600C5A5 RID: 50597 RVA: 0x00002988 File Offset: 0x00000B88
			public ENV_AUDIOINPUT_DISTANCE_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047A0 RID: 18336
			// (get) Token: 0x0600C5A6 RID: 50598 RVA: 0x00318613 File Offset: 0x00316813
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047A1 RID: 18337
			// (get) Token: 0x0600C5A7 RID: 50599 RVA: 0x00318624 File Offset: 0x00316824
			// (set) Token: 0x0600C5A8 RID: 50600 RVA: 0x00318642 File Offset: 0x00316842
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D62 RID: 32098
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D63 RID: 32099
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000929 RID: 2345
			public class SWITCH : Object
			{
				// Token: 0x0600C5A9 RID: 50601 RVA: 0x00318654 File Offset: 0x00316854
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C5AA RID: 50602 RVA: 0x003186A0 File Offset: 0x003168A0
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D005 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D005");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D010 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D010");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D015 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D015");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D020 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D020");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D025 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D025");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D030 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D030");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D040 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D040");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D050 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D050");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D060 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D060");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D070 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D070");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D080 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D080");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D100 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D100");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D120 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D120");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D140 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D140");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D160 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D160");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D180 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D180");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D200 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D200");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D250 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D250");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D300 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D300");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D400 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D400");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D500 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D500");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D600 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D600");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D700 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D700");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D800 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, "D800");
					SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr, 100678734);
				}

				// Token: 0x0600C5AB RID: 50603 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047A2 RID: 18338
				// (get) Token: 0x0600C5AC RID: 50604 RVA: 0x003188BF File Offset: 0x00316ABF
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047A3 RID: 18339
				// (get) Token: 0x0600C5AD RID: 50605 RVA: 0x003188D0 File Offset: 0x00316AD0
				// (set) Token: 0x0600C5AE RID: 50606 RVA: 0x003188EE File Offset: 0x00316AEE
				public unsafe static uint D005
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D005, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D005, (void*)(&value));
					}
				}

				// Token: 0x170047A4 RID: 18340
				// (get) Token: 0x0600C5AF RID: 50607 RVA: 0x00318900 File Offset: 0x00316B00
				// (set) Token: 0x0600C5B0 RID: 50608 RVA: 0x0031891E File Offset: 0x00316B1E
				public unsafe static uint D010
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D010, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D010, (void*)(&value));
					}
				}

				// Token: 0x170047A5 RID: 18341
				// (get) Token: 0x0600C5B1 RID: 50609 RVA: 0x00318930 File Offset: 0x00316B30
				// (set) Token: 0x0600C5B2 RID: 50610 RVA: 0x0031894E File Offset: 0x00316B4E
				public unsafe static uint D015
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D015, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D015, (void*)(&value));
					}
				}

				// Token: 0x170047A6 RID: 18342
				// (get) Token: 0x0600C5B3 RID: 50611 RVA: 0x00318960 File Offset: 0x00316B60
				// (set) Token: 0x0600C5B4 RID: 50612 RVA: 0x0031897E File Offset: 0x00316B7E
				public unsafe static uint D020
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D020, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D020, (void*)(&value));
					}
				}

				// Token: 0x170047A7 RID: 18343
				// (get) Token: 0x0600C5B5 RID: 50613 RVA: 0x00318990 File Offset: 0x00316B90
				// (set) Token: 0x0600C5B6 RID: 50614 RVA: 0x003189AE File Offset: 0x00316BAE
				public unsafe static uint D025
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D025, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D025, (void*)(&value));
					}
				}

				// Token: 0x170047A8 RID: 18344
				// (get) Token: 0x0600C5B7 RID: 50615 RVA: 0x003189C0 File Offset: 0x00316BC0
				// (set) Token: 0x0600C5B8 RID: 50616 RVA: 0x003189DE File Offset: 0x00316BDE
				public unsafe static uint D030
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D030, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D030, (void*)(&value));
					}
				}

				// Token: 0x170047A9 RID: 18345
				// (get) Token: 0x0600C5B9 RID: 50617 RVA: 0x003189F0 File Offset: 0x00316BF0
				// (set) Token: 0x0600C5BA RID: 50618 RVA: 0x00318A0E File Offset: 0x00316C0E
				public unsafe static uint D040
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D040, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D040, (void*)(&value));
					}
				}

				// Token: 0x170047AA RID: 18346
				// (get) Token: 0x0600C5BB RID: 50619 RVA: 0x00318A20 File Offset: 0x00316C20
				// (set) Token: 0x0600C5BC RID: 50620 RVA: 0x00318A3E File Offset: 0x00316C3E
				public unsafe static uint D050
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D050, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D050, (void*)(&value));
					}
				}

				// Token: 0x170047AB RID: 18347
				// (get) Token: 0x0600C5BD RID: 50621 RVA: 0x00318A50 File Offset: 0x00316C50
				// (set) Token: 0x0600C5BE RID: 50622 RVA: 0x00318A6E File Offset: 0x00316C6E
				public unsafe static uint D060
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D060, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D060, (void*)(&value));
					}
				}

				// Token: 0x170047AC RID: 18348
				// (get) Token: 0x0600C5BF RID: 50623 RVA: 0x00318A80 File Offset: 0x00316C80
				// (set) Token: 0x0600C5C0 RID: 50624 RVA: 0x00318A9E File Offset: 0x00316C9E
				public unsafe static uint D070
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D070, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D070, (void*)(&value));
					}
				}

				// Token: 0x170047AD RID: 18349
				// (get) Token: 0x0600C5C1 RID: 50625 RVA: 0x00318AB0 File Offset: 0x00316CB0
				// (set) Token: 0x0600C5C2 RID: 50626 RVA: 0x00318ACE File Offset: 0x00316CCE
				public unsafe static uint D080
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D080, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D080, (void*)(&value));
					}
				}

				// Token: 0x170047AE RID: 18350
				// (get) Token: 0x0600C5C3 RID: 50627 RVA: 0x00318AE0 File Offset: 0x00316CE0
				// (set) Token: 0x0600C5C4 RID: 50628 RVA: 0x00318AFE File Offset: 0x00316CFE
				public unsafe static uint D100
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D100, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D100, (void*)(&value));
					}
				}

				// Token: 0x170047AF RID: 18351
				// (get) Token: 0x0600C5C5 RID: 50629 RVA: 0x00318B10 File Offset: 0x00316D10
				// (set) Token: 0x0600C5C6 RID: 50630 RVA: 0x00318B2E File Offset: 0x00316D2E
				public unsafe static uint D120
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D120, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D120, (void*)(&value));
					}
				}

				// Token: 0x170047B0 RID: 18352
				// (get) Token: 0x0600C5C7 RID: 50631 RVA: 0x00318B40 File Offset: 0x00316D40
				// (set) Token: 0x0600C5C8 RID: 50632 RVA: 0x00318B5E File Offset: 0x00316D5E
				public unsafe static uint D140
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D140, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D140, (void*)(&value));
					}
				}

				// Token: 0x170047B1 RID: 18353
				// (get) Token: 0x0600C5C9 RID: 50633 RVA: 0x00318B70 File Offset: 0x00316D70
				// (set) Token: 0x0600C5CA RID: 50634 RVA: 0x00318B8E File Offset: 0x00316D8E
				public unsafe static uint D160
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D160, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D160, (void*)(&value));
					}
				}

				// Token: 0x170047B2 RID: 18354
				// (get) Token: 0x0600C5CB RID: 50635 RVA: 0x00318BA0 File Offset: 0x00316DA0
				// (set) Token: 0x0600C5CC RID: 50636 RVA: 0x00318BBE File Offset: 0x00316DBE
				public unsafe static uint D180
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D180, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D180, (void*)(&value));
					}
				}

				// Token: 0x170047B3 RID: 18355
				// (get) Token: 0x0600C5CD RID: 50637 RVA: 0x00318BD0 File Offset: 0x00316DD0
				// (set) Token: 0x0600C5CE RID: 50638 RVA: 0x00318BEE File Offset: 0x00316DEE
				public unsafe static uint D200
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D200, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D200, (void*)(&value));
					}
				}

				// Token: 0x170047B4 RID: 18356
				// (get) Token: 0x0600C5CF RID: 50639 RVA: 0x00318C00 File Offset: 0x00316E00
				// (set) Token: 0x0600C5D0 RID: 50640 RVA: 0x00318C1E File Offset: 0x00316E1E
				public unsafe static uint D250
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D250, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D250, (void*)(&value));
					}
				}

				// Token: 0x170047B5 RID: 18357
				// (get) Token: 0x0600C5D1 RID: 50641 RVA: 0x00318C30 File Offset: 0x00316E30
				// (set) Token: 0x0600C5D2 RID: 50642 RVA: 0x00318C4E File Offset: 0x00316E4E
				public unsafe static uint D300
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D300, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D300, (void*)(&value));
					}
				}

				// Token: 0x170047B6 RID: 18358
				// (get) Token: 0x0600C5D3 RID: 50643 RVA: 0x00318C60 File Offset: 0x00316E60
				// (set) Token: 0x0600C5D4 RID: 50644 RVA: 0x00318C7E File Offset: 0x00316E7E
				public unsafe static uint D400
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D400, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D400, (void*)(&value));
					}
				}

				// Token: 0x170047B7 RID: 18359
				// (get) Token: 0x0600C5D5 RID: 50645 RVA: 0x00318C90 File Offset: 0x00316E90
				// (set) Token: 0x0600C5D6 RID: 50646 RVA: 0x00318CAE File Offset: 0x00316EAE
				public unsafe static uint D500
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D500, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D500, (void*)(&value));
					}
				}

				// Token: 0x170047B8 RID: 18360
				// (get) Token: 0x0600C5D7 RID: 50647 RVA: 0x00318CC0 File Offset: 0x00316EC0
				// (set) Token: 0x0600C5D8 RID: 50648 RVA: 0x00318CDE File Offset: 0x00316EDE
				public unsafe static uint D600
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D600, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D600, (void*)(&value));
					}
				}

				// Token: 0x170047B9 RID: 18361
				// (get) Token: 0x0600C5D9 RID: 50649 RVA: 0x00318CF0 File Offset: 0x00316EF0
				// (set) Token: 0x0600C5DA RID: 50650 RVA: 0x00318D0E File Offset: 0x00316F0E
				public unsafe static uint D700
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D700, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D700, (void*)(&value));
					}
				}

				// Token: 0x170047BA RID: 18362
				// (get) Token: 0x0600C5DB RID: 50651 RVA: 0x00318D20 File Offset: 0x00316F20
				// (set) Token: 0x0600C5DC RID: 50652 RVA: 0x00318D3E File Offset: 0x00316F3E
				public unsafe static uint D800
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D800, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.ENV_AUDIOINPUT_DISTANCE_SWITCH.SWITCH.NativeFieldInfoPtr_D800, (void*)(&value));
					}
				}

				// Token: 0x04007D64 RID: 32100
				private static readonly IntPtr NativeFieldInfoPtr_D005;

				// Token: 0x04007D65 RID: 32101
				private static readonly IntPtr NativeFieldInfoPtr_D010;

				// Token: 0x04007D66 RID: 32102
				private static readonly IntPtr NativeFieldInfoPtr_D015;

				// Token: 0x04007D67 RID: 32103
				private static readonly IntPtr NativeFieldInfoPtr_D020;

				// Token: 0x04007D68 RID: 32104
				private static readonly IntPtr NativeFieldInfoPtr_D025;

				// Token: 0x04007D69 RID: 32105
				private static readonly IntPtr NativeFieldInfoPtr_D030;

				// Token: 0x04007D6A RID: 32106
				private static readonly IntPtr NativeFieldInfoPtr_D040;

				// Token: 0x04007D6B RID: 32107
				private static readonly IntPtr NativeFieldInfoPtr_D050;

				// Token: 0x04007D6C RID: 32108
				private static readonly IntPtr NativeFieldInfoPtr_D060;

				// Token: 0x04007D6D RID: 32109
				private static readonly IntPtr NativeFieldInfoPtr_D070;

				// Token: 0x04007D6E RID: 32110
				private static readonly IntPtr NativeFieldInfoPtr_D080;

				// Token: 0x04007D6F RID: 32111
				private static readonly IntPtr NativeFieldInfoPtr_D100;

				// Token: 0x04007D70 RID: 32112
				private static readonly IntPtr NativeFieldInfoPtr_D120;

				// Token: 0x04007D71 RID: 32113
				private static readonly IntPtr NativeFieldInfoPtr_D140;

				// Token: 0x04007D72 RID: 32114
				private static readonly IntPtr NativeFieldInfoPtr_D160;

				// Token: 0x04007D73 RID: 32115
				private static readonly IntPtr NativeFieldInfoPtr_D180;

				// Token: 0x04007D74 RID: 32116
				private static readonly IntPtr NativeFieldInfoPtr_D200;

				// Token: 0x04007D75 RID: 32117
				private static readonly IntPtr NativeFieldInfoPtr_D250;

				// Token: 0x04007D76 RID: 32118
				private static readonly IntPtr NativeFieldInfoPtr_D300;

				// Token: 0x04007D77 RID: 32119
				private static readonly IntPtr NativeFieldInfoPtr_D400;

				// Token: 0x04007D78 RID: 32120
				private static readonly IntPtr NativeFieldInfoPtr_D500;

				// Token: 0x04007D79 RID: 32121
				private static readonly IntPtr NativeFieldInfoPtr_D600;

				// Token: 0x04007D7A RID: 32122
				private static readonly IntPtr NativeFieldInfoPtr_D700;

				// Token: 0x04007D7B RID: 32123
				private static readonly IntPtr NativeFieldInfoPtr_D800;

				// Token: 0x04007D7C RID: 32124
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200092A RID: 2346
		public class LOADING_MUSIC_SELECTION_SWITCH : Object
		{
			// Token: 0x0600C5DD RID: 50653 RVA: 0x00318D50 File Offset: 0x00316F50
			[CallerCount(0)]
			public unsafe LOADING_MUSIC_SELECTION_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C5DE RID: 50654 RVA: 0x00318D9C File Offset: 0x00316F9C
			// Note: this type is marked as 'beforefieldinit'.
			static LOADING_MUSIC_SELECTION_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "LOADING_MUSIC_SELECTION_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr);
				SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr, 100678736);
			}

			// Token: 0x0600C5DF RID: 50655 RVA: 0x00002988 File Offset: 0x00000B88
			public LOADING_MUSIC_SELECTION_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047BB RID: 18363
			// (get) Token: 0x0600C5E0 RID: 50656 RVA: 0x00318DEF File Offset: 0x00316FEF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047BC RID: 18364
			// (get) Token: 0x0600C5E1 RID: 50657 RVA: 0x00318E00 File Offset: 0x00317000
			// (set) Token: 0x0600C5E2 RID: 50658 RVA: 0x00318E1E File Offset: 0x0031701E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D7D RID: 32125
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D7E RID: 32126
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200092B RID: 2347
			public class SWITCH : Object
			{
				// Token: 0x0600C5E3 RID: 50659 RVA: 0x00318E30 File Offset: 0x00317030
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C5E4 RID: 50660 RVA: 0x00318E7C File Offset: 0x0031707C
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_ANTCHLEA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_ANTCHLEA");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_BAZAAR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_BAZAAR");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGRESS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_EGRESS");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_HELLS_GATE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_HELLS_GATE");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_IMAGINING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_IMAGINING");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_JUNGLE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_JUNGLE");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SILENCE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_SILENCE");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SPLASHSCREEN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_SPLASHSCREEN");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SUBWAY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_SUBWAY");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_TURBINE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "LOADING_MUSIC_TURBINE");
					SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, 100678738);
				}

				// Token: 0x0600C5E5 RID: 50661 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047BD RID: 18365
				// (get) Token: 0x0600C5E6 RID: 50662 RVA: 0x00318FE7 File Offset: 0x003171E7
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047BE RID: 18366
				// (get) Token: 0x0600C5E7 RID: 50663 RVA: 0x00318FF8 File Offset: 0x003171F8
				// (set) Token: 0x0600C5E8 RID: 50664 RVA: 0x00319016 File Offset: 0x00317216
				public unsafe static uint LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD, (void*)(&value));
					}
				}

				// Token: 0x170047BF RID: 18367
				// (get) Token: 0x0600C5E9 RID: 50665 RVA: 0x00319028 File Offset: 0x00317228
				// (set) Token: 0x0600C5EA RID: 50666 RVA: 0x00319046 File Offset: 0x00317246
				public unsafe static uint LOADING_MUSIC_ANTCHLEA
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_ANTCHLEA, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_ANTCHLEA, (void*)(&value));
					}
				}

				// Token: 0x170047C0 RID: 18368
				// (get) Token: 0x0600C5EB RID: 50667 RVA: 0x00319058 File Offset: 0x00317258
				// (set) Token: 0x0600C5EC RID: 50668 RVA: 0x00319076 File Offset: 0x00317276
				public unsafe static uint LOADING_MUSIC_BAZAAR
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_BAZAAR, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_BAZAAR, (void*)(&value));
					}
				}

				// Token: 0x170047C1 RID: 18369
				// (get) Token: 0x0600C5ED RID: 50669 RVA: 0x00319088 File Offset: 0x00317288
				// (set) Token: 0x0600C5EE RID: 50670 RVA: 0x003190A6 File Offset: 0x003172A6
				public unsafe static uint LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND, (void*)(&value));
					}
				}

				// Token: 0x170047C2 RID: 18370
				// (get) Token: 0x0600C5EF RID: 50671 RVA: 0x003190B8 File Offset: 0x003172B8
				// (set) Token: 0x0600C5F0 RID: 50672 RVA: 0x003190D6 File Offset: 0x003172D6
				public unsafe static uint LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST, (void*)(&value));
					}
				}

				// Token: 0x170047C3 RID: 18371
				// (get) Token: 0x0600C5F1 RID: 50673 RVA: 0x003190E8 File Offset: 0x003172E8
				// (set) Token: 0x0600C5F2 RID: 50674 RVA: 0x00319106 File Offset: 0x00317306
				public unsafe static uint LOADING_MUSIC_EGRESS
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGRESS, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGRESS, (void*)(&value));
					}
				}

				// Token: 0x170047C4 RID: 18372
				// (get) Token: 0x0600C5F3 RID: 50675 RVA: 0x00319118 File Offset: 0x00317318
				// (set) Token: 0x0600C5F4 RID: 50676 RVA: 0x00319136 File Offset: 0x00317336
				public unsafe static uint LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE, (void*)(&value));
					}
				}

				// Token: 0x170047C5 RID: 18373
				// (get) Token: 0x0600C5F5 RID: 50677 RVA: 0x00319148 File Offset: 0x00317348
				// (set) Token: 0x0600C5F6 RID: 50678 RVA: 0x00319166 File Offset: 0x00317366
				public unsafe static uint LOADING_MUSIC_HELLS_GATE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_HELLS_GATE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_HELLS_GATE, (void*)(&value));
					}
				}

				// Token: 0x170047C6 RID: 18374
				// (get) Token: 0x0600C5F7 RID: 50679 RVA: 0x00319178 File Offset: 0x00317378
				// (set) Token: 0x0600C5F8 RID: 50680 RVA: 0x00319196 File Offset: 0x00317396
				public unsafe static uint LOADING_MUSIC_IMAGINING
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_IMAGINING, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_IMAGINING, (void*)(&value));
					}
				}

				// Token: 0x170047C7 RID: 18375
				// (get) Token: 0x0600C5F9 RID: 50681 RVA: 0x003191A8 File Offset: 0x003173A8
				// (set) Token: 0x0600C5FA RID: 50682 RVA: 0x003191C6 File Offset: 0x003173C6
				public unsafe static uint LOADING_MUSIC_JUNGLE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_JUNGLE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_JUNGLE, (void*)(&value));
					}
				}

				// Token: 0x170047C8 RID: 18376
				// (get) Token: 0x0600C5FB RID: 50683 RVA: 0x003191D8 File Offset: 0x003173D8
				// (set) Token: 0x0600C5FC RID: 50684 RVA: 0x003191F6 File Offset: 0x003173F6
				public unsafe static uint LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER, (void*)(&value));
					}
				}

				// Token: 0x170047C9 RID: 18377
				// (get) Token: 0x0600C5FD RID: 50685 RVA: 0x00319208 File Offset: 0x00317408
				// (set) Token: 0x0600C5FE RID: 50686 RVA: 0x00319226 File Offset: 0x00317426
				public unsafe static uint LOADING_MUSIC_SILENCE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SILENCE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SILENCE, (void*)(&value));
					}
				}

				// Token: 0x170047CA RID: 18378
				// (get) Token: 0x0600C5FF RID: 50687 RVA: 0x00319238 File Offset: 0x00317438
				// (set) Token: 0x0600C600 RID: 50688 RVA: 0x00319256 File Offset: 0x00317456
				public unsafe static uint LOADING_MUSIC_SPLASHSCREEN
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SPLASHSCREEN, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SPLASHSCREEN, (void*)(&value));
					}
				}

				// Token: 0x170047CB RID: 18379
				// (get) Token: 0x0600C601 RID: 50689 RVA: 0x00319268 File Offset: 0x00317468
				// (set) Token: 0x0600C602 RID: 50690 RVA: 0x00319286 File Offset: 0x00317486
				public unsafe static uint LOADING_MUSIC_SUBWAY
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SUBWAY, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_SUBWAY, (void*)(&value));
					}
				}

				// Token: 0x170047CC RID: 18380
				// (get) Token: 0x0600C603 RID: 50691 RVA: 0x00319298 File Offset: 0x00317498
				// (set) Token: 0x0600C604 RID: 50692 RVA: 0x003192B6 File Offset: 0x003174B6
				public unsafe static uint LOADING_MUSIC_TURBINE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_TURBINE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.LOADING_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING_MUSIC_TURBINE, (void*)(&value));
					}
				}

				// Token: 0x04007D7F RID: 32127
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_AMBIENT_DARK_STRING_MOOD;

				// Token: 0x04007D80 RID: 32128
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_ANTCHLEA;

				// Token: 0x04007D81 RID: 32129
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_BAZAAR;

				// Token: 0x04007D82 RID: 32130
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_DARK_AMBIENT_HORROR_BACKGROUND;

				// Token: 0x04007D83 RID: 32131
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_DEATH_IN_THE_MIDDLE_EAST;

				// Token: 0x04007D84 RID: 32132
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_EGRESS;

				// Token: 0x04007D85 RID: 32133
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_EGYPTIAN_DESERT_FLUTE;

				// Token: 0x04007D86 RID: 32134
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_HELLS_GATE;

				// Token: 0x04007D87 RID: 32135
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_IMAGINING;

				// Token: 0x04007D88 RID: 32136
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_JUNGLE;

				// Token: 0x04007D89 RID: 32137
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_REQIUEM_FOR_A_SOLDIER;

				// Token: 0x04007D8A RID: 32138
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_SILENCE;

				// Token: 0x04007D8B RID: 32139
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_SPLASHSCREEN;

				// Token: 0x04007D8C RID: 32140
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_SUBWAY;

				// Token: 0x04007D8D RID: 32141
				private static readonly IntPtr NativeFieldInfoPtr_LOADING_MUSIC_TURBINE;

				// Token: 0x04007D8E RID: 32142
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200092C RID: 2348
		public class MUSIC_SWITCH : Object
		{
			// Token: 0x0600C605 RID: 50693 RVA: 0x003192C8 File Offset: 0x003174C8
			[CallerCount(0)]
			public unsafe MUSIC_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.MUSIC_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C606 RID: 50694 RVA: 0x00319314 File Offset: 0x00317514
			// Note: this type is marked as 'beforefieldinit'.
			static MUSIC_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "MUSIC_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr);
				SWITCHES.MUSIC_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.MUSIC_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr, 100678740);
			}

			// Token: 0x0600C607 RID: 50695 RVA: 0x00002988 File Offset: 0x00000B88
			public MUSIC_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047CD RID: 18381
			// (get) Token: 0x0600C608 RID: 50696 RVA: 0x00319367 File Offset: 0x00317567
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047CE RID: 18382
			// (get) Token: 0x0600C609 RID: 50697 RVA: 0x00319378 File Offset: 0x00317578
			// (set) Token: 0x0600C60A RID: 50698 RVA: 0x00319396 File Offset: 0x00317596
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D8F RID: 32143
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D90 RID: 32144
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200092D RID: 2349
			public class SWITCH : Object
			{
				// Token: 0x0600C60B RID: 50699 RVA: 0x003193A8 File Offset: 0x003175A8
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.MUSIC_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C60C RID: 50700 RVA: 0x003193F4 File Offset: 0x003175F4
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_DEFEAT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "DEFEAT");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "LOADING");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_MENU = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "MENU");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SILENCE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "SILENCE");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SPLASHSCREEN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "SPLASHSCREEN");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_START = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "START");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_TENT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "TENT");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_VICTORY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, "VICTORY");
					SWITCHES.MUSIC_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr, 100678742);
				}

				// Token: 0x0600C60D RID: 50701 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047CF RID: 18383
				// (get) Token: 0x0600C60E RID: 50702 RVA: 0x003194D3 File Offset: 0x003176D3
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.MUSIC_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047D0 RID: 18384
				// (get) Token: 0x0600C60F RID: 50703 RVA: 0x003194E4 File Offset: 0x003176E4
				// (set) Token: 0x0600C610 RID: 50704 RVA: 0x00319502 File Offset: 0x00317702
				public unsafe static uint DEFEAT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_DEFEAT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_DEFEAT, (void*)(&value));
					}
				}

				// Token: 0x170047D1 RID: 18385
				// (get) Token: 0x0600C611 RID: 50705 RVA: 0x00319514 File Offset: 0x00317714
				// (set) Token: 0x0600C612 RID: 50706 RVA: 0x00319532 File Offset: 0x00317732
				public unsafe static uint LOADING
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_LOADING, (void*)(&value));
					}
				}

				// Token: 0x170047D2 RID: 18386
				// (get) Token: 0x0600C613 RID: 50707 RVA: 0x00319544 File Offset: 0x00317744
				// (set) Token: 0x0600C614 RID: 50708 RVA: 0x00319562 File Offset: 0x00317762
				public unsafe static uint MENU
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_MENU, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_MENU, (void*)(&value));
					}
				}

				// Token: 0x170047D3 RID: 18387
				// (get) Token: 0x0600C615 RID: 50709 RVA: 0x00319574 File Offset: 0x00317774
				// (set) Token: 0x0600C616 RID: 50710 RVA: 0x00319592 File Offset: 0x00317792
				public unsafe static uint SILENCE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SILENCE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SILENCE, (void*)(&value));
					}
				}

				// Token: 0x170047D4 RID: 18388
				// (get) Token: 0x0600C617 RID: 50711 RVA: 0x003195A4 File Offset: 0x003177A4
				// (set) Token: 0x0600C618 RID: 50712 RVA: 0x003195C2 File Offset: 0x003177C2
				public unsafe static uint SPLASHSCREEN
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SPLASHSCREEN, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_SPLASHSCREEN, (void*)(&value));
					}
				}

				// Token: 0x170047D5 RID: 18389
				// (get) Token: 0x0600C619 RID: 50713 RVA: 0x003195D4 File Offset: 0x003177D4
				// (set) Token: 0x0600C61A RID: 50714 RVA: 0x003195F2 File Offset: 0x003177F2
				public unsafe static uint START
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_START, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_START, (void*)(&value));
					}
				}

				// Token: 0x170047D6 RID: 18390
				// (get) Token: 0x0600C61B RID: 50715 RVA: 0x00319604 File Offset: 0x00317804
				// (set) Token: 0x0600C61C RID: 50716 RVA: 0x00319622 File Offset: 0x00317822
				public unsafe static uint TENT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_TENT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_TENT, (void*)(&value));
					}
				}

				// Token: 0x170047D7 RID: 18391
				// (get) Token: 0x0600C61D RID: 50717 RVA: 0x00319634 File Offset: 0x00317834
				// (set) Token: 0x0600C61E RID: 50718 RVA: 0x00319652 File Offset: 0x00317852
				public unsafe static uint VICTORY
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_VICTORY, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.MUSIC_SWITCH.SWITCH.NativeFieldInfoPtr_VICTORY, (void*)(&value));
					}
				}

				// Token: 0x04007D91 RID: 32145
				private static readonly IntPtr NativeFieldInfoPtr_DEFEAT;

				// Token: 0x04007D92 RID: 32146
				private static readonly IntPtr NativeFieldInfoPtr_LOADING;

				// Token: 0x04007D93 RID: 32147
				private static readonly IntPtr NativeFieldInfoPtr_MENU;

				// Token: 0x04007D94 RID: 32148
				private static readonly IntPtr NativeFieldInfoPtr_SILENCE;

				// Token: 0x04007D95 RID: 32149
				private static readonly IntPtr NativeFieldInfoPtr_SPLASHSCREEN;

				// Token: 0x04007D96 RID: 32150
				private static readonly IntPtr NativeFieldInfoPtr_START;

				// Token: 0x04007D97 RID: 32151
				private static readonly IntPtr NativeFieldInfoPtr_TENT;

				// Token: 0x04007D98 RID: 32152
				private static readonly IntPtr NativeFieldInfoPtr_VICTORY;

				// Token: 0x04007D99 RID: 32153
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200092E RID: 2350
		public class SPLASHSCREEN_SWITCH : Object
		{
			// Token: 0x0600C61F RID: 50719 RVA: 0x00319664 File Offset: 0x00317864
			[CallerCount(0)]
			public unsafe SPLASHSCREEN_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.SPLASHSCREEN_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C620 RID: 50720 RVA: 0x003196B0 File Offset: 0x003178B0
			// Note: this type is marked as 'beforefieldinit'.
			static SPLASHSCREEN_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "SPLASHSCREEN_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr);
				SWITCHES.SPLASHSCREEN_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.SPLASHSCREEN_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr, 100678744);
			}

			// Token: 0x0600C621 RID: 50721 RVA: 0x00002988 File Offset: 0x00000B88
			public SPLASHSCREEN_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047D8 RID: 18392
			// (get) Token: 0x0600C622 RID: 50722 RVA: 0x00319703 File Offset: 0x00317903
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047D9 RID: 18393
			// (get) Token: 0x0600C623 RID: 50723 RVA: 0x00319714 File Offset: 0x00317914
			// (set) Token: 0x0600C624 RID: 50724 RVA: 0x00319732 File Offset: 0x00317932
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.SPLASHSCREEN_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.SPLASHSCREEN_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D9A RID: 32154
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D9B RID: 32155
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200092F RID: 2351
			public class SWITCH : Object
			{
				// Token: 0x0600C625 RID: 50725 RVA: 0x00319744 File Offset: 0x00317944
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C626 RID: 50726 RVA: 0x00319790 File Offset: 0x00317990
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_LOGO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr, "LOGO");
					SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_MUSIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr, "MUSIC");
					SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr, 100678746);
				}

				// Token: 0x0600C627 RID: 50727 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047DA RID: 18394
				// (get) Token: 0x0600C628 RID: 50728 RVA: 0x003197F7 File Offset: 0x003179F7
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.SPLASHSCREEN_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047DB RID: 18395
				// (get) Token: 0x0600C629 RID: 50729 RVA: 0x00319808 File Offset: 0x00317A08
				// (set) Token: 0x0600C62A RID: 50730 RVA: 0x00319826 File Offset: 0x00317A26
				public unsafe static uint LOGO
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_LOGO, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_LOGO, (void*)(&value));
					}
				}

				// Token: 0x170047DC RID: 18396
				// (get) Token: 0x0600C62B RID: 50731 RVA: 0x00319838 File Offset: 0x00317A38
				// (set) Token: 0x0600C62C RID: 50732 RVA: 0x00319856 File Offset: 0x00317A56
				public unsafe static uint MUSIC
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_MUSIC, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.SPLASHSCREEN_SWITCH.SWITCH.NativeFieldInfoPtr_MUSIC, (void*)(&value));
					}
				}

				// Token: 0x04007D9C RID: 32156
				private static readonly IntPtr NativeFieldInfoPtr_LOGO;

				// Token: 0x04007D9D RID: 32157
				private static readonly IntPtr NativeFieldInfoPtr_MUSIC;

				// Token: 0x04007D9E RID: 32158
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000930 RID: 2352
		public class TENT_MUSIC_SELECTION_SWITCH : Object
		{
			// Token: 0x0600C62D RID: 50733 RVA: 0x00319868 File Offset: 0x00317A68
			[CallerCount(0)]
			public unsafe TENT_MUSIC_SELECTION_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C62E RID: 50734 RVA: 0x003198B4 File Offset: 0x00317AB4
			// Note: this type is marked as 'beforefieldinit'.
			static TENT_MUSIC_SELECTION_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "TENT_MUSIC_SELECTION_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr);
				SWITCHES.TENT_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.TENT_MUSIC_SELECTION_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr, 100678748);
			}

			// Token: 0x0600C62F RID: 50735 RVA: 0x00002988 File Offset: 0x00000B88
			public TENT_MUSIC_SELECTION_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047DD RID: 18397
			// (get) Token: 0x0600C630 RID: 50736 RVA: 0x00319907 File Offset: 0x00317B07
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047DE RID: 18398
			// (get) Token: 0x0600C631 RID: 50737 RVA: 0x00319918 File Offset: 0x00317B18
			// (set) Token: 0x0600C632 RID: 50738 RVA: 0x00319936 File Offset: 0x00317B36
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D9F RID: 32159
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007DA0 RID: 32160
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000931 RID: 2353
			public class SWITCH : Object
			{
				// Token: 0x0600C633 RID: 50739 RVA: 0x00319948 File Offset: 0x00317B48
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C634 RID: 50740 RVA: 0x00319994 File Offset: 0x00317B94
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_ANY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "TENT_MUSIC_ANY");
					SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRAMATIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "TENT_MUSIC_DRAMATIC");
					SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRONE_WITH_RADIO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "TENT_MUSIC_DRONE_WITH_RADIO");
					SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_SILENCE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, "TENT_MUSIC_SILENCE");
					SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr, 100678750);
				}

				// Token: 0x0600C635 RID: 50741 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047DF RID: 18399
				// (get) Token: 0x0600C636 RID: 50742 RVA: 0x00319A23 File Offset: 0x00317C23
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047E0 RID: 18400
				// (get) Token: 0x0600C637 RID: 50743 RVA: 0x00319A34 File Offset: 0x00317C34
				// (set) Token: 0x0600C638 RID: 50744 RVA: 0x00319A52 File Offset: 0x00317C52
				public unsafe static uint TENT_MUSIC_ANY
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_ANY, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_ANY, (void*)(&value));
					}
				}

				// Token: 0x170047E1 RID: 18401
				// (get) Token: 0x0600C639 RID: 50745 RVA: 0x00319A64 File Offset: 0x00317C64
				// (set) Token: 0x0600C63A RID: 50746 RVA: 0x00319A82 File Offset: 0x00317C82
				public unsafe static uint TENT_MUSIC_DRAMATIC
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRAMATIC, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRAMATIC, (void*)(&value));
					}
				}

				// Token: 0x170047E2 RID: 18402
				// (get) Token: 0x0600C63B RID: 50747 RVA: 0x00319A94 File Offset: 0x00317C94
				// (set) Token: 0x0600C63C RID: 50748 RVA: 0x00319AB2 File Offset: 0x00317CB2
				public unsafe static uint TENT_MUSIC_DRONE_WITH_RADIO
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRONE_WITH_RADIO, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_DRONE_WITH_RADIO, (void*)(&value));
					}
				}

				// Token: 0x170047E3 RID: 18403
				// (get) Token: 0x0600C63D RID: 50749 RVA: 0x00319AC4 File Offset: 0x00317CC4
				// (set) Token: 0x0600C63E RID: 50750 RVA: 0x00319AE2 File Offset: 0x00317CE2
				public unsafe static uint TENT_MUSIC_SILENCE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_SILENCE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.TENT_MUSIC_SELECTION_SWITCH.SWITCH.NativeFieldInfoPtr_TENT_MUSIC_SILENCE, (void*)(&value));
					}
				}

				// Token: 0x04007DA1 RID: 32161
				private static readonly IntPtr NativeFieldInfoPtr_TENT_MUSIC_ANY;

				// Token: 0x04007DA2 RID: 32162
				private static readonly IntPtr NativeFieldInfoPtr_TENT_MUSIC_DRAMATIC;

				// Token: 0x04007DA3 RID: 32163
				private static readonly IntPtr NativeFieldInfoPtr_TENT_MUSIC_DRONE_WITH_RADIO;

				// Token: 0x04007DA4 RID: 32164
				private static readonly IntPtr NativeFieldInfoPtr_TENT_MUSIC_SILENCE;

				// Token: 0x04007DA5 RID: 32165
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000932 RID: 2354
		public class WEP_ISSUPPRESSED_SWITCH : Object
		{
			// Token: 0x0600C63F RID: 50751 RVA: 0x00319AF4 File Offset: 0x00317CF4
			[CallerCount(0)]
			public unsafe WEP_ISSUPPRESSED_SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.WEP_ISSUPPRESSED_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C640 RID: 50752 RVA: 0x00319B40 File Offset: 0x00317D40
			// Note: this type is marked as 'beforefieldinit'.
			static WEP_ISSUPPRESSED_SWITCH()
			{
				Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES>.NativeClassPtr, "WEP_ISSUPPRESSED_SWITCH");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr);
				SWITCHES.WEP_ISSUPPRESSED_SWITCH.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr, "GROUP");
				SWITCHES.WEP_ISSUPPRESSED_SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr, 100678752);
			}

			// Token: 0x0600C641 RID: 50753 RVA: 0x00002988 File Offset: 0x00000B88
			public WEP_ISSUPPRESSED_SWITCH(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170047E4 RID: 18404
			// (get) Token: 0x0600C642 RID: 50754 RVA: 0x00319B93 File Offset: 0x00317D93
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr));
				}
			}

			// Token: 0x170047E5 RID: 18405
			// (get) Token: 0x0600C643 RID: 50755 RVA: 0x00319BA4 File Offset: 0x00317DA4
			// (set) Token: 0x0600C644 RID: 50756 RVA: 0x00319BC2 File Offset: 0x00317DC2
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007DA6 RID: 32166
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007DA7 RID: 32167
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000933 RID: 2355
			public class SWITCH : Object
			{
				// Token: 0x0600C645 RID: 50757 RVA: 0x00319BD4 File Offset: 0x00317DD4
				[CallerCount(0)]
				public unsafe SWITCH() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C646 RID: 50758 RVA: 0x00319C20 File Offset: 0x00317E20
				// Note: this type is marked as 'beforefieldinit'.
				static SWITCH()
				{
					Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH>.NativeClassPtr, "SWITCH");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr);
					SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_NORMAL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr, "NORMAL");
					SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr, "SUPPRESSED");
					SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr, 100678754);
				}

				// Token: 0x0600C647 RID: 50759 RVA: 0x00002988 File Offset: 0x00000B88
				public SWITCH(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x170047E6 RID: 18406
				// (get) Token: 0x0600C648 RID: 50760 RVA: 0x00319C87 File Offset: 0x00317E87
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH>.NativeClassPtr));
					}
				}

				// Token: 0x170047E7 RID: 18407
				// (get) Token: 0x0600C649 RID: 50761 RVA: 0x00319C98 File Offset: 0x00317E98
				// (set) Token: 0x0600C64A RID: 50762 RVA: 0x00319CB6 File Offset: 0x00317EB6
				public unsafe static uint NORMAL
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_NORMAL, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_NORMAL, (void*)(&value));
					}
				}

				// Token: 0x170047E8 RID: 18408
				// (get) Token: 0x0600C64B RID: 50763 RVA: 0x00319CC8 File Offset: 0x00317EC8
				// (set) Token: 0x0600C64C RID: 50764 RVA: 0x00319CE6 File Offset: 0x00317EE6
				public unsafe static uint SUPPRESSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_SUPPRESSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(SWITCHES.WEP_ISSUPPRESSED_SWITCH.SWITCH.NativeFieldInfoPtr_SUPPRESSED, (void*)(&value));
					}
				}

				// Token: 0x04007DA8 RID: 32168
				private static readonly IntPtr NativeFieldInfoPtr_NORMAL;

				// Token: 0x04007DA9 RID: 32169
				private static readonly IntPtr NativeFieldInfoPtr_SUPPRESSED;

				// Token: 0x04007DAA RID: 32170
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}
	}
}
