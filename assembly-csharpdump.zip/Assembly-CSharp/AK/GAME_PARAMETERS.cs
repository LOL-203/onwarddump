﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000934 RID: 2356
	public class GAME_PARAMETERS : Object
	{
		// Token: 0x0600C64D RID: 50765 RVA: 0x00319CF8 File Offset: 0x00317EF8
		[CallerCount(0)]
		public unsafe GAME_PARAMETERS() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(GAME_PARAMETERS.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C64E RID: 50766 RVA: 0x00319D44 File Offset: 0x00317F44
		// Note: this type is marked as 'beforefieldinit'.
		static GAME_PARAMETERS()
		{
			Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "GAME_PARAMETERS");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr);
			GAME_PARAMETERS.NativeFieldInfoPtr_BOLTSPEED_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "BOLTSPEED_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_BULLETCRACK_SIDECHAIN_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "BULLETCRACK_SIDECHAIN_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_CUSTOMCONTENT_VOLUME_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "CUSTOMCONTENT_VOLUME_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BUILTIN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "DISTANCE_BUILTIN");
			GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BULLETPASSBY_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "DISTANCE_BULLETPASSBY_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_DOPPLER_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "DOPPLER_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_DRONEACCELERATION_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "DRONEACCELERATION_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_DRONESPEED_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "DRONESPEED_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_GRABVOLUMEMULTIPLIER_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "GRABVOLUMEMULTIPLIER_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_3P_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "HDR_SIDECHAIN_3P_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "HDR_SIDECHAIN_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_HELI_SIDECHAIN_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "HELI_SIDECHAIN_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_3D_ENV_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "OBSTRUCTION_3D_ENV_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "OBSTRUCTION_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_OUTDOORNESS_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "OUTDOORNESS_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_L_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERARMMOVEMENT_L_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_R_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERARMMOVEMENT_R_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERCROUCH_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERCROUCH_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERDEAF_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERDEAF_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERHEALTH_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERHEALTH_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERMOVEMENT_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERMOVEMENT_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYEROUTDOORNESS_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYEROUTDOORNESS_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERSPEED_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "PLAYERSPEED_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_RADIO_EFFECT_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "RADIO_EFFECT_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_SIDECHAIN_EFFECTS_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "SIDECHAIN_EFFECTS_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_SP_3D_MIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "SP_3D_MIX");
			GAME_PARAMETERS.NativeFieldInfoPtr_TEAMCHAT_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "TEAMCHAT_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_THROWVOLUMEMULTIPLIER_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "THROWVOLUMEMULTIPLIER_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_VEHICLEACCELERATION_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VEHICLEACCELERATION_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_ENABLEATTENUATION_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOIP_ENABLEATTENUATION_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_METERING_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOIP_METERING_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MASTER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_MASTER");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MUSIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_MUSIC");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_ALL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_SFX_ALL");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_AMBIENT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_SFX_AMBIENT");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_GUNS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_SFX_GUNS");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_REVERB = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_SFX_REVERB");
			GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_VOIP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "VOLUME_VOIP");
			GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_1P_SIDECHAIN_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "WEAPON_1P_SIDECHAIN_RTPC");
			GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_BLEND_RTPC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, "WEAPON_BLEND_RTPC");
			GAME_PARAMETERS.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr, 100678756);
		}

		// Token: 0x0600C64F RID: 50767 RVA: 0x00002988 File Offset: 0x00000B88
		public GAME_PARAMETERS(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170047E9 RID: 18409
		// (get) Token: 0x0600C650 RID: 50768 RVA: 0x0031A0A8 File Offset: 0x003182A8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<GAME_PARAMETERS>.NativeClassPtr));
			}
		}

		// Token: 0x170047EA RID: 18410
		// (get) Token: 0x0600C651 RID: 50769 RVA: 0x0031A0BC File Offset: 0x003182BC
		// (set) Token: 0x0600C652 RID: 50770 RVA: 0x0031A0DA File Offset: 0x003182DA
		public unsafe static uint BOLTSPEED_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_BOLTSPEED_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_BOLTSPEED_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047EB RID: 18411
		// (get) Token: 0x0600C653 RID: 50771 RVA: 0x0031A0EC File Offset: 0x003182EC
		// (set) Token: 0x0600C654 RID: 50772 RVA: 0x0031A10A File Offset: 0x0031830A
		public unsafe static uint BULLETCRACK_SIDECHAIN_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_BULLETCRACK_SIDECHAIN_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_BULLETCRACK_SIDECHAIN_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047EC RID: 18412
		// (get) Token: 0x0600C655 RID: 50773 RVA: 0x0031A11C File Offset: 0x0031831C
		// (set) Token: 0x0600C656 RID: 50774 RVA: 0x0031A13A File Offset: 0x0031833A
		public unsafe static uint CUSTOMCONTENT_VOLUME_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_CUSTOMCONTENT_VOLUME_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_CUSTOMCONTENT_VOLUME_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047ED RID: 18413
		// (get) Token: 0x0600C657 RID: 50775 RVA: 0x0031A14C File Offset: 0x0031834C
		// (set) Token: 0x0600C658 RID: 50776 RVA: 0x0031A16A File Offset: 0x0031836A
		public unsafe static uint DISTANCE_BUILTIN
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BUILTIN, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BUILTIN, (void*)(&value));
			}
		}

		// Token: 0x170047EE RID: 18414
		// (get) Token: 0x0600C659 RID: 50777 RVA: 0x0031A17C File Offset: 0x0031837C
		// (set) Token: 0x0600C65A RID: 50778 RVA: 0x0031A19A File Offset: 0x0031839A
		public unsafe static uint DISTANCE_BULLETPASSBY_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BULLETPASSBY_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_DISTANCE_BULLETPASSBY_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047EF RID: 18415
		// (get) Token: 0x0600C65B RID: 50779 RVA: 0x0031A1AC File Offset: 0x003183AC
		// (set) Token: 0x0600C65C RID: 50780 RVA: 0x0031A1CA File Offset: 0x003183CA
		public unsafe static uint DOPPLER_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_DOPPLER_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_DOPPLER_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F0 RID: 18416
		// (get) Token: 0x0600C65D RID: 50781 RVA: 0x0031A1DC File Offset: 0x003183DC
		// (set) Token: 0x0600C65E RID: 50782 RVA: 0x0031A1FA File Offset: 0x003183FA
		public unsafe static uint DRONEACCELERATION_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_DRONEACCELERATION_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_DRONEACCELERATION_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F1 RID: 18417
		// (get) Token: 0x0600C65F RID: 50783 RVA: 0x0031A20C File Offset: 0x0031840C
		// (set) Token: 0x0600C660 RID: 50784 RVA: 0x0031A22A File Offset: 0x0031842A
		public unsafe static uint DRONESPEED_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_DRONESPEED_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_DRONESPEED_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F2 RID: 18418
		// (get) Token: 0x0600C661 RID: 50785 RVA: 0x0031A23C File Offset: 0x0031843C
		// (set) Token: 0x0600C662 RID: 50786 RVA: 0x0031A25A File Offset: 0x0031845A
		public unsafe static uint GRABVOLUMEMULTIPLIER_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_GRABVOLUMEMULTIPLIER_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_GRABVOLUMEMULTIPLIER_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F3 RID: 18419
		// (get) Token: 0x0600C663 RID: 50787 RVA: 0x0031A26C File Offset: 0x0031846C
		// (set) Token: 0x0600C664 RID: 50788 RVA: 0x0031A28A File Offset: 0x0031848A
		public unsafe static uint HDR_SIDECHAIN_3P_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_3P_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_3P_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F4 RID: 18420
		// (get) Token: 0x0600C665 RID: 50789 RVA: 0x0031A29C File Offset: 0x0031849C
		// (set) Token: 0x0600C666 RID: 50790 RVA: 0x0031A2BA File Offset: 0x003184BA
		public unsafe static uint HDR_SIDECHAIN_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_HDR_SIDECHAIN_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F5 RID: 18421
		// (get) Token: 0x0600C667 RID: 50791 RVA: 0x0031A2CC File Offset: 0x003184CC
		// (set) Token: 0x0600C668 RID: 50792 RVA: 0x0031A2EA File Offset: 0x003184EA
		public unsafe static uint HELI_SIDECHAIN_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_HELI_SIDECHAIN_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_HELI_SIDECHAIN_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F6 RID: 18422
		// (get) Token: 0x0600C669 RID: 50793 RVA: 0x0031A2FC File Offset: 0x003184FC
		// (set) Token: 0x0600C66A RID: 50794 RVA: 0x0031A31A File Offset: 0x0031851A
		public unsafe static uint OBSTRUCTION_3D_ENV_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_3D_ENV_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_3D_ENV_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F7 RID: 18423
		// (get) Token: 0x0600C66B RID: 50795 RVA: 0x0031A32C File Offset: 0x0031852C
		// (set) Token: 0x0600C66C RID: 50796 RVA: 0x0031A34A File Offset: 0x0031854A
		public unsafe static uint OBSTRUCTION_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_OBSTRUCTION_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F8 RID: 18424
		// (get) Token: 0x0600C66D RID: 50797 RVA: 0x0031A35C File Offset: 0x0031855C
		// (set) Token: 0x0600C66E RID: 50798 RVA: 0x0031A37A File Offset: 0x0031857A
		public unsafe static uint OUTDOORNESS_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_OUTDOORNESS_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_OUTDOORNESS_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047F9 RID: 18425
		// (get) Token: 0x0600C66F RID: 50799 RVA: 0x0031A38C File Offset: 0x0031858C
		// (set) Token: 0x0600C670 RID: 50800 RVA: 0x0031A3AA File Offset: 0x003185AA
		public unsafe static uint PLAYERARMMOVEMENT_L_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_L_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_L_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FA RID: 18426
		// (get) Token: 0x0600C671 RID: 50801 RVA: 0x0031A3BC File Offset: 0x003185BC
		// (set) Token: 0x0600C672 RID: 50802 RVA: 0x0031A3DA File Offset: 0x003185DA
		public unsafe static uint PLAYERARMMOVEMENT_R_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_R_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERARMMOVEMENT_R_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FB RID: 18427
		// (get) Token: 0x0600C673 RID: 50803 RVA: 0x0031A3EC File Offset: 0x003185EC
		// (set) Token: 0x0600C674 RID: 50804 RVA: 0x0031A40A File Offset: 0x0031860A
		public unsafe static uint PLAYERCROUCH_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERCROUCH_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERCROUCH_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FC RID: 18428
		// (get) Token: 0x0600C675 RID: 50805 RVA: 0x0031A41C File Offset: 0x0031861C
		// (set) Token: 0x0600C676 RID: 50806 RVA: 0x0031A43A File Offset: 0x0031863A
		public unsafe static uint PLAYERDEAF_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERDEAF_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERDEAF_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FD RID: 18429
		// (get) Token: 0x0600C677 RID: 50807 RVA: 0x0031A44C File Offset: 0x0031864C
		// (set) Token: 0x0600C678 RID: 50808 RVA: 0x0031A46A File Offset: 0x0031866A
		public unsafe static uint PLAYERHEALTH_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERHEALTH_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERHEALTH_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FE RID: 18430
		// (get) Token: 0x0600C679 RID: 50809 RVA: 0x0031A47C File Offset: 0x0031867C
		// (set) Token: 0x0600C67A RID: 50810 RVA: 0x0031A49A File Offset: 0x0031869A
		public unsafe static uint PLAYERMOVEMENT_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERMOVEMENT_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERMOVEMENT_RTPC, (void*)(&value));
			}
		}

		// Token: 0x170047FF RID: 18431
		// (get) Token: 0x0600C67B RID: 50811 RVA: 0x0031A4AC File Offset: 0x003186AC
		// (set) Token: 0x0600C67C RID: 50812 RVA: 0x0031A4CA File Offset: 0x003186CA
		public unsafe static uint PLAYEROUTDOORNESS_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYEROUTDOORNESS_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYEROUTDOORNESS_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004800 RID: 18432
		// (get) Token: 0x0600C67D RID: 50813 RVA: 0x0031A4DC File Offset: 0x003186DC
		// (set) Token: 0x0600C67E RID: 50814 RVA: 0x0031A4FA File Offset: 0x003186FA
		public unsafe static uint PLAYERSPEED_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERSPEED_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_PLAYERSPEED_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004801 RID: 18433
		// (get) Token: 0x0600C67F RID: 50815 RVA: 0x0031A50C File Offset: 0x0031870C
		// (set) Token: 0x0600C680 RID: 50816 RVA: 0x0031A52A File Offset: 0x0031872A
		public unsafe static uint RADIO_EFFECT_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_RADIO_EFFECT_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_RADIO_EFFECT_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004802 RID: 18434
		// (get) Token: 0x0600C681 RID: 50817 RVA: 0x0031A53C File Offset: 0x0031873C
		// (set) Token: 0x0600C682 RID: 50818 RVA: 0x0031A55A File Offset: 0x0031875A
		public unsafe static uint SIDECHAIN_EFFECTS_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_SIDECHAIN_EFFECTS_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_SIDECHAIN_EFFECTS_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004803 RID: 18435
		// (get) Token: 0x0600C683 RID: 50819 RVA: 0x0031A56C File Offset: 0x0031876C
		// (set) Token: 0x0600C684 RID: 50820 RVA: 0x0031A58A File Offset: 0x0031878A
		public unsafe static uint SP_3D_MIX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_SP_3D_MIX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_SP_3D_MIX, (void*)(&value));
			}
		}

		// Token: 0x17004804 RID: 18436
		// (get) Token: 0x0600C685 RID: 50821 RVA: 0x0031A59C File Offset: 0x0031879C
		// (set) Token: 0x0600C686 RID: 50822 RVA: 0x0031A5BA File Offset: 0x003187BA
		public unsafe static uint TEAMCHAT_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_TEAMCHAT_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_TEAMCHAT_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004805 RID: 18437
		// (get) Token: 0x0600C687 RID: 50823 RVA: 0x0031A5CC File Offset: 0x003187CC
		// (set) Token: 0x0600C688 RID: 50824 RVA: 0x0031A5EA File Offset: 0x003187EA
		public unsafe static uint THROWVOLUMEMULTIPLIER_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_THROWVOLUMEMULTIPLIER_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_THROWVOLUMEMULTIPLIER_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004806 RID: 18438
		// (get) Token: 0x0600C689 RID: 50825 RVA: 0x0031A5FC File Offset: 0x003187FC
		// (set) Token: 0x0600C68A RID: 50826 RVA: 0x0031A61A File Offset: 0x0031881A
		public unsafe static uint VEHICLEACCELERATION_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VEHICLEACCELERATION_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VEHICLEACCELERATION_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004807 RID: 18439
		// (get) Token: 0x0600C68B RID: 50827 RVA: 0x0031A62C File Offset: 0x0031882C
		// (set) Token: 0x0600C68C RID: 50828 RVA: 0x0031A64A File Offset: 0x0031884A
		public unsafe static uint VOIP_ENABLEATTENUATION_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_ENABLEATTENUATION_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_ENABLEATTENUATION_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004808 RID: 18440
		// (get) Token: 0x0600C68D RID: 50829 RVA: 0x0031A65C File Offset: 0x0031885C
		// (set) Token: 0x0600C68E RID: 50830 RVA: 0x0031A67A File Offset: 0x0031887A
		public unsafe static uint VOIP_METERING_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_METERING_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOIP_METERING_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004809 RID: 18441
		// (get) Token: 0x0600C68F RID: 50831 RVA: 0x0031A68C File Offset: 0x0031888C
		// (set) Token: 0x0600C690 RID: 50832 RVA: 0x0031A6AA File Offset: 0x003188AA
		public unsafe static uint VOLUME_MASTER
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MASTER, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MASTER, (void*)(&value));
			}
		}

		// Token: 0x1700480A RID: 18442
		// (get) Token: 0x0600C691 RID: 50833 RVA: 0x0031A6BC File Offset: 0x003188BC
		// (set) Token: 0x0600C692 RID: 50834 RVA: 0x0031A6DA File Offset: 0x003188DA
		public unsafe static uint VOLUME_MUSIC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MUSIC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_MUSIC, (void*)(&value));
			}
		}

		// Token: 0x1700480B RID: 18443
		// (get) Token: 0x0600C693 RID: 50835 RVA: 0x0031A6EC File Offset: 0x003188EC
		// (set) Token: 0x0600C694 RID: 50836 RVA: 0x0031A70A File Offset: 0x0031890A
		public unsafe static uint VOLUME_SFX_ALL
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_ALL, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_ALL, (void*)(&value));
			}
		}

		// Token: 0x1700480C RID: 18444
		// (get) Token: 0x0600C695 RID: 50837 RVA: 0x0031A71C File Offset: 0x0031891C
		// (set) Token: 0x0600C696 RID: 50838 RVA: 0x0031A73A File Offset: 0x0031893A
		public unsafe static uint VOLUME_SFX_AMBIENT
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_AMBIENT, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_AMBIENT, (void*)(&value));
			}
		}

		// Token: 0x1700480D RID: 18445
		// (get) Token: 0x0600C697 RID: 50839 RVA: 0x0031A74C File Offset: 0x0031894C
		// (set) Token: 0x0600C698 RID: 50840 RVA: 0x0031A76A File Offset: 0x0031896A
		public unsafe static uint VOLUME_SFX_GUNS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_GUNS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_GUNS, (void*)(&value));
			}
		}

		// Token: 0x1700480E RID: 18446
		// (get) Token: 0x0600C699 RID: 50841 RVA: 0x0031A77C File Offset: 0x0031897C
		// (set) Token: 0x0600C69A RID: 50842 RVA: 0x0031A79A File Offset: 0x0031899A
		public unsafe static uint VOLUME_SFX_REVERB
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_REVERB, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_SFX_REVERB, (void*)(&value));
			}
		}

		// Token: 0x1700480F RID: 18447
		// (get) Token: 0x0600C69B RID: 50843 RVA: 0x0031A7AC File Offset: 0x003189AC
		// (set) Token: 0x0600C69C RID: 50844 RVA: 0x0031A7CA File Offset: 0x003189CA
		public unsafe static uint VOLUME_VOIP
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_VOIP, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_VOLUME_VOIP, (void*)(&value));
			}
		}

		// Token: 0x17004810 RID: 18448
		// (get) Token: 0x0600C69D RID: 50845 RVA: 0x0031A7DC File Offset: 0x003189DC
		// (set) Token: 0x0600C69E RID: 50846 RVA: 0x0031A7FA File Offset: 0x003189FA
		public unsafe static uint WEAPON_1P_SIDECHAIN_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_1P_SIDECHAIN_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_1P_SIDECHAIN_RTPC, (void*)(&value));
			}
		}

		// Token: 0x17004811 RID: 18449
		// (get) Token: 0x0600C69F RID: 50847 RVA: 0x0031A80C File Offset: 0x00318A0C
		// (set) Token: 0x0600C6A0 RID: 50848 RVA: 0x0031A82A File Offset: 0x00318A2A
		public unsafe static uint WEAPON_BLEND_RTPC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_BLEND_RTPC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(GAME_PARAMETERS.NativeFieldInfoPtr_WEAPON_BLEND_RTPC, (void*)(&value));
			}
		}

		// Token: 0x04007DAB RID: 32171
		private static readonly IntPtr NativeFieldInfoPtr_BOLTSPEED_RTPC;

		// Token: 0x04007DAC RID: 32172
		private static readonly IntPtr NativeFieldInfoPtr_BULLETCRACK_SIDECHAIN_RTPC;

		// Token: 0x04007DAD RID: 32173
		private static readonly IntPtr NativeFieldInfoPtr_CUSTOMCONTENT_VOLUME_RTPC;

		// Token: 0x04007DAE RID: 32174
		private static readonly IntPtr NativeFieldInfoPtr_DISTANCE_BUILTIN;

		// Token: 0x04007DAF RID: 32175
		private static readonly IntPtr NativeFieldInfoPtr_DISTANCE_BULLETPASSBY_RTPC;

		// Token: 0x04007DB0 RID: 32176
		private static readonly IntPtr NativeFieldInfoPtr_DOPPLER_RTPC;

		// Token: 0x04007DB1 RID: 32177
		private static readonly IntPtr NativeFieldInfoPtr_DRONEACCELERATION_RTPC;

		// Token: 0x04007DB2 RID: 32178
		private static readonly IntPtr NativeFieldInfoPtr_DRONESPEED_RTPC;

		// Token: 0x04007DB3 RID: 32179
		private static readonly IntPtr NativeFieldInfoPtr_GRABVOLUMEMULTIPLIER_RTPC;

		// Token: 0x04007DB4 RID: 32180
		private static readonly IntPtr NativeFieldInfoPtr_HDR_SIDECHAIN_3P_RTPC;

		// Token: 0x04007DB5 RID: 32181
		private static readonly IntPtr NativeFieldInfoPtr_HDR_SIDECHAIN_RTPC;

		// Token: 0x04007DB6 RID: 32182
		private static readonly IntPtr NativeFieldInfoPtr_HELI_SIDECHAIN_RTPC;

		// Token: 0x04007DB7 RID: 32183
		private static readonly IntPtr NativeFieldInfoPtr_OBSTRUCTION_3D_ENV_RTPC;

		// Token: 0x04007DB8 RID: 32184
		private static readonly IntPtr NativeFieldInfoPtr_OBSTRUCTION_RTPC;

		// Token: 0x04007DB9 RID: 32185
		private static readonly IntPtr NativeFieldInfoPtr_OUTDOORNESS_RTPC;

		// Token: 0x04007DBA RID: 32186
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERARMMOVEMENT_L_RTPC;

		// Token: 0x04007DBB RID: 32187
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERARMMOVEMENT_R_RTPC;

		// Token: 0x04007DBC RID: 32188
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERCROUCH_RTPC;

		// Token: 0x04007DBD RID: 32189
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERDEAF_RTPC;

		// Token: 0x04007DBE RID: 32190
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERHEALTH_RTPC;

		// Token: 0x04007DBF RID: 32191
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERMOVEMENT_RTPC;

		// Token: 0x04007DC0 RID: 32192
		private static readonly IntPtr NativeFieldInfoPtr_PLAYEROUTDOORNESS_RTPC;

		// Token: 0x04007DC1 RID: 32193
		private static readonly IntPtr NativeFieldInfoPtr_PLAYERSPEED_RTPC;

		// Token: 0x04007DC2 RID: 32194
		private static readonly IntPtr NativeFieldInfoPtr_RADIO_EFFECT_RTPC;

		// Token: 0x04007DC3 RID: 32195
		private static readonly IntPtr NativeFieldInfoPtr_SIDECHAIN_EFFECTS_RTPC;

		// Token: 0x04007DC4 RID: 32196
		private static readonly IntPtr NativeFieldInfoPtr_SP_3D_MIX;

		// Token: 0x04007DC5 RID: 32197
		private static readonly IntPtr NativeFieldInfoPtr_TEAMCHAT_RTPC;

		// Token: 0x04007DC6 RID: 32198
		private static readonly IntPtr NativeFieldInfoPtr_THROWVOLUMEMULTIPLIER_RTPC;

		// Token: 0x04007DC7 RID: 32199
		private static readonly IntPtr NativeFieldInfoPtr_VEHICLEACCELERATION_RTPC;

		// Token: 0x04007DC8 RID: 32200
		private static readonly IntPtr NativeFieldInfoPtr_VOIP_ENABLEATTENUATION_RTPC;

		// Token: 0x04007DC9 RID: 32201
		private static readonly IntPtr NativeFieldInfoPtr_VOIP_METERING_RTPC;

		// Token: 0x04007DCA RID: 32202
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_MASTER;

		// Token: 0x04007DCB RID: 32203
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_MUSIC;

		// Token: 0x04007DCC RID: 32204
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_SFX_ALL;

		// Token: 0x04007DCD RID: 32205
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_SFX_AMBIENT;

		// Token: 0x04007DCE RID: 32206
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_SFX_GUNS;

		// Token: 0x04007DCF RID: 32207
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_SFX_REVERB;

		// Token: 0x04007DD0 RID: 32208
		private static readonly IntPtr NativeFieldInfoPtr_VOLUME_VOIP;

		// Token: 0x04007DD1 RID: 32209
		private static readonly IntPtr NativeFieldInfoPtr_WEAPON_1P_SIDECHAIN_RTPC;

		// Token: 0x04007DD2 RID: 32210
		private static readonly IntPtr NativeFieldInfoPtr_WEAPON_BLEND_RTPC;

		// Token: 0x04007DD3 RID: 32211
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
