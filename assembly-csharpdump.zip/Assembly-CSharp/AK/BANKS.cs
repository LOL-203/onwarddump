﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000935 RID: 2357
	public class BANKS : Object
	{
		// Token: 0x0600C6A1 RID: 50849 RVA: 0x0031A83C File Offset: 0x00318A3C
		[CallerCount(0)]
		public unsafe BANKS() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BANKS>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BANKS.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C6A2 RID: 50850 RVA: 0x0031A888 File Offset: 0x00318A88
		// Note: this type is marked as 'beforefieldinit'.
		static BANKS()
		{
			Il2CppClassPointerStore<BANKS>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "BANKS");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BANKS>.NativeClassPtr);
			BANKS.NativeFieldInfoPtr_INIT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "INIT");
			BANKS.NativeFieldInfoPtr_AMBIENCES = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "AMBIENCES");
			BANKS.NativeFieldInfoPtr_MAIN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "MAIN");
			BANKS.NativeFieldInfoPtr_MUSIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "MUSIC");
			BANKS.NativeFieldInfoPtr_STARTUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "STARTUP");
			BANKS.NativeFieldInfoPtr_VOIP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "VOIP");
			BANKS.NativeFieldInfoPtr_WEAPONFLAREGUN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONFLAREGUN");
			BANKS.NativeFieldInfoPtr_WEAPONLAUNCHERRPG7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONLAUNCHERRPG7");
			BANKS.NativeFieldInfoPtr_WEAPONLMGM240 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONLMGM240");
			BANKS.NativeFieldInfoPtr_WEAPONLMGM249 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONLMGM249");
			BANKS.NativeFieldInfoPtr_WEAPONLMGPKM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONLMGPKM");
			BANKS.NativeFieldInfoPtr_WEAPONLMGULTIMAX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONLMGULTIMAX");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOL57 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOL57");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOL1911 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOL1911");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOLG17 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOLG17");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOLM9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOLM9");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOLMAKAROV = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOLMAKAROV");
			BANKS.NativeFieldInfoPtr_WEAPONPISTOLTT30 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONPISTOLTT30");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLE552 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLE552");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK5C = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAK5C");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK12 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAK12");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK104 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAK104");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAKM");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKS74U = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAKS74U");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEASVAL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEASVAL");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEAUG = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEAUG");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEFAMAS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEFAMAS");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEG3A3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEG3A3");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEG36C = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEG36C");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEL86A2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEL86A2");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEM16A4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEM16A4");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEMCXRATTLER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEMCXRATTLER");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK16 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEMK16");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK17 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEMK17");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK18 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLEMK18");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLESKS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLESKS");
			BANKS.NativeFieldInfoPtr_WEAPONRIFLETAR21 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONRIFLETAR21");
			BANKS.NativeFieldInfoPtr_WEAPONSGENERIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSGENERIC");
			BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNM1014 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSHOTGUNM1014");
			BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNSPAS12 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSHOTGUNSPAS12");
			BANKS.NativeFieldInfoPtr_WEAPONSMGMP5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSMGMP5");
			BANKS.NativeFieldInfoPtr_WEAPONSMGMP7A2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSMGMP7A2");
			BANKS.NativeFieldInfoPtr_WEAPONSMGP90 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSMGP90");
			BANKS.NativeFieldInfoPtr_WEAPONSMGPSR2MP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSMGPSR2MP");
			BANKS.NativeFieldInfoPtr_WEAPONSNIPERM39EMR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSNIPERM39EMR");
			BANKS.NativeFieldInfoPtr_WEAPONSNIPERM40A5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSNIPERM40A5");
			BANKS.NativeFieldInfoPtr_WEAPONSNIPERSV98 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSNIPERSV98");
			BANKS.NativeFieldInfoPtr_WEAPONSNIPERSVD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BANKS>.NativeClassPtr, "WEAPONSNIPERSVD");
			BANKS.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BANKS>.NativeClassPtr, 100678758);
		}

		// Token: 0x0600C6A3 RID: 50851 RVA: 0x00002988 File Offset: 0x00000B88
		public BANKS(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004812 RID: 18450
		// (get) Token: 0x0600C6A4 RID: 50852 RVA: 0x0031AC8C File Offset: 0x00318E8C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BANKS>.NativeClassPtr));
			}
		}

		// Token: 0x17004813 RID: 18451
		// (get) Token: 0x0600C6A5 RID: 50853 RVA: 0x0031ACA0 File Offset: 0x00318EA0
		// (set) Token: 0x0600C6A6 RID: 50854 RVA: 0x0031ACBE File Offset: 0x00318EBE
		public unsafe static uint INIT
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_INIT, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_INIT, (void*)(&value));
			}
		}

		// Token: 0x17004814 RID: 18452
		// (get) Token: 0x0600C6A7 RID: 50855 RVA: 0x0031ACD0 File Offset: 0x00318ED0
		// (set) Token: 0x0600C6A8 RID: 50856 RVA: 0x0031ACEE File Offset: 0x00318EEE
		public unsafe static uint AMBIENCES
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_AMBIENCES, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_AMBIENCES, (void*)(&value));
			}
		}

		// Token: 0x17004815 RID: 18453
		// (get) Token: 0x0600C6A9 RID: 50857 RVA: 0x0031AD00 File Offset: 0x00318F00
		// (set) Token: 0x0600C6AA RID: 50858 RVA: 0x0031AD1E File Offset: 0x00318F1E
		public unsafe static uint MAIN
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_MAIN, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_MAIN, (void*)(&value));
			}
		}

		// Token: 0x17004816 RID: 18454
		// (get) Token: 0x0600C6AB RID: 50859 RVA: 0x0031AD30 File Offset: 0x00318F30
		// (set) Token: 0x0600C6AC RID: 50860 RVA: 0x0031AD4E File Offset: 0x00318F4E
		public unsafe static uint MUSIC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_MUSIC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_MUSIC, (void*)(&value));
			}
		}

		// Token: 0x17004817 RID: 18455
		// (get) Token: 0x0600C6AD RID: 50861 RVA: 0x0031AD60 File Offset: 0x00318F60
		// (set) Token: 0x0600C6AE RID: 50862 RVA: 0x0031AD7E File Offset: 0x00318F7E
		public unsafe static uint STARTUP
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_STARTUP, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_STARTUP, (void*)(&value));
			}
		}

		// Token: 0x17004818 RID: 18456
		// (get) Token: 0x0600C6AF RID: 50863 RVA: 0x0031AD90 File Offset: 0x00318F90
		// (set) Token: 0x0600C6B0 RID: 50864 RVA: 0x0031ADAE File Offset: 0x00318FAE
		public unsafe static uint VOIP
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_VOIP, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_VOIP, (void*)(&value));
			}
		}

		// Token: 0x17004819 RID: 18457
		// (get) Token: 0x0600C6B1 RID: 50865 RVA: 0x0031ADC0 File Offset: 0x00318FC0
		// (set) Token: 0x0600C6B2 RID: 50866 RVA: 0x0031ADDE File Offset: 0x00318FDE
		public unsafe static uint WEAPONFLAREGUN
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONFLAREGUN, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONFLAREGUN, (void*)(&value));
			}
		}

		// Token: 0x1700481A RID: 18458
		// (get) Token: 0x0600C6B3 RID: 50867 RVA: 0x0031ADF0 File Offset: 0x00318FF0
		// (set) Token: 0x0600C6B4 RID: 50868 RVA: 0x0031AE0E File Offset: 0x0031900E
		public unsafe static uint WEAPONLAUNCHERRPG7
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONLAUNCHERRPG7, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONLAUNCHERRPG7, (void*)(&value));
			}
		}

		// Token: 0x1700481B RID: 18459
		// (get) Token: 0x0600C6B5 RID: 50869 RVA: 0x0031AE20 File Offset: 0x00319020
		// (set) Token: 0x0600C6B6 RID: 50870 RVA: 0x0031AE3E File Offset: 0x0031903E
		public unsafe static uint WEAPONLMGM240
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONLMGM240, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONLMGM240, (void*)(&value));
			}
		}

		// Token: 0x1700481C RID: 18460
		// (get) Token: 0x0600C6B7 RID: 50871 RVA: 0x0031AE50 File Offset: 0x00319050
		// (set) Token: 0x0600C6B8 RID: 50872 RVA: 0x0031AE6E File Offset: 0x0031906E
		public unsafe static uint WEAPONLMGM249
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONLMGM249, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONLMGM249, (void*)(&value));
			}
		}

		// Token: 0x1700481D RID: 18461
		// (get) Token: 0x0600C6B9 RID: 50873 RVA: 0x0031AE80 File Offset: 0x00319080
		// (set) Token: 0x0600C6BA RID: 50874 RVA: 0x0031AE9E File Offset: 0x0031909E
		public unsafe static uint WEAPONLMGPKM
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONLMGPKM, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONLMGPKM, (void*)(&value));
			}
		}

		// Token: 0x1700481E RID: 18462
		// (get) Token: 0x0600C6BB RID: 50875 RVA: 0x0031AEB0 File Offset: 0x003190B0
		// (set) Token: 0x0600C6BC RID: 50876 RVA: 0x0031AECE File Offset: 0x003190CE
		public unsafe static uint WEAPONLMGULTIMAX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONLMGULTIMAX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONLMGULTIMAX, (void*)(&value));
			}
		}

		// Token: 0x1700481F RID: 18463
		// (get) Token: 0x0600C6BD RID: 50877 RVA: 0x0031AEE0 File Offset: 0x003190E0
		// (set) Token: 0x0600C6BE RID: 50878 RVA: 0x0031AEFE File Offset: 0x003190FE
		public unsafe static uint WEAPONPISTOL57
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOL57, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOL57, (void*)(&value));
			}
		}

		// Token: 0x17004820 RID: 18464
		// (get) Token: 0x0600C6BF RID: 50879 RVA: 0x0031AF10 File Offset: 0x00319110
		// (set) Token: 0x0600C6C0 RID: 50880 RVA: 0x0031AF2E File Offset: 0x0031912E
		public unsafe static uint WEAPONPISTOL1911
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOL1911, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOL1911, (void*)(&value));
			}
		}

		// Token: 0x17004821 RID: 18465
		// (get) Token: 0x0600C6C1 RID: 50881 RVA: 0x0031AF40 File Offset: 0x00319140
		// (set) Token: 0x0600C6C2 RID: 50882 RVA: 0x0031AF5E File Offset: 0x0031915E
		public unsafe static uint WEAPONPISTOLG17
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLG17, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLG17, (void*)(&value));
			}
		}

		// Token: 0x17004822 RID: 18466
		// (get) Token: 0x0600C6C3 RID: 50883 RVA: 0x0031AF70 File Offset: 0x00319170
		// (set) Token: 0x0600C6C4 RID: 50884 RVA: 0x0031AF8E File Offset: 0x0031918E
		public unsafe static uint WEAPONPISTOLM9
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLM9, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLM9, (void*)(&value));
			}
		}

		// Token: 0x17004823 RID: 18467
		// (get) Token: 0x0600C6C5 RID: 50885 RVA: 0x0031AFA0 File Offset: 0x003191A0
		// (set) Token: 0x0600C6C6 RID: 50886 RVA: 0x0031AFBE File Offset: 0x003191BE
		public unsafe static uint WEAPONPISTOLMAKAROV
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLMAKAROV, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLMAKAROV, (void*)(&value));
			}
		}

		// Token: 0x17004824 RID: 18468
		// (get) Token: 0x0600C6C7 RID: 50887 RVA: 0x0031AFD0 File Offset: 0x003191D0
		// (set) Token: 0x0600C6C8 RID: 50888 RVA: 0x0031AFEE File Offset: 0x003191EE
		public unsafe static uint WEAPONPISTOLTT30
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLTT30, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONPISTOLTT30, (void*)(&value));
			}
		}

		// Token: 0x17004825 RID: 18469
		// (get) Token: 0x0600C6C9 RID: 50889 RVA: 0x0031B000 File Offset: 0x00319200
		// (set) Token: 0x0600C6CA RID: 50890 RVA: 0x0031B01E File Offset: 0x0031921E
		public unsafe static uint WEAPONRIFLE552
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLE552, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLE552, (void*)(&value));
			}
		}

		// Token: 0x17004826 RID: 18470
		// (get) Token: 0x0600C6CB RID: 50891 RVA: 0x0031B030 File Offset: 0x00319230
		// (set) Token: 0x0600C6CC RID: 50892 RVA: 0x0031B04E File Offset: 0x0031924E
		public unsafe static uint WEAPONRIFLEAK5C
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK5C, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK5C, (void*)(&value));
			}
		}

		// Token: 0x17004827 RID: 18471
		// (get) Token: 0x0600C6CD RID: 50893 RVA: 0x0031B060 File Offset: 0x00319260
		// (set) Token: 0x0600C6CE RID: 50894 RVA: 0x0031B07E File Offset: 0x0031927E
		public unsafe static uint WEAPONRIFLEAK12
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK12, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK12, (void*)(&value));
			}
		}

		// Token: 0x17004828 RID: 18472
		// (get) Token: 0x0600C6CF RID: 50895 RVA: 0x0031B090 File Offset: 0x00319290
		// (set) Token: 0x0600C6D0 RID: 50896 RVA: 0x0031B0AE File Offset: 0x003192AE
		public unsafe static uint WEAPONRIFLEAK104
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK104, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAK104, (void*)(&value));
			}
		}

		// Token: 0x17004829 RID: 18473
		// (get) Token: 0x0600C6D1 RID: 50897 RVA: 0x0031B0C0 File Offset: 0x003192C0
		// (set) Token: 0x0600C6D2 RID: 50898 RVA: 0x0031B0DE File Offset: 0x003192DE
		public unsafe static uint WEAPONRIFLEAKM
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKM, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKM, (void*)(&value));
			}
		}

		// Token: 0x1700482A RID: 18474
		// (get) Token: 0x0600C6D3 RID: 50899 RVA: 0x0031B0F0 File Offset: 0x003192F0
		// (set) Token: 0x0600C6D4 RID: 50900 RVA: 0x0031B10E File Offset: 0x0031930E
		public unsafe static uint WEAPONRIFLEAKS74U
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKS74U, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAKS74U, (void*)(&value));
			}
		}

		// Token: 0x1700482B RID: 18475
		// (get) Token: 0x0600C6D5 RID: 50901 RVA: 0x0031B120 File Offset: 0x00319320
		// (set) Token: 0x0600C6D6 RID: 50902 RVA: 0x0031B13E File Offset: 0x0031933E
		public unsafe static uint WEAPONRIFLEASVAL
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEASVAL, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEASVAL, (void*)(&value));
			}
		}

		// Token: 0x1700482C RID: 18476
		// (get) Token: 0x0600C6D7 RID: 50903 RVA: 0x0031B150 File Offset: 0x00319350
		// (set) Token: 0x0600C6D8 RID: 50904 RVA: 0x0031B16E File Offset: 0x0031936E
		public unsafe static uint WEAPONRIFLEAUG
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAUG, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEAUG, (void*)(&value));
			}
		}

		// Token: 0x1700482D RID: 18477
		// (get) Token: 0x0600C6D9 RID: 50905 RVA: 0x0031B180 File Offset: 0x00319380
		// (set) Token: 0x0600C6DA RID: 50906 RVA: 0x0031B19E File Offset: 0x0031939E
		public unsafe static uint WEAPONRIFLEFAMAS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEFAMAS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEFAMAS, (void*)(&value));
			}
		}

		// Token: 0x1700482E RID: 18478
		// (get) Token: 0x0600C6DB RID: 50907 RVA: 0x0031B1B0 File Offset: 0x003193B0
		// (set) Token: 0x0600C6DC RID: 50908 RVA: 0x0031B1CE File Offset: 0x003193CE
		public unsafe static uint WEAPONRIFLEG3A3
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEG3A3, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEG3A3, (void*)(&value));
			}
		}

		// Token: 0x1700482F RID: 18479
		// (get) Token: 0x0600C6DD RID: 50909 RVA: 0x0031B1E0 File Offset: 0x003193E0
		// (set) Token: 0x0600C6DE RID: 50910 RVA: 0x0031B1FE File Offset: 0x003193FE
		public unsafe static uint WEAPONRIFLEG36C
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEG36C, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEG36C, (void*)(&value));
			}
		}

		// Token: 0x17004830 RID: 18480
		// (get) Token: 0x0600C6DF RID: 50911 RVA: 0x0031B210 File Offset: 0x00319410
		// (set) Token: 0x0600C6E0 RID: 50912 RVA: 0x0031B22E File Offset: 0x0031942E
		public unsafe static uint WEAPONRIFLEL86A2
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEL86A2, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEL86A2, (void*)(&value));
			}
		}

		// Token: 0x17004831 RID: 18481
		// (get) Token: 0x0600C6E1 RID: 50913 RVA: 0x0031B240 File Offset: 0x00319440
		// (set) Token: 0x0600C6E2 RID: 50914 RVA: 0x0031B25E File Offset: 0x0031945E
		public unsafe static uint WEAPONRIFLEM16A4
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEM16A4, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEM16A4, (void*)(&value));
			}
		}

		// Token: 0x17004832 RID: 18482
		// (get) Token: 0x0600C6E3 RID: 50915 RVA: 0x0031B270 File Offset: 0x00319470
		// (set) Token: 0x0600C6E4 RID: 50916 RVA: 0x0031B28E File Offset: 0x0031948E
		public unsafe static uint WEAPONRIFLEMCXRATTLER
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMCXRATTLER, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMCXRATTLER, (void*)(&value));
			}
		}

		// Token: 0x17004833 RID: 18483
		// (get) Token: 0x0600C6E5 RID: 50917 RVA: 0x0031B2A0 File Offset: 0x003194A0
		// (set) Token: 0x0600C6E6 RID: 50918 RVA: 0x0031B2BE File Offset: 0x003194BE
		public unsafe static uint WEAPONRIFLEMK16
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK16, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK16, (void*)(&value));
			}
		}

		// Token: 0x17004834 RID: 18484
		// (get) Token: 0x0600C6E7 RID: 50919 RVA: 0x0031B2D0 File Offset: 0x003194D0
		// (set) Token: 0x0600C6E8 RID: 50920 RVA: 0x0031B2EE File Offset: 0x003194EE
		public unsafe static uint WEAPONRIFLEMK17
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK17, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK17, (void*)(&value));
			}
		}

		// Token: 0x17004835 RID: 18485
		// (get) Token: 0x0600C6E9 RID: 50921 RVA: 0x0031B300 File Offset: 0x00319500
		// (set) Token: 0x0600C6EA RID: 50922 RVA: 0x0031B31E File Offset: 0x0031951E
		public unsafe static uint WEAPONRIFLEMK18
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK18, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLEMK18, (void*)(&value));
			}
		}

		// Token: 0x17004836 RID: 18486
		// (get) Token: 0x0600C6EB RID: 50923 RVA: 0x0031B330 File Offset: 0x00319530
		// (set) Token: 0x0600C6EC RID: 50924 RVA: 0x0031B34E File Offset: 0x0031954E
		public unsafe static uint WEAPONRIFLESKS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLESKS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLESKS, (void*)(&value));
			}
		}

		// Token: 0x17004837 RID: 18487
		// (get) Token: 0x0600C6ED RID: 50925 RVA: 0x0031B360 File Offset: 0x00319560
		// (set) Token: 0x0600C6EE RID: 50926 RVA: 0x0031B37E File Offset: 0x0031957E
		public unsafe static uint WEAPONRIFLETAR21
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLETAR21, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONRIFLETAR21, (void*)(&value));
			}
		}

		// Token: 0x17004838 RID: 18488
		// (get) Token: 0x0600C6EF RID: 50927 RVA: 0x0031B390 File Offset: 0x00319590
		// (set) Token: 0x0600C6F0 RID: 50928 RVA: 0x0031B3AE File Offset: 0x003195AE
		public unsafe static uint WEAPONSGENERIC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSGENERIC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSGENERIC, (void*)(&value));
			}
		}

		// Token: 0x17004839 RID: 18489
		// (get) Token: 0x0600C6F1 RID: 50929 RVA: 0x0031B3C0 File Offset: 0x003195C0
		// (set) Token: 0x0600C6F2 RID: 50930 RVA: 0x0031B3DE File Offset: 0x003195DE
		public unsafe static uint WEAPONSHOTGUNM1014
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNM1014, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNM1014, (void*)(&value));
			}
		}

		// Token: 0x1700483A RID: 18490
		// (get) Token: 0x0600C6F3 RID: 50931 RVA: 0x0031B3F0 File Offset: 0x003195F0
		// (set) Token: 0x0600C6F4 RID: 50932 RVA: 0x0031B40E File Offset: 0x0031960E
		public unsafe static uint WEAPONSHOTGUNSPAS12
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNSPAS12, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSHOTGUNSPAS12, (void*)(&value));
			}
		}

		// Token: 0x1700483B RID: 18491
		// (get) Token: 0x0600C6F5 RID: 50933 RVA: 0x0031B420 File Offset: 0x00319620
		// (set) Token: 0x0600C6F6 RID: 50934 RVA: 0x0031B43E File Offset: 0x0031963E
		public unsafe static uint WEAPONSMGMP5
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSMGMP5, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSMGMP5, (void*)(&value));
			}
		}

		// Token: 0x1700483C RID: 18492
		// (get) Token: 0x0600C6F7 RID: 50935 RVA: 0x0031B450 File Offset: 0x00319650
		// (set) Token: 0x0600C6F8 RID: 50936 RVA: 0x0031B46E File Offset: 0x0031966E
		public unsafe static uint WEAPONSMGMP7A2
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSMGMP7A2, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSMGMP7A2, (void*)(&value));
			}
		}

		// Token: 0x1700483D RID: 18493
		// (get) Token: 0x0600C6F9 RID: 50937 RVA: 0x0031B480 File Offset: 0x00319680
		// (set) Token: 0x0600C6FA RID: 50938 RVA: 0x0031B49E File Offset: 0x0031969E
		public unsafe static uint WEAPONSMGP90
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSMGP90, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSMGP90, (void*)(&value));
			}
		}

		// Token: 0x1700483E RID: 18494
		// (get) Token: 0x0600C6FB RID: 50939 RVA: 0x0031B4B0 File Offset: 0x003196B0
		// (set) Token: 0x0600C6FC RID: 50940 RVA: 0x0031B4CE File Offset: 0x003196CE
		public unsafe static uint WEAPONSMGPSR2MP
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSMGPSR2MP, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSMGPSR2MP, (void*)(&value));
			}
		}

		// Token: 0x1700483F RID: 18495
		// (get) Token: 0x0600C6FD RID: 50941 RVA: 0x0031B4E0 File Offset: 0x003196E0
		// (set) Token: 0x0600C6FE RID: 50942 RVA: 0x0031B4FE File Offset: 0x003196FE
		public unsafe static uint WEAPONSNIPERM39EMR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERM39EMR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERM39EMR, (void*)(&value));
			}
		}

		// Token: 0x17004840 RID: 18496
		// (get) Token: 0x0600C6FF RID: 50943 RVA: 0x0031B510 File Offset: 0x00319710
		// (set) Token: 0x0600C700 RID: 50944 RVA: 0x0031B52E File Offset: 0x0031972E
		public unsafe static uint WEAPONSNIPERM40A5
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERM40A5, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERM40A5, (void*)(&value));
			}
		}

		// Token: 0x17004841 RID: 18497
		// (get) Token: 0x0600C701 RID: 50945 RVA: 0x0031B540 File Offset: 0x00319740
		// (set) Token: 0x0600C702 RID: 50946 RVA: 0x0031B55E File Offset: 0x0031975E
		public unsafe static uint WEAPONSNIPERSV98
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERSV98, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERSV98, (void*)(&value));
			}
		}

		// Token: 0x17004842 RID: 18498
		// (get) Token: 0x0600C703 RID: 50947 RVA: 0x0031B570 File Offset: 0x00319770
		// (set) Token: 0x0600C704 RID: 50948 RVA: 0x0031B58E File Offset: 0x0031978E
		public unsafe static uint WEAPONSNIPERSVD
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERSVD, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BANKS.NativeFieldInfoPtr_WEAPONSNIPERSVD, (void*)(&value));
			}
		}

		// Token: 0x04007DD4 RID: 32212
		private static readonly IntPtr NativeFieldInfoPtr_INIT;

		// Token: 0x04007DD5 RID: 32213
		private static readonly IntPtr NativeFieldInfoPtr_AMBIENCES;

		// Token: 0x04007DD6 RID: 32214
		private static readonly IntPtr NativeFieldInfoPtr_MAIN;

		// Token: 0x04007DD7 RID: 32215
		private static readonly IntPtr NativeFieldInfoPtr_MUSIC;

		// Token: 0x04007DD8 RID: 32216
		private static readonly IntPtr NativeFieldInfoPtr_STARTUP;

		// Token: 0x04007DD9 RID: 32217
		private static readonly IntPtr NativeFieldInfoPtr_VOIP;

		// Token: 0x04007DDA RID: 32218
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONFLAREGUN;

		// Token: 0x04007DDB RID: 32219
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONLAUNCHERRPG7;

		// Token: 0x04007DDC RID: 32220
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONLMGM240;

		// Token: 0x04007DDD RID: 32221
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONLMGM249;

		// Token: 0x04007DDE RID: 32222
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONLMGPKM;

		// Token: 0x04007DDF RID: 32223
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONLMGULTIMAX;

		// Token: 0x04007DE0 RID: 32224
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOL57;

		// Token: 0x04007DE1 RID: 32225
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOL1911;

		// Token: 0x04007DE2 RID: 32226
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOLG17;

		// Token: 0x04007DE3 RID: 32227
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOLM9;

		// Token: 0x04007DE4 RID: 32228
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOLMAKAROV;

		// Token: 0x04007DE5 RID: 32229
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONPISTOLTT30;

		// Token: 0x04007DE6 RID: 32230
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLE552;

		// Token: 0x04007DE7 RID: 32231
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAK5C;

		// Token: 0x04007DE8 RID: 32232
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAK12;

		// Token: 0x04007DE9 RID: 32233
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAK104;

		// Token: 0x04007DEA RID: 32234
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAKM;

		// Token: 0x04007DEB RID: 32235
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAKS74U;

		// Token: 0x04007DEC RID: 32236
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEASVAL;

		// Token: 0x04007DED RID: 32237
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEAUG;

		// Token: 0x04007DEE RID: 32238
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEFAMAS;

		// Token: 0x04007DEF RID: 32239
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEG3A3;

		// Token: 0x04007DF0 RID: 32240
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEG36C;

		// Token: 0x04007DF1 RID: 32241
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEL86A2;

		// Token: 0x04007DF2 RID: 32242
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEM16A4;

		// Token: 0x04007DF3 RID: 32243
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEMCXRATTLER;

		// Token: 0x04007DF4 RID: 32244
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEMK16;

		// Token: 0x04007DF5 RID: 32245
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEMK17;

		// Token: 0x04007DF6 RID: 32246
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLEMK18;

		// Token: 0x04007DF7 RID: 32247
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLESKS;

		// Token: 0x04007DF8 RID: 32248
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONRIFLETAR21;

		// Token: 0x04007DF9 RID: 32249
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSGENERIC;

		// Token: 0x04007DFA RID: 32250
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSHOTGUNM1014;

		// Token: 0x04007DFB RID: 32251
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSHOTGUNSPAS12;

		// Token: 0x04007DFC RID: 32252
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSMGMP5;

		// Token: 0x04007DFD RID: 32253
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSMGMP7A2;

		// Token: 0x04007DFE RID: 32254
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSMGP90;

		// Token: 0x04007DFF RID: 32255
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSMGPSR2MP;

		// Token: 0x04007E00 RID: 32256
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSNIPERM39EMR;

		// Token: 0x04007E01 RID: 32257
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSNIPERM40A5;

		// Token: 0x04007E02 RID: 32258
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSNIPERSV98;

		// Token: 0x04007E03 RID: 32259
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONSNIPERSVD;

		// Token: 0x04007E04 RID: 32260
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
