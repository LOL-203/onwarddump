﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x0200090C RID: 2316
	public class STATES : Object
	{
		// Token: 0x0600C4A7 RID: 50343 RVA: 0x003161D4 File Offset: 0x003143D4
		[CallerCount(0)]
		public unsafe STATES() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C4A8 RID: 50344 RVA: 0x0031621F File Offset: 0x0031441F
		// Note: this type is marked as 'beforefieldinit'.
		static STATES()
		{
			Il2CppClassPointerStore<STATES>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "STATES");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES>.NativeClassPtr);
			STATES.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES>.NativeClassPtr, 100678678);
		}

		// Token: 0x0600C4A9 RID: 50345 RVA: 0x00002988 File Offset: 0x00000B88
		public STATES(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700473E RID: 18238
		// (get) Token: 0x0600C4AA RID: 50346 RVA: 0x00316258 File Offset: 0x00314458
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES>.NativeClassPtr));
			}
		}

		// Token: 0x04007D00 RID: 32000
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200090D RID: 2317
		public class AMBIENCE : Object
		{
			// Token: 0x0600C4AB RID: 50347 RVA: 0x0031626C File Offset: 0x0031446C
			[CallerCount(0)]
			public unsafe AMBIENCE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.AMBIENCE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4AC RID: 50348 RVA: 0x003162B8 File Offset: 0x003144B8
			// Note: this type is marked as 'beforefieldinit'.
			static AMBIENCE()
			{
				Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "AMBIENCE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr);
				STATES.AMBIENCE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr, "GROUP");
				STATES.AMBIENCE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr, 100678679);
			}

			// Token: 0x0600C4AD RID: 50349 RVA: 0x00002988 File Offset: 0x00000B88
			public AMBIENCE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700473F RID: 18239
			// (get) Token: 0x0600C4AE RID: 50350 RVA: 0x0031630B File Offset: 0x0031450B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr));
				}
			}

			// Token: 0x17004740 RID: 18240
			// (get) Token: 0x0600C4AF RID: 50351 RVA: 0x0031631C File Offset: 0x0031451C
			// (set) Token: 0x0600C4B0 RID: 50352 RVA: 0x0031633A File Offset: 0x0031453A
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.AMBIENCE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.AMBIENCE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D01 RID: 32001
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D02 RID: 32002
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200090E RID: 2318
			public class STATE : Object
			{
				// Token: 0x0600C4B1 RID: 50353 RVA: 0x0031634C File Offset: 0x0031454C
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.AMBIENCE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C4B2 RID: 50354 RVA: 0x00316398 File Offset: 0x00314598
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.AMBIENCE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr);
					STATES.AMBIENCE.STATE.NativeFieldInfoPtr_DEFAULT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr, "DEFAULT");
					STATES.AMBIENCE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr, "NONE");
					STATES.AMBIENCE.STATE.NativeFieldInfoPtr_TENT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr, "TENT");
					STATES.AMBIENCE.STATE.NativeFieldInfoPtr_UNDERGROUND = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr, "UNDERGROUND");
					STATES.AMBIENCE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr, 100678681);
				}

				// Token: 0x0600C4B3 RID: 50355 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004741 RID: 18241
				// (get) Token: 0x0600C4B4 RID: 50356 RVA: 0x00316427 File Offset: 0x00314627
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.AMBIENCE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004742 RID: 18242
				// (get) Token: 0x0600C4B5 RID: 50357 RVA: 0x00316438 File Offset: 0x00314638
				// (set) Token: 0x0600C4B6 RID: 50358 RVA: 0x00316456 File Offset: 0x00314656
				public unsafe static uint DEFAULT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_DEFAULT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_DEFAULT, (void*)(&value));
					}
				}

				// Token: 0x17004743 RID: 18243
				// (get) Token: 0x0600C4B7 RID: 50359 RVA: 0x00316468 File Offset: 0x00314668
				// (set) Token: 0x0600C4B8 RID: 50360 RVA: 0x00316486 File Offset: 0x00314686
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x17004744 RID: 18244
				// (get) Token: 0x0600C4B9 RID: 50361 RVA: 0x00316498 File Offset: 0x00314698
				// (set) Token: 0x0600C4BA RID: 50362 RVA: 0x003164B6 File Offset: 0x003146B6
				public unsafe static uint TENT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_TENT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_TENT, (void*)(&value));
					}
				}

				// Token: 0x17004745 RID: 18245
				// (get) Token: 0x0600C4BB RID: 50363 RVA: 0x003164C8 File Offset: 0x003146C8
				// (set) Token: 0x0600C4BC RID: 50364 RVA: 0x003164E6 File Offset: 0x003146E6
				public unsafe static uint UNDERGROUND
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_UNDERGROUND, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.AMBIENCE.STATE.NativeFieldInfoPtr_UNDERGROUND, (void*)(&value));
					}
				}

				// Token: 0x04007D03 RID: 32003
				private static readonly IntPtr NativeFieldInfoPtr_DEFAULT;

				// Token: 0x04007D04 RID: 32004
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D05 RID: 32005
				private static readonly IntPtr NativeFieldInfoPtr_TENT;

				// Token: 0x04007D06 RID: 32006
				private static readonly IntPtr NativeFieldInfoPtr_UNDERGROUND;

				// Token: 0x04007D07 RID: 32007
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200090F RID: 2319
		public class BUS_REFLECTIVE_INDOOR_LARGE_ENABLE : Object
		{
			// Token: 0x0600C4BD RID: 50365 RVA: 0x003164F8 File Offset: 0x003146F8
			[CallerCount(0)]
			public unsafe BUS_REFLECTIVE_INDOOR_LARGE_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4BE RID: 50366 RVA: 0x00316544 File Offset: 0x00314744
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_REFLECTIVE_INDOOR_LARGE_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_REFLECTIVE_INDOOR_LARGE_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr);
				STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr, 100678683);
			}

			// Token: 0x0600C4BF RID: 50367 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_REFLECTIVE_INDOOR_LARGE_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004746 RID: 18246
			// (get) Token: 0x0600C4C0 RID: 50368 RVA: 0x00316597 File Offset: 0x00314797
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x17004747 RID: 18247
			// (get) Token: 0x0600C4C1 RID: 50369 RVA: 0x003165A8 File Offset: 0x003147A8
			// (set) Token: 0x0600C4C2 RID: 50370 RVA: 0x003165C6 File Offset: 0x003147C6
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D08 RID: 32008
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D09 RID: 32009
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000910 RID: 2320
			public class STATE : Object
			{
				// Token: 0x0600C4C3 RID: 50371 RVA: 0x003165D8 File Offset: 0x003147D8
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C4C4 RID: 50372 RVA: 0x00316624 File Offset: 0x00314824
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, 100678685);
				}

				// Token: 0x0600C4C5 RID: 50373 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004748 RID: 18248
				// (get) Token: 0x0600C4C6 RID: 50374 RVA: 0x0031669F File Offset: 0x0031489F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004749 RID: 18249
				// (get) Token: 0x0600C4C7 RID: 50375 RVA: 0x003166B0 File Offset: 0x003148B0
				// (set) Token: 0x0600C4C8 RID: 50376 RVA: 0x003166CE File Offset: 0x003148CE
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x1700474A RID: 18250
				// (get) Token: 0x0600C4C9 RID: 50377 RVA: 0x003166E0 File Offset: 0x003148E0
				// (set) Token: 0x0600C4CA RID: 50378 RVA: 0x003166FE File Offset: 0x003148FE
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x1700474B RID: 18251
				// (get) Token: 0x0600C4CB RID: 50379 RVA: 0x00316710 File Offset: 0x00314910
				// (set) Token: 0x0600C4CC RID: 50380 RVA: 0x0031672E File Offset: 0x0031492E
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D0A RID: 32010
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D0B RID: 32011
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D0C RID: 32012
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D0D RID: 32013
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000911 RID: 2321
		public class BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE : Object
		{
			// Token: 0x0600C4CD RID: 50381 RVA: 0x00316740 File Offset: 0x00314940
			[CallerCount(0)]
			public unsafe BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4CE RID: 50382 RVA: 0x0031678C File Offset: 0x0031498C
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr);
				STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, 100678687);
			}

			// Token: 0x0600C4CF RID: 50383 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700474C RID: 18252
			// (get) Token: 0x0600C4D0 RID: 50384 RVA: 0x003167DF File Offset: 0x003149DF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x1700474D RID: 18253
			// (get) Token: 0x0600C4D1 RID: 50385 RVA: 0x003167F0 File Offset: 0x003149F0
			// (set) Token: 0x0600C4D2 RID: 50386 RVA: 0x0031680E File Offset: 0x00314A0E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D0E RID: 32014
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D0F RID: 32015
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000912 RID: 2322
			public class STATE : Object
			{
				// Token: 0x0600C4D3 RID: 50387 RVA: 0x00316820 File Offset: 0x00314A20
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C4D4 RID: 50388 RVA: 0x0031686C File Offset: 0x00314A6C
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, 100678689);
				}

				// Token: 0x0600C4D5 RID: 50389 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x1700474E RID: 18254
				// (get) Token: 0x0600C4D6 RID: 50390 RVA: 0x003168E7 File Offset: 0x00314AE7
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x1700474F RID: 18255
				// (get) Token: 0x0600C4D7 RID: 50391 RVA: 0x003168F8 File Offset: 0x00314AF8
				// (set) Token: 0x0600C4D8 RID: 50392 RVA: 0x00316916 File Offset: 0x00314B16
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x17004750 RID: 18256
				// (get) Token: 0x0600C4D9 RID: 50393 RVA: 0x00316928 File Offset: 0x00314B28
				// (set) Token: 0x0600C4DA RID: 50394 RVA: 0x00316946 File Offset: 0x00314B46
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x17004751 RID: 18257
				// (get) Token: 0x0600C4DB RID: 50395 RVA: 0x00316958 File Offset: 0x00314B58
				// (set) Token: 0x0600C4DC RID: 50396 RVA: 0x00316976 File Offset: 0x00314B76
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D10 RID: 32016
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D11 RID: 32017
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D12 RID: 32018
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D13 RID: 32019
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000913 RID: 2323
		public class BUS_REFLECTIVE_INDOOR_SMALL_ENABLE : Object
		{
			// Token: 0x0600C4DD RID: 50397 RVA: 0x00316988 File Offset: 0x00314B88
			[CallerCount(0)]
			public unsafe BUS_REFLECTIVE_INDOOR_SMALL_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4DE RID: 50398 RVA: 0x003169D4 File Offset: 0x00314BD4
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_REFLECTIVE_INDOOR_SMALL_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_REFLECTIVE_INDOOR_SMALL_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr);
				STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr, 100678691);
			}

			// Token: 0x0600C4DF RID: 50399 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_REFLECTIVE_INDOOR_SMALL_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004752 RID: 18258
			// (get) Token: 0x0600C4E0 RID: 50400 RVA: 0x00316A27 File Offset: 0x00314C27
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x17004753 RID: 18259
			// (get) Token: 0x0600C4E1 RID: 50401 RVA: 0x00316A38 File Offset: 0x00314C38
			// (set) Token: 0x0600C4E2 RID: 50402 RVA: 0x00316A56 File Offset: 0x00314C56
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D14 RID: 32020
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D15 RID: 32021
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000914 RID: 2324
			public class STATE : Object
			{
				// Token: 0x0600C4E3 RID: 50403 RVA: 0x00316A68 File Offset: 0x00314C68
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C4E4 RID: 50404 RVA: 0x00316AB4 File Offset: 0x00314CB4
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, 100678693);
				}

				// Token: 0x0600C4E5 RID: 50405 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004754 RID: 18260
				// (get) Token: 0x0600C4E6 RID: 50406 RVA: 0x00316B2F File Offset: 0x00314D2F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004755 RID: 18261
				// (get) Token: 0x0600C4E7 RID: 50407 RVA: 0x00316B40 File Offset: 0x00314D40
				// (set) Token: 0x0600C4E8 RID: 50408 RVA: 0x00316B5E File Offset: 0x00314D5E
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x17004756 RID: 18262
				// (get) Token: 0x0600C4E9 RID: 50409 RVA: 0x00316B70 File Offset: 0x00314D70
				// (set) Token: 0x0600C4EA RID: 50410 RVA: 0x00316B8E File Offset: 0x00314D8E
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x17004757 RID: 18263
				// (get) Token: 0x0600C4EB RID: 50411 RVA: 0x00316BA0 File Offset: 0x00314DA0
				// (set) Token: 0x0600C4EC RID: 50412 RVA: 0x00316BBE File Offset: 0x00314DBE
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D16 RID: 32022
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D17 RID: 32023
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D18 RID: 32024
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D19 RID: 32025
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000915 RID: 2325
		public class BUS_REFLECTIVE_OUTDOOR_ENABLE : Object
		{
			// Token: 0x0600C4ED RID: 50413 RVA: 0x00316BD0 File Offset: 0x00314DD0
			[CallerCount(0)]
			public unsafe BUS_REFLECTIVE_OUTDOOR_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4EE RID: 50414 RVA: 0x00316C1C File Offset: 0x00314E1C
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_REFLECTIVE_OUTDOOR_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_REFLECTIVE_OUTDOOR_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr);
				STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr, 100678695);
			}

			// Token: 0x0600C4EF RID: 50415 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_REFLECTIVE_OUTDOOR_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004758 RID: 18264
			// (get) Token: 0x0600C4F0 RID: 50416 RVA: 0x00316C6F File Offset: 0x00314E6F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x17004759 RID: 18265
			// (get) Token: 0x0600C4F1 RID: 50417 RVA: 0x00316C80 File Offset: 0x00314E80
			// (set) Token: 0x0600C4F2 RID: 50418 RVA: 0x00316C9E File Offset: 0x00314E9E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D1A RID: 32026
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D1B RID: 32027
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000916 RID: 2326
			public class STATE : Object
			{
				// Token: 0x0600C4F3 RID: 50419 RVA: 0x00316CB0 File Offset: 0x00314EB0
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C4F4 RID: 50420 RVA: 0x00316CFC File Offset: 0x00314EFC
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr, 100678697);
				}

				// Token: 0x0600C4F5 RID: 50421 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x1700475A RID: 18266
				// (get) Token: 0x0600C4F6 RID: 50422 RVA: 0x00316D77 File Offset: 0x00314F77
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x1700475B RID: 18267
				// (get) Token: 0x0600C4F7 RID: 50423 RVA: 0x00316D88 File Offset: 0x00314F88
				// (set) Token: 0x0600C4F8 RID: 50424 RVA: 0x00316DA6 File Offset: 0x00314FA6
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x1700475C RID: 18268
				// (get) Token: 0x0600C4F9 RID: 50425 RVA: 0x00316DB8 File Offset: 0x00314FB8
				// (set) Token: 0x0600C4FA RID: 50426 RVA: 0x00316DD6 File Offset: 0x00314FD6
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x1700475D RID: 18269
				// (get) Token: 0x0600C4FB RID: 50427 RVA: 0x00316DE8 File Offset: 0x00314FE8
				// (set) Token: 0x0600C4FC RID: 50428 RVA: 0x00316E06 File Offset: 0x00315006
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_REFLECTIVE_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D1C RID: 32028
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D1D RID: 32029
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D1E RID: 32030
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D1F RID: 32031
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000917 RID: 2327
		public class BUS_SMOOTH_INDOOR_LARGE_ENABLE : Object
		{
			// Token: 0x0600C4FD RID: 50429 RVA: 0x00316E18 File Offset: 0x00315018
			[CallerCount(0)]
			public unsafe BUS_SMOOTH_INDOOR_LARGE_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C4FE RID: 50430 RVA: 0x00316E64 File Offset: 0x00315064
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_SMOOTH_INDOOR_LARGE_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_SMOOTH_INDOOR_LARGE_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr);
				STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr, 100678699);
			}

			// Token: 0x0600C4FF RID: 50431 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_SMOOTH_INDOOR_LARGE_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700475E RID: 18270
			// (get) Token: 0x0600C500 RID: 50432 RVA: 0x00316EB7 File Offset: 0x003150B7
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x1700475F RID: 18271
			// (get) Token: 0x0600C501 RID: 50433 RVA: 0x00316EC8 File Offset: 0x003150C8
			// (set) Token: 0x0600C502 RID: 50434 RVA: 0x00316EE6 File Offset: 0x003150E6
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D20 RID: 32032
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D21 RID: 32033
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000918 RID: 2328
			public class STATE : Object
			{
				// Token: 0x0600C503 RID: 50435 RVA: 0x00316EF8 File Offset: 0x003150F8
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C504 RID: 50436 RVA: 0x00316F44 File Offset: 0x00315144
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr, 100678701);
				}

				// Token: 0x0600C505 RID: 50437 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004760 RID: 18272
				// (get) Token: 0x0600C506 RID: 50438 RVA: 0x00316FBF File Offset: 0x003151BF
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004761 RID: 18273
				// (get) Token: 0x0600C507 RID: 50439 RVA: 0x00316FD0 File Offset: 0x003151D0
				// (set) Token: 0x0600C508 RID: 50440 RVA: 0x00316FEE File Offset: 0x003151EE
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x17004762 RID: 18274
				// (get) Token: 0x0600C509 RID: 50441 RVA: 0x00317000 File Offset: 0x00315200
				// (set) Token: 0x0600C50A RID: 50442 RVA: 0x0031701E File Offset: 0x0031521E
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x17004763 RID: 18275
				// (get) Token: 0x0600C50B RID: 50443 RVA: 0x00317030 File Offset: 0x00315230
				// (set) Token: 0x0600C50C RID: 50444 RVA: 0x0031704E File Offset: 0x0031524E
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_LARGE_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D22 RID: 32034
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D23 RID: 32035
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D24 RID: 32036
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D25 RID: 32037
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000919 RID: 2329
		public class BUS_SMOOTH_INDOOR_MEDIUM_ENABLE : Object
		{
			// Token: 0x0600C50D RID: 50445 RVA: 0x00317060 File Offset: 0x00315260
			[CallerCount(0)]
			public unsafe BUS_SMOOTH_INDOOR_MEDIUM_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C50E RID: 50446 RVA: 0x003170AC File Offset: 0x003152AC
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_SMOOTH_INDOOR_MEDIUM_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_SMOOTH_INDOOR_MEDIUM_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr);
				STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, 100678703);
			}

			// Token: 0x0600C50F RID: 50447 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_SMOOTH_INDOOR_MEDIUM_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004764 RID: 18276
			// (get) Token: 0x0600C510 RID: 50448 RVA: 0x003170FF File Offset: 0x003152FF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x17004765 RID: 18277
			// (get) Token: 0x0600C511 RID: 50449 RVA: 0x00317110 File Offset: 0x00315310
			// (set) Token: 0x0600C512 RID: 50450 RVA: 0x0031712E File Offset: 0x0031532E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D26 RID: 32038
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D27 RID: 32039
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200091A RID: 2330
			public class STATE : Object
			{
				// Token: 0x0600C513 RID: 50451 RVA: 0x00317140 File Offset: 0x00315340
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C514 RID: 50452 RVA: 0x0031718C File Offset: 0x0031538C
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr, 100678705);
				}

				// Token: 0x0600C515 RID: 50453 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004766 RID: 18278
				// (get) Token: 0x0600C516 RID: 50454 RVA: 0x00317207 File Offset: 0x00315407
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004767 RID: 18279
				// (get) Token: 0x0600C517 RID: 50455 RVA: 0x00317218 File Offset: 0x00315418
				// (set) Token: 0x0600C518 RID: 50456 RVA: 0x00317236 File Offset: 0x00315436
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x17004768 RID: 18280
				// (get) Token: 0x0600C519 RID: 50457 RVA: 0x00317248 File Offset: 0x00315448
				// (set) Token: 0x0600C51A RID: 50458 RVA: 0x00317266 File Offset: 0x00315466
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x17004769 RID: 18281
				// (get) Token: 0x0600C51B RID: 50459 RVA: 0x00317278 File Offset: 0x00315478
				// (set) Token: 0x0600C51C RID: 50460 RVA: 0x00317296 File Offset: 0x00315496
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_MEDIUM_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D28 RID: 32040
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D29 RID: 32041
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D2A RID: 32042
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D2B RID: 32043
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200091B RID: 2331
		public class BUS_SMOOTH_INDOOR_SMALL_ENABLE : Object
		{
			// Token: 0x0600C51D RID: 50461 RVA: 0x003172A8 File Offset: 0x003154A8
			[CallerCount(0)]
			public unsafe BUS_SMOOTH_INDOOR_SMALL_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C51E RID: 50462 RVA: 0x003172F4 File Offset: 0x003154F4
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_SMOOTH_INDOOR_SMALL_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_SMOOTH_INDOOR_SMALL_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr);
				STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr, 100678707);
			}

			// Token: 0x0600C51F RID: 50463 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_SMOOTH_INDOOR_SMALL_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700476A RID: 18282
			// (get) Token: 0x0600C520 RID: 50464 RVA: 0x00317347 File Offset: 0x00315547
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x1700476B RID: 18283
			// (get) Token: 0x0600C521 RID: 50465 RVA: 0x00317358 File Offset: 0x00315558
			// (set) Token: 0x0600C522 RID: 50466 RVA: 0x00317376 File Offset: 0x00315576
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D2C RID: 32044
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D2D RID: 32045
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200091C RID: 2332
			public class STATE : Object
			{
				// Token: 0x0600C523 RID: 50467 RVA: 0x00317388 File Offset: 0x00315588
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C524 RID: 50468 RVA: 0x003173D4 File Offset: 0x003155D4
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr, 100678709);
				}

				// Token: 0x0600C525 RID: 50469 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x1700476C RID: 18284
				// (get) Token: 0x0600C526 RID: 50470 RVA: 0x0031744F File Offset: 0x0031564F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x1700476D RID: 18285
				// (get) Token: 0x0600C527 RID: 50471 RVA: 0x00317460 File Offset: 0x00315660
				// (set) Token: 0x0600C528 RID: 50472 RVA: 0x0031747E File Offset: 0x0031567E
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x1700476E RID: 18286
				// (get) Token: 0x0600C529 RID: 50473 RVA: 0x00317490 File Offset: 0x00315690
				// (set) Token: 0x0600C52A RID: 50474 RVA: 0x003174AE File Offset: 0x003156AE
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x1700476F RID: 18287
				// (get) Token: 0x0600C52B RID: 50475 RVA: 0x003174C0 File Offset: 0x003156C0
				// (set) Token: 0x0600C52C RID: 50476 RVA: 0x003174DE File Offset: 0x003156DE
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_INDOOR_SMALL_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D2E RID: 32046
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D2F RID: 32047
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D30 RID: 32048
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D31 RID: 32049
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200091D RID: 2333
		public class BUS_SMOOTH_OUTDOOR_ENABLE : Object
		{
			// Token: 0x0600C52D RID: 50477 RVA: 0x003174F0 File Offset: 0x003156F0
			[CallerCount(0)]
			public unsafe BUS_SMOOTH_OUTDOOR_ENABLE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C52E RID: 50478 RVA: 0x0031753C File Offset: 0x0031573C
			// Note: this type is marked as 'beforefieldinit'.
			static BUS_SMOOTH_OUTDOOR_ENABLE()
			{
				Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "BUS_SMOOTH_OUTDOOR_ENABLE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr);
				STATES.BUS_SMOOTH_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr, "GROUP");
				STATES.BUS_SMOOTH_OUTDOOR_ENABLE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr, 100678711);
			}

			// Token: 0x0600C52F RID: 50479 RVA: 0x00002988 File Offset: 0x00000B88
			public BUS_SMOOTH_OUTDOOR_ENABLE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004770 RID: 18288
			// (get) Token: 0x0600C530 RID: 50480 RVA: 0x0031758F File Offset: 0x0031578F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr));
				}
			}

			// Token: 0x17004771 RID: 18289
			// (get) Token: 0x0600C531 RID: 50481 RVA: 0x003175A0 File Offset: 0x003157A0
			// (set) Token: 0x0600C532 RID: 50482 RVA: 0x003175BE File Offset: 0x003157BE
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D32 RID: 32050
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D33 RID: 32051
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0200091E RID: 2334
			public class STATE : Object
			{
				// Token: 0x0600C533 RID: 50483 RVA: 0x003175D0 File Offset: 0x003157D0
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C534 RID: 50484 RVA: 0x0031761C File Offset: 0x0031581C
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr);
					STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "BYPASSED");
					STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "ENABLED");
					STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr, "NONE");
					STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr, 100678713);
				}

				// Token: 0x0600C535 RID: 50485 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004772 RID: 18290
				// (get) Token: 0x0600C536 RID: 50486 RVA: 0x00317697 File Offset: 0x00315897
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004773 RID: 18291
				// (get) Token: 0x0600C537 RID: 50487 RVA: 0x003176A8 File Offset: 0x003158A8
				// (set) Token: 0x0600C538 RID: 50488 RVA: 0x003176C6 File Offset: 0x003158C6
				public unsafe static uint BYPASSED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_BYPASSED, (void*)(&value));
					}
				}

				// Token: 0x17004774 RID: 18292
				// (get) Token: 0x0600C539 RID: 50489 RVA: 0x003176D8 File Offset: 0x003158D8
				// (set) Token: 0x0600C53A RID: 50490 RVA: 0x003176F6 File Offset: 0x003158F6
				public unsafe static uint ENABLED
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_ENABLED, (void*)(&value));
					}
				}

				// Token: 0x17004775 RID: 18293
				// (get) Token: 0x0600C53B RID: 50491 RVA: 0x00317708 File Offset: 0x00315908
				// (set) Token: 0x0600C53C RID: 50492 RVA: 0x00317726 File Offset: 0x00315926
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.BUS_SMOOTH_OUTDOOR_ENABLE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x04007D34 RID: 32052
				private static readonly IntPtr NativeFieldInfoPtr_BYPASSED;

				// Token: 0x04007D35 RID: 32053
				private static readonly IntPtr NativeFieldInfoPtr_ENABLED;

				// Token: 0x04007D36 RID: 32054
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D37 RID: 32055
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x0200091F RID: 2335
		public class GAMESTATE : Object
		{
			// Token: 0x0600C53D RID: 50493 RVA: 0x00317738 File Offset: 0x00315938
			[CallerCount(0)]
			public unsafe GAMESTATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.GAMESTATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C53E RID: 50494 RVA: 0x00317784 File Offset: 0x00315984
			// Note: this type is marked as 'beforefieldinit'.
			static GAMESTATE()
			{
				Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "GAMESTATE");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr);
				STATES.GAMESTATE.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr, "GROUP");
				STATES.GAMESTATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr, 100678715);
			}

			// Token: 0x0600C53F RID: 50495 RVA: 0x00002988 File Offset: 0x00000B88
			public GAMESTATE(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004776 RID: 18294
			// (get) Token: 0x0600C540 RID: 50496 RVA: 0x003177D7 File Offset: 0x003159D7
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr));
				}
			}

			// Token: 0x17004777 RID: 18295
			// (get) Token: 0x0600C541 RID: 50497 RVA: 0x003177E8 File Offset: 0x003159E8
			// (set) Token: 0x0600C542 RID: 50498 RVA: 0x00317806 File Offset: 0x00315A06
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D38 RID: 32056
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D39 RID: 32057
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000920 RID: 2336
			public class STATE : Object
			{
				// Token: 0x0600C543 RID: 50499 RVA: 0x00317818 File Offset: 0x00315A18
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.GAMESTATE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C544 RID: 50500 RVA: 0x00317864 File Offset: 0x00315A64
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.GAMESTATE>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr);
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_GAMEPLAY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "GAMEPLAY");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_INIT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "INIT");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_LOADING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "LOADING");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_MENU = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "MENU");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "NONE");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_SPLASHSCREEN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "SPLASHSCREEN");
					STATES.GAMESTATE.STATE.NativeFieldInfoPtr_TENT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, "TENT");
					STATES.GAMESTATE.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr, 100678717);
				}

				// Token: 0x0600C545 RID: 50501 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004778 RID: 18296
				// (get) Token: 0x0600C546 RID: 50502 RVA: 0x0031792F File Offset: 0x00315B2F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.GAMESTATE.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004779 RID: 18297
				// (get) Token: 0x0600C547 RID: 50503 RVA: 0x00317940 File Offset: 0x00315B40
				// (set) Token: 0x0600C548 RID: 50504 RVA: 0x0031795E File Offset: 0x00315B5E
				public unsafe static uint GAMEPLAY
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_GAMEPLAY, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_GAMEPLAY, (void*)(&value));
					}
				}

				// Token: 0x1700477A RID: 18298
				// (get) Token: 0x0600C549 RID: 50505 RVA: 0x00317970 File Offset: 0x00315B70
				// (set) Token: 0x0600C54A RID: 50506 RVA: 0x0031798E File Offset: 0x00315B8E
				public unsafe static uint INIT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_INIT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_INIT, (void*)(&value));
					}
				}

				// Token: 0x1700477B RID: 18299
				// (get) Token: 0x0600C54B RID: 50507 RVA: 0x003179A0 File Offset: 0x00315BA0
				// (set) Token: 0x0600C54C RID: 50508 RVA: 0x003179BE File Offset: 0x00315BBE
				public unsafe static uint LOADING
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_LOADING, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_LOADING, (void*)(&value));
					}
				}

				// Token: 0x1700477C RID: 18300
				// (get) Token: 0x0600C54D RID: 50509 RVA: 0x003179D0 File Offset: 0x00315BD0
				// (set) Token: 0x0600C54E RID: 50510 RVA: 0x003179EE File Offset: 0x00315BEE
				public unsafe static uint MENU
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_MENU, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_MENU, (void*)(&value));
					}
				}

				// Token: 0x1700477D RID: 18301
				// (get) Token: 0x0600C54F RID: 50511 RVA: 0x00317A00 File Offset: 0x00315C00
				// (set) Token: 0x0600C550 RID: 50512 RVA: 0x00317A1E File Offset: 0x00315C1E
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x1700477E RID: 18302
				// (get) Token: 0x0600C551 RID: 50513 RVA: 0x00317A30 File Offset: 0x00315C30
				// (set) Token: 0x0600C552 RID: 50514 RVA: 0x00317A4E File Offset: 0x00315C4E
				public unsafe static uint SPLASHSCREEN
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_SPLASHSCREEN, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_SPLASHSCREEN, (void*)(&value));
					}
				}

				// Token: 0x1700477F RID: 18303
				// (get) Token: 0x0600C553 RID: 50515 RVA: 0x00317A60 File Offset: 0x00315C60
				// (set) Token: 0x0600C554 RID: 50516 RVA: 0x00317A7E File Offset: 0x00315C7E
				public unsafe static uint TENT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_TENT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.GAMESTATE.STATE.NativeFieldInfoPtr_TENT, (void*)(&value));
					}
				}

				// Token: 0x04007D3A RID: 32058
				private static readonly IntPtr NativeFieldInfoPtr_GAMEPLAY;

				// Token: 0x04007D3B RID: 32059
				private static readonly IntPtr NativeFieldInfoPtr_INIT;

				// Token: 0x04007D3C RID: 32060
				private static readonly IntPtr NativeFieldInfoPtr_LOADING;

				// Token: 0x04007D3D RID: 32061
				private static readonly IntPtr NativeFieldInfoPtr_MENU;

				// Token: 0x04007D3E RID: 32062
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D3F RID: 32063
				private static readonly IntPtr NativeFieldInfoPtr_SPLASHSCREEN;

				// Token: 0x04007D40 RID: 32064
				private static readonly IntPtr NativeFieldInfoPtr_TENT;

				// Token: 0x04007D41 RID: 32065
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}

		// Token: 0x02000921 RID: 2337
		public class MIXINGPRESETS : Object
		{
			// Token: 0x0600C555 RID: 50517 RVA: 0x00317A90 File Offset: 0x00315C90
			[CallerCount(0)]
			public unsafe MIXINGPRESETS() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.MIXINGPRESETS.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C556 RID: 50518 RVA: 0x00317ADC File Offset: 0x00315CDC
			// Note: this type is marked as 'beforefieldinit'.
			static MIXINGPRESETS()
			{
				Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES>.NativeClassPtr, "MIXINGPRESETS");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr);
				STATES.MIXINGPRESETS.NativeFieldInfoPtr_GROUP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr, "GROUP");
				STATES.MIXINGPRESETS.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr, 100678719);
			}

			// Token: 0x0600C557 RID: 50519 RVA: 0x00002988 File Offset: 0x00000B88
			public MIXINGPRESETS(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004780 RID: 18304
			// (get) Token: 0x0600C558 RID: 50520 RVA: 0x00317B2F File Offset: 0x00315D2F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr));
				}
			}

			// Token: 0x17004781 RID: 18305
			// (get) Token: 0x0600C559 RID: 50521 RVA: 0x00317B40 File Offset: 0x00315D40
			// (set) Token: 0x0600C55A RID: 50522 RVA: 0x00317B5E File Offset: 0x00315D5E
			public unsafe static uint GROUP
			{
				get
				{
					uint result;
					IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.NativeFieldInfoPtr_GROUP, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.NativeFieldInfoPtr_GROUP, (void*)(&value));
				}
			}

			// Token: 0x04007D42 RID: 32066
			private static readonly IntPtr NativeFieldInfoPtr_GROUP;

			// Token: 0x04007D43 RID: 32067
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x02000922 RID: 2338
			public class STATE : Object
			{
				// Token: 0x0600C55B RID: 50523 RVA: 0x00317B70 File Offset: 0x00315D70
				[CallerCount(0)]
				public unsafe STATE() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr))
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(STATES.MIXINGPRESETS.STATE.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}

				// Token: 0x0600C55C RID: 50524 RVA: 0x00317BBC File Offset: 0x00315DBC
				// Note: this type is marked as 'beforefieldinit'.
				static STATE()
				{
					Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<STATES.MIXINGPRESETS>.NativeClassPtr, "STATE");
					IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr);
					STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_BASSBOOST = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, "BASSBOOST");
					STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_HDR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, "HDR");
					STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_MIDNIGHT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, "MIDNIGHT");
					STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_NONE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, "NONE");
					STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_QUEST_SPEAKER_MIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, "QUEST_SPEAKER_MIX");
					STATES.MIXINGPRESETS.STATE.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr, 100678721);
				}

				// Token: 0x0600C55D RID: 50525 RVA: 0x00002988 File Offset: 0x00000B88
				public STATE(IntPtr A_1) : base(A_1)
				{
				}

				// Token: 0x17004782 RID: 18306
				// (get) Token: 0x0600C55E RID: 50526 RVA: 0x00317C5F File Offset: 0x00315E5F
				[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
				public new static Type Il2CppType
				{
					get
					{
						return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<STATES.MIXINGPRESETS.STATE>.NativeClassPtr));
					}
				}

				// Token: 0x17004783 RID: 18307
				// (get) Token: 0x0600C55F RID: 50527 RVA: 0x00317C70 File Offset: 0x00315E70
				// (set) Token: 0x0600C560 RID: 50528 RVA: 0x00317C8E File Offset: 0x00315E8E
				public unsafe static uint BASSBOOST
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_BASSBOOST, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_BASSBOOST, (void*)(&value));
					}
				}

				// Token: 0x17004784 RID: 18308
				// (get) Token: 0x0600C561 RID: 50529 RVA: 0x00317CA0 File Offset: 0x00315EA0
				// (set) Token: 0x0600C562 RID: 50530 RVA: 0x00317CBE File Offset: 0x00315EBE
				public unsafe static uint HDR
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_HDR, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_HDR, (void*)(&value));
					}
				}

				// Token: 0x17004785 RID: 18309
				// (get) Token: 0x0600C563 RID: 50531 RVA: 0x00317CD0 File Offset: 0x00315ED0
				// (set) Token: 0x0600C564 RID: 50532 RVA: 0x00317CEE File Offset: 0x00315EEE
				public unsafe static uint MIDNIGHT
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_MIDNIGHT, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_MIDNIGHT, (void*)(&value));
					}
				}

				// Token: 0x17004786 RID: 18310
				// (get) Token: 0x0600C565 RID: 50533 RVA: 0x00317D00 File Offset: 0x00315F00
				// (set) Token: 0x0600C566 RID: 50534 RVA: 0x00317D1E File Offset: 0x00315F1E
				public unsafe static uint NONE
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_NONE, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_NONE, (void*)(&value));
					}
				}

				// Token: 0x17004787 RID: 18311
				// (get) Token: 0x0600C567 RID: 50535 RVA: 0x00317D30 File Offset: 0x00315F30
				// (set) Token: 0x0600C568 RID: 50536 RVA: 0x00317D4E File Offset: 0x00315F4E
				public unsafe static uint QUEST_SPEAKER_MIX
				{
					get
					{
						uint result;
						IL2CPP.il2cpp_field_static_get_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_QUEST_SPEAKER_MIX, (void*)(&result));
						return result;
					}
					set
					{
						IL2CPP.il2cpp_field_static_set_value(STATES.MIXINGPRESETS.STATE.NativeFieldInfoPtr_QUEST_SPEAKER_MIX, (void*)(&value));
					}
				}

				// Token: 0x04007D44 RID: 32068
				private static readonly IntPtr NativeFieldInfoPtr_BASSBOOST;

				// Token: 0x04007D45 RID: 32069
				private static readonly IntPtr NativeFieldInfoPtr_HDR;

				// Token: 0x04007D46 RID: 32070
				private static readonly IntPtr NativeFieldInfoPtr_MIDNIGHT;

				// Token: 0x04007D47 RID: 32071
				private static readonly IntPtr NativeFieldInfoPtr_NONE;

				// Token: 0x04007D48 RID: 32072
				private static readonly IntPtr NativeFieldInfoPtr_QUEST_SPEAKER_MIX;

				// Token: 0x04007D49 RID: 32073
				private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
			}
		}
	}
}
