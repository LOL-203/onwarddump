﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000937 RID: 2359
	public class AUX_BUSSES : Object
	{
		// Token: 0x0600C8D7 RID: 51415 RVA: 0x0031F3A0 File Offset: 0x0031D5A0
		[CallerCount(0)]
		public unsafe AUX_BUSSES() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AUX_BUSSES.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C8D8 RID: 51416 RVA: 0x0031F3EC File Offset: 0x0031D5EC
		// Note: this type is marked as 'beforefieldinit'.
		static AUX_BUSSES()
		{
			Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "AUX_BUSSES");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr);
			AUX_BUSSES.NativeFieldInfoPtr_FX_BYPASS_AUX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "FX_BYPASS_AUX");
			AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_LARGE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "REFLECTIVE_INDOOR_LARGE");
			AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_MEDIUM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "REFLECTIVE_INDOOR_MEDIUM");
			AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_SMALL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "REFLECTIVE_INDOOR_SMALL");
			AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_OUTDOOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "REFLECTIVE_OUTDOOR");
			AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_LARGE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "SMOOTH_INDOOR_LARGE");
			AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_MEDIUM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "SMOOTH_INDOOR_MEDIUM");
			AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_SMALL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "SMOOTH_INDOOR_SMALL");
			AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_OUTDOOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, "SMOOTH_OUTDOOR");
			AUX_BUSSES.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr, 100678762);
		}

		// Token: 0x0600C8D9 RID: 51417 RVA: 0x00002988 File Offset: 0x00000B88
		public AUX_BUSSES(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700492B RID: 18731
		// (get) Token: 0x0600C8DA RID: 51418 RVA: 0x0031F4E4 File Offset: 0x0031D6E4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AUX_BUSSES>.NativeClassPtr));
			}
		}

		// Token: 0x1700492C RID: 18732
		// (get) Token: 0x0600C8DB RID: 51419 RVA: 0x0031F4F8 File Offset: 0x0031D6F8
		// (set) Token: 0x0600C8DC RID: 51420 RVA: 0x0031F516 File Offset: 0x0031D716
		public unsafe static uint FX_BYPASS_AUX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_FX_BYPASS_AUX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_FX_BYPASS_AUX, (void*)(&value));
			}
		}

		// Token: 0x1700492D RID: 18733
		// (get) Token: 0x0600C8DD RID: 51421 RVA: 0x0031F528 File Offset: 0x0031D728
		// (set) Token: 0x0600C8DE RID: 51422 RVA: 0x0031F546 File Offset: 0x0031D746
		public unsafe static uint REFLECTIVE_INDOOR_LARGE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_LARGE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_LARGE, (void*)(&value));
			}
		}

		// Token: 0x1700492E RID: 18734
		// (get) Token: 0x0600C8DF RID: 51423 RVA: 0x0031F558 File Offset: 0x0031D758
		// (set) Token: 0x0600C8E0 RID: 51424 RVA: 0x0031F576 File Offset: 0x0031D776
		public unsafe static uint REFLECTIVE_INDOOR_MEDIUM
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_MEDIUM, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_MEDIUM, (void*)(&value));
			}
		}

		// Token: 0x1700492F RID: 18735
		// (get) Token: 0x0600C8E1 RID: 51425 RVA: 0x0031F588 File Offset: 0x0031D788
		// (set) Token: 0x0600C8E2 RID: 51426 RVA: 0x0031F5A6 File Offset: 0x0031D7A6
		public unsafe static uint REFLECTIVE_INDOOR_SMALL
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_SMALL, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_INDOOR_SMALL, (void*)(&value));
			}
		}

		// Token: 0x17004930 RID: 18736
		// (get) Token: 0x0600C8E3 RID: 51427 RVA: 0x0031F5B8 File Offset: 0x0031D7B8
		// (set) Token: 0x0600C8E4 RID: 51428 RVA: 0x0031F5D6 File Offset: 0x0031D7D6
		public unsafe static uint REFLECTIVE_OUTDOOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_OUTDOOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_REFLECTIVE_OUTDOOR, (void*)(&value));
			}
		}

		// Token: 0x17004931 RID: 18737
		// (get) Token: 0x0600C8E5 RID: 51429 RVA: 0x0031F5E8 File Offset: 0x0031D7E8
		// (set) Token: 0x0600C8E6 RID: 51430 RVA: 0x0031F606 File Offset: 0x0031D806
		public unsafe static uint SMOOTH_INDOOR_LARGE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_LARGE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_LARGE, (void*)(&value));
			}
		}

		// Token: 0x17004932 RID: 18738
		// (get) Token: 0x0600C8E7 RID: 51431 RVA: 0x0031F618 File Offset: 0x0031D818
		// (set) Token: 0x0600C8E8 RID: 51432 RVA: 0x0031F636 File Offset: 0x0031D836
		public unsafe static uint SMOOTH_INDOOR_MEDIUM
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_MEDIUM, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_MEDIUM, (void*)(&value));
			}
		}

		// Token: 0x17004933 RID: 18739
		// (get) Token: 0x0600C8E9 RID: 51433 RVA: 0x0031F648 File Offset: 0x0031D848
		// (set) Token: 0x0600C8EA RID: 51434 RVA: 0x0031F666 File Offset: 0x0031D866
		public unsafe static uint SMOOTH_INDOOR_SMALL
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_SMALL, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_INDOOR_SMALL, (void*)(&value));
			}
		}

		// Token: 0x17004934 RID: 18740
		// (get) Token: 0x0600C8EB RID: 51435 RVA: 0x0031F678 File Offset: 0x0031D878
		// (set) Token: 0x0600C8EC RID: 51436 RVA: 0x0031F696 File Offset: 0x0031D896
		public unsafe static uint SMOOTH_OUTDOOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_OUTDOOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUX_BUSSES.NativeFieldInfoPtr_SMOOTH_OUTDOOR, (void*)(&value));
			}
		}

		// Token: 0x04007EED RID: 32493
		private static readonly IntPtr NativeFieldInfoPtr_FX_BYPASS_AUX;

		// Token: 0x04007EEE RID: 32494
		private static readonly IntPtr NativeFieldInfoPtr_REFLECTIVE_INDOOR_LARGE;

		// Token: 0x04007EEF RID: 32495
		private static readonly IntPtr NativeFieldInfoPtr_REFLECTIVE_INDOOR_MEDIUM;

		// Token: 0x04007EF0 RID: 32496
		private static readonly IntPtr NativeFieldInfoPtr_REFLECTIVE_INDOOR_SMALL;

		// Token: 0x04007EF1 RID: 32497
		private static readonly IntPtr NativeFieldInfoPtr_REFLECTIVE_OUTDOOR;

		// Token: 0x04007EF2 RID: 32498
		private static readonly IntPtr NativeFieldInfoPtr_SMOOTH_INDOOR_LARGE;

		// Token: 0x04007EF3 RID: 32499
		private static readonly IntPtr NativeFieldInfoPtr_SMOOTH_INDOOR_MEDIUM;

		// Token: 0x04007EF4 RID: 32500
		private static readonly IntPtr NativeFieldInfoPtr_SMOOTH_INDOOR_SMALL;

		// Token: 0x04007EF5 RID: 32501
		private static readonly IntPtr NativeFieldInfoPtr_SMOOTH_OUTDOOR;

		// Token: 0x04007EF6 RID: 32502
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
