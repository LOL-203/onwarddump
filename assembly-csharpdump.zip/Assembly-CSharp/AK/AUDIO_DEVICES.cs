﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000938 RID: 2360
	public class AUDIO_DEVICES : Object
	{
		// Token: 0x0600C8ED RID: 51437 RVA: 0x0031F6A8 File Offset: 0x0031D8A8
		[CallerCount(0)]
		public unsafe AUDIO_DEVICES() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AUDIO_DEVICES.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C8EE RID: 51438 RVA: 0x0031F6F4 File Offset: 0x0031D8F4
		// Note: this type is marked as 'beforefieldinit'.
		static AUDIO_DEVICES()
		{
			Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "AUDIO_DEVICES");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr);
			AUDIO_DEVICES.NativeFieldInfoPtr_NO_OUTPUT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr, "NO_OUTPUT");
			AUDIO_DEVICES.NativeFieldInfoPtr_SYSTEM = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr, "SYSTEM");
			AUDIO_DEVICES.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr, 100678764);
		}

		// Token: 0x0600C8EF RID: 51439 RVA: 0x00002988 File Offset: 0x00000B88
		public AUDIO_DEVICES(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004935 RID: 18741
		// (get) Token: 0x0600C8F0 RID: 51440 RVA: 0x0031F760 File Offset: 0x0031D960
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AUDIO_DEVICES>.NativeClassPtr));
			}
		}

		// Token: 0x17004936 RID: 18742
		// (get) Token: 0x0600C8F1 RID: 51441 RVA: 0x0031F774 File Offset: 0x0031D974
		// (set) Token: 0x0600C8F2 RID: 51442 RVA: 0x0031F792 File Offset: 0x0031D992
		public unsafe static uint NO_OUTPUT
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUDIO_DEVICES.NativeFieldInfoPtr_NO_OUTPUT, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUDIO_DEVICES.NativeFieldInfoPtr_NO_OUTPUT, (void*)(&value));
			}
		}

		// Token: 0x17004937 RID: 18743
		// (get) Token: 0x0600C8F3 RID: 51443 RVA: 0x0031F7A4 File Offset: 0x0031D9A4
		// (set) Token: 0x0600C8F4 RID: 51444 RVA: 0x0031F7C2 File Offset: 0x0031D9C2
		public unsafe static uint SYSTEM
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(AUDIO_DEVICES.NativeFieldInfoPtr_SYSTEM, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AUDIO_DEVICES.NativeFieldInfoPtr_SYSTEM, (void*)(&value));
			}
		}

		// Token: 0x04007EF7 RID: 32503
		private static readonly IntPtr NativeFieldInfoPtr_NO_OUTPUT;

		// Token: 0x04007EF8 RID: 32504
		private static readonly IntPtr NativeFieldInfoPtr_SYSTEM;

		// Token: 0x04007EF9 RID: 32505
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
