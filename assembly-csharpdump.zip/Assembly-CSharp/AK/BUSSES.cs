﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AK
{
	// Token: 0x02000936 RID: 2358
	public class BUSSES : Object
	{
		// Token: 0x0600C705 RID: 50949 RVA: 0x0031B5A0 File Offset: 0x003197A0
		[CallerCount(0)]
		public unsafe BUSSES() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BUSSES>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BUSSES.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C706 RID: 50950 RVA: 0x0031B5EC File Offset: 0x003197EC
		// Note: this type is marked as 'beforefieldinit'.
		static BUSSES()
		{
			Il2CppClassPointerStore<BUSSES>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AK", "BUSSES");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BUSSES>.NativeClassPtr);
			BUSSES.NativeFieldInfoPtr__1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_1P");
			BUSSES.NativeFieldInfoPtr__2D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_2D");
			BUSSES.NativeFieldInfoPtr__2D_CC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_2D_CC");
			BUSSES.NativeFieldInfoPtr__3D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_3D");
			BUSSES.NativeFieldInfoPtr__3D_CC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_3D_CC");
			BUSSES.NativeFieldInfoPtr__3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "_3P");
			BUSSES.NativeFieldInfoPtr_AMBIENCE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "AMBIENCE");
			BUSSES.NativeFieldInfoPtr_AMBIENCE_CC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "AMBIENCE_CC");
			BUSSES.NativeFieldInfoPtr_AURO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "AURO");
			BUSSES.NativeFieldInfoPtr_BREATH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "BREATH");
			BUSSES.NativeFieldInfoPtr_CHARACTER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "CHARACTER");
			BUSSES.NativeFieldInfoPtr_DEFAULT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "DEFAULT");
			BUSSES.NativeFieldInfoPtr_DRY_MIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "DRY_MIX");
			BUSSES.NativeFieldInfoPtr_EFFECTS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "EFFECTS");
			BUSSES.NativeFieldInfoPtr_EXPLOSIVES = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "EXPLOSIVES");
			BUSSES.NativeFieldInfoPtr_FX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "FX");
			BUSSES.NativeFieldInfoPtr_GAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "GAME");
			BUSSES.NativeFieldInfoPtr_GAMEPLAY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "GAMEPLAY");
			BUSSES.NativeFieldInfoPtr_GEAR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "GEAR");
			BUSSES.NativeFieldInfoPtr_HOA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "HOA");
			BUSSES.NativeFieldInfoPtr_IMPACTS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "IMPACTS");
			BUSSES.NativeFieldInfoPtr_INDOOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "INDOOR");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LAUNCHERS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_LMGS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "LMGS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_MASTER_AUDIO_BUS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "MASTER_AUDIO_BUS");
			BUSSES.NativeFieldInfoPtr_MECH_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "MECH_3P");
			BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "MIXING_PRESETS_1");
			BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "MIXING_PRESETS_2");
			BUSSES.NativeFieldInfoPtr_MUSIC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "MUSIC");
			BUSSES.NativeFieldInfoPtr_NO_OUTPUT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "NO_OUTPUT");
			BUSSES.NativeFieldInfoPtr_NON_FX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "NON_FX");
			BUSSES.NativeFieldInfoPtr_OUTDOOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "OUTDOOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_REVERB = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "REVERB");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_RIFLES_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "RIFLES_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SHOTGUNS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SMGS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SMGS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED");
			BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SNIPERRIFLES_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_1P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_1P_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_EXTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_EXTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_FIRE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_INTERIOR_FIRE");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_INTERIOR_TAILS");
			BUSSES.NativeFieldInfoPtr_SPECIALS_3P_TAILS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "SPECIALS_3P_TAILS");
			BUSSES.NativeFieldInfoPtr_UI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "UI");
			BUSSES.NativeFieldInfoPtr_VEHICLES = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "VEHICLES");
			BUSSES.NativeFieldInfoPtr_VO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "VO");
			BUSSES.NativeFieldInfoPtr_VOIP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "VOIP");
			BUSSES.NativeFieldInfoPtr_WEAPON_SIDECHAIN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "WEAPON_SIDECHAIN");
			BUSSES.NativeFieldInfoPtr_WEAPONS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "WEAPONS");
			BUSSES.NativeFieldInfoPtr_WEAPONS_1P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "WEAPONS_1P");
			BUSSES.NativeFieldInfoPtr_WEAPONS_3P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, "WEAPONS_3P");
			BUSSES.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BUSSES>.NativeClassPtr, 100678760);
		}

		// Token: 0x0600C707 RID: 50951 RVA: 0x00002988 File Offset: 0x00000B88
		public BUSSES(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004843 RID: 18499
		// (get) Token: 0x0600C708 RID: 50952 RVA: 0x0031C83C File Offset: 0x0031AA3C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BUSSES>.NativeClassPtr));
			}
		}

		// Token: 0x17004844 RID: 18500
		// (get) Token: 0x0600C709 RID: 50953 RVA: 0x0031C850 File Offset: 0x0031AA50
		// (set) Token: 0x0600C70A RID: 50954 RVA: 0x0031C86E File Offset: 0x0031AA6E
		public unsafe static uint _1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__1P, (void*)(&value));
			}
		}

		// Token: 0x17004845 RID: 18501
		// (get) Token: 0x0600C70B RID: 50955 RVA: 0x0031C880 File Offset: 0x0031AA80
		// (set) Token: 0x0600C70C RID: 50956 RVA: 0x0031C89E File Offset: 0x0031AA9E
		public unsafe static uint _2D
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__2D, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__2D, (void*)(&value));
			}
		}

		// Token: 0x17004846 RID: 18502
		// (get) Token: 0x0600C70D RID: 50957 RVA: 0x0031C8B0 File Offset: 0x0031AAB0
		// (set) Token: 0x0600C70E RID: 50958 RVA: 0x0031C8CE File Offset: 0x0031AACE
		public unsafe static uint _2D_CC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__2D_CC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__2D_CC, (void*)(&value));
			}
		}

		// Token: 0x17004847 RID: 18503
		// (get) Token: 0x0600C70F RID: 50959 RVA: 0x0031C8E0 File Offset: 0x0031AAE0
		// (set) Token: 0x0600C710 RID: 50960 RVA: 0x0031C8FE File Offset: 0x0031AAFE
		public unsafe static uint _3D
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__3D, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__3D, (void*)(&value));
			}
		}

		// Token: 0x17004848 RID: 18504
		// (get) Token: 0x0600C711 RID: 50961 RVA: 0x0031C910 File Offset: 0x0031AB10
		// (set) Token: 0x0600C712 RID: 50962 RVA: 0x0031C92E File Offset: 0x0031AB2E
		public unsafe static uint _3D_CC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__3D_CC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__3D_CC, (void*)(&value));
			}
		}

		// Token: 0x17004849 RID: 18505
		// (get) Token: 0x0600C713 RID: 50963 RVA: 0x0031C940 File Offset: 0x0031AB40
		// (set) Token: 0x0600C714 RID: 50964 RVA: 0x0031C95E File Offset: 0x0031AB5E
		public unsafe static uint _3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr__3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr__3P, (void*)(&value));
			}
		}

		// Token: 0x1700484A RID: 18506
		// (get) Token: 0x0600C715 RID: 50965 RVA: 0x0031C970 File Offset: 0x0031AB70
		// (set) Token: 0x0600C716 RID: 50966 RVA: 0x0031C98E File Offset: 0x0031AB8E
		public unsafe static uint AMBIENCE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_AMBIENCE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_AMBIENCE, (void*)(&value));
			}
		}

		// Token: 0x1700484B RID: 18507
		// (get) Token: 0x0600C717 RID: 50967 RVA: 0x0031C9A0 File Offset: 0x0031ABA0
		// (set) Token: 0x0600C718 RID: 50968 RVA: 0x0031C9BE File Offset: 0x0031ABBE
		public unsafe static uint AMBIENCE_CC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_AMBIENCE_CC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_AMBIENCE_CC, (void*)(&value));
			}
		}

		// Token: 0x1700484C RID: 18508
		// (get) Token: 0x0600C719 RID: 50969 RVA: 0x0031C9D0 File Offset: 0x0031ABD0
		// (set) Token: 0x0600C71A RID: 50970 RVA: 0x0031C9EE File Offset: 0x0031ABEE
		public unsafe static uint AURO
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_AURO, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_AURO, (void*)(&value));
			}
		}

		// Token: 0x1700484D RID: 18509
		// (get) Token: 0x0600C71B RID: 50971 RVA: 0x0031CA00 File Offset: 0x0031AC00
		// (set) Token: 0x0600C71C RID: 50972 RVA: 0x0031CA1E File Offset: 0x0031AC1E
		public unsafe static uint BREATH
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_BREATH, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_BREATH, (void*)(&value));
			}
		}

		// Token: 0x1700484E RID: 18510
		// (get) Token: 0x0600C71D RID: 50973 RVA: 0x0031CA30 File Offset: 0x0031AC30
		// (set) Token: 0x0600C71E RID: 50974 RVA: 0x0031CA4E File Offset: 0x0031AC4E
		public unsafe static uint CHARACTER
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_CHARACTER, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_CHARACTER, (void*)(&value));
			}
		}

		// Token: 0x1700484F RID: 18511
		// (get) Token: 0x0600C71F RID: 50975 RVA: 0x0031CA60 File Offset: 0x0031AC60
		// (set) Token: 0x0600C720 RID: 50976 RVA: 0x0031CA7E File Offset: 0x0031AC7E
		public unsafe static uint DEFAULT
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_DEFAULT, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_DEFAULT, (void*)(&value));
			}
		}

		// Token: 0x17004850 RID: 18512
		// (get) Token: 0x0600C721 RID: 50977 RVA: 0x0031CA90 File Offset: 0x0031AC90
		// (set) Token: 0x0600C722 RID: 50978 RVA: 0x0031CAAE File Offset: 0x0031ACAE
		public unsafe static uint DRY_MIX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_DRY_MIX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_DRY_MIX, (void*)(&value));
			}
		}

		// Token: 0x17004851 RID: 18513
		// (get) Token: 0x0600C723 RID: 50979 RVA: 0x0031CAC0 File Offset: 0x0031ACC0
		// (set) Token: 0x0600C724 RID: 50980 RVA: 0x0031CADE File Offset: 0x0031ACDE
		public unsafe static uint EFFECTS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_EFFECTS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_EFFECTS, (void*)(&value));
			}
		}

		// Token: 0x17004852 RID: 18514
		// (get) Token: 0x0600C725 RID: 50981 RVA: 0x0031CAF0 File Offset: 0x0031ACF0
		// (set) Token: 0x0600C726 RID: 50982 RVA: 0x0031CB0E File Offset: 0x0031AD0E
		public unsafe static uint EXPLOSIVES
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_EXPLOSIVES, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_EXPLOSIVES, (void*)(&value));
			}
		}

		// Token: 0x17004853 RID: 18515
		// (get) Token: 0x0600C727 RID: 50983 RVA: 0x0031CB20 File Offset: 0x0031AD20
		// (set) Token: 0x0600C728 RID: 50984 RVA: 0x0031CB3E File Offset: 0x0031AD3E
		public unsafe static uint FX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_FX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_FX, (void*)(&value));
			}
		}

		// Token: 0x17004854 RID: 18516
		// (get) Token: 0x0600C729 RID: 50985 RVA: 0x0031CB50 File Offset: 0x0031AD50
		// (set) Token: 0x0600C72A RID: 50986 RVA: 0x0031CB6E File Offset: 0x0031AD6E
		public unsafe static uint GAME
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_GAME, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_GAME, (void*)(&value));
			}
		}

		// Token: 0x17004855 RID: 18517
		// (get) Token: 0x0600C72B RID: 50987 RVA: 0x0031CB80 File Offset: 0x0031AD80
		// (set) Token: 0x0600C72C RID: 50988 RVA: 0x0031CB9E File Offset: 0x0031AD9E
		public unsafe static uint GAMEPLAY
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_GAMEPLAY, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_GAMEPLAY, (void*)(&value));
			}
		}

		// Token: 0x17004856 RID: 18518
		// (get) Token: 0x0600C72D RID: 50989 RVA: 0x0031CBB0 File Offset: 0x0031ADB0
		// (set) Token: 0x0600C72E RID: 50990 RVA: 0x0031CBCE File Offset: 0x0031ADCE
		public unsafe static uint GEAR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_GEAR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_GEAR, (void*)(&value));
			}
		}

		// Token: 0x17004857 RID: 18519
		// (get) Token: 0x0600C72F RID: 50991 RVA: 0x0031CBE0 File Offset: 0x0031ADE0
		// (set) Token: 0x0600C730 RID: 50992 RVA: 0x0031CBFE File Offset: 0x0031ADFE
		public unsafe static uint HOA
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_HOA, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_HOA, (void*)(&value));
			}
		}

		// Token: 0x17004858 RID: 18520
		// (get) Token: 0x0600C731 RID: 50993 RVA: 0x0031CC10 File Offset: 0x0031AE10
		// (set) Token: 0x0600C732 RID: 50994 RVA: 0x0031CC2E File Offset: 0x0031AE2E
		public unsafe static uint IMPACTS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_IMPACTS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_IMPACTS, (void*)(&value));
			}
		}

		// Token: 0x17004859 RID: 18521
		// (get) Token: 0x0600C733 RID: 50995 RVA: 0x0031CC40 File Offset: 0x0031AE40
		// (set) Token: 0x0600C734 RID: 50996 RVA: 0x0031CC5E File Offset: 0x0031AE5E
		public unsafe static uint INDOOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_INDOOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_INDOOR, (void*)(&value));
			}
		}

		// Token: 0x1700485A RID: 18522
		// (get) Token: 0x0600C735 RID: 50997 RVA: 0x0031CC70 File Offset: 0x0031AE70
		// (set) Token: 0x0600C736 RID: 50998 RVA: 0x0031CC8E File Offset: 0x0031AE8E
		public unsafe static uint LAUNCHERS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P, (void*)(&value));
			}
		}

		// Token: 0x1700485B RID: 18523
		// (get) Token: 0x0600C737 RID: 50999 RVA: 0x0031CCA0 File Offset: 0x0031AEA0
		// (set) Token: 0x0600C738 RID: 51000 RVA: 0x0031CCBE File Offset: 0x0031AEBE
		public unsafe static uint LAUNCHERS_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700485C RID: 18524
		// (get) Token: 0x0600C739 RID: 51001 RVA: 0x0031CCD0 File Offset: 0x0031AED0
		// (set) Token: 0x0600C73A RID: 51002 RVA: 0x0031CCEE File Offset: 0x0031AEEE
		public unsafe static uint LAUNCHERS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700485D RID: 18525
		// (get) Token: 0x0600C73B RID: 51003 RVA: 0x0031CD00 File Offset: 0x0031AF00
		// (set) Token: 0x0600C73C RID: 51004 RVA: 0x0031CD1E File Offset: 0x0031AF1E
		public unsafe static uint LAUNCHERS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700485E RID: 18526
		// (get) Token: 0x0600C73D RID: 51005 RVA: 0x0031CD30 File Offset: 0x0031AF30
		// (set) Token: 0x0600C73E RID: 51006 RVA: 0x0031CD4E File Offset: 0x0031AF4E
		public unsafe static uint LAUNCHERS_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700485F RID: 18527
		// (get) Token: 0x0600C73F RID: 51007 RVA: 0x0031CD60 File Offset: 0x0031AF60
		// (set) Token: 0x0600C740 RID: 51008 RVA: 0x0031CD7E File Offset: 0x0031AF7E
		public unsafe static uint LAUNCHERS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004860 RID: 18528
		// (get) Token: 0x0600C741 RID: 51009 RVA: 0x0031CD90 File Offset: 0x0031AF90
		// (set) Token: 0x0600C742 RID: 51010 RVA: 0x0031CDAE File Offset: 0x0031AFAE
		public unsafe static uint LAUNCHERS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004861 RID: 18529
		// (get) Token: 0x0600C743 RID: 51011 RVA: 0x0031CDC0 File Offset: 0x0031AFC0
		// (set) Token: 0x0600C744 RID: 51012 RVA: 0x0031CDDE File Offset: 0x0031AFDE
		public unsafe static uint LAUNCHERS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P, (void*)(&value));
			}
		}

		// Token: 0x17004862 RID: 18530
		// (get) Token: 0x0600C745 RID: 51013 RVA: 0x0031CDF0 File Offset: 0x0031AFF0
		// (set) Token: 0x0600C746 RID: 51014 RVA: 0x0031CE0E File Offset: 0x0031B00E
		public unsafe static uint LAUNCHERS_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004863 RID: 18531
		// (get) Token: 0x0600C747 RID: 51015 RVA: 0x0031CE20 File Offset: 0x0031B020
		// (set) Token: 0x0600C748 RID: 51016 RVA: 0x0031CE3E File Offset: 0x0031B03E
		public unsafe static uint LAUNCHERS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004864 RID: 18532
		// (get) Token: 0x0600C749 RID: 51017 RVA: 0x0031CE50 File Offset: 0x0031B050
		// (set) Token: 0x0600C74A RID: 51018 RVA: 0x0031CE6E File Offset: 0x0031B06E
		public unsafe static uint LAUNCHERS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004865 RID: 18533
		// (get) Token: 0x0600C74B RID: 51019 RVA: 0x0031CE80 File Offset: 0x0031B080
		// (set) Token: 0x0600C74C RID: 51020 RVA: 0x0031CE9E File Offset: 0x0031B09E
		public unsafe static uint LAUNCHERS_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004866 RID: 18534
		// (get) Token: 0x0600C74D RID: 51021 RVA: 0x0031CEB0 File Offset: 0x0031B0B0
		// (set) Token: 0x0600C74E RID: 51022 RVA: 0x0031CECE File Offset: 0x0031B0CE
		public unsafe static uint LAUNCHERS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004867 RID: 18535
		// (get) Token: 0x0600C74F RID: 51023 RVA: 0x0031CEE0 File Offset: 0x0031B0E0
		// (set) Token: 0x0600C750 RID: 51024 RVA: 0x0031CEFE File Offset: 0x0031B0FE
		public unsafe static uint LAUNCHERS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LAUNCHERS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004868 RID: 18536
		// (get) Token: 0x0600C751 RID: 51025 RVA: 0x0031CF10 File Offset: 0x0031B110
		// (set) Token: 0x0600C752 RID: 51026 RVA: 0x0031CF2E File Offset: 0x0031B12E
		public unsafe static uint LMGS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P, (void*)(&value));
			}
		}

		// Token: 0x17004869 RID: 18537
		// (get) Token: 0x0600C753 RID: 51027 RVA: 0x0031CF40 File Offset: 0x0031B140
		// (set) Token: 0x0600C754 RID: 51028 RVA: 0x0031CF5E File Offset: 0x0031B15E
		public unsafe static uint LMGS_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700486A RID: 18538
		// (get) Token: 0x0600C755 RID: 51029 RVA: 0x0031CF70 File Offset: 0x0031B170
		// (set) Token: 0x0600C756 RID: 51030 RVA: 0x0031CF8E File Offset: 0x0031B18E
		public unsafe static uint LMGS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700486B RID: 18539
		// (get) Token: 0x0600C757 RID: 51031 RVA: 0x0031CFA0 File Offset: 0x0031B1A0
		// (set) Token: 0x0600C758 RID: 51032 RVA: 0x0031CFBE File Offset: 0x0031B1BE
		public unsafe static uint LMGS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700486C RID: 18540
		// (get) Token: 0x0600C759 RID: 51033 RVA: 0x0031CFD0 File Offset: 0x0031B1D0
		// (set) Token: 0x0600C75A RID: 51034 RVA: 0x0031CFEE File Offset: 0x0031B1EE
		public unsafe static uint LMGS_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700486D RID: 18541
		// (get) Token: 0x0600C75B RID: 51035 RVA: 0x0031D000 File Offset: 0x0031B200
		// (set) Token: 0x0600C75C RID: 51036 RVA: 0x0031D01E File Offset: 0x0031B21E
		public unsafe static uint LMGS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700486E RID: 18542
		// (get) Token: 0x0600C75D RID: 51037 RVA: 0x0031D030 File Offset: 0x0031B230
		// (set) Token: 0x0600C75E RID: 51038 RVA: 0x0031D04E File Offset: 0x0031B24E
		public unsafe static uint LMGS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700486F RID: 18543
		// (get) Token: 0x0600C75F RID: 51039 RVA: 0x0031D060 File Offset: 0x0031B260
		// (set) Token: 0x0600C760 RID: 51040 RVA: 0x0031D07E File Offset: 0x0031B27E
		public unsafe static uint LMGS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P, (void*)(&value));
			}
		}

		// Token: 0x17004870 RID: 18544
		// (get) Token: 0x0600C761 RID: 51041 RVA: 0x0031D090 File Offset: 0x0031B290
		// (set) Token: 0x0600C762 RID: 51042 RVA: 0x0031D0AE File Offset: 0x0031B2AE
		public unsafe static uint LMGS_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004871 RID: 18545
		// (get) Token: 0x0600C763 RID: 51043 RVA: 0x0031D0C0 File Offset: 0x0031B2C0
		// (set) Token: 0x0600C764 RID: 51044 RVA: 0x0031D0DE File Offset: 0x0031B2DE
		public unsafe static uint LMGS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004872 RID: 18546
		// (get) Token: 0x0600C765 RID: 51045 RVA: 0x0031D0F0 File Offset: 0x0031B2F0
		// (set) Token: 0x0600C766 RID: 51046 RVA: 0x0031D10E File Offset: 0x0031B30E
		public unsafe static uint LMGS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004873 RID: 18547
		// (get) Token: 0x0600C767 RID: 51047 RVA: 0x0031D120 File Offset: 0x0031B320
		// (set) Token: 0x0600C768 RID: 51048 RVA: 0x0031D13E File Offset: 0x0031B33E
		public unsafe static uint LMGS_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004874 RID: 18548
		// (get) Token: 0x0600C769 RID: 51049 RVA: 0x0031D150 File Offset: 0x0031B350
		// (set) Token: 0x0600C76A RID: 51050 RVA: 0x0031D16E File Offset: 0x0031B36E
		public unsafe static uint LMGS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004875 RID: 18549
		// (get) Token: 0x0600C76B RID: 51051 RVA: 0x0031D180 File Offset: 0x0031B380
		// (set) Token: 0x0600C76C RID: 51052 RVA: 0x0031D19E File Offset: 0x0031B39E
		public unsafe static uint LMGS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_LMGS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004876 RID: 18550
		// (get) Token: 0x0600C76D RID: 51053 RVA: 0x0031D1B0 File Offset: 0x0031B3B0
		// (set) Token: 0x0600C76E RID: 51054 RVA: 0x0031D1CE File Offset: 0x0031B3CE
		public unsafe static uint MASTER_AUDIO_BUS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_MASTER_AUDIO_BUS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_MASTER_AUDIO_BUS, (void*)(&value));
			}
		}

		// Token: 0x17004877 RID: 18551
		// (get) Token: 0x0600C76F RID: 51055 RVA: 0x0031D1E0 File Offset: 0x0031B3E0
		// (set) Token: 0x0600C770 RID: 51056 RVA: 0x0031D1FE File Offset: 0x0031B3FE
		public unsafe static uint MECH_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_MECH_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_MECH_3P, (void*)(&value));
			}
		}

		// Token: 0x17004878 RID: 18552
		// (get) Token: 0x0600C771 RID: 51057 RVA: 0x0031D210 File Offset: 0x0031B410
		// (set) Token: 0x0600C772 RID: 51058 RVA: 0x0031D22E File Offset: 0x0031B42E
		public unsafe static uint MIXING_PRESETS_1
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_1, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_1, (void*)(&value));
			}
		}

		// Token: 0x17004879 RID: 18553
		// (get) Token: 0x0600C773 RID: 51059 RVA: 0x0031D240 File Offset: 0x0031B440
		// (set) Token: 0x0600C774 RID: 51060 RVA: 0x0031D25E File Offset: 0x0031B45E
		public unsafe static uint MIXING_PRESETS_2
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_2, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_MIXING_PRESETS_2, (void*)(&value));
			}
		}

		// Token: 0x1700487A RID: 18554
		// (get) Token: 0x0600C775 RID: 51061 RVA: 0x0031D270 File Offset: 0x0031B470
		// (set) Token: 0x0600C776 RID: 51062 RVA: 0x0031D28E File Offset: 0x0031B48E
		public unsafe static uint MUSIC
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_MUSIC, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_MUSIC, (void*)(&value));
			}
		}

		// Token: 0x1700487B RID: 18555
		// (get) Token: 0x0600C777 RID: 51063 RVA: 0x0031D2A0 File Offset: 0x0031B4A0
		// (set) Token: 0x0600C778 RID: 51064 RVA: 0x0031D2BE File Offset: 0x0031B4BE
		public unsafe static uint NO_OUTPUT
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_NO_OUTPUT, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_NO_OUTPUT, (void*)(&value));
			}
		}

		// Token: 0x1700487C RID: 18556
		// (get) Token: 0x0600C779 RID: 51065 RVA: 0x0031D2D0 File Offset: 0x0031B4D0
		// (set) Token: 0x0600C77A RID: 51066 RVA: 0x0031D2EE File Offset: 0x0031B4EE
		public unsafe static uint NON_FX
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_NON_FX, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_NON_FX, (void*)(&value));
			}
		}

		// Token: 0x1700487D RID: 18557
		// (get) Token: 0x0600C77B RID: 51067 RVA: 0x0031D300 File Offset: 0x0031B500
		// (set) Token: 0x0600C77C RID: 51068 RVA: 0x0031D31E File Offset: 0x0031B51E
		public unsafe static uint OUTDOOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_OUTDOOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_OUTDOOR, (void*)(&value));
			}
		}

		// Token: 0x1700487E RID: 18558
		// (get) Token: 0x0600C77D RID: 51069 RVA: 0x0031D330 File Offset: 0x0031B530
		// (set) Token: 0x0600C77E RID: 51070 RVA: 0x0031D34E File Offset: 0x0031B54E
		public unsafe static uint PISTOLS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P, (void*)(&value));
			}
		}

		// Token: 0x1700487F RID: 18559
		// (get) Token: 0x0600C77F RID: 51071 RVA: 0x0031D360 File Offset: 0x0031B560
		// (set) Token: 0x0600C780 RID: 51072 RVA: 0x0031D37E File Offset: 0x0031B57E
		public unsafe static uint PISTOLS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004880 RID: 18560
		// (get) Token: 0x0600C781 RID: 51073 RVA: 0x0031D390 File Offset: 0x0031B590
		// (set) Token: 0x0600C782 RID: 51074 RVA: 0x0031D3AE File Offset: 0x0031B5AE
		public unsafe static uint PISTOLS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004881 RID: 18561
		// (get) Token: 0x0600C783 RID: 51075 RVA: 0x0031D3C0 File Offset: 0x0031B5C0
		// (set) Token: 0x0600C784 RID: 51076 RVA: 0x0031D3DE File Offset: 0x0031B5DE
		public unsafe static uint PISTOLS_1P_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004882 RID: 18562
		// (get) Token: 0x0600C785 RID: 51077 RVA: 0x0031D3F0 File Offset: 0x0031B5F0
		// (set) Token: 0x0600C786 RID: 51078 RVA: 0x0031D40E File Offset: 0x0031B60E
		public unsafe static uint PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004883 RID: 18563
		// (get) Token: 0x0600C787 RID: 51079 RVA: 0x0031D420 File Offset: 0x0031B620
		// (set) Token: 0x0600C788 RID: 51080 RVA: 0x0031D43E File Offset: 0x0031B63E
		public unsafe static uint PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004884 RID: 18564
		// (get) Token: 0x0600C789 RID: 51081 RVA: 0x0031D450 File Offset: 0x0031B650
		// (set) Token: 0x0600C78A RID: 51082 RVA: 0x0031D46E File Offset: 0x0031B66E
		public unsafe static uint PISTOLS_1P_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004885 RID: 18565
		// (get) Token: 0x0600C78B RID: 51083 RVA: 0x0031D480 File Offset: 0x0031B680
		// (set) Token: 0x0600C78C RID: 51084 RVA: 0x0031D49E File Offset: 0x0031B69E
		public unsafe static uint PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004886 RID: 18566
		// (get) Token: 0x0600C78D RID: 51085 RVA: 0x0031D4B0 File Offset: 0x0031B6B0
		// (set) Token: 0x0600C78E RID: 51086 RVA: 0x0031D4CE File Offset: 0x0031B6CE
		public unsafe static uint PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004887 RID: 18567
		// (get) Token: 0x0600C78F RID: 51087 RVA: 0x0031D4E0 File Offset: 0x0031B6E0
		// (set) Token: 0x0600C790 RID: 51088 RVA: 0x0031D4FE File Offset: 0x0031B6FE
		public unsafe static uint PISTOLS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004888 RID: 18568
		// (get) Token: 0x0600C791 RID: 51089 RVA: 0x0031D510 File Offset: 0x0031B710
		// (set) Token: 0x0600C792 RID: 51090 RVA: 0x0031D52E File Offset: 0x0031B72E
		public unsafe static uint PISTOLS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004889 RID: 18569
		// (get) Token: 0x0600C793 RID: 51091 RVA: 0x0031D540 File Offset: 0x0031B740
		// (set) Token: 0x0600C794 RID: 51092 RVA: 0x0031D55E File Offset: 0x0031B75E
		public unsafe static uint PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700488A RID: 18570
		// (get) Token: 0x0600C795 RID: 51093 RVA: 0x0031D570 File Offset: 0x0031B770
		// (set) Token: 0x0600C796 RID: 51094 RVA: 0x0031D58E File Offset: 0x0031B78E
		public unsafe static uint PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700488B RID: 18571
		// (get) Token: 0x0600C797 RID: 51095 RVA: 0x0031D5A0 File Offset: 0x0031B7A0
		// (set) Token: 0x0600C798 RID: 51096 RVA: 0x0031D5BE File Offset: 0x0031B7BE
		public unsafe static uint PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700488C RID: 18572
		// (get) Token: 0x0600C799 RID: 51097 RVA: 0x0031D5D0 File Offset: 0x0031B7D0
		// (set) Token: 0x0600C79A RID: 51098 RVA: 0x0031D5EE File Offset: 0x0031B7EE
		public unsafe static uint PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700488D RID: 18573
		// (get) Token: 0x0600C79B RID: 51099 RVA: 0x0031D600 File Offset: 0x0031B800
		// (set) Token: 0x0600C79C RID: 51100 RVA: 0x0031D61E File Offset: 0x0031B81E
		public unsafe static uint PISTOLS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P, (void*)(&value));
			}
		}

		// Token: 0x1700488E RID: 18574
		// (get) Token: 0x0600C79D RID: 51101 RVA: 0x0031D630 File Offset: 0x0031B830
		// (set) Token: 0x0600C79E RID: 51102 RVA: 0x0031D64E File Offset: 0x0031B84E
		public unsafe static uint PISTOLS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700488F RID: 18575
		// (get) Token: 0x0600C79F RID: 51103 RVA: 0x0031D660 File Offset: 0x0031B860
		// (set) Token: 0x0600C7A0 RID: 51104 RVA: 0x0031D67E File Offset: 0x0031B87E
		public unsafe static uint PISTOLS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004890 RID: 18576
		// (get) Token: 0x0600C7A1 RID: 51105 RVA: 0x0031D690 File Offset: 0x0031B890
		// (set) Token: 0x0600C7A2 RID: 51106 RVA: 0x0031D6AE File Offset: 0x0031B8AE
		public unsafe static uint PISTOLS_3P_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004891 RID: 18577
		// (get) Token: 0x0600C7A3 RID: 51107 RVA: 0x0031D6C0 File Offset: 0x0031B8C0
		// (set) Token: 0x0600C7A4 RID: 51108 RVA: 0x0031D6DE File Offset: 0x0031B8DE
		public unsafe static uint PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004892 RID: 18578
		// (get) Token: 0x0600C7A5 RID: 51109 RVA: 0x0031D6F0 File Offset: 0x0031B8F0
		// (set) Token: 0x0600C7A6 RID: 51110 RVA: 0x0031D70E File Offset: 0x0031B90E
		public unsafe static uint PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004893 RID: 18579
		// (get) Token: 0x0600C7A7 RID: 51111 RVA: 0x0031D720 File Offset: 0x0031B920
		// (set) Token: 0x0600C7A8 RID: 51112 RVA: 0x0031D73E File Offset: 0x0031B93E
		public unsafe static uint PISTOLS_3P_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004894 RID: 18580
		// (get) Token: 0x0600C7A9 RID: 51113 RVA: 0x0031D750 File Offset: 0x0031B950
		// (set) Token: 0x0600C7AA RID: 51114 RVA: 0x0031D76E File Offset: 0x0031B96E
		public unsafe static uint PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004895 RID: 18581
		// (get) Token: 0x0600C7AB RID: 51115 RVA: 0x0031D780 File Offset: 0x0031B980
		// (set) Token: 0x0600C7AC RID: 51116 RVA: 0x0031D79E File Offset: 0x0031B99E
		public unsafe static uint PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR, (void*)(&value));
			}
		}

		// Token: 0x17004896 RID: 18582
		// (get) Token: 0x0600C7AD RID: 51117 RVA: 0x0031D7B0 File Offset: 0x0031B9B0
		// (set) Token: 0x0600C7AE RID: 51118 RVA: 0x0031D7CE File Offset: 0x0031B9CE
		public unsafe static uint PISTOLS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004897 RID: 18583
		// (get) Token: 0x0600C7AF RID: 51119 RVA: 0x0031D7E0 File Offset: 0x0031B9E0
		// (set) Token: 0x0600C7B0 RID: 51120 RVA: 0x0031D7FE File Offset: 0x0031B9FE
		public unsafe static uint PISTOLS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004898 RID: 18584
		// (get) Token: 0x0600C7B1 RID: 51121 RVA: 0x0031D810 File Offset: 0x0031BA10
		// (set) Token: 0x0600C7B2 RID: 51122 RVA: 0x0031D82E File Offset: 0x0031BA2E
		public unsafe static uint PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004899 RID: 18585
		// (get) Token: 0x0600C7B3 RID: 51123 RVA: 0x0031D840 File Offset: 0x0031BA40
		// (set) Token: 0x0600C7B4 RID: 51124 RVA: 0x0031D85E File Offset: 0x0031BA5E
		public unsafe static uint PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700489A RID: 18586
		// (get) Token: 0x0600C7B5 RID: 51125 RVA: 0x0031D870 File Offset: 0x0031BA70
		// (set) Token: 0x0600C7B6 RID: 51126 RVA: 0x0031D88E File Offset: 0x0031BA8E
		public unsafe static uint PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700489B RID: 18587
		// (get) Token: 0x0600C7B7 RID: 51127 RVA: 0x0031D8A0 File Offset: 0x0031BAA0
		// (set) Token: 0x0600C7B8 RID: 51128 RVA: 0x0031D8BE File Offset: 0x0031BABE
		public unsafe static uint PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700489C RID: 18588
		// (get) Token: 0x0600C7B9 RID: 51129 RVA: 0x0031D8D0 File Offset: 0x0031BAD0
		// (set) Token: 0x0600C7BA RID: 51130 RVA: 0x0031D8EE File Offset: 0x0031BAEE
		public unsafe static uint REVERB
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_REVERB, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_REVERB, (void*)(&value));
			}
		}

		// Token: 0x1700489D RID: 18589
		// (get) Token: 0x0600C7BB RID: 51131 RVA: 0x0031D900 File Offset: 0x0031BB00
		// (set) Token: 0x0600C7BC RID: 51132 RVA: 0x0031D91E File Offset: 0x0031BB1E
		public unsafe static uint RIFLES_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P, (void*)(&value));
			}
		}

		// Token: 0x1700489E RID: 18590
		// (get) Token: 0x0600C7BD RID: 51133 RVA: 0x0031D930 File Offset: 0x0031BB30
		// (set) Token: 0x0600C7BE RID: 51134 RVA: 0x0031D94E File Offset: 0x0031BB4E
		public unsafe static uint RIFLES_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700489F RID: 18591
		// (get) Token: 0x0600C7BF RID: 51135 RVA: 0x0031D960 File Offset: 0x0031BB60
		// (set) Token: 0x0600C7C0 RID: 51136 RVA: 0x0031D97E File Offset: 0x0031BB7E
		public unsafe static uint RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A0 RID: 18592
		// (get) Token: 0x0600C7C1 RID: 51137 RVA: 0x0031D990 File Offset: 0x0031BB90
		// (set) Token: 0x0600C7C2 RID: 51138 RVA: 0x0031D9AE File Offset: 0x0031BBAE
		public unsafe static uint RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A1 RID: 18593
		// (get) Token: 0x0600C7C3 RID: 51139 RVA: 0x0031D9C0 File Offset: 0x0031BBC0
		// (set) Token: 0x0600C7C4 RID: 51140 RVA: 0x0031D9DE File Offset: 0x0031BBDE
		public unsafe static uint RIFLES_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048A2 RID: 18594
		// (get) Token: 0x0600C7C5 RID: 51141 RVA: 0x0031D9F0 File Offset: 0x0031BBF0
		// (set) Token: 0x0600C7C6 RID: 51142 RVA: 0x0031DA0E File Offset: 0x0031BC0E
		public unsafe static uint RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A3 RID: 18595
		// (get) Token: 0x0600C7C7 RID: 51143 RVA: 0x0031DA20 File Offset: 0x0031BC20
		// (set) Token: 0x0600C7C8 RID: 51144 RVA: 0x0031DA3E File Offset: 0x0031BC3E
		public unsafe static uint RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A4 RID: 18596
		// (get) Token: 0x0600C7C9 RID: 51145 RVA: 0x0031DA50 File Offset: 0x0031BC50
		// (set) Token: 0x0600C7CA RID: 51146 RVA: 0x0031DA6E File Offset: 0x0031BC6E
		public unsafe static uint RIFLES_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048A5 RID: 18597
		// (get) Token: 0x0600C7CB RID: 51147 RVA: 0x0031DA80 File Offset: 0x0031BC80
		// (set) Token: 0x0600C7CC RID: 51148 RVA: 0x0031DA9E File Offset: 0x0031BC9E
		public unsafe static uint RIFLES_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048A6 RID: 18598
		// (get) Token: 0x0600C7CD RID: 51149 RVA: 0x0031DAB0 File Offset: 0x0031BCB0
		// (set) Token: 0x0600C7CE RID: 51150 RVA: 0x0031DACE File Offset: 0x0031BCCE
		public unsafe static uint RIFLES_1P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A7 RID: 18599
		// (get) Token: 0x0600C7CF RID: 51151 RVA: 0x0031DAE0 File Offset: 0x0031BCE0
		// (set) Token: 0x0600C7D0 RID: 51152 RVA: 0x0031DAFE File Offset: 0x0031BCFE
		public unsafe static uint RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048A8 RID: 18600
		// (get) Token: 0x0600C7D1 RID: 51153 RVA: 0x0031DB10 File Offset: 0x0031BD10
		// (set) Token: 0x0600C7D2 RID: 51154 RVA: 0x0031DB2E File Offset: 0x0031BD2E
		public unsafe static uint RIFLES_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048A9 RID: 18601
		// (get) Token: 0x0600C7D3 RID: 51155 RVA: 0x0031DB40 File Offset: 0x0031BD40
		// (set) Token: 0x0600C7D4 RID: 51156 RVA: 0x0031DB5E File Offset: 0x0031BD5E
		public unsafe static uint RIFLES_1P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048AA RID: 18602
		// (get) Token: 0x0600C7D5 RID: 51157 RVA: 0x0031DB70 File Offset: 0x0031BD70
		// (set) Token: 0x0600C7D6 RID: 51158 RVA: 0x0031DB8E File Offset: 0x0031BD8E
		public unsafe static uint RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048AB RID: 18603
		// (get) Token: 0x0600C7D7 RID: 51159 RVA: 0x0031DBA0 File Offset: 0x0031BDA0
		// (set) Token: 0x0600C7D8 RID: 51160 RVA: 0x0031DBBE File Offset: 0x0031BDBE
		public unsafe static uint RIFLES_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048AC RID: 18604
		// (get) Token: 0x0600C7D9 RID: 51161 RVA: 0x0031DBD0 File Offset: 0x0031BDD0
		// (set) Token: 0x0600C7DA RID: 51162 RVA: 0x0031DBEE File Offset: 0x0031BDEE
		public unsafe static uint RIFLES_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P, (void*)(&value));
			}
		}

		// Token: 0x170048AD RID: 18605
		// (get) Token: 0x0600C7DB RID: 51163 RVA: 0x0031DC00 File Offset: 0x0031BE00
		// (set) Token: 0x0600C7DC RID: 51164 RVA: 0x0031DC1E File Offset: 0x0031BE1E
		public unsafe static uint RIFLES_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048AE RID: 18606
		// (get) Token: 0x0600C7DD RID: 51165 RVA: 0x0031DC30 File Offset: 0x0031BE30
		// (set) Token: 0x0600C7DE RID: 51166 RVA: 0x0031DC4E File Offset: 0x0031BE4E
		public unsafe static uint RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048AF RID: 18607
		// (get) Token: 0x0600C7DF RID: 51167 RVA: 0x0031DC60 File Offset: 0x0031BE60
		// (set) Token: 0x0600C7E0 RID: 51168 RVA: 0x0031DC7E File Offset: 0x0031BE7E
		public unsafe static uint RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B0 RID: 18608
		// (get) Token: 0x0600C7E1 RID: 51169 RVA: 0x0031DC90 File Offset: 0x0031BE90
		// (set) Token: 0x0600C7E2 RID: 51170 RVA: 0x0031DCAE File Offset: 0x0031BEAE
		public unsafe static uint RIFLES_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048B1 RID: 18609
		// (get) Token: 0x0600C7E3 RID: 51171 RVA: 0x0031DCC0 File Offset: 0x0031BEC0
		// (set) Token: 0x0600C7E4 RID: 51172 RVA: 0x0031DCDE File Offset: 0x0031BEDE
		public unsafe static uint RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B2 RID: 18610
		// (get) Token: 0x0600C7E5 RID: 51173 RVA: 0x0031DCF0 File Offset: 0x0031BEF0
		// (set) Token: 0x0600C7E6 RID: 51174 RVA: 0x0031DD0E File Offset: 0x0031BF0E
		public unsafe static uint RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B3 RID: 18611
		// (get) Token: 0x0600C7E7 RID: 51175 RVA: 0x0031DD20 File Offset: 0x0031BF20
		// (set) Token: 0x0600C7E8 RID: 51176 RVA: 0x0031DD3E File Offset: 0x0031BF3E
		public unsafe static uint RIFLES_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048B4 RID: 18612
		// (get) Token: 0x0600C7E9 RID: 51177 RVA: 0x0031DD50 File Offset: 0x0031BF50
		// (set) Token: 0x0600C7EA RID: 51178 RVA: 0x0031DD6E File Offset: 0x0031BF6E
		public unsafe static uint RIFLES_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048B5 RID: 18613
		// (get) Token: 0x0600C7EB RID: 51179 RVA: 0x0031DD80 File Offset: 0x0031BF80
		// (set) Token: 0x0600C7EC RID: 51180 RVA: 0x0031DD9E File Offset: 0x0031BF9E
		public unsafe static uint RIFLES_3P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B6 RID: 18614
		// (get) Token: 0x0600C7ED RID: 51181 RVA: 0x0031DDB0 File Offset: 0x0031BFB0
		// (set) Token: 0x0600C7EE RID: 51182 RVA: 0x0031DDCE File Offset: 0x0031BFCE
		public unsafe static uint RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B7 RID: 18615
		// (get) Token: 0x0600C7EF RID: 51183 RVA: 0x0031DDE0 File Offset: 0x0031BFE0
		// (set) Token: 0x0600C7F0 RID: 51184 RVA: 0x0031DDFE File Offset: 0x0031BFFE
		public unsafe static uint RIFLES_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048B8 RID: 18616
		// (get) Token: 0x0600C7F1 RID: 51185 RVA: 0x0031DE10 File Offset: 0x0031C010
		// (set) Token: 0x0600C7F2 RID: 51186 RVA: 0x0031DE2E File Offset: 0x0031C02E
		public unsafe static uint RIFLES_3P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048B9 RID: 18617
		// (get) Token: 0x0600C7F3 RID: 51187 RVA: 0x0031DE40 File Offset: 0x0031C040
		// (set) Token: 0x0600C7F4 RID: 51188 RVA: 0x0031DE5E File Offset: 0x0031C05E
		public unsafe static uint RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048BA RID: 18618
		// (get) Token: 0x0600C7F5 RID: 51189 RVA: 0x0031DE70 File Offset: 0x0031C070
		// (set) Token: 0x0600C7F6 RID: 51190 RVA: 0x0031DE8E File Offset: 0x0031C08E
		public unsafe static uint RIFLES_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_RIFLES_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048BB RID: 18619
		// (get) Token: 0x0600C7F7 RID: 51191 RVA: 0x0031DEA0 File Offset: 0x0031C0A0
		// (set) Token: 0x0600C7F8 RID: 51192 RVA: 0x0031DEBE File Offset: 0x0031C0BE
		public unsafe static uint SHOTGUNS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P, (void*)(&value));
			}
		}

		// Token: 0x170048BC RID: 18620
		// (get) Token: 0x0600C7F9 RID: 51193 RVA: 0x0031DED0 File Offset: 0x0031C0D0
		// (set) Token: 0x0600C7FA RID: 51194 RVA: 0x0031DEEE File Offset: 0x0031C0EE
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048BD RID: 18621
		// (get) Token: 0x0600C7FB RID: 51195 RVA: 0x0031DF00 File Offset: 0x0031C100
		// (set) Token: 0x0600C7FC RID: 51196 RVA: 0x0031DF1E File Offset: 0x0031C11E
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048BE RID: 18622
		// (get) Token: 0x0600C7FD RID: 51197 RVA: 0x0031DF30 File Offset: 0x0031C130
		// (set) Token: 0x0600C7FE RID: 51198 RVA: 0x0031DF4E File Offset: 0x0031C14E
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048BF RID: 18623
		// (get) Token: 0x0600C7FF RID: 51199 RVA: 0x0031DF60 File Offset: 0x0031C160
		// (set) Token: 0x0600C800 RID: 51200 RVA: 0x0031DF7E File Offset: 0x0031C17E
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048C0 RID: 18624
		// (get) Token: 0x0600C801 RID: 51201 RVA: 0x0031DF90 File Offset: 0x0031C190
		// (set) Token: 0x0600C802 RID: 51202 RVA: 0x0031DFAE File Offset: 0x0031C1AE
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C1 RID: 18625
		// (get) Token: 0x0600C803 RID: 51203 RVA: 0x0031DFC0 File Offset: 0x0031C1C0
		// (set) Token: 0x0600C804 RID: 51204 RVA: 0x0031DFDE File Offset: 0x0031C1DE
		public unsafe static uint SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C2 RID: 18626
		// (get) Token: 0x0600C805 RID: 51205 RVA: 0x0031DFF0 File Offset: 0x0031C1F0
		// (set) Token: 0x0600C806 RID: 51206 RVA: 0x0031E00E File Offset: 0x0031C20E
		public unsafe static uint SHOTGUNS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048C3 RID: 18627
		// (get) Token: 0x0600C807 RID: 51207 RVA: 0x0031E020 File Offset: 0x0031C220
		// (set) Token: 0x0600C808 RID: 51208 RVA: 0x0031E03E File Offset: 0x0031C23E
		public unsafe static uint SHOTGUNS_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048C4 RID: 18628
		// (get) Token: 0x0600C809 RID: 51209 RVA: 0x0031E050 File Offset: 0x0031C250
		// (set) Token: 0x0600C80A RID: 51210 RVA: 0x0031E06E File Offset: 0x0031C26E
		public unsafe static uint SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C5 RID: 18629
		// (get) Token: 0x0600C80B RID: 51211 RVA: 0x0031E080 File Offset: 0x0031C280
		// (set) Token: 0x0600C80C RID: 51212 RVA: 0x0031E09E File Offset: 0x0031C29E
		public unsafe static uint SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C6 RID: 18630
		// (get) Token: 0x0600C80D RID: 51213 RVA: 0x0031E0B0 File Offset: 0x0031C2B0
		// (set) Token: 0x0600C80E RID: 51214 RVA: 0x0031E0CE File Offset: 0x0031C2CE
		public unsafe static uint SHOTGUNS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048C7 RID: 18631
		// (get) Token: 0x0600C80F RID: 51215 RVA: 0x0031E0E0 File Offset: 0x0031C2E0
		// (set) Token: 0x0600C810 RID: 51216 RVA: 0x0031E0FE File Offset: 0x0031C2FE
		public unsafe static uint SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C8 RID: 18632
		// (get) Token: 0x0600C811 RID: 51217 RVA: 0x0031E110 File Offset: 0x0031C310
		// (set) Token: 0x0600C812 RID: 51218 RVA: 0x0031E12E File Offset: 0x0031C32E
		public unsafe static uint SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048C9 RID: 18633
		// (get) Token: 0x0600C813 RID: 51219 RVA: 0x0031E140 File Offset: 0x0031C340
		// (set) Token: 0x0600C814 RID: 51220 RVA: 0x0031E15E File Offset: 0x0031C35E
		public unsafe static uint SHOTGUNS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048CA RID: 18634
		// (get) Token: 0x0600C815 RID: 51221 RVA: 0x0031E170 File Offset: 0x0031C370
		// (set) Token: 0x0600C816 RID: 51222 RVA: 0x0031E18E File Offset: 0x0031C38E
		public unsafe static uint SHOTGUNS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P, (void*)(&value));
			}
		}

		// Token: 0x170048CB RID: 18635
		// (get) Token: 0x0600C817 RID: 51223 RVA: 0x0031E1A0 File Offset: 0x0031C3A0
		// (set) Token: 0x0600C818 RID: 51224 RVA: 0x0031E1BE File Offset: 0x0031C3BE
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048CC RID: 18636
		// (get) Token: 0x0600C819 RID: 51225 RVA: 0x0031E1D0 File Offset: 0x0031C3D0
		// (set) Token: 0x0600C81A RID: 51226 RVA: 0x0031E1EE File Offset: 0x0031C3EE
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048CD RID: 18637
		// (get) Token: 0x0600C81B RID: 51227 RVA: 0x0031E200 File Offset: 0x0031C400
		// (set) Token: 0x0600C81C RID: 51228 RVA: 0x0031E21E File Offset: 0x0031C41E
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048CE RID: 18638
		// (get) Token: 0x0600C81D RID: 51229 RVA: 0x0031E230 File Offset: 0x0031C430
		// (set) Token: 0x0600C81E RID: 51230 RVA: 0x0031E24E File Offset: 0x0031C44E
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048CF RID: 18639
		// (get) Token: 0x0600C81F RID: 51231 RVA: 0x0031E260 File Offset: 0x0031C460
		// (set) Token: 0x0600C820 RID: 51232 RVA: 0x0031E27E File Offset: 0x0031C47E
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D0 RID: 18640
		// (get) Token: 0x0600C821 RID: 51233 RVA: 0x0031E290 File Offset: 0x0031C490
		// (set) Token: 0x0600C822 RID: 51234 RVA: 0x0031E2AE File Offset: 0x0031C4AE
		public unsafe static uint SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D1 RID: 18641
		// (get) Token: 0x0600C823 RID: 51235 RVA: 0x0031E2C0 File Offset: 0x0031C4C0
		// (set) Token: 0x0600C824 RID: 51236 RVA: 0x0031E2DE File Offset: 0x0031C4DE
		public unsafe static uint SHOTGUNS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048D2 RID: 18642
		// (get) Token: 0x0600C825 RID: 51237 RVA: 0x0031E2F0 File Offset: 0x0031C4F0
		// (set) Token: 0x0600C826 RID: 51238 RVA: 0x0031E30E File Offset: 0x0031C50E
		public unsafe static uint SHOTGUNS_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048D3 RID: 18643
		// (get) Token: 0x0600C827 RID: 51239 RVA: 0x0031E320 File Offset: 0x0031C520
		// (set) Token: 0x0600C828 RID: 51240 RVA: 0x0031E33E File Offset: 0x0031C53E
		public unsafe static uint SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D4 RID: 18644
		// (get) Token: 0x0600C829 RID: 51241 RVA: 0x0031E350 File Offset: 0x0031C550
		// (set) Token: 0x0600C82A RID: 51242 RVA: 0x0031E36E File Offset: 0x0031C56E
		public unsafe static uint SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D5 RID: 18645
		// (get) Token: 0x0600C82B RID: 51243 RVA: 0x0031E380 File Offset: 0x0031C580
		// (set) Token: 0x0600C82C RID: 51244 RVA: 0x0031E39E File Offset: 0x0031C59E
		public unsafe static uint SHOTGUNS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048D6 RID: 18646
		// (get) Token: 0x0600C82D RID: 51245 RVA: 0x0031E3B0 File Offset: 0x0031C5B0
		// (set) Token: 0x0600C82E RID: 51246 RVA: 0x0031E3CE File Offset: 0x0031C5CE
		public unsafe static uint SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D7 RID: 18647
		// (get) Token: 0x0600C82F RID: 51247 RVA: 0x0031E3E0 File Offset: 0x0031C5E0
		// (set) Token: 0x0600C830 RID: 51248 RVA: 0x0031E3FE File Offset: 0x0031C5FE
		public unsafe static uint SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048D8 RID: 18648
		// (get) Token: 0x0600C831 RID: 51249 RVA: 0x0031E410 File Offset: 0x0031C610
		// (set) Token: 0x0600C832 RID: 51250 RVA: 0x0031E42E File Offset: 0x0031C62E
		public unsafe static uint SHOTGUNS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SHOTGUNS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048D9 RID: 18649
		// (get) Token: 0x0600C833 RID: 51251 RVA: 0x0031E440 File Offset: 0x0031C640
		// (set) Token: 0x0600C834 RID: 51252 RVA: 0x0031E45E File Offset: 0x0031C65E
		public unsafe static uint SMGS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P, (void*)(&value));
			}
		}

		// Token: 0x170048DA RID: 18650
		// (get) Token: 0x0600C835 RID: 51253 RVA: 0x0031E470 File Offset: 0x0031C670
		// (set) Token: 0x0600C836 RID: 51254 RVA: 0x0031E48E File Offset: 0x0031C68E
		public unsafe static uint SMGS_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048DB RID: 18651
		// (get) Token: 0x0600C837 RID: 51255 RVA: 0x0031E4A0 File Offset: 0x0031C6A0
		// (set) Token: 0x0600C838 RID: 51256 RVA: 0x0031E4BE File Offset: 0x0031C6BE
		public unsafe static uint SMGS_1P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048DC RID: 18652
		// (get) Token: 0x0600C839 RID: 51257 RVA: 0x0031E4D0 File Offset: 0x0031C6D0
		// (set) Token: 0x0600C83A RID: 51258 RVA: 0x0031E4EE File Offset: 0x0031C6EE
		public unsafe static uint SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048DD RID: 18653
		// (get) Token: 0x0600C83B RID: 51259 RVA: 0x0031E500 File Offset: 0x0031C700
		// (set) Token: 0x0600C83C RID: 51260 RVA: 0x0031E51E File Offset: 0x0031C71E
		public unsafe static uint SMGS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048DE RID: 18654
		// (get) Token: 0x0600C83D RID: 51261 RVA: 0x0031E530 File Offset: 0x0031C730
		// (set) Token: 0x0600C83E RID: 51262 RVA: 0x0031E54E File Offset: 0x0031C74E
		public unsafe static uint SMGS_1P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048DF RID: 18655
		// (get) Token: 0x0600C83F RID: 51263 RVA: 0x0031E560 File Offset: 0x0031C760
		// (set) Token: 0x0600C840 RID: 51264 RVA: 0x0031E57E File Offset: 0x0031C77E
		public unsafe static uint SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048E0 RID: 18656
		// (get) Token: 0x0600C841 RID: 51265 RVA: 0x0031E590 File Offset: 0x0031C790
		// (set) Token: 0x0600C842 RID: 51266 RVA: 0x0031E5AE File Offset: 0x0031C7AE
		public unsafe static uint SMGS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048E1 RID: 18657
		// (get) Token: 0x0600C843 RID: 51267 RVA: 0x0031E5C0 File Offset: 0x0031C7C0
		// (set) Token: 0x0600C844 RID: 51268 RVA: 0x0031E5DE File Offset: 0x0031C7DE
		public unsafe static uint SMGS_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048E2 RID: 18658
		// (get) Token: 0x0600C845 RID: 51269 RVA: 0x0031E5F0 File Offset: 0x0031C7F0
		// (set) Token: 0x0600C846 RID: 51270 RVA: 0x0031E60E File Offset: 0x0031C80E
		public unsafe static uint SMGS_1P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048E3 RID: 18659
		// (get) Token: 0x0600C847 RID: 51271 RVA: 0x0031E620 File Offset: 0x0031C820
		// (set) Token: 0x0600C848 RID: 51272 RVA: 0x0031E63E File Offset: 0x0031C83E
		public unsafe static uint SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048E4 RID: 18660
		// (get) Token: 0x0600C849 RID: 51273 RVA: 0x0031E650 File Offset: 0x0031C850
		// (set) Token: 0x0600C84A RID: 51274 RVA: 0x0031E66E File Offset: 0x0031C86E
		public unsafe static uint SMGS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048E5 RID: 18661
		// (get) Token: 0x0600C84B RID: 51275 RVA: 0x0031E680 File Offset: 0x0031C880
		// (set) Token: 0x0600C84C RID: 51276 RVA: 0x0031E69E File Offset: 0x0031C89E
		public unsafe static uint SMGS_1P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048E6 RID: 18662
		// (get) Token: 0x0600C84D RID: 51277 RVA: 0x0031E6B0 File Offset: 0x0031C8B0
		// (set) Token: 0x0600C84E RID: 51278 RVA: 0x0031E6CE File Offset: 0x0031C8CE
		public unsafe static uint SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048E7 RID: 18663
		// (get) Token: 0x0600C84F RID: 51279 RVA: 0x0031E6E0 File Offset: 0x0031C8E0
		// (set) Token: 0x0600C850 RID: 51280 RVA: 0x0031E6FE File Offset: 0x0031C8FE
		public unsafe static uint SMGS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048E8 RID: 18664
		// (get) Token: 0x0600C851 RID: 51281 RVA: 0x0031E710 File Offset: 0x0031C910
		// (set) Token: 0x0600C852 RID: 51282 RVA: 0x0031E72E File Offset: 0x0031C92E
		public unsafe static uint SMGS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P, (void*)(&value));
			}
		}

		// Token: 0x170048E9 RID: 18665
		// (get) Token: 0x0600C853 RID: 51283 RVA: 0x0031E740 File Offset: 0x0031C940
		// (set) Token: 0x0600C854 RID: 51284 RVA: 0x0031E75E File Offset: 0x0031C95E
		public unsafe static uint SMGS_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048EA RID: 18666
		// (get) Token: 0x0600C855 RID: 51285 RVA: 0x0031E770 File Offset: 0x0031C970
		// (set) Token: 0x0600C856 RID: 51286 RVA: 0x0031E78E File Offset: 0x0031C98E
		public unsafe static uint SMGS_3P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048EB RID: 18667
		// (get) Token: 0x0600C857 RID: 51287 RVA: 0x0031E7A0 File Offset: 0x0031C9A0
		// (set) Token: 0x0600C858 RID: 51288 RVA: 0x0031E7BE File Offset: 0x0031C9BE
		public unsafe static uint SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048EC RID: 18668
		// (get) Token: 0x0600C859 RID: 51289 RVA: 0x0031E7D0 File Offset: 0x0031C9D0
		// (set) Token: 0x0600C85A RID: 51290 RVA: 0x0031E7EE File Offset: 0x0031C9EE
		public unsafe static uint SMGS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048ED RID: 18669
		// (get) Token: 0x0600C85B RID: 51291 RVA: 0x0031E800 File Offset: 0x0031CA00
		// (set) Token: 0x0600C85C RID: 51292 RVA: 0x0031E81E File Offset: 0x0031CA1E
		public unsafe static uint SMGS_3P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048EE RID: 18670
		// (get) Token: 0x0600C85D RID: 51293 RVA: 0x0031E830 File Offset: 0x0031CA30
		// (set) Token: 0x0600C85E RID: 51294 RVA: 0x0031E84E File Offset: 0x0031CA4E
		public unsafe static uint SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048EF RID: 18671
		// (get) Token: 0x0600C85F RID: 51295 RVA: 0x0031E860 File Offset: 0x0031CA60
		// (set) Token: 0x0600C860 RID: 51296 RVA: 0x0031E87E File Offset: 0x0031CA7E
		public unsafe static uint SMGS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048F0 RID: 18672
		// (get) Token: 0x0600C861 RID: 51297 RVA: 0x0031E890 File Offset: 0x0031CA90
		// (set) Token: 0x0600C862 RID: 51298 RVA: 0x0031E8AE File Offset: 0x0031CAAE
		public unsafe static uint SMGS_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048F1 RID: 18673
		// (get) Token: 0x0600C863 RID: 51299 RVA: 0x0031E8C0 File Offset: 0x0031CAC0
		// (set) Token: 0x0600C864 RID: 51300 RVA: 0x0031E8DE File Offset: 0x0031CADE
		public unsafe static uint SMGS_3P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048F2 RID: 18674
		// (get) Token: 0x0600C865 RID: 51301 RVA: 0x0031E8F0 File Offset: 0x0031CAF0
		// (set) Token: 0x0600C866 RID: 51302 RVA: 0x0031E90E File Offset: 0x0031CB0E
		public unsafe static uint SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048F3 RID: 18675
		// (get) Token: 0x0600C867 RID: 51303 RVA: 0x0031E920 File Offset: 0x0031CB20
		// (set) Token: 0x0600C868 RID: 51304 RVA: 0x0031E93E File Offset: 0x0031CB3E
		public unsafe static uint SMGS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048F4 RID: 18676
		// (get) Token: 0x0600C869 RID: 51305 RVA: 0x0031E950 File Offset: 0x0031CB50
		// (set) Token: 0x0600C86A RID: 51306 RVA: 0x0031E96E File Offset: 0x0031CB6E
		public unsafe static uint SMGS_3P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048F5 RID: 18677
		// (get) Token: 0x0600C86B RID: 51307 RVA: 0x0031E980 File Offset: 0x0031CB80
		// (set) Token: 0x0600C86C RID: 51308 RVA: 0x0031E99E File Offset: 0x0031CB9E
		public unsafe static uint SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048F6 RID: 18678
		// (get) Token: 0x0600C86D RID: 51309 RVA: 0x0031E9B0 File Offset: 0x0031CBB0
		// (set) Token: 0x0600C86E RID: 51310 RVA: 0x0031E9CE File Offset: 0x0031CBCE
		public unsafe static uint SMGS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SMGS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048F7 RID: 18679
		// (get) Token: 0x0600C86F RID: 51311 RVA: 0x0031E9E0 File Offset: 0x0031CBE0
		// (set) Token: 0x0600C870 RID: 51312 RVA: 0x0031E9FE File Offset: 0x0031CBFE
		public unsafe static uint SNIPERRIFLES_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P, (void*)(&value));
			}
		}

		// Token: 0x170048F8 RID: 18680
		// (get) Token: 0x0600C871 RID: 51313 RVA: 0x0031EA10 File Offset: 0x0031CC10
		// (set) Token: 0x0600C872 RID: 51314 RVA: 0x0031EA2E File Offset: 0x0031CC2E
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048F9 RID: 18681
		// (get) Token: 0x0600C873 RID: 51315 RVA: 0x0031EA40 File Offset: 0x0031CC40
		// (set) Token: 0x0600C874 RID: 51316 RVA: 0x0031EA5E File Offset: 0x0031CC5E
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048FA RID: 18682
		// (get) Token: 0x0600C875 RID: 51317 RVA: 0x0031EA70 File Offset: 0x0031CC70
		// (set) Token: 0x0600C876 RID: 51318 RVA: 0x0031EA8E File Offset: 0x0031CC8E
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048FB RID: 18683
		// (get) Token: 0x0600C877 RID: 51319 RVA: 0x0031EAA0 File Offset: 0x0031CCA0
		// (set) Token: 0x0600C878 RID: 51320 RVA: 0x0031EABE File Offset: 0x0031CCBE
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x170048FC RID: 18684
		// (get) Token: 0x0600C879 RID: 51321 RVA: 0x0031EAD0 File Offset: 0x0031CCD0
		// (set) Token: 0x0600C87A RID: 51322 RVA: 0x0031EAEE File Offset: 0x0031CCEE
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048FD RID: 18685
		// (get) Token: 0x0600C87B RID: 51323 RVA: 0x0031EB00 File Offset: 0x0031CD00
		// (set) Token: 0x0600C87C RID: 51324 RVA: 0x0031EB1E File Offset: 0x0031CD1E
		public unsafe static uint SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x170048FE RID: 18686
		// (get) Token: 0x0600C87D RID: 51325 RVA: 0x0031EB30 File Offset: 0x0031CD30
		// (set) Token: 0x0600C87E RID: 51326 RVA: 0x0031EB4E File Offset: 0x0031CD4E
		public unsafe static uint SNIPERRIFLES_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x170048FF RID: 18687
		// (get) Token: 0x0600C87F RID: 51327 RVA: 0x0031EB60 File Offset: 0x0031CD60
		// (set) Token: 0x0600C880 RID: 51328 RVA: 0x0031EB7E File Offset: 0x0031CD7E
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004900 RID: 18688
		// (get) Token: 0x0600C881 RID: 51329 RVA: 0x0031EB90 File Offset: 0x0031CD90
		// (set) Token: 0x0600C882 RID: 51330 RVA: 0x0031EBAE File Offset: 0x0031CDAE
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004901 RID: 18689
		// (get) Token: 0x0600C883 RID: 51331 RVA: 0x0031EBC0 File Offset: 0x0031CDC0
		// (set) Token: 0x0600C884 RID: 51332 RVA: 0x0031EBDE File Offset: 0x0031CDDE
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004902 RID: 18690
		// (get) Token: 0x0600C885 RID: 51333 RVA: 0x0031EBF0 File Offset: 0x0031CDF0
		// (set) Token: 0x0600C886 RID: 51334 RVA: 0x0031EC0E File Offset: 0x0031CE0E
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004903 RID: 18691
		// (get) Token: 0x0600C887 RID: 51335 RVA: 0x0031EC20 File Offset: 0x0031CE20
		// (set) Token: 0x0600C888 RID: 51336 RVA: 0x0031EC3E File Offset: 0x0031CE3E
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004904 RID: 18692
		// (get) Token: 0x0600C889 RID: 51337 RVA: 0x0031EC50 File Offset: 0x0031CE50
		// (set) Token: 0x0600C88A RID: 51338 RVA: 0x0031EC6E File Offset: 0x0031CE6E
		public unsafe static uint SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004905 RID: 18693
		// (get) Token: 0x0600C88B RID: 51339 RVA: 0x0031EC80 File Offset: 0x0031CE80
		// (set) Token: 0x0600C88C RID: 51340 RVA: 0x0031EC9E File Offset: 0x0031CE9E
		public unsafe static uint SNIPERRIFLES_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004906 RID: 18694
		// (get) Token: 0x0600C88D RID: 51341 RVA: 0x0031ECB0 File Offset: 0x0031CEB0
		// (set) Token: 0x0600C88E RID: 51342 RVA: 0x0031ECCE File Offset: 0x0031CECE
		public unsafe static uint SNIPERRIFLES_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P, (void*)(&value));
			}
		}

		// Token: 0x17004907 RID: 18695
		// (get) Token: 0x0600C88F RID: 51343 RVA: 0x0031ECE0 File Offset: 0x0031CEE0
		// (set) Token: 0x0600C890 RID: 51344 RVA: 0x0031ECFE File Offset: 0x0031CEFE
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004908 RID: 18696
		// (get) Token: 0x0600C891 RID: 51345 RVA: 0x0031ED10 File Offset: 0x0031CF10
		// (set) Token: 0x0600C892 RID: 51346 RVA: 0x0031ED2E File Offset: 0x0031CF2E
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004909 RID: 18697
		// (get) Token: 0x0600C893 RID: 51347 RVA: 0x0031ED40 File Offset: 0x0031CF40
		// (set) Token: 0x0600C894 RID: 51348 RVA: 0x0031ED5E File Offset: 0x0031CF5E
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700490A RID: 18698
		// (get) Token: 0x0600C895 RID: 51349 RVA: 0x0031ED70 File Offset: 0x0031CF70
		// (set) Token: 0x0600C896 RID: 51350 RVA: 0x0031ED8E File Offset: 0x0031CF8E
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700490B RID: 18699
		// (get) Token: 0x0600C897 RID: 51351 RVA: 0x0031EDA0 File Offset: 0x0031CFA0
		// (set) Token: 0x0600C898 RID: 51352 RVA: 0x0031EDBE File Offset: 0x0031CFBE
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700490C RID: 18700
		// (get) Token: 0x0600C899 RID: 51353 RVA: 0x0031EDD0 File Offset: 0x0031CFD0
		// (set) Token: 0x0600C89A RID: 51354 RVA: 0x0031EDEE File Offset: 0x0031CFEE
		public unsafe static uint SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x1700490D RID: 18701
		// (get) Token: 0x0600C89B RID: 51355 RVA: 0x0031EE00 File Offset: 0x0031D000
		// (set) Token: 0x0600C89C RID: 51356 RVA: 0x0031EE1E File Offset: 0x0031D01E
		public unsafe static uint SNIPERRIFLES_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700490E RID: 18702
		// (get) Token: 0x0600C89D RID: 51357 RVA: 0x0031EE30 File Offset: 0x0031D030
		// (set) Token: 0x0600C89E RID: 51358 RVA: 0x0031EE4E File Offset: 0x0031D04E
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700490F RID: 18703
		// (get) Token: 0x0600C89F RID: 51359 RVA: 0x0031EE60 File Offset: 0x0031D060
		// (set) Token: 0x0600C8A0 RID: 51360 RVA: 0x0031EE7E File Offset: 0x0031D07E
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004910 RID: 18704
		// (get) Token: 0x0600C8A1 RID: 51361 RVA: 0x0031EE90 File Offset: 0x0031D090
		// (set) Token: 0x0600C8A2 RID: 51362 RVA: 0x0031EEAE File Offset: 0x0031D0AE
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004911 RID: 18705
		// (get) Token: 0x0600C8A3 RID: 51363 RVA: 0x0031EEC0 File Offset: 0x0031D0C0
		// (set) Token: 0x0600C8A4 RID: 51364 RVA: 0x0031EEDE File Offset: 0x0031D0DE
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004912 RID: 18706
		// (get) Token: 0x0600C8A5 RID: 51365 RVA: 0x0031EEF0 File Offset: 0x0031D0F0
		// (set) Token: 0x0600C8A6 RID: 51366 RVA: 0x0031EF0E File Offset: 0x0031D10E
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004913 RID: 18707
		// (get) Token: 0x0600C8A7 RID: 51367 RVA: 0x0031EF20 File Offset: 0x0031D120
		// (set) Token: 0x0600C8A8 RID: 51368 RVA: 0x0031EF3E File Offset: 0x0031D13E
		public unsafe static uint SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED, (void*)(&value));
			}
		}

		// Token: 0x17004914 RID: 18708
		// (get) Token: 0x0600C8A9 RID: 51369 RVA: 0x0031EF50 File Offset: 0x0031D150
		// (set) Token: 0x0600C8AA RID: 51370 RVA: 0x0031EF6E File Offset: 0x0031D16E
		public unsafe static uint SNIPERRIFLES_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SNIPERRIFLES_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004915 RID: 18709
		// (get) Token: 0x0600C8AB RID: 51371 RVA: 0x0031EF80 File Offset: 0x0031D180
		// (set) Token: 0x0600C8AC RID: 51372 RVA: 0x0031EF9E File Offset: 0x0031D19E
		public unsafe static uint SPECIALS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P, (void*)(&value));
			}
		}

		// Token: 0x17004916 RID: 18710
		// (get) Token: 0x0600C8AD RID: 51373 RVA: 0x0031EFB0 File Offset: 0x0031D1B0
		// (set) Token: 0x0600C8AE RID: 51374 RVA: 0x0031EFCE File Offset: 0x0031D1CE
		public unsafe static uint SPECIALS_1P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004917 RID: 18711
		// (get) Token: 0x0600C8AF RID: 51375 RVA: 0x0031EFE0 File Offset: 0x0031D1E0
		// (set) Token: 0x0600C8B0 RID: 51376 RVA: 0x0031EFFE File Offset: 0x0031D1FE
		public unsafe static uint SPECIALS_1P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004918 RID: 18712
		// (get) Token: 0x0600C8B1 RID: 51377 RVA: 0x0031F010 File Offset: 0x0031D210
		// (set) Token: 0x0600C8B2 RID: 51378 RVA: 0x0031F02E File Offset: 0x0031D22E
		public unsafe static uint SPECIALS_1P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004919 RID: 18713
		// (get) Token: 0x0600C8B3 RID: 51379 RVA: 0x0031F040 File Offset: 0x0031D240
		// (set) Token: 0x0600C8B4 RID: 51380 RVA: 0x0031F05E File Offset: 0x0031D25E
		public unsafe static uint SPECIALS_1P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700491A RID: 18714
		// (get) Token: 0x0600C8B5 RID: 51381 RVA: 0x0031F070 File Offset: 0x0031D270
		// (set) Token: 0x0600C8B6 RID: 51382 RVA: 0x0031F08E File Offset: 0x0031D28E
		public unsafe static uint SPECIALS_1P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700491B RID: 18715
		// (get) Token: 0x0600C8B7 RID: 51383 RVA: 0x0031F0A0 File Offset: 0x0031D2A0
		// (set) Token: 0x0600C8B8 RID: 51384 RVA: 0x0031F0BE File Offset: 0x0031D2BE
		public unsafe static uint SPECIALS_1P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_1P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700491C RID: 18716
		// (get) Token: 0x0600C8B9 RID: 51385 RVA: 0x0031F0D0 File Offset: 0x0031D2D0
		// (set) Token: 0x0600C8BA RID: 51386 RVA: 0x0031F0EE File Offset: 0x0031D2EE
		public unsafe static uint SPECIALS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P, (void*)(&value));
			}
		}

		// Token: 0x1700491D RID: 18717
		// (get) Token: 0x0600C8BB RID: 51387 RVA: 0x0031F100 File Offset: 0x0031D300
		// (set) Token: 0x0600C8BC RID: 51388 RVA: 0x0031F11E File Offset: 0x0031D31E
		public unsafe static uint SPECIALS_3P_EXTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x1700491E RID: 18718
		// (get) Token: 0x0600C8BD RID: 51389 RVA: 0x0031F130 File Offset: 0x0031D330
		// (set) Token: 0x0600C8BE RID: 51390 RVA: 0x0031F14E File Offset: 0x0031D34E
		public unsafe static uint SPECIALS_3P_EXTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x1700491F RID: 18719
		// (get) Token: 0x0600C8BF RID: 51391 RVA: 0x0031F160 File Offset: 0x0031D360
		// (set) Token: 0x0600C8C0 RID: 51392 RVA: 0x0031F17E File Offset: 0x0031D37E
		public unsafe static uint SPECIALS_3P_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004920 RID: 18720
		// (get) Token: 0x0600C8C1 RID: 51393 RVA: 0x0031F190 File Offset: 0x0031D390
		// (set) Token: 0x0600C8C2 RID: 51394 RVA: 0x0031F1AE File Offset: 0x0031D3AE
		public unsafe static uint SPECIALS_3P_INTERIOR_FIRE
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_FIRE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_FIRE, (void*)(&value));
			}
		}

		// Token: 0x17004921 RID: 18721
		// (get) Token: 0x0600C8C3 RID: 51395 RVA: 0x0031F1C0 File Offset: 0x0031D3C0
		// (set) Token: 0x0600C8C4 RID: 51396 RVA: 0x0031F1DE File Offset: 0x0031D3DE
		public unsafe static uint SPECIALS_3P_INTERIOR_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004922 RID: 18722
		// (get) Token: 0x0600C8C5 RID: 51397 RVA: 0x0031F1F0 File Offset: 0x0031D3F0
		// (set) Token: 0x0600C8C6 RID: 51398 RVA: 0x0031F20E File Offset: 0x0031D40E
		public unsafe static uint SPECIALS_3P_TAILS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_TAILS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_SPECIALS_3P_TAILS, (void*)(&value));
			}
		}

		// Token: 0x17004923 RID: 18723
		// (get) Token: 0x0600C8C7 RID: 51399 RVA: 0x0031F220 File Offset: 0x0031D420
		// (set) Token: 0x0600C8C8 RID: 51400 RVA: 0x0031F23E File Offset: 0x0031D43E
		public unsafe static uint UI
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_UI, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_UI, (void*)(&value));
			}
		}

		// Token: 0x17004924 RID: 18724
		// (get) Token: 0x0600C8C9 RID: 51401 RVA: 0x0031F250 File Offset: 0x0031D450
		// (set) Token: 0x0600C8CA RID: 51402 RVA: 0x0031F26E File Offset: 0x0031D46E
		public unsafe static uint VEHICLES
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_VEHICLES, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_VEHICLES, (void*)(&value));
			}
		}

		// Token: 0x17004925 RID: 18725
		// (get) Token: 0x0600C8CB RID: 51403 RVA: 0x0031F280 File Offset: 0x0031D480
		// (set) Token: 0x0600C8CC RID: 51404 RVA: 0x0031F29E File Offset: 0x0031D49E
		public unsafe static uint VO
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_VO, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_VO, (void*)(&value));
			}
		}

		// Token: 0x17004926 RID: 18726
		// (get) Token: 0x0600C8CD RID: 51405 RVA: 0x0031F2B0 File Offset: 0x0031D4B0
		// (set) Token: 0x0600C8CE RID: 51406 RVA: 0x0031F2CE File Offset: 0x0031D4CE
		public unsafe static uint VOIP
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_VOIP, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_VOIP, (void*)(&value));
			}
		}

		// Token: 0x17004927 RID: 18727
		// (get) Token: 0x0600C8CF RID: 51407 RVA: 0x0031F2E0 File Offset: 0x0031D4E0
		// (set) Token: 0x0600C8D0 RID: 51408 RVA: 0x0031F2FE File Offset: 0x0031D4FE
		public unsafe static uint WEAPON_SIDECHAIN
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_WEAPON_SIDECHAIN, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_WEAPON_SIDECHAIN, (void*)(&value));
			}
		}

		// Token: 0x17004928 RID: 18728
		// (get) Token: 0x0600C8D1 RID: 51409 RVA: 0x0031F310 File Offset: 0x0031D510
		// (set) Token: 0x0600C8D2 RID: 51410 RVA: 0x0031F32E File Offset: 0x0031D52E
		public unsafe static uint WEAPONS
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_WEAPONS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_WEAPONS, (void*)(&value));
			}
		}

		// Token: 0x17004929 RID: 18729
		// (get) Token: 0x0600C8D3 RID: 51411 RVA: 0x0031F340 File Offset: 0x0031D540
		// (set) Token: 0x0600C8D4 RID: 51412 RVA: 0x0031F35E File Offset: 0x0031D55E
		public unsafe static uint WEAPONS_1P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_WEAPONS_1P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_WEAPONS_1P, (void*)(&value));
			}
		}

		// Token: 0x1700492A RID: 18730
		// (get) Token: 0x0600C8D5 RID: 51413 RVA: 0x0031F370 File Offset: 0x0031D570
		// (set) Token: 0x0600C8D6 RID: 51414 RVA: 0x0031F38E File Offset: 0x0031D58E
		public unsafe static uint WEAPONS_3P
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(BUSSES.NativeFieldInfoPtr_WEAPONS_3P, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BUSSES.NativeFieldInfoPtr_WEAPONS_3P, (void*)(&value));
			}
		}

		// Token: 0x04007E05 RID: 32261
		private static readonly IntPtr NativeFieldInfoPtr__1P;

		// Token: 0x04007E06 RID: 32262
		private static readonly IntPtr NativeFieldInfoPtr__2D;

		// Token: 0x04007E07 RID: 32263
		private static readonly IntPtr NativeFieldInfoPtr__2D_CC;

		// Token: 0x04007E08 RID: 32264
		private static readonly IntPtr NativeFieldInfoPtr__3D;

		// Token: 0x04007E09 RID: 32265
		private static readonly IntPtr NativeFieldInfoPtr__3D_CC;

		// Token: 0x04007E0A RID: 32266
		private static readonly IntPtr NativeFieldInfoPtr__3P;

		// Token: 0x04007E0B RID: 32267
		private static readonly IntPtr NativeFieldInfoPtr_AMBIENCE;

		// Token: 0x04007E0C RID: 32268
		private static readonly IntPtr NativeFieldInfoPtr_AMBIENCE_CC;

		// Token: 0x04007E0D RID: 32269
		private static readonly IntPtr NativeFieldInfoPtr_AURO;

		// Token: 0x04007E0E RID: 32270
		private static readonly IntPtr NativeFieldInfoPtr_BREATH;

		// Token: 0x04007E0F RID: 32271
		private static readonly IntPtr NativeFieldInfoPtr_CHARACTER;

		// Token: 0x04007E10 RID: 32272
		private static readonly IntPtr NativeFieldInfoPtr_DEFAULT;

		// Token: 0x04007E11 RID: 32273
		private static readonly IntPtr NativeFieldInfoPtr_DRY_MIX;

		// Token: 0x04007E12 RID: 32274
		private static readonly IntPtr NativeFieldInfoPtr_EFFECTS;

		// Token: 0x04007E13 RID: 32275
		private static readonly IntPtr NativeFieldInfoPtr_EXPLOSIVES;

		// Token: 0x04007E14 RID: 32276
		private static readonly IntPtr NativeFieldInfoPtr_FX;

		// Token: 0x04007E15 RID: 32277
		private static readonly IntPtr NativeFieldInfoPtr_GAME;

		// Token: 0x04007E16 RID: 32278
		private static readonly IntPtr NativeFieldInfoPtr_GAMEPLAY;

		// Token: 0x04007E17 RID: 32279
		private static readonly IntPtr NativeFieldInfoPtr_GEAR;

		// Token: 0x04007E18 RID: 32280
		private static readonly IntPtr NativeFieldInfoPtr_HOA;

		// Token: 0x04007E19 RID: 32281
		private static readonly IntPtr NativeFieldInfoPtr_IMPACTS;

		// Token: 0x04007E1A RID: 32282
		private static readonly IntPtr NativeFieldInfoPtr_INDOOR;

		// Token: 0x04007E1B RID: 32283
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P;

		// Token: 0x04007E1C RID: 32284
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_FIRE;

		// Token: 0x04007E1D RID: 32285
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_EXTERIOR_TAILS;

		// Token: 0x04007E1E RID: 32286
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_FIRE;

		// Token: 0x04007E1F RID: 32287
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_FIRE;

		// Token: 0x04007E20 RID: 32288
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_INTERIOR_TAILS;

		// Token: 0x04007E21 RID: 32289
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_1P_TAILS;

		// Token: 0x04007E22 RID: 32290
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P;

		// Token: 0x04007E23 RID: 32291
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_FIRE;

		// Token: 0x04007E24 RID: 32292
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_EXTERIOR_TAILS;

		// Token: 0x04007E25 RID: 32293
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_FIRE;

		// Token: 0x04007E26 RID: 32294
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_FIRE;

		// Token: 0x04007E27 RID: 32295
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_INTERIOR_TAILS;

		// Token: 0x04007E28 RID: 32296
		private static readonly IntPtr NativeFieldInfoPtr_LAUNCHERS_3P_TAILS;

		// Token: 0x04007E29 RID: 32297
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P;

		// Token: 0x04007E2A RID: 32298
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_EXTERIOR_FIRE;

		// Token: 0x04007E2B RID: 32299
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_EXTERIOR_TAILS;

		// Token: 0x04007E2C RID: 32300
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_FIRE;

		// Token: 0x04007E2D RID: 32301
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_INTERIOR_FIRE;

		// Token: 0x04007E2E RID: 32302
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_INTERIOR_TAILS;

		// Token: 0x04007E2F RID: 32303
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_1P_TAILS;

		// Token: 0x04007E30 RID: 32304
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P;

		// Token: 0x04007E31 RID: 32305
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_EXTERIOR_FIRE;

		// Token: 0x04007E32 RID: 32306
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_EXTERIOR_TAILS;

		// Token: 0x04007E33 RID: 32307
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_FIRE;

		// Token: 0x04007E34 RID: 32308
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_INTERIOR_FIRE;

		// Token: 0x04007E35 RID: 32309
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_INTERIOR_TAILS;

		// Token: 0x04007E36 RID: 32310
		private static readonly IntPtr NativeFieldInfoPtr_LMGS_3P_TAILS;

		// Token: 0x04007E37 RID: 32311
		private static readonly IntPtr NativeFieldInfoPtr_MASTER_AUDIO_BUS;

		// Token: 0x04007E38 RID: 32312
		private static readonly IntPtr NativeFieldInfoPtr_MECH_3P;

		// Token: 0x04007E39 RID: 32313
		private static readonly IntPtr NativeFieldInfoPtr_MIXING_PRESETS_1;

		// Token: 0x04007E3A RID: 32314
		private static readonly IntPtr NativeFieldInfoPtr_MIXING_PRESETS_2;

		// Token: 0x04007E3B RID: 32315
		private static readonly IntPtr NativeFieldInfoPtr_MUSIC;

		// Token: 0x04007E3C RID: 32316
		private static readonly IntPtr NativeFieldInfoPtr_NO_OUTPUT;

		// Token: 0x04007E3D RID: 32317
		private static readonly IntPtr NativeFieldInfoPtr_NON_FX;

		// Token: 0x04007E3E RID: 32318
		private static readonly IntPtr NativeFieldInfoPtr_OUTDOOR;

		// Token: 0x04007E3F RID: 32319
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P;

		// Token: 0x04007E40 RID: 32320
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_EXTERIOR_TAILS;

		// Token: 0x04007E41 RID: 32321
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE;

		// Token: 0x04007E42 RID: 32322
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED;

		// Token: 0x04007E43 RID: 32323
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_EXTERIOR;

		// Token: 0x04007E44 RID: 32324
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_SUPPRESSED_INTERIOR;

		// Token: 0x04007E45 RID: 32325
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED;

		// Token: 0x04007E46 RID: 32326
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_EXTERIOR;

		// Token: 0x04007E47 RID: 32327
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_FIRE_UNSUPPRESSED_INTERIOR;

		// Token: 0x04007E48 RID: 32328
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_INTERIOR_TAILS;

		// Token: 0x04007E49 RID: 32329
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_TAILS;

		// Token: 0x04007E4A RID: 32330
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_SUPPRESSED;

		// Token: 0x04007E4B RID: 32331
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_TAILS_EXTERIOR_UNSUPPRESSED;

		// Token: 0x04007E4C RID: 32332
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_SUPPRESSED;

		// Token: 0x04007E4D RID: 32333
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_1P_TAILS_INTERIOR_UNSUPPRESSED;

		// Token: 0x04007E4E RID: 32334
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P;

		// Token: 0x04007E4F RID: 32335
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_EXTERIOR_TAILS;

		// Token: 0x04007E50 RID: 32336
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE;

		// Token: 0x04007E51 RID: 32337
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED;

		// Token: 0x04007E52 RID: 32338
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_EXTERIOR;

		// Token: 0x04007E53 RID: 32339
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_SUPPRESSED_INTERIOR;

		// Token: 0x04007E54 RID: 32340
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED;

		// Token: 0x04007E55 RID: 32341
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_EXTERIOR;

		// Token: 0x04007E56 RID: 32342
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_FIRE_UNSUPPRESSED_INTERIOR;

		// Token: 0x04007E57 RID: 32343
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_INTERIOR_TAILS;

		// Token: 0x04007E58 RID: 32344
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_TAILS;

		// Token: 0x04007E59 RID: 32345
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_SUPPRESSED;

		// Token: 0x04007E5A RID: 32346
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_TAILS_EXTERIOR_UNSUPPRESSED;

		// Token: 0x04007E5B RID: 32347
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_SUPPRESSED;

		// Token: 0x04007E5C RID: 32348
		private static readonly IntPtr NativeFieldInfoPtr_PISTOLS_3P_TAILS_INTERIOR_UNSUPPRESSED;

		// Token: 0x04007E5D RID: 32349
		private static readonly IntPtr NativeFieldInfoPtr_REVERB;

		// Token: 0x04007E5E RID: 32350
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P;

		// Token: 0x04007E5F RID: 32351
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE;

		// Token: 0x04007E60 RID: 32352
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E61 RID: 32353
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E62 RID: 32354
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS;

		// Token: 0x04007E63 RID: 32355
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E64 RID: 32356
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E65 RID: 32357
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_FIRE;

		// Token: 0x04007E66 RID: 32358
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE;

		// Token: 0x04007E67 RID: 32359
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E68 RID: 32360
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E69 RID: 32361
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS;

		// Token: 0x04007E6A RID: 32362
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E6B RID: 32363
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E6C RID: 32364
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_1P_TAILS;

		// Token: 0x04007E6D RID: 32365
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P;

		// Token: 0x04007E6E RID: 32366
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE;

		// Token: 0x04007E6F RID: 32367
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E70 RID: 32368
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E71 RID: 32369
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS;

		// Token: 0x04007E72 RID: 32370
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E73 RID: 32371
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E74 RID: 32372
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_FIRE;

		// Token: 0x04007E75 RID: 32373
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE;

		// Token: 0x04007E76 RID: 32374
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E77 RID: 32375
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E78 RID: 32376
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS;

		// Token: 0x04007E79 RID: 32377
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E7A RID: 32378
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E7B RID: 32379
		private static readonly IntPtr NativeFieldInfoPtr_RIFLES_3P_TAILS;

		// Token: 0x04007E7C RID: 32380
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P;

		// Token: 0x04007E7D RID: 32381
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE;

		// Token: 0x04007E7E RID: 32382
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E7F RID: 32383
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E80 RID: 32384
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS;

		// Token: 0x04007E81 RID: 32385
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E82 RID: 32386
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E83 RID: 32387
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_FIRE;

		// Token: 0x04007E84 RID: 32388
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE;

		// Token: 0x04007E85 RID: 32389
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E86 RID: 32390
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E87 RID: 32391
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS;

		// Token: 0x04007E88 RID: 32392
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E89 RID: 32393
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E8A RID: 32394
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_1P_TAILS;

		// Token: 0x04007E8B RID: 32395
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P;

		// Token: 0x04007E8C RID: 32396
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE;

		// Token: 0x04007E8D RID: 32397
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E8E RID: 32398
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E8F RID: 32399
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS;

		// Token: 0x04007E90 RID: 32400
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E91 RID: 32401
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E92 RID: 32402
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_FIRE;

		// Token: 0x04007E93 RID: 32403
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE;

		// Token: 0x04007E94 RID: 32404
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E95 RID: 32405
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E96 RID: 32406
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS;

		// Token: 0x04007E97 RID: 32407
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007E98 RID: 32408
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007E99 RID: 32409
		private static readonly IntPtr NativeFieldInfoPtr_SHOTGUNS_3P_TAILS;

		// Token: 0x04007E9A RID: 32410
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P;

		// Token: 0x04007E9B RID: 32411
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE;

		// Token: 0x04007E9C RID: 32412
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007E9D RID: 32413
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007E9E RID: 32414
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS;

		// Token: 0x04007E9F RID: 32415
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EA0 RID: 32416
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EA1 RID: 32417
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_FIRE;

		// Token: 0x04007EA2 RID: 32418
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE;

		// Token: 0x04007EA3 RID: 32419
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007EA4 RID: 32420
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007EA5 RID: 32421
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS;

		// Token: 0x04007EA6 RID: 32422
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EA7 RID: 32423
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EA8 RID: 32424
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_1P_TAILS;

		// Token: 0x04007EA9 RID: 32425
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P;

		// Token: 0x04007EAA RID: 32426
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE;

		// Token: 0x04007EAB RID: 32427
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007EAC RID: 32428
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007EAD RID: 32429
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS;

		// Token: 0x04007EAE RID: 32430
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EAF RID: 32431
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EB0 RID: 32432
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_FIRE;

		// Token: 0x04007EB1 RID: 32433
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE;

		// Token: 0x04007EB2 RID: 32434
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007EB3 RID: 32435
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007EB4 RID: 32436
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS;

		// Token: 0x04007EB5 RID: 32437
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EB6 RID: 32438
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EB7 RID: 32439
		private static readonly IntPtr NativeFieldInfoPtr_SMGS_3P_TAILS;

		// Token: 0x04007EB8 RID: 32440
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P;

		// Token: 0x04007EB9 RID: 32441
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE;

		// Token: 0x04007EBA RID: 32442
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007EBB RID: 32443
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007EBC RID: 32444
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS;

		// Token: 0x04007EBD RID: 32445
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EBE RID: 32446
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EBF RID: 32447
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_FIRE;

		// Token: 0x04007EC0 RID: 32448
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE;

		// Token: 0x04007EC1 RID: 32449
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007EC2 RID: 32450
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007EC3 RID: 32451
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS;

		// Token: 0x04007EC4 RID: 32452
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007EC5 RID: 32453
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007EC6 RID: 32454
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_1P_TAILS;

		// Token: 0x04007EC7 RID: 32455
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P;

		// Token: 0x04007EC8 RID: 32456
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE;

		// Token: 0x04007EC9 RID: 32457
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007ECA RID: 32458
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007ECB RID: 32459
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS;

		// Token: 0x04007ECC RID: 32460
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007ECD RID: 32461
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_EXTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007ECE RID: 32462
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_FIRE;

		// Token: 0x04007ECF RID: 32463
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE;

		// Token: 0x04007ED0 RID: 32464
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_SUPPRESSED;

		// Token: 0x04007ED1 RID: 32465
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_FIRE_UNSUPPRESSED;

		// Token: 0x04007ED2 RID: 32466
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS;

		// Token: 0x04007ED3 RID: 32467
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_SUPPRESSED;

		// Token: 0x04007ED4 RID: 32468
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_INTERIOR_TAILS_UNSUPPRESSED;

		// Token: 0x04007ED5 RID: 32469
		private static readonly IntPtr NativeFieldInfoPtr_SNIPERRIFLES_3P_TAILS;

		// Token: 0x04007ED6 RID: 32470
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P;

		// Token: 0x04007ED7 RID: 32471
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_FIRE;

		// Token: 0x04007ED8 RID: 32472
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_EXTERIOR_TAILS;

		// Token: 0x04007ED9 RID: 32473
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_FIRE;

		// Token: 0x04007EDA RID: 32474
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_FIRE;

		// Token: 0x04007EDB RID: 32475
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_INTERIOR_TAILS;

		// Token: 0x04007EDC RID: 32476
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_1P_TAILS;

		// Token: 0x04007EDD RID: 32477
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P;

		// Token: 0x04007EDE RID: 32478
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_FIRE;

		// Token: 0x04007EDF RID: 32479
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_EXTERIOR_TAILS;

		// Token: 0x04007EE0 RID: 32480
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_FIRE;

		// Token: 0x04007EE1 RID: 32481
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_FIRE;

		// Token: 0x04007EE2 RID: 32482
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_INTERIOR_TAILS;

		// Token: 0x04007EE3 RID: 32483
		private static readonly IntPtr NativeFieldInfoPtr_SPECIALS_3P_TAILS;

		// Token: 0x04007EE4 RID: 32484
		private static readonly IntPtr NativeFieldInfoPtr_UI;

		// Token: 0x04007EE5 RID: 32485
		private static readonly IntPtr NativeFieldInfoPtr_VEHICLES;

		// Token: 0x04007EE6 RID: 32486
		private static readonly IntPtr NativeFieldInfoPtr_VO;

		// Token: 0x04007EE7 RID: 32487
		private static readonly IntPtr NativeFieldInfoPtr_VOIP;

		// Token: 0x04007EE8 RID: 32488
		private static readonly IntPtr NativeFieldInfoPtr_WEAPON_SIDECHAIN;

		// Token: 0x04007EE9 RID: 32489
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONS;

		// Token: 0x04007EEA RID: 32490
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONS_1P;

		// Token: 0x04007EEB RID: 32491
		private static readonly IntPtr NativeFieldInfoPtr_WEAPONS_3P;

		// Token: 0x04007EEC RID: 32492
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
