﻿using System;

// Token: 0x02000166 RID: 358
public enum CasualtyUIState
{
	// Token: 0x04000F7D RID: 3965
	Null,
	// Token: 0x04000F7E RID: 3966
	Clear,
	// Token: 0x04000F7F RID: 3967
	Downed,
	// Token: 0x04000F80 RID: 3968
	Dead,
	// Token: 0x04000F81 RID: 3969
	Debug
}
