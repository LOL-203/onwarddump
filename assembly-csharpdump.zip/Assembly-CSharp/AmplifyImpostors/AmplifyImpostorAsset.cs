﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x02001285 RID: 4741
	public class AmplifyImpostorAsset : ScriptableObject
	{
		// Token: 0x060158D3 RID: 88275 RVA: 0x0056DAA4 File Offset: 0x0056BCA4
		[CallerCount(0)]
		public unsafe AmplifyImpostorAsset() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmplifyImpostorAsset.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060158D4 RID: 88276 RVA: 0x0056DAF0 File Offset: 0x0056BCF0
		// Note: this type is marked as 'beforefieldinit'.
		static AmplifyImpostorAsset()
		{
			Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "AmplifyImpostorAsset");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr);
			AmplifyImpostorAsset.NativeFieldInfoPtr_Material = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "Material");
			AmplifyImpostorAsset.NativeFieldInfoPtr_Mesh = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "Mesh");
			AmplifyImpostorAsset.NativeFieldInfoPtr_Version = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "Version");
			AmplifyImpostorAsset.NativeFieldInfoPtr_ImpostorType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "ImpostorType");
			AmplifyImpostorAsset.NativeFieldInfoPtr_LockedSizes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "LockedSizes");
			AmplifyImpostorAsset.NativeFieldInfoPtr_SelectedSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "SelectedSize");
			AmplifyImpostorAsset.NativeFieldInfoPtr_TexSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "TexSize");
			AmplifyImpostorAsset.NativeFieldInfoPtr_DecoupleAxisFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "DecoupleAxisFrames");
			AmplifyImpostorAsset.NativeFieldInfoPtr_HorizontalFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "HorizontalFrames");
			AmplifyImpostorAsset.NativeFieldInfoPtr_VerticalFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "VerticalFrames");
			AmplifyImpostorAsset.NativeFieldInfoPtr_PixelPadding = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "PixelPadding");
			AmplifyImpostorAsset.NativeFieldInfoPtr_MaxVertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "MaxVertices");
			AmplifyImpostorAsset.NativeFieldInfoPtr_Tolerance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "Tolerance");
			AmplifyImpostorAsset.NativeFieldInfoPtr_NormalScale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "NormalScale");
			AmplifyImpostorAsset.NativeFieldInfoPtr_ShapePoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "ShapePoints");
			AmplifyImpostorAsset.NativeFieldInfoPtr_Preset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "Preset");
			AmplifyImpostorAsset.NativeFieldInfoPtr_OverrideOutput = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, "OverrideOutput");
			AmplifyImpostorAsset.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr, 100690977);
		}

		// Token: 0x060158D5 RID: 88277 RVA: 0x0002DD3C File Offset: 0x0002BF3C
		public AmplifyImpostorAsset(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700797C RID: 31100
		// (get) Token: 0x060158D6 RID: 88278 RVA: 0x0056DC88 File Offset: 0x0056BE88
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmplifyImpostorAsset>.NativeClassPtr));
			}
		}

		// Token: 0x1700797D RID: 31101
		// (get) Token: 0x060158D7 RID: 88279 RVA: 0x0056DC9C File Offset: 0x0056BE9C
		// (set) Token: 0x060158D8 RID: 88280 RVA: 0x0056DCD0 File Offset: 0x0056BED0
		public unsafe Material Material
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Material);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Material(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Material), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700797E RID: 31102
		// (get) Token: 0x060158D9 RID: 88281 RVA: 0x0056DCF8 File Offset: 0x0056BEF8
		// (set) Token: 0x060158DA RID: 88282 RVA: 0x0056DD2C File Offset: 0x0056BF2C
		public unsafe Mesh Mesh
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Mesh);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Mesh(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Mesh), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700797F RID: 31103
		// (get) Token: 0x060158DB RID: 88283 RVA: 0x0056DD54 File Offset: 0x0056BF54
		// (set) Token: 0x060158DC RID: 88284 RVA: 0x0056DD7C File Offset: 0x0056BF7C
		public unsafe int Version
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Version);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Version)) = value;
			}
		}

		// Token: 0x17007980 RID: 31104
		// (get) Token: 0x060158DD RID: 88285 RVA: 0x0056DDA0 File Offset: 0x0056BFA0
		// (set) Token: 0x060158DE RID: 88286 RVA: 0x0056DDC8 File Offset: 0x0056BFC8
		public unsafe ImpostorType ImpostorType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_ImpostorType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_ImpostorType)) = value;
			}
		}

		// Token: 0x17007981 RID: 31105
		// (get) Token: 0x060158DF RID: 88287 RVA: 0x0056DDEC File Offset: 0x0056BFEC
		// (set) Token: 0x060158E0 RID: 88288 RVA: 0x0056DE14 File Offset: 0x0056C014
		public unsafe bool LockedSizes
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_LockedSizes);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_LockedSizes)) = value;
			}
		}

		// Token: 0x17007982 RID: 31106
		// (get) Token: 0x060158E1 RID: 88289 RVA: 0x0056DE38 File Offset: 0x0056C038
		// (set) Token: 0x060158E2 RID: 88290 RVA: 0x0056DE60 File Offset: 0x0056C060
		public unsafe int SelectedSize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_SelectedSize);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_SelectedSize)) = value;
			}
		}

		// Token: 0x17007983 RID: 31107
		// (get) Token: 0x060158E3 RID: 88291 RVA: 0x0056DE84 File Offset: 0x0056C084
		// (set) Token: 0x060158E4 RID: 88292 RVA: 0x0056DEAC File Offset: 0x0056C0AC
		public unsafe Vector2 TexSize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_TexSize);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_TexSize)) = value;
			}
		}

		// Token: 0x17007984 RID: 31108
		// (get) Token: 0x060158E5 RID: 88293 RVA: 0x0056DED0 File Offset: 0x0056C0D0
		// (set) Token: 0x060158E6 RID: 88294 RVA: 0x0056DEF8 File Offset: 0x0056C0F8
		public unsafe bool DecoupleAxisFrames
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_DecoupleAxisFrames);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_DecoupleAxisFrames)) = value;
			}
		}

		// Token: 0x17007985 RID: 31109
		// (get) Token: 0x060158E7 RID: 88295 RVA: 0x0056DF1C File Offset: 0x0056C11C
		// (set) Token: 0x060158E8 RID: 88296 RVA: 0x0056DF44 File Offset: 0x0056C144
		public unsafe int HorizontalFrames
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_HorizontalFrames);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_HorizontalFrames)) = value;
			}
		}

		// Token: 0x17007986 RID: 31110
		// (get) Token: 0x060158E9 RID: 88297 RVA: 0x0056DF68 File Offset: 0x0056C168
		// (set) Token: 0x060158EA RID: 88298 RVA: 0x0056DF90 File Offset: 0x0056C190
		public unsafe int VerticalFrames
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_VerticalFrames);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_VerticalFrames)) = value;
			}
		}

		// Token: 0x17007987 RID: 31111
		// (get) Token: 0x060158EB RID: 88299 RVA: 0x0056DFB4 File Offset: 0x0056C1B4
		// (set) Token: 0x060158EC RID: 88300 RVA: 0x0056DFDC File Offset: 0x0056C1DC
		public unsafe int PixelPadding
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_PixelPadding);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_PixelPadding)) = value;
			}
		}

		// Token: 0x17007988 RID: 31112
		// (get) Token: 0x060158ED RID: 88301 RVA: 0x0056E000 File Offset: 0x0056C200
		// (set) Token: 0x060158EE RID: 88302 RVA: 0x0056E028 File Offset: 0x0056C228
		public unsafe int MaxVertices
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_MaxVertices);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_MaxVertices)) = value;
			}
		}

		// Token: 0x17007989 RID: 31113
		// (get) Token: 0x060158EF RID: 88303 RVA: 0x0056E04C File Offset: 0x0056C24C
		// (set) Token: 0x060158F0 RID: 88304 RVA: 0x0056E074 File Offset: 0x0056C274
		public unsafe float Tolerance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Tolerance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Tolerance)) = value;
			}
		}

		// Token: 0x1700798A RID: 31114
		// (get) Token: 0x060158F1 RID: 88305 RVA: 0x0056E098 File Offset: 0x0056C298
		// (set) Token: 0x060158F2 RID: 88306 RVA: 0x0056E0C0 File Offset: 0x0056C2C0
		public unsafe float NormalScale
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_NormalScale);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_NormalScale)) = value;
			}
		}

		// Token: 0x1700798B RID: 31115
		// (get) Token: 0x060158F3 RID: 88307 RVA: 0x0056E0E4 File Offset: 0x0056C2E4
		// (set) Token: 0x060158F4 RID: 88308 RVA: 0x0056E118 File Offset: 0x0056C318
		public unsafe Il2CppStructArray<Vector2> ShapePoints
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_ShapePoints);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_ShapePoints), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700798C RID: 31116
		// (get) Token: 0x060158F5 RID: 88309 RVA: 0x0056E140 File Offset: 0x0056C340
		// (set) Token: 0x060158F6 RID: 88310 RVA: 0x0056E174 File Offset: 0x0056C374
		public unsafe AmplifyImpostorBakePreset Preset
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Preset);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AmplifyImpostorBakePreset(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_Preset), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700798D RID: 31117
		// (get) Token: 0x060158F7 RID: 88311 RVA: 0x0056E19C File Offset: 0x0056C39C
		// (set) Token: 0x060158F8 RID: 88312 RVA: 0x0056E1D0 File Offset: 0x0056C3D0
		public unsafe List<TextureOutput> OverrideOutput
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_OverrideOutput);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<TextureOutput>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorAsset.NativeFieldInfoPtr_OverrideOutput), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400DD25 RID: 56613
		private static readonly IntPtr NativeFieldInfoPtr_Material;

		// Token: 0x0400DD26 RID: 56614
		private static readonly IntPtr NativeFieldInfoPtr_Mesh;

		// Token: 0x0400DD27 RID: 56615
		private static readonly IntPtr NativeFieldInfoPtr_Version;

		// Token: 0x0400DD28 RID: 56616
		private static readonly IntPtr NativeFieldInfoPtr_ImpostorType;

		// Token: 0x0400DD29 RID: 56617
		private static readonly IntPtr NativeFieldInfoPtr_LockedSizes;

		// Token: 0x0400DD2A RID: 56618
		private static readonly IntPtr NativeFieldInfoPtr_SelectedSize;

		// Token: 0x0400DD2B RID: 56619
		private static readonly IntPtr NativeFieldInfoPtr_TexSize;

		// Token: 0x0400DD2C RID: 56620
		private static readonly IntPtr NativeFieldInfoPtr_DecoupleAxisFrames;

		// Token: 0x0400DD2D RID: 56621
		private static readonly IntPtr NativeFieldInfoPtr_HorizontalFrames;

		// Token: 0x0400DD2E RID: 56622
		private static readonly IntPtr NativeFieldInfoPtr_VerticalFrames;

		// Token: 0x0400DD2F RID: 56623
		private static readonly IntPtr NativeFieldInfoPtr_PixelPadding;

		// Token: 0x0400DD30 RID: 56624
		private static readonly IntPtr NativeFieldInfoPtr_MaxVertices;

		// Token: 0x0400DD31 RID: 56625
		private static readonly IntPtr NativeFieldInfoPtr_Tolerance;

		// Token: 0x0400DD32 RID: 56626
		private static readonly IntPtr NativeFieldInfoPtr_NormalScale;

		// Token: 0x0400DD33 RID: 56627
		private static readonly IntPtr NativeFieldInfoPtr_ShapePoints;

		// Token: 0x0400DD34 RID: 56628
		private static readonly IntPtr NativeFieldInfoPtr_Preset;

		// Token: 0x0400DD35 RID: 56629
		private static readonly IntPtr NativeFieldInfoPtr_OverrideOutput;

		// Token: 0x0400DD36 RID: 56630
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
