﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001283 RID: 4739
	[Flags]
	public enum DeferredBuffers
	{
		// Token: 0x0400DD1E RID: 56606
		AlbedoAlpha = 1,
		// Token: 0x0400DD1F RID: 56607
		SpecularSmoothness = 2,
		// Token: 0x0400DD20 RID: 56608
		NormalDepth = 4,
		// Token: 0x0400DD21 RID: 56609
		EmissionOcclusion = 8
	}
}
