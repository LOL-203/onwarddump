﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x02001292 RID: 4754
	public static class RenderTextureEx : Il2CppSystem.Object
	{
		// Token: 0x0601593F RID: 88383 RVA: 0x0056EF3C File Offset: 0x0056D13C
		[CallerCount(0)]
		public unsafe static RenderTexture GetTemporary(RenderTexture renderTexture)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(renderTexture);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RenderTextureEx.NativeMethodInfoPtr_GetTemporary_Public_Static_RenderTexture_RenderTexture_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new RenderTexture(intPtr2) : null;
		}

		// Token: 0x06015940 RID: 88384 RVA: 0x0056EF9A File Offset: 0x0056D19A
		// Note: this type is marked as 'beforefieldinit'.
		static RenderTextureEx()
		{
			Il2CppClassPointerStore<RenderTextureEx>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "RenderTextureEx");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<RenderTextureEx>.NativeClassPtr);
			RenderTextureEx.NativeMethodInfoPtr_GetTemporary_Public_Static_RenderTexture_RenderTexture_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RenderTextureEx>.NativeClassPtr, 100690988);
		}

		// Token: 0x06015941 RID: 88385 RVA: 0x00002988 File Offset: 0x00000B88
		public RenderTextureEx(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079AB RID: 31147
		// (get) Token: 0x06015942 RID: 88386 RVA: 0x0056EFD3 File Offset: 0x0056D1D3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<RenderTextureEx>.NativeClassPtr));
			}
		}

		// Token: 0x0400DD6F RID: 56687
		private static readonly IntPtr NativeMethodInfoPtr_GetTemporary_Public_Static_RenderTexture_RenderTexture_0;
	}
}
