﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x02001293 RID: 4755
	public static class Vector2Ex : Il2CppSystem.Object
	{
		// Token: 0x06015943 RID: 88387 RVA: 0x0056EFE4 File Offset: 0x0056D1E4
		[CallerCount(0)]
		public unsafe static float Cross(this Vector2 O, Vector2 A, Vector2 B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref O;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref A;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref B;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_Cross_Public_Static_Single_Vector2_Vector2_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015944 RID: 88388 RVA: 0x0056F060 File Offset: 0x0056D260
		[CallerCount(0)]
		public unsafe static float TriangleArea(this Vector2 O, Vector2 A, Vector2 B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref O;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref A;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref B;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector2_Vector2_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015945 RID: 88389 RVA: 0x0056F0DC File Offset: 0x0056D2DC
		[CallerCount(0)]
		public unsafe static float TriangleArea(this Vector3 O, Vector3 A, Vector3 B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref O;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref A;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref B;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector3_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015946 RID: 88390 RVA: 0x0056F158 File Offset: 0x0056D358
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<Vector2> ConvexHull(Il2CppStructArray<Vector2> P)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(P);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_ConvexHull_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
		}

		// Token: 0x06015947 RID: 88391 RVA: 0x0056F1B8 File Offset: 0x0056D3B8
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<Vector2> ScaleAlongNormals(Il2CppStructArray<Vector2> P, float scaleAmount)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(P);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref scaleAmount;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_ScaleAlongNormals_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
		}

		// Token: 0x06015948 RID: 88392 RVA: 0x0056F22C File Offset: 0x0056D42C
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<Vector2> ReduceLeastSignificantVertice(Il2CppStructArray<Vector2> P)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(P);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_ReduceLeastSignificantVertice_Private_Static_ArrayOf_Vector2_ArrayOf_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
		}

		// Token: 0x06015949 RID: 88393 RVA: 0x0056F28C File Offset: 0x0056D48C
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<Vector2> ReduceVertices(Il2CppStructArray<Vector2> P, int maxVertices)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(P);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxVertices;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_ReduceVertices_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
		}

		// Token: 0x0601594A RID: 88394 RVA: 0x0056F300 File Offset: 0x0056D500
		[CallerCount(0)]
		public unsafe static Vector2 GetIntersectionPointCoordinates(Vector2 A1, Vector2 A2, Vector2 B1, Vector2 B2)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref A1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref A2;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref B1;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref B2;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_GetIntersectionPointCoordinates_Private_Static_Vector2_Vector2_Vector2_Vector2_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601594B RID: 88395 RVA: 0x0056F38C File Offset: 0x0056D58C
		[CallerCount(0)]
		public unsafe static float OutsideBounds(Vector2 P)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref P;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.NativeMethodInfoPtr_OutsideBounds_Private_Static_Single_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601594C RID: 88396 RVA: 0x0056F3E0 File Offset: 0x0056D5E0
		// Note: this type is marked as 'beforefieldinit'.
		static Vector2Ex()
		{
			Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "Vector2Ex");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr);
			Vector2Ex.NativeMethodInfoPtr_Cross_Public_Static_Single_Vector2_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690989);
			Vector2Ex.NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector2_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690990);
			Vector2Ex.NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector3_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690991);
			Vector2Ex.NativeMethodInfoPtr_ConvexHull_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690992);
			Vector2Ex.NativeMethodInfoPtr_ScaleAlongNormals_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690993);
			Vector2Ex.NativeMethodInfoPtr_ReduceLeastSignificantVertice_Private_Static_ArrayOf_Vector2_ArrayOf_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690994);
			Vector2Ex.NativeMethodInfoPtr_ReduceVertices_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690995);
			Vector2Ex.NativeMethodInfoPtr_GetIntersectionPointCoordinates_Private_Static_Vector2_Vector2_Vector2_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690996);
			Vector2Ex.NativeMethodInfoPtr_OutsideBounds_Private_Static_Single_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, 100690997);
		}

		// Token: 0x0601594D RID: 88397 RVA: 0x00002988 File Offset: 0x00000B88
		public Vector2Ex(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079AC RID: 31148
		// (get) Token: 0x0601594E RID: 88398 RVA: 0x0056F4C4 File Offset: 0x0056D6C4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr));
			}
		}

		// Token: 0x0400DD70 RID: 56688
		private static readonly IntPtr NativeMethodInfoPtr_Cross_Public_Static_Single_Vector2_Vector2_Vector2_0;

		// Token: 0x0400DD71 RID: 56689
		private static readonly IntPtr NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector2_Vector2_Vector2_0;

		// Token: 0x0400DD72 RID: 56690
		private static readonly IntPtr NativeMethodInfoPtr_TriangleArea_Public_Static_Single_Vector3_Vector3_Vector3_0;

		// Token: 0x0400DD73 RID: 56691
		private static readonly IntPtr NativeMethodInfoPtr_ConvexHull_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_0;

		// Token: 0x0400DD74 RID: 56692
		private static readonly IntPtr NativeMethodInfoPtr_ScaleAlongNormals_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Single_0;

		// Token: 0x0400DD75 RID: 56693
		private static readonly IntPtr NativeMethodInfoPtr_ReduceLeastSignificantVertice_Private_Static_ArrayOf_Vector2_ArrayOf_Vector2_0;

		// Token: 0x0400DD76 RID: 56694
		private static readonly IntPtr NativeMethodInfoPtr_ReduceVertices_Public_Static_ArrayOf_Vector2_ArrayOf_Vector2_Int32_0;

		// Token: 0x0400DD77 RID: 56695
		private static readonly IntPtr NativeMethodInfoPtr_GetIntersectionPointCoordinates_Private_Static_Vector2_Vector2_Vector2_Vector2_Vector2_0;

		// Token: 0x0400DD78 RID: 56696
		private static readonly IntPtr NativeMethodInfoPtr_OutsideBounds_Private_Static_Single_Vector2_0;

		// Token: 0x02001294 RID: 4756
		[ObfuscatedName("AmplifyImpostors.Vector2Ex/<>c")]
		[Serializable]
		public sealed class __c : Il2CppSystem.Object
		{
			// Token: 0x0601594F RID: 88399 RVA: 0x0056F4D8 File Offset: 0x0056D6D8
			[CallerCount(0)]
			public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06015950 RID: 88400 RVA: 0x0056F524 File Offset: 0x0056D724
			[CallerCount(0)]
			public unsafe int _ConvexHull_b__3_0(Vector2 a, Vector2 b)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref a;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.__c.NativeMethodInfoPtr__ConvexHull_b__3_0_Internal_Int32_Vector2_Vector2_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06015951 RID: 88401 RVA: 0x0056F59C File Offset: 0x0056D79C
			// Note: this type is marked as 'beforefieldinit'.
			static __c()
			{
				Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, "<>c");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr);
				Vector2Ex.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr, "<>9");
				Vector2Ex.__c.NativeFieldInfoPtr___9__3_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr, "<>9__3_0");
				Vector2Ex.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr, 100690999);
				Vector2Ex.__c.NativeMethodInfoPtr__ConvexHull_b__3_0_Internal_Int32_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr, 100691000);
			}

			// Token: 0x06015952 RID: 88402 RVA: 0x00002988 File Offset: 0x00000B88
			public __c(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170079AD RID: 31149
			// (get) Token: 0x06015953 RID: 88403 RVA: 0x0056F617 File Offset: 0x0056D817
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Vector2Ex.__c>.NativeClassPtr));
				}
			}

			// Token: 0x170079AE RID: 31150
			// (get) Token: 0x06015954 RID: 88404 RVA: 0x0056F628 File Offset: 0x0056D828
			// (set) Token: 0x06015955 RID: 88405 RVA: 0x0056F653 File Offset: 0x0056D853
			public unsafe static Vector2Ex.__c __9
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(Vector2Ex.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Vector2Ex.__c(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(Vector2Ex.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170079AF RID: 31151
			// (get) Token: 0x06015956 RID: 88406 RVA: 0x0056F668 File Offset: 0x0056D868
			// (set) Token: 0x06015957 RID: 88407 RVA: 0x0056F693 File Offset: 0x0056D893
			public unsafe static Comparison<Vector2> __9__3_0
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(Vector2Ex.__c.NativeFieldInfoPtr___9__3_0, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Comparison<Vector2>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(Vector2Ex.__c.NativeFieldInfoPtr___9__3_0, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400DD79 RID: 56697
			private static readonly IntPtr NativeFieldInfoPtr___9;

			// Token: 0x0400DD7A RID: 56698
			private static readonly IntPtr NativeFieldInfoPtr___9__3_0;

			// Token: 0x0400DD7B RID: 56699
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400DD7C RID: 56700
			private static readonly IntPtr NativeMethodInfoPtr__ConvexHull_b__3_0_Internal_Int32_Vector2_Vector2_0;
		}

		// Token: 0x02001295 RID: 4757
		[ObfuscatedName("AmplifyImpostors.Vector2Ex/<>c__DisplayClass5_0")]
		public sealed class __c__DisplayClass5_0 : Il2CppSystem.Object
		{
			// Token: 0x06015958 RID: 88408 RVA: 0x0056F6A8 File Offset: 0x0056D8A8
			[CallerCount(0)]
			public unsafe __c__DisplayClass5_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.__c__DisplayClass5_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06015959 RID: 88409 RVA: 0x0056F6F4 File Offset: 0x0056D8F4
			[CallerCount(0)]
			public unsafe bool _ReduceLeastSignificantVertice_b__0(Vector2 x)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref x;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Vector2Ex.__c__DisplayClass5_0.NativeMethodInfoPtr__ReduceLeastSignificantVertice_b__0_Internal_Boolean_Vector2_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0601595A RID: 88410 RVA: 0x0056F758 File Offset: 0x0056D958
			// Note: this type is marked as 'beforefieldinit'.
			static __c__DisplayClass5_0()
			{
				Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<Vector2Ex>.NativeClassPtr, "<>c__DisplayClass5_0");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr);
				Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_P = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr, "P");
				Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_smallestIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr, "smallestIndex");
				Vector2Ex.__c__DisplayClass5_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr, 100691001);
				Vector2Ex.__c__DisplayClass5_0.NativeMethodInfoPtr__ReduceLeastSignificantVertice_b__0_Internal_Boolean_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr, 100691002);
			}

			// Token: 0x0601595B RID: 88411 RVA: 0x00002988 File Offset: 0x00000B88
			public __c__DisplayClass5_0(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170079B0 RID: 31152
			// (get) Token: 0x0601595C RID: 88412 RVA: 0x0056F7D3 File Offset: 0x0056D9D3
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Vector2Ex.__c__DisplayClass5_0>.NativeClassPtr));
				}
			}

			// Token: 0x170079B1 RID: 31153
			// (get) Token: 0x0601595D RID: 88413 RVA: 0x0056F7E4 File Offset: 0x0056D9E4
			// (set) Token: 0x0601595E RID: 88414 RVA: 0x0056F818 File Offset: 0x0056DA18
			public unsafe Il2CppStructArray<Vector2> P
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_P);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<Vector2>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_P), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170079B2 RID: 31154
			// (get) Token: 0x0601595F RID: 88415 RVA: 0x0056F840 File Offset: 0x0056DA40
			// (set) Token: 0x06015960 RID: 88416 RVA: 0x0056F868 File Offset: 0x0056DA68
			public unsafe int smallestIndex
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_smallestIndex);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Vector2Ex.__c__DisplayClass5_0.NativeFieldInfoPtr_smallestIndex)) = value;
				}
			}

			// Token: 0x0400DD7D RID: 56701
			private static readonly IntPtr NativeFieldInfoPtr_P;

			// Token: 0x0400DD7E RID: 56702
			private static readonly IntPtr NativeFieldInfoPtr_smallestIndex;

			// Token: 0x0400DD7F RID: 56703
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400DD80 RID: 56704
			private static readonly IntPtr NativeMethodInfoPtr__ReduceLeastSignificantVertice_b__0_Internal_Boolean_Vector2_0;
		}
	}
}
