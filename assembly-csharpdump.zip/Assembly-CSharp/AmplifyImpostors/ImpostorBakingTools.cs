﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace AmplifyImpostors
{
	// Token: 0x02001296 RID: 4758
	public static class ImpostorBakingTools : Object
	{
		// Token: 0x06015961 RID: 88417 RVA: 0x0056F88C File Offset: 0x0056DA8C
		// Note: this type is marked as 'beforefieldinit'.
		static ImpostorBakingTools()
		{
			Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "ImpostorBakingTools");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr);
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalFolder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalFolder");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalRelativeFolder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalRelativeFolder");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalDefault = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalDefault");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalTexImport = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalTexImport");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalCreateLodGroup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalCreateLodGroup");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer0Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalGBuffer0Name");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer1Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalGBuffer1Name");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer2Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalGBuffer2Name");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer3Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalGBuffer3Name");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalBakingOptions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefGlobalBakingOptions");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataImpType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataImpType");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeLocked = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataTexSizeLocked");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeSelected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataTexSizeSelected");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataTexSizeX");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataTexSizeY");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataDecoupledFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataDecoupledFrames");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataXFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataXFrames");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataYFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataYFrames");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataPixelBleeding = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataPixelBleeding");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTolerance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataTolerance");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataNormalScale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataNormalScale");
			ImpostorBakingTools.NativeFieldInfoPtr_PrefDataMaxVertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr, "PrefDataMaxVertices");
		}

		// Token: 0x06015962 RID: 88418 RVA: 0x00002988 File Offset: 0x00000B88
		public ImpostorBakingTools(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079B3 RID: 31155
		// (get) Token: 0x06015963 RID: 88419 RVA: 0x0056FA74 File Offset: 0x0056DC74
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ImpostorBakingTools>.NativeClassPtr));
			}
		}

		// Token: 0x170079B4 RID: 31156
		// (get) Token: 0x06015964 RID: 88420 RVA: 0x0056FA88 File Offset: 0x0056DC88
		// (set) Token: 0x06015965 RID: 88421 RVA: 0x0056FAA8 File Offset: 0x0056DCA8
		public unsafe static string PrefGlobalFolder
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalFolder, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalFolder, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079B5 RID: 31157
		// (get) Token: 0x06015966 RID: 88422 RVA: 0x0056FAC0 File Offset: 0x0056DCC0
		// (set) Token: 0x06015967 RID: 88423 RVA: 0x0056FAE0 File Offset: 0x0056DCE0
		public unsafe static string PrefGlobalRelativeFolder
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalRelativeFolder, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalRelativeFolder, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079B6 RID: 31158
		// (get) Token: 0x06015968 RID: 88424 RVA: 0x0056FAF8 File Offset: 0x0056DCF8
		// (set) Token: 0x06015969 RID: 88425 RVA: 0x0056FB18 File Offset: 0x0056DD18
		public unsafe static string PrefGlobalDefault
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalDefault, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalDefault, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079B7 RID: 31159
		// (get) Token: 0x0601596A RID: 88426 RVA: 0x0056FB30 File Offset: 0x0056DD30
		// (set) Token: 0x0601596B RID: 88427 RVA: 0x0056FB50 File Offset: 0x0056DD50
		public unsafe static string PrefGlobalTexImport
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalTexImport, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalTexImport, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079B8 RID: 31160
		// (get) Token: 0x0601596C RID: 88428 RVA: 0x0056FB68 File Offset: 0x0056DD68
		// (set) Token: 0x0601596D RID: 88429 RVA: 0x0056FB88 File Offset: 0x0056DD88
		public unsafe static string PrefGlobalCreateLodGroup
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalCreateLodGroup, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalCreateLodGroup, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079B9 RID: 31161
		// (get) Token: 0x0601596E RID: 88430 RVA: 0x0056FBA0 File Offset: 0x0056DDA0
		// (set) Token: 0x0601596F RID: 88431 RVA: 0x0056FBC0 File Offset: 0x0056DDC0
		public unsafe static string PrefGlobalGBuffer0Name
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer0Name, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer0Name, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BA RID: 31162
		// (get) Token: 0x06015970 RID: 88432 RVA: 0x0056FBD8 File Offset: 0x0056DDD8
		// (set) Token: 0x06015971 RID: 88433 RVA: 0x0056FBF8 File Offset: 0x0056DDF8
		public unsafe static string PrefGlobalGBuffer1Name
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer1Name, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer1Name, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BB RID: 31163
		// (get) Token: 0x06015972 RID: 88434 RVA: 0x0056FC10 File Offset: 0x0056DE10
		// (set) Token: 0x06015973 RID: 88435 RVA: 0x0056FC30 File Offset: 0x0056DE30
		public unsafe static string PrefGlobalGBuffer2Name
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer2Name, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer2Name, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BC RID: 31164
		// (get) Token: 0x06015974 RID: 88436 RVA: 0x0056FC48 File Offset: 0x0056DE48
		// (set) Token: 0x06015975 RID: 88437 RVA: 0x0056FC68 File Offset: 0x0056DE68
		public unsafe static string PrefGlobalGBuffer3Name
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer3Name, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalGBuffer3Name, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BD RID: 31165
		// (get) Token: 0x06015976 RID: 88438 RVA: 0x0056FC80 File Offset: 0x0056DE80
		// (set) Token: 0x06015977 RID: 88439 RVA: 0x0056FCA0 File Offset: 0x0056DEA0
		public unsafe static string PrefGlobalBakingOptions
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalBakingOptions, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefGlobalBakingOptions, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BE RID: 31166
		// (get) Token: 0x06015978 RID: 88440 RVA: 0x0056FCB8 File Offset: 0x0056DEB8
		// (set) Token: 0x06015979 RID: 88441 RVA: 0x0056FCD8 File Offset: 0x0056DED8
		public unsafe static string PrefDataImpType
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataImpType, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataImpType, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079BF RID: 31167
		// (get) Token: 0x0601597A RID: 88442 RVA: 0x0056FCF0 File Offset: 0x0056DEF0
		// (set) Token: 0x0601597B RID: 88443 RVA: 0x0056FD10 File Offset: 0x0056DF10
		public unsafe static string PrefDataTexSizeLocked
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeLocked, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeLocked, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C0 RID: 31168
		// (get) Token: 0x0601597C RID: 88444 RVA: 0x0056FD28 File Offset: 0x0056DF28
		// (set) Token: 0x0601597D RID: 88445 RVA: 0x0056FD48 File Offset: 0x0056DF48
		public unsafe static string PrefDataTexSizeSelected
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeSelected, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeSelected, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C1 RID: 31169
		// (get) Token: 0x0601597E RID: 88446 RVA: 0x0056FD60 File Offset: 0x0056DF60
		// (set) Token: 0x0601597F RID: 88447 RVA: 0x0056FD80 File Offset: 0x0056DF80
		public unsafe static string PrefDataTexSizeX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C2 RID: 31170
		// (get) Token: 0x06015980 RID: 88448 RVA: 0x0056FD98 File Offset: 0x0056DF98
		// (set) Token: 0x06015981 RID: 88449 RVA: 0x0056FDB8 File Offset: 0x0056DFB8
		public unsafe static string PrefDataTexSizeY
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeY, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTexSizeY, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C3 RID: 31171
		// (get) Token: 0x06015982 RID: 88450 RVA: 0x0056FDD0 File Offset: 0x0056DFD0
		// (set) Token: 0x06015983 RID: 88451 RVA: 0x0056FDF0 File Offset: 0x0056DFF0
		public unsafe static string PrefDataDecoupledFrames
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataDecoupledFrames, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataDecoupledFrames, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C4 RID: 31172
		// (get) Token: 0x06015984 RID: 88452 RVA: 0x0056FE08 File Offset: 0x0056E008
		// (set) Token: 0x06015985 RID: 88453 RVA: 0x0056FE28 File Offset: 0x0056E028
		public unsafe static string PrefDataXFrames
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataXFrames, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataXFrames, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C5 RID: 31173
		// (get) Token: 0x06015986 RID: 88454 RVA: 0x0056FE40 File Offset: 0x0056E040
		// (set) Token: 0x06015987 RID: 88455 RVA: 0x0056FE60 File Offset: 0x0056E060
		public unsafe static string PrefDataYFrames
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataYFrames, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataYFrames, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C6 RID: 31174
		// (get) Token: 0x06015988 RID: 88456 RVA: 0x0056FE78 File Offset: 0x0056E078
		// (set) Token: 0x06015989 RID: 88457 RVA: 0x0056FE98 File Offset: 0x0056E098
		public unsafe static string PrefDataPixelBleeding
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataPixelBleeding, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataPixelBleeding, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C7 RID: 31175
		// (get) Token: 0x0601598A RID: 88458 RVA: 0x0056FEB0 File Offset: 0x0056E0B0
		// (set) Token: 0x0601598B RID: 88459 RVA: 0x0056FED0 File Offset: 0x0056E0D0
		public unsafe static string PrefDataTolerance
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTolerance, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataTolerance, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C8 RID: 31176
		// (get) Token: 0x0601598C RID: 88460 RVA: 0x0056FEE8 File Offset: 0x0056E0E8
		// (set) Token: 0x0601598D RID: 88461 RVA: 0x0056FF08 File Offset: 0x0056E108
		public unsafe static string PrefDataNormalScale
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataNormalScale, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataNormalScale, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170079C9 RID: 31177
		// (get) Token: 0x0601598E RID: 88462 RVA: 0x0056FF20 File Offset: 0x0056E120
		// (set) Token: 0x0601598F RID: 88463 RVA: 0x0056FF40 File Offset: 0x0056E140
		public unsafe static string PrefDataMaxVertices
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataMaxVertices, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ImpostorBakingTools.NativeFieldInfoPtr_PrefDataMaxVertices, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400DD81 RID: 56705
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalFolder;

		// Token: 0x0400DD82 RID: 56706
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalRelativeFolder;

		// Token: 0x0400DD83 RID: 56707
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalDefault;

		// Token: 0x0400DD84 RID: 56708
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalTexImport;

		// Token: 0x0400DD85 RID: 56709
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalCreateLodGroup;

		// Token: 0x0400DD86 RID: 56710
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalGBuffer0Name;

		// Token: 0x0400DD87 RID: 56711
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalGBuffer1Name;

		// Token: 0x0400DD88 RID: 56712
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalGBuffer2Name;

		// Token: 0x0400DD89 RID: 56713
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalGBuffer3Name;

		// Token: 0x0400DD8A RID: 56714
		private static readonly IntPtr NativeFieldInfoPtr_PrefGlobalBakingOptions;

		// Token: 0x0400DD8B RID: 56715
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataImpType;

		// Token: 0x0400DD8C RID: 56716
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataTexSizeLocked;

		// Token: 0x0400DD8D RID: 56717
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataTexSizeSelected;

		// Token: 0x0400DD8E RID: 56718
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataTexSizeX;

		// Token: 0x0400DD8F RID: 56719
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataTexSizeY;

		// Token: 0x0400DD90 RID: 56720
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataDecoupledFrames;

		// Token: 0x0400DD91 RID: 56721
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataXFrames;

		// Token: 0x0400DD92 RID: 56722
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataYFrames;

		// Token: 0x0400DD93 RID: 56723
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataPixelBleeding;

		// Token: 0x0400DD94 RID: 56724
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataTolerance;

		// Token: 0x0400DD95 RID: 56725
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataNormalScale;

		// Token: 0x0400DD96 RID: 56726
		private static readonly IntPtr NativeFieldInfoPtr_PrefDataMaxVertices;
	}
}
