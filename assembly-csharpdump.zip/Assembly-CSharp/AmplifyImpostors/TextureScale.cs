﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001289 RID: 4745
	public enum TextureScale
	{
		// Token: 0x0400DD44 RID: 56644
		Full = 1,
		// Token: 0x0400DD45 RID: 56645
		Half,
		// Token: 0x0400DD46 RID: 56646
		Quarter = 4,
		// Token: 0x0400DD47 RID: 56647
		Eighth = 8
	}
}
