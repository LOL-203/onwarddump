﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x0200128A RID: 4746
	[Flags]
	public enum OverrideMask
	{
		// Token: 0x0400DD49 RID: 56649
		OutputToggle = 1,
		// Token: 0x0400DD4A RID: 56650
		NameSuffix = 2,
		// Token: 0x0400DD4B RID: 56651
		RelativeScale = 4,
		// Token: 0x0400DD4C RID: 56652
		ColorSpace = 8,
		// Token: 0x0400DD4D RID: 56653
		QualityCompression = 16,
		// Token: 0x0400DD4E RID: 56654
		FileFormat = 32
	}
}
