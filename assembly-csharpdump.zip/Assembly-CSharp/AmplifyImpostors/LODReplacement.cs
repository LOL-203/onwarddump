﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x0200127D RID: 4733
	public enum LODReplacement
	{
		// Token: 0x0400DCC8 RID: 56520
		DoNothing,
		// Token: 0x0400DCC9 RID: 56521
		ReplaceCulled,
		// Token: 0x0400DCCA RID: 56522
		ReplaceLast,
		// Token: 0x0400DCCB RID: 56523
		ReplaceAllExceptFirst,
		// Token: 0x0400DCCC RID: 56524
		ReplaceSpecific,
		// Token: 0x0400DCCD RID: 56525
		ReplaceAfterSpecific,
		// Token: 0x0400DCCE RID: 56526
		InsertAfter
	}
}
