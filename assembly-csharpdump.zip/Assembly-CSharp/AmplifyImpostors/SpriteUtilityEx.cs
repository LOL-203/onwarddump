﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x02001291 RID: 4753
	public static class SpriteUtilityEx : Il2CppSystem.Object
	{
		// Token: 0x170079AA RID: 31146
		// (get) Token: 0x06015938 RID: 88376 RVA: 0x0056ED84 File Offset: 0x0056CF84
		public unsafe static Type Type
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpriteUtilityEx.NativeMethodInfoPtr_get_Type_Public_Static_get_Type_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Type(intPtr2) : null;
			}
		}

		// Token: 0x06015939 RID: 88377 RVA: 0x0056EDCC File Offset: 0x0056CFCC
		[CallerCount(0)]
		public unsafe static void GenerateOutline(Texture2D texture, Rect rect, float detail, byte alphaTolerance, bool holeDetection, out Il2CppReferenceArray<Il2CppStructArray<Vector2>> paths)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(texture);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rect;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref detail;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref alphaTolerance;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref holeDetection;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(paths);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpriteUtilityEx.NativeMethodInfoPtr_GenerateOutline_Public_Static_Void_Texture2D_Rect_Single_Byte_Boolean_byref_ArrayOf_ArrayOf_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601593A RID: 88378 RVA: 0x0056EE7C File Offset: 0x0056D07C
		// Note: this type is marked as 'beforefieldinit'.
		static SpriteUtilityEx()
		{
			Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "SpriteUtilityEx");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr);
			SpriteUtilityEx.NativeFieldInfoPtr_type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr, "type");
			SpriteUtilityEx.NativeMethodInfoPtr_get_Type_Public_Static_get_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr, 100690986);
			SpriteUtilityEx.NativeMethodInfoPtr_GenerateOutline_Public_Static_Void_Texture2D_Rect_Single_Byte_Boolean_byref_ArrayOf_ArrayOf_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr, 100690987);
		}

		// Token: 0x0601593B RID: 88379 RVA: 0x00002988 File Offset: 0x00000B88
		public SpriteUtilityEx(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079A8 RID: 31144
		// (get) Token: 0x0601593C RID: 88380 RVA: 0x0056EEE8 File Offset: 0x0056D0E8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SpriteUtilityEx>.NativeClassPtr));
			}
		}

		// Token: 0x170079A9 RID: 31145
		// (get) Token: 0x0601593D RID: 88381 RVA: 0x0056EEFC File Offset: 0x0056D0FC
		// (set) Token: 0x0601593E RID: 88382 RVA: 0x0056EF27 File Offset: 0x0056D127
		public unsafe static Type type
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(SpriteUtilityEx.NativeFieldInfoPtr_type, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Type(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpriteUtilityEx.NativeFieldInfoPtr_type, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400DD6C RID: 56684
		private static readonly IntPtr NativeFieldInfoPtr_type;

		// Token: 0x0400DD6D RID: 56685
		private static readonly IntPtr NativeMethodInfoPtr_get_Type_Public_Static_get_Type_0;

		// Token: 0x0400DD6E RID: 56686
		private static readonly IntPtr NativeMethodInfoPtr_GenerateOutline_Public_Static_Void_Texture2D_Rect_Single_Byte_Boolean_byref_ArrayOf_ArrayOf_Vector2_0;
	}
}
