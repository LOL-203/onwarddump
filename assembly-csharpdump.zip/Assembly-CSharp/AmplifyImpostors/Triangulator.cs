﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x02001297 RID: 4759
	public class Triangulator : Il2CppSystem.Object
	{
		// Token: 0x170079CC RID: 31180
		// (get) Token: 0x06015990 RID: 88464 RVA: 0x0056FF58 File Offset: 0x0056E158
		public unsafe List<Vector2> Points
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr_get_Points_Public_get_List_1_Vector2_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<Vector2>(intPtr2) : null;
			}
		}

		// Token: 0x06015991 RID: 88465 RVA: 0x0056FFB0 File Offset: 0x0056E1B0
		[CallerCount(0)]
		public unsafe Triangulator(Il2CppStructArray<Vector2> points) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Triangulator>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(points);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06015992 RID: 88466 RVA: 0x00570014 File Offset: 0x0056E214
		[CallerCount(0)]
		public unsafe Triangulator(Il2CppStructArray<Vector2> points, bool invertY = true) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Triangulator>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(points);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref invertY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06015993 RID: 88467 RVA: 0x0057008C File Offset: 0x0056E28C
		[CallerCount(0)]
		public unsafe Il2CppStructArray<int> Triangulate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr_Triangulate_Public_ArrayOf_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}

		// Token: 0x06015994 RID: 88468 RVA: 0x005700E4 File Offset: 0x0056E2E4
		[CallerCount(0)]
		public unsafe float Area()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr_Area_Private_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015995 RID: 88469 RVA: 0x00570134 File Offset: 0x0056E334
		[CallerCount(0)]
		public unsafe bool Snip(int u, int v, int w, int n, Il2CppStructArray<int> V)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref u;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref w;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(V);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr_Snip_Private_Boolean_Int32_Int32_Int32_Int32_ArrayOf_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015996 RID: 88470 RVA: 0x005701E8 File Offset: 0x0056E3E8
		[CallerCount(0)]
		public unsafe bool InsideTriangle(Vector2 pt, Vector2 v1, Vector2 v2, Vector2 v3)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pt;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v1;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v2;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v3;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Triangulator.NativeMethodInfoPtr_InsideTriangle_Private_Boolean_Vector2_Vector2_Vector2_Vector2_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015997 RID: 88471 RVA: 0x00570284 File Offset: 0x0056E484
		// Note: this type is marked as 'beforefieldinit'.
		static Triangulator()
		{
			Il2CppClassPointerStore<Triangulator>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "Triangulator");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Triangulator>.NativeClassPtr);
			Triangulator.NativeFieldInfoPtr_m_points = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, "m_points");
			Triangulator.NativeMethodInfoPtr_get_Points_Public_get_List_1_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691004);
			Triangulator.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691005);
			Triangulator.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691006);
			Triangulator.NativeMethodInfoPtr_Triangulate_Public_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691007);
			Triangulator.NativeMethodInfoPtr_Area_Private_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691008);
			Triangulator.NativeMethodInfoPtr_Snip_Private_Boolean_Int32_Int32_Int32_Int32_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691009);
			Triangulator.NativeMethodInfoPtr_InsideTriangle_Private_Boolean_Vector2_Vector2_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Triangulator>.NativeClassPtr, 100691010);
		}

		// Token: 0x06015998 RID: 88472 RVA: 0x00002988 File Offset: 0x00000B88
		public Triangulator(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079CA RID: 31178
		// (get) Token: 0x06015999 RID: 88473 RVA: 0x00570354 File Offset: 0x0056E554
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Triangulator>.NativeClassPtr));
			}
		}

		// Token: 0x170079CB RID: 31179
		// (get) Token: 0x0601599A RID: 88474 RVA: 0x00570368 File Offset: 0x0056E568
		// (set) Token: 0x0601599B RID: 88475 RVA: 0x0057039C File Offset: 0x0056E59C
		public unsafe List<Vector2> m_points
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Triangulator.NativeFieldInfoPtr_m_points);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Vector2>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Triangulator.NativeFieldInfoPtr_m_points), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400DD97 RID: 56727
		private static readonly IntPtr NativeFieldInfoPtr_m_points;

		// Token: 0x0400DD98 RID: 56728
		private static readonly IntPtr NativeMethodInfoPtr_get_Points_Public_get_List_1_Vector2_0;

		// Token: 0x0400DD99 RID: 56729
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_0;

		// Token: 0x0400DD9A RID: 56730
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Vector2_Boolean_0;

		// Token: 0x0400DD9B RID: 56731
		private static readonly IntPtr NativeMethodInfoPtr_Triangulate_Public_ArrayOf_Int32_0;

		// Token: 0x0400DD9C RID: 56732
		private static readonly IntPtr NativeMethodInfoPtr_Area_Private_Single_0;

		// Token: 0x0400DD9D RID: 56733
		private static readonly IntPtr NativeMethodInfoPtr_Snip_Private_Boolean_Int32_Int32_Int32_Int32_ArrayOf_Int32_0;

		// Token: 0x0400DD9E RID: 56734
		private static readonly IntPtr NativeMethodInfoPtr_InsideTriangle_Private_Boolean_Vector2_Vector2_Vector2_Vector2_0;
	}
}
