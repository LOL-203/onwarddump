﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x0200128D RID: 4749
	public class AmplifyImpostorBakePreset : ScriptableObject
	{
		// Token: 0x0601591D RID: 88349 RVA: 0x0056E85C File Offset: 0x0056CA5C
		[CallerCount(0)]
		public unsafe AmplifyImpostorBakePreset() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmplifyImpostorBakePreset.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601591E RID: 88350 RVA: 0x0056E8A8 File Offset: 0x0056CAA8
		// Note: this type is marked as 'beforefieldinit'.
		static AmplifyImpostorBakePreset()
		{
			Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "AmplifyImpostorBakePreset");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr);
			AmplifyImpostorBakePreset.NativeFieldInfoPtr_BakeShader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, "BakeShader");
			AmplifyImpostorBakePreset.NativeFieldInfoPtr_RuntimeShader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, "RuntimeShader");
			AmplifyImpostorBakePreset.NativeFieldInfoPtr_Pipeline = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, "Pipeline");
			AmplifyImpostorBakePreset.NativeFieldInfoPtr_AlphaIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, "AlphaIndex");
			AmplifyImpostorBakePreset.NativeFieldInfoPtr_Output = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, "Output");
			AmplifyImpostorBakePreset.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr, 100690981);
		}

		// Token: 0x0601591F RID: 88351 RVA: 0x0002DD3C File Offset: 0x0002BF3C
		public AmplifyImpostorBakePreset(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700799E RID: 31134
		// (get) Token: 0x06015920 RID: 88352 RVA: 0x0056E950 File Offset: 0x0056CB50
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmplifyImpostorBakePreset>.NativeClassPtr));
			}
		}

		// Token: 0x1700799F RID: 31135
		// (get) Token: 0x06015921 RID: 88353 RVA: 0x0056E964 File Offset: 0x0056CB64
		// (set) Token: 0x06015922 RID: 88354 RVA: 0x0056E998 File Offset: 0x0056CB98
		public unsafe Shader BakeShader
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_BakeShader);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Shader(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_BakeShader), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170079A0 RID: 31136
		// (get) Token: 0x06015923 RID: 88355 RVA: 0x0056E9C0 File Offset: 0x0056CBC0
		// (set) Token: 0x06015924 RID: 88356 RVA: 0x0056E9F4 File Offset: 0x0056CBF4
		public unsafe Shader RuntimeShader
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_RuntimeShader);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Shader(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_RuntimeShader), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170079A1 RID: 31137
		// (get) Token: 0x06015925 RID: 88357 RVA: 0x0056EA1C File Offset: 0x0056CC1C
		// (set) Token: 0x06015926 RID: 88358 RVA: 0x0056EA44 File Offset: 0x0056CC44
		public unsafe PresetPipeline Pipeline
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_Pipeline);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_Pipeline)) = value;
			}
		}

		// Token: 0x170079A2 RID: 31138
		// (get) Token: 0x06015927 RID: 88359 RVA: 0x0056EA68 File Offset: 0x0056CC68
		// (set) Token: 0x06015928 RID: 88360 RVA: 0x0056EA90 File Offset: 0x0056CC90
		public unsafe int AlphaIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_AlphaIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_AlphaIndex)) = value;
			}
		}

		// Token: 0x170079A3 RID: 31139
		// (get) Token: 0x06015929 RID: 88361 RVA: 0x0056EAB4 File Offset: 0x0056CCB4
		// (set) Token: 0x0601592A RID: 88362 RVA: 0x0056EAE8 File Offset: 0x0056CCE8
		public unsafe List<TextureOutput> Output
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_Output);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<TextureOutput>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmplifyImpostorBakePreset.NativeFieldInfoPtr_Output), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400DD5F RID: 56671
		private static readonly IntPtr NativeFieldInfoPtr_BakeShader;

		// Token: 0x0400DD60 RID: 56672
		private static readonly IntPtr NativeFieldInfoPtr_RuntimeShader;

		// Token: 0x0400DD61 RID: 56673
		private static readonly IntPtr NativeFieldInfoPtr_Pipeline;

		// Token: 0x0400DD62 RID: 56674
		private static readonly IntPtr NativeFieldInfoPtr_AlphaIndex;

		// Token: 0x0400DD63 RID: 56675
		private static readonly IntPtr NativeFieldInfoPtr_Output;

		// Token: 0x0400DD64 RID: 56676
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
