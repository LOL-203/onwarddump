﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x0200128F RID: 4751
	public static class Texture2DEx : Il2CppSystem.Object
	{
		// Token: 0x0601592F RID: 88367 RVA: 0x0056EBC0 File Offset: 0x0056CDC0
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> EncodeToTGA(this Texture2D tex, [Optional] Texture2DEx.Compression compression)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(tex);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref compression;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Texture2DEx.NativeMethodInfoPtr_EncodeToTGA_Public_Static_ArrayOf_Byte_Texture2D_Compression_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x06015930 RID: 88368 RVA: 0x0056EC34 File Offset: 0x0056CE34
		[CallerCount(0)]
		public unsafe static bool Equals(Color32 first, Color32 second)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref first;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref second;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Texture2DEx.NativeMethodInfoPtr_Equals_Private_Static_Boolean_Color32_Color32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06015931 RID: 88369 RVA: 0x0056EC9C File Offset: 0x0056CE9C
		// Note: this type is marked as 'beforefieldinit'.
		static Texture2DEx()
		{
			Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "Texture2DEx");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr);
			Texture2DEx.NativeFieldInfoPtr_Footer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr, "Footer");
			Texture2DEx.NativeMethodInfoPtr_EncodeToTGA_Public_Static_ArrayOf_Byte_Texture2D_Compression_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr, 100690983);
			Texture2DEx.NativeMethodInfoPtr_Equals_Private_Static_Boolean_Color32_Color32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr, 100690984);
		}

		// Token: 0x06015932 RID: 88370 RVA: 0x00002988 File Offset: 0x00000B88
		public Texture2DEx(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079A5 RID: 31141
		// (get) Token: 0x06015933 RID: 88371 RVA: 0x0056ED08 File Offset: 0x0056CF08
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Texture2DEx>.NativeClassPtr));
			}
		}

		// Token: 0x170079A6 RID: 31142
		// (get) Token: 0x06015934 RID: 88372 RVA: 0x0056ED1C File Offset: 0x0056CF1C
		// (set) Token: 0x06015935 RID: 88373 RVA: 0x0056ED47 File Offset: 0x0056CF47
		public unsafe static Il2CppStructArray<byte> Footer
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(Texture2DEx.NativeFieldInfoPtr_Footer, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Texture2DEx.NativeFieldInfoPtr_Footer, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400DD66 RID: 56678
		private static readonly IntPtr NativeFieldInfoPtr_Footer;

		// Token: 0x0400DD67 RID: 56679
		private static readonly IntPtr NativeMethodInfoPtr_EncodeToTGA_Public_Static_ArrayOf_Byte_Texture2D_Compression_0;

		// Token: 0x0400DD68 RID: 56680
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Private_Static_Boolean_Color32_Color32_0;

		// Token: 0x02001290 RID: 4752
		public enum Compression
		{
			// Token: 0x0400DD6A RID: 56682
			None,
			// Token: 0x0400DD6B RID: 56683
			RLE
		}
	}
}
