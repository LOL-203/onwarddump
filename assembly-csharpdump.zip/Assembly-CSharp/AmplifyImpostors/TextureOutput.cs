﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AmplifyImpostors
{
	// Token: 0x0200128C RID: 4748
	[Serializable]
	public class TextureOutput : Object
	{
		// Token: 0x06015905 RID: 88325 RVA: 0x0056E300 File Offset: 0x0056C500
		[CallerCount(0)]
		public unsafe TextureOutput() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TextureOutput.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06015906 RID: 88326 RVA: 0x0056E34C File Offset: 0x0056C54C
		[CallerCount(0)]
		public unsafe TextureOutput(bool a, string n, TextureScale s, bool sr, TextureChannels c, TextureCompression nc, ImageFormat i) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(n);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref s;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref sr;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref c;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref nc;
			ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TextureOutput.NativeMethodInfoPtr__ctor_Public_Void_Boolean_String_TextureScale_Boolean_TextureChannels_TextureCompression_ImageFormat_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06015907 RID: 88327 RVA: 0x0056E420 File Offset: 0x0056C620
		[CallerCount(0)]
		public unsafe TextureOutput Clone()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TextureOutput.NativeMethodInfoPtr_Clone_Public_TextureOutput_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new TextureOutput(intPtr2) : null;
		}

		// Token: 0x06015908 RID: 88328 RVA: 0x0056E478 File Offset: 0x0056C678
		// Note: this type is marked as 'beforefieldinit'.
		static TextureOutput()
		{
			Il2CppClassPointerStore<TextureOutput>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "TextureOutput");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr);
			TextureOutput.NativeFieldInfoPtr_Index = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Index");
			TextureOutput.NativeFieldInfoPtr_OverrideMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "OverrideMask");
			TextureOutput.NativeFieldInfoPtr_Active = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Active");
			TextureOutput.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Name");
			TextureOutput.NativeFieldInfoPtr_Scale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Scale");
			TextureOutput.NativeFieldInfoPtr_SRGB = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "SRGB");
			TextureOutput.NativeFieldInfoPtr_Channels = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Channels");
			TextureOutput.NativeFieldInfoPtr_Compression = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "Compression");
			TextureOutput.NativeFieldInfoPtr_ImageFormat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, "ImageFormat");
			TextureOutput.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, 100690978);
			TextureOutput.NativeMethodInfoPtr__ctor_Public_Void_Boolean_String_TextureScale_Boolean_TextureChannels_TextureCompression_ImageFormat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, 100690979);
			TextureOutput.NativeMethodInfoPtr_Clone_Public_TextureOutput_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr, 100690980);
		}

		// Token: 0x06015909 RID: 88329 RVA: 0x00002988 File Offset: 0x00000B88
		public TextureOutput(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007994 RID: 31124
		// (get) Token: 0x0601590A RID: 88330 RVA: 0x0056E598 File Offset: 0x0056C798
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TextureOutput>.NativeClassPtr));
			}
		}

		// Token: 0x17007995 RID: 31125
		// (get) Token: 0x0601590B RID: 88331 RVA: 0x0056E5AC File Offset: 0x0056C7AC
		// (set) Token: 0x0601590C RID: 88332 RVA: 0x0056E5D4 File Offset: 0x0056C7D4
		public unsafe int Index
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Index);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Index)) = value;
			}
		}

		// Token: 0x17007996 RID: 31126
		// (get) Token: 0x0601590D RID: 88333 RVA: 0x0056E5F8 File Offset: 0x0056C7F8
		// (set) Token: 0x0601590E RID: 88334 RVA: 0x0056E620 File Offset: 0x0056C820
		public unsafe OverrideMask OverrideMask
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_OverrideMask);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_OverrideMask)) = value;
			}
		}

		// Token: 0x17007997 RID: 31127
		// (get) Token: 0x0601590F RID: 88335 RVA: 0x0056E644 File Offset: 0x0056C844
		// (set) Token: 0x06015910 RID: 88336 RVA: 0x0056E66C File Offset: 0x0056C86C
		public unsafe bool Active
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Active);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Active)) = value;
			}
		}

		// Token: 0x17007998 RID: 31128
		// (get) Token: 0x06015911 RID: 88337 RVA: 0x0056E690 File Offset: 0x0056C890
		// (set) Token: 0x06015912 RID: 88338 RVA: 0x0056E6B9 File Offset: 0x0056C8B9
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17007999 RID: 31129
		// (get) Token: 0x06015913 RID: 88339 RVA: 0x0056E6E0 File Offset: 0x0056C8E0
		// (set) Token: 0x06015914 RID: 88340 RVA: 0x0056E708 File Offset: 0x0056C908
		public unsafe TextureScale Scale
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Scale);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Scale)) = value;
			}
		}

		// Token: 0x1700799A RID: 31130
		// (get) Token: 0x06015915 RID: 88341 RVA: 0x0056E72C File Offset: 0x0056C92C
		// (set) Token: 0x06015916 RID: 88342 RVA: 0x0056E754 File Offset: 0x0056C954
		public unsafe bool SRGB
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_SRGB);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_SRGB)) = value;
			}
		}

		// Token: 0x1700799B RID: 31131
		// (get) Token: 0x06015917 RID: 88343 RVA: 0x0056E778 File Offset: 0x0056C978
		// (set) Token: 0x06015918 RID: 88344 RVA: 0x0056E7A0 File Offset: 0x0056C9A0
		public unsafe TextureChannels Channels
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Channels);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Channels)) = value;
			}
		}

		// Token: 0x1700799C RID: 31132
		// (get) Token: 0x06015919 RID: 88345 RVA: 0x0056E7C4 File Offset: 0x0056C9C4
		// (set) Token: 0x0601591A RID: 88346 RVA: 0x0056E7EC File Offset: 0x0056C9EC
		public unsafe TextureCompression Compression
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Compression);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_Compression)) = value;
			}
		}

		// Token: 0x1700799D RID: 31133
		// (get) Token: 0x0601591B RID: 88347 RVA: 0x0056E810 File Offset: 0x0056CA10
		// (set) Token: 0x0601591C RID: 88348 RVA: 0x0056E838 File Offset: 0x0056CA38
		public unsafe ImageFormat ImageFormat
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_ImageFormat);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TextureOutput.NativeFieldInfoPtr_ImageFormat)) = value;
			}
		}

		// Token: 0x0400DD53 RID: 56659
		private static readonly IntPtr NativeFieldInfoPtr_Index;

		// Token: 0x0400DD54 RID: 56660
		private static readonly IntPtr NativeFieldInfoPtr_OverrideMask;

		// Token: 0x0400DD55 RID: 56661
		private static readonly IntPtr NativeFieldInfoPtr_Active;

		// Token: 0x0400DD56 RID: 56662
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x0400DD57 RID: 56663
		private static readonly IntPtr NativeFieldInfoPtr_Scale;

		// Token: 0x0400DD58 RID: 56664
		private static readonly IntPtr NativeFieldInfoPtr_SRGB;

		// Token: 0x0400DD59 RID: 56665
		private static readonly IntPtr NativeFieldInfoPtr_Channels;

		// Token: 0x0400DD5A RID: 56666
		private static readonly IntPtr NativeFieldInfoPtr_Compression;

		// Token: 0x0400DD5B RID: 56667
		private static readonly IntPtr NativeFieldInfoPtr_ImageFormat;

		// Token: 0x0400DD5C RID: 56668
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0400DD5D RID: 56669
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Boolean_String_TextureScale_Boolean_TextureChannels_TextureCompression_ImageFormat_0;

		// Token: 0x0400DD5E RID: 56670
		private static readonly IntPtr NativeMethodInfoPtr_Clone_Public_TextureOutput_0;
	}
}
