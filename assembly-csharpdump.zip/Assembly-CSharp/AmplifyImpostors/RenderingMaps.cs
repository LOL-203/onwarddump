﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001284 RID: 4740
	public enum RenderingMaps
	{
		// Token: 0x0400DD23 RID: 56611
		Standard,
		// Token: 0x0400DD24 RID: 56612
		Custom
	}
}
