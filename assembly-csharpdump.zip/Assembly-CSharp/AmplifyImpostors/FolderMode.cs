﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x0200127F RID: 4735
	public enum FolderMode
	{
		// Token: 0x0400DCD3 RID: 56531
		RelativeToPrefab,
		// Token: 0x0400DCD4 RID: 56532
		Global
	}
}
