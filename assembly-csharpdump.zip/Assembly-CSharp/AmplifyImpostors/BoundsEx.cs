﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x0200128E RID: 4750
	public static class BoundsEx : Il2CppSystem.Object
	{
		// Token: 0x0601592B RID: 88363 RVA: 0x0056EB10 File Offset: 0x0056CD10
		[CallerCount(0)]
		public unsafe static Bounds Transform(this Bounds bounds, Matrix4x4 matrix)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref bounds;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref matrix;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoundsEx.NativeMethodInfoPtr_Transform_Public_Static_Bounds_Bounds_Matrix4x4_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601592C RID: 88364 RVA: 0x0056EB76 File Offset: 0x0056CD76
		// Note: this type is marked as 'beforefieldinit'.
		static BoundsEx()
		{
			Il2CppClassPointerStore<BoundsEx>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "BoundsEx");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BoundsEx>.NativeClassPtr);
			BoundsEx.NativeMethodInfoPtr_Transform_Public_Static_Bounds_Bounds_Matrix4x4_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoundsEx>.NativeClassPtr, 100690982);
		}

		// Token: 0x0601592D RID: 88365 RVA: 0x00002988 File Offset: 0x00000B88
		public BoundsEx(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079A4 RID: 31140
		// (get) Token: 0x0601592E RID: 88366 RVA: 0x0056EBAF File Offset: 0x0056CDAF
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BoundsEx>.NativeClassPtr));
			}
		}

		// Token: 0x0400DD65 RID: 56677
		private static readonly IntPtr NativeMethodInfoPtr_Transform_Public_Static_Bounds_Bounds_Matrix4x4_0;
	}
}
