﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x0200128B RID: 4747
	public enum PresetPipeline
	{
		// Token: 0x0400DD50 RID: 56656
		Legacy,
		// Token: 0x0400DD51 RID: 56657
		Lightweight,
		// Token: 0x0400DD52 RID: 56658
		HighDefinition
	}
}
