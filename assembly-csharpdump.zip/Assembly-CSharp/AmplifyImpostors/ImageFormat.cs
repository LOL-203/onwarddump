﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001286 RID: 4742
	public enum ImageFormat
	{
		// Token: 0x0400DD38 RID: 56632
		PNG,
		// Token: 0x0400DD39 RID: 56633
		TGA,
		// Token: 0x0400DD3A RID: 56634
		EXR
	}
}
