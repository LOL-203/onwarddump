﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001287 RID: 4743
	public enum TextureChannels
	{
		// Token: 0x0400DD3C RID: 56636
		RGBA,
		// Token: 0x0400DD3D RID: 56637
		RGB
	}
}
