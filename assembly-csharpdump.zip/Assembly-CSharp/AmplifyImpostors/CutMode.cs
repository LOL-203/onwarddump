﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x0200127E RID: 4734
	public enum CutMode
	{
		// Token: 0x0400DCD0 RID: 56528
		Automatic,
		// Token: 0x0400DCD1 RID: 56529
		Manual
	}
}
