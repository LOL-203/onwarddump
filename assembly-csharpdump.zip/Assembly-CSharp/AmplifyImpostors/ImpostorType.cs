﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001282 RID: 4738
	public enum ImpostorType
	{
		// Token: 0x0400DD1A RID: 56602
		Spherical,
		// Token: 0x0400DD1B RID: 56603
		Octahedron,
		// Token: 0x0400DD1C RID: 56604
		HemiOctahedron
	}
}
