﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AmplifyImpostors
{
	// Token: 0x02001298 RID: 4760
	[Serializable]
	public class VersionInfo : Object
	{
		// Token: 0x0601599C RID: 88476 RVA: 0x005703C4 File Offset: 0x0056E5C4
		[CallerCount(0)]
		public unsafe static string StaticToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(VersionInfo.NativeMethodInfoPtr_StaticToString_Public_Static_String_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x170079D2 RID: 31186
		// (get) Token: 0x0601599D RID: 88477 RVA: 0x00570400 File Offset: 0x0056E600
		public unsafe static int FullNumber
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(VersionInfo.NativeMethodInfoPtr_get_FullNumber_Public_Static_get_Int32_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170079D3 RID: 31187
		// (get) Token: 0x0601599E RID: 88478 RVA: 0x00570444 File Offset: 0x0056E644
		public unsafe static string FullLabel
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(VersionInfo.NativeMethodInfoPtr_get_FullLabel_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x0601599F RID: 88479 RVA: 0x00570480 File Offset: 0x0056E680
		[CallerCount(0)]
		public unsafe VersionInfo() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VersionInfo.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060159A0 RID: 88480 RVA: 0x005704CC File Offset: 0x0056E6CC
		// Note: this type is marked as 'beforefieldinit'.
		static VersionInfo()
		{
			Il2CppClassPointerStore<VersionInfo>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AmplifyImpostors", "VersionInfo");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr);
			VersionInfo.NativeFieldInfoPtr_Major = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, "Major");
			VersionInfo.NativeFieldInfoPtr_Minor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, "Minor");
			VersionInfo.NativeFieldInfoPtr_Release = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, "Release");
			VersionInfo.NativeFieldInfoPtr_Revision = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, "Revision");
			VersionInfo.NativeMethodInfoPtr_StaticToString_Public_Static_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, 100691011);
			VersionInfo.NativeMethodInfoPtr_get_FullNumber_Public_Static_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, 100691012);
			VersionInfo.NativeMethodInfoPtr_get_FullLabel_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, 100691013);
			VersionInfo.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr, 100691014);
		}

		// Token: 0x060159A1 RID: 88481 RVA: 0x00002988 File Offset: 0x00000B88
		public VersionInfo(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170079CD RID: 31181
		// (get) Token: 0x060159A2 RID: 88482 RVA: 0x0057059C File Offset: 0x0056E79C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VersionInfo>.NativeClassPtr));
			}
		}

		// Token: 0x170079CE RID: 31182
		// (get) Token: 0x060159A3 RID: 88483 RVA: 0x005705B0 File Offset: 0x0056E7B0
		// (set) Token: 0x060159A4 RID: 88484 RVA: 0x005705CE File Offset: 0x0056E7CE
		public unsafe static byte Major
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(VersionInfo.NativeFieldInfoPtr_Major, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VersionInfo.NativeFieldInfoPtr_Major, (void*)(&value));
			}
		}

		// Token: 0x170079CF RID: 31183
		// (get) Token: 0x060159A5 RID: 88485 RVA: 0x005705E0 File Offset: 0x0056E7E0
		// (set) Token: 0x060159A6 RID: 88486 RVA: 0x005705FE File Offset: 0x0056E7FE
		public unsafe static byte Minor
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(VersionInfo.NativeFieldInfoPtr_Minor, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VersionInfo.NativeFieldInfoPtr_Minor, (void*)(&value));
			}
		}

		// Token: 0x170079D0 RID: 31184
		// (get) Token: 0x060159A7 RID: 88487 RVA: 0x00570610 File Offset: 0x0056E810
		// (set) Token: 0x060159A8 RID: 88488 RVA: 0x0057062E File Offset: 0x0056E82E
		public unsafe static byte Release
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(VersionInfo.NativeFieldInfoPtr_Release, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VersionInfo.NativeFieldInfoPtr_Release, (void*)(&value));
			}
		}

		// Token: 0x170079D1 RID: 31185
		// (get) Token: 0x060159A9 RID: 88489 RVA: 0x00570640 File Offset: 0x0056E840
		// (set) Token: 0x060159AA RID: 88490 RVA: 0x0057065E File Offset: 0x0056E85E
		public unsafe static byte Revision
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(VersionInfo.NativeFieldInfoPtr_Revision, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VersionInfo.NativeFieldInfoPtr_Revision, (void*)(&value));
			}
		}

		// Token: 0x0400DD9F RID: 56735
		private static readonly IntPtr NativeFieldInfoPtr_Major;

		// Token: 0x0400DDA0 RID: 56736
		private static readonly IntPtr NativeFieldInfoPtr_Minor;

		// Token: 0x0400DDA1 RID: 56737
		private static readonly IntPtr NativeFieldInfoPtr_Release;

		// Token: 0x0400DDA2 RID: 56738
		private static readonly IntPtr NativeFieldInfoPtr_Revision;

		// Token: 0x0400DDA3 RID: 56739
		private static readonly IntPtr NativeMethodInfoPtr_StaticToString_Public_Static_String_0;

		// Token: 0x0400DDA4 RID: 56740
		private static readonly IntPtr NativeMethodInfoPtr_get_FullNumber_Public_Static_get_Int32_0;

		// Token: 0x0400DDA5 RID: 56741
		private static readonly IntPtr NativeMethodInfoPtr_get_FullLabel_Public_Static_get_String_0;

		// Token: 0x0400DDA6 RID: 56742
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
