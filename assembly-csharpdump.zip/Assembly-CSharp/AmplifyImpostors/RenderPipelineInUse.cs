﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001280 RID: 4736
	public enum RenderPipelineInUse
	{
		// Token: 0x0400DCD6 RID: 56534
		None,
		// Token: 0x0400DCD7 RID: 56535
		LW,
		// Token: 0x0400DCD8 RID: 56536
		HD,
		// Token: 0x0400DCD9 RID: 56537
		URP,
		// Token: 0x0400DCDA RID: 56538
		Custom = 3
	}
}
