﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x02001288 RID: 4744
	public enum TextureCompression
	{
		// Token: 0x0400DD3F RID: 56639
		None,
		// Token: 0x0400DD40 RID: 56640
		Normal,
		// Token: 0x0400DD41 RID: 56641
		High,
		// Token: 0x0400DD42 RID: 56642
		Low
	}
}
