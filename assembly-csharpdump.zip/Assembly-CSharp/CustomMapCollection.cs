﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.CustomMaps;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x02000184 RID: 388
public static class CustomMapCollection : Object
{
	// Token: 0x170008FF RID: 2303
	// (get) Token: 0x060019E3 RID: 6627 RVA: 0x000671D0 File Offset: 0x000653D0
	// (set) Token: 0x060019E4 RID: 6628 RVA: 0x0006720C File Offset: 0x0006540C
	public unsafe static string MapSummary
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_get_MapSummary_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_set_MapSummary_Private_Static_set_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x060019E5 RID: 6629 RVA: 0x00067258 File Offset: 0x00065458
	[CallerCount(0)]
	public unsafe static void Clear()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_Clear_Private_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019E6 RID: 6630 RVA: 0x0006728C File Offset: 0x0006548C
	[CallerCount(0)]
	public unsafe static void Scan()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_Scan_Public_Static_Void_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019E7 RID: 6631 RVA: 0x000672C0 File Offset: 0x000654C0
	[CallerCount(0)]
	public unsafe static WorkshopItem GetItemByMapHash(string mapHash)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(mapHash);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_GetItemByMapHash_Public_Static_WorkshopItem_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new WorkshopItem(intPtr2) : null;
	}

	// Token: 0x060019E8 RID: 6632 RVA: 0x00067320 File Offset: 0x00065520
	[CallerCount(0)]
	public unsafe static Il2CppStringArray GetRandomMaps(int maxMaps, GameVariantTypes variantType, WorkshopMapPlatformCompatibility filter)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref maxMaps;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref variantType;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref filter;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_GameVariantTypes_WorkshopMapPlatformCompatibility_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
	}

	// Token: 0x060019E9 RID: 6633 RVA: 0x000673A0 File Offset: 0x000655A0
	[CallerCount(0)]
	public unsafe static Il2CppStringArray GetRandomMaps(int maxMaps, Il2CppStructArray<GameVariantTypes> variantTypes, WorkshopMapPlatformCompatibility filter)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref maxMaps;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(variantTypes);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref filter;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_ArrayOf_GameVariantTypes_WorkshopMapPlatformCompatibility_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
	}

	// Token: 0x060019EA RID: 6634 RVA: 0x00067424 File Offset: 0x00065624
	[CallerCount(0)]
	public unsafe static bool MapSupportsCurrentMode(WorkshopItem workshopItem, GameVariantTypes variantType, GameVariantStyleTypes gameVariantStyleType)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(workshopItem);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref variantType;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref gameVariantStyleType;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_MapSupportsCurrentMode_Private_Static_Boolean_WorkshopItem_GameVariantTypes_GameVariantStyleTypes_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060019EB RID: 6635 RVA: 0x000674A4 File Offset: 0x000656A4
	[CallerCount(0)]
	public unsafe static void OnFetchNewItem(WorkshopItem workshopItem)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(workshopItem);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_OnFetchNewItem_Private_Static_Void_WorkshopItem_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060019EC RID: 6636 RVA: 0x000674F0 File Offset: 0x000656F0
	[CallerCount(0)]
	public unsafe static string GetMapHash(string mapID, string liveVersionId)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(mapID);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(liveVersionId);
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_GetMapHash_Private_Static_String_String_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x060019ED RID: 6637 RVA: 0x0006755C File Offset: 0x0006575C
	[CallerCount(0)]
	public unsafe static void ShuffleIDs(ref List<string> ids)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		ref IntPtr ptr2 = ref *ptr;
		IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(ids);
		ptr2 = &intPtr;
		IntPtr returnedException;
		IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(CustomMapCollection.NativeMethodInfoPtr_ShuffleIDs_Private_Static_Void_byref_List_1_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr3 = intPtr;
		ids = ((intPtr3 == 0) ? null : new List(intPtr3));
	}

	// Token: 0x060019EE RID: 6638 RVA: 0x000675C8 File Offset: 0x000657C8
	// Note: this type is marked as 'beforefieldinit'.
	static CustomMapCollection()
	{
		Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomMapCollection");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr);
		CustomMapCollection.NativeFieldInfoPtr_MAP_COLLECTION_SIZE_LIMIT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, "MAP_COLLECTION_SIZE_LIMIT");
		CustomMapCollection.NativeFieldInfoPtr_MAP_SUMMARY_PIECE_LENGTH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, "MAP_SUMMARY_PIECE_LENGTH");
		CustomMapCollection.NativeFieldInfoPtr_MapCollection = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, "MapCollection");
		CustomMapCollection.NativeFieldInfoPtr__MapSummary_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, "<MapSummary>k__BackingField");
		CustomMapCollection.NativeMethodInfoPtr_get_MapSummary_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665353);
		CustomMapCollection.NativeMethodInfoPtr_set_MapSummary_Private_Static_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665354);
		CustomMapCollection.NativeMethodInfoPtr_Clear_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665355);
		CustomMapCollection.NativeMethodInfoPtr_Scan_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665356);
		CustomMapCollection.NativeMethodInfoPtr_GetItemByMapHash_Public_Static_WorkshopItem_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665357);
		CustomMapCollection.NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_GameVariantTypes_WorkshopMapPlatformCompatibility_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665358);
		CustomMapCollection.NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_ArrayOf_GameVariantTypes_WorkshopMapPlatformCompatibility_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665359);
		CustomMapCollection.NativeMethodInfoPtr_MapSupportsCurrentMode_Private_Static_Boolean_WorkshopItem_GameVariantTypes_GameVariantStyleTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665360);
		CustomMapCollection.NativeMethodInfoPtr_OnFetchNewItem_Private_Static_Void_WorkshopItem_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665361);
		CustomMapCollection.NativeMethodInfoPtr_GetMapHash_Private_Static_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665362);
		CustomMapCollection.NativeMethodInfoPtr_ShuffleIDs_Private_Static_Void_byref_List_1_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr, 100665363);
	}

	// Token: 0x060019EF RID: 6639 RVA: 0x00002988 File Offset: 0x00000B88
	public CustomMapCollection(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170008FA RID: 2298
	// (get) Token: 0x060019F0 RID: 6640 RVA: 0x00067724 File Offset: 0x00065924
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomMapCollection>.NativeClassPtr));
		}
	}

	// Token: 0x170008FB RID: 2299
	// (get) Token: 0x060019F1 RID: 6641 RVA: 0x00067738 File Offset: 0x00065938
	// (set) Token: 0x060019F2 RID: 6642 RVA: 0x00067756 File Offset: 0x00065956
	public unsafe static int MAP_COLLECTION_SIZE_LIMIT
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(CustomMapCollection.NativeFieldInfoPtr_MAP_COLLECTION_SIZE_LIMIT, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomMapCollection.NativeFieldInfoPtr_MAP_COLLECTION_SIZE_LIMIT, (void*)(&value));
		}
	}

	// Token: 0x170008FC RID: 2300
	// (get) Token: 0x060019F3 RID: 6643 RVA: 0x00067768 File Offset: 0x00065968
	// (set) Token: 0x060019F4 RID: 6644 RVA: 0x00067786 File Offset: 0x00065986
	public unsafe static int MAP_SUMMARY_PIECE_LENGTH
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(CustomMapCollection.NativeFieldInfoPtr_MAP_SUMMARY_PIECE_LENGTH, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomMapCollection.NativeFieldInfoPtr_MAP_SUMMARY_PIECE_LENGTH, (void*)(&value));
		}
	}

	// Token: 0x170008FD RID: 2301
	// (get) Token: 0x060019F5 RID: 6645 RVA: 0x00067798 File Offset: 0x00065998
	// (set) Token: 0x060019F6 RID: 6646 RVA: 0x000677C3 File Offset: 0x000659C3
	public unsafe static Dictionary<string, WorkshopItem> MapCollection
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CustomMapCollection.NativeFieldInfoPtr_MapCollection, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<string, WorkshopItem>(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomMapCollection.NativeFieldInfoPtr_MapCollection, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170008FE RID: 2302
	// (get) Token: 0x060019F7 RID: 6647 RVA: 0x000677D8 File Offset: 0x000659D8
	// (set) Token: 0x060019F8 RID: 6648 RVA: 0x000677F8 File Offset: 0x000659F8
	public unsafe static string _MapSummary_k__BackingField
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(CustomMapCollection.NativeFieldInfoPtr__MapSummary_k__BackingField, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomMapCollection.NativeFieldInfoPtr__MapSummary_k__BackingField, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x04001095 RID: 4245
	private static readonly IntPtr NativeFieldInfoPtr_MAP_COLLECTION_SIZE_LIMIT;

	// Token: 0x04001096 RID: 4246
	private static readonly IntPtr NativeFieldInfoPtr_MAP_SUMMARY_PIECE_LENGTH;

	// Token: 0x04001097 RID: 4247
	private static readonly IntPtr NativeFieldInfoPtr_MapCollection;

	// Token: 0x04001098 RID: 4248
	private static readonly IntPtr NativeFieldInfoPtr__MapSummary_k__BackingField;

	// Token: 0x04001099 RID: 4249
	private static readonly IntPtr NativeMethodInfoPtr_get_MapSummary_Public_Static_get_String_0;

	// Token: 0x0400109A RID: 4250
	private static readonly IntPtr NativeMethodInfoPtr_set_MapSummary_Private_Static_set_Void_String_0;

	// Token: 0x0400109B RID: 4251
	private static readonly IntPtr NativeMethodInfoPtr_Clear_Private_Static_Void_0;

	// Token: 0x0400109C RID: 4252
	private static readonly IntPtr NativeMethodInfoPtr_Scan_Public_Static_Void_0;

	// Token: 0x0400109D RID: 4253
	private static readonly IntPtr NativeMethodInfoPtr_GetItemByMapHash_Public_Static_WorkshopItem_String_0;

	// Token: 0x0400109E RID: 4254
	private static readonly IntPtr NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_GameVariantTypes_WorkshopMapPlatformCompatibility_0;

	// Token: 0x0400109F RID: 4255
	private static readonly IntPtr NativeMethodInfoPtr_GetRandomMaps_Public_Static_ArrayOf_Int32_ArrayOf_GameVariantTypes_WorkshopMapPlatformCompatibility_0;

	// Token: 0x040010A0 RID: 4256
	private static readonly IntPtr NativeMethodInfoPtr_MapSupportsCurrentMode_Private_Static_Boolean_WorkshopItem_GameVariantTypes_GameVariantStyleTypes_0;

	// Token: 0x040010A1 RID: 4257
	private static readonly IntPtr NativeMethodInfoPtr_OnFetchNewItem_Private_Static_Void_WorkshopItem_0;

	// Token: 0x040010A2 RID: 4258
	private static readonly IntPtr NativeMethodInfoPtr_GetMapHash_Private_Static_String_String_String_0;

	// Token: 0x040010A3 RID: 4259
	private static readonly IntPtr NativeMethodInfoPtr_ShuffleIDs_Private_Static_Void_byref_List_1_String_0;
}
