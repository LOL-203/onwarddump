﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000C3 RID: 195
public class boardScript : MonoBehaviour
{
	// Token: 0x06000C2A RID: 3114 RVA: 0x000318E0 File Offset: 0x0002FAE0
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(boardScript.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x00031924 File Offset: 0x0002FB24
	[CallerCount(0)]
	public unsafe void AddBoard()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(boardScript.NativeMethodInfoPtr_AddBoard_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x00031968 File Offset: 0x0002FB68
	[CallerCount(0)]
	public unsafe void RemoveBoard()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(boardScript.NativeMethodInfoPtr_RemoveBoard_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x000319AC File Offset: 0x0002FBAC
	[CallerCount(0)]
	public unsafe boardScript() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<boardScript>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(boardScript.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x000319F8 File Offset: 0x0002FBF8
	// Note: this type is marked as 'beforefieldinit'.
	static boardScript()
	{
		Il2CppClassPointerStore<boardScript>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "boardScript");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<boardScript>.NativeClassPtr);
		boardScript.NativeFieldInfoPtr_boards = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<boardScript>.NativeClassPtr, "boards");
		boardScript.NativeFieldInfoPtr_previousBoards = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<boardScript>.NativeClassPtr, "previousBoards");
		boardScript.NativeFieldInfoPtr_boardAnim = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<boardScript>.NativeClassPtr, "boardAnim");
		boardScript.NativeFieldInfoPtr_board = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<boardScript>.NativeClassPtr, "board");
		boardScript.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<boardScript>.NativeClassPtr, 100664246);
		boardScript.NativeMethodInfoPtr_AddBoard_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<boardScript>.NativeClassPtr, 100664247);
		boardScript.NativeMethodInfoPtr_RemoveBoard_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<boardScript>.NativeClassPtr, 100664248);
		boardScript.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<boardScript>.NativeClassPtr, 100664249);
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x0000210C File Offset: 0x0000030C
	public boardScript(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000431 RID: 1073
	// (get) Token: 0x06000C30 RID: 3120 RVA: 0x00031AC8 File Offset: 0x0002FCC8
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<boardScript>.NativeClassPtr));
		}
	}

	// Token: 0x17000432 RID: 1074
	// (get) Token: 0x06000C31 RID: 3121 RVA: 0x00031ADC File Offset: 0x0002FCDC
	// (set) Token: 0x06000C32 RID: 3122 RVA: 0x00031B04 File Offset: 0x0002FD04
	public unsafe int boards
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_boards);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_boards)) = value;
		}
	}

	// Token: 0x17000433 RID: 1075
	// (get) Token: 0x06000C33 RID: 3123 RVA: 0x00031B28 File Offset: 0x0002FD28
	// (set) Token: 0x06000C34 RID: 3124 RVA: 0x00031B50 File Offset: 0x0002FD50
	public unsafe int previousBoards
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_previousBoards);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_previousBoards)) = value;
		}
	}

	// Token: 0x17000434 RID: 1076
	// (get) Token: 0x06000C35 RID: 3125 RVA: 0x00031B74 File Offset: 0x0002FD74
	// (set) Token: 0x06000C36 RID: 3126 RVA: 0x00031BA8 File Offset: 0x0002FDA8
	public unsafe Il2CppReferenceArray<Animator> boardAnim
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_boardAnim);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Animator>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_boardAnim), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000435 RID: 1077
	// (get) Token: 0x06000C37 RID: 3127 RVA: 0x00031BD0 File Offset: 0x0002FDD0
	// (set) Token: 0x06000C38 RID: 3128 RVA: 0x00031C04 File Offset: 0x0002FE04
	public unsafe Il2CppReferenceArray<GameObject> board
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_board);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(boardScript.NativeFieldInfoPtr_board), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400075E RID: 1886
	private static readonly IntPtr NativeFieldInfoPtr_boards;

	// Token: 0x0400075F RID: 1887
	private static readonly IntPtr NativeFieldInfoPtr_previousBoards;

	// Token: 0x04000760 RID: 1888
	private static readonly IntPtr NativeFieldInfoPtr_boardAnim;

	// Token: 0x04000761 RID: 1889
	private static readonly IntPtr NativeFieldInfoPtr_board;

	// Token: 0x04000762 RID: 1890
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04000763 RID: 1891
	private static readonly IntPtr NativeMethodInfoPtr_AddBoard_Private_Void_0;

	// Token: 0x04000764 RID: 1892
	private static readonly IntPtr NativeMethodInfoPtr_RemoveBoard_Private_Void_0;

	// Token: 0x04000765 RID: 1893
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
