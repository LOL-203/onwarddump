﻿using System;

// Token: 0x02000186 RID: 390
[Flags]
public enum CustomMapRoomFlags : byte
{
	// Token: 0x040010B0 RID: 4272
	None = 0,
	// Token: 0x040010B1 RID: 4273
	PCPlatform = 1,
	// Token: 0x040010B2 RID: 4274
	AndroidPlatform = 2
}
