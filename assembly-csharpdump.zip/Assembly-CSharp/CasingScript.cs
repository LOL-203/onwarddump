﻿using System;
using Il2CppSystem;
using Onward.Weapons;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004F2 RID: 1266
public class CasingScript : MonoBehaviour
{
	// Token: 0x170024A4 RID: 9380
	// (get) Token: 0x060066FB RID: 26363 RVA: 0x0019D9A4 File Offset: 0x0019BBA4
	// (set) Token: 0x060066FC RID: 26364 RVA: 0x0019D9F4 File Offset: 0x0019BBF4
	public unsafe bool ManagedLateUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x060066FD RID: 26365 RVA: 0x0019DA48 File Offset: 0x0019BC48
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066FE RID: 26366 RVA: 0x0019DA8C File Offset: 0x0019BC8C
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060066FF RID: 26367 RVA: 0x0019DAD0 File Offset: 0x0019BCD0
	[CallerCount(0)]
	public unsafe void OnManagedLateUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006700 RID: 26368 RVA: 0x0019DB14 File Offset: 0x0019BD14
	[CallerCount(0)]
	public unsafe void Initialize()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006701 RID: 26369 RVA: 0x0019DB58 File Offset: 0x0019BD58
	[CallerCount(0)]
	public unsafe void RemoveCasing()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_RemoveCasing_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006702 RID: 26370 RVA: 0x0019DB9C File Offset: 0x0019BD9C
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006703 RID: 26371 RVA: 0x0019DBE0 File Offset: 0x0019BDE0
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006704 RID: 26372 RVA: 0x0019DC24 File Offset: 0x0019BE24
	[CallerCount(0)]
	public unsafe void SetAmmoType(ClassLoadout.AmmoType ammoType)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref ammoType;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr_SetAmmoType_Public_Void_AmmoType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006705 RID: 26373 RVA: 0x0019DC78 File Offset: 0x0019BE78
	[CallerCount(0)]
	public unsafe CasingScript() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CasingScript>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingScript.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006706 RID: 26374 RVA: 0x0019DCC4 File Offset: 0x0019BEC4
	// Note: this type is marked as 'beforefieldinit'.
	static CasingScript()
	{
		Il2CppClassPointerStore<CasingScript>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CasingScript");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CasingScript>.NativeClassPtr);
		CasingScript.NativeFieldInfoPtr_isAtlased = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "isAtlased");
		CasingScript.NativeFieldInfoPtr_minimumXForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "minimumXForce");
		CasingScript.NativeFieldInfoPtr_maximumXForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "maximumXForce");
		CasingScript.NativeFieldInfoPtr_minimumYForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "minimumYForce");
		CasingScript.NativeFieldInfoPtr_maximumYForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "maximumYForce");
		CasingScript.NativeFieldInfoPtr_minimumZForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "minimumZForce");
		CasingScript.NativeFieldInfoPtr_maximumZForce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "maximumZForce");
		CasingScript.NativeFieldInfoPtr_rotateSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "rotateSpeed");
		CasingScript.NativeFieldInfoPtr_despawnTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "despawnTime");
		CasingScript.NativeFieldInfoPtr_ammoVisuals = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "ammoVisuals");
		CasingScript.NativeFieldInfoPtr_casingTransform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "casingTransform");
		CasingScript.NativeFieldInfoPtr_body = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "body");
		CasingScript.NativeFieldInfoPtr__isGrounded = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "_isGrounded");
		CasingScript.NativeFieldInfoPtr__prevVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "_prevVelocity");
		CasingScript.NativeFieldInfoPtr__timeUntilDespawn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "_timeUntilDespawn");
		CasingScript.NativeFieldInfoPtr__transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "_transform");
		CasingScript.NativeFieldInfoPtr_VELOCITY_SPEED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "VELOCITY_SPEED");
		CasingScript.NativeFieldInfoPtr_BOUNCE_SOUND_SPEED = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "BOUNCE_SOUND_SPEED");
		CasingScript.NativeFieldInfoPtr_Z_FORCE_MULTIPLIER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "Z_FORCE_MULTIPLIER");
		CasingScript.NativeFieldInfoPtr_pooledObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "pooledObject");
		CasingScript.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, "<ManagedLateUpdateRemoval>k__BackingField");
		CasingScript.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671484);
		CasingScript.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671485);
		CasingScript.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671486);
		CasingScript.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671487);
		CasingScript.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671488);
		CasingScript.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671489);
		CasingScript.NativeMethodInfoPtr_RemoveCasing_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671490);
		CasingScript.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671491);
		CasingScript.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671492);
		CasingScript.NativeMethodInfoPtr_SetAmmoType_Public_Void_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671493);
		CasingScript.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingScript>.NativeClassPtr, 100671494);
	}

	// Token: 0x06006707 RID: 26375 RVA: 0x0000210C File Offset: 0x0000030C
	public CasingScript(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700248E RID: 9358
	// (get) Token: 0x06006708 RID: 26376 RVA: 0x0019DF74 File Offset: 0x0019C174
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CasingScript>.NativeClassPtr));
		}
	}

	// Token: 0x1700248F RID: 9359
	// (get) Token: 0x06006709 RID: 26377 RVA: 0x0019DF88 File Offset: 0x0019C188
	// (set) Token: 0x0600670A RID: 26378 RVA: 0x0019DFB0 File Offset: 0x0019C1B0
	public unsafe bool isAtlased
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_isAtlased);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_isAtlased)) = value;
		}
	}

	// Token: 0x17002490 RID: 9360
	// (get) Token: 0x0600670B RID: 26379 RVA: 0x0019DFD4 File Offset: 0x0019C1D4
	// (set) Token: 0x0600670C RID: 26380 RVA: 0x0019DFFC File Offset: 0x0019C1FC
	public unsafe float minimumXForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumXForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumXForce)) = value;
		}
	}

	// Token: 0x17002491 RID: 9361
	// (get) Token: 0x0600670D RID: 26381 RVA: 0x0019E020 File Offset: 0x0019C220
	// (set) Token: 0x0600670E RID: 26382 RVA: 0x0019E048 File Offset: 0x0019C248
	public unsafe float maximumXForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumXForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumXForce)) = value;
		}
	}

	// Token: 0x17002492 RID: 9362
	// (get) Token: 0x0600670F RID: 26383 RVA: 0x0019E06C File Offset: 0x0019C26C
	// (set) Token: 0x06006710 RID: 26384 RVA: 0x0019E094 File Offset: 0x0019C294
	public unsafe float minimumYForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumYForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumYForce)) = value;
		}
	}

	// Token: 0x17002493 RID: 9363
	// (get) Token: 0x06006711 RID: 26385 RVA: 0x0019E0B8 File Offset: 0x0019C2B8
	// (set) Token: 0x06006712 RID: 26386 RVA: 0x0019E0E0 File Offset: 0x0019C2E0
	public unsafe float maximumYForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumYForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumYForce)) = value;
		}
	}

	// Token: 0x17002494 RID: 9364
	// (get) Token: 0x06006713 RID: 26387 RVA: 0x0019E104 File Offset: 0x0019C304
	// (set) Token: 0x06006714 RID: 26388 RVA: 0x0019E12C File Offset: 0x0019C32C
	public unsafe float minimumZForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumZForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_minimumZForce)) = value;
		}
	}

	// Token: 0x17002495 RID: 9365
	// (get) Token: 0x06006715 RID: 26389 RVA: 0x0019E150 File Offset: 0x0019C350
	// (set) Token: 0x06006716 RID: 26390 RVA: 0x0019E178 File Offset: 0x0019C378
	public unsafe float maximumZForce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumZForce);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_maximumZForce)) = value;
		}
	}

	// Token: 0x17002496 RID: 9366
	// (get) Token: 0x06006717 RID: 26391 RVA: 0x0019E19C File Offset: 0x0019C39C
	// (set) Token: 0x06006718 RID: 26392 RVA: 0x0019E1C4 File Offset: 0x0019C3C4
	public unsafe float rotateSpeed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_rotateSpeed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_rotateSpeed)) = value;
		}
	}

	// Token: 0x17002497 RID: 9367
	// (get) Token: 0x06006719 RID: 26393 RVA: 0x0019E1E8 File Offset: 0x0019C3E8
	// (set) Token: 0x0600671A RID: 26394 RVA: 0x0019E210 File Offset: 0x0019C410
	public unsafe float despawnTime
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_despawnTime);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_despawnTime)) = value;
		}
	}

	// Token: 0x17002498 RID: 9368
	// (get) Token: 0x0600671B RID: 26395 RVA: 0x0019E234 File Offset: 0x0019C434
	// (set) Token: 0x0600671C RID: 26396 RVA: 0x0019E268 File Offset: 0x0019C468
	public unsafe AmmoVisuals ammoVisuals
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_ammoVisuals);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AmmoVisuals(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_ammoVisuals), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002499 RID: 9369
	// (get) Token: 0x0600671D RID: 26397 RVA: 0x0019E290 File Offset: 0x0019C490
	// (set) Token: 0x0600671E RID: 26398 RVA: 0x0019E2C4 File Offset: 0x0019C4C4
	public unsafe Transform casingTransform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_casingTransform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_casingTransform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700249A RID: 9370
	// (get) Token: 0x0600671F RID: 26399 RVA: 0x0019E2EC File Offset: 0x0019C4EC
	// (set) Token: 0x06006720 RID: 26400 RVA: 0x0019E320 File Offset: 0x0019C520
	public unsafe Rigidbody body
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_body);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_body), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700249B RID: 9371
	// (get) Token: 0x06006721 RID: 26401 RVA: 0x0019E348 File Offset: 0x0019C548
	// (set) Token: 0x06006722 RID: 26402 RVA: 0x0019E370 File Offset: 0x0019C570
	public unsafe bool _isGrounded
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__isGrounded);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__isGrounded)) = value;
		}
	}

	// Token: 0x1700249C RID: 9372
	// (get) Token: 0x06006723 RID: 26403 RVA: 0x0019E394 File Offset: 0x0019C594
	// (set) Token: 0x06006724 RID: 26404 RVA: 0x0019E3BC File Offset: 0x0019C5BC
	public unsafe float _prevVelocity
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__prevVelocity);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__prevVelocity)) = value;
		}
	}

	// Token: 0x1700249D RID: 9373
	// (get) Token: 0x06006725 RID: 26405 RVA: 0x0019E3E0 File Offset: 0x0019C5E0
	// (set) Token: 0x06006726 RID: 26406 RVA: 0x0019E408 File Offset: 0x0019C608
	public unsafe float _timeUntilDespawn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__timeUntilDespawn);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__timeUntilDespawn)) = value;
		}
	}

	// Token: 0x1700249E RID: 9374
	// (get) Token: 0x06006727 RID: 26407 RVA: 0x0019E42C File Offset: 0x0019C62C
	// (set) Token: 0x06006728 RID: 26408 RVA: 0x0019E460 File Offset: 0x0019C660
	public unsafe Transform _transform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__transform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__transform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700249F RID: 9375
	// (get) Token: 0x06006729 RID: 26409 RVA: 0x0019E488 File Offset: 0x0019C688
	// (set) Token: 0x0600672A RID: 26410 RVA: 0x0019E4A6 File Offset: 0x0019C6A6
	public unsafe static float VELOCITY_SPEED
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CasingScript.NativeFieldInfoPtr_VELOCITY_SPEED, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CasingScript.NativeFieldInfoPtr_VELOCITY_SPEED, (void*)(&value));
		}
	}

	// Token: 0x170024A0 RID: 9376
	// (get) Token: 0x0600672B RID: 26411 RVA: 0x0019E4B8 File Offset: 0x0019C6B8
	// (set) Token: 0x0600672C RID: 26412 RVA: 0x0019E4D6 File Offset: 0x0019C6D6
	public unsafe static float BOUNCE_SOUND_SPEED
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CasingScript.NativeFieldInfoPtr_BOUNCE_SOUND_SPEED, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CasingScript.NativeFieldInfoPtr_BOUNCE_SOUND_SPEED, (void*)(&value));
		}
	}

	// Token: 0x170024A1 RID: 9377
	// (get) Token: 0x0600672D RID: 26413 RVA: 0x0019E4E8 File Offset: 0x0019C6E8
	// (set) Token: 0x0600672E RID: 26414 RVA: 0x0019E506 File Offset: 0x0019C706
	public unsafe static float Z_FORCE_MULTIPLIER
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CasingScript.NativeFieldInfoPtr_Z_FORCE_MULTIPLIER, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CasingScript.NativeFieldInfoPtr_Z_FORCE_MULTIPLIER, (void*)(&value));
		}
	}

	// Token: 0x170024A2 RID: 9378
	// (get) Token: 0x0600672F RID: 26415 RVA: 0x0019E518 File Offset: 0x0019C718
	// (set) Token: 0x06006730 RID: 26416 RVA: 0x0019E54C File Offset: 0x0019C74C
	public unsafe PooledObject pooledObject
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_pooledObject);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new PooledObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr_pooledObject), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170024A3 RID: 9379
	// (get) Token: 0x06006731 RID: 26417 RVA: 0x0019E574 File Offset: 0x0019C774
	// (set) Token: 0x06006732 RID: 26418 RVA: 0x0019E59C File Offset: 0x0019C79C
	public unsafe bool _ManagedLateUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingScript.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x04004108 RID: 16648
	private static readonly IntPtr NativeFieldInfoPtr_isAtlased;

	// Token: 0x04004109 RID: 16649
	private static readonly IntPtr NativeFieldInfoPtr_minimumXForce;

	// Token: 0x0400410A RID: 16650
	private static readonly IntPtr NativeFieldInfoPtr_maximumXForce;

	// Token: 0x0400410B RID: 16651
	private static readonly IntPtr NativeFieldInfoPtr_minimumYForce;

	// Token: 0x0400410C RID: 16652
	private static readonly IntPtr NativeFieldInfoPtr_maximumYForce;

	// Token: 0x0400410D RID: 16653
	private static readonly IntPtr NativeFieldInfoPtr_minimumZForce;

	// Token: 0x0400410E RID: 16654
	private static readonly IntPtr NativeFieldInfoPtr_maximumZForce;

	// Token: 0x0400410F RID: 16655
	private static readonly IntPtr NativeFieldInfoPtr_rotateSpeed;

	// Token: 0x04004110 RID: 16656
	private static readonly IntPtr NativeFieldInfoPtr_despawnTime;

	// Token: 0x04004111 RID: 16657
	private static readonly IntPtr NativeFieldInfoPtr_ammoVisuals;

	// Token: 0x04004112 RID: 16658
	private static readonly IntPtr NativeFieldInfoPtr_casingTransform;

	// Token: 0x04004113 RID: 16659
	private static readonly IntPtr NativeFieldInfoPtr_body;

	// Token: 0x04004114 RID: 16660
	private static readonly IntPtr NativeFieldInfoPtr__isGrounded;

	// Token: 0x04004115 RID: 16661
	private static readonly IntPtr NativeFieldInfoPtr__prevVelocity;

	// Token: 0x04004116 RID: 16662
	private static readonly IntPtr NativeFieldInfoPtr__timeUntilDespawn;

	// Token: 0x04004117 RID: 16663
	private static readonly IntPtr NativeFieldInfoPtr__transform;

	// Token: 0x04004118 RID: 16664
	private static readonly IntPtr NativeFieldInfoPtr_VELOCITY_SPEED;

	// Token: 0x04004119 RID: 16665
	private static readonly IntPtr NativeFieldInfoPtr_BOUNCE_SOUND_SPEED;

	// Token: 0x0400411A RID: 16666
	private static readonly IntPtr NativeFieldInfoPtr_Z_FORCE_MULTIPLIER;

	// Token: 0x0400411B RID: 16667
	private static readonly IntPtr NativeFieldInfoPtr_pooledObject;

	// Token: 0x0400411C RID: 16668
	private static readonly IntPtr NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField;

	// Token: 0x0400411D RID: 16669
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x0400411E RID: 16670
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x0400411F RID: 16671
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x04004120 RID: 16672
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04004121 RID: 16673
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04004122 RID: 16674
	private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

	// Token: 0x04004123 RID: 16675
	private static readonly IntPtr NativeMethodInfoPtr_RemoveCasing_Private_Void_0;

	// Token: 0x04004124 RID: 16676
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x04004125 RID: 16677
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x04004126 RID: 16678
	private static readonly IntPtr NativeMethodInfoPtr_SetAmmoType_Public_Void_AmmoType_0;

	// Token: 0x04004127 RID: 16679
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
