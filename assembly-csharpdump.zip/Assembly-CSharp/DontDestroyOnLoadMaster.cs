﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000D3 RID: 211
public class DontDestroyOnLoadMaster : MonoBehaviour
{
	// Token: 0x06000CF1 RID: 3313 RVA: 0x000345F0 File Offset: 0x000327F0
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF2 RID: 3314 RVA: 0x00034634 File Offset: 0x00032834
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF3 RID: 3315 RVA: 0x00034678 File Offset: 0x00032878
	[CallerCount(0)]
	public unsafe void OnApplicationQuit()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF4 RID: 3316 RVA: 0x000346BC File Offset: 0x000328BC
	[CallerCount(0)]
	public unsafe void ShutdownSteamClient()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr_ShutdownSteamClient_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF5 RID: 3317 RVA: 0x00034700 File Offset: 0x00032900
	[CallerCount(0)]
	public unsafe void CleanupOnward()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr_CleanupOnward_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x00034744 File Offset: 0x00032944
	[CallerCount(0)]
	public unsafe DontDestroyOnLoadMaster() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DontDestroyOnLoadMaster.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x00034790 File Offset: 0x00032990
	// Note: this type is marked as 'beforefieldinit'.
	static DontDestroyOnLoadMaster()
	{
		Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DontDestroyOnLoadMaster");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr);
		DontDestroyOnLoadMaster.NativeFieldInfoPtr_Singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, "Singleton");
		DontDestroyOnLoadMaster.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664307);
		DontDestroyOnLoadMaster.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664308);
		DontDestroyOnLoadMaster.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664309);
		DontDestroyOnLoadMaster.NativeMethodInfoPtr_ShutdownSteamClient_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664310);
		DontDestroyOnLoadMaster.NativeMethodInfoPtr_CleanupOnward_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664311);
		DontDestroyOnLoadMaster.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr, 100664312);
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x0000210C File Offset: 0x0000030C
	public DontDestroyOnLoadMaster(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000475 RID: 1141
	// (get) Token: 0x06000CF9 RID: 3321 RVA: 0x0003484C File Offset: 0x00032A4C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DontDestroyOnLoadMaster>.NativeClassPtr));
		}
	}

	// Token: 0x17000476 RID: 1142
	// (get) Token: 0x06000CFA RID: 3322 RVA: 0x00034860 File Offset: 0x00032A60
	// (set) Token: 0x06000CFB RID: 3323 RVA: 0x0003488B File Offset: 0x00032A8B
	public unsafe static DontDestroyOnLoadMaster Singleton
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(DontDestroyOnLoadMaster.NativeFieldInfoPtr_Singleton, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DontDestroyOnLoadMaster(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DontDestroyOnLoadMaster.NativeFieldInfoPtr_Singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040007D0 RID: 2000
	private static readonly IntPtr NativeFieldInfoPtr_Singleton;

	// Token: 0x040007D1 RID: 2001
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x040007D2 RID: 2002
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x040007D3 RID: 2003
	private static readonly IntPtr NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0;

	// Token: 0x040007D4 RID: 2004
	private static readonly IntPtr NativeMethodInfoPtr_ShutdownSteamClient_Private_Void_0;

	// Token: 0x040007D5 RID: 2005
	private static readonly IntPtr NativeMethodInfoPtr_CleanupOnward_Private_Void_0;

	// Token: 0x040007D6 RID: 2006
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
