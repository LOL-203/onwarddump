﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200049C RID: 1180
public class BufferedFloats : Object
{
	// Token: 0x06005E0B RID: 24075 RVA: 0x00177E88 File Offset: 0x00176088
	[CallerCount(0)]
	public unsafe void Add(Il2CppStructArray<float> srcBuf)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(srcBuf);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BufferedFloats.NativeMethodInfoPtr_Add_Public_Void_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E0C RID: 24076 RVA: 0x00177EE4 File Offset: 0x001760E4
	[CallerCount(0)]
	public unsafe bool TryConsume(Il2CppStructArray<float> targetBuf, int count)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(targetBuf);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref count;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BufferedFloats.NativeMethodInfoPtr_TryConsume_Public_Boolean_ArrayOf_Single_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005E0D RID: 24077 RVA: 0x00177F60 File Offset: 0x00176160
	[CallerCount(0)]
	public unsafe void ClearBuffer()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BufferedFloats.NativeMethodInfoPtr_ClearBuffer_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E0E RID: 24078 RVA: 0x00177FA4 File Offset: 0x001761A4
	[CallerCount(0)]
	public unsafe BufferedFloats() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BufferedFloats.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E0F RID: 24079 RVA: 0x00177FF0 File Offset: 0x001761F0
	// Note: this type is marked as 'beforefieldinit'.
	static BufferedFloats()
	{
		Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BufferedFloats");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr);
		BufferedFloats.NativeFieldInfoPtr_HasInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, "HasInitialized");
		BufferedFloats.NativeFieldInfoPtr_CanBeWrittenTo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, "CanBeWrittenTo");
		BufferedFloats.NativeFieldInfoPtr__values = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, "_values");
		BufferedFloats.NativeMethodInfoPtr_Add_Public_Void_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, 100670716);
		BufferedFloats.NativeMethodInfoPtr_TryConsume_Public_Boolean_ArrayOf_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, 100670717);
		BufferedFloats.NativeMethodInfoPtr_ClearBuffer_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, 100670718);
		BufferedFloats.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr, 100670719);
	}

	// Token: 0x06005E10 RID: 24080 RVA: 0x00002988 File Offset: 0x00000B88
	public BufferedFloats(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700216A RID: 8554
	// (get) Token: 0x06005E11 RID: 24081 RVA: 0x001780AC File Offset: 0x001762AC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BufferedFloats>.NativeClassPtr));
		}
	}

	// Token: 0x1700216B RID: 8555
	// (get) Token: 0x06005E12 RID: 24082 RVA: 0x001780C0 File Offset: 0x001762C0
	// (set) Token: 0x06005E13 RID: 24083 RVA: 0x001780E8 File Offset: 0x001762E8
	public unsafe bool HasInitialized
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr_HasInitialized);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr_HasInitialized)) = value;
		}
	}

	// Token: 0x1700216C RID: 8556
	// (get) Token: 0x06005E14 RID: 24084 RVA: 0x0017810C File Offset: 0x0017630C
	// (set) Token: 0x06005E15 RID: 24085 RVA: 0x00178134 File Offset: 0x00176334
	public unsafe bool CanBeWrittenTo
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr_CanBeWrittenTo);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr_CanBeWrittenTo)) = value;
		}
	}

	// Token: 0x1700216D RID: 8557
	// (get) Token: 0x06005E16 RID: 24086 RVA: 0x00178158 File Offset: 0x00176358
	// (set) Token: 0x06005E17 RID: 24087 RVA: 0x0017818C File Offset: 0x0017638C
	public unsafe List<float> _values
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr__values);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<float>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BufferedFloats.NativeFieldInfoPtr__values), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04003B60 RID: 15200
	private static readonly IntPtr NativeFieldInfoPtr_HasInitialized;

	// Token: 0x04003B61 RID: 15201
	private static readonly IntPtr NativeFieldInfoPtr_CanBeWrittenTo;

	// Token: 0x04003B62 RID: 15202
	private static readonly IntPtr NativeFieldInfoPtr__values;

	// Token: 0x04003B63 RID: 15203
	private static readonly IntPtr NativeMethodInfoPtr_Add_Public_Void_ArrayOf_Single_0;

	// Token: 0x04003B64 RID: 15204
	private static readonly IntPtr NativeMethodInfoPtr_TryConsume_Public_Boolean_ArrayOf_Single_Int32_0;

	// Token: 0x04003B65 RID: 15205
	private static readonly IntPtr NativeMethodInfoPtr_ClearBuffer_Public_Void_0;

	// Token: 0x04003B66 RID: 15206
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
