﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003A4 RID: 932
public class ClusterLODGroup : MonoBehaviour
{
	// Token: 0x06004A5E RID: 19038 RVA: 0x0012A498 File Offset: 0x00128698
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_OnEnable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A5F RID: 19039 RVA: 0x0012A4DC File Offset: 0x001286DC
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_OnDisable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17001AA3 RID: 6819
	// (get) Token: 0x06004A60 RID: 19040 RVA: 0x0012A520 File Offset: 0x00128720
	// (set) Token: 0x06004A61 RID: 19041 RVA: 0x0012A570 File Offset: 0x00128770
	public unsafe bool ManagedUpdateRemoval
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06004A62 RID: 19042 RVA: 0x0012A5C4 File Offset: 0x001287C4
	[CallerCount(0)]
	public unsafe void OnManagedUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A63 RID: 19043 RVA: 0x0012A608 File Offset: 0x00128808
	[CallerCount(0)]
	public unsafe ClusterLODGroup.ClusterLODThreshold GetCurrentThreshold()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_GetCurrentThreshold_Protected_ClusterLODThreshold_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new ClusterLODGroup.ClusterLODThreshold(intPtr2) : null;
	}

	// Token: 0x06004A64 RID: 19044 RVA: 0x0012A660 File Offset: 0x00128860
	[CallerCount(0)]
	public unsafe void UpdateLODGroups()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr_UpdateLODGroups_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A65 RID: 19045 RVA: 0x0012A6A4 File Offset: 0x001288A4
	[CallerCount(0)]
	public unsafe ClusterLODGroup() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004A66 RID: 19046 RVA: 0x0012A6F0 File Offset: 0x001288F0
	// Note: this type is marked as 'beforefieldinit'.
	static ClusterLODGroup()
	{
		Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ClusterLODGroup");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr);
		ClusterLODGroup.NativeFieldInfoPtr_ClusterType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "ClusterType");
		ClusterLODGroup.NativeFieldInfoPtr_QuestDefaultGroup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "QuestDefaultGroup");
		ClusterLODGroup.NativeFieldInfoPtr_PCGroup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "PCGroup");
		ClusterLODGroup.NativeFieldInfoPtr_Thresholds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "Thresholds");
		ClusterLODGroup.NativeFieldInfoPtr_AllLods = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "AllLods");
		ClusterLODGroup.NativeFieldInfoPtr_FRAME_SKIP = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "FRAME_SKIP");
		ClusterLODGroup.NativeFieldInfoPtr_frameSkipStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "frameSkipStart");
		ClusterLODGroup.NativeFieldInfoPtr_frameSkipCounter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "frameSkipCounter");
		ClusterLODGroup.NativeFieldInfoPtr_CurrentGroup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "CurrentGroup");
		ClusterLODGroup.NativeFieldInfoPtr__warPlayerScript = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "_warPlayerScript");
		ClusterLODGroup.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
		ClusterLODGroup.NativeMethodInfoPtr_OnEnable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669149);
		ClusterLODGroup.NativeMethodInfoPtr_OnDisable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669150);
		ClusterLODGroup.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669151);
		ClusterLODGroup.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669152);
		ClusterLODGroup.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669153);
		ClusterLODGroup.NativeMethodInfoPtr_GetCurrentThreshold_Protected_ClusterLODThreshold_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669154);
		ClusterLODGroup.NativeMethodInfoPtr_UpdateLODGroups_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669155);
		ClusterLODGroup.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, 100669156);
	}

	// Token: 0x06004A67 RID: 19047 RVA: 0x0000210C File Offset: 0x0000030C
	public ClusterLODGroup(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001A97 RID: 6807
	// (get) Token: 0x06004A68 RID: 19048 RVA: 0x0012A89C File Offset: 0x00128A9C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr));
		}
	}

	// Token: 0x17001A98 RID: 6808
	// (get) Token: 0x06004A69 RID: 19049 RVA: 0x0012A8B0 File Offset: 0x00128AB0
	// (set) Token: 0x06004A6A RID: 19050 RVA: 0x0012A8D8 File Offset: 0x00128AD8
	public unsafe ClusterLODGroup.ClusterLODType ClusterType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_ClusterType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_ClusterType)) = value;
		}
	}

	// Token: 0x17001A99 RID: 6809
	// (get) Token: 0x06004A6B RID: 19051 RVA: 0x0012A8FC File Offset: 0x00128AFC
	// (set) Token: 0x06004A6C RID: 19052 RVA: 0x0012A930 File Offset: 0x00128B30
	public unsafe LODGroup QuestDefaultGroup
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_QuestDefaultGroup);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_QuestDefaultGroup), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001A9A RID: 6810
	// (get) Token: 0x06004A6D RID: 19053 RVA: 0x0012A958 File Offset: 0x00128B58
	// (set) Token: 0x06004A6E RID: 19054 RVA: 0x0012A98C File Offset: 0x00128B8C
	public unsafe LODGroup PCGroup
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_PCGroup);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_PCGroup), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001A9B RID: 6811
	// (get) Token: 0x06004A6F RID: 19055 RVA: 0x0012A9B4 File Offset: 0x00128BB4
	// (set) Token: 0x06004A70 RID: 19056 RVA: 0x0012A9E8 File Offset: 0x00128BE8
	public unsafe Il2CppReferenceArray<ClusterLODGroup.ClusterLODThreshold> Thresholds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_Thresholds);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClusterLODGroup.ClusterLODThreshold>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_Thresholds), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001A9C RID: 6812
	// (get) Token: 0x06004A71 RID: 19057 RVA: 0x0012AA10 File Offset: 0x00128C10
	// (set) Token: 0x06004A72 RID: 19058 RVA: 0x0012AA44 File Offset: 0x00128C44
	public unsafe List<GameObject> AllLods
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_AllLods);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_AllLods), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001A9D RID: 6813
	// (get) Token: 0x06004A73 RID: 19059 RVA: 0x0012AA6C File Offset: 0x00128C6C
	// (set) Token: 0x06004A74 RID: 19060 RVA: 0x0012AA8A File Offset: 0x00128C8A
	public unsafe static int FRAME_SKIP
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(ClusterLODGroup.NativeFieldInfoPtr_FRAME_SKIP, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClusterLODGroup.NativeFieldInfoPtr_FRAME_SKIP, (void*)(&value));
		}
	}

	// Token: 0x17001A9E RID: 6814
	// (get) Token: 0x06004A75 RID: 19061 RVA: 0x0012AA9C File Offset: 0x00128C9C
	// (set) Token: 0x06004A76 RID: 19062 RVA: 0x0012AABA File Offset: 0x00128CBA
	public unsafe static int frameSkipStart
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(ClusterLODGroup.NativeFieldInfoPtr_frameSkipStart, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClusterLODGroup.NativeFieldInfoPtr_frameSkipStart, (void*)(&value));
		}
	}

	// Token: 0x17001A9F RID: 6815
	// (get) Token: 0x06004A77 RID: 19063 RVA: 0x0012AACC File Offset: 0x00128CCC
	// (set) Token: 0x06004A78 RID: 19064 RVA: 0x0012AAF4 File Offset: 0x00128CF4
	public unsafe int frameSkipCounter
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_frameSkipCounter);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_frameSkipCounter)) = value;
		}
	}

	// Token: 0x17001AA0 RID: 6816
	// (get) Token: 0x06004A79 RID: 19065 RVA: 0x0012AB18 File Offset: 0x00128D18
	// (set) Token: 0x06004A7A RID: 19066 RVA: 0x0012AB4C File Offset: 0x00128D4C
	public unsafe LODGroup CurrentGroup
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_CurrentGroup);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr_CurrentGroup), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AA1 RID: 6817
	// (get) Token: 0x06004A7B RID: 19067 RVA: 0x0012AB74 File Offset: 0x00128D74
	// (set) Token: 0x06004A7C RID: 19068 RVA: 0x0012ABA8 File Offset: 0x00128DA8
	public unsafe WarPlayerScript _warPlayerScript
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr__warPlayerScript);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr__warPlayerScript), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001AA2 RID: 6818
	// (get) Token: 0x06004A7D RID: 19069 RVA: 0x0012ABD0 File Offset: 0x00128DD0
	// (set) Token: 0x06004A7E RID: 19070 RVA: 0x0012ABF8 File Offset: 0x00128DF8
	public unsafe bool _ManagedUpdateRemoval_k__BackingField
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
		}
	}

	// Token: 0x04002F6F RID: 12143
	private static readonly IntPtr NativeFieldInfoPtr_ClusterType;

	// Token: 0x04002F70 RID: 12144
	private static readonly IntPtr NativeFieldInfoPtr_QuestDefaultGroup;

	// Token: 0x04002F71 RID: 12145
	private static readonly IntPtr NativeFieldInfoPtr_PCGroup;

	// Token: 0x04002F72 RID: 12146
	private static readonly IntPtr NativeFieldInfoPtr_Thresholds;

	// Token: 0x04002F73 RID: 12147
	private static readonly IntPtr NativeFieldInfoPtr_AllLods;

	// Token: 0x04002F74 RID: 12148
	private static readonly IntPtr NativeFieldInfoPtr_FRAME_SKIP;

	// Token: 0x04002F75 RID: 12149
	private static readonly IntPtr NativeFieldInfoPtr_frameSkipStart;

	// Token: 0x04002F76 RID: 12150
	private static readonly IntPtr NativeFieldInfoPtr_frameSkipCounter;

	// Token: 0x04002F77 RID: 12151
	private static readonly IntPtr NativeFieldInfoPtr_CurrentGroup;

	// Token: 0x04002F78 RID: 12152
	private static readonly IntPtr NativeFieldInfoPtr__warPlayerScript;

	// Token: 0x04002F79 RID: 12153
	private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

	// Token: 0x04002F7A RID: 12154
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Void_0;

	// Token: 0x04002F7B RID: 12155
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Protected_Void_0;

	// Token: 0x04002F7C RID: 12156
	private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

	// Token: 0x04002F7D RID: 12157
	private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

	// Token: 0x04002F7E RID: 12158
	private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

	// Token: 0x04002F7F RID: 12159
	private static readonly IntPtr NativeMethodInfoPtr_GetCurrentThreshold_Protected_ClusterLODThreshold_0;

	// Token: 0x04002F80 RID: 12160
	private static readonly IntPtr NativeMethodInfoPtr_UpdateLODGroups_Protected_Void_0;

	// Token: 0x04002F81 RID: 12161
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003A5 RID: 933
	public enum ClusterLODType
	{
		// Token: 0x04002F83 RID: 12163
		AI,
		// Token: 0x04002F84 RID: 12164
		Player,
		// Token: 0x04002F85 RID: 12165
		InventoryWeapon,
		// Token: 0x04002F86 RID: 12166
		InventoryNonWeapon
	}

	// Token: 0x020003A6 RID: 934
	[Serializable]
	public class ClusterLODThreshold : Il2CppSystem.Object
	{
		// Token: 0x06004A81 RID: 19073 RVA: 0x0012AC40 File Offset: 0x00128E40
		[CallerCount(0)]
		public unsafe ClusterLODThreshold() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.ClusterLODThreshold.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004A82 RID: 19074 RVA: 0x0012AC8C File Offset: 0x00128E8C
		// Note: this type is marked as 'beforefieldinit'.
		static ClusterLODThreshold()
		{
			Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "ClusterLODThreshold");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr);
			ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_FFRLevelThreshold = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr, "FFRLevelThreshold");
			ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_Group = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr, "Group");
			ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_UnusedLODS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr, "UnusedLODS");
			ClusterLODGroup.ClusterLODThreshold.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr, 100669157);
		}

		// Token: 0x06004A83 RID: 19075 RVA: 0x00002988 File Offset: 0x00000B88
		public ClusterLODThreshold(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001AA5 RID: 6821
		// (get) Token: 0x06004A84 RID: 19076 RVA: 0x0012AD07 File Offset: 0x00128F07
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClusterLODGroup.ClusterLODThreshold>.NativeClassPtr));
			}
		}

		// Token: 0x17001AA6 RID: 6822
		// (get) Token: 0x06004A85 RID: 19077 RVA: 0x0012AD18 File Offset: 0x00128F18
		// (set) Token: 0x06004A86 RID: 19078 RVA: 0x0012AD40 File Offset: 0x00128F40
		public unsafe int FFRLevelThreshold
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_FFRLevelThreshold);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_FFRLevelThreshold)) = value;
			}
		}

		// Token: 0x17001AA7 RID: 6823
		// (get) Token: 0x06004A87 RID: 19079 RVA: 0x0012AD64 File Offset: 0x00128F64
		// (set) Token: 0x06004A88 RID: 19080 RVA: 0x0012AD98 File Offset: 0x00128F98
		public unsafe LODGroup Group
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_Group);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LODGroup(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_Group), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001AA8 RID: 6824
		// (get) Token: 0x06004A89 RID: 19081 RVA: 0x0012ADC0 File Offset: 0x00128FC0
		// (set) Token: 0x06004A8A RID: 19082 RVA: 0x0012ADF4 File Offset: 0x00128FF4
		public unsafe List<GameObject> UnusedLODS
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_UnusedLODS);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<GameObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClusterLODGroup.ClusterLODThreshold.NativeFieldInfoPtr_UnusedLODS), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04002F87 RID: 12167
		private static readonly IntPtr NativeFieldInfoPtr_FFRLevelThreshold;

		// Token: 0x04002F88 RID: 12168
		private static readonly IntPtr NativeFieldInfoPtr_Group;

		// Token: 0x04002F89 RID: 12169
		private static readonly IntPtr NativeFieldInfoPtr_UnusedLODS;

		// Token: 0x04002F8A RID: 12170
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x020003A7 RID: 935
	[ObfuscatedName("ClusterLODGroup/<>c")]
	[Serializable]
	public sealed class __c : Il2CppSystem.Object
	{
		// Token: 0x06004A8B RID: 19083 RVA: 0x0012AE1C File Offset: 0x0012901C
		[CallerCount(0)]
		public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004A8C RID: 19084 RVA: 0x0012AE68 File Offset: 0x00129068
		[CallerCount(0)]
		public unsafe int _OnEnable_b__12_0(ClusterLODGroup.ClusterLODThreshold x, ClusterLODGroup.ClusterLODThreshold y)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(y);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClusterLODGroup.__c.NativeMethodInfoPtr__OnEnable_b__12_0_Internal_Int32_ClusterLODThreshold_ClusterLODThreshold_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06004A8D RID: 19085 RVA: 0x0012AEE8 File Offset: 0x001290E8
		// Note: this type is marked as 'beforefieldinit'.
		static __c()
		{
			Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClusterLODGroup>.NativeClassPtr, "<>c");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr);
			ClusterLODGroup.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr, "<>9");
			ClusterLODGroup.__c.NativeFieldInfoPtr___9__12_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr, "<>9__12_0");
			ClusterLODGroup.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr, 100669159);
			ClusterLODGroup.__c.NativeMethodInfoPtr__OnEnable_b__12_0_Internal_Int32_ClusterLODThreshold_ClusterLODThreshold_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr, 100669160);
		}

		// Token: 0x06004A8E RID: 19086 RVA: 0x00002988 File Offset: 0x00000B88
		public __c(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001AA9 RID: 6825
		// (get) Token: 0x06004A8F RID: 19087 RVA: 0x0012AF63 File Offset: 0x00129163
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClusterLODGroup.__c>.NativeClassPtr));
			}
		}

		// Token: 0x17001AAA RID: 6826
		// (get) Token: 0x06004A90 RID: 19088 RVA: 0x0012AF74 File Offset: 0x00129174
		// (set) Token: 0x06004A91 RID: 19089 RVA: 0x0012AF9F File Offset: 0x0012919F
		public unsafe static ClusterLODGroup.__c __9
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ClusterLODGroup.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ClusterLODGroup.__c(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ClusterLODGroup.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001AAB RID: 6827
		// (get) Token: 0x06004A92 RID: 19090 RVA: 0x0012AFB4 File Offset: 0x001291B4
		// (set) Token: 0x06004A93 RID: 19091 RVA: 0x0012AFDF File Offset: 0x001291DF
		public unsafe static Comparison<ClusterLODGroup.ClusterLODThreshold> __9__12_0
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ClusterLODGroup.__c.NativeFieldInfoPtr___9__12_0, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Comparison<ClusterLODGroup.ClusterLODThreshold>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ClusterLODGroup.__c.NativeFieldInfoPtr___9__12_0, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04002F8B RID: 12171
		private static readonly IntPtr NativeFieldInfoPtr___9;

		// Token: 0x04002F8C RID: 12172
		private static readonly IntPtr NativeFieldInfoPtr___9__12_0;

		// Token: 0x04002F8D RID: 12173
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04002F8E RID: 12174
		private static readonly IntPtr NativeMethodInfoPtr__OnEnable_b__12_0_Internal_Int32_ClusterLODThreshold_ClusterLODThreshold_0;
	}
}
