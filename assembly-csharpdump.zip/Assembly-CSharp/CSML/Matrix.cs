﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CSML
{
	// Token: 0x0200061C RID: 1564
	public class Matrix : Object
	{
		// Token: 0x17002D6B RID: 11627
		// (get) Token: 0x06007E81 RID: 32385 RVA: 0x001FD438 File Offset: 0x001FB638
		public unsafe int RowCount
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_get_RowCount_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17002D6C RID: 11628
		// (get) Token: 0x06007E82 RID: 32386 RVA: 0x001FD488 File Offset: 0x001FB688
		public unsafe int ColumnCount
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_get_ColumnCount_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06007E83 RID: 32387 RVA: 0x001FD4D8 File Offset: 0x001FB6D8
		[CallerCount(0)]
		public unsafe Matrix() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E84 RID: 32388 RVA: 0x001FD524 File Offset: 0x001FB724
		[CallerCount(0)]
		public unsafe Matrix(int m, int n) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E85 RID: 32389 RVA: 0x001FD594 File Offset: 0x001FB794
		[CallerCount(0)]
		public unsafe Matrix(int n) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E86 RID: 32390 RVA: 0x001FD5F4 File Offset: 0x001FB7F4
		[CallerCount(0)]
		public unsafe Matrix(Complex x) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E87 RID: 32391 RVA: 0x001FD658 File Offset: 0x001FB858
		[CallerCount(0)]
		public unsafe Matrix(Il2CppObjectBase values) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(values);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E88 RID: 32392 RVA: 0x001FD6BC File Offset: 0x001FB8BC
		[CallerCount(0)]
		public unsafe Matrix(Il2CppReferenceArray<Complex> values) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(values);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E89 RID: 32393 RVA: 0x001FD720 File Offset: 0x001FB920
		[CallerCount(0)]
		public unsafe Matrix(double x) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E8A RID: 32394 RVA: 0x001FD780 File Offset: 0x001FB980
		[CallerCount(0)]
		public unsafe Matrix(Il2CppObjectBase values) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(values);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E8B RID: 32395 RVA: 0x001FD7E4 File Offset: 0x001FB9E4
		[CallerCount(0)]
		public unsafe Matrix(Il2CppStructArray<double> values) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(values);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E8C RID: 32396 RVA: 0x001FD848 File Offset: 0x001FBA48
		[CallerCount(0)]
		public unsafe Matrix(string matrix_string) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Matrix>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(matrix_string);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr__ctor_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E8D RID: 32397 RVA: 0x001FD8AC File Offset: 0x001FBAAC
		[CallerCount(0)]
		public unsafe static Matrix E(int n, int j)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_E_Public_Static_Matrix_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E8E RID: 32398 RVA: 0x001FD918 File Offset: 0x001FBB18
		[CallerCount(0)]
		public unsafe static Complex KroneckerDelta(int i, int j)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_KroneckerDelta_Public_Static_Complex_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E8F RID: 32399 RVA: 0x001FD984 File Offset: 0x001FBB84
		[CallerCount(0)]
		public unsafe static Matrix ChessboardMatrix(int m, int n, bool even)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref even;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Int32_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E90 RID: 32400 RVA: 0x001FDA04 File Offset: 0x001FBC04
		[CallerCount(0)]
		public unsafe static Matrix ChessboardMatrix(int n, bool even)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref even;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E91 RID: 32401 RVA: 0x001FDA70 File Offset: 0x001FBC70
		[CallerCount(0)]
		public unsafe static Matrix Zeros(int m, int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E92 RID: 32402 RVA: 0x001FDADC File Offset: 0x001FBCDC
		[CallerCount(0)]
		public unsafe static Matrix Zeros(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E93 RID: 32403 RVA: 0x001FDB38 File Offset: 0x001FBD38
		[CallerCount(0)]
		public unsafe static Matrix Ones(int m, int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E94 RID: 32404 RVA: 0x001FDBA4 File Offset: 0x001FBDA4
		[CallerCount(0)]
		public unsafe static Matrix Ones(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E95 RID: 32405 RVA: 0x001FDC00 File Offset: 0x001FBE00
		[CallerCount(0)]
		public unsafe static Matrix Identity(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Identity_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E96 RID: 32406 RVA: 0x001FDC5C File Offset: 0x001FBE5C
		[CallerCount(0)]
		public unsafe static Matrix Eye(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Eye_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E97 RID: 32407 RVA: 0x001FDCB8 File Offset: 0x001FBEB8
		[CallerCount(0)]
		public unsafe static Matrix VerticalConcat(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E98 RID: 32408 RVA: 0x001FDD30 File Offset: 0x001FBF30
		[CallerCount(0)]
		public unsafe static Matrix VerticalConcat(Il2CppReferenceArray<Matrix> A)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_ArrayOf_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E99 RID: 32409 RVA: 0x001FDD90 File Offset: 0x001FBF90
		[CallerCount(0)]
		public unsafe static Matrix HorizontalConcat(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9A RID: 32410 RVA: 0x001FDE08 File Offset: 0x001FC008
		[CallerCount(0)]
		public unsafe static Matrix HorizontalConcat(Il2CppReferenceArray<Matrix> A)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_ArrayOf_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9B RID: 32411 RVA: 0x001FDE68 File Offset: 0x001FC068
		[CallerCount(0)]
		public unsafe static Matrix Diag(Matrix diag_vector)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(diag_vector);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9C RID: 32412 RVA: 0x001FDEC8 File Offset: 0x001FC0C8
		[CallerCount(0)]
		public unsafe static Matrix Diag(Matrix diag_vector, int offset)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(diag_vector);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offset;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9D RID: 32413 RVA: 0x001FDF3C File Offset: 0x001FC13C
		[CallerCount(0)]
		public unsafe static Matrix TriDiag(Complex l, Complex d, Complex u, int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(l);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(d);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(u);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Complex_Complex_Complex_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9E RID: 32414 RVA: 0x001FDFE0 File Offset: 0x001FC1E0
		[CallerCount(0)]
		public unsafe static Matrix TriDiag(Matrix l, Matrix d, Matrix u)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(l);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(d);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(u);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007E9F RID: 32415 RVA: 0x001FE070 File Offset: 0x001FC270
		[CallerCount(0)]
		public unsafe static Complex Dot(Matrix v, Matrix w)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(v);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(w);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Dot_Public_Static_Complex_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EA0 RID: 32416 RVA: 0x001FE0E8 File Offset: 0x001FC2E8
		[CallerCount(0)]
		public unsafe static Complex Fib(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Fib_Public_Static_Complex_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EA1 RID: 32417 RVA: 0x001FE144 File Offset: 0x001FC344
		[CallerCount(0)]
		public unsafe static Matrix RandomGraph(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA2 RID: 32418 RVA: 0x001FE1A0 File Offset: 0x001FC3A0
		[CallerCount(0)]
		public unsafe static Matrix RandomGraph(int n, double p)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref p;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA3 RID: 32419 RVA: 0x001FE20C File Offset: 0x001FC40C
		[CallerCount(0)]
		public unsafe static Matrix Random(int m, int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA4 RID: 32420 RVA: 0x001FE278 File Offset: 0x001FC478
		[CallerCount(0)]
		public unsafe static Matrix Random(int n)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA5 RID: 32421 RVA: 0x001FE2D4 File Offset: 0x001FC4D4
		[CallerCount(0)]
		public unsafe static Matrix Random(int n, int lo, int hi)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref lo;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hi;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA6 RID: 32422 RVA: 0x001FE354 File Offset: 0x001FC554
		[CallerCount(0)]
		public unsafe static Matrix RandomZeroOne(int m, int n, double p)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref p;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Int32_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA7 RID: 32423 RVA: 0x001FE3D4 File Offset: 0x001FC5D4
		[CallerCount(0)]
		public unsafe static Matrix RandomZeroOne(int n, double p)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref p;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA8 RID: 32424 RVA: 0x001FE440 File Offset: 0x001FC640
		[CallerCount(0)]
		public unsafe static Matrix Random(int m, int n, int lo, int hi)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref lo;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hi;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EA9 RID: 32425 RVA: 0x001FE4D4 File Offset: 0x001FC6D4
		[CallerCount(0)]
		public unsafe static Matrix Vandermonde(Il2CppReferenceArray<Complex> x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Vandermonde_Public_Static_Matrix_ArrayOf_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EAA RID: 32426 RVA: 0x001FE534 File Offset: 0x001FC734
		[CallerCount(0)]
		public unsafe static Il2CppReferenceArray<Matrix> Floyd(Matrix adjacence_matrix)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(adjacence_matrix);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Floyd_Public_Static_ArrayOf_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EAB RID: 32427 RVA: 0x001FE594 File Offset: 0x001FC794
		[CallerCount(0)]
		public unsafe static ArrayList FloydPath(Matrix P, int i, int j)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(P);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_FloydPath_Public_Static_ArrayList_Matrix_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new ArrayList(intPtr2) : null;
		}

		// Token: 0x06007EAC RID: 32428 RVA: 0x001FE618 File Offset: 0x001FC818
		[CallerCount(0)]
		public unsafe static Matrix DFS(Matrix adjacence_matrix, int root)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(adjacence_matrix);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref root;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_DFS_Public_Static_Matrix_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EAD RID: 32429 RVA: 0x001FE68C File Offset: 0x001FC88C
		[CallerCount(0)]
		public unsafe static Matrix BFS(Matrix adjacence_matrix, int root)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(adjacence_matrix);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref root;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_BFS_Public_Static_Matrix_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EAE RID: 32430 RVA: 0x001FE700 File Offset: 0x001FC900
		[CallerCount(0)]
		public unsafe static Matrix ZeroOneRandom(int m, int n, double p)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref m;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref p;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Int32_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EAF RID: 32431 RVA: 0x001FE780 File Offset: 0x001FC980
		[CallerCount(0)]
		public unsafe static Matrix ZeroOneRandom(int n, double p)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref n;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref p;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB0 RID: 32432 RVA: 0x001FE7EC File Offset: 0x001FC9EC
		[CallerCount(0)]
		public unsafe static Il2CppReferenceArray<Matrix> HouseholderVector(Matrix x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HouseholderVector_Private_Static_ArrayOf_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EB1 RID: 32433 RVA: 0x001FE84C File Offset: 0x001FCA4C
		[CallerCount(0)]
		public unsafe static Matrix BlockMatrix(Matrix A, Matrix B, Matrix C, Matrix D)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(C);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(D);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_BlockMatrix_Public_Static_Matrix_Matrix_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB2 RID: 32434 RVA: 0x001FE8F4 File Offset: 0x001FCAF4
		[CallerCount(0)]
		public unsafe static Matrix Solve(Matrix A, Matrix b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Solve_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB3 RID: 32435 RVA: 0x001FE96C File Offset: 0x001FCB6C
		[CallerCount(0)]
		public unsafe Matrix Re()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Re_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB4 RID: 32436 RVA: 0x001FE9C4 File Offset: 0x001FCBC4
		[CallerCount(0)]
		public unsafe Matrix Im()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Im_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB5 RID: 32437 RVA: 0x001FEA1C File Offset: 0x001FCC1C
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Matrix> HessenbergHouseholder()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HessenbergHouseholder_Public_ArrayOf_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EB6 RID: 32438 RVA: 0x001FEA74 File Offset: 0x001FCC74
		[CallerCount(0)]
		public unsafe Matrix Extract(int i1, int i2, int j1, int j2)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i2;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j1;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j2;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Extract_Public_Matrix_Int32_Int32_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB7 RID: 32439 RVA: 0x001FEB18 File Offset: 0x001FCD18
		[CallerCount(0)]
		public unsafe Matrix ExtractLowerTrapeze()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ExtractLowerTrapeze_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB8 RID: 32440 RVA: 0x001FEB70 File Offset: 0x001FCD70
		[CallerCount(0)]
		public unsafe Matrix ExtractUpperTrapeze()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ExtractUpperTrapeze_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EB9 RID: 32441 RVA: 0x001FEBC8 File Offset: 0x001FCDC8
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Matrix> ColumnVectorize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ColumnVectorize_Public_ArrayOf_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EBA RID: 32442 RVA: 0x001FEC20 File Offset: 0x001FCE20
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Matrix> RowVectorize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RowVectorize_Public_ArrayOf_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EBB RID: 32443 RVA: 0x001FEC78 File Offset: 0x001FCE78
		[CallerCount(0)]
		public unsafe void VerticalFlip()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_VerticalFlip_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EBC RID: 32444 RVA: 0x001FECBC File Offset: 0x001FCEBC
		[CallerCount(0)]
		public unsafe void HorizontalFlip()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HorizontalFlip_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EBD RID: 32445 RVA: 0x001FED00 File Offset: 0x001FCF00
		[CallerCount(0)]
		public unsafe void SwapColumns(int j1, int j2)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j2;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_SwapColumns_Public_Void_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EBE RID: 32446 RVA: 0x001FED68 File Offset: 0x001FCF68
		[CallerCount(0)]
		public unsafe void SwapRows(int i1, int i2)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i2;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_SwapRows_Public_Void_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EBF RID: 32447 RVA: 0x001FEDD0 File Offset: 0x001FCFD0
		[CallerCount(0)]
		public unsafe void DeleteRow(int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_DeleteRow_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EC0 RID: 32448 RVA: 0x001FEE24 File Offset: 0x001FD024
		[CallerCount(0)]
		public unsafe void DeleteColumn(int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_DeleteColumn_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EC1 RID: 32449 RVA: 0x001FEE78 File Offset: 0x001FD078
		[CallerCount(0)]
		public unsafe Matrix ExtractRow(int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ExtractRow_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EC2 RID: 32450 RVA: 0x001FEEE0 File Offset: 0x001FD0E0
		[CallerCount(0)]
		public unsafe Matrix ExtractColumn(int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ExtractColumn_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EC3 RID: 32451 RVA: 0x001FEF48 File Offset: 0x001FD148
		[CallerCount(0)]
		public unsafe void InsertRow(Matrix row, int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(row);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_InsertRow_Public_Void_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EC4 RID: 32452 RVA: 0x001FEFB4 File Offset: 0x001FD1B4
		[CallerCount(0)]
		public unsafe void Insert(int i, int j, Matrix M)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(M);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Insert_Public_Void_Int32_Int32_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EC5 RID: 32453 RVA: 0x001FF034 File Offset: 0x001FD234
		[CallerCount(0)]
		public unsafe void InsertColumn(Matrix col, int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_InsertColumn_Public_Void_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EC6 RID: 32454 RVA: 0x001FF0A0 File Offset: 0x001FD2A0
		[CallerCount(0)]
		public unsafe Matrix Inverse()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Inverse_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EC7 RID: 32455 RVA: 0x001FF0F8 File Offset: 0x001FD2F8
		[CallerCount(0)]
		public unsafe Matrix InverseLeverrier()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_InverseLeverrier_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EC8 RID: 32456 RVA: 0x001FF150 File Offset: 0x001FD350
		[CallerCount(0)]
		public unsafe Matrix Minor(int i, int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Minor_Public_Matrix_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EC9 RID: 32457 RVA: 0x001FF1CC File Offset: 0x001FD3CC
		[CallerCount(0)]
		public unsafe Matrix Clone()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Clone_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECA RID: 32458 RVA: 0x001FF224 File Offset: 0x001FD424
		[CallerCount(0)]
		public unsafe Matrix DiagVector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_DiagVector_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECB RID: 32459 RVA: 0x001FF27C File Offset: 0x001FD47C
		[CallerCount(0)]
		public unsafe Matrix Column(int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Column_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECC RID: 32460 RVA: 0x001FF2E4 File Offset: 0x001FD4E4
		[CallerCount(0)]
		public unsafe Matrix Row(int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Row_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECD RID: 32461 RVA: 0x001FF34C File Offset: 0x001FD54C
		[CallerCount(0)]
		public unsafe Matrix Transpose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Transpose_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECE RID: 32462 RVA: 0x001FF3A4 File Offset: 0x001FD5A4
		[CallerCount(0)]
		public unsafe Matrix Conjugate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Conjugate_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ECF RID: 32463 RVA: 0x001FF3FC File Offset: 0x001FD5FC
		[CallerCount(0)]
		public unsafe Matrix ConjTranspose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ConjTranspose_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ED0 RID: 32464 RVA: 0x001FF454 File Offset: 0x001FD654
		[CallerCount(0)]
		public unsafe void LU()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_LU_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED1 RID: 32465 RVA: 0x001FF498 File Offset: 0x001FD698
		[CallerCount(0)]
		public unsafe Matrix LUSafe()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_LUSafe_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007ED2 RID: 32466 RVA: 0x001FF4F0 File Offset: 0x001FD6F0
		[CallerCount(0)]
		public unsafe void Cholesky()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Cholesky_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED3 RID: 32467 RVA: 0x001FF534 File Offset: 0x001FD734
		[CallerCount(0)]
		public unsafe void CholeskyUndo()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_CholeskyUndo_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED4 RID: 32468 RVA: 0x001FF578 File Offset: 0x001FD778
		[CallerCount(0)]
		public unsafe void ForwardInsertion(Matrix b)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ForwardInsertion_Public_Void_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED5 RID: 32469 RVA: 0x001FF5D4 File Offset: 0x001FD7D4
		[CallerCount(0)]
		public unsafe void BackwardInsertion(Matrix b)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_BackwardInsertion_Public_Void_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED6 RID: 32470 RVA: 0x001FF630 File Offset: 0x001FD830
		[CallerCount(0)]
		public unsafe void SymmetrizeDown()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_SymmetrizeDown_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED7 RID: 32471 RVA: 0x001FF674 File Offset: 0x001FD874
		[CallerCount(0)]
		public unsafe void SymmetrizeUp()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_SymmetrizeUp_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007ED8 RID: 32472 RVA: 0x001FF6B8 File Offset: 0x001FD8B8
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Matrix> QRGramSchmidt()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_QRGramSchmidt_Public_ArrayOf_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007ED9 RID: 32473 RVA: 0x001FF710 File Offset: 0x001FD910
		[CallerCount(0)]
		public unsafe Matrix Eigenvalues()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Eigenvalues_Public_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EDA RID: 32474 RVA: 0x001FF768 File Offset: 0x001FD968
		[CallerCount(0)]
		public unsafe Matrix Eigenvector(Complex eigenvalue)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(eigenvalue);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Eigenvector_Public_Matrix_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EDB RID: 32475 RVA: 0x001FF7D8 File Offset: 0x001FD9D8
		[CallerCount(0)]
		public unsafe Matrix SolveCG(Matrix b)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_SolveCG_Public_Matrix_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EDC RID: 32476 RVA: 0x001FF848 File Offset: 0x001FDA48
		[CallerCount(0)]
		public unsafe Matrix QRIterationBasic(int max_iterations)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref max_iterations;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_QRIterationBasic_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EDD RID: 32477 RVA: 0x001FF8B0 File Offset: 0x001FDAB0
		[CallerCount(0)]
		public unsafe Matrix QRIterationHessenberg(int max_iterations)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref max_iterations;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_QRIterationHessenberg_Public_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EDE RID: 32478 RVA: 0x001FF918 File Offset: 0x001FDB18
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Matrix> QRGivens()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_QRGivens_Public_ArrayOf_Matrix_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Matrix>(intPtr2) : null;
		}

		// Token: 0x06007EDF RID: 32479 RVA: 0x001FF970 File Offset: 0x001FDB70
		[CallerCount(0)]
		public unsafe Matrix GivProd(Matrix c, Matrix s, int n)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(c);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(s);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref n;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_GivProd_Private_Matrix_Matrix_Matrix_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007EE0 RID: 32480 RVA: 0x001FFA08 File Offset: 0x001FDC08
		[CallerCount(0)]
		public unsafe void Garow(Complex c, Complex s, int i, int k, int j1, int j2)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(c);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(s);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref k;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j1;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j2;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Garow_Private_Void_Complex_Complex_Int32_Int32_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EE1 RID: 32481 RVA: 0x001FFAC8 File Offset: 0x001FDCC8
		[CallerCount(0)]
		public unsafe void Gacol(Complex c, Complex s, int j1, int j2, int i, int k)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(c);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(s);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j1;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j2;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref i;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref k;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Gacol_Public_Void_Complex_Complex_Int32_Int32_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007EE2 RID: 32482 RVA: 0x001FFB88 File Offset: 0x001FDD88
		[CallerCount(0)]
		public unsafe Il2CppReferenceArray<Complex> GivensCS(Complex xi, Complex xk)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(xi);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(xk);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_GivensCS_Private_ArrayOf_Complex_Complex_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Complex>(intPtr2) : null;
		}

		// Token: 0x06007EE3 RID: 32483 RVA: 0x001FFC10 File Offset: 0x001FDE10
		[CallerCount(0)]
		public unsafe Complex Determinant()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Determinant_Public_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EE4 RID: 32484 RVA: 0x001FFC68 File Offset: 0x001FDE68
		[CallerCount(0)]
		public unsafe double ColumnSumNorm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ColumnSumNorm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EE5 RID: 32485 RVA: 0x001FFCB8 File Offset: 0x001FDEB8
		[CallerCount(0)]
		public unsafe double RowSumNorm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RowSumNorm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EE6 RID: 32486 RVA: 0x001FFD08 File Offset: 0x001FDF08
		[CallerCount(0)]
		public unsafe Complex Permanent()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Permanent_Public_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EE7 RID: 32487 RVA: 0x001FFD60 File Offset: 0x001FDF60
		[CallerCount(0)]
		public unsafe int GetMinRow()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_GetMinRow_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EE8 RID: 32488 RVA: 0x001FFDB0 File Offset: 0x001FDFB0
		[CallerCount(0)]
		public unsafe int GetMinColumn()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_GetMinColumn_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EE9 RID: 32489 RVA: 0x001FFE00 File Offset: 0x001FE000
		[CallerCount(0)]
		public unsafe double Factorial(int x)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Factorial_Private_Double_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EEA RID: 32490 RVA: 0x001FFE64 File Offset: 0x001FE064
		[CallerCount(0)]
		public unsafe double Signum()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Signum_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EEB RID: 32491 RVA: 0x001FFEB4 File Offset: 0x001FE0B4
		[CallerCount(0)]
		public unsafe double Condition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Condition_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EEC RID: 32492 RVA: 0x001FFF04 File Offset: 0x001FE104
		[CallerCount(0)]
		public unsafe double Condition(int p)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref p;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Condition_Public_Double_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EED RID: 32493 RVA: 0x001FFF68 File Offset: 0x001FE168
		[CallerCount(0)]
		public unsafe double ConditionFro()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ConditionFro_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EEE RID: 32494 RVA: 0x001FFFB8 File Offset: 0x001FE1B8
		[CallerCount(0)]
		public unsafe double PNorm(double p)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref p;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_PNorm_Public_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EEF RID: 32495 RVA: 0x0020001C File Offset: 0x001FE21C
		[CallerCount(0)]
		public unsafe double Norm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Norm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF0 RID: 32496 RVA: 0x0020006C File Offset: 0x001FE26C
		[CallerCount(0)]
		public unsafe double FrobeniusNorm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_FrobeniusNorm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF1 RID: 32497 RVA: 0x002000BC File Offset: 0x001FE2BC
		[CallerCount(0)]
		public unsafe double TaxiNorm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_TaxiNorm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF2 RID: 32498 RVA: 0x0020010C File Offset: 0x001FE30C
		[CallerCount(0)]
		public unsafe double MaxNorm()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_MaxNorm_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF3 RID: 32499 RVA: 0x0020015C File Offset: 0x001FE35C
		[CallerCount(0)]
		public unsafe Complex ColumnSum(int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ColumnSum_Public_Complex_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EF4 RID: 32500 RVA: 0x002001C4 File Offset: 0x001FE3C4
		[CallerCount(0)]
		public unsafe double AbsColumnSum(int j)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref j;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_AbsColumnSum_Public_Double_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF5 RID: 32501 RVA: 0x00200228 File Offset: 0x001FE428
		[CallerCount(0)]
		public unsafe Complex RowSum(int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_RowSum_Public_Complex_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EF6 RID: 32502 RVA: 0x00200290 File Offset: 0x001FE490
		[CallerCount(0)]
		public unsafe double AbsRowSum(int i)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref i;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_AbsRowSum_Public_Double_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EF7 RID: 32503 RVA: 0x002002F4 File Offset: 0x001FE4F4
		[CallerCount(0)]
		public unsafe Complex DiagProd()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_DiagProd_Public_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EF8 RID: 32504 RVA: 0x0020034C File Offset: 0x001FE54C
		[CallerCount(0)]
		public unsafe Complex Trace()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Trace_Public_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EF9 RID: 32505 RVA: 0x002003A4 File Offset: 0x001FE5A4
		[CallerCount(0)]
		public unsafe Complex Sqr(Complex x)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Sqr_Private_Complex_Complex_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007EFA RID: 32506 RVA: 0x00200414 File Offset: 0x001FE614
		[CallerCount(0)]
		public unsafe bool IsNormal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsNormal_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EFB RID: 32507 RVA: 0x00200464 File Offset: 0x001FE664
		[CallerCount(0)]
		public unsafe bool IsUnitary()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsUnitary_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EFC RID: 32508 RVA: 0x002004B4 File Offset: 0x001FE6B4
		[CallerCount(0)]
		public unsafe bool IsHermitian()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsHermitian_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EFD RID: 32509 RVA: 0x00200504 File Offset: 0x001FE704
		[CallerCount(0)]
		public unsafe bool IsReal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsReal_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EFE RID: 32510 RVA: 0x00200554 File Offset: 0x001FE754
		[CallerCount(0)]
		public unsafe bool IsSymmetricPositiveDefinite()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsSymmetricPositiveDefinite_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007EFF RID: 32511 RVA: 0x002005A4 File Offset: 0x001FE7A4
		[CallerCount(0)]
		public unsafe bool IsSPD()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsSPD_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F00 RID: 32512 RVA: 0x002005F4 File Offset: 0x001FE7F4
		[CallerCount(0)]
		public unsafe Matrix.DefinitenessType Definiteness()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_Definiteness_Public_DefinitenessType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F01 RID: 32513 RVA: 0x00200644 File Offset: 0x001FE844
		[CallerCount(0)]
		public unsafe bool HasZeroRowOrColumn()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_HasZeroRowOrColumn_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F02 RID: 32514 RVA: 0x00200694 File Offset: 0x001FE894
		[CallerCount(0)]
		public unsafe bool IsZeroOneMatrix()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsZeroOneMatrix_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F03 RID: 32515 RVA: 0x002006E4 File Offset: 0x001FE8E4
		[CallerCount(0)]
		public unsafe bool IsPermutation()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsPermutation_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F04 RID: 32516 RVA: 0x00200734 File Offset: 0x001FE934
		[CallerCount(0)]
		public unsafe bool IsDiagonal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsDiagonal_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F05 RID: 32517 RVA: 0x00200784 File Offset: 0x001FE984
		[CallerCount(0)]
		public unsafe int VectorLength()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_VectorLength_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F06 RID: 32518 RVA: 0x002007D4 File Offset: 0x001FE9D4
		[CallerCount(0)]
		public unsafe bool IsSquare()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsSquare_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F07 RID: 32519 RVA: 0x00200824 File Offset: 0x001FEA24
		[CallerCount(0)]
		public unsafe bool IsInvolutary()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsInvolutary_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F08 RID: 32520 RVA: 0x00200874 File Offset: 0x001FEA74
		[CallerCount(0)]
		public unsafe bool IsSymmetric()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsSymmetric_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F09 RID: 32521 RVA: 0x002008C4 File Offset: 0x001FEAC4
		[CallerCount(0)]
		public unsafe bool IsOrthogonal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsOrthogonal_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0A RID: 32522 RVA: 0x00200914 File Offset: 0x001FEB14
		[CallerCount(0)]
		public unsafe bool IsTrapeze()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsTrapeze_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0B RID: 32523 RVA: 0x00200964 File Offset: 0x001FEB64
		[CallerCount(0)]
		public unsafe bool IsTriangular()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsTriangular_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0C RID: 32524 RVA: 0x002009B4 File Offset: 0x001FEBB4
		[CallerCount(0)]
		public unsafe bool IsUpperTriangular()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsUpperTriangular_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0D RID: 32525 RVA: 0x00200A04 File Offset: 0x001FEC04
		[CallerCount(0)]
		public unsafe bool IsLowerTriangular()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsLowerTriangular_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0E RID: 32526 RVA: 0x00200A54 File Offset: 0x001FEC54
		[CallerCount(0)]
		public unsafe bool IsUpperTrapeze()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsUpperTrapeze_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F0F RID: 32527 RVA: 0x00200AA4 File Offset: 0x001FECA4
		[CallerCount(0)]
		public unsafe bool IsLowerTrapeze()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_IsLowerTrapeze_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F10 RID: 32528 RVA: 0x00200AF4 File Offset: 0x001FECF4
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_ToString_Public_Virtual_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06007F11 RID: 32529 RVA: 0x00200B4C File Offset: 0x001FED4C
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_ToString_Public_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06007F12 RID: 32530 RVA: 0x00200BB0 File Offset: 0x001FEDB0
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06007F13 RID: 32531 RVA: 0x00200C24 File Offset: 0x001FEE24
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F14 RID: 32532 RVA: 0x00200C80 File Offset: 0x001FEE80
		[CallerCount(0)]
		public unsafe static bool operator ==(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F15 RID: 32533 RVA: 0x00200CF0 File Offset: 0x001FEEF0
		[CallerCount(0)]
		public unsafe static bool operator !=(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007F16 RID: 32534 RVA: 0x00200D60 File Offset: 0x001FEF60
		[CallerCount(0)]
		public unsafe static Matrix operator +(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Addition_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F17 RID: 32535 RVA: 0x00200DD8 File Offset: 0x001FEFD8
		[CallerCount(0)]
		public unsafe static Matrix operator -(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Subtraction_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F18 RID: 32536 RVA: 0x00200E50 File Offset: 0x001FF050
		[CallerCount(0)]
		public unsafe static Matrix operator -(Matrix A)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F19 RID: 32537 RVA: 0x00200EB0 File Offset: 0x001FF0B0
		[CallerCount(0)]
		public unsafe static Matrix operator *(Matrix A, Matrix B)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(B);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1A RID: 32538 RVA: 0x00200F28 File Offset: 0x001FF128
		[CallerCount(0)]
		public unsafe static Matrix operator *(Matrix A, Complex x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1B RID: 32539 RVA: 0x00200FA0 File Offset: 0x001FF1A0
		[CallerCount(0)]
		public unsafe static Matrix operator *(Complex x, Matrix A)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(x);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(A);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Complex_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1C RID: 32540 RVA: 0x00201018 File Offset: 0x001FF218
		[CallerCount(0)]
		public unsafe static Matrix operator *(Matrix A, double x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref x;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1D RID: 32541 RVA: 0x0020108C File Offset: 0x001FF28C
		[CallerCount(0)]
		public unsafe static Matrix operator *(double x, Matrix A)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(A);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Double_Matrix_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1E RID: 32542 RVA: 0x00201100 File Offset: 0x001FF300
		[CallerCount(0)]
		public unsafe static Matrix operator /(Matrix A, Complex x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(x);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F1F RID: 32543 RVA: 0x00201178 File Offset: 0x001FF378
		[CallerCount(0)]
		public unsafe static Matrix operator /(Matrix A, double x)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref x;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x06007F20 RID: 32544 RVA: 0x002011EC File Offset: 0x001FF3EC
		[CallerCount(0)]
		public unsafe static Matrix operator ^(Matrix A, int k)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(A);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref k;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Matrix.NativeMethodInfoPtr_op_ExclusiveOr_Public_Static_Matrix_Matrix_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Matrix(intPtr2) : null;
		}

		// Token: 0x17002D6D RID: 11629
		public unsafe Complex this[int i, int j]
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref i;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Complex(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref i;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref j;
				ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Int32_Complex_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17002D6E RID: 11630
		public unsafe Complex this[int i]
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref i;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Complex(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref i;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Matrix.NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Complex_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06007F25 RID: 32549 RVA: 0x00201460 File Offset: 0x001FF660
		// Note: this type is marked as 'beforefieldinit'.
		static Matrix()
		{
			Il2CppClassPointerStore<Matrix>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "CSML", "Matrix");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Matrix>.NativeClassPtr);
			Matrix.NativeFieldInfoPtr_Values = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Matrix>.NativeClassPtr, "Values");
			Matrix.NativeFieldInfoPtr_rowCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Matrix>.NativeClassPtr, "rowCount");
			Matrix.NativeFieldInfoPtr_columnCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Matrix>.NativeClassPtr, "columnCount");
			Matrix.NativeMethodInfoPtr_get_RowCount_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673412);
			Matrix.NativeMethodInfoPtr_get_ColumnCount_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673413);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673414);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673415);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673416);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673417);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673418);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673419);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673420);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673421);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673422);
			Matrix.NativeMethodInfoPtr__ctor_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673423);
			Matrix.NativeMethodInfoPtr_E_Public_Static_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673424);
			Matrix.NativeMethodInfoPtr_KroneckerDelta_Public_Static_Complex_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673425);
			Matrix.NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Int32_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673426);
			Matrix.NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673427);
			Matrix.NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673428);
			Matrix.NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673429);
			Matrix.NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673430);
			Matrix.NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673431);
			Matrix.NativeMethodInfoPtr_Identity_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673432);
			Matrix.NativeMethodInfoPtr_Eye_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673433);
			Matrix.NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673434);
			Matrix.NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673435);
			Matrix.NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673436);
			Matrix.NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673437);
			Matrix.NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673438);
			Matrix.NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673439);
			Matrix.NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Complex_Complex_Complex_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673440);
			Matrix.NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673441);
			Matrix.NativeMethodInfoPtr_Dot_Public_Static_Complex_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673442);
			Matrix.NativeMethodInfoPtr_Fib_Public_Static_Complex_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673443);
			Matrix.NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673444);
			Matrix.NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673445);
			Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673446);
			Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673447);
			Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673448);
			Matrix.NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Int32_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673449);
			Matrix.NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673450);
			Matrix.NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673451);
			Matrix.NativeMethodInfoPtr_Vandermonde_Public_Static_Matrix_ArrayOf_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673452);
			Matrix.NativeMethodInfoPtr_Floyd_Public_Static_ArrayOf_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673453);
			Matrix.NativeMethodInfoPtr_FloydPath_Public_Static_ArrayList_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673454);
			Matrix.NativeMethodInfoPtr_DFS_Public_Static_Matrix_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673455);
			Matrix.NativeMethodInfoPtr_BFS_Public_Static_Matrix_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673456);
			Matrix.NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Int32_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673457);
			Matrix.NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673458);
			Matrix.NativeMethodInfoPtr_HouseholderVector_Private_Static_ArrayOf_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673459);
			Matrix.NativeMethodInfoPtr_BlockMatrix_Public_Static_Matrix_Matrix_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673460);
			Matrix.NativeMethodInfoPtr_Solve_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673461);
			Matrix.NativeMethodInfoPtr_Re_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673462);
			Matrix.NativeMethodInfoPtr_Im_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673463);
			Matrix.NativeMethodInfoPtr_HessenbergHouseholder_Public_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673464);
			Matrix.NativeMethodInfoPtr_Extract_Public_Matrix_Int32_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673465);
			Matrix.NativeMethodInfoPtr_ExtractLowerTrapeze_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673466);
			Matrix.NativeMethodInfoPtr_ExtractUpperTrapeze_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673467);
			Matrix.NativeMethodInfoPtr_ColumnVectorize_Public_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673468);
			Matrix.NativeMethodInfoPtr_RowVectorize_Public_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673469);
			Matrix.NativeMethodInfoPtr_VerticalFlip_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673470);
			Matrix.NativeMethodInfoPtr_HorizontalFlip_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673471);
			Matrix.NativeMethodInfoPtr_SwapColumns_Public_Void_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673472);
			Matrix.NativeMethodInfoPtr_SwapRows_Public_Void_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673473);
			Matrix.NativeMethodInfoPtr_DeleteRow_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673474);
			Matrix.NativeMethodInfoPtr_DeleteColumn_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673475);
			Matrix.NativeMethodInfoPtr_ExtractRow_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673476);
			Matrix.NativeMethodInfoPtr_ExtractColumn_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673477);
			Matrix.NativeMethodInfoPtr_InsertRow_Public_Void_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673478);
			Matrix.NativeMethodInfoPtr_Insert_Public_Void_Int32_Int32_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673479);
			Matrix.NativeMethodInfoPtr_InsertColumn_Public_Void_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673480);
			Matrix.NativeMethodInfoPtr_Inverse_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673481);
			Matrix.NativeMethodInfoPtr_InverseLeverrier_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673482);
			Matrix.NativeMethodInfoPtr_Minor_Public_Matrix_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673483);
			Matrix.NativeMethodInfoPtr_Clone_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673484);
			Matrix.NativeMethodInfoPtr_DiagVector_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673485);
			Matrix.NativeMethodInfoPtr_Column_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673486);
			Matrix.NativeMethodInfoPtr_Row_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673487);
			Matrix.NativeMethodInfoPtr_Transpose_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673488);
			Matrix.NativeMethodInfoPtr_Conjugate_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673489);
			Matrix.NativeMethodInfoPtr_ConjTranspose_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673490);
			Matrix.NativeMethodInfoPtr_LU_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673491);
			Matrix.NativeMethodInfoPtr_LUSafe_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673492);
			Matrix.NativeMethodInfoPtr_Cholesky_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673493);
			Matrix.NativeMethodInfoPtr_CholeskyUndo_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673494);
			Matrix.NativeMethodInfoPtr_ForwardInsertion_Public_Void_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673495);
			Matrix.NativeMethodInfoPtr_BackwardInsertion_Public_Void_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673496);
			Matrix.NativeMethodInfoPtr_SymmetrizeDown_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673497);
			Matrix.NativeMethodInfoPtr_SymmetrizeUp_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673498);
			Matrix.NativeMethodInfoPtr_QRGramSchmidt_Public_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673499);
			Matrix.NativeMethodInfoPtr_Eigenvalues_Public_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673500);
			Matrix.NativeMethodInfoPtr_Eigenvector_Public_Matrix_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673501);
			Matrix.NativeMethodInfoPtr_SolveCG_Public_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673502);
			Matrix.NativeMethodInfoPtr_QRIterationBasic_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673503);
			Matrix.NativeMethodInfoPtr_QRIterationHessenberg_Public_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673504);
			Matrix.NativeMethodInfoPtr_QRGivens_Public_ArrayOf_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673505);
			Matrix.NativeMethodInfoPtr_GivProd_Private_Matrix_Matrix_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673506);
			Matrix.NativeMethodInfoPtr_Garow_Private_Void_Complex_Complex_Int32_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673507);
			Matrix.NativeMethodInfoPtr_Gacol_Public_Void_Complex_Complex_Int32_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673508);
			Matrix.NativeMethodInfoPtr_GivensCS_Private_ArrayOf_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673509);
			Matrix.NativeMethodInfoPtr_Determinant_Public_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673510);
			Matrix.NativeMethodInfoPtr_ColumnSumNorm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673511);
			Matrix.NativeMethodInfoPtr_RowSumNorm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673512);
			Matrix.NativeMethodInfoPtr_Permanent_Public_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673513);
			Matrix.NativeMethodInfoPtr_GetMinRow_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673514);
			Matrix.NativeMethodInfoPtr_GetMinColumn_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673515);
			Matrix.NativeMethodInfoPtr_Factorial_Private_Double_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673516);
			Matrix.NativeMethodInfoPtr_Signum_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673517);
			Matrix.NativeMethodInfoPtr_Condition_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673518);
			Matrix.NativeMethodInfoPtr_Condition_Public_Double_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673519);
			Matrix.NativeMethodInfoPtr_ConditionFro_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673520);
			Matrix.NativeMethodInfoPtr_PNorm_Public_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673521);
			Matrix.NativeMethodInfoPtr_Norm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673522);
			Matrix.NativeMethodInfoPtr_FrobeniusNorm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673523);
			Matrix.NativeMethodInfoPtr_TaxiNorm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673524);
			Matrix.NativeMethodInfoPtr_MaxNorm_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673525);
			Matrix.NativeMethodInfoPtr_ColumnSum_Public_Complex_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673526);
			Matrix.NativeMethodInfoPtr_AbsColumnSum_Public_Double_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673527);
			Matrix.NativeMethodInfoPtr_RowSum_Public_Complex_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673528);
			Matrix.NativeMethodInfoPtr_AbsRowSum_Public_Double_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673529);
			Matrix.NativeMethodInfoPtr_DiagProd_Public_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673530);
			Matrix.NativeMethodInfoPtr_Trace_Public_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673531);
			Matrix.NativeMethodInfoPtr_Sqr_Private_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673532);
			Matrix.NativeMethodInfoPtr_IsNormal_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673533);
			Matrix.NativeMethodInfoPtr_IsUnitary_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673534);
			Matrix.NativeMethodInfoPtr_IsHermitian_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673535);
			Matrix.NativeMethodInfoPtr_IsReal_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673536);
			Matrix.NativeMethodInfoPtr_IsSymmetricPositiveDefinite_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673537);
			Matrix.NativeMethodInfoPtr_IsSPD_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673538);
			Matrix.NativeMethodInfoPtr_Definiteness_Public_DefinitenessType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673539);
			Matrix.NativeMethodInfoPtr_HasZeroRowOrColumn_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673540);
			Matrix.NativeMethodInfoPtr_IsZeroOneMatrix_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673541);
			Matrix.NativeMethodInfoPtr_IsPermutation_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673542);
			Matrix.NativeMethodInfoPtr_IsDiagonal_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673543);
			Matrix.NativeMethodInfoPtr_VectorLength_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673544);
			Matrix.NativeMethodInfoPtr_IsSquare_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673545);
			Matrix.NativeMethodInfoPtr_IsInvolutary_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673546);
			Matrix.NativeMethodInfoPtr_IsSymmetric_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673547);
			Matrix.NativeMethodInfoPtr_IsOrthogonal_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673548);
			Matrix.NativeMethodInfoPtr_IsTrapeze_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673549);
			Matrix.NativeMethodInfoPtr_IsTriangular_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673550);
			Matrix.NativeMethodInfoPtr_IsUpperTriangular_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673551);
			Matrix.NativeMethodInfoPtr_IsLowerTriangular_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673552);
			Matrix.NativeMethodInfoPtr_IsUpperTrapeze_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673553);
			Matrix.NativeMethodInfoPtr_IsLowerTrapeze_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673554);
			Matrix.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673555);
			Matrix.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673556);
			Matrix.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673557);
			Matrix.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673558);
			Matrix.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673559);
			Matrix.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673560);
			Matrix.NativeMethodInfoPtr_op_Addition_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673561);
			Matrix.NativeMethodInfoPtr_op_Subtraction_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673562);
			Matrix.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673563);
			Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673564);
			Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673565);
			Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Complex_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673566);
			Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673567);
			Matrix.NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Double_Matrix_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673568);
			Matrix.NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673569);
			Matrix.NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673570);
			Matrix.NativeMethodInfoPtr_op_ExclusiveOr_Public_Static_Matrix_Matrix_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673571);
			Matrix.NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Int32_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673572);
			Matrix.NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673573);
			Matrix.NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673574);
			Matrix.NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Matrix>.NativeClassPtr, 100673575);
		}

		// Token: 0x06007F26 RID: 32550 RVA: 0x00002988 File Offset: 0x00000B88
		public Matrix(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002D67 RID: 11623
		// (get) Token: 0x06007F27 RID: 32551 RVA: 0x0020219C File Offset: 0x0020039C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Matrix>.NativeClassPtr));
			}
		}

		// Token: 0x17002D68 RID: 11624
		// (get) Token: 0x06007F28 RID: 32552 RVA: 0x002021B0 File Offset: 0x002003B0
		// (set) Token: 0x06007F29 RID: 32553 RVA: 0x002021E4 File Offset: 0x002003E4
		public unsafe ArrayList Values
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_Values);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ArrayList(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_Values), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002D69 RID: 11625
		// (get) Token: 0x06007F2A RID: 32554 RVA: 0x0020220C File Offset: 0x0020040C
		// (set) Token: 0x06007F2B RID: 32555 RVA: 0x00202234 File Offset: 0x00200434
		public unsafe int rowCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_rowCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_rowCount)) = value;
			}
		}

		// Token: 0x17002D6A RID: 11626
		// (get) Token: 0x06007F2C RID: 32556 RVA: 0x00202258 File Offset: 0x00200458
		// (set) Token: 0x06007F2D RID: 32557 RVA: 0x00202280 File Offset: 0x00200480
		public unsafe int columnCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_columnCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Matrix.NativeFieldInfoPtr_columnCount)) = value;
			}
		}

		// Token: 0x040050ED RID: 20717
		private static readonly IntPtr NativeFieldInfoPtr_Values;

		// Token: 0x040050EE RID: 20718
		private static readonly IntPtr NativeFieldInfoPtr_rowCount;

		// Token: 0x040050EF RID: 20719
		private static readonly IntPtr NativeFieldInfoPtr_columnCount;

		// Token: 0x040050F0 RID: 20720
		private static readonly IntPtr NativeMethodInfoPtr_get_RowCount_Public_get_Int32_0;

		// Token: 0x040050F1 RID: 20721
		private static readonly IntPtr NativeMethodInfoPtr_get_ColumnCount_Public_get_Int32_0;

		// Token: 0x040050F2 RID: 20722
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x040050F3 RID: 20723
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_Int32_0;

		// Token: 0x040050F4 RID: 20724
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040050F5 RID: 20725
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Complex_0;

		// Token: 0x040050F6 RID: 20726
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0;

		// Token: 0x040050F7 RID: 20727
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Complex_0;

		// Token: 0x040050F8 RID: 20728
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Double_0;

		// Token: 0x040050F9 RID: 20729
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Il2CppObjectBase_0;

		// Token: 0x040050FA RID: 20730
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_Double_0;

		// Token: 0x040050FB RID: 20731
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_0;

		// Token: 0x040050FC RID: 20732
		private static readonly IntPtr NativeMethodInfoPtr_E_Public_Static_Matrix_Int32_Int32_0;

		// Token: 0x040050FD RID: 20733
		private static readonly IntPtr NativeMethodInfoPtr_KroneckerDelta_Public_Static_Complex_Int32_Int32_0;

		// Token: 0x040050FE RID: 20734
		private static readonly IntPtr NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Int32_Boolean_0;

		// Token: 0x040050FF RID: 20735
		private static readonly IntPtr NativeMethodInfoPtr_ChessboardMatrix_Public_Static_Matrix_Int32_Boolean_0;

		// Token: 0x04005100 RID: 20736
		private static readonly IntPtr NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_Int32_0;

		// Token: 0x04005101 RID: 20737
		private static readonly IntPtr NativeMethodInfoPtr_Zeros_Public_Static_Matrix_Int32_0;

		// Token: 0x04005102 RID: 20738
		private static readonly IntPtr NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_Int32_0;

		// Token: 0x04005103 RID: 20739
		private static readonly IntPtr NativeMethodInfoPtr_Ones_Public_Static_Matrix_Int32_0;

		// Token: 0x04005104 RID: 20740
		private static readonly IntPtr NativeMethodInfoPtr_Identity_Public_Static_Matrix_Int32_0;

		// Token: 0x04005105 RID: 20741
		private static readonly IntPtr NativeMethodInfoPtr_Eye_Public_Static_Matrix_Int32_0;

		// Token: 0x04005106 RID: 20742
		private static readonly IntPtr NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005107 RID: 20743
		private static readonly IntPtr NativeMethodInfoPtr_VerticalConcat_Public_Static_Matrix_ArrayOf_Matrix_0;

		// Token: 0x04005108 RID: 20744
		private static readonly IntPtr NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005109 RID: 20745
		private static readonly IntPtr NativeMethodInfoPtr_HorizontalConcat_Public_Static_Matrix_ArrayOf_Matrix_0;

		// Token: 0x0400510A RID: 20746
		private static readonly IntPtr NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_0;

		// Token: 0x0400510B RID: 20747
		private static readonly IntPtr NativeMethodInfoPtr_Diag_Public_Static_Matrix_Matrix_Int32_0;

		// Token: 0x0400510C RID: 20748
		private static readonly IntPtr NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Complex_Complex_Complex_Int32_0;

		// Token: 0x0400510D RID: 20749
		private static readonly IntPtr NativeMethodInfoPtr_TriDiag_Public_Static_Matrix_Matrix_Matrix_Matrix_0;

		// Token: 0x0400510E RID: 20750
		private static readonly IntPtr NativeMethodInfoPtr_Dot_Public_Static_Complex_Matrix_Matrix_0;

		// Token: 0x0400510F RID: 20751
		private static readonly IntPtr NativeMethodInfoPtr_Fib_Public_Static_Complex_Int32_0;

		// Token: 0x04005110 RID: 20752
		private static readonly IntPtr NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_0;

		// Token: 0x04005111 RID: 20753
		private static readonly IntPtr NativeMethodInfoPtr_RandomGraph_Public_Static_Matrix_Int32_Double_0;

		// Token: 0x04005112 RID: 20754
		private static readonly IntPtr NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_0;

		// Token: 0x04005113 RID: 20755
		private static readonly IntPtr NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_0;

		// Token: 0x04005114 RID: 20756
		private static readonly IntPtr NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_0;

		// Token: 0x04005115 RID: 20757
		private static readonly IntPtr NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Int32_Double_0;

		// Token: 0x04005116 RID: 20758
		private static readonly IntPtr NativeMethodInfoPtr_RandomZeroOne_Public_Static_Matrix_Int32_Double_0;

		// Token: 0x04005117 RID: 20759
		private static readonly IntPtr NativeMethodInfoPtr_Random_Public_Static_Matrix_Int32_Int32_Int32_Int32_0;

		// Token: 0x04005118 RID: 20760
		private static readonly IntPtr NativeMethodInfoPtr_Vandermonde_Public_Static_Matrix_ArrayOf_Complex_0;

		// Token: 0x04005119 RID: 20761
		private static readonly IntPtr NativeMethodInfoPtr_Floyd_Public_Static_ArrayOf_Matrix_Matrix_0;

		// Token: 0x0400511A RID: 20762
		private static readonly IntPtr NativeMethodInfoPtr_FloydPath_Public_Static_ArrayList_Matrix_Int32_Int32_0;

		// Token: 0x0400511B RID: 20763
		private static readonly IntPtr NativeMethodInfoPtr_DFS_Public_Static_Matrix_Matrix_Int32_0;

		// Token: 0x0400511C RID: 20764
		private static readonly IntPtr NativeMethodInfoPtr_BFS_Public_Static_Matrix_Matrix_Int32_0;

		// Token: 0x0400511D RID: 20765
		private static readonly IntPtr NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Int32_Double_0;

		// Token: 0x0400511E RID: 20766
		private static readonly IntPtr NativeMethodInfoPtr_ZeroOneRandom_Public_Static_Matrix_Int32_Double_0;

		// Token: 0x0400511F RID: 20767
		private static readonly IntPtr NativeMethodInfoPtr_HouseholderVector_Private_Static_ArrayOf_Matrix_Matrix_0;

		// Token: 0x04005120 RID: 20768
		private static readonly IntPtr NativeMethodInfoPtr_BlockMatrix_Public_Static_Matrix_Matrix_Matrix_Matrix_Matrix_0;

		// Token: 0x04005121 RID: 20769
		private static readonly IntPtr NativeMethodInfoPtr_Solve_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005122 RID: 20770
		private static readonly IntPtr NativeMethodInfoPtr_Re_Public_Matrix_0;

		// Token: 0x04005123 RID: 20771
		private static readonly IntPtr NativeMethodInfoPtr_Im_Public_Matrix_0;

		// Token: 0x04005124 RID: 20772
		private static readonly IntPtr NativeMethodInfoPtr_HessenbergHouseholder_Public_ArrayOf_Matrix_0;

		// Token: 0x04005125 RID: 20773
		private static readonly IntPtr NativeMethodInfoPtr_Extract_Public_Matrix_Int32_Int32_Int32_Int32_0;

		// Token: 0x04005126 RID: 20774
		private static readonly IntPtr NativeMethodInfoPtr_ExtractLowerTrapeze_Public_Matrix_0;

		// Token: 0x04005127 RID: 20775
		private static readonly IntPtr NativeMethodInfoPtr_ExtractUpperTrapeze_Public_Matrix_0;

		// Token: 0x04005128 RID: 20776
		private static readonly IntPtr NativeMethodInfoPtr_ColumnVectorize_Public_ArrayOf_Matrix_0;

		// Token: 0x04005129 RID: 20777
		private static readonly IntPtr NativeMethodInfoPtr_RowVectorize_Public_ArrayOf_Matrix_0;

		// Token: 0x0400512A RID: 20778
		private static readonly IntPtr NativeMethodInfoPtr_VerticalFlip_Public_Void_0;

		// Token: 0x0400512B RID: 20779
		private static readonly IntPtr NativeMethodInfoPtr_HorizontalFlip_Public_Void_0;

		// Token: 0x0400512C RID: 20780
		private static readonly IntPtr NativeMethodInfoPtr_SwapColumns_Public_Void_Int32_Int32_0;

		// Token: 0x0400512D RID: 20781
		private static readonly IntPtr NativeMethodInfoPtr_SwapRows_Public_Void_Int32_Int32_0;

		// Token: 0x0400512E RID: 20782
		private static readonly IntPtr NativeMethodInfoPtr_DeleteRow_Public_Void_Int32_0;

		// Token: 0x0400512F RID: 20783
		private static readonly IntPtr NativeMethodInfoPtr_DeleteColumn_Public_Void_Int32_0;

		// Token: 0x04005130 RID: 20784
		private static readonly IntPtr NativeMethodInfoPtr_ExtractRow_Public_Matrix_Int32_0;

		// Token: 0x04005131 RID: 20785
		private static readonly IntPtr NativeMethodInfoPtr_ExtractColumn_Public_Matrix_Int32_0;

		// Token: 0x04005132 RID: 20786
		private static readonly IntPtr NativeMethodInfoPtr_InsertRow_Public_Void_Matrix_Int32_0;

		// Token: 0x04005133 RID: 20787
		private static readonly IntPtr NativeMethodInfoPtr_Insert_Public_Void_Int32_Int32_Matrix_0;

		// Token: 0x04005134 RID: 20788
		private static readonly IntPtr NativeMethodInfoPtr_InsertColumn_Public_Void_Matrix_Int32_0;

		// Token: 0x04005135 RID: 20789
		private static readonly IntPtr NativeMethodInfoPtr_Inverse_Public_Matrix_0;

		// Token: 0x04005136 RID: 20790
		private static readonly IntPtr NativeMethodInfoPtr_InverseLeverrier_Public_Matrix_0;

		// Token: 0x04005137 RID: 20791
		private static readonly IntPtr NativeMethodInfoPtr_Minor_Public_Matrix_Int32_Int32_0;

		// Token: 0x04005138 RID: 20792
		private static readonly IntPtr NativeMethodInfoPtr_Clone_Public_Matrix_0;

		// Token: 0x04005139 RID: 20793
		private static readonly IntPtr NativeMethodInfoPtr_DiagVector_Public_Matrix_0;

		// Token: 0x0400513A RID: 20794
		private static readonly IntPtr NativeMethodInfoPtr_Column_Public_Matrix_Int32_0;

		// Token: 0x0400513B RID: 20795
		private static readonly IntPtr NativeMethodInfoPtr_Row_Public_Matrix_Int32_0;

		// Token: 0x0400513C RID: 20796
		private static readonly IntPtr NativeMethodInfoPtr_Transpose_Public_Matrix_0;

		// Token: 0x0400513D RID: 20797
		private static readonly IntPtr NativeMethodInfoPtr_Conjugate_Public_Matrix_0;

		// Token: 0x0400513E RID: 20798
		private static readonly IntPtr NativeMethodInfoPtr_ConjTranspose_Public_Matrix_0;

		// Token: 0x0400513F RID: 20799
		private static readonly IntPtr NativeMethodInfoPtr_LU_Public_Void_0;

		// Token: 0x04005140 RID: 20800
		private static readonly IntPtr NativeMethodInfoPtr_LUSafe_Public_Matrix_0;

		// Token: 0x04005141 RID: 20801
		private static readonly IntPtr NativeMethodInfoPtr_Cholesky_Public_Void_0;

		// Token: 0x04005142 RID: 20802
		private static readonly IntPtr NativeMethodInfoPtr_CholeskyUndo_Public_Void_0;

		// Token: 0x04005143 RID: 20803
		private static readonly IntPtr NativeMethodInfoPtr_ForwardInsertion_Public_Void_Matrix_0;

		// Token: 0x04005144 RID: 20804
		private static readonly IntPtr NativeMethodInfoPtr_BackwardInsertion_Public_Void_Matrix_0;

		// Token: 0x04005145 RID: 20805
		private static readonly IntPtr NativeMethodInfoPtr_SymmetrizeDown_Public_Void_0;

		// Token: 0x04005146 RID: 20806
		private static readonly IntPtr NativeMethodInfoPtr_SymmetrizeUp_Public_Void_0;

		// Token: 0x04005147 RID: 20807
		private static readonly IntPtr NativeMethodInfoPtr_QRGramSchmidt_Public_ArrayOf_Matrix_0;

		// Token: 0x04005148 RID: 20808
		private static readonly IntPtr NativeMethodInfoPtr_Eigenvalues_Public_Matrix_0;

		// Token: 0x04005149 RID: 20809
		private static readonly IntPtr NativeMethodInfoPtr_Eigenvector_Public_Matrix_Complex_0;

		// Token: 0x0400514A RID: 20810
		private static readonly IntPtr NativeMethodInfoPtr_SolveCG_Public_Matrix_Matrix_0;

		// Token: 0x0400514B RID: 20811
		private static readonly IntPtr NativeMethodInfoPtr_QRIterationBasic_Public_Matrix_Int32_0;

		// Token: 0x0400514C RID: 20812
		private static readonly IntPtr NativeMethodInfoPtr_QRIterationHessenberg_Public_Matrix_Int32_0;

		// Token: 0x0400514D RID: 20813
		private static readonly IntPtr NativeMethodInfoPtr_QRGivens_Public_ArrayOf_Matrix_0;

		// Token: 0x0400514E RID: 20814
		private static readonly IntPtr NativeMethodInfoPtr_GivProd_Private_Matrix_Matrix_Matrix_Int32_0;

		// Token: 0x0400514F RID: 20815
		private static readonly IntPtr NativeMethodInfoPtr_Garow_Private_Void_Complex_Complex_Int32_Int32_Int32_Int32_0;

		// Token: 0x04005150 RID: 20816
		private static readonly IntPtr NativeMethodInfoPtr_Gacol_Public_Void_Complex_Complex_Int32_Int32_Int32_Int32_0;

		// Token: 0x04005151 RID: 20817
		private static readonly IntPtr NativeMethodInfoPtr_GivensCS_Private_ArrayOf_Complex_Complex_Complex_0;

		// Token: 0x04005152 RID: 20818
		private static readonly IntPtr NativeMethodInfoPtr_Determinant_Public_Complex_0;

		// Token: 0x04005153 RID: 20819
		private static readonly IntPtr NativeMethodInfoPtr_ColumnSumNorm_Public_Double_0;

		// Token: 0x04005154 RID: 20820
		private static readonly IntPtr NativeMethodInfoPtr_RowSumNorm_Public_Double_0;

		// Token: 0x04005155 RID: 20821
		private static readonly IntPtr NativeMethodInfoPtr_Permanent_Public_Complex_0;

		// Token: 0x04005156 RID: 20822
		private static readonly IntPtr NativeMethodInfoPtr_GetMinRow_Public_Int32_0;

		// Token: 0x04005157 RID: 20823
		private static readonly IntPtr NativeMethodInfoPtr_GetMinColumn_Public_Int32_0;

		// Token: 0x04005158 RID: 20824
		private static readonly IntPtr NativeMethodInfoPtr_Factorial_Private_Double_Int32_0;

		// Token: 0x04005159 RID: 20825
		private static readonly IntPtr NativeMethodInfoPtr_Signum_Public_Double_0;

		// Token: 0x0400515A RID: 20826
		private static readonly IntPtr NativeMethodInfoPtr_Condition_Public_Double_0;

		// Token: 0x0400515B RID: 20827
		private static readonly IntPtr NativeMethodInfoPtr_Condition_Public_Double_Int32_0;

		// Token: 0x0400515C RID: 20828
		private static readonly IntPtr NativeMethodInfoPtr_ConditionFro_Public_Double_0;

		// Token: 0x0400515D RID: 20829
		private static readonly IntPtr NativeMethodInfoPtr_PNorm_Public_Double_Double_0;

		// Token: 0x0400515E RID: 20830
		private static readonly IntPtr NativeMethodInfoPtr_Norm_Public_Double_0;

		// Token: 0x0400515F RID: 20831
		private static readonly IntPtr NativeMethodInfoPtr_FrobeniusNorm_Public_Double_0;

		// Token: 0x04005160 RID: 20832
		private static readonly IntPtr NativeMethodInfoPtr_TaxiNorm_Public_Double_0;

		// Token: 0x04005161 RID: 20833
		private static readonly IntPtr NativeMethodInfoPtr_MaxNorm_Public_Double_0;

		// Token: 0x04005162 RID: 20834
		private static readonly IntPtr NativeMethodInfoPtr_ColumnSum_Public_Complex_Int32_0;

		// Token: 0x04005163 RID: 20835
		private static readonly IntPtr NativeMethodInfoPtr_AbsColumnSum_Public_Double_Int32_0;

		// Token: 0x04005164 RID: 20836
		private static readonly IntPtr NativeMethodInfoPtr_RowSum_Public_Complex_Int32_0;

		// Token: 0x04005165 RID: 20837
		private static readonly IntPtr NativeMethodInfoPtr_AbsRowSum_Public_Double_Int32_0;

		// Token: 0x04005166 RID: 20838
		private static readonly IntPtr NativeMethodInfoPtr_DiagProd_Public_Complex_0;

		// Token: 0x04005167 RID: 20839
		private static readonly IntPtr NativeMethodInfoPtr_Trace_Public_Complex_0;

		// Token: 0x04005168 RID: 20840
		private static readonly IntPtr NativeMethodInfoPtr_Sqr_Private_Complex_Complex_0;

		// Token: 0x04005169 RID: 20841
		private static readonly IntPtr NativeMethodInfoPtr_IsNormal_Public_Boolean_0;

		// Token: 0x0400516A RID: 20842
		private static readonly IntPtr NativeMethodInfoPtr_IsUnitary_Public_Boolean_0;

		// Token: 0x0400516B RID: 20843
		private static readonly IntPtr NativeMethodInfoPtr_IsHermitian_Public_Boolean_0;

		// Token: 0x0400516C RID: 20844
		private static readonly IntPtr NativeMethodInfoPtr_IsReal_Public_Boolean_0;

		// Token: 0x0400516D RID: 20845
		private static readonly IntPtr NativeMethodInfoPtr_IsSymmetricPositiveDefinite_Public_Boolean_0;

		// Token: 0x0400516E RID: 20846
		private static readonly IntPtr NativeMethodInfoPtr_IsSPD_Public_Boolean_0;

		// Token: 0x0400516F RID: 20847
		private static readonly IntPtr NativeMethodInfoPtr_Definiteness_Public_DefinitenessType_0;

		// Token: 0x04005170 RID: 20848
		private static readonly IntPtr NativeMethodInfoPtr_HasZeroRowOrColumn_Public_Boolean_0;

		// Token: 0x04005171 RID: 20849
		private static readonly IntPtr NativeMethodInfoPtr_IsZeroOneMatrix_Public_Boolean_0;

		// Token: 0x04005172 RID: 20850
		private static readonly IntPtr NativeMethodInfoPtr_IsPermutation_Public_Boolean_0;

		// Token: 0x04005173 RID: 20851
		private static readonly IntPtr NativeMethodInfoPtr_IsDiagonal_Public_Boolean_0;

		// Token: 0x04005174 RID: 20852
		private static readonly IntPtr NativeMethodInfoPtr_VectorLength_Public_Int32_0;

		// Token: 0x04005175 RID: 20853
		private static readonly IntPtr NativeMethodInfoPtr_IsSquare_Public_Boolean_0;

		// Token: 0x04005176 RID: 20854
		private static readonly IntPtr NativeMethodInfoPtr_IsInvolutary_Public_Boolean_0;

		// Token: 0x04005177 RID: 20855
		private static readonly IntPtr NativeMethodInfoPtr_IsSymmetric_Public_Boolean_0;

		// Token: 0x04005178 RID: 20856
		private static readonly IntPtr NativeMethodInfoPtr_IsOrthogonal_Public_Boolean_0;

		// Token: 0x04005179 RID: 20857
		private static readonly IntPtr NativeMethodInfoPtr_IsTrapeze_Public_Boolean_0;

		// Token: 0x0400517A RID: 20858
		private static readonly IntPtr NativeMethodInfoPtr_IsTriangular_Public_Boolean_0;

		// Token: 0x0400517B RID: 20859
		private static readonly IntPtr NativeMethodInfoPtr_IsUpperTriangular_Public_Boolean_0;

		// Token: 0x0400517C RID: 20860
		private static readonly IntPtr NativeMethodInfoPtr_IsLowerTriangular_Public_Boolean_0;

		// Token: 0x0400517D RID: 20861
		private static readonly IntPtr NativeMethodInfoPtr_IsUpperTrapeze_Public_Boolean_0;

		// Token: 0x0400517E RID: 20862
		private static readonly IntPtr NativeMethodInfoPtr_IsLowerTrapeze_Public_Boolean_0;

		// Token: 0x0400517F RID: 20863
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04005180 RID: 20864
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04005181 RID: 20865
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04005182 RID: 20866
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04005183 RID: 20867
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Matrix_Matrix_0;

		// Token: 0x04005184 RID: 20868
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Matrix_Matrix_0;

		// Token: 0x04005185 RID: 20869
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005186 RID: 20870
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005187 RID: 20871
		private static readonly IntPtr NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Matrix_Matrix_0;

		// Token: 0x04005188 RID: 20872
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Matrix_0;

		// Token: 0x04005189 RID: 20873
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Complex_0;

		// Token: 0x0400518A RID: 20874
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Complex_Matrix_0;

		// Token: 0x0400518B RID: 20875
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Matrix_Double_0;

		// Token: 0x0400518C RID: 20876
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Matrix_Double_Matrix_0;

		// Token: 0x0400518D RID: 20877
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Complex_0;

		// Token: 0x0400518E RID: 20878
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_Matrix_Matrix_Double_0;

		// Token: 0x0400518F RID: 20879
		private static readonly IntPtr NativeMethodInfoPtr_op_ExclusiveOr_Public_Static_Matrix_Matrix_Int32_0;

		// Token: 0x04005190 RID: 20880
		private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Int32_Complex_0;

		// Token: 0x04005191 RID: 20881
		private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_Int32_0;

		// Token: 0x04005192 RID: 20882
		private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_Virtual_New_set_Void_Int32_Complex_0;

		// Token: 0x04005193 RID: 20883
		private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_Virtual_New_get_Complex_Int32_0;

		// Token: 0x0200061D RID: 1565
		public enum DefinitenessType
		{
			// Token: 0x04005195 RID: 20885
			PositiveDefinite,
			// Token: 0x04005196 RID: 20886
			PositiveSemidefinite,
			// Token: 0x04005197 RID: 20887
			NegativeDefinite,
			// Token: 0x04005198 RID: 20888
			NegativeSemidefinite,
			// Token: 0x04005199 RID: 20889
			Indefinite
		}
	}
}
