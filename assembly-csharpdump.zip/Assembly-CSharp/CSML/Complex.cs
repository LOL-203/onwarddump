﻿using System;
using Il2CppSystem;
using Il2CppSystem.Text.RegularExpressions;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CSML
{
	// Token: 0x0200061B RID: 1563
	public class Complex : Object
	{
		// Token: 0x17002D62 RID: 11618
		// (get) Token: 0x06007E40 RID: 32320 RVA: 0x001FB804 File Offset: 0x001F9A04
		// (set) Token: 0x06007E41 RID: 32321 RVA: 0x001FB854 File Offset: 0x001F9A54
		public unsafe double Re
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_get_Re_Public_get_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_set_Re_Public_set_Void_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17002D63 RID: 11619
		// (get) Token: 0x06007E42 RID: 32322 RVA: 0x001FB8A8 File Offset: 0x001F9AA8
		// (set) Token: 0x06007E43 RID: 32323 RVA: 0x001FB8F8 File Offset: 0x001F9AF8
		public unsafe double Im
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_get_Im_Public_get_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_set_Im_Public_set_Void_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17002D64 RID: 11620
		// (get) Token: 0x06007E44 RID: 32324 RVA: 0x001FB94C File Offset: 0x001F9B4C
		public unsafe static Complex I
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_get_I_Public_Static_get_Complex_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Complex(intPtr2) : null;
			}
		}

		// Token: 0x17002D65 RID: 11621
		// (get) Token: 0x06007E45 RID: 32325 RVA: 0x001FB994 File Offset: 0x001F9B94
		public unsafe static Complex Zero
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_get_Zero_Public_Static_get_Complex_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Complex(intPtr2) : null;
			}
		}

		// Token: 0x17002D66 RID: 11622
		// (get) Token: 0x06007E46 RID: 32326 RVA: 0x001FB9DC File Offset: 0x001F9BDC
		public unsafe static Complex One
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_get_One_Public_Static_get_Complex_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Complex(intPtr2) : null;
			}
		}

		// Token: 0x06007E47 RID: 32327 RVA: 0x001FBA24 File Offset: 0x001F9C24
		[CallerCount(0)]
		public unsafe Complex() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Complex>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E48 RID: 32328 RVA: 0x001FBA70 File Offset: 0x001F9C70
		[CallerCount(0)]
		public unsafe Complex(double real_part) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Complex>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref real_part;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr__ctor_Public_Void_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E49 RID: 32329 RVA: 0x001FBAD0 File Offset: 0x001F9CD0
		[CallerCount(0)]
		public unsafe Complex(double real_part, double imaginary_part) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Complex>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref real_part;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref imaginary_part;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr__ctor_Public_Void_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E4A RID: 32330 RVA: 0x001FBB40 File Offset: 0x001F9D40
		[CallerCount(0)]
		public unsafe Complex(string s) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Complex>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(s);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr__ctor_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06007E4B RID: 32331 RVA: 0x001FBBA4 File Offset: 0x001F9DA4
		[CallerCount(0)]
		public unsafe static Match Test(string s)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(s);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Test_Public_Static_Match_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Match(intPtr2) : null;
		}

		// Token: 0x06007E4C RID: 32332 RVA: 0x001FBC04 File Offset: 0x001F9E04
		[CallerCount(0)]
		public unsafe static Complex operator +(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E4D RID: 32333 RVA: 0x001FBC7C File Offset: 0x001F9E7C
		[CallerCount(0)]
		public unsafe static Complex operator +(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E4E RID: 32334 RVA: 0x001FBCF0 File Offset: 0x001F9EF0
		[CallerCount(0)]
		public unsafe static Complex operator +(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E4F RID: 32335 RVA: 0x001FBD64 File Offset: 0x001F9F64
		[CallerCount(0)]
		public unsafe static Complex operator -(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E50 RID: 32336 RVA: 0x001FBDDC File Offset: 0x001F9FDC
		[CallerCount(0)]
		public unsafe static Complex operator -(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E51 RID: 32337 RVA: 0x001FBE50 File Offset: 0x001FA050
		[CallerCount(0)]
		public unsafe static Complex operator -(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E52 RID: 32338 RVA: 0x001FBEC4 File Offset: 0x001FA0C4
		[CallerCount(0)]
		public unsafe static Complex operator -(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E53 RID: 32339 RVA: 0x001FBF24 File Offset: 0x001FA124
		[CallerCount(0)]
		public unsafe static Complex operator *(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E54 RID: 32340 RVA: 0x001FBF9C File Offset: 0x001FA19C
		[CallerCount(0)]
		public unsafe static Complex operator *(Complex a, double d)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref d;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E55 RID: 32341 RVA: 0x001FC010 File Offset: 0x001FA210
		[CallerCount(0)]
		public unsafe static Complex operator *(double d, Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref d;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E56 RID: 32342 RVA: 0x001FC084 File Offset: 0x001FA284
		[CallerCount(0)]
		public unsafe static Complex operator /(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E57 RID: 32343 RVA: 0x001FC0FC File Offset: 0x001FA2FC
		[CallerCount(0)]
		public unsafe static Complex operator /(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E58 RID: 32344 RVA: 0x001FC170 File Offset: 0x001FA370
		[CallerCount(0)]
		public unsafe static Complex operator /(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E59 RID: 32345 RVA: 0x001FC1E4 File Offset: 0x001FA3E4
		[CallerCount(0)]
		public unsafe static bool operator ==(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5A RID: 32346 RVA: 0x001FC254 File Offset: 0x001FA454
		[CallerCount(0)]
		public unsafe static bool operator ==(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5B RID: 32347 RVA: 0x001FC2C0 File Offset: 0x001FA4C0
		[CallerCount(0)]
		public unsafe static bool operator ==(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5C RID: 32348 RVA: 0x001FC32C File Offset: 0x001FA52C
		[CallerCount(0)]
		public unsafe static bool operator !=(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5D RID: 32349 RVA: 0x001FC39C File Offset: 0x001FA59C
		[CallerCount(0)]
		public unsafe static bool operator !=(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5E RID: 32350 RVA: 0x001FC408 File Offset: 0x001FA608
		[CallerCount(0)]
		public unsafe static bool operator !=(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E5F RID: 32351 RVA: 0x001FC474 File Offset: 0x001FA674
		[CallerCount(0)]
		public unsafe static double Abs(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Abs_Public_Static_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E60 RID: 32352 RVA: 0x001FC4CC File Offset: 0x001FA6CC
		[CallerCount(0)]
		public unsafe static Complex Inv(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Inv_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E61 RID: 32353 RVA: 0x001FC52C File Offset: 0x001FA72C
		[CallerCount(0)]
		public unsafe static Complex Tan(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Tan_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E62 RID: 32354 RVA: 0x001FC58C File Offset: 0x001FA78C
		[CallerCount(0)]
		public unsafe static Complex Cosh(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Cosh_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E63 RID: 32355 RVA: 0x001FC5EC File Offset: 0x001FA7EC
		[CallerCount(0)]
		public unsafe static Complex Sinh(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Sinh_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E64 RID: 32356 RVA: 0x001FC64C File Offset: 0x001FA84C
		[CallerCount(0)]
		public unsafe static Complex Tanh(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Tanh_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E65 RID: 32357 RVA: 0x001FC6AC File Offset: 0x001FA8AC
		[CallerCount(0)]
		public unsafe static Complex Coth(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Coth_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E66 RID: 32358 RVA: 0x001FC70C File Offset: 0x001FA90C
		[CallerCount(0)]
		public unsafe static Complex Sech(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Sech_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E67 RID: 32359 RVA: 0x001FC76C File Offset: 0x001FA96C
		[CallerCount(0)]
		public unsafe static Complex Csch(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Csch_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E68 RID: 32360 RVA: 0x001FC7CC File Offset: 0x001FA9CC
		[CallerCount(0)]
		public unsafe static Complex Cot(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Cot_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E69 RID: 32361 RVA: 0x001FC82C File Offset: 0x001FAA2C
		[CallerCount(0)]
		public unsafe static Complex Conj(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Conj_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E6A RID: 32362 RVA: 0x001FC88C File Offset: 0x001FAA8C
		[CallerCount(0)]
		public unsafe static Complex Sqrt(double d)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref d;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E6B RID: 32363 RVA: 0x001FC8E8 File Offset: 0x001FAAE8
		[CallerCount(0)]
		public unsafe static Complex Sqrt(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E6C RID: 32364 RVA: 0x001FC948 File Offset: 0x001FAB48
		[CallerCount(0)]
		public unsafe static Complex Exp(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Exp_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E6D RID: 32365 RVA: 0x001FC9A8 File Offset: 0x001FABA8
		[CallerCount(0)]
		public unsafe static Complex Log(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Log_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E6E RID: 32366 RVA: 0x001FCA08 File Offset: 0x001FAC08
		[CallerCount(0)]
		public unsafe static double Arg(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Arg_Public_Static_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E6F RID: 32367 RVA: 0x001FCA60 File Offset: 0x001FAC60
		[CallerCount(0)]
		public unsafe static Complex Cos(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Cos_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E70 RID: 32368 RVA: 0x001FCAC0 File Offset: 0x001FACC0
		[CallerCount(0)]
		public unsafe static Complex Sin(Complex a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Sin_Public_Static_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E71 RID: 32369 RVA: 0x001FCB20 File Offset: 0x001FAD20
		[CallerCount(0)]
		public unsafe static Complex Pow(Complex a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E72 RID: 32370 RVA: 0x001FCB98 File Offset: 0x001FAD98
		[CallerCount(0)]
		public unsafe static Complex Pow(double a, Complex b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Double_Complex_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E73 RID: 32371 RVA: 0x001FCC0C File Offset: 0x001FAE0C
		[CallerCount(0)]
		public unsafe static Complex Pow(Complex a, double b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Complex(intPtr2) : null;
		}

		// Token: 0x06007E74 RID: 32372 RVA: 0x001FCC80 File Offset: 0x001FAE80
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Complex.NativeMethodInfoPtr_ToString_Public_Virtual_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06007E75 RID: 32373 RVA: 0x001FCCD8 File Offset: 0x001FAED8
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_ToString_Public_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06007E76 RID: 32374 RVA: 0x001FCD3C File Offset: 0x001FAF3C
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Complex.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06007E77 RID: 32375 RVA: 0x001FCDB0 File Offset: 0x001FAFB0
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Complex.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E78 RID: 32376 RVA: 0x001FCE0C File Offset: 0x001FB00C
		[CallerCount(0)]
		public unsafe bool IsReal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_IsReal_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E79 RID: 32377 RVA: 0x001FCE5C File Offset: 0x001FB05C
		[CallerCount(0)]
		public unsafe bool IsImaginary()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Complex.NativeMethodInfoPtr_IsImaginary_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06007E7A RID: 32378 RVA: 0x001FCEAC File Offset: 0x001FB0AC
		// Note: this type is marked as 'beforefieldinit'.
		static Complex()
		{
			Il2CppClassPointerStore<Complex>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "CSML", "Complex");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Complex>.NativeClassPtr);
			Complex.NativeFieldInfoPtr_re = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Complex>.NativeClassPtr, "re");
			Complex.NativeFieldInfoPtr_im = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Complex>.NativeClassPtr, "im");
			Complex.NativeMethodInfoPtr_get_Re_Public_get_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673354);
			Complex.NativeMethodInfoPtr_set_Re_Public_set_Void_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673355);
			Complex.NativeMethodInfoPtr_get_Im_Public_get_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673356);
			Complex.NativeMethodInfoPtr_set_Im_Public_set_Void_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673357);
			Complex.NativeMethodInfoPtr_get_I_Public_Static_get_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673358);
			Complex.NativeMethodInfoPtr_get_Zero_Public_Static_get_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673359);
			Complex.NativeMethodInfoPtr_get_One_Public_Static_get_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673360);
			Complex.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673361);
			Complex.NativeMethodInfoPtr__ctor_Public_Void_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673362);
			Complex.NativeMethodInfoPtr__ctor_Public_Void_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673363);
			Complex.NativeMethodInfoPtr__ctor_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673364);
			Complex.NativeMethodInfoPtr_Test_Public_Static_Match_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673365);
			Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673366);
			Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673367);
			Complex.NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673368);
			Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673369);
			Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673370);
			Complex.NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673371);
			Complex.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673372);
			Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673373);
			Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673374);
			Complex.NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673375);
			Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673376);
			Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673377);
			Complex.NativeMethodInfoPtr_op_Division_Public_Static_Complex_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673378);
			Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673379);
			Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673380);
			Complex.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673381);
			Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673382);
			Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673383);
			Complex.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673384);
			Complex.NativeMethodInfoPtr_Abs_Public_Static_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673385);
			Complex.NativeMethodInfoPtr_Inv_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673386);
			Complex.NativeMethodInfoPtr_Tan_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673387);
			Complex.NativeMethodInfoPtr_Cosh_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673388);
			Complex.NativeMethodInfoPtr_Sinh_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673389);
			Complex.NativeMethodInfoPtr_Tanh_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673390);
			Complex.NativeMethodInfoPtr_Coth_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673391);
			Complex.NativeMethodInfoPtr_Sech_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673392);
			Complex.NativeMethodInfoPtr_Csch_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673393);
			Complex.NativeMethodInfoPtr_Cot_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673394);
			Complex.NativeMethodInfoPtr_Conj_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673395);
			Complex.NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673396);
			Complex.NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673397);
			Complex.NativeMethodInfoPtr_Exp_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673398);
			Complex.NativeMethodInfoPtr_Log_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673399);
			Complex.NativeMethodInfoPtr_Arg_Public_Static_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673400);
			Complex.NativeMethodInfoPtr_Cos_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673401);
			Complex.NativeMethodInfoPtr_Sin_Public_Static_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673402);
			Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673403);
			Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Double_Complex_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673404);
			Complex.NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673405);
			Complex.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673406);
			Complex.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673407);
			Complex.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673408);
			Complex.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673409);
			Complex.NativeMethodInfoPtr_IsReal_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673410);
			Complex.NativeMethodInfoPtr_IsImaginary_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Complex>.NativeClassPtr, 100673411);
		}

		// Token: 0x06007E7B RID: 32379 RVA: 0x00002988 File Offset: 0x00000B88
		public Complex(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002D5F RID: 11615
		// (get) Token: 0x06007E7C RID: 32380 RVA: 0x001FD38C File Offset: 0x001FB58C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Complex>.NativeClassPtr));
			}
		}

		// Token: 0x17002D60 RID: 11616
		// (get) Token: 0x06007E7D RID: 32381 RVA: 0x001FD3A0 File Offset: 0x001FB5A0
		// (set) Token: 0x06007E7E RID: 32382 RVA: 0x001FD3C8 File Offset: 0x001FB5C8
		public unsafe double re
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Complex.NativeFieldInfoPtr_re);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Complex.NativeFieldInfoPtr_re)) = value;
			}
		}

		// Token: 0x17002D61 RID: 11617
		// (get) Token: 0x06007E7F RID: 32383 RVA: 0x001FD3EC File Offset: 0x001FB5EC
		// (set) Token: 0x06007E80 RID: 32384 RVA: 0x001FD414 File Offset: 0x001FB614
		public unsafe double im
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Complex.NativeFieldInfoPtr_im);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Complex.NativeFieldInfoPtr_im)) = value;
			}
		}

		// Token: 0x040050B1 RID: 20657
		private static readonly IntPtr NativeFieldInfoPtr_re;

		// Token: 0x040050B2 RID: 20658
		private static readonly IntPtr NativeFieldInfoPtr_im;

		// Token: 0x040050B3 RID: 20659
		private static readonly IntPtr NativeMethodInfoPtr_get_Re_Public_get_Double_0;

		// Token: 0x040050B4 RID: 20660
		private static readonly IntPtr NativeMethodInfoPtr_set_Re_Public_set_Void_Double_0;

		// Token: 0x040050B5 RID: 20661
		private static readonly IntPtr NativeMethodInfoPtr_get_Im_Public_get_Double_0;

		// Token: 0x040050B6 RID: 20662
		private static readonly IntPtr NativeMethodInfoPtr_set_Im_Public_set_Void_Double_0;

		// Token: 0x040050B7 RID: 20663
		private static readonly IntPtr NativeMethodInfoPtr_get_I_Public_Static_get_Complex_0;

		// Token: 0x040050B8 RID: 20664
		private static readonly IntPtr NativeMethodInfoPtr_get_Zero_Public_Static_get_Complex_0;

		// Token: 0x040050B9 RID: 20665
		private static readonly IntPtr NativeMethodInfoPtr_get_One_Public_Static_get_Complex_0;

		// Token: 0x040050BA RID: 20666
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x040050BB RID: 20667
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Double_0;

		// Token: 0x040050BC RID: 20668
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Double_Double_0;

		// Token: 0x040050BD RID: 20669
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_0;

		// Token: 0x040050BE RID: 20670
		private static readonly IntPtr NativeMethodInfoPtr_Test_Public_Static_Match_String_0;

		// Token: 0x040050BF RID: 20671
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Complex_0;

		// Token: 0x040050C0 RID: 20672
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Complex_Double_0;

		// Token: 0x040050C1 RID: 20673
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_Complex_Double_Complex_0;

		// Token: 0x040050C2 RID: 20674
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Complex_0;

		// Token: 0x040050C3 RID: 20675
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Complex_Double_0;

		// Token: 0x040050C4 RID: 20676
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_Complex_Double_Complex_0;

		// Token: 0x040050C5 RID: 20677
		private static readonly IntPtr NativeMethodInfoPtr_op_UnaryNegation_Public_Static_Complex_Complex_0;

		// Token: 0x040050C6 RID: 20678
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Complex_0;

		// Token: 0x040050C7 RID: 20679
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Complex_Double_0;

		// Token: 0x040050C8 RID: 20680
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_Complex_Double_Complex_0;

		// Token: 0x040050C9 RID: 20681
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Complex_0;

		// Token: 0x040050CA RID: 20682
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_Complex_Complex_Double_0;

		// Token: 0x040050CB RID: 20683
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_Complex_Double_Complex_0;

		// Token: 0x040050CC RID: 20684
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Complex_0;

		// Token: 0x040050CD RID: 20685
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Complex_Double_0;

		// Token: 0x040050CE RID: 20686
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Double_Complex_0;

		// Token: 0x040050CF RID: 20687
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Complex_0;

		// Token: 0x040050D0 RID: 20688
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Complex_Double_0;

		// Token: 0x040050D1 RID: 20689
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Double_Complex_0;

		// Token: 0x040050D2 RID: 20690
		private static readonly IntPtr NativeMethodInfoPtr_Abs_Public_Static_Double_Complex_0;

		// Token: 0x040050D3 RID: 20691
		private static readonly IntPtr NativeMethodInfoPtr_Inv_Public_Static_Complex_Complex_0;

		// Token: 0x040050D4 RID: 20692
		private static readonly IntPtr NativeMethodInfoPtr_Tan_Public_Static_Complex_Complex_0;

		// Token: 0x040050D5 RID: 20693
		private static readonly IntPtr NativeMethodInfoPtr_Cosh_Public_Static_Complex_Complex_0;

		// Token: 0x040050D6 RID: 20694
		private static readonly IntPtr NativeMethodInfoPtr_Sinh_Public_Static_Complex_Complex_0;

		// Token: 0x040050D7 RID: 20695
		private static readonly IntPtr NativeMethodInfoPtr_Tanh_Public_Static_Complex_Complex_0;

		// Token: 0x040050D8 RID: 20696
		private static readonly IntPtr NativeMethodInfoPtr_Coth_Public_Static_Complex_Complex_0;

		// Token: 0x040050D9 RID: 20697
		private static readonly IntPtr NativeMethodInfoPtr_Sech_Public_Static_Complex_Complex_0;

		// Token: 0x040050DA RID: 20698
		private static readonly IntPtr NativeMethodInfoPtr_Csch_Public_Static_Complex_Complex_0;

		// Token: 0x040050DB RID: 20699
		private static readonly IntPtr NativeMethodInfoPtr_Cot_Public_Static_Complex_Complex_0;

		// Token: 0x040050DC RID: 20700
		private static readonly IntPtr NativeMethodInfoPtr_Conj_Public_Static_Complex_Complex_0;

		// Token: 0x040050DD RID: 20701
		private static readonly IntPtr NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Double_0;

		// Token: 0x040050DE RID: 20702
		private static readonly IntPtr NativeMethodInfoPtr_Sqrt_Public_Static_Complex_Complex_0;

		// Token: 0x040050DF RID: 20703
		private static readonly IntPtr NativeMethodInfoPtr_Exp_Public_Static_Complex_Complex_0;

		// Token: 0x040050E0 RID: 20704
		private static readonly IntPtr NativeMethodInfoPtr_Log_Public_Static_Complex_Complex_0;

		// Token: 0x040050E1 RID: 20705
		private static readonly IntPtr NativeMethodInfoPtr_Arg_Public_Static_Double_Complex_0;

		// Token: 0x040050E2 RID: 20706
		private static readonly IntPtr NativeMethodInfoPtr_Cos_Public_Static_Complex_Complex_0;

		// Token: 0x040050E3 RID: 20707
		private static readonly IntPtr NativeMethodInfoPtr_Sin_Public_Static_Complex_Complex_0;

		// Token: 0x040050E4 RID: 20708
		private static readonly IntPtr NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Complex_0;

		// Token: 0x040050E5 RID: 20709
		private static readonly IntPtr NativeMethodInfoPtr_Pow_Public_Static_Complex_Double_Complex_0;

		// Token: 0x040050E6 RID: 20710
		private static readonly IntPtr NativeMethodInfoPtr_Pow_Public_Static_Complex_Complex_Double_0;

		// Token: 0x040050E7 RID: 20711
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040050E8 RID: 20712
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040050E9 RID: 20713
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040050EA RID: 20714
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040050EB RID: 20715
		private static readonly IntPtr NativeMethodInfoPtr_IsReal_Public_Boolean_0;

		// Token: 0x040050EC RID: 20716
		private static readonly IntPtr NativeMethodInfoPtr_IsImaginary_Public_Boolean_0;
	}
}
