﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003EA RID: 1002
public class ConfirmFlasher : MonoBehaviour
{
	// Token: 0x06004EAD RID: 20141 RVA: 0x0013B548 File Offset: 0x00139748
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher.NativeMethodInfoPtr_OnEnable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004EAE RID: 20142 RVA: 0x0013B58C File Offset: 0x0013978C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher.NativeMethodInfoPtr_OnDisable_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004EAF RID: 20143 RVA: 0x0013B5D0 File Offset: 0x001397D0
	[CallerCount(0)]
	public unsafe void Stop()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher.NativeMethodInfoPtr_Stop_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004EB0 RID: 20144 RVA: 0x0013B614 File Offset: 0x00139814
	[CallerCount(0)]
	public unsafe IEnumerator FlashRoutine()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher.NativeMethodInfoPtr_FlashRoutine_Protected_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004EB1 RID: 20145 RVA: 0x0013B66C File Offset: 0x0013986C
	[CallerCount(0)]
	public unsafe ConfirmFlasher() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004EB2 RID: 20146 RVA: 0x0013B6B8 File Offset: 0x001398B8
	// Note: this type is marked as 'beforefieldinit'.
	static ConfirmFlasher()
	{
		Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConfirmFlasher");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr);
		ConfirmFlasher.NativeFieldInfoPtr_FlashLull = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "FlashLull");
		ConfirmFlasher.NativeFieldInfoPtr_OriginalColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "OriginalColor");
		ConfirmFlasher.NativeFieldInfoPtr_FlashColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "FlashColor");
		ConfirmFlasher.NativeFieldInfoPtr_Caption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "Caption");
		ConfirmFlasher.NativeFieldInfoPtr_AllowFlashing = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "AllowFlashing");
		ConfirmFlasher.NativeFieldInfoPtr_flashCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "flashCoroutine");
		ConfirmFlasher.NativeMethodInfoPtr_OnEnable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, 100669493);
		ConfirmFlasher.NativeMethodInfoPtr_OnDisable_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, 100669494);
		ConfirmFlasher.NativeMethodInfoPtr_Stop_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, 100669495);
		ConfirmFlasher.NativeMethodInfoPtr_FlashRoutine_Protected_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, 100669496);
		ConfirmFlasher.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, 100669497);
	}

	// Token: 0x06004EB3 RID: 20147 RVA: 0x0000210C File Offset: 0x0000030C
	public ConfirmFlasher(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001C1D RID: 7197
	// (get) Token: 0x06004EB4 RID: 20148 RVA: 0x0013B7C4 File Offset: 0x001399C4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr));
		}
	}

	// Token: 0x17001C1E RID: 7198
	// (get) Token: 0x06004EB5 RID: 20149 RVA: 0x0013B7D8 File Offset: 0x001399D8
	// (set) Token: 0x06004EB6 RID: 20150 RVA: 0x0013B800 File Offset: 0x00139A00
	public unsafe float FlashLull
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_FlashLull);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_FlashLull)) = value;
		}
	}

	// Token: 0x17001C1F RID: 7199
	// (get) Token: 0x06004EB7 RID: 20151 RVA: 0x0013B824 File Offset: 0x00139A24
	// (set) Token: 0x06004EB8 RID: 20152 RVA: 0x0013B84C File Offset: 0x00139A4C
	public unsafe Color OriginalColor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_OriginalColor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_OriginalColor)) = value;
		}
	}

	// Token: 0x17001C20 RID: 7200
	// (get) Token: 0x06004EB9 RID: 20153 RVA: 0x0013B870 File Offset: 0x00139A70
	// (set) Token: 0x06004EBA RID: 20154 RVA: 0x0013B898 File Offset: 0x00139A98
	public unsafe Color FlashColor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_FlashColor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_FlashColor)) = value;
		}
	}

	// Token: 0x17001C21 RID: 7201
	// (get) Token: 0x06004EBB RID: 20155 RVA: 0x0013B8BC File Offset: 0x00139ABC
	// (set) Token: 0x06004EBC RID: 20156 RVA: 0x0013B8F0 File Offset: 0x00139AF0
	public unsafe TextMeshProUGUI Caption
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_Caption);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_Caption), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C22 RID: 7202
	// (get) Token: 0x06004EBD RID: 20157 RVA: 0x0013B918 File Offset: 0x00139B18
	// (set) Token: 0x06004EBE RID: 20158 RVA: 0x0013B940 File Offset: 0x00139B40
	public unsafe bool AllowFlashing
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_AllowFlashing);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_AllowFlashing)) = value;
		}
	}

	// Token: 0x17001C23 RID: 7203
	// (get) Token: 0x06004EBF RID: 20159 RVA: 0x0013B964 File Offset: 0x00139B64
	// (set) Token: 0x06004EC0 RID: 20160 RVA: 0x0013B998 File Offset: 0x00139B98
	public unsafe Coroutine flashCoroutine
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_flashCoroutine);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher.NativeFieldInfoPtr_flashCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040031F3 RID: 12787
	private static readonly IntPtr NativeFieldInfoPtr_FlashLull;

	// Token: 0x040031F4 RID: 12788
	private static readonly IntPtr NativeFieldInfoPtr_OriginalColor;

	// Token: 0x040031F5 RID: 12789
	private static readonly IntPtr NativeFieldInfoPtr_FlashColor;

	// Token: 0x040031F6 RID: 12790
	private static readonly IntPtr NativeFieldInfoPtr_Caption;

	// Token: 0x040031F7 RID: 12791
	private static readonly IntPtr NativeFieldInfoPtr_AllowFlashing;

	// Token: 0x040031F8 RID: 12792
	private static readonly IntPtr NativeFieldInfoPtr_flashCoroutine;

	// Token: 0x040031F9 RID: 12793
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Void_0;

	// Token: 0x040031FA RID: 12794
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Protected_Void_0;

	// Token: 0x040031FB RID: 12795
	private static readonly IntPtr NativeMethodInfoPtr_Stop_Protected_Void_0;

	// Token: 0x040031FC RID: 12796
	private static readonly IntPtr NativeMethodInfoPtr_FlashRoutine_Protected_IEnumerator_0;

	// Token: 0x040031FD RID: 12797
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003EB RID: 1003
	[ObfuscatedName("ConfirmFlasher/<FlashRoutine>d__9")]
	public sealed class _FlashRoutine_d__9 : Il2CppSystem.Object
	{
		// Token: 0x06004EC1 RID: 20161 RVA: 0x0013B9C0 File Offset: 0x00139BC0
		[CallerCount(0)]
		public unsafe _FlashRoutine_d__9(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004EC2 RID: 20162 RVA: 0x0013BA20 File Offset: 0x00139C20
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004EC3 RID: 20163 RVA: 0x0013BA64 File Offset: 0x00139C64
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001C28 RID: 7208
		// (get) Token: 0x06004EC4 RID: 20164 RVA: 0x0013BAB4 File Offset: 0x00139CB4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004EC5 RID: 20165 RVA: 0x0013BB0C File Offset: 0x00139D0C
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001C29 RID: 7209
		// (get) Token: 0x06004EC6 RID: 20166 RVA: 0x0013BB50 File Offset: 0x00139D50
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004EC7 RID: 20167 RVA: 0x0013BBA8 File Offset: 0x00139DA8
		// Note: this type is marked as 'beforefieldinit'.
		static _FlashRoutine_d__9()
		{
			Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ConfirmFlasher>.NativeClassPtr, "<FlashRoutine>d__9");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr);
			ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, "<>1__state");
			ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, "<>2__current");
			ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, "<>4__this");
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669498);
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669499);
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669500);
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669501);
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669502);
			ConfirmFlasher._FlashRoutine_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr, 100669503);
		}

		// Token: 0x06004EC8 RID: 20168 RVA: 0x00002988 File Offset: 0x00000B88
		public _FlashRoutine_d__9(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C24 RID: 7204
		// (get) Token: 0x06004EC9 RID: 20169 RVA: 0x0013BC87 File Offset: 0x00139E87
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConfirmFlasher._FlashRoutine_d__9>.NativeClassPtr));
			}
		}

		// Token: 0x17001C25 RID: 7205
		// (get) Token: 0x06004ECA RID: 20170 RVA: 0x0013BC98 File Offset: 0x00139E98
		// (set) Token: 0x06004ECB RID: 20171 RVA: 0x0013BCC0 File Offset: 0x00139EC0
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C26 RID: 7206
		// (get) Token: 0x06004ECC RID: 20172 RVA: 0x0013BCE4 File Offset: 0x00139EE4
		// (set) Token: 0x06004ECD RID: 20173 RVA: 0x0013BD18 File Offset: 0x00139F18
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C27 RID: 7207
		// (get) Token: 0x06004ECE RID: 20174 RVA: 0x0013BD40 File Offset: 0x00139F40
		// (set) Token: 0x06004ECF RID: 20175 RVA: 0x0013BD74 File Offset: 0x00139F74
		public unsafe ConfirmFlasher __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ConfirmFlasher(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConfirmFlasher._FlashRoutine_d__9.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040031FE RID: 12798
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040031FF RID: 12799
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04003200 RID: 12800
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04003201 RID: 12801
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04003202 RID: 12802
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003203 RID: 12803
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04003204 RID: 12804
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04003205 RID: 12805
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003206 RID: 12806
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
