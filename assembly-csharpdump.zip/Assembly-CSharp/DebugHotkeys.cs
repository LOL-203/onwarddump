﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200019D RID: 413
public class DebugHotkeys : MonoBehaviour
{
	// Token: 0x06001C06 RID: 7174 RVA: 0x00070270 File Offset: 0x0006E470
	[CallerCount(0)]
	public unsafe static bool GetKeyQAOrEditor([In] ref KeyCode key, [In] [Optional] ref KeyCode modifier)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &key;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &modifier;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DebugHotkeys.NativeMethodInfoPtr_GetKeyQAOrEditor_Public_Static_Boolean_byref_KeyCode_byref_KeyCode_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001C07 RID: 7175 RVA: 0x000702D8 File Offset: 0x0006E4D8
	[CallerCount(0)]
	public unsafe static bool GetKey(KeyCode key)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref key;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DebugHotkeys.NativeMethodInfoPtr_GetKey_Public_Static_Boolean_KeyCode_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001C08 RID: 7176 RVA: 0x0007032C File Offset: 0x0006E52C
	[CallerCount(0)]
	public unsafe static bool GetKeyUp(KeyCode key)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref key;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DebugHotkeys.NativeMethodInfoPtr_GetKeyUp_Public_Static_Boolean_KeyCode_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001C09 RID: 7177 RVA: 0x00070380 File Offset: 0x0006E580
	[CallerCount(0)]
	public unsafe DebugHotkeys() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DebugHotkeys.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001C0A RID: 7178 RVA: 0x000703CC File Offset: 0x0006E5CC
	// Note: this type is marked as 'beforefieldinit'.
	static DebugHotkeys()
	{
		Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DebugHotkeys");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr);
		DebugHotkeys.NativeFieldInfoPtr_DebugSituation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "DebugSituation");
		DebugHotkeys.NativeFieldInfoPtr_JoinQuarantine1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinQuarantine1");
		DebugHotkeys.NativeFieldInfoPtr_JoinDownfall3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinDownfall3");
		DebugHotkeys.NativeFieldInfoPtr_JoinTanker = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinTanker");
		DebugHotkeys.NativeFieldInfoPtr_JoinSubway = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinSubway");
		DebugHotkeys.NativeFieldInfoPtr_JoinSuburbia = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinSuburbia");
		DebugHotkeys.NativeFieldInfoPtr_JoinBazaar = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinBazaar");
		DebugHotkeys.NativeFieldInfoPtr_JoinAbandoned = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinAbandoned");
		DebugHotkeys.NativeFieldInfoPtr_JoinJungle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinJungle");
		DebugHotkeys.NativeFieldInfoPtr_JoinInventory = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinInventory");
		DebugHotkeys.NativeFieldInfoPtr_JoinCargo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinCargo");
		DebugHotkeys.NativeFieldInfoPtr_JoinTurbine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinTurbine");
		DebugHotkeys.NativeFieldInfoPtr_JoinSnowpeak = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinSnowpeak");
		DebugHotkeys.NativeFieldInfoPtr_JoinTestMPPerfMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinTestMPPerfMap");
		DebugHotkeys.NativeFieldInfoPtr_JoinNewEmptyScene = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinNewEmptyScene");
		DebugHotkeys.NativeFieldInfoPtr_Snapshot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Snapshot");
		DebugHotkeys.NativeFieldInfoPtr_Diff = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Diff");
		DebugHotkeys.NativeFieldInfoPtr_RefreshLoadout = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "RefreshLoadout");
		DebugHotkeys.NativeFieldInfoPtr_FreeRoam = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "FreeRoam");
		DebugHotkeys.NativeFieldInfoPtr_Operations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Operations");
		DebugHotkeys.NativeFieldInfoPtr_FireFight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "FireFight");
		DebugHotkeys.NativeFieldInfoPtr_UplinkAssault = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "UplinkAssault");
		DebugHotkeys.NativeFieldInfoPtr_Escort = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Escort");
		DebugHotkeys.NativeFieldInfoPtr_Uplink = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Uplink");
		DebugHotkeys.NativeFieldInfoPtr_ShootingRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "ShootingRange");
		DebugHotkeys.NativeFieldInfoPtr_SpecOps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "SpecOps");
		DebugHotkeys.NativeFieldInfoPtr_GunGame = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "GunGame");
		DebugHotkeys.NativeFieldInfoPtr_OneInTheChamber = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "OneInTheChamber");
		DebugHotkeys.NativeFieldInfoPtr_Spectating = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Spectating");
		DebugHotkeys.NativeFieldInfoPtr_Competitive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Competitive");
		DebugHotkeys.NativeFieldInfoPtr_CargoSoloAsObserver = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "CargoSoloAsObserver");
		DebugHotkeys.NativeFieldInfoPtr_DownfallAsObserver = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "DownfallAsObserver");
		DebugHotkeys.NativeFieldInfoPtr_JoinCustomContent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinCustomContent");
		DebugHotkeys.NativeFieldInfoPtr_JoinHandTesting = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinHandTesting");
		DebugHotkeys.NativeFieldInfoPtr_JoinTeamMarsoc = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinTeamMarsoc");
		DebugHotkeys.NativeFieldInfoPtr_JoinTeamVolk = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "JoinTeamVolk");
		DebugHotkeys.NativeFieldInfoPtr_logCustomProps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "logCustomProps");
		DebugHotkeys.NativeFieldInfoPtr_toggleInvincibility = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleInvincibility");
		DebugHotkeys.NativeFieldInfoPtr_enableInfiniteAmmo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "enableInfiniteAmmo");
		DebugHotkeys.NativeFieldInfoPtr_toggleStandardSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleStandardSpeed");
		DebugHotkeys.NativeFieldInfoPtr_showAllOnTabletMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "showAllOnTabletMap");
		DebugHotkeys.NativeFieldInfoPtr_toggleTargetability = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleTargetability");
		DebugHotkeys.NativeFieldInfoPtr_inflictDamageToSelf = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "inflictDamageToSelf");
		DebugHotkeys.NativeFieldInfoPtr_toggleMirroredDamage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleMirroredDamage");
		DebugHotkeys.NativeFieldInfoPtr_makeAIInvincible = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "makeAIInvincible");
		DebugHotkeys.NativeFieldInfoPtr_aiWhistle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "aiWhistle");
		DebugHotkeys.NativeFieldInfoPtr_addInfractionToSelf = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "addInfractionToSelf");
		DebugHotkeys.NativeFieldInfoPtr_toggleTeamChat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleTeamChat");
		DebugHotkeys.NativeFieldInfoPtr_forcibleRefreshRadioChannels = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "forcibleRefreshRadioChannels");
		DebugHotkeys.NativeFieldInfoPtr_toggleRadio = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "toggleRadio");
		DebugHotkeys.NativeFieldInfoPtr_roundReset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "roundReset");
		DebugHotkeys.NativeFieldInfoPtr_crashAbort = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "crashAbort");
		DebugHotkeys.NativeFieldInfoPtr_crashAccessViolation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "crashAccessViolation");
		DebugHotkeys.NativeFieldInfoPtr_crashFatalError = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "crashFatalError");
		DebugHotkeys.NativeFieldInfoPtr_crashPureVirtualFunction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "crashPureVirtualFunction");
		DebugHotkeys.NativeFieldInfoPtr_flashBang = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "flashBang");
		DebugHotkeys.NativeFieldInfoPtr_suppression = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "suppression");
		DebugHotkeys.NativeFieldInfoPtr_heal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "heal");
		DebugHotkeys.NativeFieldInfoPtr_Hurt = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Hurt");
		DebugHotkeys.NativeFieldInfoPtr_Downed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Downed");
		DebugHotkeys.NativeFieldInfoPtr_Dead = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Dead");
		DebugHotkeys.NativeFieldInfoPtr_DeathFade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "DeathFade");
		DebugHotkeys.NativeFieldInfoPtr_Suppressed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "Suppressed");
		DebugHotkeys.NativeFieldInfoPtr_SuppressedTracer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "SuppressedTracer");
		DebugHotkeys.NativeFieldInfoPtr_SuppressedGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "SuppressedGrenade");
		DebugHotkeys.NativeFieldInfoPtr_UnderWater = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "UnderWater");
		DebugHotkeys.NativeFieldInfoPtr_PrintScreenEffects = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, "PrintScreenEffects");
		DebugHotkeys.NativeMethodInfoPtr_GetKeyQAOrEditor_Public_Static_Boolean_byref_KeyCode_byref_KeyCode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, 100665529);
		DebugHotkeys.NativeMethodInfoPtr_GetKey_Public_Static_Boolean_KeyCode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, 100665530);
		DebugHotkeys.NativeMethodInfoPtr_GetKeyUp_Public_Static_Boolean_KeyCode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, 100665531);
		DebugHotkeys.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr, 100665532);
	}

	// Token: 0x06001C0B RID: 7179 RVA: 0x0000210C File Offset: 0x0000030C
	public DebugHotkeys(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170009B8 RID: 2488
	// (get) Token: 0x06001C0C RID: 7180 RVA: 0x00070988 File Offset: 0x0006EB88
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DebugHotkeys>.NativeClassPtr));
		}
	}

	// Token: 0x170009B9 RID: 2489
	// (get) Token: 0x06001C0D RID: 7181 RVA: 0x0007099C File Offset: 0x0006EB9C
	// (set) Token: 0x06001C0E RID: 7182 RVA: 0x000709BA File Offset: 0x0006EBBA
	public unsafe static KeyCode DebugSituation
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_DebugSituation, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_DebugSituation, (void*)(&value));
		}
	}

	// Token: 0x170009BA RID: 2490
	// (get) Token: 0x06001C0F RID: 7183 RVA: 0x000709CC File Offset: 0x0006EBCC
	// (set) Token: 0x06001C10 RID: 7184 RVA: 0x000709EA File Offset: 0x0006EBEA
	public unsafe static KeyCode JoinQuarantine1
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinQuarantine1, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinQuarantine1, (void*)(&value));
		}
	}

	// Token: 0x170009BB RID: 2491
	// (get) Token: 0x06001C11 RID: 7185 RVA: 0x000709FC File Offset: 0x0006EBFC
	// (set) Token: 0x06001C12 RID: 7186 RVA: 0x00070A1A File Offset: 0x0006EC1A
	public unsafe static KeyCode JoinDownfall3
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinDownfall3, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinDownfall3, (void*)(&value));
		}
	}

	// Token: 0x170009BC RID: 2492
	// (get) Token: 0x06001C13 RID: 7187 RVA: 0x00070A2C File Offset: 0x0006EC2C
	// (set) Token: 0x06001C14 RID: 7188 RVA: 0x00070A4A File Offset: 0x0006EC4A
	public unsafe static KeyCode JoinTanker
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinTanker, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinTanker, (void*)(&value));
		}
	}

	// Token: 0x170009BD RID: 2493
	// (get) Token: 0x06001C15 RID: 7189 RVA: 0x00070A5C File Offset: 0x0006EC5C
	// (set) Token: 0x06001C16 RID: 7190 RVA: 0x00070A7A File Offset: 0x0006EC7A
	public unsafe static KeyCode JoinSubway
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinSubway, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinSubway, (void*)(&value));
		}
	}

	// Token: 0x170009BE RID: 2494
	// (get) Token: 0x06001C17 RID: 7191 RVA: 0x00070A8C File Offset: 0x0006EC8C
	// (set) Token: 0x06001C18 RID: 7192 RVA: 0x00070AAA File Offset: 0x0006ECAA
	public unsafe static KeyCode JoinSuburbia
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinSuburbia, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinSuburbia, (void*)(&value));
		}
	}

	// Token: 0x170009BF RID: 2495
	// (get) Token: 0x06001C19 RID: 7193 RVA: 0x00070ABC File Offset: 0x0006ECBC
	// (set) Token: 0x06001C1A RID: 7194 RVA: 0x00070ADA File Offset: 0x0006ECDA
	public unsafe static KeyCode JoinBazaar
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinBazaar, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinBazaar, (void*)(&value));
		}
	}

	// Token: 0x170009C0 RID: 2496
	// (get) Token: 0x06001C1B RID: 7195 RVA: 0x00070AEC File Offset: 0x0006ECEC
	// (set) Token: 0x06001C1C RID: 7196 RVA: 0x00070B0A File Offset: 0x0006ED0A
	public unsafe static KeyCode JoinAbandoned
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinAbandoned, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinAbandoned, (void*)(&value));
		}
	}

	// Token: 0x170009C1 RID: 2497
	// (get) Token: 0x06001C1D RID: 7197 RVA: 0x00070B1C File Offset: 0x0006ED1C
	// (set) Token: 0x06001C1E RID: 7198 RVA: 0x00070B3A File Offset: 0x0006ED3A
	public unsafe static KeyCode JoinJungle
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinJungle, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinJungle, (void*)(&value));
		}
	}

	// Token: 0x170009C2 RID: 2498
	// (get) Token: 0x06001C1F RID: 7199 RVA: 0x00070B4C File Offset: 0x0006ED4C
	// (set) Token: 0x06001C20 RID: 7200 RVA: 0x00070B6A File Offset: 0x0006ED6A
	public unsafe static KeyCode JoinInventory
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinInventory, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinInventory, (void*)(&value));
		}
	}

	// Token: 0x170009C3 RID: 2499
	// (get) Token: 0x06001C21 RID: 7201 RVA: 0x00070B7C File Offset: 0x0006ED7C
	// (set) Token: 0x06001C22 RID: 7202 RVA: 0x00070B9A File Offset: 0x0006ED9A
	public unsafe static KeyCode JoinCargo
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinCargo, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinCargo, (void*)(&value));
		}
	}

	// Token: 0x170009C4 RID: 2500
	// (get) Token: 0x06001C23 RID: 7203 RVA: 0x00070BAC File Offset: 0x0006EDAC
	// (set) Token: 0x06001C24 RID: 7204 RVA: 0x00070BCA File Offset: 0x0006EDCA
	public unsafe static KeyCode JoinTurbine
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinTurbine, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinTurbine, (void*)(&value));
		}
	}

	// Token: 0x170009C5 RID: 2501
	// (get) Token: 0x06001C25 RID: 7205 RVA: 0x00070BDC File Offset: 0x0006EDDC
	// (set) Token: 0x06001C26 RID: 7206 RVA: 0x00070BFA File Offset: 0x0006EDFA
	public unsafe static KeyCode JoinSnowpeak
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinSnowpeak, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinSnowpeak, (void*)(&value));
		}
	}

	// Token: 0x170009C6 RID: 2502
	// (get) Token: 0x06001C27 RID: 7207 RVA: 0x00070C0C File Offset: 0x0006EE0C
	// (set) Token: 0x06001C28 RID: 7208 RVA: 0x00070C2A File Offset: 0x0006EE2A
	public unsafe static KeyCode JoinTestMPPerfMap
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinTestMPPerfMap, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinTestMPPerfMap, (void*)(&value));
		}
	}

	// Token: 0x170009C7 RID: 2503
	// (get) Token: 0x06001C29 RID: 7209 RVA: 0x00070C3C File Offset: 0x0006EE3C
	// (set) Token: 0x06001C2A RID: 7210 RVA: 0x00070C5A File Offset: 0x0006EE5A
	public unsafe static KeyCode JoinNewEmptyScene
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinNewEmptyScene, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinNewEmptyScene, (void*)(&value));
		}
	}

	// Token: 0x170009C8 RID: 2504
	// (get) Token: 0x06001C2B RID: 7211 RVA: 0x00070C6C File Offset: 0x0006EE6C
	// (set) Token: 0x06001C2C RID: 7212 RVA: 0x00070C8A File Offset: 0x0006EE8A
	public unsafe static KeyCode Snapshot
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Snapshot, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Snapshot, (void*)(&value));
		}
	}

	// Token: 0x170009C9 RID: 2505
	// (get) Token: 0x06001C2D RID: 7213 RVA: 0x00070C9C File Offset: 0x0006EE9C
	// (set) Token: 0x06001C2E RID: 7214 RVA: 0x00070CBA File Offset: 0x0006EEBA
	public unsafe static KeyCode Diff
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Diff, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Diff, (void*)(&value));
		}
	}

	// Token: 0x170009CA RID: 2506
	// (get) Token: 0x06001C2F RID: 7215 RVA: 0x00070CCC File Offset: 0x0006EECC
	// (set) Token: 0x06001C30 RID: 7216 RVA: 0x00070CEA File Offset: 0x0006EEEA
	public unsafe static KeyCode RefreshLoadout
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_RefreshLoadout, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_RefreshLoadout, (void*)(&value));
		}
	}

	// Token: 0x170009CB RID: 2507
	// (get) Token: 0x06001C31 RID: 7217 RVA: 0x00070CFC File Offset: 0x0006EEFC
	// (set) Token: 0x06001C32 RID: 7218 RVA: 0x00070D1A File Offset: 0x0006EF1A
	public unsafe static KeyCode FreeRoam
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_FreeRoam, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_FreeRoam, (void*)(&value));
		}
	}

	// Token: 0x170009CC RID: 2508
	// (get) Token: 0x06001C33 RID: 7219 RVA: 0x00070D2C File Offset: 0x0006EF2C
	// (set) Token: 0x06001C34 RID: 7220 RVA: 0x00070D4A File Offset: 0x0006EF4A
	public unsafe static KeyCode Operations
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Operations, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Operations, (void*)(&value));
		}
	}

	// Token: 0x170009CD RID: 2509
	// (get) Token: 0x06001C35 RID: 7221 RVA: 0x00070D5C File Offset: 0x0006EF5C
	// (set) Token: 0x06001C36 RID: 7222 RVA: 0x00070D7A File Offset: 0x0006EF7A
	public unsafe static KeyCode FireFight
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_FireFight, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_FireFight, (void*)(&value));
		}
	}

	// Token: 0x170009CE RID: 2510
	// (get) Token: 0x06001C37 RID: 7223 RVA: 0x00070D8C File Offset: 0x0006EF8C
	// (set) Token: 0x06001C38 RID: 7224 RVA: 0x00070DAA File Offset: 0x0006EFAA
	public unsafe static KeyCode UplinkAssault
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_UplinkAssault, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_UplinkAssault, (void*)(&value));
		}
	}

	// Token: 0x170009CF RID: 2511
	// (get) Token: 0x06001C39 RID: 7225 RVA: 0x00070DBC File Offset: 0x0006EFBC
	// (set) Token: 0x06001C3A RID: 7226 RVA: 0x00070DDA File Offset: 0x0006EFDA
	public unsafe static KeyCode Escort
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Escort, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Escort, (void*)(&value));
		}
	}

	// Token: 0x170009D0 RID: 2512
	// (get) Token: 0x06001C3B RID: 7227 RVA: 0x00070DEC File Offset: 0x0006EFEC
	// (set) Token: 0x06001C3C RID: 7228 RVA: 0x00070E0A File Offset: 0x0006F00A
	public unsafe static KeyCode Uplink
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Uplink, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Uplink, (void*)(&value));
		}
	}

	// Token: 0x170009D1 RID: 2513
	// (get) Token: 0x06001C3D RID: 7229 RVA: 0x00070E1C File Offset: 0x0006F01C
	// (set) Token: 0x06001C3E RID: 7230 RVA: 0x00070E3A File Offset: 0x0006F03A
	public unsafe static KeyCode ShootingRange
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_ShootingRange, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_ShootingRange, (void*)(&value));
		}
	}

	// Token: 0x170009D2 RID: 2514
	// (get) Token: 0x06001C3F RID: 7231 RVA: 0x00070E4C File Offset: 0x0006F04C
	// (set) Token: 0x06001C40 RID: 7232 RVA: 0x00070E6A File Offset: 0x0006F06A
	public unsafe static KeyCode SpecOps
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_SpecOps, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_SpecOps, (void*)(&value));
		}
	}

	// Token: 0x170009D3 RID: 2515
	// (get) Token: 0x06001C41 RID: 7233 RVA: 0x00070E7C File Offset: 0x0006F07C
	// (set) Token: 0x06001C42 RID: 7234 RVA: 0x00070E9A File Offset: 0x0006F09A
	public unsafe static KeyCode GunGame
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_GunGame, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_GunGame, (void*)(&value));
		}
	}

	// Token: 0x170009D4 RID: 2516
	// (get) Token: 0x06001C43 RID: 7235 RVA: 0x00070EAC File Offset: 0x0006F0AC
	// (set) Token: 0x06001C44 RID: 7236 RVA: 0x00070ECA File Offset: 0x0006F0CA
	public unsafe static KeyCode OneInTheChamber
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_OneInTheChamber, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_OneInTheChamber, (void*)(&value));
		}
	}

	// Token: 0x170009D5 RID: 2517
	// (get) Token: 0x06001C45 RID: 7237 RVA: 0x00070EDC File Offset: 0x0006F0DC
	// (set) Token: 0x06001C46 RID: 7238 RVA: 0x00070EFA File Offset: 0x0006F0FA
	public unsafe static KeyCode Spectating
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Spectating, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Spectating, (void*)(&value));
		}
	}

	// Token: 0x170009D6 RID: 2518
	// (get) Token: 0x06001C47 RID: 7239 RVA: 0x00070F0C File Offset: 0x0006F10C
	// (set) Token: 0x06001C48 RID: 7240 RVA: 0x00070F2A File Offset: 0x0006F12A
	public unsafe static KeyCode Competitive
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Competitive, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Competitive, (void*)(&value));
		}
	}

	// Token: 0x170009D7 RID: 2519
	// (get) Token: 0x06001C49 RID: 7241 RVA: 0x00070F3C File Offset: 0x0006F13C
	// (set) Token: 0x06001C4A RID: 7242 RVA: 0x00070F5A File Offset: 0x0006F15A
	public unsafe static KeyCode CargoSoloAsObserver
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_CargoSoloAsObserver, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_CargoSoloAsObserver, (void*)(&value));
		}
	}

	// Token: 0x170009D8 RID: 2520
	// (get) Token: 0x06001C4B RID: 7243 RVA: 0x00070F6C File Offset: 0x0006F16C
	// (set) Token: 0x06001C4C RID: 7244 RVA: 0x00070F8A File Offset: 0x0006F18A
	public unsafe static KeyCode DownfallAsObserver
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_DownfallAsObserver, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_DownfallAsObserver, (void*)(&value));
		}
	}

	// Token: 0x170009D9 RID: 2521
	// (get) Token: 0x06001C4D RID: 7245 RVA: 0x00070F9C File Offset: 0x0006F19C
	// (set) Token: 0x06001C4E RID: 7246 RVA: 0x00070FBA File Offset: 0x0006F1BA
	public unsafe static KeyCode JoinCustomContent
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinCustomContent, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinCustomContent, (void*)(&value));
		}
	}

	// Token: 0x170009DA RID: 2522
	// (get) Token: 0x06001C4F RID: 7247 RVA: 0x00070FCC File Offset: 0x0006F1CC
	// (set) Token: 0x06001C50 RID: 7248 RVA: 0x00070FEA File Offset: 0x0006F1EA
	public unsafe static KeyCode JoinHandTesting
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinHandTesting, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinHandTesting, (void*)(&value));
		}
	}

	// Token: 0x170009DB RID: 2523
	// (get) Token: 0x06001C51 RID: 7249 RVA: 0x00070FFC File Offset: 0x0006F1FC
	// (set) Token: 0x06001C52 RID: 7250 RVA: 0x0007101A File Offset: 0x0006F21A
	public unsafe static KeyCode JoinTeamMarsoc
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinTeamMarsoc, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinTeamMarsoc, (void*)(&value));
		}
	}

	// Token: 0x170009DC RID: 2524
	// (get) Token: 0x06001C53 RID: 7251 RVA: 0x0007102C File Offset: 0x0006F22C
	// (set) Token: 0x06001C54 RID: 7252 RVA: 0x0007104A File Offset: 0x0006F24A
	public unsafe static KeyCode JoinTeamVolk
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_JoinTeamVolk, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_JoinTeamVolk, (void*)(&value));
		}
	}

	// Token: 0x170009DD RID: 2525
	// (get) Token: 0x06001C55 RID: 7253 RVA: 0x0007105C File Offset: 0x0006F25C
	// (set) Token: 0x06001C56 RID: 7254 RVA: 0x0007107A File Offset: 0x0006F27A
	public unsafe static KeyCode logCustomProps
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_logCustomProps, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_logCustomProps, (void*)(&value));
		}
	}

	// Token: 0x170009DE RID: 2526
	// (get) Token: 0x06001C57 RID: 7255 RVA: 0x0007108C File Offset: 0x0006F28C
	// (set) Token: 0x06001C58 RID: 7256 RVA: 0x000710AA File Offset: 0x0006F2AA
	public unsafe static KeyCode toggleInvincibility
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleInvincibility, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleInvincibility, (void*)(&value));
		}
	}

	// Token: 0x170009DF RID: 2527
	// (get) Token: 0x06001C59 RID: 7257 RVA: 0x000710BC File Offset: 0x0006F2BC
	// (set) Token: 0x06001C5A RID: 7258 RVA: 0x000710DA File Offset: 0x0006F2DA
	public unsafe static KeyCode enableInfiniteAmmo
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_enableInfiniteAmmo, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_enableInfiniteAmmo, (void*)(&value));
		}
	}

	// Token: 0x170009E0 RID: 2528
	// (get) Token: 0x06001C5B RID: 7259 RVA: 0x000710EC File Offset: 0x0006F2EC
	// (set) Token: 0x06001C5C RID: 7260 RVA: 0x0007110A File Offset: 0x0006F30A
	public unsafe static KeyCode toggleStandardSpeed
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleStandardSpeed, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleStandardSpeed, (void*)(&value));
		}
	}

	// Token: 0x170009E1 RID: 2529
	// (get) Token: 0x06001C5D RID: 7261 RVA: 0x0007111C File Offset: 0x0006F31C
	// (set) Token: 0x06001C5E RID: 7262 RVA: 0x0007113A File Offset: 0x0006F33A
	public unsafe static KeyCode showAllOnTabletMap
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_showAllOnTabletMap, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_showAllOnTabletMap, (void*)(&value));
		}
	}

	// Token: 0x170009E2 RID: 2530
	// (get) Token: 0x06001C5F RID: 7263 RVA: 0x0007114C File Offset: 0x0006F34C
	// (set) Token: 0x06001C60 RID: 7264 RVA: 0x0007116A File Offset: 0x0006F36A
	public unsafe static KeyCode toggleTargetability
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleTargetability, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleTargetability, (void*)(&value));
		}
	}

	// Token: 0x170009E3 RID: 2531
	// (get) Token: 0x06001C61 RID: 7265 RVA: 0x0007117C File Offset: 0x0006F37C
	// (set) Token: 0x06001C62 RID: 7266 RVA: 0x0007119A File Offset: 0x0006F39A
	public unsafe static KeyCode inflictDamageToSelf
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_inflictDamageToSelf, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_inflictDamageToSelf, (void*)(&value));
		}
	}

	// Token: 0x170009E4 RID: 2532
	// (get) Token: 0x06001C63 RID: 7267 RVA: 0x000711AC File Offset: 0x0006F3AC
	// (set) Token: 0x06001C64 RID: 7268 RVA: 0x000711CA File Offset: 0x0006F3CA
	public unsafe static KeyCode toggleMirroredDamage
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleMirroredDamage, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleMirroredDamage, (void*)(&value));
		}
	}

	// Token: 0x170009E5 RID: 2533
	// (get) Token: 0x06001C65 RID: 7269 RVA: 0x000711DC File Offset: 0x0006F3DC
	// (set) Token: 0x06001C66 RID: 7270 RVA: 0x000711FA File Offset: 0x0006F3FA
	public unsafe static KeyCode makeAIInvincible
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_makeAIInvincible, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_makeAIInvincible, (void*)(&value));
		}
	}

	// Token: 0x170009E6 RID: 2534
	// (get) Token: 0x06001C67 RID: 7271 RVA: 0x0007120C File Offset: 0x0006F40C
	// (set) Token: 0x06001C68 RID: 7272 RVA: 0x0007122A File Offset: 0x0006F42A
	public unsafe static KeyCode aiWhistle
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_aiWhistle, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_aiWhistle, (void*)(&value));
		}
	}

	// Token: 0x170009E7 RID: 2535
	// (get) Token: 0x06001C69 RID: 7273 RVA: 0x0007123C File Offset: 0x0006F43C
	// (set) Token: 0x06001C6A RID: 7274 RVA: 0x0007125A File Offset: 0x0006F45A
	public unsafe static KeyCode addInfractionToSelf
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_addInfractionToSelf, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_addInfractionToSelf, (void*)(&value));
		}
	}

	// Token: 0x170009E8 RID: 2536
	// (get) Token: 0x06001C6B RID: 7275 RVA: 0x0007126C File Offset: 0x0006F46C
	// (set) Token: 0x06001C6C RID: 7276 RVA: 0x0007128A File Offset: 0x0006F48A
	public unsafe static KeyCode toggleTeamChat
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleTeamChat, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleTeamChat, (void*)(&value));
		}
	}

	// Token: 0x170009E9 RID: 2537
	// (get) Token: 0x06001C6D RID: 7277 RVA: 0x0007129C File Offset: 0x0006F49C
	// (set) Token: 0x06001C6E RID: 7278 RVA: 0x000712BA File Offset: 0x0006F4BA
	public unsafe static KeyCode forcibleRefreshRadioChannels
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_forcibleRefreshRadioChannels, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_forcibleRefreshRadioChannels, (void*)(&value));
		}
	}

	// Token: 0x170009EA RID: 2538
	// (get) Token: 0x06001C6F RID: 7279 RVA: 0x000712CC File Offset: 0x0006F4CC
	// (set) Token: 0x06001C70 RID: 7280 RVA: 0x000712EA File Offset: 0x0006F4EA
	public unsafe static KeyCode toggleRadio
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_toggleRadio, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_toggleRadio, (void*)(&value));
		}
	}

	// Token: 0x170009EB RID: 2539
	// (get) Token: 0x06001C71 RID: 7281 RVA: 0x000712FC File Offset: 0x0006F4FC
	// (set) Token: 0x06001C72 RID: 7282 RVA: 0x0007131A File Offset: 0x0006F51A
	public unsafe static KeyCode roundReset
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_roundReset, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_roundReset, (void*)(&value));
		}
	}

	// Token: 0x170009EC RID: 2540
	// (get) Token: 0x06001C73 RID: 7283 RVA: 0x0007132C File Offset: 0x0006F52C
	// (set) Token: 0x06001C74 RID: 7284 RVA: 0x0007134A File Offset: 0x0006F54A
	public unsafe static KeyCode crashAbort
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_crashAbort, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_crashAbort, (void*)(&value));
		}
	}

	// Token: 0x170009ED RID: 2541
	// (get) Token: 0x06001C75 RID: 7285 RVA: 0x0007135C File Offset: 0x0006F55C
	// (set) Token: 0x06001C76 RID: 7286 RVA: 0x0007137A File Offset: 0x0006F57A
	public unsafe static KeyCode crashAccessViolation
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_crashAccessViolation, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_crashAccessViolation, (void*)(&value));
		}
	}

	// Token: 0x170009EE RID: 2542
	// (get) Token: 0x06001C77 RID: 7287 RVA: 0x0007138C File Offset: 0x0006F58C
	// (set) Token: 0x06001C78 RID: 7288 RVA: 0x000713AA File Offset: 0x0006F5AA
	public unsafe static KeyCode crashFatalError
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_crashFatalError, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_crashFatalError, (void*)(&value));
		}
	}

	// Token: 0x170009EF RID: 2543
	// (get) Token: 0x06001C79 RID: 7289 RVA: 0x000713BC File Offset: 0x0006F5BC
	// (set) Token: 0x06001C7A RID: 7290 RVA: 0x000713DA File Offset: 0x0006F5DA
	public unsafe static KeyCode crashPureVirtualFunction
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_crashPureVirtualFunction, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_crashPureVirtualFunction, (void*)(&value));
		}
	}

	// Token: 0x170009F0 RID: 2544
	// (get) Token: 0x06001C7B RID: 7291 RVA: 0x000713EC File Offset: 0x0006F5EC
	// (set) Token: 0x06001C7C RID: 7292 RVA: 0x0007140A File Offset: 0x0006F60A
	public unsafe static KeyCode flashBang
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_flashBang, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_flashBang, (void*)(&value));
		}
	}

	// Token: 0x170009F1 RID: 2545
	// (get) Token: 0x06001C7D RID: 7293 RVA: 0x0007141C File Offset: 0x0006F61C
	// (set) Token: 0x06001C7E RID: 7294 RVA: 0x0007143A File Offset: 0x0006F63A
	public unsafe static KeyCode suppression
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_suppression, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_suppression, (void*)(&value));
		}
	}

	// Token: 0x170009F2 RID: 2546
	// (get) Token: 0x06001C7F RID: 7295 RVA: 0x0007144C File Offset: 0x0006F64C
	// (set) Token: 0x06001C80 RID: 7296 RVA: 0x0007146A File Offset: 0x0006F66A
	public unsafe static KeyCode heal
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_heal, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_heal, (void*)(&value));
		}
	}

	// Token: 0x170009F3 RID: 2547
	// (get) Token: 0x06001C81 RID: 7297 RVA: 0x0007147C File Offset: 0x0006F67C
	// (set) Token: 0x06001C82 RID: 7298 RVA: 0x0007149A File Offset: 0x0006F69A
	public unsafe static KeyCode Hurt
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Hurt, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Hurt, (void*)(&value));
		}
	}

	// Token: 0x170009F4 RID: 2548
	// (get) Token: 0x06001C83 RID: 7299 RVA: 0x000714AC File Offset: 0x0006F6AC
	// (set) Token: 0x06001C84 RID: 7300 RVA: 0x000714CA File Offset: 0x0006F6CA
	public unsafe static KeyCode Downed
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Downed, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Downed, (void*)(&value));
		}
	}

	// Token: 0x170009F5 RID: 2549
	// (get) Token: 0x06001C85 RID: 7301 RVA: 0x000714DC File Offset: 0x0006F6DC
	// (set) Token: 0x06001C86 RID: 7302 RVA: 0x000714FA File Offset: 0x0006F6FA
	public unsafe static KeyCode Dead
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Dead, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Dead, (void*)(&value));
		}
	}

	// Token: 0x170009F6 RID: 2550
	// (get) Token: 0x06001C87 RID: 7303 RVA: 0x0007150C File Offset: 0x0006F70C
	// (set) Token: 0x06001C88 RID: 7304 RVA: 0x0007152A File Offset: 0x0006F72A
	public unsafe static KeyCode DeathFade
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_DeathFade, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_DeathFade, (void*)(&value));
		}
	}

	// Token: 0x170009F7 RID: 2551
	// (get) Token: 0x06001C89 RID: 7305 RVA: 0x0007153C File Offset: 0x0006F73C
	// (set) Token: 0x06001C8A RID: 7306 RVA: 0x0007155A File Offset: 0x0006F75A
	public unsafe static KeyCode Suppressed
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_Suppressed, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_Suppressed, (void*)(&value));
		}
	}

	// Token: 0x170009F8 RID: 2552
	// (get) Token: 0x06001C8B RID: 7307 RVA: 0x0007156C File Offset: 0x0006F76C
	// (set) Token: 0x06001C8C RID: 7308 RVA: 0x0007158A File Offset: 0x0006F78A
	public unsafe static KeyCode SuppressedTracer
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_SuppressedTracer, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_SuppressedTracer, (void*)(&value));
		}
	}

	// Token: 0x170009F9 RID: 2553
	// (get) Token: 0x06001C8D RID: 7309 RVA: 0x0007159C File Offset: 0x0006F79C
	// (set) Token: 0x06001C8E RID: 7310 RVA: 0x000715BA File Offset: 0x0006F7BA
	public unsafe static KeyCode SuppressedGrenade
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_SuppressedGrenade, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_SuppressedGrenade, (void*)(&value));
		}
	}

	// Token: 0x170009FA RID: 2554
	// (get) Token: 0x06001C8F RID: 7311 RVA: 0x000715CC File Offset: 0x0006F7CC
	// (set) Token: 0x06001C90 RID: 7312 RVA: 0x000715EA File Offset: 0x0006F7EA
	public unsafe static KeyCode UnderWater
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_UnderWater, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_UnderWater, (void*)(&value));
		}
	}

	// Token: 0x170009FB RID: 2555
	// (get) Token: 0x06001C91 RID: 7313 RVA: 0x000715FC File Offset: 0x0006F7FC
	// (set) Token: 0x06001C92 RID: 7314 RVA: 0x0007161A File Offset: 0x0006F81A
	public unsafe static KeyCode PrintScreenEffects
	{
		get
		{
			KeyCode result;
			IL2CPP.il2cpp_field_static_get_value(DebugHotkeys.NativeFieldInfoPtr_PrintScreenEffects, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DebugHotkeys.NativeFieldInfoPtr_PrintScreenEffects, (void*)(&value));
		}
	}

	// Token: 0x04001205 RID: 4613
	private static readonly IntPtr NativeFieldInfoPtr_DebugSituation;

	// Token: 0x04001206 RID: 4614
	private static readonly IntPtr NativeFieldInfoPtr_JoinQuarantine1;

	// Token: 0x04001207 RID: 4615
	private static readonly IntPtr NativeFieldInfoPtr_JoinDownfall3;

	// Token: 0x04001208 RID: 4616
	private static readonly IntPtr NativeFieldInfoPtr_JoinTanker;

	// Token: 0x04001209 RID: 4617
	private static readonly IntPtr NativeFieldInfoPtr_JoinSubway;

	// Token: 0x0400120A RID: 4618
	private static readonly IntPtr NativeFieldInfoPtr_JoinSuburbia;

	// Token: 0x0400120B RID: 4619
	private static readonly IntPtr NativeFieldInfoPtr_JoinBazaar;

	// Token: 0x0400120C RID: 4620
	private static readonly IntPtr NativeFieldInfoPtr_JoinAbandoned;

	// Token: 0x0400120D RID: 4621
	private static readonly IntPtr NativeFieldInfoPtr_JoinJungle;

	// Token: 0x0400120E RID: 4622
	private static readonly IntPtr NativeFieldInfoPtr_JoinInventory;

	// Token: 0x0400120F RID: 4623
	private static readonly IntPtr NativeFieldInfoPtr_JoinCargo;

	// Token: 0x04001210 RID: 4624
	private static readonly IntPtr NativeFieldInfoPtr_JoinTurbine;

	// Token: 0x04001211 RID: 4625
	private static readonly IntPtr NativeFieldInfoPtr_JoinSnowpeak;

	// Token: 0x04001212 RID: 4626
	private static readonly IntPtr NativeFieldInfoPtr_JoinTestMPPerfMap;

	// Token: 0x04001213 RID: 4627
	private static readonly IntPtr NativeFieldInfoPtr_JoinNewEmptyScene;

	// Token: 0x04001214 RID: 4628
	private static readonly IntPtr NativeFieldInfoPtr_Snapshot;

	// Token: 0x04001215 RID: 4629
	private static readonly IntPtr NativeFieldInfoPtr_Diff;

	// Token: 0x04001216 RID: 4630
	private static readonly IntPtr NativeFieldInfoPtr_RefreshLoadout;

	// Token: 0x04001217 RID: 4631
	private static readonly IntPtr NativeFieldInfoPtr_FreeRoam;

	// Token: 0x04001218 RID: 4632
	private static readonly IntPtr NativeFieldInfoPtr_Operations;

	// Token: 0x04001219 RID: 4633
	private static readonly IntPtr NativeFieldInfoPtr_FireFight;

	// Token: 0x0400121A RID: 4634
	private static readonly IntPtr NativeFieldInfoPtr_UplinkAssault;

	// Token: 0x0400121B RID: 4635
	private static readonly IntPtr NativeFieldInfoPtr_Escort;

	// Token: 0x0400121C RID: 4636
	private static readonly IntPtr NativeFieldInfoPtr_Uplink;

	// Token: 0x0400121D RID: 4637
	private static readonly IntPtr NativeFieldInfoPtr_ShootingRange;

	// Token: 0x0400121E RID: 4638
	private static readonly IntPtr NativeFieldInfoPtr_SpecOps;

	// Token: 0x0400121F RID: 4639
	private static readonly IntPtr NativeFieldInfoPtr_GunGame;

	// Token: 0x04001220 RID: 4640
	private static readonly IntPtr NativeFieldInfoPtr_OneInTheChamber;

	// Token: 0x04001221 RID: 4641
	private static readonly IntPtr NativeFieldInfoPtr_Spectating;

	// Token: 0x04001222 RID: 4642
	private static readonly IntPtr NativeFieldInfoPtr_Competitive;

	// Token: 0x04001223 RID: 4643
	private static readonly IntPtr NativeFieldInfoPtr_CargoSoloAsObserver;

	// Token: 0x04001224 RID: 4644
	private static readonly IntPtr NativeFieldInfoPtr_DownfallAsObserver;

	// Token: 0x04001225 RID: 4645
	private static readonly IntPtr NativeFieldInfoPtr_JoinCustomContent;

	// Token: 0x04001226 RID: 4646
	private static readonly IntPtr NativeFieldInfoPtr_JoinHandTesting;

	// Token: 0x04001227 RID: 4647
	private static readonly IntPtr NativeFieldInfoPtr_JoinTeamMarsoc;

	// Token: 0x04001228 RID: 4648
	private static readonly IntPtr NativeFieldInfoPtr_JoinTeamVolk;

	// Token: 0x04001229 RID: 4649
	private static readonly IntPtr NativeFieldInfoPtr_logCustomProps;

	// Token: 0x0400122A RID: 4650
	private static readonly IntPtr NativeFieldInfoPtr_toggleInvincibility;

	// Token: 0x0400122B RID: 4651
	private static readonly IntPtr NativeFieldInfoPtr_enableInfiniteAmmo;

	// Token: 0x0400122C RID: 4652
	private static readonly IntPtr NativeFieldInfoPtr_toggleStandardSpeed;

	// Token: 0x0400122D RID: 4653
	private static readonly IntPtr NativeFieldInfoPtr_showAllOnTabletMap;

	// Token: 0x0400122E RID: 4654
	private static readonly IntPtr NativeFieldInfoPtr_toggleTargetability;

	// Token: 0x0400122F RID: 4655
	private static readonly IntPtr NativeFieldInfoPtr_inflictDamageToSelf;

	// Token: 0x04001230 RID: 4656
	private static readonly IntPtr NativeFieldInfoPtr_toggleMirroredDamage;

	// Token: 0x04001231 RID: 4657
	private static readonly IntPtr NativeFieldInfoPtr_makeAIInvincible;

	// Token: 0x04001232 RID: 4658
	private static readonly IntPtr NativeFieldInfoPtr_aiWhistle;

	// Token: 0x04001233 RID: 4659
	private static readonly IntPtr NativeFieldInfoPtr_addInfractionToSelf;

	// Token: 0x04001234 RID: 4660
	private static readonly IntPtr NativeFieldInfoPtr_toggleTeamChat;

	// Token: 0x04001235 RID: 4661
	private static readonly IntPtr NativeFieldInfoPtr_forcibleRefreshRadioChannels;

	// Token: 0x04001236 RID: 4662
	private static readonly IntPtr NativeFieldInfoPtr_toggleRadio;

	// Token: 0x04001237 RID: 4663
	private static readonly IntPtr NativeFieldInfoPtr_roundReset;

	// Token: 0x04001238 RID: 4664
	private static readonly IntPtr NativeFieldInfoPtr_crashAbort;

	// Token: 0x04001239 RID: 4665
	private static readonly IntPtr NativeFieldInfoPtr_crashAccessViolation;

	// Token: 0x0400123A RID: 4666
	private static readonly IntPtr NativeFieldInfoPtr_crashFatalError;

	// Token: 0x0400123B RID: 4667
	private static readonly IntPtr NativeFieldInfoPtr_crashPureVirtualFunction;

	// Token: 0x0400123C RID: 4668
	private static readonly IntPtr NativeFieldInfoPtr_flashBang;

	// Token: 0x0400123D RID: 4669
	private static readonly IntPtr NativeFieldInfoPtr_suppression;

	// Token: 0x0400123E RID: 4670
	private static readonly IntPtr NativeFieldInfoPtr_heal;

	// Token: 0x0400123F RID: 4671
	private static readonly IntPtr NativeFieldInfoPtr_Hurt;

	// Token: 0x04001240 RID: 4672
	private static readonly IntPtr NativeFieldInfoPtr_Downed;

	// Token: 0x04001241 RID: 4673
	private static readonly IntPtr NativeFieldInfoPtr_Dead;

	// Token: 0x04001242 RID: 4674
	private static readonly IntPtr NativeFieldInfoPtr_DeathFade;

	// Token: 0x04001243 RID: 4675
	private static readonly IntPtr NativeFieldInfoPtr_Suppressed;

	// Token: 0x04001244 RID: 4676
	private static readonly IntPtr NativeFieldInfoPtr_SuppressedTracer;

	// Token: 0x04001245 RID: 4677
	private static readonly IntPtr NativeFieldInfoPtr_SuppressedGrenade;

	// Token: 0x04001246 RID: 4678
	private static readonly IntPtr NativeFieldInfoPtr_UnderWater;

	// Token: 0x04001247 RID: 4679
	private static readonly IntPtr NativeFieldInfoPtr_PrintScreenEffects;

	// Token: 0x04001248 RID: 4680
	private static readonly IntPtr NativeMethodInfoPtr_GetKeyQAOrEditor_Public_Static_Boolean_byref_KeyCode_byref_KeyCode_0;

	// Token: 0x04001249 RID: 4681
	private static readonly IntPtr NativeMethodInfoPtr_GetKey_Public_Static_Boolean_KeyCode_0;

	// Token: 0x0400124A RID: 4682
	private static readonly IntPtr NativeMethodInfoPtr_GetKeyUp_Public_Static_Boolean_KeyCode_0;

	// Token: 0x0400124B RID: 4683
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
