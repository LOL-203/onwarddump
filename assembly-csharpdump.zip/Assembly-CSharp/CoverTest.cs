﻿using System;
using DPI.CoverSystems;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000BE RID: 190
public class CoverTest : MonoBehaviour
{
	// Token: 0x06000BE4 RID: 3044 RVA: 0x0003092C File Offset: 0x0002EB2C
	[CallerCount(0)]
	public unsafe void FindEdge()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverTest.NativeMethodInfoPtr_FindEdge_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x00030970 File Offset: 0x0002EB70
	[CallerCount(0)]
	public unsafe CoverTest() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverTest>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverTest.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x000309BC File Offset: 0x0002EBBC
	// Note: this type is marked as 'beforefieldinit'.
	static CoverTest()
	{
		Il2CppClassPointerStore<CoverTest>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CoverTest");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverTest>.NativeClassPtr);
		CoverTest.NativeFieldInfoPtr_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverTest>.NativeClassPtr, "Target");
		CoverTest.NativeFieldInfoPtr_CoverPoint = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverTest>.NativeClassPtr, "CoverPoint");
		CoverTest.NativeFieldInfoPtr_Map = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverTest>.NativeClassPtr, "Map");
		CoverTest.NativeMethodInfoPtr_FindEdge_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverTest>.NativeClassPtr, 100664226);
		CoverTest.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverTest>.NativeClassPtr, 100664227);
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x0000210C File Offset: 0x0000030C
	public CoverTest(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700041A RID: 1050
	// (get) Token: 0x06000BE8 RID: 3048 RVA: 0x00030A50 File Offset: 0x0002EC50
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverTest>.NativeClassPtr));
		}
	}

	// Token: 0x1700041B RID: 1051
	// (get) Token: 0x06000BE9 RID: 3049 RVA: 0x00030A64 File Offset: 0x0002EC64
	// (set) Token: 0x06000BEA RID: 3050 RVA: 0x00030A98 File Offset: 0x0002EC98
	public unsafe Transform Target
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_Target);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700041C RID: 1052
	// (get) Token: 0x06000BEB RID: 3051 RVA: 0x00030AC0 File Offset: 0x0002ECC0
	// (set) Token: 0x06000BEC RID: 3052 RVA: 0x00030AF4 File Offset: 0x0002ECF4
	public unsafe CoverPoint CoverPoint
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_CoverPoint);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new CoverPoint(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_CoverPoint), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700041D RID: 1053
	// (get) Token: 0x06000BED RID: 3053 RVA: 0x00030B1C File Offset: 0x0002ED1C
	// (set) Token: 0x06000BEE RID: 3054 RVA: 0x00030B50 File Offset: 0x0002ED50
	public unsafe NavigationMap Map
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_Map);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new NavigationMap(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverTest.NativeFieldInfoPtr_Map), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000732 RID: 1842
	private static readonly IntPtr NativeFieldInfoPtr_Target;

	// Token: 0x04000733 RID: 1843
	private static readonly IntPtr NativeFieldInfoPtr_CoverPoint;

	// Token: 0x04000734 RID: 1844
	private static readonly IntPtr NativeFieldInfoPtr_Map;

	// Token: 0x04000735 RID: 1845
	private static readonly IntPtr NativeMethodInfoPtr_FindEdge_Public_Void_0;

	// Token: 0x04000736 RID: 1846
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
