﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000AA RID: 170
[Serializable]
[StructLayout(2)]
public struct ColliderData
{
	// Token: 0x06000AC2 RID: 2754 RVA: 0x0002C720 File Offset: 0x0002A920
	[CallerCount(0)]
	public unsafe ColliderData(Vector3 position, Quaternion rotation, Vector3 lossyScale, Vector3 size, bool isKillVolume)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref position;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rotation;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref lossyScale;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref size;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isKillVolume;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ColliderData.NativeMethodInfoPtr__ctor_Public_Void_Vector3_Quaternion_Vector3_Vector3_Boolean_0, ref this, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x0002C7B4 File Offset: 0x0002A9B4
	// Note: this type is marked as 'beforefieldinit'.
	static ColliderData()
	{
		Il2CppClassPointerStore<ColliderData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ColliderData");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ColliderData>.NativeClassPtr);
		ColliderData.NativeFieldInfoPtr_position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, "position");
		ColliderData.NativeFieldInfoPtr_rotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, "rotation");
		ColliderData.NativeFieldInfoPtr_lossyScale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, "lossyScale");
		ColliderData.NativeFieldInfoPtr_size = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, "size");
		ColliderData.NativeFieldInfoPtr_IsKillVolume = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, "IsKillVolume");
		ColliderData.NativeMethodInfoPtr__ctor_Public_Void_Vector3_Quaternion_Vector3_Vector3_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, 100664151);
	}

	// Token: 0x06000AC4 RID: 2756 RVA: 0x0002C85C File Offset: 0x0002AA5C
	public Il2CppSystem.Object BoxIl2CppObject()
	{
		return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ColliderData>.NativeClassPtr, ref this));
	}

	// Token: 0x170003B1 RID: 945
	// (get) Token: 0x06000AC5 RID: 2757 RVA: 0x0002C86E File Offset: 0x0002AA6E
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ColliderData>.NativeClassPtr));
		}
	}

	// Token: 0x04000687 RID: 1671
	private static readonly IntPtr NativeFieldInfoPtr_position;

	// Token: 0x04000688 RID: 1672
	private static readonly IntPtr NativeFieldInfoPtr_rotation;

	// Token: 0x04000689 RID: 1673
	private static readonly IntPtr NativeFieldInfoPtr_lossyScale;

	// Token: 0x0400068A RID: 1674
	private static readonly IntPtr NativeFieldInfoPtr_size;

	// Token: 0x0400068B RID: 1675
	private static readonly IntPtr NativeFieldInfoPtr_IsKillVolume;

	// Token: 0x0400068C RID: 1676
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Vector3_Quaternion_Vector3_Vector3_Boolean_0;

	// Token: 0x0400068D RID: 1677
	[FieldOffset(0)]
	public Vector3 position;

	// Token: 0x0400068E RID: 1678
	[FieldOffset(12)]
	public Quaternion rotation;

	// Token: 0x0400068F RID: 1679
	[FieldOffset(28)]
	public Vector3 lossyScale;

	// Token: 0x04000690 RID: 1680
	[FieldOffset(40)]
	public Vector3 size;

	// Token: 0x04000691 RID: 1681
	[FieldOffset(52)]
	public bool IsKillVolume;
}
