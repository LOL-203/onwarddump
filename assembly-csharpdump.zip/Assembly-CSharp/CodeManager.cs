﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Tablet;
using Onward.UI;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000446 RID: 1094
public class CodeManager : MonoBehaviour
{
	// Token: 0x0600573A RID: 22330 RVA: 0x0015D3E8 File Offset: 0x0015B5E8
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600573B RID: 22331 RVA: 0x0015D42C File Offset: 0x0015B62C
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600573C RID: 22332 RVA: 0x0015D470 File Offset: 0x0015B670
	[CallerCount(0)]
	public unsafe void OnTabletScreenInitialized(Pickup_Tablet tablet)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(tablet);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnTabletScreenInitialized_Public_Void_Pickup_Tablet_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600573D RID: 22333 RVA: 0x0015D4CC File Offset: 0x0015B6CC
	[CallerCount(0)]
	public unsafe void OnTabletScreenDeinitialized(Pickup_Tablet tablet)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(tablet);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnTabletScreenDeinitialized_Public_Void_Pickup_Tablet_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600573E RID: 22334 RVA: 0x0015D528 File Offset: 0x0015B728
	[CallerCount(0)]
	public unsafe void OnNumberBtnClick(int buttonNumber)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref buttonNumber;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnNumberBtnClick_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600573F RID: 22335 RVA: 0x0015D57C File Offset: 0x0015B77C
	[CallerCount(0)]
	public unsafe void OnSendBtnClick()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnSendBtnClick_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005740 RID: 22336 RVA: 0x0015D5C0 File Offset: 0x0015B7C0
	[CallerCount(0)]
	public unsafe void OnClearBtnClick()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_OnClearBtnClick_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005741 RID: 22337 RVA: 0x0015D604 File Offset: 0x0015B804
	[CallerCount(0)]
	public unsafe void ClearNumbers()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_ClearNumbers_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005742 RID: 22338 RVA: 0x0015D648 File Offset: 0x0015B848
	[CallerCount(0)]
	public unsafe void CheckNumbers()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_CheckNumbers_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005743 RID: 22339 RVA: 0x0015D68C File Offset: 0x0015B88C
	[CallerCount(0)]
	public unsafe IEnumerator CheckAndWaitForMasterClientConnection()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_CheckAndWaitForMasterClientConnection_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06005744 RID: 22340 RVA: 0x0015D6E4 File Offset: 0x0015B8E4
	[CallerCount(0)]
	public unsafe void DoCodeCorrect()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr_DoCodeCorrect_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005745 RID: 22341 RVA: 0x0015D728 File Offset: 0x0015B928
	[CallerCount(0)]
	public unsafe CodeManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CodeManager>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005746 RID: 22342 RVA: 0x0015D774 File Offset: 0x0015B974
	// Note: this type is marked as 'beforefieldinit'.
	static CodeManager()
	{
		Il2CppClassPointerStore<CodeManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CodeManager");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CodeManager>.NativeClassPtr);
		CodeManager.NativeFieldInfoPtr_thisTablet = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "thisTablet");
		CodeManager.NativeFieldInfoPtr_CodeText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "CodeText");
		CodeManager.NativeFieldInfoPtr_NumberButtons = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "NumberButtons");
		CodeManager.NativeFieldInfoPtr_SendButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "SendButton");
		CodeManager.NativeFieldInfoPtr_ClearButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "ClearButton");
		CodeManager.NativeFieldInfoPtr_IsHackScreen = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "IsHackScreen");
		CodeManager.NativeFieldInfoPtr_InputtedCode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "InputtedCode");
		CodeManager.NativeFieldInfoPtr_InputtedCodeIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "InputtedCodeIndex");
		CodeManager.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670169);
		CodeManager.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670170);
		CodeManager.NativeMethodInfoPtr_OnTabletScreenInitialized_Public_Void_Pickup_Tablet_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670171);
		CodeManager.NativeMethodInfoPtr_OnTabletScreenDeinitialized_Public_Void_Pickup_Tablet_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670172);
		CodeManager.NativeMethodInfoPtr_OnNumberBtnClick_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670173);
		CodeManager.NativeMethodInfoPtr_OnSendBtnClick_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670174);
		CodeManager.NativeMethodInfoPtr_OnClearBtnClick_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670175);
		CodeManager.NativeMethodInfoPtr_ClearNumbers_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670176);
		CodeManager.NativeMethodInfoPtr_CheckNumbers_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670177);
		CodeManager.NativeMethodInfoPtr_CheckAndWaitForMasterClientConnection_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670178);
		CodeManager.NativeMethodInfoPtr_DoCodeCorrect_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670179);
		CodeManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, 100670180);
	}

	// Token: 0x06005747 RID: 22343 RVA: 0x0000210C File Offset: 0x0000030C
	public CodeManager(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001F07 RID: 7943
	// (get) Token: 0x06005748 RID: 22344 RVA: 0x0015D934 File Offset: 0x0015BB34
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CodeManager>.NativeClassPtr));
		}
	}

	// Token: 0x17001F08 RID: 7944
	// (get) Token: 0x06005749 RID: 22345 RVA: 0x0015D948 File Offset: 0x0015BB48
	// (set) Token: 0x0600574A RID: 22346 RVA: 0x0015D97C File Offset: 0x0015BB7C
	public unsafe Pickup_Tablet thisTablet
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_thisTablet);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Pickup_Tablet(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_thisTablet), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F09 RID: 7945
	// (get) Token: 0x0600574B RID: 22347 RVA: 0x0015D9A4 File Offset: 0x0015BBA4
	// (set) Token: 0x0600574C RID: 22348 RVA: 0x0015D9D8 File Offset: 0x0015BBD8
	public unsafe Il2CppReferenceArray<TextMeshPro> CodeText
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_CodeText);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<TextMeshPro>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_CodeText), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F0A RID: 7946
	// (get) Token: 0x0600574D RID: 22349 RVA: 0x0015DA00 File Offset: 0x0015BC00
	// (set) Token: 0x0600574E RID: 22350 RVA: 0x0015DA34 File Offset: 0x0015BC34
	public unsafe Il2CppReferenceArray<ControlPanelButton> NumberButtons
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_NumberButtons);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ControlPanelButton>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_NumberButtons), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F0B RID: 7947
	// (get) Token: 0x0600574F RID: 22351 RVA: 0x0015DA5C File Offset: 0x0015BC5C
	// (set) Token: 0x06005750 RID: 22352 RVA: 0x0015DA90 File Offset: 0x0015BC90
	public unsafe Onward_UI_Sprite_Button SendButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_SendButton);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Onward_UI_Sprite_Button(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_SendButton), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F0C RID: 7948
	// (get) Token: 0x06005751 RID: 22353 RVA: 0x0015DAB8 File Offset: 0x0015BCB8
	// (set) Token: 0x06005752 RID: 22354 RVA: 0x0015DAEC File Offset: 0x0015BCEC
	public unsafe Onward_UI_Sprite_Button ClearButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_ClearButton);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Onward_UI_Sprite_Button(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_ClearButton), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F0D RID: 7949
	// (get) Token: 0x06005753 RID: 22355 RVA: 0x0015DB14 File Offset: 0x0015BD14
	// (set) Token: 0x06005754 RID: 22356 RVA: 0x0015DB3C File Offset: 0x0015BD3C
	public unsafe bool IsHackScreen
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_IsHackScreen);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_IsHackScreen)) = value;
		}
	}

	// Token: 0x17001F0E RID: 7950
	// (get) Token: 0x06005755 RID: 22357 RVA: 0x0015DB60 File Offset: 0x0015BD60
	// (set) Token: 0x06005756 RID: 22358 RVA: 0x0015DB94 File Offset: 0x0015BD94
	public unsafe Il2CppStructArray<int> InputtedCode
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_InputtedCode);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_InputtedCode), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001F0F RID: 7951
	// (get) Token: 0x06005757 RID: 22359 RVA: 0x0015DBBC File Offset: 0x0015BDBC
	// (set) Token: 0x06005758 RID: 22360 RVA: 0x0015DBE4 File Offset: 0x0015BDE4
	public unsafe int InputtedCodeIndex
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_InputtedCodeIndex);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.NativeFieldInfoPtr_InputtedCodeIndex)) = value;
		}
	}

	// Token: 0x04003749 RID: 14153
	private static readonly IntPtr NativeFieldInfoPtr_thisTablet;

	// Token: 0x0400374A RID: 14154
	private static readonly IntPtr NativeFieldInfoPtr_CodeText;

	// Token: 0x0400374B RID: 14155
	private static readonly IntPtr NativeFieldInfoPtr_NumberButtons;

	// Token: 0x0400374C RID: 14156
	private static readonly IntPtr NativeFieldInfoPtr_SendButton;

	// Token: 0x0400374D RID: 14157
	private static readonly IntPtr NativeFieldInfoPtr_ClearButton;

	// Token: 0x0400374E RID: 14158
	private static readonly IntPtr NativeFieldInfoPtr_IsHackScreen;

	// Token: 0x0400374F RID: 14159
	private static readonly IntPtr NativeFieldInfoPtr_InputtedCode;

	// Token: 0x04003750 RID: 14160
	private static readonly IntPtr NativeFieldInfoPtr_InputtedCodeIndex;

	// Token: 0x04003751 RID: 14161
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04003752 RID: 14162
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04003753 RID: 14163
	private static readonly IntPtr NativeMethodInfoPtr_OnTabletScreenInitialized_Public_Void_Pickup_Tablet_0;

	// Token: 0x04003754 RID: 14164
	private static readonly IntPtr NativeMethodInfoPtr_OnTabletScreenDeinitialized_Public_Void_Pickup_Tablet_0;

	// Token: 0x04003755 RID: 14165
	private static readonly IntPtr NativeMethodInfoPtr_OnNumberBtnClick_Public_Void_Int32_0;

	// Token: 0x04003756 RID: 14166
	private static readonly IntPtr NativeMethodInfoPtr_OnSendBtnClick_Private_Void_0;

	// Token: 0x04003757 RID: 14167
	private static readonly IntPtr NativeMethodInfoPtr_OnClearBtnClick_Private_Void_0;

	// Token: 0x04003758 RID: 14168
	private static readonly IntPtr NativeMethodInfoPtr_ClearNumbers_Public_Void_0;

	// Token: 0x04003759 RID: 14169
	private static readonly IntPtr NativeMethodInfoPtr_CheckNumbers_Private_Void_0;

	// Token: 0x0400375A RID: 14170
	private static readonly IntPtr NativeMethodInfoPtr_CheckAndWaitForMasterClientConnection_Private_IEnumerator_0;

	// Token: 0x0400375B RID: 14171
	private static readonly IntPtr NativeMethodInfoPtr_DoCodeCorrect_Private_Void_0;

	// Token: 0x0400375C RID: 14172
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000447 RID: 1095
	[ObfuscatedName("CodeManager/<>c__DisplayClass8_0")]
	public sealed class __c__DisplayClass8_0 : Il2CppSystem.Object
	{
		// Token: 0x06005759 RID: 22361 RVA: 0x0015DC08 File Offset: 0x0015BE08
		[CallerCount(0)]
		public unsafe __c__DisplayClass8_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.__c__DisplayClass8_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600575A RID: 22362 RVA: 0x0015DC54 File Offset: 0x0015BE54
		[CallerCount(0)]
		public unsafe void _Awake_b__0()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.__c__DisplayClass8_0.NativeMethodInfoPtr__Awake_b__0_Internal_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600575B RID: 22363 RVA: 0x0015DC98 File Offset: 0x0015BE98
		// Note: this type is marked as 'beforefieldinit'.
		static __c__DisplayClass8_0()
		{
			Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "<>c__DisplayClass8_0");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr);
			CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr_btn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr, "btn");
			CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr, "<>4__this");
			CodeManager.__c__DisplayClass8_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr, 100670181);
			CodeManager.__c__DisplayClass8_0.NativeMethodInfoPtr__Awake_b__0_Internal_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr, 100670182);
		}

		// Token: 0x0600575C RID: 22364 RVA: 0x00002988 File Offset: 0x00000B88
		public __c__DisplayClass8_0(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001F10 RID: 7952
		// (get) Token: 0x0600575D RID: 22365 RVA: 0x0015DD13 File Offset: 0x0015BF13
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CodeManager.__c__DisplayClass8_0>.NativeClassPtr));
			}
		}

		// Token: 0x17001F11 RID: 7953
		// (get) Token: 0x0600575E RID: 22366 RVA: 0x0015DD24 File Offset: 0x0015BF24
		// (set) Token: 0x0600575F RID: 22367 RVA: 0x0015DD58 File Offset: 0x0015BF58
		public unsafe Onward_UI_Sprite_Button btn
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr_btn);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Onward_UI_Sprite_Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr_btn), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001F12 RID: 7954
		// (get) Token: 0x06005760 RID: 22368 RVA: 0x0015DD80 File Offset: 0x0015BF80
		// (set) Token: 0x06005761 RID: 22369 RVA: 0x0015DDB4 File Offset: 0x0015BFB4
		public unsafe CodeManager __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CodeManager(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager.__c__DisplayClass8_0.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400375D RID: 14173
		private static readonly IntPtr NativeFieldInfoPtr_btn;

		// Token: 0x0400375E RID: 14174
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x0400375F RID: 14175
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04003760 RID: 14176
		private static readonly IntPtr NativeMethodInfoPtr__Awake_b__0_Internal_Void_0;
	}

	// Token: 0x02000448 RID: 1096
	[ObfuscatedName("CodeManager/<>c")]
	[Serializable]
	public sealed class __c : Il2CppSystem.Object
	{
		// Token: 0x06005762 RID: 22370 RVA: 0x0015DDDC File Offset: 0x0015BFDC
		[CallerCount(0)]
		public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06005763 RID: 22371 RVA: 0x0015DE28 File Offset: 0x0015C028
		[CallerCount(0)]
		public unsafe bool _CheckAndWaitForMasterClientConnection_b__17_0()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CodeManager.__c.NativeMethodInfoPtr__CheckAndWaitForMasterClientConnection_b__17_0_Internal_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06005764 RID: 22372 RVA: 0x0015DE78 File Offset: 0x0015C078
		// Note: this type is marked as 'beforefieldinit'.
		static __c()
		{
			Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "<>c");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr);
			CodeManager.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr, "<>9");
			CodeManager.__c.NativeFieldInfoPtr___9__17_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr, "<>9__17_0");
			CodeManager.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr, 100670184);
			CodeManager.__c.NativeMethodInfoPtr__CheckAndWaitForMasterClientConnection_b__17_0_Internal_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr, 100670185);
		}

		// Token: 0x06005765 RID: 22373 RVA: 0x00002988 File Offset: 0x00000B88
		public __c(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001F13 RID: 7955
		// (get) Token: 0x06005766 RID: 22374 RVA: 0x0015DEF3 File Offset: 0x0015C0F3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CodeManager.__c>.NativeClassPtr));
			}
		}

		// Token: 0x17001F14 RID: 7956
		// (get) Token: 0x06005767 RID: 22375 RVA: 0x0015DF04 File Offset: 0x0015C104
		// (set) Token: 0x06005768 RID: 22376 RVA: 0x0015DF2F File Offset: 0x0015C12F
		public unsafe static CodeManager.__c __9
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(CodeManager.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new CodeManager.__c(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CodeManager.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001F15 RID: 7957
		// (get) Token: 0x06005769 RID: 22377 RVA: 0x0015DF44 File Offset: 0x0015C144
		// (set) Token: 0x0600576A RID: 22378 RVA: 0x0015DF6F File Offset: 0x0015C16F
		public unsafe static Func<bool> __9__17_0
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(CodeManager.__c.NativeFieldInfoPtr___9__17_0, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Func<bool>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CodeManager.__c.NativeFieldInfoPtr___9__17_0, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04003761 RID: 14177
		private static readonly IntPtr NativeFieldInfoPtr___9;

		// Token: 0x04003762 RID: 14178
		private static readonly IntPtr NativeFieldInfoPtr___9__17_0;

		// Token: 0x04003763 RID: 14179
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04003764 RID: 14180
		private static readonly IntPtr NativeMethodInfoPtr__CheckAndWaitForMasterClientConnection_b__17_0_Internal_Boolean_0;
	}

	// Token: 0x02000449 RID: 1097
	[ObfuscatedName("CodeManager/<CheckAndWaitForMasterClientConnection>d__17")]
	public sealed class _CheckAndWaitForMasterClientConnection_d__17 : Il2CppSystem.Object
	{
		// Token: 0x0600576B RID: 22379 RVA: 0x0015DF84 File Offset: 0x0015C184
		[CallerCount(0)]
		public unsafe _CheckAndWaitForMasterClientConnection_d__17(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600576C RID: 22380 RVA: 0x0015DFE4 File Offset: 0x0015C1E4
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600576D RID: 22381 RVA: 0x0015E028 File Offset: 0x0015C228
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001F1A RID: 7962
		// (get) Token: 0x0600576E RID: 22382 RVA: 0x0015E078 File Offset: 0x0015C278
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600576F RID: 22383 RVA: 0x0015E0D0 File Offset: 0x0015C2D0
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001F1B RID: 7963
		// (get) Token: 0x06005770 RID: 22384 RVA: 0x0015E114 File Offset: 0x0015C314
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06005771 RID: 22385 RVA: 0x0015E16C File Offset: 0x0015C36C
		// Note: this type is marked as 'beforefieldinit'.
		static _CheckAndWaitForMasterClientConnection_d__17()
		{
			Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CodeManager>.NativeClassPtr, "<CheckAndWaitForMasterClientConnection>d__17");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, "<>1__state");
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, "<>2__current");
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, "<>4__this");
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670186);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670187);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670188);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670189);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670190);
			CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr, 100670191);
		}

		// Token: 0x06005772 RID: 22386 RVA: 0x00002988 File Offset: 0x00000B88
		public _CheckAndWaitForMasterClientConnection_d__17(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001F16 RID: 7958
		// (get) Token: 0x06005773 RID: 22387 RVA: 0x0015E24B File Offset: 0x0015C44B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CodeManager._CheckAndWaitForMasterClientConnection_d__17>.NativeClassPtr));
			}
		}

		// Token: 0x17001F17 RID: 7959
		// (get) Token: 0x06005774 RID: 22388 RVA: 0x0015E25C File Offset: 0x0015C45C
		// (set) Token: 0x06005775 RID: 22389 RVA: 0x0015E284 File Offset: 0x0015C484
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001F18 RID: 7960
		// (get) Token: 0x06005776 RID: 22390 RVA: 0x0015E2A8 File Offset: 0x0015C4A8
		// (set) Token: 0x06005777 RID: 22391 RVA: 0x0015E2DC File Offset: 0x0015C4DC
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001F19 RID: 7961
		// (get) Token: 0x06005778 RID: 22392 RVA: 0x0015E304 File Offset: 0x0015C504
		// (set) Token: 0x06005779 RID: 22393 RVA: 0x0015E338 File Offset: 0x0015C538
		public unsafe CodeManager __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CodeManager(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CodeManager._CheckAndWaitForMasterClientConnection_d__17.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04003765 RID: 14181
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04003766 RID: 14182
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04003767 RID: 14183
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04003768 RID: 14184
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04003769 RID: 14185
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400376A RID: 14186
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x0400376B RID: 14187
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x0400376C RID: 14188
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400376D RID: 14189
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
