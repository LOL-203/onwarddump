﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class BouncingBallLogic : MonoBehaviour
{
	// Token: 0x0600088B RID: 2187 RVA: 0x00023EE0 File Offset: 0x000220E0
	[CallerCount(0)]
	public unsafe void OnCollisionEnter()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x00023F24 File Offset: 0x00022124
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x00023F68 File Offset: 0x00022168
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x00023FAC File Offset: 0x000221AC
	[CallerCount(0)]
	public unsafe void UpdateVisibility()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_UpdateVisibility_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x00023FF0 File Offset: 0x000221F0
	[CallerCount(0)]
	public unsafe void SetVisible(bool setVisible)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref setVisible;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_SetVisible_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00024044 File Offset: 0x00022244
	[CallerCount(0)]
	public unsafe void Release(Vector3 pos, Vector3 vel, Vector3 angVel)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref pos;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vel;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angVel;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_Release_Public_Void_Vector3_Vector3_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x000240C0 File Offset: 0x000222C0
	[CallerCount(0)]
	public unsafe IEnumerator PlayPopCallback(float clipLength)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref clipLength;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr_PlayPopCallback_Private_IEnumerator_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x00024128 File Offset: 0x00022328
	[CallerCount(0)]
	public unsafe BouncingBallLogic() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x00024174 File Offset: 0x00022374
	// Note: this type is marked as 'beforefieldinit'.
	static BouncingBallLogic()
	{
		Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BouncingBallLogic");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr);
		BouncingBallLogic.NativeFieldInfoPtr_TTL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "TTL");
		BouncingBallLogic.NativeFieldInfoPtr_pop = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "pop");
		BouncingBallLogic.NativeFieldInfoPtr_bounce = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "bounce");
		BouncingBallLogic.NativeFieldInfoPtr_loadball = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "loadball");
		BouncingBallLogic.NativeFieldInfoPtr_visibleMat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "visibleMat");
		BouncingBallLogic.NativeFieldInfoPtr_hiddenMat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "hiddenMat");
		BouncingBallLogic.NativeFieldInfoPtr_audioSource = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "audioSource");
		BouncingBallLogic.NativeFieldInfoPtr_centerEyeCamera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "centerEyeCamera");
		BouncingBallLogic.NativeFieldInfoPtr_isVisible = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "isVisible");
		BouncingBallLogic.NativeFieldInfoPtr_timer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "timer");
		BouncingBallLogic.NativeFieldInfoPtr_isReleased = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "isReleased");
		BouncingBallLogic.NativeFieldInfoPtr_isReadyForDestroy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "isReadyForDestroy");
		BouncingBallLogic.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663989);
		BouncingBallLogic.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663990);
		BouncingBallLogic.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663991);
		BouncingBallLogic.NativeMethodInfoPtr_UpdateVisibility_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663992);
		BouncingBallLogic.NativeMethodInfoPtr_SetVisible_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663993);
		BouncingBallLogic.NativeMethodInfoPtr_Release_Public_Void_Vector3_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663994);
		BouncingBallLogic.NativeMethodInfoPtr_PlayPopCallback_Private_IEnumerator_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663995);
		BouncingBallLogic.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, 100663996);
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x0000210C File Offset: 0x0000030C
	public BouncingBallLogic(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170002EB RID: 747
	// (get) Token: 0x06000895 RID: 2197 RVA: 0x00024334 File Offset: 0x00022534
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr));
		}
	}

	// Token: 0x170002EC RID: 748
	// (get) Token: 0x06000896 RID: 2198 RVA: 0x00024348 File Offset: 0x00022548
	// (set) Token: 0x06000897 RID: 2199 RVA: 0x00024370 File Offset: 0x00022570
	public unsafe float TTL
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_TTL);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_TTL)) = value;
		}
	}

	// Token: 0x170002ED RID: 749
	// (get) Token: 0x06000898 RID: 2200 RVA: 0x00024394 File Offset: 0x00022594
	// (set) Token: 0x06000899 RID: 2201 RVA: 0x000243C8 File Offset: 0x000225C8
	public unsafe AudioClip pop
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_pop);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AudioClip(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_pop), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002EE RID: 750
	// (get) Token: 0x0600089A RID: 2202 RVA: 0x000243F0 File Offset: 0x000225F0
	// (set) Token: 0x0600089B RID: 2203 RVA: 0x00024424 File Offset: 0x00022624
	public unsafe AudioClip bounce
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_bounce);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AudioClip(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_bounce), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002EF RID: 751
	// (get) Token: 0x0600089C RID: 2204 RVA: 0x0002444C File Offset: 0x0002264C
	// (set) Token: 0x0600089D RID: 2205 RVA: 0x00024480 File Offset: 0x00022680
	public unsafe AudioClip loadball
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_loadball);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AudioClip(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_loadball), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002F0 RID: 752
	// (get) Token: 0x0600089E RID: 2206 RVA: 0x000244A8 File Offset: 0x000226A8
	// (set) Token: 0x0600089F RID: 2207 RVA: 0x000244DC File Offset: 0x000226DC
	public unsafe Material visibleMat
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_visibleMat);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Material(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_visibleMat), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002F1 RID: 753
	// (get) Token: 0x060008A0 RID: 2208 RVA: 0x00024504 File Offset: 0x00022704
	// (set) Token: 0x060008A1 RID: 2209 RVA: 0x00024538 File Offset: 0x00022738
	public unsafe Material hiddenMat
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_hiddenMat);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Material(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_hiddenMat), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002F2 RID: 754
	// (get) Token: 0x060008A2 RID: 2210 RVA: 0x00024560 File Offset: 0x00022760
	// (set) Token: 0x060008A3 RID: 2211 RVA: 0x00024594 File Offset: 0x00022794
	public unsafe AudioSource audioSource
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_audioSource);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AudioSource(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_audioSource), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002F3 RID: 755
	// (get) Token: 0x060008A4 RID: 2212 RVA: 0x000245BC File Offset: 0x000227BC
	// (set) Token: 0x060008A5 RID: 2213 RVA: 0x000245F0 File Offset: 0x000227F0
	public unsafe Transform centerEyeCamera
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_centerEyeCamera);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_centerEyeCamera), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170002F4 RID: 756
	// (get) Token: 0x060008A6 RID: 2214 RVA: 0x00024618 File Offset: 0x00022818
	// (set) Token: 0x060008A7 RID: 2215 RVA: 0x00024640 File Offset: 0x00022840
	public unsafe bool isVisible
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isVisible);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isVisible)) = value;
		}
	}

	// Token: 0x170002F5 RID: 757
	// (get) Token: 0x060008A8 RID: 2216 RVA: 0x00024664 File Offset: 0x00022864
	// (set) Token: 0x060008A9 RID: 2217 RVA: 0x0002468C File Offset: 0x0002288C
	public unsafe float timer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_timer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_timer)) = value;
		}
	}

	// Token: 0x170002F6 RID: 758
	// (get) Token: 0x060008AA RID: 2218 RVA: 0x000246B0 File Offset: 0x000228B0
	// (set) Token: 0x060008AB RID: 2219 RVA: 0x000246D8 File Offset: 0x000228D8
	public unsafe bool isReleased
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isReleased);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isReleased)) = value;
		}
	}

	// Token: 0x170002F7 RID: 759
	// (get) Token: 0x060008AC RID: 2220 RVA: 0x000246FC File Offset: 0x000228FC
	// (set) Token: 0x060008AD RID: 2221 RVA: 0x00024724 File Offset: 0x00022924
	public unsafe bool isReadyForDestroy
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isReadyForDestroy);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic.NativeFieldInfoPtr_isReadyForDestroy)) = value;
		}
	}

	// Token: 0x04000540 RID: 1344
	private static readonly IntPtr NativeFieldInfoPtr_TTL;

	// Token: 0x04000541 RID: 1345
	private static readonly IntPtr NativeFieldInfoPtr_pop;

	// Token: 0x04000542 RID: 1346
	private static readonly IntPtr NativeFieldInfoPtr_bounce;

	// Token: 0x04000543 RID: 1347
	private static readonly IntPtr NativeFieldInfoPtr_loadball;

	// Token: 0x04000544 RID: 1348
	private static readonly IntPtr NativeFieldInfoPtr_visibleMat;

	// Token: 0x04000545 RID: 1349
	private static readonly IntPtr NativeFieldInfoPtr_hiddenMat;

	// Token: 0x04000546 RID: 1350
	private static readonly IntPtr NativeFieldInfoPtr_audioSource;

	// Token: 0x04000547 RID: 1351
	private static readonly IntPtr NativeFieldInfoPtr_centerEyeCamera;

	// Token: 0x04000548 RID: 1352
	private static readonly IntPtr NativeFieldInfoPtr_isVisible;

	// Token: 0x04000549 RID: 1353
	private static readonly IntPtr NativeFieldInfoPtr_timer;

	// Token: 0x0400054A RID: 1354
	private static readonly IntPtr NativeFieldInfoPtr_isReleased;

	// Token: 0x0400054B RID: 1355
	private static readonly IntPtr NativeFieldInfoPtr_isReadyForDestroy;

	// Token: 0x0400054C RID: 1356
	private static readonly IntPtr NativeMethodInfoPtr_OnCollisionEnter_Private_Void_0;

	// Token: 0x0400054D RID: 1357
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x0400054E RID: 1358
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x0400054F RID: 1359
	private static readonly IntPtr NativeMethodInfoPtr_UpdateVisibility_Private_Void_0;

	// Token: 0x04000550 RID: 1360
	private static readonly IntPtr NativeMethodInfoPtr_SetVisible_Private_Void_Boolean_0;

	// Token: 0x04000551 RID: 1361
	private static readonly IntPtr NativeMethodInfoPtr_Release_Public_Void_Vector3_Vector3_Vector3_0;

	// Token: 0x04000552 RID: 1362
	private static readonly IntPtr NativeMethodInfoPtr_PlayPopCallback_Private_IEnumerator_Single_0;

	// Token: 0x04000553 RID: 1363
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200008B RID: 139
	[ObfuscatedName("BouncingBallLogic/<PlayPopCallback>d__18")]
	public sealed class _PlayPopCallback_d__18 : Il2CppSystem.Object
	{
		// Token: 0x060008AE RID: 2222 RVA: 0x00024748 File Offset: 0x00022948
		[CallerCount(0)]
		public unsafe _PlayPopCallback_d__18(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x000247A8 File Offset: 0x000229A8
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x000247EC File Offset: 0x000229EC
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x170002FD RID: 765
		// (get) Token: 0x060008B1 RID: 2225 RVA: 0x0002483C File Offset: 0x00022A3C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060008B2 RID: 2226 RVA: 0x00024894 File Offset: 0x00022A94
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170002FE RID: 766
		// (get) Token: 0x060008B3 RID: 2227 RVA: 0x000248D8 File Offset: 0x00022AD8
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x060008B4 RID: 2228 RVA: 0x00024930 File Offset: 0x00022B30
		// Note: this type is marked as 'beforefieldinit'.
		static _PlayPopCallback_d__18()
		{
			Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BouncingBallLogic>.NativeClassPtr, "<PlayPopCallback>d__18");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr);
			BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, "<>1__state");
			BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, "<>2__current");
			BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr_clipLength = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, "clipLength");
			BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, "<>4__this");
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100663997);
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100663998);
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100663999);
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100664000);
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100664001);
			BouncingBallLogic._PlayPopCallback_d__18.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr, 100664002);
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00002988 File Offset: 0x00000B88
		public _PlayPopCallback_d__18(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170002F8 RID: 760
		// (get) Token: 0x060008B6 RID: 2230 RVA: 0x00024A23 File Offset: 0x00022C23
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BouncingBallLogic._PlayPopCallback_d__18>.NativeClassPtr));
			}
		}

		// Token: 0x170002F9 RID: 761
		// (get) Token: 0x060008B7 RID: 2231 RVA: 0x00024A34 File Offset: 0x00022C34
		// (set) Token: 0x060008B8 RID: 2232 RVA: 0x00024A5C File Offset: 0x00022C5C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x170002FA RID: 762
		// (get) Token: 0x060008B9 RID: 2233 RVA: 0x00024A80 File Offset: 0x00022C80
		// (set) Token: 0x060008BA RID: 2234 RVA: 0x00024AB4 File Offset: 0x00022CB4
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170002FB RID: 763
		// (get) Token: 0x060008BB RID: 2235 RVA: 0x00024ADC File Offset: 0x00022CDC
		// (set) Token: 0x060008BC RID: 2236 RVA: 0x00024B04 File Offset: 0x00022D04
		public unsafe float clipLength
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr_clipLength);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr_clipLength)) = value;
			}
		}

		// Token: 0x170002FC RID: 764
		// (get) Token: 0x060008BD RID: 2237 RVA: 0x00024B28 File Offset: 0x00022D28
		// (set) Token: 0x060008BE RID: 2238 RVA: 0x00024B5C File Offset: 0x00022D5C
		public unsafe BouncingBallLogic __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BouncingBallLogic(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BouncingBallLogic._PlayPopCallback_d__18.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000554 RID: 1364
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04000555 RID: 1365
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04000556 RID: 1366
		private static readonly IntPtr NativeFieldInfoPtr_clipLength;

		// Token: 0x04000557 RID: 1367
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04000558 RID: 1368
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04000559 RID: 1369
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400055A RID: 1370
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x0400055B RID: 1371
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x0400055C RID: 1372
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400055D RID: 1373
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
