﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200049D RID: 1181
public class CircularBuffer : Object
{
	// Token: 0x06005E18 RID: 24088 RVA: 0x001781B4 File Offset: 0x001763B4
	[CallerCount(0)]
	public unsafe CircularBuffer(int capacity) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref capacity;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E19 RID: 24089 RVA: 0x00178214 File Offset: 0x00176414
	[CallerCount(0)]
	public unsafe CircularBuffer(int capacity, Il2CppStructArray<float> items) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref capacity;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(items);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr__ctor_Public_Void_Int32_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17002174 RID: 8564
	// (get) Token: 0x06005E1A RID: 24090 RVA: 0x0017828C File Offset: 0x0017648C
	public unsafe int Capacity
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_get_Capacity_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002175 RID: 8565
	// (get) Token: 0x06005E1B RID: 24091 RVA: 0x001782DC File Offset: 0x001764DC
	public unsafe bool IsFull
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_get_IsFull_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002176 RID: 8566
	// (get) Token: 0x06005E1C RID: 24092 RVA: 0x0017832C File Offset: 0x0017652C
	public unsafe bool IsEmpty
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_get_IsEmpty_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x17002177 RID: 8567
	// (get) Token: 0x06005E1D RID: 24093 RVA: 0x0017837C File Offset: 0x0017657C
	public unsafe int Size
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_get_Size_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
	}

	// Token: 0x06005E1E RID: 24094 RVA: 0x001783CC File Offset: 0x001765CC
	[CallerCount(0)]
	public unsafe float Front()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_Front_Public_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005E1F RID: 24095 RVA: 0x0017841C File Offset: 0x0017661C
	[CallerCount(0)]
	public unsafe float Back()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_Back_Public_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x17002178 RID: 8568
	public unsafe float this[int index]
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref index;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}
		[CallerCount(0)]
		set
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref index;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x06005E22 RID: 24098 RVA: 0x00178538 File Offset: 0x00176738
	[CallerCount(0)]
	public unsafe void PushBack(float item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref item;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_PushBack_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E23 RID: 24099 RVA: 0x0017858C File Offset: 0x0017678C
	[CallerCount(0)]
	public unsafe void PushBack(Il2CppStructArray<float> buffer)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(buffer);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_PushBack_Public_Void_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E24 RID: 24100 RVA: 0x001785E8 File Offset: 0x001767E8
	[CallerCount(0)]
	public unsafe void PushFront(float item)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref item;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_PushFront_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E25 RID: 24101 RVA: 0x0017863C File Offset: 0x0017683C
	[CallerCount(0)]
	public unsafe Il2CppStructArray<float> GetData()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_GetData_Public_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppStructArray<float>(intPtr2) : null;
	}

	// Token: 0x06005E26 RID: 24102 RVA: 0x00178694 File Offset: 0x00176894
	[CallerCount(0)]
	public unsafe void PopFront()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_PopFront_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E27 RID: 24103 RVA: 0x001786D8 File Offset: 0x001768D8
	[CallerCount(0)]
	public unsafe void Clear()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_Clear_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E28 RID: 24104 RVA: 0x0017871C File Offset: 0x0017691C
	[CallerCount(0)]
	public unsafe Il2CppStructArray<float> ToArray()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_ToArray_Public_ArrayOf_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new Il2CppStructArray<float>(intPtr2) : null;
	}

	// Token: 0x06005E29 RID: 24105 RVA: 0x00178774 File Offset: 0x00176974
	[CallerCount(0)]
	public unsafe IList<ArraySegment<float>> ToArraySegments()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_ToArraySegments_Public_IList_1_ArraySegment_1_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IList<ArraySegment<float>>(intPtr2) : null;
	}

	// Token: 0x06005E2A RID: 24106 RVA: 0x001787CC File Offset: 0x001769CC
	[CallerCount(0)]
	public unsafe IEnumerator<float> GetEnumerator()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_GetEnumerator_Public_IEnumerator_1_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator<float>(intPtr2) : null;
	}

	// Token: 0x06005E2B RID: 24107 RVA: 0x00178824 File Offset: 0x00176A24
	[CallerCount(0)]
	public unsafe IEnumerator System_Collections_IEnumerable_GetEnumerator()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06005E2C RID: 24108 RVA: 0x0017887C File Offset: 0x00176A7C
	[CallerCount(0)]
	public unsafe void ThrowIfEmpty(string message = "Cannot access an empty buffer.")
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_ThrowIfEmpty_Private_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E2D RID: 24109 RVA: 0x001788D8 File Offset: 0x00176AD8
	[CallerCount(0)]
	public unsafe void Increment(ref int index)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &index;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_Increment_Private_Void_byref_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E2E RID: 24110 RVA: 0x00178930 File Offset: 0x00176B30
	[CallerCount(0)]
	public unsafe void Decrement(ref int index)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &index;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_Decrement_Private_Void_byref_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06005E2F RID: 24111 RVA: 0x00178988 File Offset: 0x00176B88
	[CallerCount(0)]
	public unsafe int InternalIndex(int index)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref index;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_InternalIndex_Private_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06005E30 RID: 24112 RVA: 0x001789EC File Offset: 0x00176BEC
	[CallerCount(0)]
	public unsafe ArraySegment<float> ArrayOne()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_ArrayOne_Private_ArraySegment_1_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return new ArraySegment<float>(intPtr);
	}

	// Token: 0x06005E31 RID: 24113 RVA: 0x00178A38 File Offset: 0x00176C38
	[CallerCount(0)]
	public unsafe ArraySegment<float> ArrayTwo()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer.NativeMethodInfoPtr_ArrayTwo_Private_ArraySegment_1_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return new ArraySegment<float>(intPtr);
	}

	// Token: 0x06005E32 RID: 24114 RVA: 0x00178A84 File Offset: 0x00176C84
	// Note: this type is marked as 'beforefieldinit'.
	static CircularBuffer()
	{
		Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CircularBuffer");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr);
		CircularBuffer.NativeFieldInfoPtr__buffer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "_buffer");
		CircularBuffer.NativeFieldInfoPtr__start = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "_start");
		CircularBuffer.NativeFieldInfoPtr__end = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "_end");
		CircularBuffer.NativeFieldInfoPtr__size = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "_size");
		CircularBuffer.NativeFieldInfoPtr_threadLock = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "threadLock");
		CircularBuffer.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670720);
		CircularBuffer.NativeMethodInfoPtr__ctor_Public_Void_Int32_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670721);
		CircularBuffer.NativeMethodInfoPtr_get_Capacity_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670722);
		CircularBuffer.NativeMethodInfoPtr_get_IsFull_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670723);
		CircularBuffer.NativeMethodInfoPtr_get_IsEmpty_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670724);
		CircularBuffer.NativeMethodInfoPtr_get_Size_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670725);
		CircularBuffer.NativeMethodInfoPtr_Front_Public_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670726);
		CircularBuffer.NativeMethodInfoPtr_Back_Public_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670727);
		CircularBuffer.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670728);
		CircularBuffer.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670729);
		CircularBuffer.NativeMethodInfoPtr_PushBack_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670730);
		CircularBuffer.NativeMethodInfoPtr_PushBack_Public_Void_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670731);
		CircularBuffer.NativeMethodInfoPtr_PushFront_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670732);
		CircularBuffer.NativeMethodInfoPtr_GetData_Public_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670733);
		CircularBuffer.NativeMethodInfoPtr_PopFront_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670734);
		CircularBuffer.NativeMethodInfoPtr_Clear_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670735);
		CircularBuffer.NativeMethodInfoPtr_ToArray_Public_ArrayOf_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670736);
		CircularBuffer.NativeMethodInfoPtr_ToArraySegments_Public_IList_1_ArraySegment_1_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670737);
		CircularBuffer.NativeMethodInfoPtr_GetEnumerator_Public_IEnumerator_1_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670738);
		CircularBuffer.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670739);
		CircularBuffer.NativeMethodInfoPtr_ThrowIfEmpty_Private_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670740);
		CircularBuffer.NativeMethodInfoPtr_Increment_Private_Void_byref_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670741);
		CircularBuffer.NativeMethodInfoPtr_Decrement_Private_Void_byref_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670742);
		CircularBuffer.NativeMethodInfoPtr_InternalIndex_Private_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670743);
		CircularBuffer.NativeMethodInfoPtr_ArrayOne_Private_ArraySegment_1_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670744);
		CircularBuffer.NativeMethodInfoPtr_ArrayTwo_Private_ArraySegment_1_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, 100670745);
	}

	// Token: 0x06005E33 RID: 24115 RVA: 0x00002988 File Offset: 0x00000B88
	public CircularBuffer(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700216E RID: 8558
	// (get) Token: 0x06005E34 RID: 24116 RVA: 0x00178D20 File Offset: 0x00176F20
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr));
		}
	}

	// Token: 0x1700216F RID: 8559
	// (get) Token: 0x06005E35 RID: 24117 RVA: 0x00178D34 File Offset: 0x00176F34
	// (set) Token: 0x06005E36 RID: 24118 RVA: 0x00178D68 File Offset: 0x00176F68
	public unsafe Il2CppStructArray<float> _buffer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__buffer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<float>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__buffer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002170 RID: 8560
	// (get) Token: 0x06005E37 RID: 24119 RVA: 0x00178D90 File Offset: 0x00176F90
	// (set) Token: 0x06005E38 RID: 24120 RVA: 0x00178DB8 File Offset: 0x00176FB8
	public unsafe int _start
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__start);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__start)) = value;
		}
	}

	// Token: 0x17002171 RID: 8561
	// (get) Token: 0x06005E39 RID: 24121 RVA: 0x00178DDC File Offset: 0x00176FDC
	// (set) Token: 0x06005E3A RID: 24122 RVA: 0x00178E04 File Offset: 0x00177004
	public unsafe int _end
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__end);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__end)) = value;
		}
	}

	// Token: 0x17002172 RID: 8562
	// (get) Token: 0x06005E3B RID: 24123 RVA: 0x00178E28 File Offset: 0x00177028
	// (set) Token: 0x06005E3C RID: 24124 RVA: 0x00178E50 File Offset: 0x00177050
	public unsafe int _size
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__size);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr__size)) = value;
		}
	}

	// Token: 0x17002173 RID: 8563
	// (get) Token: 0x06005E3D RID: 24125 RVA: 0x00178E74 File Offset: 0x00177074
	// (set) Token: 0x06005E3E RID: 24126 RVA: 0x00178EA8 File Offset: 0x001770A8
	public unsafe Object threadLock
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr_threadLock);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Object(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer.NativeFieldInfoPtr_threadLock), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04003B67 RID: 15207
	private static readonly IntPtr NativeFieldInfoPtr__buffer;

	// Token: 0x04003B68 RID: 15208
	private static readonly IntPtr NativeFieldInfoPtr__start;

	// Token: 0x04003B69 RID: 15209
	private static readonly IntPtr NativeFieldInfoPtr__end;

	// Token: 0x04003B6A RID: 15210
	private static readonly IntPtr NativeFieldInfoPtr__size;

	// Token: 0x04003B6B RID: 15211
	private static readonly IntPtr NativeFieldInfoPtr_threadLock;

	// Token: 0x04003B6C RID: 15212
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

	// Token: 0x04003B6D RID: 15213
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_ArrayOf_Single_0;

	// Token: 0x04003B6E RID: 15214
	private static readonly IntPtr NativeMethodInfoPtr_get_Capacity_Public_get_Int32_0;

	// Token: 0x04003B6F RID: 15215
	private static readonly IntPtr NativeMethodInfoPtr_get_IsFull_Public_get_Boolean_0;

	// Token: 0x04003B70 RID: 15216
	private static readonly IntPtr NativeMethodInfoPtr_get_IsEmpty_Public_get_Boolean_0;

	// Token: 0x04003B71 RID: 15217
	private static readonly IntPtr NativeMethodInfoPtr_get_Size_Public_get_Int32_0;

	// Token: 0x04003B72 RID: 15218
	private static readonly IntPtr NativeMethodInfoPtr_Front_Public_Single_0;

	// Token: 0x04003B73 RID: 15219
	private static readonly IntPtr NativeMethodInfoPtr_Back_Public_Single_0;

	// Token: 0x04003B74 RID: 15220
	private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0;

	// Token: 0x04003B75 RID: 15221
	private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0;

	// Token: 0x04003B76 RID: 15222
	private static readonly IntPtr NativeMethodInfoPtr_PushBack_Public_Void_Single_0;

	// Token: 0x04003B77 RID: 15223
	private static readonly IntPtr NativeMethodInfoPtr_PushBack_Public_Void_ArrayOf_Single_0;

	// Token: 0x04003B78 RID: 15224
	private static readonly IntPtr NativeMethodInfoPtr_PushFront_Public_Void_Single_0;

	// Token: 0x04003B79 RID: 15225
	private static readonly IntPtr NativeMethodInfoPtr_GetData_Public_ArrayOf_Single_0;

	// Token: 0x04003B7A RID: 15226
	private static readonly IntPtr NativeMethodInfoPtr_PopFront_Public_Void_0;

	// Token: 0x04003B7B RID: 15227
	private static readonly IntPtr NativeMethodInfoPtr_Clear_Public_Void_0;

	// Token: 0x04003B7C RID: 15228
	private static readonly IntPtr NativeMethodInfoPtr_ToArray_Public_ArrayOf_Single_0;

	// Token: 0x04003B7D RID: 15229
	private static readonly IntPtr NativeMethodInfoPtr_ToArraySegments_Public_IList_1_ArraySegment_1_Single_0;

	// Token: 0x04003B7E RID: 15230
	private static readonly IntPtr NativeMethodInfoPtr_GetEnumerator_Public_IEnumerator_1_Single_0;

	// Token: 0x04003B7F RID: 15231
	private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0;

	// Token: 0x04003B80 RID: 15232
	private static readonly IntPtr NativeMethodInfoPtr_ThrowIfEmpty_Private_Void_String_0;

	// Token: 0x04003B81 RID: 15233
	private static readonly IntPtr NativeMethodInfoPtr_Increment_Private_Void_byref_Int32_0;

	// Token: 0x04003B82 RID: 15234
	private static readonly IntPtr NativeMethodInfoPtr_Decrement_Private_Void_byref_Int32_0;

	// Token: 0x04003B83 RID: 15235
	private static readonly IntPtr NativeMethodInfoPtr_InternalIndex_Private_Int32_Int32_0;

	// Token: 0x04003B84 RID: 15236
	private static readonly IntPtr NativeMethodInfoPtr_ArrayOne_Private_ArraySegment_1_Single_0;

	// Token: 0x04003B85 RID: 15237
	private static readonly IntPtr NativeMethodInfoPtr_ArrayTwo_Private_ArraySegment_1_Single_0;

	// Token: 0x0200049E RID: 1182
	[ObfuscatedName("CircularBuffer/<GetEnumerator>d__28")]
	public sealed class _GetEnumerator_d__28 : Object
	{
		// Token: 0x06005E3F RID: 24127 RVA: 0x00178ED0 File Offset: 0x001770D0
		[CallerCount(0)]
		public unsafe _GetEnumerator_d__28(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06005E40 RID: 24128 RVA: 0x00178F30 File Offset: 0x00177130
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06005E41 RID: 24129 RVA: 0x00178F74 File Offset: 0x00177174
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06005E42 RID: 24130 RVA: 0x00178FC4 File Offset: 0x001771C4
		[CallerCount(0)]
		public unsafe void __m__Finally1()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr___m__Finally1_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17002180 RID: 8576
		// (get) Token: 0x06005E43 RID: 24131 RVA: 0x00179008 File Offset: 0x00177208
		public unsafe float Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Single__get_Current_Private_Virtual_Final_New_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06005E44 RID: 24132 RVA: 0x00179058 File Offset: 0x00177258
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17002181 RID: 8577
		// (get) Token: 0x06005E45 RID: 24133 RVA: 0x0017909C File Offset: 0x0017729C
		public unsafe Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Object(intPtr2) : null;
			}
		}

		// Token: 0x06005E46 RID: 24134 RVA: 0x001790F4 File Offset: 0x001772F4
		// Note: this type is marked as 'beforefieldinit'.
		static _GetEnumerator_d__28()
		{
			Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CircularBuffer>.NativeClassPtr, "<GetEnumerator>d__28");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr);
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<>1__state");
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<>2__current");
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<>4__this");
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___7__wrap1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<>7__wrap1");
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__segment_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<segment>5__3");
			CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__i_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, "<i>5__4");
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670746);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670747);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670748);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr___m__Finally1_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670749);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Single__get_Current_Private_Virtual_Final_New_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670750);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670751);
			CircularBuffer._GetEnumerator_d__28.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr, 100670752);
		}

		// Token: 0x06005E47 RID: 24135 RVA: 0x00002988 File Offset: 0x00000B88
		public _GetEnumerator_d__28(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002179 RID: 8569
		// (get) Token: 0x06005E48 RID: 24136 RVA: 0x00179223 File Offset: 0x00177423
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CircularBuffer._GetEnumerator_d__28>.NativeClassPtr));
			}
		}

		// Token: 0x1700217A RID: 8570
		// (get) Token: 0x06005E49 RID: 24137 RVA: 0x00179234 File Offset: 0x00177434
		// (set) Token: 0x06005E4A RID: 24138 RVA: 0x0017925C File Offset: 0x0017745C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700217B RID: 8571
		// (get) Token: 0x06005E4B RID: 24139 RVA: 0x00179280 File Offset: 0x00177480
		// (set) Token: 0x06005E4C RID: 24140 RVA: 0x001792A8 File Offset: 0x001774A8
		public unsafe float __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___2__current);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___2__current)) = value;
			}
		}

		// Token: 0x1700217C RID: 8572
		// (get) Token: 0x06005E4D RID: 24141 RVA: 0x001792CC File Offset: 0x001774CC
		// (set) Token: 0x06005E4E RID: 24142 RVA: 0x00179300 File Offset: 0x00177500
		public unsafe CircularBuffer __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CircularBuffer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700217D RID: 8573
		// (get) Token: 0x06005E4F RID: 24143 RVA: 0x00179328 File Offset: 0x00177528
		// (set) Token: 0x06005E50 RID: 24144 RVA: 0x0017935C File Offset: 0x0017755C
		public unsafe IEnumerator<ArraySegment<float>> __7__wrap1
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___7__wrap1);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new IEnumerator<ArraySegment<float>>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr___7__wrap1), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700217E RID: 8574
		// (get) Token: 0x06005E51 RID: 24145 RVA: 0x00179384 File Offset: 0x00177584
		// (set) Token: 0x06005E52 RID: 24146 RVA: 0x001793B6 File Offset: 0x001775B6
		public ArraySegment<float> _segment_5__3
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__segment_5__3);
				return new ArraySegment<float>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ArraySegment<float>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__segment_5__3), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ArraySegment<float>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x1700217F RID: 8575
		// (get) Token: 0x06005E53 RID: 24147 RVA: 0x001793EC File Offset: 0x001775EC
		// (set) Token: 0x06005E54 RID: 24148 RVA: 0x00179414 File Offset: 0x00177614
		public unsafe int _i_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__i_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CircularBuffer._GetEnumerator_d__28.NativeFieldInfoPtr__i_5__4)) = value;
			}
		}

		// Token: 0x04003B86 RID: 15238
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04003B87 RID: 15239
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04003B88 RID: 15240
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04003B89 RID: 15241
		private static readonly IntPtr NativeFieldInfoPtr___7__wrap1;

		// Token: 0x04003B8A RID: 15242
		private static readonly IntPtr NativeFieldInfoPtr__segment_5__3;

		// Token: 0x04003B8B RID: 15243
		private static readonly IntPtr NativeFieldInfoPtr__i_5__4;

		// Token: 0x04003B8C RID: 15244
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04003B8D RID: 15245
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003B8E RID: 15246
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04003B8F RID: 15247
		private static readonly IntPtr NativeMethodInfoPtr___m__Finally1_Private_Void_0;

		// Token: 0x04003B90 RID: 15248
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Single__get_Current_Private_Virtual_Final_New_get_Single_0;

		// Token: 0x04003B91 RID: 15249
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04003B92 RID: 15250
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
