﻿using System;

// Token: 0x02000167 RID: 359
public enum ControllerVelocityMode
{
	// Token: 0x04000F83 RID: 3971
	None,
	// Token: 0x04000F84 RID: 3972
	Raw,
	// Token: 0x04000F85 RID: 3973
	Smooth,
	// Token: 0x04000F86 RID: 3974
	Physics,
	// Token: 0x04000F87 RID: 3975
	Vanilla
}
