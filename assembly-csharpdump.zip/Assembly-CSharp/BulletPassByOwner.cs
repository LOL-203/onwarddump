﻿using System;
using AK.Wwise;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000141 RID: 321
public class BulletPassByOwner : MonoBehaviour
{
	// Token: 0x060014BA RID: 5306 RVA: 0x00053F08 File Offset: 0x00052108
	[CallerCount(0)]
	public unsafe void PlayFlyBy(Vector3 pos, Vector3 forward, Vector3 up, Vector3 ownerPos, bool isSubsonic)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref pos;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref forward;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref up;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref ownerPos;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isSubsonic;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletPassByOwner.NativeMethodInfoPtr_PlayFlyBy_Public_Void_Vector3_Vector3_Vector3_Vector3_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014BB RID: 5307 RVA: 0x00053FA8 File Offset: 0x000521A8
	[CallerCount(0)]
	public unsafe BulletPassByOwner() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BulletPassByOwner.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060014BC RID: 5308 RVA: 0x00053FF4 File Offset: 0x000521F4
	// Note: this type is marked as 'beforefieldinit'.
	static BulletPassByOwner()
	{
		Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BulletPassByOwner");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr);
		BulletPassByOwner.NativeFieldInfoPtr_Owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr, "Owner");
		BulletPassByOwner.NativeFieldInfoPtr_BulletPassBySoundPlayEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr, "BulletPassBySoundPlayEvent");
		BulletPassByOwner.NativeFieldInfoPtr_BulletCrackSoundEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr, "BulletCrackSoundEvent");
		BulletPassByOwner.NativeMethodInfoPtr_PlayFlyBy_Public_Void_Vector3_Vector3_Vector3_Vector3_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr, 100665016);
		BulletPassByOwner.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr, 100665017);
	}

	// Token: 0x060014BD RID: 5309 RVA: 0x0000210C File Offset: 0x0000030C
	public BulletPassByOwner(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700070A RID: 1802
	// (get) Token: 0x060014BE RID: 5310 RVA: 0x00054088 File Offset: 0x00052288
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BulletPassByOwner>.NativeClassPtr));
		}
	}

	// Token: 0x1700070B RID: 1803
	// (get) Token: 0x060014BF RID: 5311 RVA: 0x0005409C File Offset: 0x0005229C
	// (set) Token: 0x060014C0 RID: 5312 RVA: 0x000540D0 File Offset: 0x000522D0
	public unsafe WarPlayerScript Owner
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_Owner);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_Owner), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700070C RID: 1804
	// (get) Token: 0x060014C1 RID: 5313 RVA: 0x000540F8 File Offset: 0x000522F8
	// (set) Token: 0x060014C2 RID: 5314 RVA: 0x0005412C File Offset: 0x0005232C
	public unsafe AK.Wwise.Event BulletPassBySoundPlayEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_BulletPassBySoundPlayEvent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_BulletPassBySoundPlayEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700070D RID: 1805
	// (get) Token: 0x060014C3 RID: 5315 RVA: 0x00054154 File Offset: 0x00052354
	// (set) Token: 0x060014C4 RID: 5316 RVA: 0x00054188 File Offset: 0x00052388
	public unsafe AK.Wwise.Event BulletCrackSoundEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_BulletCrackSoundEvent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BulletPassByOwner.NativeFieldInfoPtr_BulletCrackSoundEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04000D3F RID: 3391
	private static readonly IntPtr NativeFieldInfoPtr_Owner;

	// Token: 0x04000D40 RID: 3392
	private static readonly IntPtr NativeFieldInfoPtr_BulletPassBySoundPlayEvent;

	// Token: 0x04000D41 RID: 3393
	private static readonly IntPtr NativeFieldInfoPtr_BulletCrackSoundEvent;

	// Token: 0x04000D42 RID: 3394
	private static readonly IntPtr NativeMethodInfoPtr_PlayFlyBy_Public_Void_Vector3_Vector3_Vector3_Vector3_Boolean_0;

	// Token: 0x04000D43 RID: 3395
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
