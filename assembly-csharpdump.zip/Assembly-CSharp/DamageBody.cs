﻿using System;
using System.Runtime.InteropServices;
using AK.Wwise;
using DPI.Bhaptics;
using DPI.Networking;
using Il2CppSystem;
using Onward.Networking;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000187 RID: 391
public class DamageBody : MonoBehaviour
{
	// Token: 0x06001A0E RID: 6670 RVA: 0x00067D8C File Offset: 0x00065F8C
	[CallerCount(0)]
	public unsafe Faction GetFaction()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_GetFaction_Public_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001A0F RID: 6671 RVA: 0x00067DDC File Offset: 0x00065FDC
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A10 RID: 6672 RVA: 0x00067E20 File Offset: 0x00066020
	[CallerCount(0)]
	public unsafe void ToggleTrigger(bool isTrigger)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref isTrigger;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ToggleTrigger_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A11 RID: 6673 RVA: 0x00067E74 File Offset: 0x00066074
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A12 RID: 6674 RVA: 0x00067EB8 File Offset: 0x000660B8
	[CallerCount(0)]
	public unsafe void ToggleColliders(bool on)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref on;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x17000922 RID: 2338
	// (get) Token: 0x06001A13 RID: 6675 RVA: 0x00067F0C File Offset: 0x0006610C
	public unsafe Collider FirstCollider
	{
		[CallerCount(0)]
		get
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_get_FirstCollider_Public_get_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Collider(intPtr2) : null;
		}
	}

	// Token: 0x06001A14 RID: 6676 RVA: 0x00067F64 File Offset: 0x00066164
	[CallerCount(0)]
	public unsafe void PlayBodyHitSound()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_PlayBodyHitSound_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A15 RID: 6677 RVA: 0x00067FA8 File Offset: 0x000661A8
	[CallerCount(0)]
	public unsafe void PlayArmorHitSound()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_PlayArmorHitSound_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A16 RID: 6678 RVA: 0x00067FEC File Offset: 0x000661EC
	[CallerCount(0)]
	public unsafe void ShowHitEffect(RaycastHit hit, bool armorPiercing)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref hit;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref armorPiercing;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ShowHitEffect_Public_Void_RaycastHit_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A17 RID: 6679 RVA: 0x00068054 File Offset: 0x00066254
	[CallerCount(0)]
	public unsafe void ApplyBodyDamage(float damage, DPIPlayer shooterOwner, [Optional] DamageType damageType, bool isArmorPiercing = false, [Optional] int AISourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref damage;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(shooterOwner);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isArmorPiercing;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref AISourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_DamageType_Boolean_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A18 RID: 6680 RVA: 0x000680FC File Offset: 0x000662FC
	[CallerCount(0)]
	public unsafe void ApplyBodyDamage(float damage, DPIPlayer shooterOwner, Vector3 hitPos, [Optional] DamageType damageType, bool isArmorPiercing = false, [Optional] int AISourceID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref damage;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(shooterOwner);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hitPos;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
		ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isArmorPiercing;
		ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref AISourceID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_Vector3_DamageType_Boolean_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A19 RID: 6681 RVA: 0x000681B4 File Offset: 0x000663B4
	[CallerCount(0)]
	public unsafe float CapAIDamage(float damageToApply)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref damageToApply;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_CapAIDamage_Private_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x06001A1A RID: 6682 RVA: 0x00068218 File Offset: 0x00066418
	[CallerCount(0)]
	public unsafe void ApplyTaserDamage(OnwardPhotonPlayer shooterOwner, int AISourceID, Pickup pickup)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(shooterOwner);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref AISourceID;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(pickup);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_ApplyTaserDamage_Public_Void_OnwardPhotonPlayer_Int32_Pickup_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A1B RID: 6683 RVA: 0x0006829C File Offset: 0x0006649C
	[CallerCount(0)]
	public unsafe void GrenadeApplyBodyDamage(float damage, DPIPlayer shooter, int AISourceID, [Optional] DamageType damageType)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref damage;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(shooter);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref AISourceID;
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_GrenadeApplyBodyDamage_Public_Void_Single_DPIPlayer_Int32_DamageType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A1C RID: 6684 RVA: 0x00068330 File Offset: 0x00066530
	[CallerCount(0)]
	public unsafe BhapticsVestBounds GetBhapticsReference()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr_GetBhapticsReference_Public_BhapticsVestBounds_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new BhapticsVestBounds(intPtr2) : null;
	}

	// Token: 0x06001A1D RID: 6685 RVA: 0x00068388 File Offset: 0x00066588
	[CallerCount(0)]
	public unsafe DamageBody() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageBody>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBody.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A1E RID: 6686 RVA: 0x000683D4 File Offset: 0x000665D4
	// Note: this type is marked as 'beforefieldinit'.
	static DamageBody()
	{
		Il2CppClassPointerStore<DamageBody>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageBody");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageBody>.NativeClassPtr);
		DamageBody.NativeFieldInfoPtr_MultiplierLimb = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "MultiplierLimb");
		DamageBody.NativeFieldInfoPtr_MultiplierBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "MultiplierBody");
		DamageBody.NativeFieldInfoPtr_MultiplierUpperBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "MultiplierUpperBody");
		DamageBody.NativeFieldInfoPtr_MultiplierHead = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "MultiplierHead");
		DamageBody.NativeFieldInfoPtr_playerType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "playerType");
		DamageBody.NativeFieldInfoPtr_Limb = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Limb");
		DamageBody.NativeFieldInfoPtr_Body = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Body");
		DamageBody.NativeFieldInfoPtr_Upper = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Upper");
		DamageBody.NativeFieldInfoPtr_Head = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Head");
		DamageBody.NativeFieldInfoPtr_Armor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Armor");
		DamageBody.NativeFieldInfoPtr_CurrentAIArmorHealth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "CurrentAIArmorHealth");
		DamageBody.NativeFieldInfoPtr_Controller = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "Controller");
		DamageBody.NativeFieldInfoPtr_OverrideController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "OverrideController");
		DamageBody.NativeFieldInfoPtr_ArmorMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "ArmorMaterial");
		DamageBody.NativeFieldInfoPtr_WarPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "WarPlayer");
		DamageBody.NativeFieldInfoPtr_AIPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "AIPlayer");
		DamageBody.NativeFieldInfoPtr_BodyPart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "BodyPart");
		DamageBody.NativeFieldInfoPtr_HitSoundPlayEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "HitSoundPlayEvent");
		DamageBody.NativeFieldInfoPtr_BodyHitSoundBulletMaterialSwitch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "BodyHitSoundBulletMaterialSwitch");
		DamageBody.NativeFieldInfoPtr_ArmorHitSoundBulletMaterialSwitch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "ArmorHitSoundBulletMaterialSwitch");
		DamageBody.NativeFieldInfoPtr_SoundPlaybackMaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "SoundPlaybackMaxDistance");
		DamageBody.NativeFieldInfoPtr_BodyHitSounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "BodyHitSounds");
		DamageBody.NativeFieldInfoPtr_ArmorHitSounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "ArmorHitSounds");
		DamageBody.NativeFieldInfoPtr_RigidBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "RigidBody");
		DamageBody.NativeFieldInfoPtr_SightWeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "SightWeight");
		DamageBody.NativeFieldInfoPtr_CachedColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, "CachedColliders");
		DamageBody.NativeMethodInfoPtr_GetFaction_Public_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665372);
		DamageBody.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665373);
		DamageBody.NativeMethodInfoPtr_ToggleTrigger_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665374);
		DamageBody.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665375);
		DamageBody.NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665376);
		DamageBody.NativeMethodInfoPtr_get_FirstCollider_Public_get_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665377);
		DamageBody.NativeMethodInfoPtr_PlayBodyHitSound_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665378);
		DamageBody.NativeMethodInfoPtr_PlayArmorHitSound_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665379);
		DamageBody.NativeMethodInfoPtr_ShowHitEffect_Public_Void_RaycastHit_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665380);
		DamageBody.NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_DamageType_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665381);
		DamageBody.NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_Vector3_DamageType_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665382);
		DamageBody.NativeMethodInfoPtr_CapAIDamage_Private_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665383);
		DamageBody.NativeMethodInfoPtr_ApplyTaserDamage_Public_Void_OnwardPhotonPlayer_Int32_Pickup_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665384);
		DamageBody.NativeMethodInfoPtr_GrenadeApplyBodyDamage_Public_Void_Single_DPIPlayer_Int32_DamageType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665385);
		DamageBody.NativeMethodInfoPtr_GetBhapticsReference_Public_BhapticsVestBounds_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665386);
		DamageBody.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBody>.NativeClassPtr, 100665387);
	}

	// Token: 0x06001A1F RID: 6687 RVA: 0x0000210C File Offset: 0x0000030C
	public DamageBody(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000907 RID: 2311
	// (get) Token: 0x06001A20 RID: 6688 RVA: 0x0006874C File Offset: 0x0006694C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Il2CppSystem.Type Il2CppType
	{
		get
		{
			return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageBody>.NativeClassPtr));
		}
	}

	// Token: 0x17000908 RID: 2312
	// (get) Token: 0x06001A21 RID: 6689 RVA: 0x00068760 File Offset: 0x00066960
	// (set) Token: 0x06001A22 RID: 6690 RVA: 0x0006877E File Offset: 0x0006697E
	public unsafe static float MultiplierLimb
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(DamageBody.NativeFieldInfoPtr_MultiplierLimb, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBody.NativeFieldInfoPtr_MultiplierLimb, (void*)(&value));
		}
	}

	// Token: 0x17000909 RID: 2313
	// (get) Token: 0x06001A23 RID: 6691 RVA: 0x00068790 File Offset: 0x00066990
	// (set) Token: 0x06001A24 RID: 6692 RVA: 0x000687AE File Offset: 0x000669AE
	public unsafe static float MultiplierBody
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(DamageBody.NativeFieldInfoPtr_MultiplierBody, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBody.NativeFieldInfoPtr_MultiplierBody, (void*)(&value));
		}
	}

	// Token: 0x1700090A RID: 2314
	// (get) Token: 0x06001A25 RID: 6693 RVA: 0x000687C0 File Offset: 0x000669C0
	// (set) Token: 0x06001A26 RID: 6694 RVA: 0x000687DE File Offset: 0x000669DE
	public unsafe static float MultiplierUpperBody
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(DamageBody.NativeFieldInfoPtr_MultiplierUpperBody, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBody.NativeFieldInfoPtr_MultiplierUpperBody, (void*)(&value));
		}
	}

	// Token: 0x1700090B RID: 2315
	// (get) Token: 0x06001A27 RID: 6695 RVA: 0x000687F0 File Offset: 0x000669F0
	// (set) Token: 0x06001A28 RID: 6696 RVA: 0x0006880E File Offset: 0x00066A0E
	public unsafe static float MultiplierHead
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(DamageBody.NativeFieldInfoPtr_MultiplierHead, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBody.NativeFieldInfoPtr_MultiplierHead, (void*)(&value));
		}
	}

	// Token: 0x1700090C RID: 2316
	// (get) Token: 0x06001A29 RID: 6697 RVA: 0x00068820 File Offset: 0x00066A20
	// (set) Token: 0x06001A2A RID: 6698 RVA: 0x00068848 File Offset: 0x00066A48
	public unsafe DamageBody.Type playerType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_playerType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_playerType)) = value;
		}
	}

	// Token: 0x1700090D RID: 2317
	// (get) Token: 0x06001A2B RID: 6699 RVA: 0x0006886C File Offset: 0x00066A6C
	// (set) Token: 0x06001A2C RID: 6700 RVA: 0x00068894 File Offset: 0x00066A94
	public unsafe bool Limb
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Limb);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Limb)) = value;
		}
	}

	// Token: 0x1700090E RID: 2318
	// (get) Token: 0x06001A2D RID: 6701 RVA: 0x000688B8 File Offset: 0x00066AB8
	// (set) Token: 0x06001A2E RID: 6702 RVA: 0x000688E0 File Offset: 0x00066AE0
	public unsafe bool Body
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Body);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Body)) = value;
		}
	}

	// Token: 0x1700090F RID: 2319
	// (get) Token: 0x06001A2F RID: 6703 RVA: 0x00068904 File Offset: 0x00066B04
	// (set) Token: 0x06001A30 RID: 6704 RVA: 0x0006892C File Offset: 0x00066B2C
	public unsafe bool Upper
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Upper);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Upper)) = value;
		}
	}

	// Token: 0x17000910 RID: 2320
	// (get) Token: 0x06001A31 RID: 6705 RVA: 0x00068950 File Offset: 0x00066B50
	// (set) Token: 0x06001A32 RID: 6706 RVA: 0x00068978 File Offset: 0x00066B78
	public unsafe bool Head
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Head);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Head)) = value;
		}
	}

	// Token: 0x17000911 RID: 2321
	// (get) Token: 0x06001A33 RID: 6707 RVA: 0x0006899C File Offset: 0x00066B9C
	// (set) Token: 0x06001A34 RID: 6708 RVA: 0x000689C4 File Offset: 0x00066BC4
	public unsafe bool Armor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Armor);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Armor)) = value;
		}
	}

	// Token: 0x17000912 RID: 2322
	// (get) Token: 0x06001A35 RID: 6709 RVA: 0x000689E8 File Offset: 0x00066BE8
	// (set) Token: 0x06001A36 RID: 6710 RVA: 0x00068A10 File Offset: 0x00066C10
	public unsafe float CurrentAIArmorHealth
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_CurrentAIArmorHealth);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_CurrentAIArmorHealth)) = value;
		}
	}

	// Token: 0x17000913 RID: 2323
	// (get) Token: 0x06001A37 RID: 6711 RVA: 0x00068A34 File Offset: 0x00066C34
	// (set) Token: 0x06001A38 RID: 6712 RVA: 0x00068A68 File Offset: 0x00066C68
	public unsafe DamageController Controller
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Controller);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_Controller), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000914 RID: 2324
	// (get) Token: 0x06001A39 RID: 6713 RVA: 0x00068A90 File Offset: 0x00066C90
	// (set) Token: 0x06001A3A RID: 6714 RVA: 0x00068AC4 File Offset: 0x00066CC4
	public unsafe DamageController OverrideController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_OverrideController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_OverrideController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000915 RID: 2325
	// (get) Token: 0x06001A3B RID: 6715 RVA: 0x00068AEC File Offset: 0x00066CEC
	// (set) Token: 0x06001A3C RID: 6716 RVA: 0x00068B14 File Offset: 0x00066D14
	public unsafe DamageLibrary.MaterialType ArmorMaterial
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorMaterial);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorMaterial)) = value;
		}
	}

	// Token: 0x17000916 RID: 2326
	// (get) Token: 0x06001A3D RID: 6717 RVA: 0x00068B38 File Offset: 0x00066D38
	// (set) Token: 0x06001A3E RID: 6718 RVA: 0x00068B6C File Offset: 0x00066D6C
	public unsafe WarPlayerScript WarPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_WarPlayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_WarPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000917 RID: 2327
	// (get) Token: 0x06001A3F RID: 6719 RVA: 0x00068B94 File Offset: 0x00066D94
	// (set) Token: 0x06001A40 RID: 6720 RVA: 0x00068BC8 File Offset: 0x00066DC8
	public unsafe HumanoidAI AIPlayer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_AIPlayer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_AIPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000918 RID: 2328
	// (get) Token: 0x06001A41 RID: 6721 RVA: 0x00068BF0 File Offset: 0x00066DF0
	// (set) Token: 0x06001A42 RID: 6722 RVA: 0x00068C18 File Offset: 0x00066E18
	public unsafe BodyParts BodyPart
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyPart);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyPart)) = value;
		}
	}

	// Token: 0x17000919 RID: 2329
	// (get) Token: 0x06001A43 RID: 6723 RVA: 0x00068C3C File Offset: 0x00066E3C
	// (set) Token: 0x06001A44 RID: 6724 RVA: 0x00068C70 File Offset: 0x00066E70
	public unsafe AK.Wwise.Event HitSoundPlayEvent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_HitSoundPlayEvent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_HitSoundPlayEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700091A RID: 2330
	// (get) Token: 0x06001A45 RID: 6725 RVA: 0x00068C98 File Offset: 0x00066E98
	// (set) Token: 0x06001A46 RID: 6726 RVA: 0x00068CCC File Offset: 0x00066ECC
	public unsafe Switch BodyHitSoundBulletMaterialSwitch
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyHitSoundBulletMaterialSwitch);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Switch(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyHitSoundBulletMaterialSwitch), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700091B RID: 2331
	// (get) Token: 0x06001A47 RID: 6727 RVA: 0x00068CF4 File Offset: 0x00066EF4
	// (set) Token: 0x06001A48 RID: 6728 RVA: 0x00068D28 File Offset: 0x00066F28
	public unsafe Switch ArmorHitSoundBulletMaterialSwitch
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorHitSoundBulletMaterialSwitch);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Switch(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorHitSoundBulletMaterialSwitch), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700091C RID: 2332
	// (get) Token: 0x06001A49 RID: 6729 RVA: 0x00068D50 File Offset: 0x00066F50
	// (set) Token: 0x06001A4A RID: 6730 RVA: 0x00068D78 File Offset: 0x00066F78
	public unsafe float SoundPlaybackMaxDistance
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_SoundPlaybackMaxDistance);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_SoundPlaybackMaxDistance)) = value;
		}
	}

	// Token: 0x1700091D RID: 2333
	// (get) Token: 0x06001A4B RID: 6731 RVA: 0x00068D9C File Offset: 0x00066F9C
	// (set) Token: 0x06001A4C RID: 6732 RVA: 0x00068DD0 File Offset: 0x00066FD0
	public unsafe Il2CppReferenceArray<AudioClip> BodyHitSounds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyHitSounds);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<AudioClip>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_BodyHitSounds), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700091E RID: 2334
	// (get) Token: 0x06001A4D RID: 6733 RVA: 0x00068DF8 File Offset: 0x00066FF8
	// (set) Token: 0x06001A4E RID: 6734 RVA: 0x00068E2C File Offset: 0x0006702C
	public unsafe Il2CppReferenceArray<AudioClip> ArmorHitSounds
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorHitSounds);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<AudioClip>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_ArmorHitSounds), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700091F RID: 2335
	// (get) Token: 0x06001A4F RID: 6735 RVA: 0x00068E54 File Offset: 0x00067054
	// (set) Token: 0x06001A50 RID: 6736 RVA: 0x00068E88 File Offset: 0x00067088
	public unsafe Rigidbody RigidBody
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_RigidBody);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_RigidBody), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000920 RID: 2336
	// (get) Token: 0x06001A51 RID: 6737 RVA: 0x00068EB0 File Offset: 0x000670B0
	// (set) Token: 0x06001A52 RID: 6738 RVA: 0x00068ED8 File Offset: 0x000670D8
	public unsafe float SightWeight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_SightWeight);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_SightWeight)) = value;
		}
	}

	// Token: 0x17000921 RID: 2337
	// (get) Token: 0x06001A53 RID: 6739 RVA: 0x00068EFC File Offset: 0x000670FC
	// (set) Token: 0x06001A54 RID: 6740 RVA: 0x00068F30 File Offset: 0x00067130
	public unsafe Il2CppReferenceArray<Collider> CachedColliders
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_CachedColliders);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Collider>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBody.NativeFieldInfoPtr_CachedColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040010B3 RID: 4275
	private static readonly IntPtr NativeFieldInfoPtr_MultiplierLimb;

	// Token: 0x040010B4 RID: 4276
	private static readonly IntPtr NativeFieldInfoPtr_MultiplierBody;

	// Token: 0x040010B5 RID: 4277
	private static readonly IntPtr NativeFieldInfoPtr_MultiplierUpperBody;

	// Token: 0x040010B6 RID: 4278
	private static readonly IntPtr NativeFieldInfoPtr_MultiplierHead;

	// Token: 0x040010B7 RID: 4279
	private static readonly IntPtr NativeFieldInfoPtr_playerType;

	// Token: 0x040010B8 RID: 4280
	private static readonly IntPtr NativeFieldInfoPtr_Limb;

	// Token: 0x040010B9 RID: 4281
	private static readonly IntPtr NativeFieldInfoPtr_Body;

	// Token: 0x040010BA RID: 4282
	private static readonly IntPtr NativeFieldInfoPtr_Upper;

	// Token: 0x040010BB RID: 4283
	private static readonly IntPtr NativeFieldInfoPtr_Head;

	// Token: 0x040010BC RID: 4284
	private static readonly IntPtr NativeFieldInfoPtr_Armor;

	// Token: 0x040010BD RID: 4285
	private static readonly IntPtr NativeFieldInfoPtr_CurrentAIArmorHealth;

	// Token: 0x040010BE RID: 4286
	private static readonly IntPtr NativeFieldInfoPtr_Controller;

	// Token: 0x040010BF RID: 4287
	private static readonly IntPtr NativeFieldInfoPtr_OverrideController;

	// Token: 0x040010C0 RID: 4288
	private static readonly IntPtr NativeFieldInfoPtr_ArmorMaterial;

	// Token: 0x040010C1 RID: 4289
	private static readonly IntPtr NativeFieldInfoPtr_WarPlayer;

	// Token: 0x040010C2 RID: 4290
	private static readonly IntPtr NativeFieldInfoPtr_AIPlayer;

	// Token: 0x040010C3 RID: 4291
	private static readonly IntPtr NativeFieldInfoPtr_BodyPart;

	// Token: 0x040010C4 RID: 4292
	private static readonly IntPtr NativeFieldInfoPtr_HitSoundPlayEvent;

	// Token: 0x040010C5 RID: 4293
	private static readonly IntPtr NativeFieldInfoPtr_BodyHitSoundBulletMaterialSwitch;

	// Token: 0x040010C6 RID: 4294
	private static readonly IntPtr NativeFieldInfoPtr_ArmorHitSoundBulletMaterialSwitch;

	// Token: 0x040010C7 RID: 4295
	private static readonly IntPtr NativeFieldInfoPtr_SoundPlaybackMaxDistance;

	// Token: 0x040010C8 RID: 4296
	private static readonly IntPtr NativeFieldInfoPtr_BodyHitSounds;

	// Token: 0x040010C9 RID: 4297
	private static readonly IntPtr NativeFieldInfoPtr_ArmorHitSounds;

	// Token: 0x040010CA RID: 4298
	private static readonly IntPtr NativeFieldInfoPtr_RigidBody;

	// Token: 0x040010CB RID: 4299
	private static readonly IntPtr NativeFieldInfoPtr_SightWeight;

	// Token: 0x040010CC RID: 4300
	private static readonly IntPtr NativeFieldInfoPtr_CachedColliders;

	// Token: 0x040010CD RID: 4301
	private static readonly IntPtr NativeMethodInfoPtr_GetFaction_Public_Faction_0;

	// Token: 0x040010CE RID: 4302
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x040010CF RID: 4303
	private static readonly IntPtr NativeMethodInfoPtr_ToggleTrigger_Public_Void_Boolean_0;

	// Token: 0x040010D0 RID: 4304
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x040010D1 RID: 4305
	private static readonly IntPtr NativeMethodInfoPtr_ToggleColliders_Public_Void_Boolean_0;

	// Token: 0x040010D2 RID: 4306
	private static readonly IntPtr NativeMethodInfoPtr_get_FirstCollider_Public_get_Collider_0;

	// Token: 0x040010D3 RID: 4307
	private static readonly IntPtr NativeMethodInfoPtr_PlayBodyHitSound_Public_Void_0;

	// Token: 0x040010D4 RID: 4308
	private static readonly IntPtr NativeMethodInfoPtr_PlayArmorHitSound_Public_Void_0;

	// Token: 0x040010D5 RID: 4309
	private static readonly IntPtr NativeMethodInfoPtr_ShowHitEffect_Public_Void_RaycastHit_Boolean_0;

	// Token: 0x040010D6 RID: 4310
	private static readonly IntPtr NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_DamageType_Boolean_Int32_0;

	// Token: 0x040010D7 RID: 4311
	private static readonly IntPtr NativeMethodInfoPtr_ApplyBodyDamage_Public_Void_Single_DPIPlayer_Vector3_DamageType_Boolean_Int32_0;

	// Token: 0x040010D8 RID: 4312
	private static readonly IntPtr NativeMethodInfoPtr_CapAIDamage_Private_Single_Single_0;

	// Token: 0x040010D9 RID: 4313
	private static readonly IntPtr NativeMethodInfoPtr_ApplyTaserDamage_Public_Void_OnwardPhotonPlayer_Int32_Pickup_0;

	// Token: 0x040010DA RID: 4314
	private static readonly IntPtr NativeMethodInfoPtr_GrenadeApplyBodyDamage_Public_Void_Single_DPIPlayer_Int32_DamageType_0;

	// Token: 0x040010DB RID: 4315
	private static readonly IntPtr NativeMethodInfoPtr_GetBhapticsReference_Public_BhapticsVestBounds_0;

	// Token: 0x040010DC RID: 4316
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000188 RID: 392
	public enum Type
	{
		// Token: 0x040010DE RID: 4318
		HumanPlayer,
		// Token: 0x040010DF RID: 4319
		AI,
		// Token: 0x040010E0 RID: 4320
		NULL
	}
}
