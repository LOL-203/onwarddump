﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems.Objectives
{
	// Token: 0x02000E85 RID: 3717
	public class TrackPlayerObjective : AIObjective
	{
		// Token: 0x06011DDA RID: 73178 RVA: 0x00472440 File Offset: 0x00470640
		[CallerCount(0)]
		public new unsafe void CreateObjective(Il2CppSystem.Object target, int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), TrackPlayerObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DDB RID: 73179 RVA: 0x004724B8 File Offset: 0x004706B8
		[CallerCount(0)]
		public new unsafe Vector3 Position()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), TrackPlayerObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011DDC RID: 73180 RVA: 0x00472514 File Offset: 0x00470714
		[CallerCount(0)]
		public unsafe TrackPlayerObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TrackPlayerObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DDD RID: 73181 RVA: 0x00472560 File Offset: 0x00470760
		// Note: this type is marked as 'beforefieldinit'.
		static TrackPlayerObjective()
		{
			Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "TrackPlayerObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr);
			TrackPlayerObjective.NativeFieldInfoPtr_TargetPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr, "TargetPlayer");
			TrackPlayerObjective.NativeFieldInfoPtr__transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr, "_transform");
			TrackPlayerObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr, 100685648);
			TrackPlayerObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr, 100685649);
			TrackPlayerObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr, 100685650);
		}

		// Token: 0x06011DDE RID: 73182 RVA: 0x004713FC File Offset: 0x0046F5FC
		public TrackPlayerObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065E8 RID: 26088
		// (get) Token: 0x06011DDF RID: 73183 RVA: 0x004725F4 File Offset: 0x004707F4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TrackPlayerObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170065E9 RID: 26089
		// (get) Token: 0x06011DE0 RID: 73184 RVA: 0x00472608 File Offset: 0x00470808
		// (set) Token: 0x06011DE1 RID: 73185 RVA: 0x0047263C File Offset: 0x0047083C
		public unsafe WarPlayerScript TargetPlayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TrackPlayerObjective.NativeFieldInfoPtr_TargetPlayer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WarPlayerScript(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(TrackPlayerObjective.NativeFieldInfoPtr_TargetPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170065EA RID: 26090
		// (get) Token: 0x06011DE2 RID: 73186 RVA: 0x00472664 File Offset: 0x00470864
		// (set) Token: 0x06011DE3 RID: 73187 RVA: 0x00472698 File Offset: 0x00470898
		public unsafe Transform _transform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TrackPlayerObjective.NativeFieldInfoPtr__transform);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(TrackPlayerObjective.NativeFieldInfoPtr__transform), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B596 RID: 46486
		private static readonly IntPtr NativeFieldInfoPtr_TargetPlayer;

		// Token: 0x0400B597 RID: 46487
		private static readonly IntPtr NativeFieldInfoPtr__transform;

		// Token: 0x0400B598 RID: 46488
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0;

		// Token: 0x0400B599 RID: 46489
		private static readonly IntPtr NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0;

		// Token: 0x0400B59A RID: 46490
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
