﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using _Game.GameVariants.Objectives;

namespace AISystems.Objectives
{
	// Token: 0x02000E7F RID: 3711
	public class AIUplinkObjective : AIObjective
	{
		// Token: 0x06011DB9 RID: 73145 RVA: 0x00471BF8 File Offset: 0x0046FDF8
		[CallerCount(0)]
		public new unsafe void CreateObjective(Il2CppSystem.Object target, int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIUplinkObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DBA RID: 73146 RVA: 0x00471C70 File Offset: 0x0046FE70
		[CallerCount(0)]
		public new unsafe Vector3 Position()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIUplinkObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011DBB RID: 73147 RVA: 0x00471CCC File Offset: 0x0046FECC
		[CallerCount(0)]
		public unsafe AIUplinkObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUplinkObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DBC RID: 73148 RVA: 0x00471D18 File Offset: 0x0046FF18
		// Note: this type is marked as 'beforefieldinit'.
		static AIUplinkObjective()
		{
			Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "AIUplinkObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr);
			AIUplinkObjective.NativeFieldInfoPtr__uplinkObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr, "_uplinkObjective");
			AIUplinkObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr, 100685637);
			AIUplinkObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr, 100685638);
			AIUplinkObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr, 100685639);
		}

		// Token: 0x06011DBD RID: 73149 RVA: 0x004713FC File Offset: 0x0046F5FC
		public AIUplinkObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065E0 RID: 26080
		// (get) Token: 0x06011DBE RID: 73150 RVA: 0x00471D98 File Offset: 0x0046FF98
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIUplinkObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170065E1 RID: 26081
		// (get) Token: 0x06011DBF RID: 73151 RVA: 0x00471DAC File Offset: 0x0046FFAC
		// (set) Token: 0x06011DC0 RID: 73152 RVA: 0x00471DE0 File Offset: 0x0046FFE0
		public unsafe UplinkObjective _uplinkObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIUplinkObjective.NativeFieldInfoPtr__uplinkObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UplinkObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIUplinkObjective.NativeFieldInfoPtr__uplinkObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B583 RID: 46467
		private static readonly IntPtr NativeFieldInfoPtr__uplinkObjective;

		// Token: 0x0400B584 RID: 46468
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0;

		// Token: 0x0400B585 RID: 46469
		private static readonly IntPtr NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0;

		// Token: 0x0400B586 RID: 46470
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
