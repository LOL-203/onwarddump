﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems.Objectives
{
	// Token: 0x02000E80 RID: 3712
	public class EvacHelicopterObjective : AIObjective
	{
		// Token: 0x06011DC1 RID: 73153 RVA: 0x00471E08 File Offset: 0x00470008
		[CallerCount(0)]
		public new unsafe void CreateObjective(Il2CppSystem.Object target, int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacHelicopterObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DC2 RID: 73154 RVA: 0x00471E80 File Offset: 0x00470080
		[CallerCount(0)]
		public new unsafe Vector3 Position()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacHelicopterObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011DC3 RID: 73155 RVA: 0x00471EDC File Offset: 0x004700DC
		[CallerCount(0)]
		public unsafe EvacHelicopterObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacHelicopterObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DC4 RID: 73156 RVA: 0x00471F28 File Offset: 0x00470128
		// Note: this type is marked as 'beforefieldinit'.
		static EvacHelicopterObjective()
		{
			Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "EvacHelicopterObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr);
			EvacHelicopterObjective.NativeFieldInfoPtr_DefendRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr, "DefendRadius");
			EvacHelicopterObjective.NativeFieldInfoPtr__helicopter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr, "_helicopter");
			EvacHelicopterObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr, 100685640);
			EvacHelicopterObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr, 100685641);
			EvacHelicopterObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr, 100685642);
		}

		// Token: 0x06011DC5 RID: 73157 RVA: 0x004713FC File Offset: 0x0046F5FC
		public EvacHelicopterObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065E2 RID: 26082
		// (get) Token: 0x06011DC6 RID: 73158 RVA: 0x00471FBC File Offset: 0x004701BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<EvacHelicopterObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170065E3 RID: 26083
		// (get) Token: 0x06011DC7 RID: 73159 RVA: 0x00471FD0 File Offset: 0x004701D0
		// (set) Token: 0x06011DC8 RID: 73160 RVA: 0x00471FF8 File Offset: 0x004701F8
		public unsafe float DefendRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacHelicopterObjective.NativeFieldInfoPtr_DefendRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacHelicopterObjective.NativeFieldInfoPtr_DefendRadius)) = value;
			}
		}

		// Token: 0x170065E4 RID: 26084
		// (get) Token: 0x06011DC9 RID: 73161 RVA: 0x0047201C File Offset: 0x0047021C
		// (set) Token: 0x06011DCA RID: 73162 RVA: 0x00472050 File Offset: 0x00470250
		public unsafe AIDefendObjective _helicopter
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacHelicopterObjective.NativeFieldInfoPtr__helicopter);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacHelicopterObjective.NativeFieldInfoPtr__helicopter), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B587 RID: 46471
		private static readonly IntPtr NativeFieldInfoPtr_DefendRadius;

		// Token: 0x0400B588 RID: 46472
		private static readonly IntPtr NativeFieldInfoPtr__helicopter;

		// Token: 0x0400B589 RID: 46473
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0;

		// Token: 0x0400B58A RID: 46474
		private static readonly IntPtr NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0;

		// Token: 0x0400B58B RID: 46475
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
