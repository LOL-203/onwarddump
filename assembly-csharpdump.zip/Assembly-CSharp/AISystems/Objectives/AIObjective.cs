﻿using System;
using DPI.AISystems;
using DPI.Data;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems.Objectives
{
	// Token: 0x02000E7D RID: 3709
	public class AIObjective : BaseData
	{
		// Token: 0x06011D9D RID: 73117 RVA: 0x00471474 File Offset: 0x0046F674
		[CallerCount(0)]
		public unsafe void CreateObjective(Il2CppSystem.Object target, int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_New_Void_Object_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D9E RID: 73118 RVA: 0x004714EC File Offset: 0x0046F6EC
		[CallerCount(0)]
		public unsafe void SetMaxDefenders(int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIObjective.NativeMethodInfoPtr_SetMaxDefenders_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D9F RID: 73119 RVA: 0x00471540 File Offset: 0x0046F740
		[CallerCount(0)]
		public unsafe Vector3 Position()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIObjective.NativeMethodInfoPtr_Position_Public_Virtual_New_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011DA0 RID: 73120 RVA: 0x0047159C File Offset: 0x0046F79C
		[CallerCount(0)]
		public unsafe bool IsOpenToDefenders(HumanoidAI ai)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ai);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIObjective.NativeMethodInfoPtr_IsOpenToDefenders_Public_Boolean_HumanoidAI_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011DA1 RID: 73121 RVA: 0x00471604 File Offset: 0x0046F804
		[CallerCount(0)]
		public unsafe void AddDefendingAI(HumanoidAI ai)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ai);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIObjective.NativeMethodInfoPtr_AddDefendingAI_Public_Void_HumanoidAI_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DA2 RID: 73122 RVA: 0x00471660 File Offset: 0x0046F860
		[CallerCount(0)]
		public unsafe void RemoveDefendingAI(HumanoidAI ai)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ai);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIObjective.NativeMethodInfoPtr_RemoveDefendingAI_Public_Void_HumanoidAI_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DA3 RID: 73123 RVA: 0x004716BC File Offset: 0x0046F8BC
		[CallerCount(0)]
		public unsafe AIObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DA4 RID: 73124 RVA: 0x00471708 File Offset: 0x0046F908
		// Note: this type is marked as 'beforefieldinit'.
		static AIObjective()
		{
			Il2CppClassPointerStore<AIObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "AIObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIObjective>.NativeClassPtr);
			AIObjective.NativeFieldInfoPtr_AssignedState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, "AssignedState");
			AIObjective.NativeFieldInfoPtr_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, "Target");
			AIObjective.NativeFieldInfoPtr_Priority = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, "Priority");
			AIObjective.NativeFieldInfoPtr__maxAIDefenders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, "_maxAIDefenders");
			AIObjective.NativeFieldInfoPtr__defendingAI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, "_defendingAI");
			AIObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_New_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685627);
			AIObjective.NativeMethodInfoPtr_SetMaxDefenders_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685628);
			AIObjective.NativeMethodInfoPtr_Position_Public_Virtual_New_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685629);
			AIObjective.NativeMethodInfoPtr_IsOpenToDefenders_Public_Boolean_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685630);
			AIObjective.NativeMethodInfoPtr_AddDefendingAI_Public_Void_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685631);
			AIObjective.NativeMethodInfoPtr_RemoveDefendingAI_Public_Void_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685632);
			AIObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIObjective>.NativeClassPtr, 100685633);
		}

		// Token: 0x06011DA5 RID: 73125 RVA: 0x000AD628 File Offset: 0x000AB828
		public AIObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065D8 RID: 26072
		// (get) Token: 0x06011DA6 RID: 73126 RVA: 0x00471828 File Offset: 0x0046FA28
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170065D9 RID: 26073
		// (get) Token: 0x06011DA7 RID: 73127 RVA: 0x0047183C File Offset: 0x0046FA3C
		// (set) Token: 0x06011DA8 RID: 73128 RVA: 0x00471870 File Offset: 0x0046FA70
		public unsafe AIState AssignedState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_AssignedState);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIState(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_AssignedState), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170065DA RID: 26074
		// (get) Token: 0x06011DA9 RID: 73129 RVA: 0x00471898 File Offset: 0x0046FA98
		// (set) Token: 0x06011DAA RID: 73130 RVA: 0x004718CC File Offset: 0x0046FACC
		public unsafe Il2CppSystem.Object Target
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_Target);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170065DB RID: 26075
		// (get) Token: 0x06011DAB RID: 73131 RVA: 0x004718F4 File Offset: 0x0046FAF4
		// (set) Token: 0x06011DAC RID: 73132 RVA: 0x0047191C File Offset: 0x0046FB1C
		public unsafe int Priority
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_Priority);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr_Priority)) = value;
			}
		}

		// Token: 0x170065DC RID: 26076
		// (get) Token: 0x06011DAD RID: 73133 RVA: 0x00471940 File Offset: 0x0046FB40
		// (set) Token: 0x06011DAE RID: 73134 RVA: 0x00471968 File Offset: 0x0046FB68
		public unsafe float _maxAIDefenders
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr__maxAIDefenders);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr__maxAIDefenders)) = value;
			}
		}

		// Token: 0x170065DD RID: 26077
		// (get) Token: 0x06011DAF RID: 73135 RVA: 0x0047198C File Offset: 0x0046FB8C
		// (set) Token: 0x06011DB0 RID: 73136 RVA: 0x004719C0 File Offset: 0x0046FBC0
		public unsafe HashSet<HumanoidAI> _defendingAI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr__defendingAI);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HashSet<HumanoidAI>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIObjective.NativeFieldInfoPtr__defendingAI), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B573 RID: 46451
		private static readonly IntPtr NativeFieldInfoPtr_AssignedState;

		// Token: 0x0400B574 RID: 46452
		private static readonly IntPtr NativeFieldInfoPtr_Target;

		// Token: 0x0400B575 RID: 46453
		private static readonly IntPtr NativeFieldInfoPtr_Priority;

		// Token: 0x0400B576 RID: 46454
		private static readonly IntPtr NativeFieldInfoPtr__maxAIDefenders;

		// Token: 0x0400B577 RID: 46455
		private static readonly IntPtr NativeFieldInfoPtr__defendingAI;

		// Token: 0x0400B578 RID: 46456
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Virtual_New_Void_Object_Int32_0;

		// Token: 0x0400B579 RID: 46457
		private static readonly IntPtr NativeMethodInfoPtr_SetMaxDefenders_Public_Void_Int32_0;

		// Token: 0x0400B57A RID: 46458
		private static readonly IntPtr NativeMethodInfoPtr_Position_Public_Virtual_New_Vector3_0;

		// Token: 0x0400B57B RID: 46459
		private static readonly IntPtr NativeMethodInfoPtr_IsOpenToDefenders_Public_Boolean_HumanoidAI_0;

		// Token: 0x0400B57C RID: 46460
		private static readonly IntPtr NativeMethodInfoPtr_AddDefendingAI_Public_Void_HumanoidAI_0;

		// Token: 0x0400B57D RID: 46461
		private static readonly IntPtr NativeMethodInfoPtr_RemoveDefendingAI_Public_Void_HumanoidAI_0;

		// Token: 0x0400B57E RID: 46462
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
