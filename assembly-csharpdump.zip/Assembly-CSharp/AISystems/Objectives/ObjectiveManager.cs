﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems.Objectives
{
	// Token: 0x02000E81 RID: 3713
	public static class ObjectiveManager : Il2CppSystem.Object
	{
		// Token: 0x06011DCB RID: 73163 RVA: 0x00472078 File Offset: 0x00470278
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObjectiveManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DCC RID: 73164 RVA: 0x004720AC File Offset: 0x004702AC
		[CallerCount(0)]
		public unsafe static void Uninitialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObjectiveManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DCD RID: 73165 RVA: 0x004720E0 File Offset: 0x004702E0
		[CallerCount(0)]
		public unsafe static T CreateObjective<T>(UnityEngine.Object target, int maxDefenders) where T : AIObjective
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDefenders;
			IntPtr returnedException;
			IntPtr objectPointer = IL2CPP.il2cpp_runtime_invoke(ObjectiveManager.MethodInfoStoreGeneric_CreateObjective_Public_Static_T_Object_Int32_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.PointerToValueGeneric<T>(objectPointer, false, true);
		}

		// Token: 0x06011DCE RID: 73166 RVA: 0x00472148 File Offset: 0x00470348
		[CallerCount(0)]
		public unsafe static void RemoveObjective<T>(UnityEngine.Object target) where T : AIObjective
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObjectiveManager.MethodInfoStoreGeneric_RemoveObjective_Public_Static_Void_Object_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DCF RID: 73167 RVA: 0x00472194 File Offset: 0x00470394
		[CallerCount(0)]
		public unsafe static void SetDefenderCount<T>(UnityEngine.Object target, int maxAIDefenders) where T : AIObjective
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObjectiveManager.MethodInfoStoreGeneric_SetDefenderCount_Public_Static_Void_Object_Int32_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011DD0 RID: 73168 RVA: 0x004721F4 File Offset: 0x004703F4
		// Note: this type is marked as 'beforefieldinit'.
		static ObjectiveManager()
		{
			Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "ObjectiveManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr);
			ObjectiveManager.NativeFieldInfoPtr_ObjectivesByType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, "ObjectivesByType");
			ObjectiveManager.NativeFieldInfoPtr_AllObjectives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, "AllObjectives");
			ObjectiveManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, 100685643);
			ObjectiveManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, 100685644);
			ObjectiveManager.NativeMethodInfoPtr_CreateObjective_Public_Static_T_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, 100685645);
			ObjectiveManager.NativeMethodInfoPtr_RemoveObjective_Public_Static_Void_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, 100685646);
			ObjectiveManager.NativeMethodInfoPtr_SetDefenderCount_Public_Static_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr, 100685647);
		}

		// Token: 0x06011DD1 RID: 73169 RVA: 0x00002988 File Offset: 0x00000B88
		public ObjectiveManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065E5 RID: 26085
		// (get) Token: 0x06011DD2 RID: 73170 RVA: 0x004722B0 File Offset: 0x004704B0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr));
			}
		}

		// Token: 0x170065E6 RID: 26086
		// (get) Token: 0x06011DD3 RID: 73171 RVA: 0x004722C4 File Offset: 0x004704C4
		// (set) Token: 0x06011DD4 RID: 73172 RVA: 0x004722EF File Offset: 0x004704EF
		public unsafe static Dictionary<Type, List<AIObjective>> ObjectivesByType
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ObjectiveManager.NativeFieldInfoPtr_ObjectivesByType, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<Type, List<AIObjective>>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObjectiveManager.NativeFieldInfoPtr_ObjectivesByType, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170065E7 RID: 26087
		// (get) Token: 0x06011DD5 RID: 73173 RVA: 0x00472304 File Offset: 0x00470504
		// (set) Token: 0x06011DD6 RID: 73174 RVA: 0x0047232F File Offset: 0x0047052F
		public unsafe static List<AIObjective> AllObjectives
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ObjectiveManager.NativeFieldInfoPtr_AllObjectives, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<AIObjective>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObjectiveManager.NativeFieldInfoPtr_AllObjectives, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B58C RID: 46476
		private static readonly IntPtr NativeFieldInfoPtr_ObjectivesByType;

		// Token: 0x0400B58D RID: 46477
		private static readonly IntPtr NativeFieldInfoPtr_AllObjectives;

		// Token: 0x0400B58E RID: 46478
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400B58F RID: 46479
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0;

		// Token: 0x0400B590 RID: 46480
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Static_T_Object_Int32_0;

		// Token: 0x0400B591 RID: 46481
		private static readonly IntPtr NativeMethodInfoPtr_RemoveObjective_Public_Static_Void_Object_0;

		// Token: 0x0400B592 RID: 46482
		private static readonly IntPtr NativeMethodInfoPtr_SetDefenderCount_Public_Static_Void_Object_Int32_0;

		// Token: 0x02000E82 RID: 3714
		private sealed class MethodInfoStoreGeneric_CreateObjective_Public_Static_T_Object_Int32_0<T>
		{
			// Token: 0x0400B593 RID: 46483
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(ObjectiveManager.NativeMethodInfoPtr_CreateObjective_Public_Static_T_Object_Int32_0, Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x02000E83 RID: 3715
		private sealed class MethodInfoStoreGeneric_RemoveObjective_Public_Static_Void_Object_0<T>
		{
			// Token: 0x0400B594 RID: 46484
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(ObjectiveManager.NativeMethodInfoPtr_RemoveObjective_Public_Static_Void_Object_0, Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x02000E84 RID: 3716
		private sealed class MethodInfoStoreGeneric_SetDefenderCount_Public_Static_Void_Object_Int32_0<T>
		{
			// Token: 0x0400B595 RID: 46485
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(ObjectiveManager.NativeMethodInfoPtr_SetDefenderCount_Public_Static_Void_Object_Int32_0, Il2CppClassPointerStore<ObjectiveManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
