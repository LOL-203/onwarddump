﻿using System;
using DPI.Pickups;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems.Objectives
{
	// Token: 0x02000E7C RID: 3708
	public class AIHardDriveObjective : AIObjective
	{
		// Token: 0x06011D95 RID: 73109 RVA: 0x0047125C File Offset: 0x0046F45C
		[CallerCount(0)]
		public new unsafe void CreateObjective(Il2CppSystem.Object target, int maxAIDefenders)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxAIDefenders;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIHardDriveObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D96 RID: 73110 RVA: 0x004712D4 File Offset: 0x0046F4D4
		[CallerCount(0)]
		public new unsafe Vector3 Position()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIHardDriveObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D97 RID: 73111 RVA: 0x00471330 File Offset: 0x0046F530
		[CallerCount(0)]
		public unsafe AIHardDriveObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIHardDriveObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D98 RID: 73112 RVA: 0x0047137C File Offset: 0x0046F57C
		// Note: this type is marked as 'beforefieldinit'.
		static AIHardDriveObjective()
		{
			Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Objectives", "AIHardDriveObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr);
			AIHardDriveObjective.NativeFieldInfoPtr__hardDrive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr, "_hardDrive");
			AIHardDriveObjective.NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr, 100685624);
			AIHardDriveObjective.NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr, 100685625);
			AIHardDriveObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr, 100685626);
		}

		// Token: 0x06011D99 RID: 73113 RVA: 0x004713FC File Offset: 0x0046F5FC
		public AIHardDriveObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065D6 RID: 26070
		// (get) Token: 0x06011D9A RID: 73114 RVA: 0x00471405 File Offset: 0x0046F605
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIHardDriveObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170065D7 RID: 26071
		// (get) Token: 0x06011D9B RID: 73115 RVA: 0x00471418 File Offset: 0x0046F618
		// (set) Token: 0x06011D9C RID: 73116 RVA: 0x0047144C File Offset: 0x0046F64C
		public unsafe Pickup_FireFightObjective _hardDrive
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIHardDriveObjective.NativeFieldInfoPtr__hardDrive);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Pickup_FireFightObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIHardDriveObjective.NativeFieldInfoPtr__hardDrive), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B56F RID: 46447
		private static readonly IntPtr NativeFieldInfoPtr__hardDrive;

		// Token: 0x0400B570 RID: 46448
		private static readonly IntPtr NativeMethodInfoPtr_CreateObjective_Public_Virtual_Void_Object_Int32_0;

		// Token: 0x0400B571 RID: 46449
		private static readonly IntPtr NativeMethodInfoPtr_Position_Public_Virtual_Vector3_0;

		// Token: 0x0400B572 RID: 46450
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
