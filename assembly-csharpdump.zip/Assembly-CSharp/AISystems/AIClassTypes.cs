﻿using System;

namespace AISystems
{
	// Token: 0x02000E75 RID: 3701
	public enum AIClassTypes
	{
		// Token: 0x0400B542 RID: 46402
		Rifleman,
		// Token: 0x0400B543 RID: 46403
		Sniper,
		// Token: 0x0400B544 RID: 46404
		AutomaticRifleman
	}
}
