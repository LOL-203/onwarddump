﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AISystems
{
	// Token: 0x02000E76 RID: 3702
	[Serializable]
	public class AIDistribution : Object
	{
		// Token: 0x06011D58 RID: 73048 RVA: 0x00470434 File Offset: 0x0046E634
		[CallerCount(0)]
		public unsafe Dictionary<AIClassTypes, float> GetDistribution()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDistribution.NativeMethodInfoPtr_GetDistribution_Public_Dictionary_2_AIClassTypes_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Dictionary<AIClassTypes, float>(intPtr2) : null;
		}

		// Token: 0x06011D59 RID: 73049 RVA: 0x0047048C File Offset: 0x0046E68C
		[CallerCount(0)]
		public unsafe AIDistribution() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDistribution.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D5A RID: 73050 RVA: 0x004704D8 File Offset: 0x0046E6D8
		// Note: this type is marked as 'beforefieldinit'.
		static AIDistribution()
		{
			Il2CppClassPointerStore<AIDistribution>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems", "AIDistribution");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr);
			AIDistribution.NativeFieldInfoPtr_ClassTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr, "ClassTypes");
			AIDistribution.NativeFieldInfoPtr_Weights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr, "Weights");
			AIDistribution.NativeMethodInfoPtr_GetDistribution_Public_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr, 100685603);
			AIDistribution.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr, 100685604);
		}

		// Token: 0x06011D5B RID: 73051 RVA: 0x00002988 File Offset: 0x00000B88
		public AIDistribution(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065C3 RID: 26051
		// (get) Token: 0x06011D5C RID: 73052 RVA: 0x00470558 File Offset: 0x0046E758
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDistribution>.NativeClassPtr));
			}
		}

		// Token: 0x170065C4 RID: 26052
		// (get) Token: 0x06011D5D RID: 73053 RVA: 0x0047056C File Offset: 0x0046E76C
		// (set) Token: 0x06011D5E RID: 73054 RVA: 0x004705A0 File Offset: 0x0046E7A0
		public unsafe List<AIClassTypes> ClassTypes
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDistribution.NativeFieldInfoPtr_ClassTypes);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<AIClassTypes>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDistribution.NativeFieldInfoPtr_ClassTypes), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170065C5 RID: 26053
		// (get) Token: 0x06011D5F RID: 73055 RVA: 0x004705C8 File Offset: 0x0046E7C8
		// (set) Token: 0x06011D60 RID: 73056 RVA: 0x004705FC File Offset: 0x0046E7FC
		public unsafe List<float> Weights
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDistribution.NativeFieldInfoPtr_Weights);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<float>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDistribution.NativeFieldInfoPtr_Weights), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B545 RID: 46405
		private static readonly IntPtr NativeFieldInfoPtr_ClassTypes;

		// Token: 0x0400B546 RID: 46406
		private static readonly IntPtr NativeFieldInfoPtr_Weights;

		// Token: 0x0400B547 RID: 46407
		private static readonly IntPtr NativeMethodInfoPtr_GetDistribution_Public_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400B548 RID: 46408
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
