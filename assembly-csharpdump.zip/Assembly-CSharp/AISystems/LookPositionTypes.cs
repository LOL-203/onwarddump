﻿using System;

namespace AISystems
{
	// Token: 0x02000E78 RID: 3704
	public enum LookPositionTypes
	{
		// Token: 0x0400B559 RID: 46425
		Forward,
		// Token: 0x0400B55A RID: 46426
		FarthestPoint,
		// Token: 0x0400B55B RID: 46427
		Target,
		// Token: 0x0400B55C RID: 46428
		CoverDirection,
		// Token: 0x0400B55D RID: 46429
		StateDrivenPosition
	}
}
