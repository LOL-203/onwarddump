﻿using System;

namespace AISystems.Tokens
{
	// Token: 0x02000E7B RID: 3707
	public enum TokenTypes
	{
		// Token: 0x0400B56C RID: 46444
		FragGrenade,
		// Token: 0x0400B56D RID: 46445
		SmokeGrenade,
		// Token: 0x0400B56E RID: 46446
		FlashGrenade
	}
}
