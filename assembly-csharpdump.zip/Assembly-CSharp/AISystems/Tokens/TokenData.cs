﻿using System;
using DPI.Data;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AISystems.Tokens
{
	// Token: 0x02000E79 RID: 3705
	public class TokenData : BaseData
	{
		// Token: 0x06011D7A RID: 73082 RVA: 0x00470CF4 File Offset: 0x0046EEF4
		[CallerCount(0)]
		public unsafe void Tick(float deltaTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref deltaTime;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TokenData.NativeMethodInfoPtr_Tick_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D7B RID: 73083 RVA: 0x00470D48 File Offset: 0x0046EF48
		[CallerCount(0)]
		public unsafe bool UseToken()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(TokenData.NativeMethodInfoPtr_UseToken_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D7C RID: 73084 RVA: 0x00470D98 File Offset: 0x0046EF98
		[CallerCount(0)]
		public unsafe TokenData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<TokenData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TokenData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D7D RID: 73085 RVA: 0x00470DE4 File Offset: 0x0046EFE4
		// Note: this type is marked as 'beforefieldinit'.
		static TokenData()
		{
			Il2CppClassPointerStore<TokenData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Tokens", "TokenData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TokenData>.NativeClassPtr);
			TokenData.NativeFieldInfoPtr_TokenType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenData>.NativeClassPtr, "TokenType");
			TokenData.NativeFieldInfoPtr_MaxTokens = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenData>.NativeClassPtr, "MaxTokens");
			TokenData.NativeFieldInfoPtr_TokenCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenData>.NativeClassPtr, "TokenCount");
			TokenData.NativeFieldInfoPtr_RefillDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenData>.NativeClassPtr, "RefillDuration");
			TokenData.NativeFieldInfoPtr__timer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenData>.NativeClassPtr, "_timer");
			TokenData.NativeMethodInfoPtr_Tick_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenData>.NativeClassPtr, 100685616);
			TokenData.NativeMethodInfoPtr_UseToken_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenData>.NativeClassPtr, 100685617);
			TokenData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenData>.NativeClassPtr, 100685618);
		}

		// Token: 0x06011D7E RID: 73086 RVA: 0x000AD628 File Offset: 0x000AB828
		public TokenData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065CD RID: 26061
		// (get) Token: 0x06011D7F RID: 73087 RVA: 0x00470EB4 File Offset: 0x0046F0B4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TokenData>.NativeClassPtr));
			}
		}

		// Token: 0x170065CE RID: 26062
		// (get) Token: 0x06011D80 RID: 73088 RVA: 0x00470EC8 File Offset: 0x0046F0C8
		// (set) Token: 0x06011D81 RID: 73089 RVA: 0x00470EF0 File Offset: 0x0046F0F0
		public unsafe TokenTypes TokenType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_TokenType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_TokenType)) = value;
			}
		}

		// Token: 0x170065CF RID: 26063
		// (get) Token: 0x06011D82 RID: 73090 RVA: 0x00470F14 File Offset: 0x0046F114
		// (set) Token: 0x06011D83 RID: 73091 RVA: 0x00470F3C File Offset: 0x0046F13C
		public unsafe int MaxTokens
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_MaxTokens);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_MaxTokens)) = value;
			}
		}

		// Token: 0x170065D0 RID: 26064
		// (get) Token: 0x06011D84 RID: 73092 RVA: 0x00470F60 File Offset: 0x0046F160
		// (set) Token: 0x06011D85 RID: 73093 RVA: 0x00470F88 File Offset: 0x0046F188
		public unsafe int TokenCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_TokenCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_TokenCount)) = value;
			}
		}

		// Token: 0x170065D1 RID: 26065
		// (get) Token: 0x06011D86 RID: 73094 RVA: 0x00470FAC File Offset: 0x0046F1AC
		// (set) Token: 0x06011D87 RID: 73095 RVA: 0x00470FD4 File Offset: 0x0046F1D4
		public unsafe float RefillDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_RefillDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr_RefillDuration)) = value;
			}
		}

		// Token: 0x170065D2 RID: 26066
		// (get) Token: 0x06011D88 RID: 73096 RVA: 0x00470FF8 File Offset: 0x0046F1F8
		// (set) Token: 0x06011D89 RID: 73097 RVA: 0x00471020 File Offset: 0x0046F220
		public unsafe float _timer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr__timer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TokenData.NativeFieldInfoPtr__timer)) = value;
			}
		}

		// Token: 0x0400B55E RID: 46430
		private static readonly IntPtr NativeFieldInfoPtr_TokenType;

		// Token: 0x0400B55F RID: 46431
		private static readonly IntPtr NativeFieldInfoPtr_MaxTokens;

		// Token: 0x0400B560 RID: 46432
		private static readonly IntPtr NativeFieldInfoPtr_TokenCount;

		// Token: 0x0400B561 RID: 46433
		private static readonly IntPtr NativeFieldInfoPtr_RefillDuration;

		// Token: 0x0400B562 RID: 46434
		private static readonly IntPtr NativeFieldInfoPtr__timer;

		// Token: 0x0400B563 RID: 46435
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Public_Void_Single_0;

		// Token: 0x0400B564 RID: 46436
		private static readonly IntPtr NativeMethodInfoPtr_UseToken_Public_Boolean_0;

		// Token: 0x0400B565 RID: 46437
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
