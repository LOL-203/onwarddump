﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace AISystems.Tokens
{
	// Token: 0x02000E7A RID: 3706
	public static class TokenManager : Object
	{
		// Token: 0x06011D8A RID: 73098 RVA: 0x00471044 File Offset: 0x0046F244
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TokenManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D8B RID: 73099 RVA: 0x00471078 File Offset: 0x0046F278
		[CallerCount(0)]
		public unsafe static void Uninitialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TokenManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D8C RID: 73100 RVA: 0x004710AC File Offset: 0x0046F2AC
		[CallerCount(0)]
		public unsafe static void Tick(float deltaTime)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref deltaTime;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TokenManager.NativeMethodInfoPtr_Tick_Public_Static_Void_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D8D RID: 73101 RVA: 0x004710F4 File Offset: 0x0046F2F4
		[CallerCount(0)]
		public unsafe static bool UseToken(TokenTypes tokenType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref tokenType;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(TokenManager.NativeMethodInfoPtr_UseToken_Public_Static_Boolean_TokenTypes_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D8E RID: 73102 RVA: 0x00471148 File Offset: 0x0046F348
		// Note: this type is marked as 'beforefieldinit'.
		static TokenManager()
		{
			Il2CppClassPointerStore<TokenManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems.Tokens", "TokenManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TokenManager>.NativeClassPtr);
			TokenManager.NativeFieldInfoPtr__tokensByType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TokenManager>.NativeClassPtr, "_tokensByType");
			TokenManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenManager>.NativeClassPtr, 100685619);
			TokenManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenManager>.NativeClassPtr, 100685620);
			TokenManager.NativeMethodInfoPtr_Tick_Public_Static_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenManager>.NativeClassPtr, 100685621);
			TokenManager.NativeMethodInfoPtr_UseToken_Public_Static_Boolean_TokenTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TokenManager>.NativeClassPtr, 100685622);
		}

		// Token: 0x06011D8F RID: 73103 RVA: 0x00002988 File Offset: 0x00000B88
		public TokenManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065D3 RID: 26067
		// (get) Token: 0x06011D90 RID: 73104 RVA: 0x004711DC File Offset: 0x0046F3DC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TokenManager>.NativeClassPtr));
			}
		}

		// Token: 0x170065D4 RID: 26068
		// (get) Token: 0x06011D91 RID: 73105 RVA: 0x004711F0 File Offset: 0x0046F3F0
		// (set) Token: 0x06011D92 RID: 73106 RVA: 0x0047121B File Offset: 0x0046F41B
		public unsafe static Dictionary<TokenTypes, TokenData> _tokensByType
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(TokenManager.NativeFieldInfoPtr__tokensByType, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<TokenTypes, TokenData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(TokenManager.NativeFieldInfoPtr__tokensByType, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B566 RID: 46438
		private static readonly IntPtr NativeFieldInfoPtr__tokensByType;

		// Token: 0x0400B567 RID: 46439
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400B568 RID: 46440
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0;

		// Token: 0x0400B569 RID: 46441
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Public_Static_Void_Single_0;

		// Token: 0x0400B56A RID: 46442
		private static readonly IntPtr NativeMethodInfoPtr_UseToken_Public_Static_Boolean_TokenTypes_0;
	}
}
