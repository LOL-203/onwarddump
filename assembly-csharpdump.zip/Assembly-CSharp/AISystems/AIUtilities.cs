﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace AISystems
{
	// Token: 0x02000E77 RID: 3703
	public static class AIUtilities : Il2CppSystem.Object
	{
		// Token: 0x06011D61 RID: 73057 RVA: 0x00470624 File Offset: 0x0046E824
		[CallerCount(0)]
		public unsafe static int GetAIID()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_GetAIID_Public_Static_Int32_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D62 RID: 73058 RVA: 0x00470668 File Offset: 0x0046E868
		[CallerCount(0)]
		public unsafe static int FrameCount()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_FrameCount_Public_Static_Int32_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D63 RID: 73059 RVA: 0x004706AC File Offset: 0x0046E8AC
		[CallerCount(0)]
		public unsafe static void ResetSpawnPool(GameVariant gameVariant, int missionIndex, Faction faction, [Optional] int task)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(gameVariant);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref task;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_ResetSpawnPool_Public_Static_Void_GameVariant_Int32_Faction_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D64 RID: 73060 RVA: 0x00470730 File Offset: 0x0046E930
		[CallerCount(0)]
		public unsafe static void SpawnAI(GameVariant gameVariant, int missionIndex, Faction faction, int spawnCount, bool useLineOfSightChecks = false, [Optional] float minDistance, bool refreshSpawns = true, [Optional] int task, [Optional] List<HumanoidAI> spawnedAis, [Optional] Dictionary<AIClassTypes, float> classWeights)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)10) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(gameVariant);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnCount;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref useLineOfSightChecks;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minDistance;
			ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref refreshSpawns;
			ptr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref task;
			ptr[checked(unchecked((UIntPtr)8) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(spawnedAis);
			ptr[checked(unchecked((UIntPtr)9) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(classWeights);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_SpawnAI_Public_Static_Void_GameVariant_Int32_Faction_Int32_Boolean_Single_Boolean_Int32_List_1_HumanoidAI_Dictionary_2_AIClassTypes_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D65 RID: 73061 RVA: 0x00470834 File Offset: 0x0046EA34
		[CallerCount(0)]
		public unsafe static void CleanUpAI()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D66 RID: 73062 RVA: 0x00470868 File Offset: 0x0046EA68
		[CallerCount(0)]
		public unsafe static void CleanUpAI(HumanoidAI ai)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ai);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_HumanoidAI_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D67 RID: 73063 RVA: 0x004708B4 File Offset: 0x0046EAB4
		[CallerCount(0)]
		public unsafe static List<AIClassTypes> GetClassTypes(Dictionary<AIClassTypes, float> classWeights, int botCount)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(classWeights);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref botCount;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_GetClassTypes_Private_Static_List_1_AIClassTypes_Dictionary_2_AIClassTypes_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<AIClassTypes>(intPtr2) : null;
		}

		// Token: 0x06011D68 RID: 73064 RVA: 0x00470928 File Offset: 0x0046EB28
		[CallerCount(0)]
		public unsafe static bool CheckMinimumDistance(Vector3 position, float minDistance)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref position;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minDistance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_CheckMinimumDistance_Private_Static_Boolean_Vector3_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D69 RID: 73065 RVA: 0x00470990 File Offset: 0x0046EB90
		[CallerCount(0)]
		public unsafe static void ForceRunToPosition(List<HumanoidAI> ais, Vector3 position)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ais);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_ForceRunToPosition_Public_Static_Void_List_1_HumanoidAI_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06011D6A RID: 73066 RVA: 0x004709F0 File Offset: 0x0046EBF0
		[CallerCount(0)]
		public unsafe static bool IsAnyAgentNearPosition(Vector3 targetPos, float maxDist)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref targetPos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDist;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIUtilities.NativeMethodInfoPtr_IsAnyAgentNearPosition_Public_Static_Boolean_Vector3_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06011D6B RID: 73067 RVA: 0x00470A58 File Offset: 0x0046EC58
		// Note: this type is marked as 'beforefieldinit'.
		static AIUtilities()
		{
			Il2CppClassPointerStore<AIUtilities>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "AISystems", "AIUtilities");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr);
			AIUtilities.NativeFieldInfoPtr_FrameSkipInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, "FrameSkipInterval");
			AIUtilities.NativeFieldInfoPtr__lastID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, "_lastID");
			AIUtilities.NativeFieldInfoPtr__lastFrame = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, "_lastFrame");
			AIUtilities.NativeFieldInfoPtr__frameCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, "_frameCount");
			AIUtilities.NativeFieldInfoPtr_UnusedSpawnIndicies = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, "UnusedSpawnIndicies");
			AIUtilities.NativeMethodInfoPtr_GetAIID_Public_Static_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685605);
			AIUtilities.NativeMethodInfoPtr_FrameCount_Public_Static_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685606);
			AIUtilities.NativeMethodInfoPtr_ResetSpawnPool_Public_Static_Void_GameVariant_Int32_Faction_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685607);
			AIUtilities.NativeMethodInfoPtr_SpawnAI_Public_Static_Void_GameVariant_Int32_Faction_Int32_Boolean_Single_Boolean_Int32_List_1_HumanoidAI_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685608);
			AIUtilities.NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685609);
			AIUtilities.NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685610);
			AIUtilities.NativeMethodInfoPtr_GetClassTypes_Private_Static_List_1_AIClassTypes_Dictionary_2_AIClassTypes_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685611);
			AIUtilities.NativeMethodInfoPtr_CheckMinimumDistance_Private_Static_Boolean_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685612);
			AIUtilities.NativeMethodInfoPtr_ForceRunToPosition_Public_Static_Void_List_1_HumanoidAI_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685613);
			AIUtilities.NativeMethodInfoPtr_IsAnyAgentNearPosition_Public_Static_Boolean_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr, 100685614);
		}

		// Token: 0x06011D6C RID: 73068 RVA: 0x00002988 File Offset: 0x00000B88
		public AIUtilities(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170065C6 RID: 26054
		// (get) Token: 0x06011D6D RID: 73069 RVA: 0x00470BB4 File Offset: 0x0046EDB4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIUtilities>.NativeClassPtr));
			}
		}

		// Token: 0x170065C7 RID: 26055
		// (get) Token: 0x06011D6E RID: 73070 RVA: 0x00470BC8 File Offset: 0x0046EDC8
		// (set) Token: 0x06011D6F RID: 73071 RVA: 0x00470BE6 File Offset: 0x0046EDE6
		public unsafe static int FrameSkipInterval
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(AIUtilities.NativeFieldInfoPtr_FrameSkipInterval, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIUtilities.NativeFieldInfoPtr_FrameSkipInterval, (void*)(&value));
			}
		}

		// Token: 0x170065C8 RID: 26056
		// (get) Token: 0x06011D70 RID: 73072 RVA: 0x00470BF8 File Offset: 0x0046EDF8
		// (set) Token: 0x06011D71 RID: 73073 RVA: 0x00470C16 File Offset: 0x0046EE16
		public unsafe static int _lastID
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(AIUtilities.NativeFieldInfoPtr__lastID, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIUtilities.NativeFieldInfoPtr__lastID, (void*)(&value));
			}
		}

		// Token: 0x170065C9 RID: 26057
		// (get) Token: 0x06011D72 RID: 73074 RVA: 0x00470C28 File Offset: 0x0046EE28
		// (set) Token: 0x06011D73 RID: 73075 RVA: 0x00470C46 File Offset: 0x0046EE46
		public unsafe static int _lastFrame
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(AIUtilities.NativeFieldInfoPtr__lastFrame, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIUtilities.NativeFieldInfoPtr__lastFrame, (void*)(&value));
			}
		}

		// Token: 0x170065CA RID: 26058
		// (get) Token: 0x06011D74 RID: 73076 RVA: 0x00470C58 File Offset: 0x0046EE58
		// (set) Token: 0x06011D75 RID: 73077 RVA: 0x00470C76 File Offset: 0x0046EE76
		public unsafe static int _frameCount
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(AIUtilities.NativeFieldInfoPtr__frameCount, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIUtilities.NativeFieldInfoPtr__frameCount, (void*)(&value));
			}
		}

		// Token: 0x170065CB RID: 26059
		// (get) Token: 0x06011D76 RID: 73078 RVA: 0x00470C88 File Offset: 0x0046EE88
		// (set) Token: 0x06011D77 RID: 73079 RVA: 0x00470CB3 File Offset: 0x0046EEB3
		public unsafe static List<Onward.GameVariants.SpawnPoint> UnusedSpawnIndicies
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AIUtilities.NativeFieldInfoPtr_UnusedSpawnIndicies, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<Onward.GameVariants.SpawnPoint>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIUtilities.NativeFieldInfoPtr_UnusedSpawnIndicies, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400B549 RID: 46409
		private static readonly IntPtr NativeFieldInfoPtr_FrameSkipInterval;

		// Token: 0x0400B54A RID: 46410
		private static readonly IntPtr NativeFieldInfoPtr__lastID;

		// Token: 0x0400B54B RID: 46411
		private static readonly IntPtr NativeFieldInfoPtr__lastFrame;

		// Token: 0x0400B54C RID: 46412
		private static readonly IntPtr NativeFieldInfoPtr__frameCount;

		// Token: 0x0400B54D RID: 46413
		private static readonly IntPtr NativeFieldInfoPtr_UnusedSpawnIndicies;

		// Token: 0x0400B54E RID: 46414
		private static readonly IntPtr NativeMethodInfoPtr_GetAIID_Public_Static_Int32_0;

		// Token: 0x0400B54F RID: 46415
		private static readonly IntPtr NativeMethodInfoPtr_FrameCount_Public_Static_Int32_0;

		// Token: 0x0400B550 RID: 46416
		private static readonly IntPtr NativeMethodInfoPtr_ResetSpawnPool_Public_Static_Void_GameVariant_Int32_Faction_Int32_0;

		// Token: 0x0400B551 RID: 46417
		private static readonly IntPtr NativeMethodInfoPtr_SpawnAI_Public_Static_Void_GameVariant_Int32_Faction_Int32_Boolean_Single_Boolean_Int32_List_1_HumanoidAI_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400B552 RID: 46418
		private static readonly IntPtr NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_0;

		// Token: 0x0400B553 RID: 46419
		private static readonly IntPtr NativeMethodInfoPtr_CleanUpAI_Public_Static_Void_HumanoidAI_0;

		// Token: 0x0400B554 RID: 46420
		private static readonly IntPtr NativeMethodInfoPtr_GetClassTypes_Private_Static_List_1_AIClassTypes_Dictionary_2_AIClassTypes_Single_Int32_0;

		// Token: 0x0400B555 RID: 46421
		private static readonly IntPtr NativeMethodInfoPtr_CheckMinimumDistance_Private_Static_Boolean_Vector3_Single_0;

		// Token: 0x0400B556 RID: 46422
		private static readonly IntPtr NativeMethodInfoPtr_ForceRunToPosition_Public_Static_Void_List_1_HumanoidAI_Vector3_0;

		// Token: 0x0400B557 RID: 46423
		private static readonly IntPtr NativeMethodInfoPtr_IsAnyAgentNearPosition_Public_Static_Boolean_Vector3_Single_0;
	}
}
