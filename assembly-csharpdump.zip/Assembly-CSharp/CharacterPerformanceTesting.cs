﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Data;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003DD RID: 989
public class CharacterPerformanceTesting : MonoBehaviour
{
	// Token: 0x06004E0B RID: 19979 RVA: 0x00138CA4 File Offset: 0x00136EA4
	[CallerCount(0)]
	public unsafe IEnumerator Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting.NativeMethodInfoPtr_Start_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004E0C RID: 19980 RVA: 0x00138CFC File Offset: 0x00136EFC
	[CallerCount(0)]
	public unsafe CharacterPerformanceTesting() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E0D RID: 19981 RVA: 0x00138D48 File Offset: 0x00136F48
	// Note: this type is marked as 'beforefieldinit'.
	static CharacterPerformanceTesting()
	{
		Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CharacterPerformanceTesting");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr);
		CharacterPerformanceTesting.NativeFieldInfoPtr_SpawnPoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr, "SpawnPoints");
		CharacterPerformanceTesting.NativeFieldInfoPtr_PlayerData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr, "PlayerData");
		CharacterPerformanceTesting.NativeMethodInfoPtr_Start_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr, 100669439);
		CharacterPerformanceTesting.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr, 100669440);
	}

	// Token: 0x06004E0E RID: 19982 RVA: 0x0000210C File Offset: 0x0000030C
	public CharacterPerformanceTesting(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001BE8 RID: 7144
	// (get) Token: 0x06004E0F RID: 19983 RVA: 0x00138DC8 File Offset: 0x00136FC8
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr));
		}
	}

	// Token: 0x17001BE9 RID: 7145
	// (get) Token: 0x06004E10 RID: 19984 RVA: 0x00138DDC File Offset: 0x00136FDC
	// (set) Token: 0x06004E11 RID: 19985 RVA: 0x00138E10 File Offset: 0x00137010
	public unsafe Il2CppReferenceArray<Transform> SpawnPoints
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting.NativeFieldInfoPtr_SpawnPoints);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Transform>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting.NativeFieldInfoPtr_SpawnPoints), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001BEA RID: 7146
	// (get) Token: 0x06004E12 RID: 19986 RVA: 0x00138E38 File Offset: 0x00137038
	// (set) Token: 0x06004E13 RID: 19987 RVA: 0x00138E6C File Offset: 0x0013706C
	public unsafe AssetReferenceData PlayerData
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting.NativeFieldInfoPtr_PlayerData);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new AssetReferenceData(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting.NativeFieldInfoPtr_PlayerData), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04003194 RID: 12692
	private static readonly IntPtr NativeFieldInfoPtr_SpawnPoints;

	// Token: 0x04003195 RID: 12693
	private static readonly IntPtr NativeFieldInfoPtr_PlayerData;

	// Token: 0x04003196 RID: 12694
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_IEnumerator_0;

	// Token: 0x04003197 RID: 12695
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003DE RID: 990
	[ObfuscatedName("CharacterPerformanceTesting/<Start>d__2")]
	public sealed class _Start_d__2 : Il2CppSystem.Object
	{
		// Token: 0x06004E14 RID: 19988 RVA: 0x00138E94 File Offset: 0x00137094
		[CallerCount(0)]
		public unsafe _Start_d__2(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E15 RID: 19989 RVA: 0x00138EF4 File Offset: 0x001370F4
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E16 RID: 19990 RVA: 0x00138F38 File Offset: 0x00137138
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001BEF RID: 7151
		// (get) Token: 0x06004E17 RID: 19991 RVA: 0x00138F88 File Offset: 0x00137188
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004E18 RID: 19992 RVA: 0x00138FE0 File Offset: 0x001371E0
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001BF0 RID: 7152
		// (get) Token: 0x06004E19 RID: 19993 RVA: 0x00139024 File Offset: 0x00137224
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004E1A RID: 19994 RVA: 0x0013907C File Offset: 0x0013727C
		// Note: this type is marked as 'beforefieldinit'.
		static _Start_d__2()
		{
			Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CharacterPerformanceTesting>.NativeClassPtr, "<Start>d__2");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr);
			CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, "<>1__state");
			CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, "<>2__current");
			CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, "<>4__this");
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669441);
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669442);
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669443);
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669444);
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669445);
			CharacterPerformanceTesting._Start_d__2.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr, 100669446);
		}

		// Token: 0x06004E1B RID: 19995 RVA: 0x00002988 File Offset: 0x00000B88
		public _Start_d__2(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001BEB RID: 7147
		// (get) Token: 0x06004E1C RID: 19996 RVA: 0x0013915B File Offset: 0x0013735B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CharacterPerformanceTesting._Start_d__2>.NativeClassPtr));
			}
		}

		// Token: 0x17001BEC RID: 7148
		// (get) Token: 0x06004E1D RID: 19997 RVA: 0x0013916C File Offset: 0x0013736C
		// (set) Token: 0x06004E1E RID: 19998 RVA: 0x00139194 File Offset: 0x00137394
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001BED RID: 7149
		// (get) Token: 0x06004E1F RID: 19999 RVA: 0x001391B8 File Offset: 0x001373B8
		// (set) Token: 0x06004E20 RID: 20000 RVA: 0x001391EC File Offset: 0x001373EC
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001BEE RID: 7150
		// (get) Token: 0x06004E21 RID: 20001 RVA: 0x00139214 File Offset: 0x00137414
		// (set) Token: 0x06004E22 RID: 20002 RVA: 0x00139248 File Offset: 0x00137448
		public unsafe CharacterPerformanceTesting __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CharacterPerformanceTesting(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CharacterPerformanceTesting._Start_d__2.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04003198 RID: 12696
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04003199 RID: 12697
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x0400319A RID: 12698
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x0400319B RID: 12699
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x0400319C RID: 12700
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x0400319D RID: 12701
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x0400319E RID: 12702
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x0400319F RID: 12703
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040031A0 RID: 12704
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
