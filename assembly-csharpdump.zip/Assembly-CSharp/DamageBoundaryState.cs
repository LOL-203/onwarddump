﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200018B RID: 395
public class DamageBoundaryState : Il2CppSystem.Object
{
	// Token: 0x06001A8B RID: 6795 RVA: 0x00069BC4 File Offset: 0x00067DC4
	[CallerCount(0)]
	public unsafe DamageBoundaryState(DamageController damageController) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr))
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageController);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr__ctor_Public_Void_DamageController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A8C RID: 6796 RVA: 0x00069C28 File Offset: 0x00067E28
	[CallerCount(0)]
	public unsafe void ColliderEnteredDamageBoundary(Collider col, DamageBoundary damageBoundary)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageBoundary);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A8D RID: 6797 RVA: 0x00069C9C File Offset: 0x00067E9C
	[CallerCount(0)]
	public unsafe void ColliderExitedDamageBoundary(Collider col, DamageBoundary damageBoundary)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(col);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageBoundary);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A8E RID: 6798 RVA: 0x00069D10 File Offset: 0x00067F10
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_Update_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A8F RID: 6799 RVA: 0x00069D54 File Offset: 0x00067F54
	[CallerCount(0)]
	public unsafe void ApplyDamage(DamageBoundary damageBoundary)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageBoundary);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_ApplyDamage_Private_Void_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A90 RID: 6800 RVA: 0x00069DB0 File Offset: 0x00067FB0
	[CallerCount(0)]
	public unsafe void ToggleWarningUI(bool showWarningUI, DamageBoundary damageBoundary)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref showWarningUI;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageBoundary);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_ToggleWarningUI_Private_Void_Boolean_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A91 RID: 6801 RVA: 0x00069E1C File Offset: 0x0006801C
	[CallerCount(0)]
	public unsafe void UpdateWarningUI(DamageBoundary damageBoundary)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageBoundary);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageBoundaryState.NativeMethodInfoPtr_UpdateWarningUI_Private_Void_DamageBoundary_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06001A92 RID: 6802 RVA: 0x00069E78 File Offset: 0x00068078
	// Note: this type is marked as 'beforefieldinit'.
	static DamageBoundaryState()
	{
		Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageBoundaryState");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr);
		DamageBoundaryState.NativeFieldInfoPtr_DamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "DamageController");
		DamageBoundaryState.NativeFieldInfoPtr_FlagedForRemoval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "FlagedForRemoval");
		DamageBoundaryState.NativeFieldInfoPtr_damageBoundaries = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "damageBoundaries");
		DamageBoundaryState.NativeFieldInfoPtr_damageBoundariesDict = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "damageBoundariesDict");
		DamageBoundaryState.NativeFieldInfoPtr_timeSinceLastTick = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "timeSinceLastTick");
		DamageBoundaryState.NativeFieldInfoPtr_OutOfBoundsString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, "OutOfBoundsString");
		DamageBoundaryState.NativeMethodInfoPtr__ctor_Public_Void_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665402);
		DamageBoundaryState.NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665403);
		DamageBoundaryState.NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665404);
		DamageBoundaryState.NativeMethodInfoPtr_Update_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665405);
		DamageBoundaryState.NativeMethodInfoPtr_ApplyDamage_Private_Void_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665406);
		DamageBoundaryState.NativeMethodInfoPtr_ToggleWarningUI_Private_Void_Boolean_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665407);
		DamageBoundaryState.NativeMethodInfoPtr_UpdateWarningUI_Private_Void_DamageBoundary_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr, 100665408);
	}

	// Token: 0x06001A93 RID: 6803 RVA: 0x00002988 File Offset: 0x00000B88
	public DamageBoundaryState(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000936 RID: 2358
	// (get) Token: 0x06001A94 RID: 6804 RVA: 0x00069FAC File Offset: 0x000681AC
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageBoundaryState>.NativeClassPtr));
		}
	}

	// Token: 0x17000937 RID: 2359
	// (get) Token: 0x06001A95 RID: 6805 RVA: 0x00069FC0 File Offset: 0x000681C0
	// (set) Token: 0x06001A96 RID: 6806 RVA: 0x00069FF4 File Offset: 0x000681F4
	public unsafe DamageController DamageController
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_DamageController);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_DamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000938 RID: 2360
	// (get) Token: 0x06001A97 RID: 6807 RVA: 0x0006A01C File Offset: 0x0006821C
	// (set) Token: 0x06001A98 RID: 6808 RVA: 0x0006A044 File Offset: 0x00068244
	public unsafe bool FlagedForRemoval
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_FlagedForRemoval);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_FlagedForRemoval)) = value;
		}
	}

	// Token: 0x17000939 RID: 2361
	// (get) Token: 0x06001A99 RID: 6809 RVA: 0x0006A068 File Offset: 0x00068268
	// (set) Token: 0x06001A9A RID: 6810 RVA: 0x0006A09C File Offset: 0x0006829C
	public unsafe List<DamageBoundary> damageBoundaries
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_damageBoundaries);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageBoundary>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_damageBoundaries), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700093A RID: 2362
	// (get) Token: 0x06001A9B RID: 6811 RVA: 0x0006A0C4 File Offset: 0x000682C4
	// (set) Token: 0x06001A9C RID: 6812 RVA: 0x0006A0F8 File Offset: 0x000682F8
	public unsafe Dictionary<DamageBoundary, HashSet<Collider>> damageBoundariesDict
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_damageBoundariesDict);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Dictionary<DamageBoundary, HashSet<Collider>>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_damageBoundariesDict), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700093B RID: 2363
	// (get) Token: 0x06001A9D RID: 6813 RVA: 0x0006A120 File Offset: 0x00068320
	// (set) Token: 0x06001A9E RID: 6814 RVA: 0x0006A148 File Offset: 0x00068348
	public unsafe float timeSinceLastTick
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_timeSinceLastTick);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageBoundaryState.NativeFieldInfoPtr_timeSinceLastTick)) = value;
		}
	}

	// Token: 0x1700093C RID: 2364
	// (get) Token: 0x06001A9F RID: 6815 RVA: 0x0006A16C File Offset: 0x0006836C
	// (set) Token: 0x06001AA0 RID: 6816 RVA: 0x0006A18C File Offset: 0x0006838C
	public unsafe static string OutOfBoundsString
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(DamageBoundaryState.NativeFieldInfoPtr_OutOfBoundsString, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(DamageBoundaryState.NativeFieldInfoPtr_OutOfBoundsString, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x040010FE RID: 4350
	private static readonly IntPtr NativeFieldInfoPtr_DamageController;

	// Token: 0x040010FF RID: 4351
	private static readonly IntPtr NativeFieldInfoPtr_FlagedForRemoval;

	// Token: 0x04001100 RID: 4352
	private static readonly IntPtr NativeFieldInfoPtr_damageBoundaries;

	// Token: 0x04001101 RID: 4353
	private static readonly IntPtr NativeFieldInfoPtr_damageBoundariesDict;

	// Token: 0x04001102 RID: 4354
	private static readonly IntPtr NativeFieldInfoPtr_timeSinceLastTick;

	// Token: 0x04001103 RID: 4355
	private static readonly IntPtr NativeFieldInfoPtr_OutOfBoundsString;

	// Token: 0x04001104 RID: 4356
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_DamageController_0;

	// Token: 0x04001105 RID: 4357
	private static readonly IntPtr NativeMethodInfoPtr_ColliderEnteredDamageBoundary_Public_Void_Collider_DamageBoundary_0;

	// Token: 0x04001106 RID: 4358
	private static readonly IntPtr NativeMethodInfoPtr_ColliderExitedDamageBoundary_Public_Void_Collider_DamageBoundary_0;

	// Token: 0x04001107 RID: 4359
	private static readonly IntPtr NativeMethodInfoPtr_Update_Public_Void_0;

	// Token: 0x04001108 RID: 4360
	private static readonly IntPtr NativeMethodInfoPtr_ApplyDamage_Private_Void_DamageBoundary_0;

	// Token: 0x04001109 RID: 4361
	private static readonly IntPtr NativeMethodInfoPtr_ToggleWarningUI_Private_Void_Boolean_DamageBoundary_0;

	// Token: 0x0400110A RID: 4362
	private static readonly IntPtr NativeMethodInfoPtr_UpdateWarningUI_Private_Void_DamageBoundary_0;
}
