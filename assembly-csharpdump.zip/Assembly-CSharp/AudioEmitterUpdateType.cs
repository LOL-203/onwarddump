﻿using System;

// Token: 0x02000135 RID: 309
public enum AudioEmitterUpdateType
{
	// Token: 0x04000C6A RID: 3178
	EveryFrame,
	// Token: 0x04000C6B RID: 3179
	WithinRange,
	// Token: 0x04000C6C RID: 3180
	EventBased,
	// Token: 0x04000C6D RID: 3181
	Area = 4,
	// Token: 0x04000C6E RID: 3182
	Never = 3
}
