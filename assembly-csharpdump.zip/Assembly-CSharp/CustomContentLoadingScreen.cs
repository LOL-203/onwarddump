﻿using System;
using Il2CppSystem;
using Onward.CustomMaps;
using Onward.UI.ImageDownloading;
using Onward.UI.Workshop;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000353 RID: 851
public class CustomContentLoadingScreen : ImageDownloadingBehaviour
{
	// Token: 0x060042FC RID: 17148 RVA: 0x0010DD84 File Offset: 0x0010BF84
	[CallerCount(0)]
	public unsafe void Awake()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042FD RID: 17149 RVA: 0x0010DDC8 File Offset: 0x0010BFC8
	[CallerCount(0)]
	public unsafe void Init(string id, WorkshopItem workshopItem)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(id);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(workshopItem);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_Init_Public_Void_String_WorkshopItem_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042FE RID: 17150 RVA: 0x0010DE3C File Offset: 0x0010C03C
	[CallerCount(0)]
	public unsafe void ToggleDownloadBar(bool toggle)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref toggle;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_ToggleDownloadBar_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060042FF RID: 17151 RVA: 0x0010DE90 File Offset: 0x0010C090
	[CallerCount(0)]
	public unsafe void UpdateMapLoadProgress(float progress)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref progress;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_UpdateMapLoadProgress_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004300 RID: 17152 RVA: 0x0010DEE4 File Offset: 0x0010C0E4
	[CallerCount(0)]
	public unsafe void SetDownloadBarRetryCaption(int retryCurrent, int retryTotal)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref retryCurrent;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref retryTotal;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarRetryCaption_Public_Void_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004301 RID: 17153 RVA: 0x0010DF4C File Offset: 0x0010C14C
	[CallerCount(0)]
	public unsafe void SetDownloadBarRetryProgress(float timeStarted, float timeEnded)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref timeStarted;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref timeEnded;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarRetryProgress_Public_Void_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004302 RID: 17154 RVA: 0x0010DFB4 File Offset: 0x0010C1B4
	[CallerCount(0)]
	public unsafe void SetDownloadBarProgressAndCapacity(int usedMegabytes, int totalMegabytes)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref usedMegabytes;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref totalMegabytes;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarProgressAndCapacity_Public_Void_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004303 RID: 17155 RVA: 0x0010E01C File Offset: 0x0010C21C
	[CallerCount(0)]
	public unsafe void SetDownloadBarProgressAndSpeed(float progress, float speed, float time)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref progress;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref speed;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref time;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarProgressAndSpeed_Public_Void_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004304 RID: 17156 RVA: 0x0010E098 File Offset: 0x0010C298
	[CallerCount(0)]
	public unsafe void SetStatusText(string text, Color color)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(text);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref color;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr_SetStatusText_Public_Void_String_Color_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004305 RID: 17157 RVA: 0x0010E104 File Offset: 0x0010C304
	[CallerCount(0)]
	public unsafe CustomContentLoadingScreen() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentLoadingScreen.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004306 RID: 17158 RVA: 0x0010E150 File Offset: 0x0010C350
	// Note: this type is marked as 'beforefieldinit'.
	static CustomContentLoadingScreen()
	{
		Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CustomContentLoadingScreen");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr);
		CustomContentLoadingScreen.NativeFieldInfoPtr_STATUS_TEXT_ALPHA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "STATUS_TEXT_ALPHA");
		CustomContentLoadingScreen.NativeFieldInfoPtr_StatusText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "StatusText");
		CustomContentLoadingScreen.NativeFieldInfoPtr_MapName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "MapName");
		CustomContentLoadingScreen.NativeFieldInfoPtr_MapDesc = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "MapDesc");
		CustomContentLoadingScreen.NativeFieldInfoPtr_ModeName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "ModeName");
		CustomContentLoadingScreen.NativeFieldInfoPtr_ModeDesc = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "ModeDesc");
		CustomContentLoadingScreen.NativeFieldInfoPtr_MapProgress = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "MapProgress");
		CustomContentLoadingScreen.NativeFieldInfoPtr_ImgThumb = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "ImgThumb");
		CustomContentLoadingScreen.NativeFieldInfoPtr_workshopDownloadBar = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "workshopDownloadBar");
		CustomContentLoadingScreen.NativeFieldInfoPtr__workshopTextureCache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "_workshopTextureCache");
		CustomContentLoadingScreen.NativeFieldInfoPtr_m_thumbDownloadState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, "m_thumbDownloadState");
		CustomContentLoadingScreen.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668628);
		CustomContentLoadingScreen.NativeMethodInfoPtr_Init_Public_Void_String_WorkshopItem_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668629);
		CustomContentLoadingScreen.NativeMethodInfoPtr_ToggleDownloadBar_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668630);
		CustomContentLoadingScreen.NativeMethodInfoPtr_UpdateMapLoadProgress_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668631);
		CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarRetryCaption_Public_Void_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668632);
		CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarRetryProgress_Public_Void_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668633);
		CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarProgressAndCapacity_Public_Void_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668634);
		CustomContentLoadingScreen.NativeMethodInfoPtr_SetDownloadBarProgressAndSpeed_Public_Void_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668635);
		CustomContentLoadingScreen.NativeMethodInfoPtr_SetStatusText_Public_Void_String_Color_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668636);
		CustomContentLoadingScreen.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr, 100668637);
	}

	// Token: 0x06004307 RID: 17159 RVA: 0x0010E324 File Offset: 0x0010C524
	public CustomContentLoadingScreen(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170017C2 RID: 6082
	// (get) Token: 0x06004308 RID: 17160 RVA: 0x0010E32D File Offset: 0x0010C52D
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentLoadingScreen>.NativeClassPtr));
		}
	}

	// Token: 0x170017C3 RID: 6083
	// (get) Token: 0x06004309 RID: 17161 RVA: 0x0010E340 File Offset: 0x0010C540
	// (set) Token: 0x0600430A RID: 17162 RVA: 0x0010E35E File Offset: 0x0010C55E
	public unsafe static float STATUS_TEXT_ALPHA
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(CustomContentLoadingScreen.NativeFieldInfoPtr_STATUS_TEXT_ALPHA, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomContentLoadingScreen.NativeFieldInfoPtr_STATUS_TEXT_ALPHA, (void*)(&value));
		}
	}

	// Token: 0x170017C4 RID: 6084
	// (get) Token: 0x0600430B RID: 17163 RVA: 0x0010E370 File Offset: 0x0010C570
	// (set) Token: 0x0600430C RID: 17164 RVA: 0x0010E3A4 File Offset: 0x0010C5A4
	public unsafe TextMeshProUGUI StatusText
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_StatusText);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_StatusText), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017C5 RID: 6085
	// (get) Token: 0x0600430D RID: 17165 RVA: 0x0010E3CC File Offset: 0x0010C5CC
	// (set) Token: 0x0600430E RID: 17166 RVA: 0x0010E400 File Offset: 0x0010C600
	public unsafe TextMeshProUGUI MapName
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapName);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapName), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017C6 RID: 6086
	// (get) Token: 0x0600430F RID: 17167 RVA: 0x0010E428 File Offset: 0x0010C628
	// (set) Token: 0x06004310 RID: 17168 RVA: 0x0010E45C File Offset: 0x0010C65C
	public unsafe TextMeshProUGUI MapDesc
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapDesc);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapDesc), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017C7 RID: 6087
	// (get) Token: 0x06004311 RID: 17169 RVA: 0x0010E484 File Offset: 0x0010C684
	// (set) Token: 0x06004312 RID: 17170 RVA: 0x0010E4B8 File Offset: 0x0010C6B8
	public unsafe TextMeshProUGUI ModeName
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ModeName);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ModeName), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017C8 RID: 6088
	// (get) Token: 0x06004313 RID: 17171 RVA: 0x0010E4E0 File Offset: 0x0010C6E0
	// (set) Token: 0x06004314 RID: 17172 RVA: 0x0010E514 File Offset: 0x0010C714
	public unsafe TextMeshProUGUI ModeDesc
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ModeDesc);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ModeDesc), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017C9 RID: 6089
	// (get) Token: 0x06004315 RID: 17173 RVA: 0x0010E53C File Offset: 0x0010C73C
	// (set) Token: 0x06004316 RID: 17174 RVA: 0x0010E570 File Offset: 0x0010C770
	public unsafe TextMeshProUGUI MapProgress
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapProgress);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_MapProgress), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017CA RID: 6090
	// (get) Token: 0x06004317 RID: 17175 RVA: 0x0010E598 File Offset: 0x0010C798
	// (set) Token: 0x06004318 RID: 17176 RVA: 0x0010E5CC File Offset: 0x0010C7CC
	public unsafe Image ImgThumb
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ImgThumb);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Image(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_ImgThumb), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017CB RID: 6091
	// (get) Token: 0x06004319 RID: 17177 RVA: 0x0010E5F4 File Offset: 0x0010C7F4
	// (set) Token: 0x0600431A RID: 17178 RVA: 0x0010E628 File Offset: 0x0010C828
	public unsafe WorkshopBar workshopDownloadBar
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_workshopDownloadBar);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WorkshopBar(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_workshopDownloadBar), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017CC RID: 6092
	// (get) Token: 0x0600431B RID: 17179 RVA: 0x0010E650 File Offset: 0x0010C850
	// (set) Token: 0x0600431C RID: 17180 RVA: 0x0010E67B File Offset: 0x0010C87B
	public new unsafe static WorkshopTextureCache _workshopTextureCache
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(CustomContentLoadingScreen.NativeFieldInfoPtr__workshopTextureCache, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new WorkshopTextureCache(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(CustomContentLoadingScreen.NativeFieldInfoPtr__workshopTextureCache, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170017CD RID: 6093
	// (get) Token: 0x0600431D RID: 17181 RVA: 0x0010E690 File Offset: 0x0010C890
	// (set) Token: 0x0600431E RID: 17182 RVA: 0x0010E6C4 File Offset: 0x0010C8C4
	public unsafe WorkshopTextureState m_thumbDownloadState
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_m_thumbDownloadState);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new WorkshopTextureState(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentLoadingScreen.NativeFieldInfoPtr_m_thumbDownloadState), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002AEB RID: 10987
	private static readonly IntPtr NativeFieldInfoPtr_STATUS_TEXT_ALPHA;

	// Token: 0x04002AEC RID: 10988
	private static readonly IntPtr NativeFieldInfoPtr_StatusText;

	// Token: 0x04002AED RID: 10989
	private static readonly IntPtr NativeFieldInfoPtr_MapName;

	// Token: 0x04002AEE RID: 10990
	private static readonly IntPtr NativeFieldInfoPtr_MapDesc;

	// Token: 0x04002AEF RID: 10991
	private static readonly IntPtr NativeFieldInfoPtr_ModeName;

	// Token: 0x04002AF0 RID: 10992
	private static readonly IntPtr NativeFieldInfoPtr_ModeDesc;

	// Token: 0x04002AF1 RID: 10993
	private static readonly IntPtr NativeFieldInfoPtr_MapProgress;

	// Token: 0x04002AF2 RID: 10994
	private static readonly IntPtr NativeFieldInfoPtr_ImgThumb;

	// Token: 0x04002AF3 RID: 10995
	private static readonly IntPtr NativeFieldInfoPtr_workshopDownloadBar;

	// Token: 0x04002AF4 RID: 10996
	private static readonly IntPtr NativeFieldInfoPtr__workshopTextureCache;

	// Token: 0x04002AF5 RID: 10997
	private static readonly IntPtr NativeFieldInfoPtr_m_thumbDownloadState;

	// Token: 0x04002AF6 RID: 10998
	private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

	// Token: 0x04002AF7 RID: 10999
	private static readonly IntPtr NativeMethodInfoPtr_Init_Public_Void_String_WorkshopItem_0;

	// Token: 0x04002AF8 RID: 11000
	private static readonly IntPtr NativeMethodInfoPtr_ToggleDownloadBar_Public_Void_Boolean_0;

	// Token: 0x04002AF9 RID: 11001
	private static readonly IntPtr NativeMethodInfoPtr_UpdateMapLoadProgress_Public_Void_Single_0;

	// Token: 0x04002AFA RID: 11002
	private static readonly IntPtr NativeMethodInfoPtr_SetDownloadBarRetryCaption_Public_Void_Int32_Int32_0;

	// Token: 0x04002AFB RID: 11003
	private static readonly IntPtr NativeMethodInfoPtr_SetDownloadBarRetryProgress_Public_Void_Single_Single_0;

	// Token: 0x04002AFC RID: 11004
	private static readonly IntPtr NativeMethodInfoPtr_SetDownloadBarProgressAndCapacity_Public_Void_Int32_Int32_0;

	// Token: 0x04002AFD RID: 11005
	private static readonly IntPtr NativeMethodInfoPtr_SetDownloadBarProgressAndSpeed_Public_Void_Single_Single_Single_0;

	// Token: 0x04002AFE RID: 11006
	private static readonly IntPtr NativeMethodInfoPtr_SetStatusText_Public_Void_String_Color_0;

	// Token: 0x04002AFF RID: 11007
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
