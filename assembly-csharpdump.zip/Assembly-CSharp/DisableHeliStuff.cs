﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020000D1 RID: 209
public class DisableHeliStuff : MonoBehaviour
{
	// Token: 0x06000CD9 RID: 3289 RVA: 0x00034118 File Offset: 0x00032318
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableHeliStuff.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x0003415C File Offset: 0x0003235C
	[CallerCount(0)]
	public unsafe DisableHeliStuff() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableHeliStuff.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000CDB RID: 3291 RVA: 0x000341A8 File Offset: 0x000323A8
	// Note: this type is marked as 'beforefieldinit'.
	static DisableHeliStuff()
	{
		Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DisableHeliStuff");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr);
		DisableHeliStuff.NativeFieldInfoPtr_HeliLights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, "HeliLights");
		DisableHeliStuff.NativeFieldInfoPtr_HeliMeshes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, "HeliMeshes");
		DisableHeliStuff.NativeFieldInfoPtr_Lights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, "Lights");
		DisableHeliStuff.NativeFieldInfoPtr_MeshOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, "MeshOn");
		DisableHeliStuff.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, 100664303);
		DisableHeliStuff.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr, 100664304);
	}

	// Token: 0x06000CDC RID: 3292 RVA: 0x0000210C File Offset: 0x0000030C
	public DisableHeliStuff(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700046C RID: 1132
	// (get) Token: 0x06000CDD RID: 3293 RVA: 0x00034250 File Offset: 0x00032450
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DisableHeliStuff>.NativeClassPtr));
		}
	}

	// Token: 0x1700046D RID: 1133
	// (get) Token: 0x06000CDE RID: 3294 RVA: 0x00034264 File Offset: 0x00032464
	// (set) Token: 0x06000CDF RID: 3295 RVA: 0x00034298 File Offset: 0x00032498
	public unsafe Il2CppReferenceArray<Light> HeliLights
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_HeliLights);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<Light>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_HeliLights), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700046E RID: 1134
	// (get) Token: 0x06000CE0 RID: 3296 RVA: 0x000342C0 File Offset: 0x000324C0
	// (set) Token: 0x06000CE1 RID: 3297 RVA: 0x000342F4 File Offset: 0x000324F4
	public unsafe Il2CppReferenceArray<MeshRenderer> HeliMeshes
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_HeliMeshes);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<MeshRenderer>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_HeliMeshes), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x1700046F RID: 1135
	// (get) Token: 0x06000CE2 RID: 3298 RVA: 0x0003431C File Offset: 0x0003251C
	// (set) Token: 0x06000CE3 RID: 3299 RVA: 0x00034344 File Offset: 0x00032544
	public unsafe bool Lights
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_Lights);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_Lights)) = value;
		}
	}

	// Token: 0x17000470 RID: 1136
	// (get) Token: 0x06000CE4 RID: 3300 RVA: 0x00034368 File Offset: 0x00032568
	// (set) Token: 0x06000CE5 RID: 3301 RVA: 0x00034390 File Offset: 0x00032590
	public unsafe bool MeshOn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_MeshOn);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableHeliStuff.NativeFieldInfoPtr_MeshOn)) = value;
		}
	}

	// Token: 0x040007C5 RID: 1989
	private static readonly IntPtr NativeFieldInfoPtr_HeliLights;

	// Token: 0x040007C6 RID: 1990
	private static readonly IntPtr NativeFieldInfoPtr_HeliMeshes;

	// Token: 0x040007C7 RID: 1991
	private static readonly IntPtr NativeFieldInfoPtr_Lights;

	// Token: 0x040007C8 RID: 1992
	private static readonly IntPtr NativeFieldInfoPtr_MeshOn;

	// Token: 0x040007C9 RID: 1993
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040007CA RID: 1994
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
