﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200031B RID: 795
public class CasingPooledObject : PooledObject
{
	// Token: 0x06003EA4 RID: 16036 RVA: 0x000FCBDC File Offset: 0x000FADDC
	[CallerCount(0)]
	public new unsafe void OnCreatedInPool()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), CasingPooledObject.NativeMethodInfoPtr_OnCreatedInPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003EA5 RID: 16037 RVA: 0x000FCC2C File Offset: 0x000FAE2C
	[CallerCount(0)]
	public unsafe CasingPooledObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CasingPooledObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06003EA6 RID: 16038 RVA: 0x000FCC78 File Offset: 0x000FAE78
	// Note: this type is marked as 'beforefieldinit'.
	static CasingPooledObject()
	{
		Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CasingPooledObject");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr);
		CasingPooledObject.NativeFieldInfoPtr_Casing = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr, "Casing");
		CasingPooledObject.NativeMethodInfoPtr_OnCreatedInPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr, 100668304);
		CasingPooledObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr, 100668305);
	}

	// Token: 0x06003EA7 RID: 16039 RVA: 0x000FCB64 File Offset: 0x000FAD64
	public CasingPooledObject(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x1700162D RID: 5677
	// (get) Token: 0x06003EA8 RID: 16040 RVA: 0x000FCCE4 File Offset: 0x000FAEE4
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CasingPooledObject>.NativeClassPtr));
		}
	}

	// Token: 0x1700162E RID: 5678
	// (get) Token: 0x06003EA9 RID: 16041 RVA: 0x000FCCF8 File Offset: 0x000FAEF8
	// (set) Token: 0x06003EAA RID: 16042 RVA: 0x000FCD2C File Offset: 0x000FAF2C
	public unsafe CasingScript Casing
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingPooledObject.NativeFieldInfoPtr_Casing);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new CasingScript(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CasingPooledObject.NativeFieldInfoPtr_Casing), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002830 RID: 10288
	private static readonly IntPtr NativeFieldInfoPtr_Casing;

	// Token: 0x04002831 RID: 10289
	private static readonly IntPtr NativeMethodInfoPtr_OnCreatedInPool_Public_Virtual_Void_0;

	// Token: 0x04002832 RID: 10290
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
