﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000018 RID: 24
public class BoundsLockedObject : MonoBehaviour
{
	// Token: 0x06000144 RID: 324 RVA: 0x000079F8 File Offset: 0x00005BF8
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoundsLockedObject.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000145 RID: 325 RVA: 0x00007A3C File Offset: 0x00005C3C
	[CallerCount(0)]
	public unsafe void RefreshDisplay()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoundsLockedObject.NativeMethodInfoPtr_RefreshDisplay_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000146 RID: 326 RVA: 0x00007A80 File Offset: 0x00005C80
	[CallerCount(0)]
	public unsafe BoundsLockedObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BoundsLockedObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000147 RID: 327 RVA: 0x00007ACC File Offset: 0x00005CCC
	// Note: this type is marked as 'beforefieldinit'.
	static BoundsLockedObject()
	{
		Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "BoundsLockedObject");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr);
		BoundsLockedObject.NativeFieldInfoPtr_m_initialOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, "m_initialOffset");
		BoundsLockedObject.NativeFieldInfoPtr_m_playerOrigin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, "m_playerOrigin");
		BoundsLockedObject.NativeFieldInfoPtr_m_enforcer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, "m_enforcer");
		BoundsLockedObject.NativeFieldInfoPtr_m_bounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, "m_bounds");
		BoundsLockedObject.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, 100663422);
		BoundsLockedObject.NativeMethodInfoPtr_RefreshDisplay_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, 100663423);
		BoundsLockedObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr, 100663424);
	}

	// Token: 0x06000148 RID: 328 RVA: 0x0000210C File Offset: 0x0000030C
	public BoundsLockedObject(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x06000149 RID: 329 RVA: 0x00007B88 File Offset: 0x00005D88
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BoundsLockedObject>.NativeClassPtr));
		}
	}

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x0600014A RID: 330 RVA: 0x00007B9C File Offset: 0x00005D9C
	// (set) Token: 0x0600014B RID: 331 RVA: 0x00007BC4 File Offset: 0x00005DC4
	public unsafe Vector3 m_initialOffset
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_initialOffset);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_initialOffset)) = value;
		}
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x0600014C RID: 332 RVA: 0x00007BE8 File Offset: 0x00005DE8
	// (set) Token: 0x0600014D RID: 333 RVA: 0x00007C1C File Offset: 0x00005E1C
	public unsafe OVRCameraRig m_playerOrigin
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_playerOrigin);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new OVRCameraRig(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_playerOrigin), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000058 RID: 88
	// (get) Token: 0x0600014E RID: 334 RVA: 0x00007C44 File Offset: 0x00005E44
	// (set) Token: 0x0600014F RID: 335 RVA: 0x00007C78 File Offset: 0x00005E78
	public unsafe GuardianBoundaryEnforcer m_enforcer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_enforcer);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GuardianBoundaryEnforcer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_enforcer), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x06000150 RID: 336 RVA: 0x00007CA0 File Offset: 0x00005EA0
	// (set) Token: 0x06000151 RID: 337 RVA: 0x00007CD2 File Offset: 0x00005ED2
	public Nullable<Bounds> m_bounds
	{
		get
		{
			IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_bounds);
			return new Nullable<Bounds>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<Nullable<Bounds>>.NativeClassPtr, data));
		}
		set
		{
			cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BoundsLockedObject.NativeFieldInfoPtr_m_bounds), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<Nullable<Bounds>>.NativeClassPtr, (UIntPtr)0));
		}
	}

	// Token: 0x040000BE RID: 190
	private static readonly IntPtr NativeFieldInfoPtr_m_initialOffset;

	// Token: 0x040000BF RID: 191
	private static readonly IntPtr NativeFieldInfoPtr_m_playerOrigin;

	// Token: 0x040000C0 RID: 192
	private static readonly IntPtr NativeFieldInfoPtr_m_enforcer;

	// Token: 0x040000C1 RID: 193
	private static readonly IntPtr NativeFieldInfoPtr_m_bounds;

	// Token: 0x040000C2 RID: 194
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x040000C3 RID: 195
	private static readonly IntPtr NativeMethodInfoPtr_RefreshDisplay_Private_Void_0;

	// Token: 0x040000C4 RID: 196
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
