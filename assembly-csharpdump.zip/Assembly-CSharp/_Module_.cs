﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x02000002 RID: 2
[ObfuscatedName("<Module>")]
public class _Module_ : Il2CppObjectBase
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	// Note: this type is marked as 'beforefieldinit'.
	static _Module_()
	{
		Il2CppClassPointerStore<global::_Module_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "<Module>");
	}

	// Token: 0x06000002 RID: 2 RVA: 0x0000206B File Offset: 0x0000026B
	public _Module_(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000003 RID: 3 RVA: 0x00002074 File Offset: 0x00000274
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_Module_>.NativeClassPtr));
		}
	}
}
