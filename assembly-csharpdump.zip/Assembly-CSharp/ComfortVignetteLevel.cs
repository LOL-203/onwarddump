﻿using System;

// Token: 0x020001AF RID: 431
public enum ComfortVignetteLevel
{
	// Token: 0x040012D1 RID: 4817
	Off,
	// Token: 0x040012D2 RID: 4818
	Low,
	// Token: 0x040012D3 RID: 4819
	Medium,
	// Token: 0x040012D4 RID: 4820
	High
}
