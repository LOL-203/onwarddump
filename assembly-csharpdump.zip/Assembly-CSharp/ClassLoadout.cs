﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward;
using Onward.Data;
using Onward.Weapons;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x0200022C RID: 556
public class ClassLoadout : ScriptableObject
{
	// Token: 0x060027CD RID: 10189 RVA: 0x0009E048 File Offset: 0x0009C248
	[CallerCount(0)]
	public unsafe static List<WeaponAttachment.AttachmentType> GetAttachmentsFromString(string attachmentsSaveData)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(attachmentsSaveData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetAttachmentsFromString_Public_Static_List_1_AttachmentType_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
	}

	// Token: 0x060027CE RID: 10190 RVA: 0x0009E0A8 File Offset: 0x0009C2A8
	[CallerCount(0)]
	public unsafe static string GetStringFromAttachments(List<WeaponAttachment.AttachmentType> attachments)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(attachments);
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetStringFromAttachments_Public_Static_String_List_1_AttachmentType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x060027CF RID: 10191 RVA: 0x0009E0FC File Offset: 0x0009C2FC
	[CallerCount(0)]
	public unsafe static List<ClassLoadout.EquipmentType> GetEquipmentFromString(string equipmentSaveData)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(equipmentSaveData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetEquipmentFromString_Public_Static_List_1_EquipmentType_String_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new List<ClassLoadout.EquipmentType>(intPtr2) : null;
	}

	// Token: 0x060027D0 RID: 10192 RVA: 0x0009E15C File Offset: 0x0009C35C
	[CallerCount(0)]
	public unsafe static string GetStringFromEquipment(List<ClassLoadout.EquipmentType> equipments)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(equipments);
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetStringFromEquipment_Public_Static_String_List_1_EquipmentType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x060027D1 RID: 10193 RVA: 0x0009E1B0 File Offset: 0x0009C3B0
	[CallerCount(0)]
	public unsafe static string GetStringFromIntArray(Il2CppStructArray<int> values)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(values);
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetStringFromIntArray_Private_Static_String_ArrayOf_Int32_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x060027D2 RID: 10194 RVA: 0x0009E204 File Offset: 0x0009C404
	[CallerCount(0)]
	public unsafe static bool AmmoPiercesArmor([In] ref ClassLoadout.AmmoType type)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &type;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_AmmoPiercesArmor_Public_Static_Boolean_byref_AmmoType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060027D3 RID: 10195 RVA: 0x0009E258 File Offset: 0x0009C458
	[CallerCount(0)]
	public unsafe static bool AmmoIsFMJ([In] ref ClassLoadout.AmmoType type)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &type;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_AmmoIsFMJ_Public_Static_Boolean_byref_AmmoType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060027D4 RID: 10196 RVA: 0x0009E2AC File Offset: 0x0009C4AC
	[CallerCount(0)]
	public unsafe void DoValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_DoValidate_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060027D5 RID: 10197 RVA: 0x0009E2F0 File Offset: 0x0009C4F0
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060027D6 RID: 10198 RVA: 0x0009E334 File Offset: 0x0009C534
	[CallerCount(0)]
	public unsafe static string GetReadableType([In] ref ClassLoadout.AmmoType type)
	{
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = &type;
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetReadableType_Public_Static_String_byref_AmmoType_0, 0, (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x060027D7 RID: 10199 RVA: 0x0009E384 File Offset: 0x0009C584
	[CallerCount(0)]
	public unsafe static float GetStartingArmorHealth()
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr_GetStartingArmorHealth_Public_Static_Single_0, 0, (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060027D8 RID: 10200 RVA: 0x0009E3C8 File Offset: 0x0009C5C8
	[CallerCount(0)]
	public unsafe ClassLoadout() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060027D9 RID: 10201 RVA: 0x0009E414 File Offset: 0x0009C614
	// Note: this type is marked as 'beforefieldinit'.
	static ClassLoadout()
	{
		Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ClassLoadout");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr);
		ClassLoadout.NativeFieldInfoPtr_SavePrimary = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SavePrimary");
		ClassLoadout.NativeFieldInfoPtr_SavePrimaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SavePrimaryAttachments");
		ClassLoadout.NativeFieldInfoPtr_SavePrimaryAmmo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SavePrimaryAmmo");
		ClassLoadout.NativeFieldInfoPtr_SaveSecondary = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SaveSecondary");
		ClassLoadout.NativeFieldInfoPtr_SaveSecondaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SaveSecondaryAttachments");
		ClassLoadout.NativeFieldInfoPtr_SaveEquipment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SaveEquipment");
		ClassLoadout.NativeFieldInfoPtr_SaveExplosive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SaveExplosive");
		ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_WEAPONSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "ASSETS_DATA_WEAPONS_WEAPONSO");
		ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_ATTACHMENTSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "ASSETS_DATA_WEAPONS_ATTACHMENTSO");
		ClassLoadout.NativeFieldInfoPtr_faction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "faction");
		ClassLoadout.NativeFieldInfoPtr_soldierClass = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "soldierClass");
		ClassLoadout.NativeFieldInfoPtr_PointsMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "PointsMax");
		ClassLoadout.NativeFieldInfoPtr_NeverAllowedAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "NeverAllowedAttachments");
		ClassLoadout.NativeFieldInfoPtr_CustomAttachmentCosts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "CustomAttachmentCosts");
		ClassLoadout.NativeFieldInfoPtr_PrimaryWeapons = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "PrimaryWeapons");
		ClassLoadout.NativeFieldInfoPtr_SecondaryWeapons = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "SecondaryWeapons");
		ClassLoadout.NativeFieldInfoPtr_Explosives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "Explosives");
		ClassLoadout.NativeFieldInfoPtr_Equipment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "Equipment");
		ClassLoadout.NativeMethodInfoPtr_GetAttachmentsFromString_Public_Static_List_1_AttachmentType_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666388);
		ClassLoadout.NativeMethodInfoPtr_GetStringFromAttachments_Public_Static_String_List_1_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666389);
		ClassLoadout.NativeMethodInfoPtr_GetEquipmentFromString_Public_Static_List_1_EquipmentType_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666390);
		ClassLoadout.NativeMethodInfoPtr_GetStringFromEquipment_Public_Static_String_List_1_EquipmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666391);
		ClassLoadout.NativeMethodInfoPtr_GetStringFromIntArray_Private_Static_String_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666392);
		ClassLoadout.NativeMethodInfoPtr_AmmoPiercesArmor_Public_Static_Boolean_byref_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666393);
		ClassLoadout.NativeMethodInfoPtr_AmmoIsFMJ_Public_Static_Boolean_byref_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666394);
		ClassLoadout.NativeMethodInfoPtr_DoValidate_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666395);
		ClassLoadout.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666396);
		ClassLoadout.NativeMethodInfoPtr_GetReadableType_Public_Static_String_byref_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666397);
		ClassLoadout.NativeMethodInfoPtr_GetStartingArmorHealth_Public_Static_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666398);
		ClassLoadout.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, 100666399);
	}

	// Token: 0x060027DA RID: 10202 RVA: 0x0002DD3C File Offset: 0x0002BF3C
	public ClassLoadout(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000E09 RID: 3593
	// (get) Token: 0x060027DB RID: 10203 RVA: 0x0009E69C File Offset: 0x0009C89C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr));
		}
	}

	// Token: 0x17000E0A RID: 3594
	// (get) Token: 0x060027DC RID: 10204 RVA: 0x0009E6B0 File Offset: 0x0009C8B0
	// (set) Token: 0x060027DD RID: 10205 RVA: 0x0009E6D0 File Offset: 0x0009C8D0
	public unsafe static string SavePrimary
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SavePrimary, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SavePrimary, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E0B RID: 3595
	// (get) Token: 0x060027DE RID: 10206 RVA: 0x0009E6E8 File Offset: 0x0009C8E8
	// (set) Token: 0x060027DF RID: 10207 RVA: 0x0009E708 File Offset: 0x0009C908
	public unsafe static string SavePrimaryAttachments
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SavePrimaryAttachments, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SavePrimaryAttachments, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E0C RID: 3596
	// (get) Token: 0x060027E0 RID: 10208 RVA: 0x0009E720 File Offset: 0x0009C920
	// (set) Token: 0x060027E1 RID: 10209 RVA: 0x0009E740 File Offset: 0x0009C940
	public unsafe static string SavePrimaryAmmo
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SavePrimaryAmmo, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SavePrimaryAmmo, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E0D RID: 3597
	// (get) Token: 0x060027E2 RID: 10210 RVA: 0x0009E758 File Offset: 0x0009C958
	// (set) Token: 0x060027E3 RID: 10211 RVA: 0x0009E778 File Offset: 0x0009C978
	public unsafe static string SaveSecondary
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SaveSecondary, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SaveSecondary, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E0E RID: 3598
	// (get) Token: 0x060027E4 RID: 10212 RVA: 0x0009E790 File Offset: 0x0009C990
	// (set) Token: 0x060027E5 RID: 10213 RVA: 0x0009E7B0 File Offset: 0x0009C9B0
	public unsafe static string SaveSecondaryAttachments
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SaveSecondaryAttachments, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SaveSecondaryAttachments, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E0F RID: 3599
	// (get) Token: 0x060027E6 RID: 10214 RVA: 0x0009E7C8 File Offset: 0x0009C9C8
	// (set) Token: 0x060027E7 RID: 10215 RVA: 0x0009E7E8 File Offset: 0x0009C9E8
	public unsafe static string SaveEquipment
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SaveEquipment, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SaveEquipment, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E10 RID: 3600
	// (get) Token: 0x060027E8 RID: 10216 RVA: 0x0009E800 File Offset: 0x0009CA00
	// (set) Token: 0x060027E9 RID: 10217 RVA: 0x0009E820 File Offset: 0x0009CA20
	public unsafe static string SaveExplosive
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_SaveExplosive, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_SaveExplosive, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E11 RID: 3601
	// (get) Token: 0x060027EA RID: 10218 RVA: 0x0009E838 File Offset: 0x0009CA38
	// (set) Token: 0x060027EB RID: 10219 RVA: 0x0009E858 File Offset: 0x0009CA58
	public unsafe static string ASSETS_DATA_WEAPONS_WEAPONSO
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_WEAPONSO, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_WEAPONSO, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E12 RID: 3602
	// (get) Token: 0x060027EC RID: 10220 RVA: 0x0009E870 File Offset: 0x0009CA70
	// (set) Token: 0x060027ED RID: 10221 RVA: 0x0009E890 File Offset: 0x0009CA90
	public unsafe static string ASSETS_DATA_WEAPONS_ATTACHMENTSO
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_ATTACHMENTSO, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ClassLoadout.NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_ATTACHMENTSO, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17000E13 RID: 3603
	// (get) Token: 0x060027EE RID: 10222 RVA: 0x0009E8A8 File Offset: 0x0009CAA8
	// (set) Token: 0x060027EF RID: 10223 RVA: 0x0009E8D0 File Offset: 0x0009CAD0
	public unsafe Faction faction
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_faction);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_faction)) = value;
		}
	}

	// Token: 0x17000E14 RID: 3604
	// (get) Token: 0x060027F0 RID: 10224 RVA: 0x0009E8F4 File Offset: 0x0009CAF4
	// (set) Token: 0x060027F1 RID: 10225 RVA: 0x0009E91C File Offset: 0x0009CB1C
	public unsafe SoldierClass soldierClass
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_soldierClass);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_soldierClass)) = value;
		}
	}

	// Token: 0x17000E15 RID: 3605
	// (get) Token: 0x060027F2 RID: 10226 RVA: 0x0009E940 File Offset: 0x0009CB40
	// (set) Token: 0x060027F3 RID: 10227 RVA: 0x0009E968 File Offset: 0x0009CB68
	public unsafe int PointsMax
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_PointsMax);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_PointsMax)) = value;
		}
	}

	// Token: 0x17000E16 RID: 3606
	// (get) Token: 0x060027F4 RID: 10228 RVA: 0x0009E98C File Offset: 0x0009CB8C
	// (set) Token: 0x060027F5 RID: 10229 RVA: 0x0009E9C0 File Offset: 0x0009CBC0
	public unsafe List<WeaponAttachment.AttachmentType> NeverAllowedAttachments
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_NeverAllowedAttachments);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_NeverAllowedAttachments), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000E17 RID: 3607
	// (get) Token: 0x060027F6 RID: 10230 RVA: 0x0009E9E8 File Offset: 0x0009CBE8
	// (set) Token: 0x060027F7 RID: 10231 RVA: 0x0009EA1C File Offset: 0x0009CC1C
	public unsafe Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointModifier> CustomAttachmentCosts
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_CustomAttachmentCosts);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointModifier>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_CustomAttachmentCosts), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000E18 RID: 3608
	// (get) Token: 0x060027F8 RID: 10232 RVA: 0x0009EA44 File Offset: 0x0009CC44
	// (set) Token: 0x060027F9 RID: 10233 RVA: 0x0009EA78 File Offset: 0x0009CC78
	public unsafe Il2CppReferenceArray<ClassLoadout.WeaponPointObject> PrimaryWeapons
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_PrimaryWeapons);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.WeaponPointObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_PrimaryWeapons), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000E19 RID: 3609
	// (get) Token: 0x060027FA RID: 10234 RVA: 0x0009EAA0 File Offset: 0x0009CCA0
	// (set) Token: 0x060027FB RID: 10235 RVA: 0x0009EAD4 File Offset: 0x0009CCD4
	public unsafe Il2CppReferenceArray<ClassLoadout.WeaponPointObject> SecondaryWeapons
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_SecondaryWeapons);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.WeaponPointObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_SecondaryWeapons), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000E1A RID: 3610
	// (get) Token: 0x060027FC RID: 10236 RVA: 0x0009EAFC File Offset: 0x0009CCFC
	// (set) Token: 0x060027FD RID: 10237 RVA: 0x0009EB30 File Offset: 0x0009CD30
	public unsafe Il2CppReferenceArray<ClassLoadout.EquipmentObject> Explosives
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_Explosives);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.EquipmentObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_Explosives), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17000E1B RID: 3611
	// (get) Token: 0x060027FE RID: 10238 RVA: 0x0009EB58 File Offset: 0x0009CD58
	// (set) Token: 0x060027FF RID: 10239 RVA: 0x0009EB8C File Offset: 0x0009CD8C
	public unsafe Il2CppReferenceArray<ClassLoadout.EquipmentObject> Equipment
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_Equipment);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.EquipmentObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.NativeFieldInfoPtr_Equipment), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400195E RID: 6494
	private static readonly IntPtr NativeFieldInfoPtr_SavePrimary;

	// Token: 0x0400195F RID: 6495
	private static readonly IntPtr NativeFieldInfoPtr_SavePrimaryAttachments;

	// Token: 0x04001960 RID: 6496
	private static readonly IntPtr NativeFieldInfoPtr_SavePrimaryAmmo;

	// Token: 0x04001961 RID: 6497
	private static readonly IntPtr NativeFieldInfoPtr_SaveSecondary;

	// Token: 0x04001962 RID: 6498
	private static readonly IntPtr NativeFieldInfoPtr_SaveSecondaryAttachments;

	// Token: 0x04001963 RID: 6499
	private static readonly IntPtr NativeFieldInfoPtr_SaveEquipment;

	// Token: 0x04001964 RID: 6500
	private static readonly IntPtr NativeFieldInfoPtr_SaveExplosive;

	// Token: 0x04001965 RID: 6501
	private static readonly IntPtr NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_WEAPONSO;

	// Token: 0x04001966 RID: 6502
	private static readonly IntPtr NativeFieldInfoPtr_ASSETS_DATA_WEAPONS_ATTACHMENTSO;

	// Token: 0x04001967 RID: 6503
	private static readonly IntPtr NativeFieldInfoPtr_faction;

	// Token: 0x04001968 RID: 6504
	private static readonly IntPtr NativeFieldInfoPtr_soldierClass;

	// Token: 0x04001969 RID: 6505
	private static readonly IntPtr NativeFieldInfoPtr_PointsMax;

	// Token: 0x0400196A RID: 6506
	private static readonly IntPtr NativeFieldInfoPtr_NeverAllowedAttachments;

	// Token: 0x0400196B RID: 6507
	private static readonly IntPtr NativeFieldInfoPtr_CustomAttachmentCosts;

	// Token: 0x0400196C RID: 6508
	private static readonly IntPtr NativeFieldInfoPtr_PrimaryWeapons;

	// Token: 0x0400196D RID: 6509
	private static readonly IntPtr NativeFieldInfoPtr_SecondaryWeapons;

	// Token: 0x0400196E RID: 6510
	private static readonly IntPtr NativeFieldInfoPtr_Explosives;

	// Token: 0x0400196F RID: 6511
	private static readonly IntPtr NativeFieldInfoPtr_Equipment;

	// Token: 0x04001970 RID: 6512
	private static readonly IntPtr NativeMethodInfoPtr_GetAttachmentsFromString_Public_Static_List_1_AttachmentType_String_0;

	// Token: 0x04001971 RID: 6513
	private static readonly IntPtr NativeMethodInfoPtr_GetStringFromAttachments_Public_Static_String_List_1_AttachmentType_0;

	// Token: 0x04001972 RID: 6514
	private static readonly IntPtr NativeMethodInfoPtr_GetEquipmentFromString_Public_Static_List_1_EquipmentType_String_0;

	// Token: 0x04001973 RID: 6515
	private static readonly IntPtr NativeMethodInfoPtr_GetStringFromEquipment_Public_Static_String_List_1_EquipmentType_0;

	// Token: 0x04001974 RID: 6516
	private static readonly IntPtr NativeMethodInfoPtr_GetStringFromIntArray_Private_Static_String_ArrayOf_Int32_0;

	// Token: 0x04001975 RID: 6517
	private static readonly IntPtr NativeMethodInfoPtr_AmmoPiercesArmor_Public_Static_Boolean_byref_AmmoType_0;

	// Token: 0x04001976 RID: 6518
	private static readonly IntPtr NativeMethodInfoPtr_AmmoIsFMJ_Public_Static_Boolean_byref_AmmoType_0;

	// Token: 0x04001977 RID: 6519
	private static readonly IntPtr NativeMethodInfoPtr_DoValidate_Public_Void_0;

	// Token: 0x04001978 RID: 6520
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x04001979 RID: 6521
	private static readonly IntPtr NativeMethodInfoPtr_GetReadableType_Public_Static_String_byref_AmmoType_0;

	// Token: 0x0400197A RID: 6522
	private static readonly IntPtr NativeMethodInfoPtr_GetStartingArmorHealth_Public_Static_Single_0;

	// Token: 0x0400197B RID: 6523
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x0200022D RID: 557
	public enum AmmoType : byte
	{
		// Token: 0x0400197D RID: 6525
		NULL,
		// Token: 0x0400197E RID: 6526
		FMJ,
		// Token: 0x0400197F RID: 6527
		FMJTracer,
		// Token: 0x04001980 RID: 6528
		AP,
		// Token: 0x04001981 RID: 6529
		Shotgun_Buckshot,
		// Token: 0x04001982 RID: 6530
		Shotgun_Slug,
		// Token: 0x04001983 RID: 6531
		HighExplosive
	}

	// Token: 0x0200022E RID: 558
	[Serializable]
	public class WeaponPointObject : Il2CppSystem.Object
	{
		// Token: 0x06002802 RID: 10242 RVA: 0x0009EBD8 File Offset: 0x0009CDD8
		[CallerCount(0)]
		public unsafe bool SupportsAttachment(WeaponAttachment.AttachmentType attachment)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref attachment;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.WeaponPointObject.NativeMethodInfoPtr_SupportsAttachment_Public_Boolean_AttachmentType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06002803 RID: 10243 RVA: 0x0009EC3C File Offset: 0x0009CE3C
		[CallerCount(0)]
		public unsafe WeaponPointObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.WeaponPointObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06002804 RID: 10244 RVA: 0x0009EC88 File Offset: 0x0009CE88
		// Note: this type is marked as 'beforefieldinit'.
		static WeaponPointObject()
		{
			Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "WeaponPointObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr);
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "Name");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "WeaponName");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_ListOrderPriority = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "ListOrderPriority");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_PointValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "PointValue");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentSights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "AttatchmentSights");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentFront = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "AttatchmentFront");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AmmoObjects = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "AmmoObjects");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Data = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "Data");
			ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, "WeaponSO");
			ClassLoadout.WeaponPointObject.NativeMethodInfoPtr_SupportsAttachment_Public_Boolean_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, 100666400);
			ClassLoadout.WeaponPointObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr, 100666401);
		}

		// Token: 0x06002805 RID: 10245 RVA: 0x00002988 File Offset: 0x00000B88
		public WeaponPointObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000E1D RID: 3613
		// (get) Token: 0x06002806 RID: 10246 RVA: 0x0009ED8F File Offset: 0x0009CF8F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout.WeaponPointObject>.NativeClassPtr));
			}
		}

		// Token: 0x17000E1E RID: 3614
		// (get) Token: 0x06002807 RID: 10247 RVA: 0x0009EDA0 File Offset: 0x0009CFA0
		// (set) Token: 0x06002808 RID: 10248 RVA: 0x0009EDC9 File Offset: 0x0009CFC9
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000E1F RID: 3615
		// (get) Token: 0x06002809 RID: 10249 RVA: 0x0009EDF0 File Offset: 0x0009CFF0
		// (set) Token: 0x0600280A RID: 10250 RVA: 0x0009EE18 File Offset: 0x0009D018
		public unsafe WeaponName WeaponName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponName);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponName)) = value;
			}
		}

		// Token: 0x17000E20 RID: 3616
		// (get) Token: 0x0600280B RID: 10251 RVA: 0x0009EE3C File Offset: 0x0009D03C
		// (set) Token: 0x0600280C RID: 10252 RVA: 0x0009EE64 File Offset: 0x0009D064
		public unsafe int ListOrderPriority
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_ListOrderPriority);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_ListOrderPriority)) = value;
			}
		}

		// Token: 0x17000E21 RID: 3617
		// (get) Token: 0x0600280D RID: 10253 RVA: 0x0009EE88 File Offset: 0x0009D088
		// (set) Token: 0x0600280E RID: 10254 RVA: 0x0009EEB0 File Offset: 0x0009D0B0
		public unsafe int PointValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_PointValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_PointValue)) = value;
			}
		}

		// Token: 0x17000E22 RID: 3618
		// (get) Token: 0x0600280F RID: 10255 RVA: 0x0009EED4 File Offset: 0x0009D0D4
		// (set) Token: 0x06002810 RID: 10256 RVA: 0x0009EF08 File Offset: 0x0009D108
		public unsafe Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointObject> AttatchmentSights
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentSights);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentSights), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000E23 RID: 3619
		// (get) Token: 0x06002811 RID: 10257 RVA: 0x0009EF30 File Offset: 0x0009D130
		// (set) Token: 0x06002812 RID: 10258 RVA: 0x0009EF64 File Offset: 0x0009D164
		public unsafe Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointObject> AttatchmentFront
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentFront);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.WeaponAttachmentPointObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AttatchmentFront), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000E24 RID: 3620
		// (get) Token: 0x06002813 RID: 10259 RVA: 0x0009EF8C File Offset: 0x0009D18C
		// (set) Token: 0x06002814 RID: 10260 RVA: 0x0009EFC0 File Offset: 0x0009D1C0
		public unsafe Il2CppReferenceArray<ClassLoadout.AmmoObject> AmmoObjects
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AmmoObjects);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<ClassLoadout.AmmoObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_AmmoObjects), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000E25 RID: 3621
		// (get) Token: 0x06002815 RID: 10261 RVA: 0x0009EFE8 File Offset: 0x0009D1E8
		// (set) Token: 0x06002816 RID: 10262 RVA: 0x0009F01C File Offset: 0x0009D21C
		public unsafe WeaponData Data
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Data);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WeaponData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_Data), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000E26 RID: 3622
		// (get) Token: 0x06002817 RID: 10263 RVA: 0x0009F044 File Offset: 0x0009D244
		// (set) Token: 0x06002818 RID: 10264 RVA: 0x0009F078 File Offset: 0x0009D278
		public unsafe WeaponSO WeaponSO
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponSO);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WeaponSO(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponPointObject.NativeFieldInfoPtr_WeaponSO), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04001984 RID: 6532
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x04001985 RID: 6533
		private static readonly IntPtr NativeFieldInfoPtr_WeaponName;

		// Token: 0x04001986 RID: 6534
		private static readonly IntPtr NativeFieldInfoPtr_ListOrderPriority;

		// Token: 0x04001987 RID: 6535
		private static readonly IntPtr NativeFieldInfoPtr_PointValue;

		// Token: 0x04001988 RID: 6536
		private static readonly IntPtr NativeFieldInfoPtr_AttatchmentSights;

		// Token: 0x04001989 RID: 6537
		private static readonly IntPtr NativeFieldInfoPtr_AttatchmentFront;

		// Token: 0x0400198A RID: 6538
		private static readonly IntPtr NativeFieldInfoPtr_AmmoObjects;

		// Token: 0x0400198B RID: 6539
		private static readonly IntPtr NativeFieldInfoPtr_Data;

		// Token: 0x0400198C RID: 6540
		private static readonly IntPtr NativeFieldInfoPtr_WeaponSO;

		// Token: 0x0400198D RID: 6541
		private static readonly IntPtr NativeMethodInfoPtr_SupportsAttachment_Public_Boolean_AttachmentType_0;

		// Token: 0x0400198E RID: 6542
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x0200022F RID: 559
	[Serializable]
	public class WeaponAttachmentPointObject : Il2CppSystem.Object
	{
		// Token: 0x06002819 RID: 10265 RVA: 0x0009F0A0 File Offset: 0x0009D2A0
		[CallerCount(0)]
		public unsafe WeaponAttachmentPointObject(string Name, WeaponAttachment.AttachmentType Attachment, int PointValue) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(Name);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref Attachment;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref PointValue;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.WeaponAttachmentPointObject.NativeMethodInfoPtr__ctor_Public_Void_String_AttachmentType_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600281A RID: 10266 RVA: 0x0009F128 File Offset: 0x0009D328
		[CallerCount(0)]
		public unsafe WeaponAttachmentPointObject(AttachmentSettings attachmentSettings) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(attachmentSettings);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.WeaponAttachmentPointObject.NativeMethodInfoPtr__ctor_Public_Void_AttachmentSettings_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600281B RID: 10267 RVA: 0x0009F18C File Offset: 0x0009D38C
		// Note: this type is marked as 'beforefieldinit'.
		static WeaponAttachmentPointObject()
		{
			Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "WeaponAttachmentPointObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr);
			ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, "Name");
			ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Attachment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, "Attachment");
			ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_PointValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, "PointValue");
			ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_AttachmentSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, "AttachmentSO");
			ClassLoadout.WeaponAttachmentPointObject.NativeMethodInfoPtr__ctor_Public_Void_String_AttachmentType_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, 100666402);
			ClassLoadout.WeaponAttachmentPointObject.NativeMethodInfoPtr__ctor_Public_Void_AttachmentSettings_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr, 100666403);
		}

		// Token: 0x0600281C RID: 10268 RVA: 0x00002988 File Offset: 0x00000B88
		public WeaponAttachmentPointObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000E27 RID: 3623
		// (get) Token: 0x0600281D RID: 10269 RVA: 0x0009F22F File Offset: 0x0009D42F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointObject>.NativeClassPtr));
			}
		}

		// Token: 0x17000E28 RID: 3624
		// (get) Token: 0x0600281E RID: 10270 RVA: 0x0009F240 File Offset: 0x0009D440
		// (set) Token: 0x0600281F RID: 10271 RVA: 0x0009F269 File Offset: 0x0009D469
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000E29 RID: 3625
		// (get) Token: 0x06002820 RID: 10272 RVA: 0x0009F290 File Offset: 0x0009D490
		// (set) Token: 0x06002821 RID: 10273 RVA: 0x0009F2B8 File Offset: 0x0009D4B8
		public unsafe WeaponAttachment.AttachmentType Attachment
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Attachment);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_Attachment)) = value;
			}
		}

		// Token: 0x17000E2A RID: 3626
		// (get) Token: 0x06002822 RID: 10274 RVA: 0x0009F2DC File Offset: 0x0009D4DC
		// (set) Token: 0x06002823 RID: 10275 RVA: 0x0009F304 File Offset: 0x0009D504
		public unsafe int PointValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_PointValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_PointValue)) = value;
			}
		}

		// Token: 0x17000E2B RID: 3627
		// (get) Token: 0x06002824 RID: 10276 RVA: 0x0009F328 File Offset: 0x0009D528
		// (set) Token: 0x06002825 RID: 10277 RVA: 0x0009F35C File Offset: 0x0009D55C
		public unsafe AttachmentSO AttachmentSO
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_AttachmentSO);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AttachmentSO(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointObject.NativeFieldInfoPtr_AttachmentSO), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400198F RID: 6543
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x04001990 RID: 6544
		private static readonly IntPtr NativeFieldInfoPtr_Attachment;

		// Token: 0x04001991 RID: 6545
		private static readonly IntPtr NativeFieldInfoPtr_PointValue;

		// Token: 0x04001992 RID: 6546
		private static readonly IntPtr NativeFieldInfoPtr_AttachmentSO;

		// Token: 0x04001993 RID: 6547
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_AttachmentType_Int32_0;

		// Token: 0x04001994 RID: 6548
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_AttachmentSettings_0;
	}

	// Token: 0x02000230 RID: 560
	[Serializable]
	public class WeaponAttachmentPointModifier : Il2CppSystem.Object
	{
		// Token: 0x06002826 RID: 10278 RVA: 0x0009F384 File Offset: 0x0009D584
		[CallerCount(0)]
		public unsafe WeaponAttachmentPointModifier() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.WeaponAttachmentPointModifier.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06002827 RID: 10279 RVA: 0x0009F3D0 File Offset: 0x0009D5D0
		// Note: this type is marked as 'beforefieldinit'.
		static WeaponAttachmentPointModifier()
		{
			Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "WeaponAttachmentPointModifier");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr);
			ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_Attachment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr, "Attachment");
			ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_customPointValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr, "customPointValue");
			ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_AttachmentSO = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr, "AttachmentSO");
			ClassLoadout.WeaponAttachmentPointModifier.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr, 100666404);
		}

		// Token: 0x06002828 RID: 10280 RVA: 0x00002988 File Offset: 0x00000B88
		public WeaponAttachmentPointModifier(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000E2C RID: 3628
		// (get) Token: 0x06002829 RID: 10281 RVA: 0x0009F44B File Offset: 0x0009D64B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout.WeaponAttachmentPointModifier>.NativeClassPtr));
			}
		}

		// Token: 0x17000E2D RID: 3629
		// (get) Token: 0x0600282A RID: 10282 RVA: 0x0009F45C File Offset: 0x0009D65C
		// (set) Token: 0x0600282B RID: 10283 RVA: 0x0009F484 File Offset: 0x0009D684
		public unsafe WeaponAttachment.AttachmentType Attachment
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_Attachment);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_Attachment)) = value;
			}
		}

		// Token: 0x17000E2E RID: 3630
		// (get) Token: 0x0600282C RID: 10284 RVA: 0x0009F4A8 File Offset: 0x0009D6A8
		// (set) Token: 0x0600282D RID: 10285 RVA: 0x0009F4D0 File Offset: 0x0009D6D0
		public unsafe int customPointValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_customPointValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_customPointValue)) = value;
			}
		}

		// Token: 0x17000E2F RID: 3631
		// (get) Token: 0x0600282E RID: 10286 RVA: 0x0009F4F4 File Offset: 0x0009D6F4
		// (set) Token: 0x0600282F RID: 10287 RVA: 0x0009F528 File Offset: 0x0009D728
		public unsafe AttachmentSO AttachmentSO
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_AttachmentSO);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AttachmentSO(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.WeaponAttachmentPointModifier.NativeFieldInfoPtr_AttachmentSO), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04001995 RID: 6549
		private static readonly IntPtr NativeFieldInfoPtr_Attachment;

		// Token: 0x04001996 RID: 6550
		private static readonly IntPtr NativeFieldInfoPtr_customPointValue;

		// Token: 0x04001997 RID: 6551
		private static readonly IntPtr NativeFieldInfoPtr_AttachmentSO;

		// Token: 0x04001998 RID: 6552
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000231 RID: 561
	public enum EquipmentType
	{
		// Token: 0x0400199A RID: 6554
		NULL = -2,
		// Token: 0x0400199B RID: 6555
		None,
		// Token: 0x0400199C RID: 6556
		GrenadeSmokeWhite,
		// Token: 0x0400199D RID: 6557
		GrenadeStun,
		// Token: 0x0400199E RID: 6558
		GrenadeFrag,
		// Token: 0x0400199F RID: 6559
		BodyArmor,
		// Token: 0x040019A0 RID: 6560
		NightVision_PVS,
		// Token: 0x040019A1 RID: 6561
		SyringeExtra,
		// Token: 0x040019A2 RID: 6562
		Tablet,
		// Token: 0x040019A3 RID: 6563
		TabletWithDrone,
		// Token: 0x040019A4 RID: 6564
		TabletWithHacking,
		// Token: 0x040019A5 RID: 6565
		GrenadeIncendiary,
		// Token: 0x040019A6 RID: 6566
		GrenadeImpact,
		// Token: 0x040019A7 RID: 6567
		GrenadeMolotov,
		// Token: 0x040019A8 RID: 6568
		C4,
		// Token: 0x040019A9 RID: 6569
		Lighter,
		// Token: 0x040019AA RID: 6570
		C4Clacker,
		// Token: 0x040019AB RID: 6571
		GrenadeSmokeGreen,
		// Token: 0x040019AC RID: 6572
		GrenadeSmokeRed,
		// Token: 0x040019AD RID: 6573
		GrenadeSmokeViolet,
		// Token: 0x040019AE RID: 6574
		GrenadeSmokeYellow,
		// Token: 0x040019AF RID: 6575
		ShotgunBox,
		// Token: 0x040019B0 RID: 6576
		AmmoBox,
		// Token: 0x040019B1 RID: 6577
		PrimaryWeapon,
		// Token: 0x040019B2 RID: 6578
		SecondaryWeapon,
		// Token: 0x040019B3 RID: 6579
		TabletWithFlyingDrone = 30,
		// Token: 0x040019B4 RID: 6580
		TabletWithGroundDrone,
		// Token: 0x040019B5 RID: 6581
		KnifeMarsoc,
		// Token: 0x040019B6 RID: 6582
		KnifeVolk,
		// Token: 0x040019B7 RID: 6583
		ShotgunAmmo,
		// Token: 0x040019B8 RID: 6584
		Defibrillator = 40,
		// Token: 0x040019B9 RID: 6585
		Defibrillator_Other_paddle,
		// Token: 0x040019BA RID: 6586
		NightVision_GPNVG = 50,
		// Token: 0x040019BB RID: 6587
		NVGFilter_Amber,
		// Token: 0x040019BC RID: 6588
		NVGFilter_Green,
		// Token: 0x040019BD RID: 6589
		NVGFilter_White,
		// Token: 0x040019BE RID: 6590
		NVGFilter_Digital,
		// Token: 0x040019BF RID: 6591
		IRStrobe,
		// Token: 0x040019C0 RID: 6592
		ChemLight = 60
	}

	// Token: 0x02000232 RID: 562
	public enum MagazineEjectionType
	{
		// Token: 0x040019C2 RID: 6594
		None,
		// Token: 0x040019C3 RID: 6595
		DropFree,
		// Token: 0x040019C4 RID: 6596
		ManualRelease
	}

	// Token: 0x02000233 RID: 563
	[Serializable]
	public class EquipmentObject : Il2CppSystem.Object
	{
		// Token: 0x06002834 RID: 10292 RVA: 0x0009F59C File Offset: 0x0009D79C
		[CallerCount(0)]
		public unsafe EquipmentObject() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.EquipmentObject.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06002835 RID: 10293 RVA: 0x0009F5E8 File Offset: 0x0009D7E8
		// Note: this type is marked as 'beforefieldinit'.
		static EquipmentObject()
		{
			Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "EquipmentObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr);
			ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr, "Name");
			ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr, "Type");
			ClassLoadout.EquipmentObject.NativeFieldInfoPtr_PointValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr, "PointValue");
			ClassLoadout.EquipmentObject.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr, 100666405);
		}

		// Token: 0x06002836 RID: 10294 RVA: 0x00002988 File Offset: 0x00000B88
		public EquipmentObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000E32 RID: 3634
		// (get) Token: 0x06002837 RID: 10295 RVA: 0x0009F663 File Offset: 0x0009D863
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout.EquipmentObject>.NativeClassPtr));
			}
		}

		// Token: 0x17000E33 RID: 3635
		// (get) Token: 0x06002838 RID: 10296 RVA: 0x0009F674 File Offset: 0x0009D874
		// (set) Token: 0x06002839 RID: 10297 RVA: 0x0009F69D File Offset: 0x0009D89D
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000E34 RID: 3636
		// (get) Token: 0x0600283A RID: 10298 RVA: 0x0009F6C4 File Offset: 0x0009D8C4
		// (set) Token: 0x0600283B RID: 10299 RVA: 0x0009F6EC File Offset: 0x0009D8EC
		public unsafe ClassLoadout.EquipmentType Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x17000E35 RID: 3637
		// (get) Token: 0x0600283C RID: 10300 RVA: 0x0009F710 File Offset: 0x0009D910
		// (set) Token: 0x0600283D RID: 10301 RVA: 0x0009F738 File Offset: 0x0009D938
		public unsafe int PointValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_PointValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.EquipmentObject.NativeFieldInfoPtr_PointValue)) = value;
			}
		}

		// Token: 0x040019C5 RID: 6597
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x040019C6 RID: 6598
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x040019C7 RID: 6599
		private static readonly IntPtr NativeFieldInfoPtr_PointValue;

		// Token: 0x040019C8 RID: 6600
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000234 RID: 564
	[Serializable]
	public class AmmoObject : Il2CppSystem.Object
	{
		// Token: 0x0600283E RID: 10302 RVA: 0x0009F75C File Offset: 0x0009D95C
		[CallerCount(0)]
		public unsafe AmmoObject(ClassLoadout.AmmoType Type, int PointValue) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref Type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref PointValue;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ClassLoadout.AmmoObject.NativeMethodInfoPtr__ctor_Public_Void_AmmoType_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600283F RID: 10303 RVA: 0x0009F7CC File Offset: 0x0009D9CC
		// Note: this type is marked as 'beforefieldinit'.
		static AmmoObject()
		{
			Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ClassLoadout>.NativeClassPtr, "AmmoObject");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr);
			ClassLoadout.AmmoObject.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr, "Name");
			ClassLoadout.AmmoObject.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr, "Type");
			ClassLoadout.AmmoObject.NativeFieldInfoPtr_PointValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr, "PointValue");
			ClassLoadout.AmmoObject.NativeMethodInfoPtr__ctor_Public_Void_AmmoType_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr, 100666406);
		}

		// Token: 0x06002840 RID: 10304 RVA: 0x00002988 File Offset: 0x00000B88
		public AmmoObject(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000E36 RID: 3638
		// (get) Token: 0x06002841 RID: 10305 RVA: 0x0009F847 File Offset: 0x0009DA47
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClassLoadout.AmmoObject>.NativeClassPtr));
			}
		}

		// Token: 0x17000E37 RID: 3639
		// (get) Token: 0x06002842 RID: 10306 RVA: 0x0009F858 File Offset: 0x0009DA58
		// (set) Token: 0x06002843 RID: 10307 RVA: 0x0009F881 File Offset: 0x0009DA81
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000E38 RID: 3640
		// (get) Token: 0x06002844 RID: 10308 RVA: 0x0009F8A8 File Offset: 0x0009DAA8
		// (set) Token: 0x06002845 RID: 10309 RVA: 0x0009F8D0 File Offset: 0x0009DAD0
		public unsafe ClassLoadout.AmmoType Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x17000E39 RID: 3641
		// (get) Token: 0x06002846 RID: 10310 RVA: 0x0009F8F4 File Offset: 0x0009DAF4
		// (set) Token: 0x06002847 RID: 10311 RVA: 0x0009F91C File Offset: 0x0009DB1C
		public unsafe int PointValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_PointValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ClassLoadout.AmmoObject.NativeFieldInfoPtr_PointValue)) = value;
			}
		}

		// Token: 0x040019C9 RID: 6601
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x040019CA RID: 6602
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x040019CB RID: 6603
		private static readonly IntPtr NativeFieldInfoPtr_PointValue;

		// Token: 0x040019CC RID: 6604
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_AmmoType_Int32_0;
	}
}
