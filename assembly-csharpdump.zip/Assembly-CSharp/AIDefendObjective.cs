﻿using System;
using DG.Tweening;
using DPI.Networking;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using Onward.AI.Objectives;
using Onward.GameVariants;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000333 RID: 819
public class AIDefendObjective : MonoBehaviour
{
	// Token: 0x0600407B RID: 16507 RVA: 0x001047AC File Offset: 0x001029AC
	[CallerCount(0)]
	public unsafe void SetUp(ObjectiveData objData)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(objData);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_SetUp_Public_Void_ObjectiveData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600407C RID: 16508 RVA: 0x00104808 File Offset: 0x00102A08
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600407D RID: 16509 RVA: 0x0010484C File Offset: 0x00102A4C
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600407E RID: 16510 RVA: 0x00104890 File Offset: 0x00102A90
	[CallerCount(0)]
	public unsafe void Tick()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_Tick_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600407F RID: 16511 RVA: 0x001048D4 File Offset: 0x00102AD4
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterLandInY()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterLandInY_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004080 RID: 16512 RVA: 0x0010492C File Offset: 0x00102B2C
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterFlyIn()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyIn_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004081 RID: 16513 RVA: 0x00104984 File Offset: 0x00102B84
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterDecelerate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterDecelerate_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004082 RID: 16514 RVA: 0x001049DC File Offset: 0x00102BDC
	[CallerCount(0)]
	public unsafe void heliArrive()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_heliArrive_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004083 RID: 16515 RVA: 0x00104A20 File Offset: 0x00102C20
	[CallerCount(0)]
	public unsafe void landingCallback()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_landingCallback_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004084 RID: 16516 RVA: 0x00104A64 File Offset: 0x00102C64
	[CallerCount(0)]
	public unsafe void teleportHeli()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_teleportHeli_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004085 RID: 16517 RVA: 0x00104AA8 File Offset: 0x00102CA8
	[CallerCount(0)]
	public unsafe void openDoor()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_openDoor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004086 RID: 16518 RVA: 0x00104AEC File Offset: 0x00102CEC
	[CallerCount(0)]
	public unsafe void heliLanded()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_heliLanded_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004087 RID: 16519 RVA: 0x00104B30 File Offset: 0x00102D30
	[CallerCount(0)]
	public unsafe void closeDoor(float duration)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref duration;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_closeDoor_Private_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004088 RID: 16520 RVA: 0x00104B84 File Offset: 0x00102D84
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterAccelerate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterAccelerate_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004089 RID: 16521 RVA: 0x00104BDC File Offset: 0x00102DDC
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterFlyOut()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyOut_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x0600408A RID: 16522 RVA: 0x00104C34 File Offset: 0x00102E34
	[CallerCount(0)]
	public unsafe IEnumerator HelicopterFlyOutMoveXZ()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyOutMoveXZ_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x0600408B RID: 16523 RVA: 0x00104C8C File Offset: 0x00102E8C
	[CallerCount(0)]
	public unsafe void LeaveNowClientSide()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_LeaveNowClientSide_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600408C RID: 16524 RVA: 0x00104CD0 File Offset: 0x00102ED0
	[CallerCount(0)]
	public unsafe void LeaveNowServerSide()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_LeaveNowServerSide_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600408D RID: 16525 RVA: 0x00104D14 File Offset: 0x00102F14
	[CallerCount(0)]
	public unsafe void OnEventMessageHelicopterLeave(HelicopterLeaveEvent messageType, DPINetworkMessageInfo messageInfo)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref messageType;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_OnEventMessageHelicopterLeave_Private_Void_HelicopterLeaveEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600408E RID: 16526 RVA: 0x00104D88 File Offset: 0x00102F88
	[CallerCount(0)]
	public unsafe void Leave(double timestampLeaveStarted)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref timestampLeaveStarted;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_Leave_Private_Void_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600408F RID: 16527 RVA: 0x00104DDC File Offset: 0x00102FDC
	[CallerCount(0)]
	public unsafe IEnumerator heliLeave(double timestampLeaveStarted)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref timestampLeaveStarted;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_heliLeave_Private_IEnumerator_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004090 RID: 16528 RVA: 0x00104E44 File Offset: 0x00103044
	[CallerCount(0)]
	public unsafe void landHeli()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_landHeli_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004091 RID: 16529 RVA: 0x00104E88 File Offset: 0x00103088
	[CallerCount(0)]
	public unsafe void dropSmoke()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_dropSmoke_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004092 RID: 16530 RVA: 0x00104ECC File Offset: 0x001030CC
	[CallerCount(0)]
	public unsafe void Reset(bool hide)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref hide;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr_Reset_Public_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004093 RID: 16531 RVA: 0x00104F20 File Offset: 0x00103120
	[CallerCount(0)]
	public unsafe AIDefendObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004094 RID: 16532 RVA: 0x00104F6C File Offset: 0x0010316C
	// Note: this type is marked as 'beforefieldinit'.
	static AIDefendObjective()
	{
		Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "AIDefendObjective");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr);
		AIDefendObjective.NativeFieldInfoPtr_OnVictoryTriggered = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "OnVictoryTriggered");
		AIDefendObjective.NativeFieldInfoPtr_NetworkedMovement = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "NetworkedMovement");
		AIDefendObjective.NativeFieldInfoPtr_type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "type");
		AIDefendObjective.NativeFieldInfoPtr_IsFlyingIn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "IsFlyingIn");
		AIDefendObjective.NativeFieldInfoPtr_IsLeaving = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "IsLeaving");
		AIDefendObjective.NativeFieldInfoPtr_heli = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heli");
		AIDefendObjective.NativeFieldInfoPtr_originTransform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "originTransform");
		AIDefendObjective.NativeFieldInfoPtr_destinationTransform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "destinationTransform");
		AIDefendObjective.NativeFieldInfoPtr_hoverPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "hoverPosition");
		AIDefendObjective.NativeFieldInfoPtr_hoverRotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "hoverRotation");
		AIDefendObjective.NativeFieldInfoPtr_landingPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "landingPosition");
		AIDefendObjective.NativeFieldInfoPtr_landingRotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "landingRotation");
		AIDefendObjective.NativeFieldInfoPtr_doorOpenAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "doorOpenAmount");
		AIDefendObjective.NativeFieldInfoPtr_tallSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "tallSmoke");
		AIDefendObjective.NativeFieldInfoPtr_flareStuff = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "flareStuff");
		AIDefendObjective.NativeFieldInfoPtr_disableWhenInside = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "disableWhenInside");
		AIDefendObjective.NativeFieldInfoPtr_Evac_Air_Flare = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "Evac_Air_Flare");
		AIDefendObjective.NativeFieldInfoPtr_flare1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "flare1");
		AIDefendObjective.NativeFieldInfoPtr_flare2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "flare2");
		AIDefendObjective.NativeFieldInfoPtr_smokeGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "smokeGrenade");
		AIDefendObjective.NativeFieldInfoPtr_smokeGrenadeParent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "smokeGrenadeParent");
		AIDefendObjective.NativeFieldInfoPtr_icon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "icon");
		AIDefendObjective.NativeFieldInfoPtr_heliAccelerating = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heliAccelerating");
		AIDefendObjective.NativeFieldInfoPtr_heliDecelerating = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heliDecelerating");
		AIDefendObjective.NativeFieldInfoPtr_flyIn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "flyIn");
		AIDefendObjective.NativeFieldInfoPtr_decelerate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "decelerate");
		AIDefendObjective.NativeFieldInfoPtr_accelerate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "accelerate");
		AIDefendObjective.NativeFieldInfoPtr_flyOut = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "flyOut");
		AIDefendObjective.NativeFieldInfoPtr_landingLight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "landingLight");
		AIDefendObjective.NativeFieldInfoPtr_landingDoor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "landingDoor");
		AIDefendObjective.NativeFieldInfoPtr_doorCollider = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "doorCollider");
		AIDefendObjective.NativeFieldInfoPtr_squashBoundaries = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "squashBoundaries");
		AIDefendObjective.NativeFieldInfoPtr_victoryTrigger = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "victoryTrigger");
		AIDefendObjective.NativeFieldInfoPtr_heliTrigger = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heliTrigger");
		AIDefendObjective.NativeFieldInfoPtr_groundTrigger = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "groundTrigger");
		AIDefendObjective.NativeFieldInfoPtr_heliArrivalSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heliArrivalSpeed");
		AIDefendObjective.NativeFieldInfoPtr_heliArrived = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "heliArrived");
		AIDefendObjective.NativeFieldInfoPtr_thisCollider = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "thisCollider");
		AIDefendObjective.NativeFieldInfoPtr_Debug_Lines = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "Debug_Lines");
		AIDefendObjective.NativeFieldInfoPtr_DEBUG_lastFramePosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "DEBUG_lastFramePosition");
		AIDefendObjective.NativeFieldInfoPtr_DEBUG_thisFramePosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "DEBUG_thisFramePosition");
		AIDefendObjective.NativeFieldInfoPtr_dropSmokeIgnoreTag = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "dropSmokeIgnoreTag");
		AIDefendObjective.NativeFieldInfoPtr_dropSmokeRaycastLength = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "dropSmokeRaycastLength");
		AIDefendObjective.NativeFieldInfoPtr_SmokeOriginalPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "SmokeOriginalPosition");
		AIDefendObjective.NativeFieldInfoPtr_GrenadeOriginalPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "GrenadeOriginalPosition");
		AIDefendObjective.NativeFieldInfoPtr_aiObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "aiObjective");
		AIDefendObjective.NativeMethodInfoPtr_SetUp_Public_Void_ObjectiveData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668465);
		AIDefendObjective.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668466);
		AIDefendObjective.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668467);
		AIDefendObjective.NativeMethodInfoPtr_Tick_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668468);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterLandInY_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668469);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyIn_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668470);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterDecelerate_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668471);
		AIDefendObjective.NativeMethodInfoPtr_heliArrive_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668472);
		AIDefendObjective.NativeMethodInfoPtr_landingCallback_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668473);
		AIDefendObjective.NativeMethodInfoPtr_teleportHeli_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668474);
		AIDefendObjective.NativeMethodInfoPtr_openDoor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668475);
		AIDefendObjective.NativeMethodInfoPtr_heliLanded_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668476);
		AIDefendObjective.NativeMethodInfoPtr_closeDoor_Private_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668477);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterAccelerate_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668478);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyOut_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668479);
		AIDefendObjective.NativeMethodInfoPtr_HelicopterFlyOutMoveXZ_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668480);
		AIDefendObjective.NativeMethodInfoPtr_LeaveNowClientSide_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668481);
		AIDefendObjective.NativeMethodInfoPtr_LeaveNowServerSide_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668482);
		AIDefendObjective.NativeMethodInfoPtr_OnEventMessageHelicopterLeave_Private_Void_HelicopterLeaveEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668483);
		AIDefendObjective.NativeMethodInfoPtr_Leave_Private_Void_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668484);
		AIDefendObjective.NativeMethodInfoPtr_heliLeave_Private_IEnumerator_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668485);
		AIDefendObjective.NativeMethodInfoPtr_landHeli_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668486);
		AIDefendObjective.NativeMethodInfoPtr_dropSmoke_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668487);
		AIDefendObjective.NativeMethodInfoPtr_Reset_Public_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668488);
		AIDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, 100668489);
	}

	// Token: 0x06004095 RID: 16533 RVA: 0x0000210C File Offset: 0x0000030C
	public AIDefendObjective(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170016CA RID: 5834
	// (get) Token: 0x06004096 RID: 16534 RVA: 0x00105528 File Offset: 0x00103728
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr));
		}
	}

	// Token: 0x170016CB RID: 5835
	// (get) Token: 0x06004097 RID: 16535 RVA: 0x0010553C File Offset: 0x0010373C
	// (set) Token: 0x06004098 RID: 16536 RVA: 0x00105570 File Offset: 0x00103770
	public unsafe Action<EvacVictoryTrigger> OnVictoryTriggered
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_OnVictoryTriggered);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Action<EvacVictoryTrigger>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_OnVictoryTriggered), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016CC RID: 5836
	// (get) Token: 0x06004099 RID: 16537 RVA: 0x00105598 File Offset: 0x00103798
	// (set) Token: 0x0600409A RID: 16538 RVA: 0x001055C0 File Offset: 0x001037C0
	public unsafe bool NetworkedMovement
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_NetworkedMovement);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_NetworkedMovement)) = value;
		}
	}

	// Token: 0x170016CD RID: 5837
	// (get) Token: 0x0600409B RID: 16539 RVA: 0x001055E4 File Offset: 0x001037E4
	// (set) Token: 0x0600409C RID: 16540 RVA: 0x0010560C File Offset: 0x0010380C
	public unsafe AIDefendObjective.EvacType type
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_type);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_type)) = value;
		}
	}

	// Token: 0x170016CE RID: 5838
	// (get) Token: 0x0600409D RID: 16541 RVA: 0x00105630 File Offset: 0x00103830
	// (set) Token: 0x0600409E RID: 16542 RVA: 0x00105658 File Offset: 0x00103858
	public unsafe bool IsFlyingIn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_IsFlyingIn);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_IsFlyingIn)) = value;
		}
	}

	// Token: 0x170016CF RID: 5839
	// (get) Token: 0x0600409F RID: 16543 RVA: 0x0010567C File Offset: 0x0010387C
	// (set) Token: 0x060040A0 RID: 16544 RVA: 0x001056A4 File Offset: 0x001038A4
	public unsafe bool IsLeaving
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_IsLeaving);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_IsLeaving)) = value;
		}
	}

	// Token: 0x170016D0 RID: 5840
	// (get) Token: 0x060040A1 RID: 16545 RVA: 0x001056C8 File Offset: 0x001038C8
	// (set) Token: 0x060040A2 RID: 16546 RVA: 0x001056FC File Offset: 0x001038FC
	public unsafe Transform heli
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heli);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heli), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016D1 RID: 5841
	// (get) Token: 0x060040A3 RID: 16547 RVA: 0x00105724 File Offset: 0x00103924
	// (set) Token: 0x060040A4 RID: 16548 RVA: 0x00105758 File Offset: 0x00103958
	public unsafe Transform originTransform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_originTransform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_originTransform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016D2 RID: 5842
	// (get) Token: 0x060040A5 RID: 16549 RVA: 0x00105780 File Offset: 0x00103980
	// (set) Token: 0x060040A6 RID: 16550 RVA: 0x001057B4 File Offset: 0x001039B4
	public unsafe Transform destinationTransform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_destinationTransform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_destinationTransform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016D3 RID: 5843
	// (get) Token: 0x060040A7 RID: 16551 RVA: 0x001057DC File Offset: 0x001039DC
	// (set) Token: 0x060040A8 RID: 16552 RVA: 0x00105804 File Offset: 0x00103A04
	public unsafe Vector3 hoverPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_hoverPosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_hoverPosition)) = value;
		}
	}

	// Token: 0x170016D4 RID: 5844
	// (get) Token: 0x060040A9 RID: 16553 RVA: 0x00105828 File Offset: 0x00103A28
	// (set) Token: 0x060040AA RID: 16554 RVA: 0x00105850 File Offset: 0x00103A50
	public unsafe Vector3 hoverRotation
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_hoverRotation);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_hoverRotation)) = value;
		}
	}

	// Token: 0x170016D5 RID: 5845
	// (get) Token: 0x060040AB RID: 16555 RVA: 0x00105874 File Offset: 0x00103A74
	// (set) Token: 0x060040AC RID: 16556 RVA: 0x0010589C File Offset: 0x00103A9C
	public unsafe Vector3 landingPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingPosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingPosition)) = value;
		}
	}

	// Token: 0x170016D6 RID: 5846
	// (get) Token: 0x060040AD RID: 16557 RVA: 0x001058C0 File Offset: 0x00103AC0
	// (set) Token: 0x060040AE RID: 16558 RVA: 0x001058E8 File Offset: 0x00103AE8
	public unsafe Vector3 landingRotation
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingRotation);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingRotation)) = value;
		}
	}

	// Token: 0x170016D7 RID: 5847
	// (get) Token: 0x060040AF RID: 16559 RVA: 0x0010590C File Offset: 0x00103B0C
	// (set) Token: 0x060040B0 RID: 16560 RVA: 0x00105934 File Offset: 0x00103B34
	public unsafe Quaternion doorOpenAmount
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_doorOpenAmount);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_doorOpenAmount)) = value;
		}
	}

	// Token: 0x170016D8 RID: 5848
	// (get) Token: 0x060040B1 RID: 16561 RVA: 0x00105958 File Offset: 0x00103B58
	// (set) Token: 0x060040B2 RID: 16562 RVA: 0x0010598C File Offset: 0x00103B8C
	public unsafe ParticleDistanceHider tallSmoke
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_tallSmoke);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new ParticleDistanceHider(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_tallSmoke), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016D9 RID: 5849
	// (get) Token: 0x060040B3 RID: 16563 RVA: 0x001059B4 File Offset: 0x00103BB4
	// (set) Token: 0x060040B4 RID: 16564 RVA: 0x001059E8 File Offset: 0x00103BE8
	public unsafe Il2CppReferenceArray<GameObject> flareStuff
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flareStuff);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flareStuff), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DA RID: 5850
	// (get) Token: 0x060040B5 RID: 16565 RVA: 0x00105A10 File Offset: 0x00103C10
	// (set) Token: 0x060040B6 RID: 16566 RVA: 0x00105A44 File Offset: 0x00103C44
	public unsafe Il2CppReferenceArray<GameObject> disableWhenInside
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_disableWhenInside);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_disableWhenInside), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DB RID: 5851
	// (get) Token: 0x060040B7 RID: 16567 RVA: 0x00105A6C File Offset: 0x00103C6C
	// (set) Token: 0x060040B8 RID: 16568 RVA: 0x00105AA0 File Offset: 0x00103CA0
	public unsafe GameObject Evac_Air_Flare
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_Evac_Air_Flare);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_Evac_Air_Flare), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DC RID: 5852
	// (get) Token: 0x060040B9 RID: 16569 RVA: 0x00105AC8 File Offset: 0x00103CC8
	// (set) Token: 0x060040BA RID: 16570 RVA: 0x00105AFC File Offset: 0x00103CFC
	public unsafe MeshRenderer flare1
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flare1);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flare1), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DD RID: 5853
	// (get) Token: 0x060040BB RID: 16571 RVA: 0x00105B24 File Offset: 0x00103D24
	// (set) Token: 0x060040BC RID: 16572 RVA: 0x00105B58 File Offset: 0x00103D58
	public unsafe MeshRenderer flare2
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flare2);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flare2), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DE RID: 5854
	// (get) Token: 0x060040BD RID: 16573 RVA: 0x00105B80 File Offset: 0x00103D80
	// (set) Token: 0x060040BE RID: 16574 RVA: 0x00105BB4 File Offset: 0x00103DB4
	public unsafe MeshRenderer smokeGrenade
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_smokeGrenade);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_smokeGrenade), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016DF RID: 5855
	// (get) Token: 0x060040BF RID: 16575 RVA: 0x00105BDC File Offset: 0x00103DDC
	// (set) Token: 0x060040C0 RID: 16576 RVA: 0x00105C10 File Offset: 0x00103E10
	public unsafe Transform smokeGrenadeParent
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_smokeGrenadeParent);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_smokeGrenadeParent), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E0 RID: 5856
	// (get) Token: 0x060040C1 RID: 16577 RVA: 0x00105C38 File Offset: 0x00103E38
	// (set) Token: 0x060040C2 RID: 16578 RVA: 0x00105C6C File Offset: 0x00103E6C
	public unsafe bl_MiniMapItem icon
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_icon);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new bl_MiniMapItem(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_icon), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E1 RID: 5857
	// (get) Token: 0x060040C3 RID: 16579 RVA: 0x00105C94 File Offset: 0x00103E94
	// (set) Token: 0x060040C4 RID: 16580 RVA: 0x00105CBC File Offset: 0x00103EBC
	public unsafe Vector3 heliAccelerating
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliAccelerating);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliAccelerating)) = value;
		}
	}

	// Token: 0x170016E2 RID: 5858
	// (get) Token: 0x060040C5 RID: 16581 RVA: 0x00105CE0 File Offset: 0x00103EE0
	// (set) Token: 0x060040C6 RID: 16582 RVA: 0x00105D08 File Offset: 0x00103F08
	public unsafe Vector3 heliDecelerating
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliDecelerating);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliDecelerating)) = value;
		}
	}

	// Token: 0x170016E3 RID: 5859
	// (get) Token: 0x060040C7 RID: 16583 RVA: 0x00105D2C File Offset: 0x00103F2C
	// (set) Token: 0x060040C8 RID: 16584 RVA: 0x00105D60 File Offset: 0x00103F60
	public unsafe Sequence flyIn
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flyIn);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Sequence(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flyIn), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E4 RID: 5860
	// (get) Token: 0x060040C9 RID: 16585 RVA: 0x00105D88 File Offset: 0x00103F88
	// (set) Token: 0x060040CA RID: 16586 RVA: 0x00105DBC File Offset: 0x00103FBC
	public unsafe Sequence decelerate
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_decelerate);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Sequence(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_decelerate), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E5 RID: 5861
	// (get) Token: 0x060040CB RID: 16587 RVA: 0x00105DE4 File Offset: 0x00103FE4
	// (set) Token: 0x060040CC RID: 16588 RVA: 0x00105E18 File Offset: 0x00104018
	public unsafe Sequence accelerate
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_accelerate);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Sequence(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_accelerate), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E6 RID: 5862
	// (get) Token: 0x060040CD RID: 16589 RVA: 0x00105E40 File Offset: 0x00104040
	// (set) Token: 0x060040CE RID: 16590 RVA: 0x00105E74 File Offset: 0x00104074
	public unsafe Sequence flyOut
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flyOut);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Sequence(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_flyOut), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E7 RID: 5863
	// (get) Token: 0x060040CF RID: 16591 RVA: 0x00105E9C File Offset: 0x0010409C
	// (set) Token: 0x060040D0 RID: 16592 RVA: 0x00105ED0 File Offset: 0x001040D0
	public unsafe FlashingLight landingLight
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingLight);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new FlashingLight(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingLight), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E8 RID: 5864
	// (get) Token: 0x060040D1 RID: 16593 RVA: 0x00105EF8 File Offset: 0x001040F8
	// (set) Token: 0x060040D2 RID: 16594 RVA: 0x00105F2C File Offset: 0x0010412C
	public unsafe Transform landingDoor
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingDoor);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_landingDoor), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016E9 RID: 5865
	// (get) Token: 0x060040D3 RID: 16595 RVA: 0x00105F54 File Offset: 0x00104154
	// (set) Token: 0x060040D4 RID: 16596 RVA: 0x00105F88 File Offset: 0x00104188
	public unsafe GameObject doorCollider
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_doorCollider);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_doorCollider), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016EA RID: 5866
	// (get) Token: 0x060040D5 RID: 16597 RVA: 0x00105FB0 File Offset: 0x001041B0
	// (set) Token: 0x060040D6 RID: 16598 RVA: 0x00105FE4 File Offset: 0x001041E4
	public unsafe Il2CppReferenceArray<GameObject> squashBoundaries
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_squashBoundaries);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_squashBoundaries), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016EB RID: 5867
	// (get) Token: 0x060040D7 RID: 16599 RVA: 0x0010600C File Offset: 0x0010420C
	// (set) Token: 0x060040D8 RID: 16600 RVA: 0x00106040 File Offset: 0x00104240
	public unsafe EvacVictoryTrigger victoryTrigger
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_victoryTrigger);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EvacVictoryTrigger(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_victoryTrigger), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016EC RID: 5868
	// (get) Token: 0x060040D9 RID: 16601 RVA: 0x00106068 File Offset: 0x00104268
	// (set) Token: 0x060040DA RID: 16602 RVA: 0x0010609C File Offset: 0x0010429C
	public unsafe EvacVictoryTrigger heliTrigger
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliTrigger);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EvacVictoryTrigger(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliTrigger), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016ED RID: 5869
	// (get) Token: 0x060040DB RID: 16603 RVA: 0x001060C4 File Offset: 0x001042C4
	// (set) Token: 0x060040DC RID: 16604 RVA: 0x001060F8 File Offset: 0x001042F8
	public unsafe EvacVictoryTrigger groundTrigger
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_groundTrigger);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EvacVictoryTrigger(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_groundTrigger), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016EE RID: 5870
	// (get) Token: 0x060040DD RID: 16605 RVA: 0x00106120 File Offset: 0x00104320
	// (set) Token: 0x060040DE RID: 16606 RVA: 0x00106148 File Offset: 0x00104348
	public unsafe float heliArrivalSpeed
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliArrivalSpeed);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliArrivalSpeed)) = value;
		}
	}

	// Token: 0x170016EF RID: 5871
	// (get) Token: 0x060040DF RID: 16607 RVA: 0x0010616C File Offset: 0x0010436C
	// (set) Token: 0x060040E0 RID: 16608 RVA: 0x00106194 File Offset: 0x00104394
	public unsafe bool heliArrived
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliArrived);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_heliArrived)) = value;
		}
	}

	// Token: 0x170016F0 RID: 5872
	// (get) Token: 0x060040E1 RID: 16609 RVA: 0x001061B8 File Offset: 0x001043B8
	// (set) Token: 0x060040E2 RID: 16610 RVA: 0x001061EC File Offset: 0x001043EC
	public unsafe Collider thisCollider
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_thisCollider);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Collider(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_thisCollider), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016F1 RID: 5873
	// (get) Token: 0x060040E3 RID: 16611 RVA: 0x00106214 File Offset: 0x00104414
	// (set) Token: 0x060040E4 RID: 16612 RVA: 0x00106248 File Offset: 0x00104448
	public unsafe List<AIDefendObjective.GizmoLineDraw> Debug_Lines
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_Debug_Lines);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<AIDefendObjective.GizmoLineDraw>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_Debug_Lines), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016F2 RID: 5874
	// (get) Token: 0x060040E5 RID: 16613 RVA: 0x00106270 File Offset: 0x00104470
	// (set) Token: 0x060040E6 RID: 16614 RVA: 0x00106298 File Offset: 0x00104498
	public unsafe Vector3 DEBUG_lastFramePosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_DEBUG_lastFramePosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_DEBUG_lastFramePosition)) = value;
		}
	}

	// Token: 0x170016F3 RID: 5875
	// (get) Token: 0x060040E7 RID: 16615 RVA: 0x001062BC File Offset: 0x001044BC
	// (set) Token: 0x060040E8 RID: 16616 RVA: 0x001062E4 File Offset: 0x001044E4
	public unsafe Vector3 DEBUG_thisFramePosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_DEBUG_thisFramePosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_DEBUG_thisFramePosition)) = value;
		}
	}

	// Token: 0x170016F4 RID: 5876
	// (get) Token: 0x060040E9 RID: 16617 RVA: 0x00106308 File Offset: 0x00104508
	// (set) Token: 0x060040EA RID: 16618 RVA: 0x00106328 File Offset: 0x00104528
	public unsafe static string dropSmokeIgnoreTag
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(AIDefendObjective.NativeFieldInfoPtr_dropSmokeIgnoreTag, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(AIDefendObjective.NativeFieldInfoPtr_dropSmokeIgnoreTag, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x170016F5 RID: 5877
	// (get) Token: 0x060040EB RID: 16619 RVA: 0x00106340 File Offset: 0x00104540
	// (set) Token: 0x060040EC RID: 16620 RVA: 0x0010635E File Offset: 0x0010455E
	public unsafe static float dropSmokeRaycastLength
	{
		get
		{
			float result;
			IL2CPP.il2cpp_field_static_get_value(AIDefendObjective.NativeFieldInfoPtr_dropSmokeRaycastLength, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(AIDefendObjective.NativeFieldInfoPtr_dropSmokeRaycastLength, (void*)(&value));
		}
	}

	// Token: 0x170016F6 RID: 5878
	// (get) Token: 0x060040ED RID: 16621 RVA: 0x00106370 File Offset: 0x00104570
	// (set) Token: 0x060040EE RID: 16622 RVA: 0x00106398 File Offset: 0x00104598
	public unsafe Vector3 SmokeOriginalPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_SmokeOriginalPosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_SmokeOriginalPosition)) = value;
		}
	}

	// Token: 0x170016F7 RID: 5879
	// (get) Token: 0x060040EF RID: 16623 RVA: 0x001063BC File Offset: 0x001045BC
	// (set) Token: 0x060040F0 RID: 16624 RVA: 0x001063E4 File Offset: 0x001045E4
	public unsafe Vector3 GrenadeOriginalPosition
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_GrenadeOriginalPosition);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_GrenadeOriginalPosition)) = value;
		}
	}

	// Token: 0x170016F8 RID: 5880
	// (get) Token: 0x060040F1 RID: 16625 RVA: 0x00106408 File Offset: 0x00104608
	// (set) Token: 0x060040F2 RID: 16626 RVA: 0x0010643C File Offset: 0x0010463C
	public unsafe EvacHeloObjective aiObjective
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_aiObjective);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EvacHeloObjective(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.NativeFieldInfoPtr_aiObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002977 RID: 10615
	private static readonly IntPtr NativeFieldInfoPtr_OnVictoryTriggered;

	// Token: 0x04002978 RID: 10616
	private static readonly IntPtr NativeFieldInfoPtr_NetworkedMovement;

	// Token: 0x04002979 RID: 10617
	private static readonly IntPtr NativeFieldInfoPtr_type;

	// Token: 0x0400297A RID: 10618
	private static readonly IntPtr NativeFieldInfoPtr_IsFlyingIn;

	// Token: 0x0400297B RID: 10619
	private static readonly IntPtr NativeFieldInfoPtr_IsLeaving;

	// Token: 0x0400297C RID: 10620
	private static readonly IntPtr NativeFieldInfoPtr_heli;

	// Token: 0x0400297D RID: 10621
	private static readonly IntPtr NativeFieldInfoPtr_originTransform;

	// Token: 0x0400297E RID: 10622
	private static readonly IntPtr NativeFieldInfoPtr_destinationTransform;

	// Token: 0x0400297F RID: 10623
	private static readonly IntPtr NativeFieldInfoPtr_hoverPosition;

	// Token: 0x04002980 RID: 10624
	private static readonly IntPtr NativeFieldInfoPtr_hoverRotation;

	// Token: 0x04002981 RID: 10625
	private static readonly IntPtr NativeFieldInfoPtr_landingPosition;

	// Token: 0x04002982 RID: 10626
	private static readonly IntPtr NativeFieldInfoPtr_landingRotation;

	// Token: 0x04002983 RID: 10627
	private static readonly IntPtr NativeFieldInfoPtr_doorOpenAmount;

	// Token: 0x04002984 RID: 10628
	private static readonly IntPtr NativeFieldInfoPtr_tallSmoke;

	// Token: 0x04002985 RID: 10629
	private static readonly IntPtr NativeFieldInfoPtr_flareStuff;

	// Token: 0x04002986 RID: 10630
	private static readonly IntPtr NativeFieldInfoPtr_disableWhenInside;

	// Token: 0x04002987 RID: 10631
	private static readonly IntPtr NativeFieldInfoPtr_Evac_Air_Flare;

	// Token: 0x04002988 RID: 10632
	private static readonly IntPtr NativeFieldInfoPtr_flare1;

	// Token: 0x04002989 RID: 10633
	private static readonly IntPtr NativeFieldInfoPtr_flare2;

	// Token: 0x0400298A RID: 10634
	private static readonly IntPtr NativeFieldInfoPtr_smokeGrenade;

	// Token: 0x0400298B RID: 10635
	private static readonly IntPtr NativeFieldInfoPtr_smokeGrenadeParent;

	// Token: 0x0400298C RID: 10636
	private static readonly IntPtr NativeFieldInfoPtr_icon;

	// Token: 0x0400298D RID: 10637
	private static readonly IntPtr NativeFieldInfoPtr_heliAccelerating;

	// Token: 0x0400298E RID: 10638
	private static readonly IntPtr NativeFieldInfoPtr_heliDecelerating;

	// Token: 0x0400298F RID: 10639
	private static readonly IntPtr NativeFieldInfoPtr_flyIn;

	// Token: 0x04002990 RID: 10640
	private static readonly IntPtr NativeFieldInfoPtr_decelerate;

	// Token: 0x04002991 RID: 10641
	private static readonly IntPtr NativeFieldInfoPtr_accelerate;

	// Token: 0x04002992 RID: 10642
	private static readonly IntPtr NativeFieldInfoPtr_flyOut;

	// Token: 0x04002993 RID: 10643
	private static readonly IntPtr NativeFieldInfoPtr_landingLight;

	// Token: 0x04002994 RID: 10644
	private static readonly IntPtr NativeFieldInfoPtr_landingDoor;

	// Token: 0x04002995 RID: 10645
	private static readonly IntPtr NativeFieldInfoPtr_doorCollider;

	// Token: 0x04002996 RID: 10646
	private static readonly IntPtr NativeFieldInfoPtr_squashBoundaries;

	// Token: 0x04002997 RID: 10647
	private static readonly IntPtr NativeFieldInfoPtr_victoryTrigger;

	// Token: 0x04002998 RID: 10648
	private static readonly IntPtr NativeFieldInfoPtr_heliTrigger;

	// Token: 0x04002999 RID: 10649
	private static readonly IntPtr NativeFieldInfoPtr_groundTrigger;

	// Token: 0x0400299A RID: 10650
	private static readonly IntPtr NativeFieldInfoPtr_heliArrivalSpeed;

	// Token: 0x0400299B RID: 10651
	private static readonly IntPtr NativeFieldInfoPtr_heliArrived;

	// Token: 0x0400299C RID: 10652
	private static readonly IntPtr NativeFieldInfoPtr_thisCollider;

	// Token: 0x0400299D RID: 10653
	private static readonly IntPtr NativeFieldInfoPtr_Debug_Lines;

	// Token: 0x0400299E RID: 10654
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_lastFramePosition;

	// Token: 0x0400299F RID: 10655
	private static readonly IntPtr NativeFieldInfoPtr_DEBUG_thisFramePosition;

	// Token: 0x040029A0 RID: 10656
	private static readonly IntPtr NativeFieldInfoPtr_dropSmokeIgnoreTag;

	// Token: 0x040029A1 RID: 10657
	private static readonly IntPtr NativeFieldInfoPtr_dropSmokeRaycastLength;

	// Token: 0x040029A2 RID: 10658
	private static readonly IntPtr NativeFieldInfoPtr_SmokeOriginalPosition;

	// Token: 0x040029A3 RID: 10659
	private static readonly IntPtr NativeFieldInfoPtr_GrenadeOriginalPosition;

	// Token: 0x040029A4 RID: 10660
	private static readonly IntPtr NativeFieldInfoPtr_aiObjective;

	// Token: 0x040029A5 RID: 10661
	private static readonly IntPtr NativeMethodInfoPtr_SetUp_Public_Void_ObjectiveData_0;

	// Token: 0x040029A6 RID: 10662
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x040029A7 RID: 10663
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x040029A8 RID: 10664
	private static readonly IntPtr NativeMethodInfoPtr_Tick_Public_Void_0;

	// Token: 0x040029A9 RID: 10665
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterLandInY_Private_IEnumerator_0;

	// Token: 0x040029AA RID: 10666
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterFlyIn_Private_IEnumerator_0;

	// Token: 0x040029AB RID: 10667
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterDecelerate_Private_IEnumerator_0;

	// Token: 0x040029AC RID: 10668
	private static readonly IntPtr NativeMethodInfoPtr_heliArrive_Public_Void_0;

	// Token: 0x040029AD RID: 10669
	private static readonly IntPtr NativeMethodInfoPtr_landingCallback_Public_Void_0;

	// Token: 0x040029AE RID: 10670
	private static readonly IntPtr NativeMethodInfoPtr_teleportHeli_Public_Void_0;

	// Token: 0x040029AF RID: 10671
	private static readonly IntPtr NativeMethodInfoPtr_openDoor_Public_Void_0;

	// Token: 0x040029B0 RID: 10672
	private static readonly IntPtr NativeMethodInfoPtr_heliLanded_Public_Void_0;

	// Token: 0x040029B1 RID: 10673
	private static readonly IntPtr NativeMethodInfoPtr_closeDoor_Private_Void_Single_0;

	// Token: 0x040029B2 RID: 10674
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterAccelerate_Private_IEnumerator_0;

	// Token: 0x040029B3 RID: 10675
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterFlyOut_Private_IEnumerator_0;

	// Token: 0x040029B4 RID: 10676
	private static readonly IntPtr NativeMethodInfoPtr_HelicopterFlyOutMoveXZ_Private_IEnumerator_0;

	// Token: 0x040029B5 RID: 10677
	private static readonly IntPtr NativeMethodInfoPtr_LeaveNowClientSide_Public_Void_0;

	// Token: 0x040029B6 RID: 10678
	private static readonly IntPtr NativeMethodInfoPtr_LeaveNowServerSide_Public_Void_0;

	// Token: 0x040029B7 RID: 10679
	private static readonly IntPtr NativeMethodInfoPtr_OnEventMessageHelicopterLeave_Private_Void_HelicopterLeaveEvent_DPINetworkMessageInfo_0;

	// Token: 0x040029B8 RID: 10680
	private static readonly IntPtr NativeMethodInfoPtr_Leave_Private_Void_Double_0;

	// Token: 0x040029B9 RID: 10681
	private static readonly IntPtr NativeMethodInfoPtr_heliLeave_Private_IEnumerator_Double_0;

	// Token: 0x040029BA RID: 10682
	private static readonly IntPtr NativeMethodInfoPtr_landHeli_Public_Void_0;

	// Token: 0x040029BB RID: 10683
	private static readonly IntPtr NativeMethodInfoPtr_dropSmoke_Public_Void_0;

	// Token: 0x040029BC RID: 10684
	private static readonly IntPtr NativeMethodInfoPtr_Reset_Public_Void_Boolean_0;

	// Token: 0x040029BD RID: 10685
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000334 RID: 820
	public enum EvacType
	{
		// Token: 0x040029BF RID: 10687
		heliLand,
		// Token: 0x040029C0 RID: 10688
		heliHover
	}

	// Token: 0x02000335 RID: 821
	public class GizmoLineDraw : Il2CppSystem.Object
	{
		// Token: 0x060040F5 RID: 16629 RVA: 0x00106488 File Offset: 0x00104688
		[CallerCount(0)]
		public unsafe GizmoLineDraw() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective.GizmoLineDraw.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060040F6 RID: 16630 RVA: 0x001064D4 File Offset: 0x001046D4
		// Note: this type is marked as 'beforefieldinit'.
		static GizmoLineDraw()
		{
			Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "GizmoLineDraw");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr);
			AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_from = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr, "from");
			AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_to = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr, "to");
			AIDefendObjective.GizmoLineDraw.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr, 100668490);
		}

		// Token: 0x060040F7 RID: 16631 RVA: 0x00002988 File Offset: 0x00000B88
		public GizmoLineDraw(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170016FA RID: 5882
		// (get) Token: 0x060040F8 RID: 16632 RVA: 0x0010653B File Offset: 0x0010473B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective.GizmoLineDraw>.NativeClassPtr));
			}
		}

		// Token: 0x170016FB RID: 5883
		// (get) Token: 0x060040F9 RID: 16633 RVA: 0x0010654C File Offset: 0x0010474C
		// (set) Token: 0x060040FA RID: 16634 RVA: 0x00106574 File Offset: 0x00104774
		public unsafe Vector3 from
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_from);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_from)) = value;
			}
		}

		// Token: 0x170016FC RID: 5884
		// (get) Token: 0x060040FB RID: 16635 RVA: 0x00106598 File Offset: 0x00104798
		// (set) Token: 0x060040FC RID: 16636 RVA: 0x001065C0 File Offset: 0x001047C0
		public unsafe Vector3 to
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_to);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective.GizmoLineDraw.NativeFieldInfoPtr_to)) = value;
			}
		}

		// Token: 0x040029C1 RID: 10689
		private static readonly IntPtr NativeFieldInfoPtr_from;

		// Token: 0x040029C2 RID: 10690
		private static readonly IntPtr NativeFieldInfoPtr_to;

		// Token: 0x040029C3 RID: 10691
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}

	// Token: 0x02000336 RID: 822
	[ObfuscatedName("AIDefendObjective/<HelicopterLandInY>d__52")]
	public sealed class _HelicopterLandInY_d__52 : Il2CppSystem.Object
	{
		// Token: 0x060040FD RID: 16637 RVA: 0x001065E4 File Offset: 0x001047E4
		[CallerCount(0)]
		public unsafe _HelicopterLandInY_d__52(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060040FE RID: 16638 RVA: 0x00106644 File Offset: 0x00104844
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060040FF RID: 16639 RVA: 0x00106688 File Offset: 0x00104888
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001704 RID: 5892
		// (get) Token: 0x06004100 RID: 16640 RVA: 0x001066D8 File Offset: 0x001048D8
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004101 RID: 16641 RVA: 0x00106730 File Offset: 0x00104930
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001705 RID: 5893
		// (get) Token: 0x06004102 RID: 16642 RVA: 0x00106774 File Offset: 0x00104974
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004103 RID: 16643 RVA: 0x001067CC File Offset: 0x001049CC
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterLandInY_d__52()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterLandInY>d__52");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr);
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__heliY_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<heliY>5__2");
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__startTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<startTime>5__3");
			AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__endTime_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, "<endTime>5__4");
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668491);
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668492);
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668493);
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668494);
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668495);
			AIDefendObjective._HelicopterLandInY_d__52.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr, 100668496);
		}

		// Token: 0x06004104 RID: 16644 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterLandInY_d__52(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170016FD RID: 5885
		// (get) Token: 0x06004105 RID: 16645 RVA: 0x001068E7 File Offset: 0x00104AE7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterLandInY_d__52>.NativeClassPtr));
			}
		}

		// Token: 0x170016FE RID: 5886
		// (get) Token: 0x06004106 RID: 16646 RVA: 0x001068F8 File Offset: 0x00104AF8
		// (set) Token: 0x06004107 RID: 16647 RVA: 0x00106920 File Offset: 0x00104B20
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x170016FF RID: 5887
		// (get) Token: 0x06004108 RID: 16648 RVA: 0x00106944 File Offset: 0x00104B44
		// (set) Token: 0x06004109 RID: 16649 RVA: 0x00106978 File Offset: 0x00104B78
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001700 RID: 5888
		// (get) Token: 0x0600410A RID: 16650 RVA: 0x001069A0 File Offset: 0x00104BA0
		// (set) Token: 0x0600410B RID: 16651 RVA: 0x001069D4 File Offset: 0x00104BD4
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001701 RID: 5889
		// (get) Token: 0x0600410C RID: 16652 RVA: 0x001069FC File Offset: 0x00104BFC
		// (set) Token: 0x0600410D RID: 16653 RVA: 0x00106A24 File Offset: 0x00104C24
		public unsafe float _heliY_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__heliY_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__heliY_5__2)) = value;
			}
		}

		// Token: 0x17001702 RID: 5890
		// (get) Token: 0x0600410E RID: 16654 RVA: 0x00106A48 File Offset: 0x00104C48
		// (set) Token: 0x0600410F RID: 16655 RVA: 0x00106A70 File Offset: 0x00104C70
		public unsafe double _startTime_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__startTime_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__startTime_5__3)) = value;
			}
		}

		// Token: 0x17001703 RID: 5891
		// (get) Token: 0x06004110 RID: 16656 RVA: 0x00106A94 File Offset: 0x00104C94
		// (set) Token: 0x06004111 RID: 16657 RVA: 0x00106ABC File Offset: 0x00104CBC
		public unsafe double _endTime_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__endTime_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterLandInY_d__52.NativeFieldInfoPtr__endTime_5__4)) = value;
			}
		}

		// Token: 0x040029C4 RID: 10692
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040029C5 RID: 10693
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040029C6 RID: 10694
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040029C7 RID: 10695
		private static readonly IntPtr NativeFieldInfoPtr__heliY_5__2;

		// Token: 0x040029C8 RID: 10696
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__3;

		// Token: 0x040029C9 RID: 10697
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__4;

		// Token: 0x040029CA RID: 10698
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040029CB RID: 10699
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029CC RID: 10700
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040029CD RID: 10701
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040029CE RID: 10702
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029CF RID: 10703
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x02000337 RID: 823
	[ObfuscatedName("AIDefendObjective/<HelicopterFlyIn>d__53")]
	public sealed class _HelicopterFlyIn_d__53 : Il2CppSystem.Object
	{
		// Token: 0x06004112 RID: 16658 RVA: 0x00106AE0 File Offset: 0x00104CE0
		[CallerCount(0)]
		public unsafe _HelicopterFlyIn_d__53(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004113 RID: 16659 RVA: 0x00106B40 File Offset: 0x00104D40
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004114 RID: 16660 RVA: 0x00106B84 File Offset: 0x00104D84
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x1700170F RID: 5903
		// (get) Token: 0x06004115 RID: 16661 RVA: 0x00106BD4 File Offset: 0x00104DD4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004116 RID: 16662 RVA: 0x00106C2C File Offset: 0x00104E2C
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001710 RID: 5904
		// (get) Token: 0x06004117 RID: 16663 RVA: 0x00106C70 File Offset: 0x00104E70
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004118 RID: 16664 RVA: 0x00106CC8 File Offset: 0x00104EC8
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterFlyIn_d__53()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterFlyIn>d__53");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliPos_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<heliPos>5__2");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__startTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<startTime>5__3");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__endTime_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<endTime>5__4");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliLanding_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<heliLanding>5__5");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliOpenDoor_5__6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, "<heliOpenDoor>5__6");
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668497);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668498);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668499);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668500);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668501);
			AIDefendObjective._HelicopterFlyIn_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr, 100668502);
		}

		// Token: 0x06004119 RID: 16665 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterFlyIn_d__53(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001706 RID: 5894
		// (get) Token: 0x0600411A RID: 16666 RVA: 0x00106E0B File Offset: 0x0010500B
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyIn_d__53>.NativeClassPtr));
			}
		}

		// Token: 0x17001707 RID: 5895
		// (get) Token: 0x0600411B RID: 16667 RVA: 0x00106E1C File Offset: 0x0010501C
		// (set) Token: 0x0600411C RID: 16668 RVA: 0x00106E44 File Offset: 0x00105044
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001708 RID: 5896
		// (get) Token: 0x0600411D RID: 16669 RVA: 0x00106E68 File Offset: 0x00105068
		// (set) Token: 0x0600411E RID: 16670 RVA: 0x00106E9C File Offset: 0x0010509C
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001709 RID: 5897
		// (get) Token: 0x0600411F RID: 16671 RVA: 0x00106EC4 File Offset: 0x001050C4
		// (set) Token: 0x06004120 RID: 16672 RVA: 0x00106EF8 File Offset: 0x001050F8
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700170A RID: 5898
		// (get) Token: 0x06004121 RID: 16673 RVA: 0x00106F20 File Offset: 0x00105120
		// (set) Token: 0x06004122 RID: 16674 RVA: 0x00106F48 File Offset: 0x00105148
		public unsafe Vector3 _heliPos_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliPos_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliPos_5__2)) = value;
			}
		}

		// Token: 0x1700170B RID: 5899
		// (get) Token: 0x06004123 RID: 16675 RVA: 0x00106F6C File Offset: 0x0010516C
		// (set) Token: 0x06004124 RID: 16676 RVA: 0x00106F94 File Offset: 0x00105194
		public unsafe double _startTime_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__startTime_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__startTime_5__3)) = value;
			}
		}

		// Token: 0x1700170C RID: 5900
		// (get) Token: 0x06004125 RID: 16677 RVA: 0x00106FB8 File Offset: 0x001051B8
		// (set) Token: 0x06004126 RID: 16678 RVA: 0x00106FE0 File Offset: 0x001051E0
		public unsafe double _endTime_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__endTime_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__endTime_5__4)) = value;
			}
		}

		// Token: 0x1700170D RID: 5901
		// (get) Token: 0x06004127 RID: 16679 RVA: 0x00107004 File Offset: 0x00105204
		// (set) Token: 0x06004128 RID: 16680 RVA: 0x0010702C File Offset: 0x0010522C
		public unsafe bool _heliLanding_5__5
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliLanding_5__5);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliLanding_5__5)) = value;
			}
		}

		// Token: 0x1700170E RID: 5902
		// (get) Token: 0x06004129 RID: 16681 RVA: 0x00107050 File Offset: 0x00105250
		// (set) Token: 0x0600412A RID: 16682 RVA: 0x00107078 File Offset: 0x00105278
		public unsafe bool _heliOpenDoor_5__6
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliOpenDoor_5__6);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyIn_d__53.NativeFieldInfoPtr__heliOpenDoor_5__6)) = value;
			}
		}

		// Token: 0x040029D0 RID: 10704
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040029D1 RID: 10705
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040029D2 RID: 10706
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040029D3 RID: 10707
		private static readonly IntPtr NativeFieldInfoPtr__heliPos_5__2;

		// Token: 0x040029D4 RID: 10708
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__3;

		// Token: 0x040029D5 RID: 10709
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__4;

		// Token: 0x040029D6 RID: 10710
		private static readonly IntPtr NativeFieldInfoPtr__heliLanding_5__5;

		// Token: 0x040029D7 RID: 10711
		private static readonly IntPtr NativeFieldInfoPtr__heliOpenDoor_5__6;

		// Token: 0x040029D8 RID: 10712
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040029D9 RID: 10713
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029DA RID: 10714
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040029DB RID: 10715
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040029DC RID: 10716
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029DD RID: 10717
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x02000338 RID: 824
	[ObfuscatedName("AIDefendObjective/<HelicopterDecelerate>d__54")]
	public sealed class _HelicopterDecelerate_d__54 : Il2CppSystem.Object
	{
		// Token: 0x0600412B RID: 16683 RVA: 0x0010709C File Offset: 0x0010529C
		[CallerCount(0)]
		public unsafe _HelicopterDecelerate_d__54(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600412C RID: 16684 RVA: 0x001070FC File Offset: 0x001052FC
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600412D RID: 16685 RVA: 0x00107140 File Offset: 0x00105340
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001719 RID: 5913
		// (get) Token: 0x0600412E RID: 16686 RVA: 0x00107190 File Offset: 0x00105390
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600412F RID: 16687 RVA: 0x001071E8 File Offset: 0x001053E8
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700171A RID: 5914
		// (get) Token: 0x06004130 RID: 16688 RVA: 0x0010722C File Offset: 0x0010542C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004131 RID: 16689 RVA: 0x00107284 File Offset: 0x00105484
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterDecelerate_d__54()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterDecelerate>d__54");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__heliRot_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<heliRot>5__2");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__newRot_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<newRot>5__3");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__startTime_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<startTime>5__4");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__endTime_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, "<endTime>5__5");
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668503);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668504);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668505);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668506);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668507);
			AIDefendObjective._HelicopterDecelerate_d__54.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr, 100668508);
		}

		// Token: 0x06004132 RID: 16690 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterDecelerate_d__54(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001711 RID: 5905
		// (get) Token: 0x06004133 RID: 16691 RVA: 0x001073B3 File Offset: 0x001055B3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterDecelerate_d__54>.NativeClassPtr));
			}
		}

		// Token: 0x17001712 RID: 5906
		// (get) Token: 0x06004134 RID: 16692 RVA: 0x001073C4 File Offset: 0x001055C4
		// (set) Token: 0x06004135 RID: 16693 RVA: 0x001073EC File Offset: 0x001055EC
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001713 RID: 5907
		// (get) Token: 0x06004136 RID: 16694 RVA: 0x00107410 File Offset: 0x00105610
		// (set) Token: 0x06004137 RID: 16695 RVA: 0x00107444 File Offset: 0x00105644
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001714 RID: 5908
		// (get) Token: 0x06004138 RID: 16696 RVA: 0x0010746C File Offset: 0x0010566C
		// (set) Token: 0x06004139 RID: 16697 RVA: 0x001074A0 File Offset: 0x001056A0
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001715 RID: 5909
		// (get) Token: 0x0600413A RID: 16698 RVA: 0x001074C8 File Offset: 0x001056C8
		// (set) Token: 0x0600413B RID: 16699 RVA: 0x001074F0 File Offset: 0x001056F0
		public unsafe Vector3 _heliRot_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__heliRot_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__heliRot_5__2)) = value;
			}
		}

		// Token: 0x17001716 RID: 5910
		// (get) Token: 0x0600413C RID: 16700 RVA: 0x00107514 File Offset: 0x00105714
		// (set) Token: 0x0600413D RID: 16701 RVA: 0x0010753C File Offset: 0x0010573C
		public unsafe Vector3 _newRot_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__newRot_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__newRot_5__3)) = value;
			}
		}

		// Token: 0x17001717 RID: 5911
		// (get) Token: 0x0600413E RID: 16702 RVA: 0x00107560 File Offset: 0x00105760
		// (set) Token: 0x0600413F RID: 16703 RVA: 0x00107588 File Offset: 0x00105788
		public unsafe double _startTime_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__startTime_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__startTime_5__4)) = value;
			}
		}

		// Token: 0x17001718 RID: 5912
		// (get) Token: 0x06004140 RID: 16704 RVA: 0x001075AC File Offset: 0x001057AC
		// (set) Token: 0x06004141 RID: 16705 RVA: 0x001075D4 File Offset: 0x001057D4
		public unsafe double _endTime_5__5
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__endTime_5__5);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterDecelerate_d__54.NativeFieldInfoPtr__endTime_5__5)) = value;
			}
		}

		// Token: 0x040029DE RID: 10718
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040029DF RID: 10719
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040029E0 RID: 10720
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040029E1 RID: 10721
		private static readonly IntPtr NativeFieldInfoPtr__heliRot_5__2;

		// Token: 0x040029E2 RID: 10722
		private static readonly IntPtr NativeFieldInfoPtr__newRot_5__3;

		// Token: 0x040029E3 RID: 10723
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__4;

		// Token: 0x040029E4 RID: 10724
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__5;

		// Token: 0x040029E5 RID: 10725
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040029E6 RID: 10726
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029E7 RID: 10727
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040029E8 RID: 10728
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040029E9 RID: 10729
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029EA RID: 10730
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x02000339 RID: 825
	[ObfuscatedName("AIDefendObjective/<HelicopterAccelerate>d__61")]
	public sealed class _HelicopterAccelerate_d__61 : Il2CppSystem.Object
	{
		// Token: 0x06004142 RID: 16706 RVA: 0x001075F8 File Offset: 0x001057F8
		[CallerCount(0)]
		public unsafe _HelicopterAccelerate_d__61(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004143 RID: 16707 RVA: 0x00107658 File Offset: 0x00105858
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004144 RID: 16708 RVA: 0x0010769C File Offset: 0x0010589C
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001723 RID: 5923
		// (get) Token: 0x06004145 RID: 16709 RVA: 0x001076EC File Offset: 0x001058EC
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004146 RID: 16710 RVA: 0x00107744 File Offset: 0x00105944
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001724 RID: 5924
		// (get) Token: 0x06004147 RID: 16711 RVA: 0x00107788 File Offset: 0x00105988
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004148 RID: 16712 RVA: 0x001077E0 File Offset: 0x001059E0
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterAccelerate_d__61()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterAccelerate>d__61");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__startTime_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<startTime>5__2");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__endTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<endTime>5__3");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliRot_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<heliRot>5__4");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliEndRot_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, "<heliEndRot>5__5");
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668509);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668510);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668511);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668512);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668513);
			AIDefendObjective._HelicopterAccelerate_d__61.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr, 100668514);
		}

		// Token: 0x06004149 RID: 16713 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterAccelerate_d__61(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700171B RID: 5915
		// (get) Token: 0x0600414A RID: 16714 RVA: 0x0010790F File Offset: 0x00105B0F
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterAccelerate_d__61>.NativeClassPtr));
			}
		}

		// Token: 0x1700171C RID: 5916
		// (get) Token: 0x0600414B RID: 16715 RVA: 0x00107920 File Offset: 0x00105B20
		// (set) Token: 0x0600414C RID: 16716 RVA: 0x00107948 File Offset: 0x00105B48
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700171D RID: 5917
		// (get) Token: 0x0600414D RID: 16717 RVA: 0x0010796C File Offset: 0x00105B6C
		// (set) Token: 0x0600414E RID: 16718 RVA: 0x001079A0 File Offset: 0x00105BA0
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700171E RID: 5918
		// (get) Token: 0x0600414F RID: 16719 RVA: 0x001079C8 File Offset: 0x00105BC8
		// (set) Token: 0x06004150 RID: 16720 RVA: 0x001079FC File Offset: 0x00105BFC
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700171F RID: 5919
		// (get) Token: 0x06004151 RID: 16721 RVA: 0x00107A24 File Offset: 0x00105C24
		// (set) Token: 0x06004152 RID: 16722 RVA: 0x00107A4C File Offset: 0x00105C4C
		public unsafe double _startTime_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__startTime_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__startTime_5__2)) = value;
			}
		}

		// Token: 0x17001720 RID: 5920
		// (get) Token: 0x06004153 RID: 16723 RVA: 0x00107A70 File Offset: 0x00105C70
		// (set) Token: 0x06004154 RID: 16724 RVA: 0x00107A98 File Offset: 0x00105C98
		public unsafe double _endTime_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__endTime_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__endTime_5__3)) = value;
			}
		}

		// Token: 0x17001721 RID: 5921
		// (get) Token: 0x06004155 RID: 16725 RVA: 0x00107ABC File Offset: 0x00105CBC
		// (set) Token: 0x06004156 RID: 16726 RVA: 0x00107AE4 File Offset: 0x00105CE4
		public unsafe Vector3 _heliRot_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliRot_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliRot_5__4)) = value;
			}
		}

		// Token: 0x17001722 RID: 5922
		// (get) Token: 0x06004157 RID: 16727 RVA: 0x00107B08 File Offset: 0x00105D08
		// (set) Token: 0x06004158 RID: 16728 RVA: 0x00107B30 File Offset: 0x00105D30
		public unsafe Vector3 _heliEndRot_5__5
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliEndRot_5__5);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterAccelerate_d__61.NativeFieldInfoPtr__heliEndRot_5__5)) = value;
			}
		}

		// Token: 0x040029EB RID: 10731
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040029EC RID: 10732
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040029ED RID: 10733
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040029EE RID: 10734
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__2;

		// Token: 0x040029EF RID: 10735
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__3;

		// Token: 0x040029F0 RID: 10736
		private static readonly IntPtr NativeFieldInfoPtr__heliRot_5__4;

		// Token: 0x040029F1 RID: 10737
		private static readonly IntPtr NativeFieldInfoPtr__heliEndRot_5__5;

		// Token: 0x040029F2 RID: 10738
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040029F3 RID: 10739
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029F4 RID: 10740
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040029F5 RID: 10741
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040029F6 RID: 10742
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040029F7 RID: 10743
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x0200033A RID: 826
	[ObfuscatedName("AIDefendObjective/<HelicopterFlyOut>d__62")]
	public sealed class _HelicopterFlyOut_d__62 : Il2CppSystem.Object
	{
		// Token: 0x06004159 RID: 16729 RVA: 0x00107B54 File Offset: 0x00105D54
		[CallerCount(0)]
		public unsafe _HelicopterFlyOut_d__62(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600415A RID: 16730 RVA: 0x00107BB4 File Offset: 0x00105DB4
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600415B RID: 16731 RVA: 0x00107BF8 File Offset: 0x00105DF8
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001730 RID: 5936
		// (get) Token: 0x0600415C RID: 16732 RVA: 0x00107C48 File Offset: 0x00105E48
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600415D RID: 16733 RVA: 0x00107CA0 File Offset: 0x00105EA0
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001731 RID: 5937
		// (get) Token: 0x0600415E RID: 16734 RVA: 0x00107CE4 File Offset: 0x00105EE4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600415F RID: 16735 RVA: 0x00107D3C File Offset: 0x00105F3C
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterFlyOut_d__62()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterFlyOut>d__62");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__startTime_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<startTime>5__2");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__endTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<endTime>5__3");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliY_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<heliY>5__4");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverEndTime_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<hoverEndTime>5__5");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliRot_5__6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<heliRot>5__6");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliEndRot_5__7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<heliEndRot>5__7");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverFinished_5__8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, "<hoverFinished>5__8");
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668515);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668516);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668517);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668518);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668519);
			AIDefendObjective._HelicopterFlyOut_d__62.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr, 100668520);
		}

		// Token: 0x06004160 RID: 16736 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterFlyOut_d__62(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001725 RID: 5925
		// (get) Token: 0x06004161 RID: 16737 RVA: 0x00107EA7 File Offset: 0x001060A7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOut_d__62>.NativeClassPtr));
			}
		}

		// Token: 0x17001726 RID: 5926
		// (get) Token: 0x06004162 RID: 16738 RVA: 0x00107EB8 File Offset: 0x001060B8
		// (set) Token: 0x06004163 RID: 16739 RVA: 0x00107EE0 File Offset: 0x001060E0
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001727 RID: 5927
		// (get) Token: 0x06004164 RID: 16740 RVA: 0x00107F04 File Offset: 0x00106104
		// (set) Token: 0x06004165 RID: 16741 RVA: 0x00107F38 File Offset: 0x00106138
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001728 RID: 5928
		// (get) Token: 0x06004166 RID: 16742 RVA: 0x00107F60 File Offset: 0x00106160
		// (set) Token: 0x06004167 RID: 16743 RVA: 0x00107F94 File Offset: 0x00106194
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001729 RID: 5929
		// (get) Token: 0x06004168 RID: 16744 RVA: 0x00107FBC File Offset: 0x001061BC
		// (set) Token: 0x06004169 RID: 16745 RVA: 0x00107FE4 File Offset: 0x001061E4
		public unsafe double _startTime_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__startTime_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__startTime_5__2)) = value;
			}
		}

		// Token: 0x1700172A RID: 5930
		// (get) Token: 0x0600416A RID: 16746 RVA: 0x00108008 File Offset: 0x00106208
		// (set) Token: 0x0600416B RID: 16747 RVA: 0x00108030 File Offset: 0x00106230
		public unsafe double _endTime_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__endTime_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__endTime_5__3)) = value;
			}
		}

		// Token: 0x1700172B RID: 5931
		// (get) Token: 0x0600416C RID: 16748 RVA: 0x00108054 File Offset: 0x00106254
		// (set) Token: 0x0600416D RID: 16749 RVA: 0x0010807C File Offset: 0x0010627C
		public unsafe float _heliY_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliY_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliY_5__4)) = value;
			}
		}

		// Token: 0x1700172C RID: 5932
		// (get) Token: 0x0600416E RID: 16750 RVA: 0x001080A0 File Offset: 0x001062A0
		// (set) Token: 0x0600416F RID: 16751 RVA: 0x001080C8 File Offset: 0x001062C8
		public unsafe double _hoverEndTime_5__5
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverEndTime_5__5);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverEndTime_5__5)) = value;
			}
		}

		// Token: 0x1700172D RID: 5933
		// (get) Token: 0x06004170 RID: 16752 RVA: 0x001080EC File Offset: 0x001062EC
		// (set) Token: 0x06004171 RID: 16753 RVA: 0x00108114 File Offset: 0x00106314
		public unsafe Vector3 _heliRot_5__6
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliRot_5__6);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliRot_5__6)) = value;
			}
		}

		// Token: 0x1700172E RID: 5934
		// (get) Token: 0x06004172 RID: 16754 RVA: 0x00108138 File Offset: 0x00106338
		// (set) Token: 0x06004173 RID: 16755 RVA: 0x00108160 File Offset: 0x00106360
		public unsafe Vector3 _heliEndRot_5__7
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliEndRot_5__7);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__heliEndRot_5__7)) = value;
			}
		}

		// Token: 0x1700172F RID: 5935
		// (get) Token: 0x06004174 RID: 16756 RVA: 0x00108184 File Offset: 0x00106384
		// (set) Token: 0x06004175 RID: 16757 RVA: 0x001081AC File Offset: 0x001063AC
		public unsafe bool _hoverFinished_5__8
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverFinished_5__8);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOut_d__62.NativeFieldInfoPtr__hoverFinished_5__8)) = value;
			}
		}

		// Token: 0x040029F8 RID: 10744
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040029F9 RID: 10745
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040029FA RID: 10746
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040029FB RID: 10747
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__2;

		// Token: 0x040029FC RID: 10748
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__3;

		// Token: 0x040029FD RID: 10749
		private static readonly IntPtr NativeFieldInfoPtr__heliY_5__4;

		// Token: 0x040029FE RID: 10750
		private static readonly IntPtr NativeFieldInfoPtr__hoverEndTime_5__5;

		// Token: 0x040029FF RID: 10751
		private static readonly IntPtr NativeFieldInfoPtr__heliRot_5__6;

		// Token: 0x04002A00 RID: 10752
		private static readonly IntPtr NativeFieldInfoPtr__heliEndRot_5__7;

		// Token: 0x04002A01 RID: 10753
		private static readonly IntPtr NativeFieldInfoPtr__hoverFinished_5__8;

		// Token: 0x04002A02 RID: 10754
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04002A03 RID: 10755
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A04 RID: 10756
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04002A05 RID: 10757
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04002A06 RID: 10758
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A07 RID: 10759
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x0200033B RID: 827
	[ObfuscatedName("AIDefendObjective/<HelicopterFlyOutMoveXZ>d__63")]
	public sealed class _HelicopterFlyOutMoveXZ_d__63 : Il2CppSystem.Object
	{
		// Token: 0x06004176 RID: 16758 RVA: 0x001081D0 File Offset: 0x001063D0
		[CallerCount(0)]
		public unsafe _HelicopterFlyOutMoveXZ_d__63(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004177 RID: 16759 RVA: 0x00108230 File Offset: 0x00106430
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004178 RID: 16760 RVA: 0x00108274 File Offset: 0x00106474
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001739 RID: 5945
		// (get) Token: 0x06004179 RID: 16761 RVA: 0x001082C4 File Offset: 0x001064C4
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600417A RID: 16762 RVA: 0x0010831C File Offset: 0x0010651C
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700173A RID: 5946
		// (get) Token: 0x0600417B RID: 16763 RVA: 0x00108360 File Offset: 0x00106560
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600417C RID: 16764 RVA: 0x001083B8 File Offset: 0x001065B8
		// Note: this type is marked as 'beforefieldinit'.
		static _HelicopterFlyOutMoveXZ_d__63()
		{
			Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<HelicopterFlyOutMoveXZ>d__63");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<>1__state");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<>2__current");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<>4__this");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__startTime_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<startTime>5__2");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__endTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<endTime>5__3");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__heliPos_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, "<heliPos>5__4");
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668521);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668522);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668523);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668524);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668525);
			AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr, 100668526);
		}

		// Token: 0x0600417D RID: 16765 RVA: 0x00002988 File Offset: 0x00000B88
		public _HelicopterFlyOutMoveXZ_d__63(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001732 RID: 5938
		// (get) Token: 0x0600417E RID: 16766 RVA: 0x001084D3 File Offset: 0x001066D3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._HelicopterFlyOutMoveXZ_d__63>.NativeClassPtr));
			}
		}

		// Token: 0x17001733 RID: 5939
		// (get) Token: 0x0600417F RID: 16767 RVA: 0x001084E4 File Offset: 0x001066E4
		// (set) Token: 0x06004180 RID: 16768 RVA: 0x0010850C File Offset: 0x0010670C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001734 RID: 5940
		// (get) Token: 0x06004181 RID: 16769 RVA: 0x00108530 File Offset: 0x00106730
		// (set) Token: 0x06004182 RID: 16770 RVA: 0x00108564 File Offset: 0x00106764
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001735 RID: 5941
		// (get) Token: 0x06004183 RID: 16771 RVA: 0x0010858C File Offset: 0x0010678C
		// (set) Token: 0x06004184 RID: 16772 RVA: 0x001085C0 File Offset: 0x001067C0
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001736 RID: 5942
		// (get) Token: 0x06004185 RID: 16773 RVA: 0x001085E8 File Offset: 0x001067E8
		// (set) Token: 0x06004186 RID: 16774 RVA: 0x00108610 File Offset: 0x00106810
		public unsafe double _startTime_5__2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__startTime_5__2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__startTime_5__2)) = value;
			}
		}

		// Token: 0x17001737 RID: 5943
		// (get) Token: 0x06004187 RID: 16775 RVA: 0x00108634 File Offset: 0x00106834
		// (set) Token: 0x06004188 RID: 16776 RVA: 0x0010865C File Offset: 0x0010685C
		public unsafe double _endTime_5__3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__endTime_5__3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__endTime_5__3)) = value;
			}
		}

		// Token: 0x17001738 RID: 5944
		// (get) Token: 0x06004189 RID: 16777 RVA: 0x00108680 File Offset: 0x00106880
		// (set) Token: 0x0600418A RID: 16778 RVA: 0x001086A8 File Offset: 0x001068A8
		public unsafe Vector3 _heliPos_5__4
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__heliPos_5__4);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._HelicopterFlyOutMoveXZ_d__63.NativeFieldInfoPtr__heliPos_5__4)) = value;
			}
		}

		// Token: 0x04002A08 RID: 10760
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04002A09 RID: 10761
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04002A0A RID: 10762
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04002A0B RID: 10763
		private static readonly IntPtr NativeFieldInfoPtr__startTime_5__2;

		// Token: 0x04002A0C RID: 10764
		private static readonly IntPtr NativeFieldInfoPtr__endTime_5__3;

		// Token: 0x04002A0D RID: 10765
		private static readonly IntPtr NativeFieldInfoPtr__heliPos_5__4;

		// Token: 0x04002A0E RID: 10766
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04002A0F RID: 10767
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A10 RID: 10768
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04002A11 RID: 10769
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04002A12 RID: 10770
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A13 RID: 10771
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}

	// Token: 0x0200033C RID: 828
	[ObfuscatedName("AIDefendObjective/<heliLeave>d__68")]
	public sealed class _heliLeave_d__68 : Il2CppSystem.Object
	{
		// Token: 0x0600418B RID: 16779 RVA: 0x001086CC File Offset: 0x001068CC
		[CallerCount(0)]
		public unsafe _heliLeave_d__68(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600418C RID: 16780 RVA: 0x0010872C File Offset: 0x0010692C
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600418D RID: 16781 RVA: 0x00108770 File Offset: 0x00106970
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001740 RID: 5952
		// (get) Token: 0x0600418E RID: 16782 RVA: 0x001087C0 File Offset: 0x001069C0
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x0600418F RID: 16783 RVA: 0x00108818 File Offset: 0x00106A18
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001741 RID: 5953
		// (get) Token: 0x06004190 RID: 16784 RVA: 0x0010885C File Offset: 0x00106A5C
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004191 RID: 16785 RVA: 0x001088B4 File Offset: 0x00106AB4
		// Note: this type is marked as 'beforefieldinit'.
		static _heliLeave_d__68()
		{
			Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AIDefendObjective>.NativeClassPtr, "<heliLeave>d__68");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr);
			AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, "<>1__state");
			AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, "<>2__current");
			AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr_timestampLeaveStarted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, "timestampLeaveStarted");
			AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, "<>4__this");
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668527);
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668528);
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668529);
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668530);
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668531);
			AIDefendObjective._heliLeave_d__68.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr, 100668532);
		}

		// Token: 0x06004192 RID: 16786 RVA: 0x00002988 File Offset: 0x00000B88
		public _heliLeave_d__68(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700173B RID: 5947
		// (get) Token: 0x06004193 RID: 16787 RVA: 0x001089A7 File Offset: 0x00106BA7
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIDefendObjective._heliLeave_d__68>.NativeClassPtr));
			}
		}

		// Token: 0x1700173C RID: 5948
		// (get) Token: 0x06004194 RID: 16788 RVA: 0x001089B8 File Offset: 0x00106BB8
		// (set) Token: 0x06004195 RID: 16789 RVA: 0x001089E0 File Offset: 0x00106BE0
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x1700173D RID: 5949
		// (get) Token: 0x06004196 RID: 16790 RVA: 0x00108A04 File Offset: 0x00106C04
		// (set) Token: 0x06004197 RID: 16791 RVA: 0x00108A38 File Offset: 0x00106C38
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700173E RID: 5950
		// (get) Token: 0x06004198 RID: 16792 RVA: 0x00108A60 File Offset: 0x00106C60
		// (set) Token: 0x06004199 RID: 16793 RVA: 0x00108A88 File Offset: 0x00106C88
		public unsafe double timestampLeaveStarted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr_timestampLeaveStarted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr_timestampLeaveStarted)) = value;
			}
		}

		// Token: 0x1700173F RID: 5951
		// (get) Token: 0x0600419A RID: 16794 RVA: 0x00108AAC File Offset: 0x00106CAC
		// (set) Token: 0x0600419B RID: 16795 RVA: 0x00108AE0 File Offset: 0x00106CE0
		public unsafe AIDefendObjective __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIDefendObjective._heliLeave_d__68.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04002A14 RID: 10772
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x04002A15 RID: 10773
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x04002A16 RID: 10774
		private static readonly IntPtr NativeFieldInfoPtr_timestampLeaveStarted;

		// Token: 0x04002A17 RID: 10775
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x04002A18 RID: 10776
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x04002A19 RID: 10777
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A1A RID: 10778
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x04002A1B RID: 10779
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x04002A1C RID: 10780
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x04002A1D RID: 10781
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
