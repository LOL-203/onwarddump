﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003E7 RID: 999
public class CameraDirectionRotator : MonoBehaviour
{
	// Token: 0x06004E90 RID: 20112 RVA: 0x0013AEB0 File Offset: 0x001390B0
	[CallerCount(0)]
	public unsafe IEnumerator Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator.NativeMethodInfoPtr_Start_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		IntPtr intPtr2 = intPtr;
		return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
	}

	// Token: 0x06004E91 RID: 20113 RVA: 0x0013AF08 File Offset: 0x00139108
	[CallerCount(0)]
	public unsafe void LateUpdate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator.NativeMethodInfoPtr_LateUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E92 RID: 20114 RVA: 0x0013AF4C File Offset: 0x0013914C
	[CallerCount(0)]
	public unsafe CameraDirectionRotator() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004E93 RID: 20115 RVA: 0x0013AF98 File Offset: 0x00139198
	// Note: this type is marked as 'beforefieldinit'.
	static CameraDirectionRotator()
	{
		Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraDirectionRotator");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr);
		CameraDirectionRotator.NativeFieldInfoPtr_behaviorType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, "behaviorType");
		CameraDirectionRotator.NativeFieldInfoPtr_RotationDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, "RotationDelay");
		CameraDirectionRotator.NativeFieldInfoPtr_Camera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, "Camera");
		CameraDirectionRotator.NativeMethodInfoPtr_Start_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, 100669484);
		CameraDirectionRotator.NativeMethodInfoPtr_LateUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, 100669485);
		CameraDirectionRotator.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, 100669486);
	}

	// Token: 0x06004E94 RID: 20116 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraDirectionRotator(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001C12 RID: 7186
	// (get) Token: 0x06004E95 RID: 20117 RVA: 0x0013B040 File Offset: 0x00139240
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr));
		}
	}

	// Token: 0x17001C13 RID: 7187
	// (get) Token: 0x06004E96 RID: 20118 RVA: 0x0013B054 File Offset: 0x00139254
	// (set) Token: 0x06004E97 RID: 20119 RVA: 0x0013B07C File Offset: 0x0013927C
	public unsafe CameraDirectionRotator.BehaviorType behaviorType
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_behaviorType);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_behaviorType)) = value;
		}
	}

	// Token: 0x17001C14 RID: 7188
	// (get) Token: 0x06004E98 RID: 20120 RVA: 0x0013B0A0 File Offset: 0x001392A0
	// (set) Token: 0x06004E99 RID: 20121 RVA: 0x0013B0C8 File Offset: 0x001392C8
	public unsafe float RotationDelay
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_RotationDelay);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_RotationDelay)) = value;
		}
	}

	// Token: 0x17001C15 RID: 7189
	// (get) Token: 0x06004E9A RID: 20122 RVA: 0x0013B0EC File Offset: 0x001392EC
	// (set) Token: 0x06004E9B RID: 20123 RVA: 0x0013B120 File Offset: 0x00139320
	public unsafe Transform Camera
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_Camera);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new Transform(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator.NativeFieldInfoPtr_Camera), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x040031E1 RID: 12769
	private static readonly IntPtr NativeFieldInfoPtr_behaviorType;

	// Token: 0x040031E2 RID: 12770
	private static readonly IntPtr NativeFieldInfoPtr_RotationDelay;

	// Token: 0x040031E3 RID: 12771
	private static readonly IntPtr NativeFieldInfoPtr_Camera;

	// Token: 0x040031E4 RID: 12772
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_IEnumerator_0;

	// Token: 0x040031E5 RID: 12773
	private static readonly IntPtr NativeMethodInfoPtr_LateUpdate_Private_Void_0;

	// Token: 0x040031E6 RID: 12774
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020003E8 RID: 1000
	public enum BehaviorType
	{
		// Token: 0x040031E8 RID: 12776
		OneShotWithDelay,
		// Token: 0x040031E9 RID: 12777
		UpdateEveryFrame
	}

	// Token: 0x020003E9 RID: 1001
	[ObfuscatedName("CameraDirectionRotator/<Start>d__4")]
	public sealed class _Start_d__4 : Il2CppSystem.Object
	{
		// Token: 0x06004E9E RID: 20126 RVA: 0x0013B16C File Offset: 0x0013936C
		[CallerCount(0)]
		public unsafe _Start_d__4(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref <>1__state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004E9F RID: 20127 RVA: 0x0013B1CC File Offset: 0x001393CC
		[CallerCount(0)]
		public unsafe void System_IDisposable_Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004EA0 RID: 20128 RVA: 0x0013B210 File Offset: 0x00139410
		[CallerCount(0)]
		public unsafe bool MoveNext()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x17001C1B RID: 7195
		// (get) Token: 0x06004EA1 RID: 20129 RVA: 0x0013B260 File Offset: 0x00139460
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004EA2 RID: 20130 RVA: 0x0013B2B8 File Offset: 0x001394B8
		[CallerCount(0)]
		public unsafe void System_Collections_IEnumerator_Reset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17001C1C RID: 7196
		// (get) Token: 0x06004EA3 RID: 20131 RVA: 0x0013B2FC File Offset: 0x001394FC
		public unsafe Il2CppSystem.Object Current
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
		}

		// Token: 0x06004EA4 RID: 20132 RVA: 0x0013B354 File Offset: 0x00139554
		// Note: this type is marked as 'beforefieldinit'.
		static _Start_d__4()
		{
			Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CameraDirectionRotator>.NativeClassPtr, "<Start>d__4");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr);
			CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, "<>1__state");
			CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, "<>2__current");
			CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, "<>4__this");
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669487);
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669488);
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669489);
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669490);
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669491);
			CameraDirectionRotator._Start_d__4.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr, 100669492);
		}

		// Token: 0x06004EA5 RID: 20133 RVA: 0x00002988 File Offset: 0x00000B88
		public _Start_d__4(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17001C17 RID: 7191
		// (get) Token: 0x06004EA6 RID: 20134 RVA: 0x0013B433 File Offset: 0x00139633
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraDirectionRotator._Start_d__4>.NativeClassPtr));
			}
		}

		// Token: 0x17001C18 RID: 7192
		// (get) Token: 0x06004EA7 RID: 20135 RVA: 0x0013B444 File Offset: 0x00139644
		// (set) Token: 0x06004EA8 RID: 20136 RVA: 0x0013B46C File Offset: 0x0013966C
		public unsafe int __1__state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___1__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___1__state)) = value;
			}
		}

		// Token: 0x17001C19 RID: 7193
		// (get) Token: 0x06004EA9 RID: 20137 RVA: 0x0013B490 File Offset: 0x00139690
		// (set) Token: 0x06004EAA RID: 20138 RVA: 0x0013B4C4 File Offset: 0x001396C4
		public unsafe Il2CppSystem.Object __2__current
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___2__current);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17001C1A RID: 7194
		// (get) Token: 0x06004EAB RID: 20139 RVA: 0x0013B4EC File Offset: 0x001396EC
		// (set) Token: 0x06004EAC RID: 20140 RVA: 0x0013B520 File Offset: 0x00139720
		public unsafe CameraDirectionRotator __4__this
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___4__this);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CameraDirectionRotator(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraDirectionRotator._Start_d__4.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040031EA RID: 12778
		private static readonly IntPtr NativeFieldInfoPtr___1__state;

		// Token: 0x040031EB RID: 12779
		private static readonly IntPtr NativeFieldInfoPtr___2__current;

		// Token: 0x040031EC RID: 12780
		private static readonly IntPtr NativeFieldInfoPtr___4__this;

		// Token: 0x040031ED RID: 12781
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040031EE RID: 12782
		private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

		// Token: 0x040031EF RID: 12783
		private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

		// Token: 0x040031F0 RID: 12784
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

		// Token: 0x040031F1 RID: 12785
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

		// Token: 0x040031F2 RID: 12786
		private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
	}
}
