﻿using System;
using DPI.Async;
using Il2CppSystem;
using Onward.Networking;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020003FA RID: 1018
public class ConnectionUI : MonoBehaviour
{
	// Token: 0x06004F7A RID: 20346 RVA: 0x0013E3AC File Offset: 0x0013C5AC
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F7B RID: 20347 RVA: 0x0013E3F0 File Offset: 0x0013C5F0
	[CallerCount(0)]
	public unsafe void OnDestroy()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F7C RID: 20348 RVA: 0x0013E434 File Offset: 0x0013C634
	[CallerCount(0)]
	public unsafe void SetEvents(bool active)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref active;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_SetEvents_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F7D RID: 20349 RVA: 0x0013E488 File Offset: 0x0013C688
	[CallerCount(0)]
	public unsafe void OnLoginStateChanged(AsyncProcessState oldMetaState, AsyncProcessState newMetaState)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref oldMetaState;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newMetaState;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnLoginStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F7E RID: 20350 RVA: 0x0013E4F0 File Offset: 0x0013C6F0
	[CallerCount(0)]
	public unsafe void OnMetaStateChanged(AsyncProcessState oldMetaState, AsyncProcessState newMetaState)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref oldMetaState;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newMetaState;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnMetaStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F7F RID: 20351 RVA: 0x0013E558 File Offset: 0x0013C758
	[CallerCount(0)]
	public unsafe void OnVivoxStateChanged()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnVivoxStateChanged_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F80 RID: 20352 RVA: 0x0013E59C File Offset: 0x0013C79C
	[CallerCount(0)]
	public unsafe void OnUpdateInternetState(AsyncProcessState oldInternetState, AsyncProcessState newInternetState)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref oldInternetState;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newInternetState;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnUpdateInternetState_Private_Void_AsyncProcessState_AsyncProcessState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F81 RID: 20353 RVA: 0x0013E604 File Offset: 0x0013C804
	[CallerCount(0)]
	public unsafe void OnUpdatePlatformState(AsyncProcessState oldPlatformState, AsyncProcessState newPlatformState)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref oldPlatformState;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newPlatformState;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnUpdatePlatformState_Private_Void_AsyncProcessState_AsyncProcessState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F82 RID: 20354 RVA: 0x0013E66C File Offset: 0x0013C86C
	[CallerCount(0)]
	public unsafe void OnChangeVersionClicked()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnChangeVersionClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F83 RID: 20355 RVA: 0x0013E6B0 File Offset: 0x0013C8B0
	[CallerCount(0)]
	public unsafe void OnReconnectServersButton()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnReconnectServersButton_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F84 RID: 20356 RVA: 0x0013E6F4 File Offset: 0x0013C8F4
	[CallerCount(0)]
	public unsafe void OnReconnectVoiceButton()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnReconnectVoiceButton_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F85 RID: 20357 RVA: 0x0013E738 File Offset: 0x0013C938
	[CallerCount(0)]
	public unsafe void OnServerContextActivated(OnwardServerContext context)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref context;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnServerContextActivated_Private_Void_OnwardServerContext_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F86 RID: 20358 RVA: 0x0013E78C File Offset: 0x0013C98C
	[CallerCount(0)]
	public unsafe void SetUIState(ConnectionUIState state)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref state;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_SetUIState_Private_Void_ConnectionUIState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F87 RID: 20359 RVA: 0x0013E7E0 File Offset: 0x0013C9E0
	[CallerCount(0)]
	public unsafe string FormatTextForDisplay(string colorHex, string header, string information)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.ManagedStringToIl2Cpp(colorHex);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(header);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(information);
		IntPtr returnedException;
		IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_FormatTextForDisplay_Private_String_String_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return IL2CPP.Il2CppStringToManaged(il2CppString);
	}

	// Token: 0x06004F88 RID: 20360 RVA: 0x0013E874 File Offset: 0x0013CA74
	[CallerCount(0)]
	public unsafe void SetVisibleText(TextMeshProUGUI t, string color, string header, string information)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(color);
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(header);
		ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(information);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_SetVisibleText_Private_Void_TextMeshProUGUI_String_String_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F89 RID: 20361 RVA: 0x0013E918 File Offset: 0x0013CB18
	[CallerCount(0)]
	public unsafe void RefreshServerUI()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshServerUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8A RID: 20362 RVA: 0x0013E95C File Offset: 0x0013CB5C
	[CallerCount(0)]
	public unsafe void RefreshBanUIs()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshBanUIs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8B RID: 20363 RVA: 0x0013E9A0 File Offset: 0x0013CBA0
	[CallerCount(0)]
	public unsafe void RefreshServerAndBanUIs(bool force)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref force;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshServerAndBanUIs_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8C RID: 20364 RVA: 0x0013E9F4 File Offset: 0x0013CBF4
	[CallerCount(0)]
	public unsafe void RefreshInternetUI()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshInternetUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8D RID: 20365 RVA: 0x0013EA38 File Offset: 0x0013CC38
	[CallerCount(0)]
	public unsafe void RefreshPlatformUI()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshPlatformUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8E RID: 20366 RVA: 0x0013EA7C File Offset: 0x0013CC7C
	[CallerCount(0)]
	public unsafe void RefreshVivoxUI()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshVivoxUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F8F RID: 20367 RVA: 0x0013EAC0 File Offset: 0x0013CCC0
	[CallerCount(0)]
	public unsafe void RefreshDeveloperUI()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshDeveloperUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F90 RID: 20368 RVA: 0x0013EB04 File Offset: 0x0013CD04
	[CallerCount(0)]
	public unsafe void RefreshBuildInformation()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_RefreshBuildInformation_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F91 RID: 20369 RVA: 0x0013EB48 File Offset: 0x0013CD48
	[CallerCount(0)]
	public unsafe void OnEverySecond()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr_OnEverySecond_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F92 RID: 20370 RVA: 0x0013EB8C File Offset: 0x0013CD8C
	[CallerCount(0)]
	public unsafe ConnectionUI() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConnectionUI.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004F93 RID: 20371 RVA: 0x0013EBD8 File Offset: 0x0013CDD8
	// Note: this type is marked as 'beforefieldinit'.
	static ConnectionUI()
	{
		Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "ConnectionUI");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr);
		ConnectionUI.NativeFieldInfoPtr_Text_Server = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Server");
		ConnectionUI.NativeFieldInfoPtr_Text_Voice = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Voice");
		ConnectionUI.NativeFieldInfoPtr_Text_StorePlatform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_StorePlatform");
		ConnectionUI.NativeFieldInfoPtr_Text_Context = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Context");
		ConnectionUI.NativeFieldInfoPtr_Text_Build = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Build");
		ConnectionUI.NativeFieldInfoPtr_Text_Changeset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Changeset");
		ConnectionUI.NativeFieldInfoPtr_Text_Restrictions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Restrictions");
		ConnectionUI.NativeFieldInfoPtr_Text_Expiration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_Expiration");
		ConnectionUI.NativeFieldInfoPtr_Text_InternetConnection = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "Text_InternetConnection");
		ConnectionUI.NativeFieldInfoPtr_ReconnectServersButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "ReconnectServersButton");
		ConnectionUI.NativeFieldInfoPtr_ReconnectVoiceButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "ReconnectVoiceButton");
		ConnectionUI.NativeFieldInfoPtr_ToggleVersionButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "ToggleVersionButton");
		ConnectionUI.NativeFieldInfoPtr_goodColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "goodColor");
		ConnectionUI.NativeFieldInfoPtr_warningColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "warningColor");
		ConnectionUI.NativeFieldInfoPtr_badColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "badColor");
		ConnectionUI.NativeFieldInfoPtr_devColor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "devColor");
		ConnectionUI.NativeFieldInfoPtr__moderationCache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, "_moderationCache");
		ConnectionUI.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669547);
		ConnectionUI.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669548);
		ConnectionUI.NativeMethodInfoPtr_SetEvents_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669549);
		ConnectionUI.NativeMethodInfoPtr_OnLoginStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669550);
		ConnectionUI.NativeMethodInfoPtr_OnMetaStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669551);
		ConnectionUI.NativeMethodInfoPtr_OnVivoxStateChanged_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669552);
		ConnectionUI.NativeMethodInfoPtr_OnUpdateInternetState_Private_Void_AsyncProcessState_AsyncProcessState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669553);
		ConnectionUI.NativeMethodInfoPtr_OnUpdatePlatformState_Private_Void_AsyncProcessState_AsyncProcessState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669554);
		ConnectionUI.NativeMethodInfoPtr_OnChangeVersionClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669555);
		ConnectionUI.NativeMethodInfoPtr_OnReconnectServersButton_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669556);
		ConnectionUI.NativeMethodInfoPtr_OnReconnectVoiceButton_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669557);
		ConnectionUI.NativeMethodInfoPtr_OnServerContextActivated_Private_Void_OnwardServerContext_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669558);
		ConnectionUI.NativeMethodInfoPtr_SetUIState_Private_Void_ConnectionUIState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669559);
		ConnectionUI.NativeMethodInfoPtr_FormatTextForDisplay_Private_String_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669560);
		ConnectionUI.NativeMethodInfoPtr_SetVisibleText_Private_Void_TextMeshProUGUI_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669561);
		ConnectionUI.NativeMethodInfoPtr_RefreshServerUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669562);
		ConnectionUI.NativeMethodInfoPtr_RefreshBanUIs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669563);
		ConnectionUI.NativeMethodInfoPtr_RefreshServerAndBanUIs_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669564);
		ConnectionUI.NativeMethodInfoPtr_RefreshInternetUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669565);
		ConnectionUI.NativeMethodInfoPtr_RefreshPlatformUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669566);
		ConnectionUI.NativeMethodInfoPtr_RefreshVivoxUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669567);
		ConnectionUI.NativeMethodInfoPtr_RefreshDeveloperUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669568);
		ConnectionUI.NativeMethodInfoPtr_RefreshBuildInformation_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669569);
		ConnectionUI.NativeMethodInfoPtr_OnEverySecond_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669570);
		ConnectionUI.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr, 100669571);
	}

	// Token: 0x06004F94 RID: 20372 RVA: 0x0000210C File Offset: 0x0000030C
	public ConnectionUI(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17001C66 RID: 7270
	// (get) Token: 0x06004F95 RID: 20373 RVA: 0x0013EF50 File Offset: 0x0013D150
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConnectionUI>.NativeClassPtr));
		}
	}

	// Token: 0x17001C67 RID: 7271
	// (get) Token: 0x06004F96 RID: 20374 RVA: 0x0013EF64 File Offset: 0x0013D164
	// (set) Token: 0x06004F97 RID: 20375 RVA: 0x0013EF98 File Offset: 0x0013D198
	public unsafe TextMeshProUGUI Text_Server
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Server);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Server), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C68 RID: 7272
	// (get) Token: 0x06004F98 RID: 20376 RVA: 0x0013EFC0 File Offset: 0x0013D1C0
	// (set) Token: 0x06004F99 RID: 20377 RVA: 0x0013EFF4 File Offset: 0x0013D1F4
	public unsafe TextMeshProUGUI Text_Voice
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Voice);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Voice), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C69 RID: 7273
	// (get) Token: 0x06004F9A RID: 20378 RVA: 0x0013F01C File Offset: 0x0013D21C
	// (set) Token: 0x06004F9B RID: 20379 RVA: 0x0013F050 File Offset: 0x0013D250
	public unsafe TextMeshProUGUI Text_StorePlatform
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_StorePlatform);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_StorePlatform), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6A RID: 7274
	// (get) Token: 0x06004F9C RID: 20380 RVA: 0x0013F078 File Offset: 0x0013D278
	// (set) Token: 0x06004F9D RID: 20381 RVA: 0x0013F0AC File Offset: 0x0013D2AC
	public unsafe TextMeshProUGUI Text_Context
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Context);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Context), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6B RID: 7275
	// (get) Token: 0x06004F9E RID: 20382 RVA: 0x0013F0D4 File Offset: 0x0013D2D4
	// (set) Token: 0x06004F9F RID: 20383 RVA: 0x0013F108 File Offset: 0x0013D308
	public unsafe TextMeshProUGUI Text_Build
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Build);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Build), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6C RID: 7276
	// (get) Token: 0x06004FA0 RID: 20384 RVA: 0x0013F130 File Offset: 0x0013D330
	// (set) Token: 0x06004FA1 RID: 20385 RVA: 0x0013F164 File Offset: 0x0013D364
	public unsafe TextMeshProUGUI Text_Changeset
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Changeset);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Changeset), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6D RID: 7277
	// (get) Token: 0x06004FA2 RID: 20386 RVA: 0x0013F18C File Offset: 0x0013D38C
	// (set) Token: 0x06004FA3 RID: 20387 RVA: 0x0013F1C0 File Offset: 0x0013D3C0
	public unsafe TextMeshProUGUI Text_Restrictions
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Restrictions);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Restrictions), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6E RID: 7278
	// (get) Token: 0x06004FA4 RID: 20388 RVA: 0x0013F1E8 File Offset: 0x0013D3E8
	// (set) Token: 0x06004FA5 RID: 20389 RVA: 0x0013F21C File Offset: 0x0013D41C
	public unsafe TextMeshProUGUI Text_Expiration
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Expiration);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_Expiration), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C6F RID: 7279
	// (get) Token: 0x06004FA6 RID: 20390 RVA: 0x0013F244 File Offset: 0x0013D444
	// (set) Token: 0x06004FA7 RID: 20391 RVA: 0x0013F278 File Offset: 0x0013D478
	public unsafe TextMeshProUGUI Text_InternetConnection
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_InternetConnection);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_Text_InternetConnection), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C70 RID: 7280
	// (get) Token: 0x06004FA8 RID: 20392 RVA: 0x0013F2A0 File Offset: 0x0013D4A0
	// (set) Token: 0x06004FA9 RID: 20393 RVA: 0x0013F2D4 File Offset: 0x0013D4D4
	public unsafe MenuItemPopout ReconnectServersButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ReconnectServersButton);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ReconnectServersButton), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C71 RID: 7281
	// (get) Token: 0x06004FAA RID: 20394 RVA: 0x0013F2FC File Offset: 0x0013D4FC
	// (set) Token: 0x06004FAB RID: 20395 RVA: 0x0013F330 File Offset: 0x0013D530
	public unsafe MenuItemPopout ReconnectVoiceButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ReconnectVoiceButton);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ReconnectVoiceButton), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C72 RID: 7282
	// (get) Token: 0x06004FAC RID: 20396 RVA: 0x0013F358 File Offset: 0x0013D558
	// (set) Token: 0x06004FAD RID: 20397 RVA: 0x0013F38C File Offset: 0x0013D58C
	public unsafe MenuItemPopout ToggleVersionButton
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ToggleVersionButton);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr_ToggleVersionButton), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17001C73 RID: 7283
	// (get) Token: 0x06004FAE RID: 20398 RVA: 0x0013F3B4 File Offset: 0x0013D5B4
	// (set) Token: 0x06004FAF RID: 20399 RVA: 0x0013F3D4 File Offset: 0x0013D5D4
	public unsafe static string goodColor
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ConnectionUI.NativeFieldInfoPtr_goodColor, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ConnectionUI.NativeFieldInfoPtr_goodColor, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001C74 RID: 7284
	// (get) Token: 0x06004FB0 RID: 20400 RVA: 0x0013F3EC File Offset: 0x0013D5EC
	// (set) Token: 0x06004FB1 RID: 20401 RVA: 0x0013F40C File Offset: 0x0013D60C
	public unsafe static string warningColor
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ConnectionUI.NativeFieldInfoPtr_warningColor, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ConnectionUI.NativeFieldInfoPtr_warningColor, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001C75 RID: 7285
	// (get) Token: 0x06004FB2 RID: 20402 RVA: 0x0013F424 File Offset: 0x0013D624
	// (set) Token: 0x06004FB3 RID: 20403 RVA: 0x0013F444 File Offset: 0x0013D644
	public unsafe static string badColor
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ConnectionUI.NativeFieldInfoPtr_badColor, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ConnectionUI.NativeFieldInfoPtr_badColor, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001C76 RID: 7286
	// (get) Token: 0x06004FB4 RID: 20404 RVA: 0x0013F45C File Offset: 0x0013D65C
	// (set) Token: 0x06004FB5 RID: 20405 RVA: 0x0013F47C File Offset: 0x0013D67C
	public unsafe static string devColor
	{
		get
		{
			IntPtr il2CppString;
			IL2CPP.il2cpp_field_static_get_value(ConnectionUI.NativeFieldInfoPtr_devColor, (void*)(&il2CppString));
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(ConnectionUI.NativeFieldInfoPtr_devColor, IL2CPP.ManagedStringToIl2Cpp(value));
		}
	}

	// Token: 0x17001C77 RID: 7287
	// (get) Token: 0x06004FB6 RID: 20406 RVA: 0x0013F494 File Offset: 0x0013D694
	// (set) Token: 0x06004FB7 RID: 20407 RVA: 0x0013F4BC File Offset: 0x0013D6BC
	public unsafe bool _moderationCache
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr__moderationCache);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConnectionUI.NativeFieldInfoPtr__moderationCache)) = value;
		}
	}

	// Token: 0x04003264 RID: 12900
	private static readonly IntPtr NativeFieldInfoPtr_Text_Server;

	// Token: 0x04003265 RID: 12901
	private static readonly IntPtr NativeFieldInfoPtr_Text_Voice;

	// Token: 0x04003266 RID: 12902
	private static readonly IntPtr NativeFieldInfoPtr_Text_StorePlatform;

	// Token: 0x04003267 RID: 12903
	private static readonly IntPtr NativeFieldInfoPtr_Text_Context;

	// Token: 0x04003268 RID: 12904
	private static readonly IntPtr NativeFieldInfoPtr_Text_Build;

	// Token: 0x04003269 RID: 12905
	private static readonly IntPtr NativeFieldInfoPtr_Text_Changeset;

	// Token: 0x0400326A RID: 12906
	private static readonly IntPtr NativeFieldInfoPtr_Text_Restrictions;

	// Token: 0x0400326B RID: 12907
	private static readonly IntPtr NativeFieldInfoPtr_Text_Expiration;

	// Token: 0x0400326C RID: 12908
	private static readonly IntPtr NativeFieldInfoPtr_Text_InternetConnection;

	// Token: 0x0400326D RID: 12909
	private static readonly IntPtr NativeFieldInfoPtr_ReconnectServersButton;

	// Token: 0x0400326E RID: 12910
	private static readonly IntPtr NativeFieldInfoPtr_ReconnectVoiceButton;

	// Token: 0x0400326F RID: 12911
	private static readonly IntPtr NativeFieldInfoPtr_ToggleVersionButton;

	// Token: 0x04003270 RID: 12912
	private static readonly IntPtr NativeFieldInfoPtr_goodColor;

	// Token: 0x04003271 RID: 12913
	private static readonly IntPtr NativeFieldInfoPtr_warningColor;

	// Token: 0x04003272 RID: 12914
	private static readonly IntPtr NativeFieldInfoPtr_badColor;

	// Token: 0x04003273 RID: 12915
	private static readonly IntPtr NativeFieldInfoPtr_devColor;

	// Token: 0x04003274 RID: 12916
	private static readonly IntPtr NativeFieldInfoPtr__moderationCache;

	// Token: 0x04003275 RID: 12917
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04003276 RID: 12918
	private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

	// Token: 0x04003277 RID: 12919
	private static readonly IntPtr NativeMethodInfoPtr_SetEvents_Private_Void_Boolean_0;

	// Token: 0x04003278 RID: 12920
	private static readonly IntPtr NativeMethodInfoPtr_OnLoginStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0;

	// Token: 0x04003279 RID: 12921
	private static readonly IntPtr NativeMethodInfoPtr_OnMetaStateChanged_Private_Void_AsyncProcessState_AsyncProcessState_0;

	// Token: 0x0400327A RID: 12922
	private static readonly IntPtr NativeMethodInfoPtr_OnVivoxStateChanged_Private_Void_0;

	// Token: 0x0400327B RID: 12923
	private static readonly IntPtr NativeMethodInfoPtr_OnUpdateInternetState_Private_Void_AsyncProcessState_AsyncProcessState_0;

	// Token: 0x0400327C RID: 12924
	private static readonly IntPtr NativeMethodInfoPtr_OnUpdatePlatformState_Private_Void_AsyncProcessState_AsyncProcessState_0;

	// Token: 0x0400327D RID: 12925
	private static readonly IntPtr NativeMethodInfoPtr_OnChangeVersionClicked_Private_Void_0;

	// Token: 0x0400327E RID: 12926
	private static readonly IntPtr NativeMethodInfoPtr_OnReconnectServersButton_Public_Void_0;

	// Token: 0x0400327F RID: 12927
	private static readonly IntPtr NativeMethodInfoPtr_OnReconnectVoiceButton_Public_Void_0;

	// Token: 0x04003280 RID: 12928
	private static readonly IntPtr NativeMethodInfoPtr_OnServerContextActivated_Private_Void_OnwardServerContext_0;

	// Token: 0x04003281 RID: 12929
	private static readonly IntPtr NativeMethodInfoPtr_SetUIState_Private_Void_ConnectionUIState_0;

	// Token: 0x04003282 RID: 12930
	private static readonly IntPtr NativeMethodInfoPtr_FormatTextForDisplay_Private_String_String_String_String_0;

	// Token: 0x04003283 RID: 12931
	private static readonly IntPtr NativeMethodInfoPtr_SetVisibleText_Private_Void_TextMeshProUGUI_String_String_String_0;

	// Token: 0x04003284 RID: 12932
	private static readonly IntPtr NativeMethodInfoPtr_RefreshServerUI_Private_Void_0;

	// Token: 0x04003285 RID: 12933
	private static readonly IntPtr NativeMethodInfoPtr_RefreshBanUIs_Private_Void_0;

	// Token: 0x04003286 RID: 12934
	private static readonly IntPtr NativeMethodInfoPtr_RefreshServerAndBanUIs_Private_Void_Boolean_0;

	// Token: 0x04003287 RID: 12935
	private static readonly IntPtr NativeMethodInfoPtr_RefreshInternetUI_Private_Void_0;

	// Token: 0x04003288 RID: 12936
	private static readonly IntPtr NativeMethodInfoPtr_RefreshPlatformUI_Private_Void_0;

	// Token: 0x04003289 RID: 12937
	private static readonly IntPtr NativeMethodInfoPtr_RefreshVivoxUI_Private_Void_0;

	// Token: 0x0400328A RID: 12938
	private static readonly IntPtr NativeMethodInfoPtr_RefreshDeveloperUI_Private_Void_0;

	// Token: 0x0400328B RID: 12939
	private static readonly IntPtr NativeMethodInfoPtr_RefreshBuildInformation_Private_Void_0;

	// Token: 0x0400328C RID: 12940
	private static readonly IntPtr NativeMethodInfoPtr_OnEverySecond_Private_Void_0;

	// Token: 0x0400328D RID: 12941
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
