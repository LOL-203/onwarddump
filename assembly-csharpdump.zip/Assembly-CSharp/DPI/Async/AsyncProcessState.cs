﻿using System;

namespace DPI.Async
{
	// Token: 0x0200102A RID: 4138
	public enum AsyncProcessState
	{
		// Token: 0x0400CA73 RID: 51827
		NotStarted,
		// Token: 0x0400CA74 RID: 51828
		InProgress,
		// Token: 0x0400CA75 RID: 51829
		Failed,
		// Token: 0x0400CA76 RID: 51830
		FailedWithNoRetry,
		// Token: 0x0400CA77 RID: 51831
		Succeeded
	}
}
