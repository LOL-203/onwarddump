﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Benchmark
{
	// Token: 0x02000FFE RID: 4094
	[Serializable]
	public class BenchmarkSamplePoint : Il2CppSystem.Object
	{
		// Token: 0x0601399A RID: 80282 RVA: 0x004EEA48 File Offset: 0x004ECC48
		[CallerCount(0)]
		public unsafe static BenchmarkSamplePoint Create(Vector3 pos, Quaternion rot)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rot;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplePoint.NativeMethodInfoPtr_Create_Public_Static_BenchmarkSamplePoint_Vector3_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new BenchmarkSamplePoint(intPtr2) : null;
		}

		// Token: 0x0601399B RID: 80283 RVA: 0x004EEAB4 File Offset: 0x004ECCB4
		[CallerCount(0)]
		public unsafe void ApplyToTransform(Transform cameraRigTransform)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(cameraRigTransform);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplePoint.NativeMethodInfoPtr_ApplyToTransform_Public_Void_Transform_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601399C RID: 80284 RVA: 0x004EEB10 File Offset: 0x004ECD10
		[CallerCount(0)]
		public unsafe BenchmarkSamplePoint() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplePoint.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601399D RID: 80285 RVA: 0x004EEB5C File Offset: 0x004ECD5C
		// Note: this type is marked as 'beforefieldinit'.
		static BenchmarkSamplePoint()
		{
			Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "BenchmarkSamplePoint");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr);
			BenchmarkSamplePoint.NativeFieldInfoPtr_GUID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "GUID");
			BenchmarkSamplePoint.NativeFieldInfoPtr_Active = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "Active");
			BenchmarkSamplePoint.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "Position");
			BenchmarkSamplePoint.NativeFieldInfoPtr_Rotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "Rotation");
			BenchmarkSamplePoint.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "Name");
			BenchmarkSamplePoint.NativeFieldInfoPtr_Comment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, "Comment");
			BenchmarkSamplePoint.NativeMethodInfoPtr_Create_Public_Static_BenchmarkSamplePoint_Vector3_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, 100688323);
			BenchmarkSamplePoint.NativeMethodInfoPtr_ApplyToTransform_Public_Void_Transform_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, 100688324);
			BenchmarkSamplePoint.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr, 100688325);
		}

		// Token: 0x0601399E RID: 80286 RVA: 0x00002988 File Offset: 0x00000B88
		public BenchmarkSamplePoint(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006F26 RID: 28454
		// (get) Token: 0x0601399F RID: 80287 RVA: 0x004EEC40 File Offset: 0x004ECE40
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkSamplePoint>.NativeClassPtr));
			}
		}

		// Token: 0x17006F27 RID: 28455
		// (get) Token: 0x060139A0 RID: 80288 RVA: 0x004EEC54 File Offset: 0x004ECE54
		// (set) Token: 0x060139A1 RID: 80289 RVA: 0x004EEC7D File Offset: 0x004ECE7D
		public unsafe string GUID
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_GUID);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_GUID), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F28 RID: 28456
		// (get) Token: 0x060139A2 RID: 80290 RVA: 0x004EECA4 File Offset: 0x004ECEA4
		// (set) Token: 0x060139A3 RID: 80291 RVA: 0x004EECCC File Offset: 0x004ECECC
		public unsafe bool Active
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Active);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Active)) = value;
			}
		}

		// Token: 0x17006F29 RID: 28457
		// (get) Token: 0x060139A4 RID: 80292 RVA: 0x004EECF0 File Offset: 0x004ECEF0
		// (set) Token: 0x060139A5 RID: 80293 RVA: 0x004EED18 File Offset: 0x004ECF18
		public unsafe Vector3 Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x17006F2A RID: 28458
		// (get) Token: 0x060139A6 RID: 80294 RVA: 0x004EED3C File Offset: 0x004ECF3C
		// (set) Token: 0x060139A7 RID: 80295 RVA: 0x004EED64 File Offset: 0x004ECF64
		public unsafe Quaternion Rotation
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Rotation);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Rotation)) = value;
			}
		}

		// Token: 0x17006F2B RID: 28459
		// (get) Token: 0x060139A8 RID: 80296 RVA: 0x004EED88 File Offset: 0x004ECF88
		// (set) Token: 0x060139A9 RID: 80297 RVA: 0x004EEDB1 File Offset: 0x004ECFB1
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F2C RID: 28460
		// (get) Token: 0x060139AA RID: 80298 RVA: 0x004EEDD8 File Offset: 0x004ECFD8
		// (set) Token: 0x060139AB RID: 80299 RVA: 0x004EEE01 File Offset: 0x004ED001
		public unsafe string Comment
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Comment);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplePoint.NativeFieldInfoPtr_Comment), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400C87F RID: 51327
		private static readonly IntPtr NativeFieldInfoPtr_GUID;

		// Token: 0x0400C880 RID: 51328
		private static readonly IntPtr NativeFieldInfoPtr_Active;

		// Token: 0x0400C881 RID: 51329
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x0400C882 RID: 51330
		private static readonly IntPtr NativeFieldInfoPtr_Rotation;

		// Token: 0x0400C883 RID: 51331
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x0400C884 RID: 51332
		private static readonly IntPtr NativeFieldInfoPtr_Comment;

		// Token: 0x0400C885 RID: 51333
		private static readonly IntPtr NativeMethodInfoPtr_Create_Public_Static_BenchmarkSamplePoint_Vector3_Quaternion_0;

		// Token: 0x0400C886 RID: 51334
		private static readonly IntPtr NativeMethodInfoPtr_ApplyToTransform_Public_Void_Transform_0;

		// Token: 0x0400C887 RID: 51335
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;
	}
}
