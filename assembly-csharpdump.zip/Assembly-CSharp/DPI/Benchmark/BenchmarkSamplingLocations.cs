﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Benchmark
{
	// Token: 0x02001001 RID: 4097
	public class BenchmarkSamplingLocations : ScriptableObject
	{
		// Token: 0x17006F33 RID: 28467
		// (get) Token: 0x060139BB RID: 80315 RVA: 0x004EF1E4 File Offset: 0x004ED3E4
		public unsafe List<BenchmarkSamplePoint> ActiveSamplePoints
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplingLocations.NativeMethodInfoPtr_get_ActiveSamplePoints_Public_get_List_1_BenchmarkSamplePoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<BenchmarkSamplePoint>(intPtr2) : null;
			}
		}

		// Token: 0x17006F34 RID: 28468
		// (get) Token: 0x060139BC RID: 80316 RVA: 0x004EF23C File Offset: 0x004ED43C
		public unsafe List<BenchmarkSamplePoint> AllSamplingPositions
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplingLocations.NativeMethodInfoPtr_get_AllSamplingPositions_Public_get_List_1_BenchmarkSamplePoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<BenchmarkSamplePoint>(intPtr2) : null;
			}
		}

		// Token: 0x060139BD RID: 80317 RVA: 0x004EF294 File Offset: 0x004ED494
		[CallerCount(0)]
		public unsafe BenchmarkSamplingLocations() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplingLocations.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139BE RID: 80318 RVA: 0x004EF2E0 File Offset: 0x004ED4E0
		// Note: this type is marked as 'beforefieldinit'.
		static BenchmarkSamplingLocations()
		{
			Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "BenchmarkSamplingLocations");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr);
			BenchmarkSamplingLocations.NativeFieldInfoPtr__samplePoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr, "_samplePoints");
			BenchmarkSamplingLocations.NativeMethodInfoPtr_get_ActiveSamplePoints_Public_get_List_1_BenchmarkSamplePoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr, 100688333);
			BenchmarkSamplingLocations.NativeMethodInfoPtr_get_AllSamplingPositions_Public_get_List_1_BenchmarkSamplePoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr, 100688334);
			BenchmarkSamplingLocations.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr, 100688335);
		}

		// Token: 0x060139BF RID: 80319 RVA: 0x0002DD3C File Offset: 0x0002BF3C
		public BenchmarkSamplingLocations(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006F31 RID: 28465
		// (get) Token: 0x060139C0 RID: 80320 RVA: 0x004EF360 File Offset: 0x004ED560
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr));
			}
		}

		// Token: 0x17006F32 RID: 28466
		// (get) Token: 0x060139C1 RID: 80321 RVA: 0x004EF374 File Offset: 0x004ED574
		// (set) Token: 0x060139C2 RID: 80322 RVA: 0x004EF3A8 File Offset: 0x004ED5A8
		public unsafe List<BenchmarkSamplePoint> _samplePoints
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplingLocations.NativeFieldInfoPtr__samplePoints);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<BenchmarkSamplePoint>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSamplingLocations.NativeFieldInfoPtr__samplePoints), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C896 RID: 51350
		private static readonly IntPtr NativeFieldInfoPtr__samplePoints;

		// Token: 0x0400C897 RID: 51351
		private static readonly IntPtr NativeMethodInfoPtr_get_ActiveSamplePoints_Public_get_List_1_BenchmarkSamplePoint_0;

		// Token: 0x0400C898 RID: 51352
		private static readonly IntPtr NativeMethodInfoPtr_get_AllSamplingPositions_Public_get_List_1_BenchmarkSamplePoint_0;

		// Token: 0x0400C899 RID: 51353
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001002 RID: 4098
		[ObfuscatedName("DPI.Benchmark.BenchmarkSamplingLocations/<>c")]
		[Serializable]
		public sealed class __c : Il2CppSystem.Object
		{
			// Token: 0x060139C3 RID: 80323 RVA: 0x004EF3D0 File Offset: 0x004ED5D0
			[CallerCount(0)]
			public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplingLocations.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x060139C4 RID: 80324 RVA: 0x004EF41C File Offset: 0x004ED61C
			[CallerCount(0)]
			public unsafe bool _get_ActiveSamplePoints_b__1_0(BenchmarkSamplePoint point)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(point);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkSamplingLocations.__c.NativeMethodInfoPtr__get_ActiveSamplePoints_b__1_0_Internal_Boolean_BenchmarkSamplePoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x060139C5 RID: 80325 RVA: 0x004EF484 File Offset: 0x004ED684
			// Note: this type is marked as 'beforefieldinit'.
			static __c()
			{
				Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BenchmarkSamplingLocations>.NativeClassPtr, "<>c");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr);
				BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr, "<>9");
				BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9__1_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr, "<>9__1_0");
				BenchmarkSamplingLocations.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr, 100688337);
				BenchmarkSamplingLocations.__c.NativeMethodInfoPtr__get_ActiveSamplePoints_b__1_0_Internal_Boolean_BenchmarkSamplePoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr, 100688338);
			}

			// Token: 0x060139C6 RID: 80326 RVA: 0x00002988 File Offset: 0x00000B88
			public __c(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006F35 RID: 28469
			// (get) Token: 0x060139C7 RID: 80327 RVA: 0x004EF4FF File Offset: 0x004ED6FF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkSamplingLocations.__c>.NativeClassPtr));
				}
			}

			// Token: 0x17006F36 RID: 28470
			// (get) Token: 0x060139C8 RID: 80328 RVA: 0x004EF510 File Offset: 0x004ED710
			// (set) Token: 0x060139C9 RID: 80329 RVA: 0x004EF53B File Offset: 0x004ED73B
			public unsafe static BenchmarkSamplingLocations.__c __9
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new BenchmarkSamplingLocations.__c(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F37 RID: 28471
			// (get) Token: 0x060139CA RID: 80330 RVA: 0x004EF550 File Offset: 0x004ED750
			// (set) Token: 0x060139CB RID: 80331 RVA: 0x004EF57B File Offset: 0x004ED77B
			public unsafe static Func<BenchmarkSamplePoint, bool> __9__1_0
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9__1_0, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<BenchmarkSamplePoint, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(BenchmarkSamplingLocations.__c.NativeFieldInfoPtr___9__1_0, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C89A RID: 51354
			private static readonly IntPtr NativeFieldInfoPtr___9;

			// Token: 0x0400C89B RID: 51355
			private static readonly IntPtr NativeFieldInfoPtr___9__1_0;

			// Token: 0x0400C89C RID: 51356
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400C89D RID: 51357
			private static readonly IntPtr NativeMethodInfoPtr__get_ActiveSamplePoints_b__1_0_Internal_Boolean_BenchmarkSamplePoint_0;
		}
	}
}
