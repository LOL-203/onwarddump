﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Benchmark
{
	// Token: 0x02001005 RID: 4101
	[Serializable]
	public class SerializedBenchmarkSample : Il2CppSystem.Object
	{
		// Token: 0x060139E8 RID: 80360 RVA: 0x004EFAD0 File Offset: 0x004EDCD0
		[CallerCount(0)]
		public unsafe SerializedBenchmarkSample() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializedBenchmarkSample.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139E9 RID: 80361 RVA: 0x004EFB1C File Offset: 0x004EDD1C
		// Note: this type is marked as 'beforefieldinit'.
		static SerializedBenchmarkSample()
		{
			Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "SerializedBenchmarkSample");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr);
			SerializedBenchmarkSample.NativeFieldInfoPtr_GUID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "GUID");
			SerializedBenchmarkSample.NativeFieldInfoPtr_LocationName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "LocationName");
			SerializedBenchmarkSample.NativeFieldInfoPtr_LocationComment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "LocationComment");
			SerializedBenchmarkSample.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "Position");
			SerializedBenchmarkSample.NativeFieldInfoPtr_Rotation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "Rotation");
			SerializedBenchmarkSample.NativeFieldInfoPtr_ImageName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "ImageName");
			SerializedBenchmarkSample.NativeFieldInfoPtr_CpuTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "CpuTime");
			SerializedBenchmarkSample.NativeFieldInfoPtr_DrawCallCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "DrawCallCount");
			SerializedBenchmarkSample.NativeFieldInfoPtr_SetPassCallCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "SetPassCallCount");
			SerializedBenchmarkSample.NativeFieldInfoPtr_VerticesCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "VerticesCount");
			SerializedBenchmarkSample.NativeFieldInfoPtr_TrianglesCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "TrianglesCount");
			SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppCpuTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "OVR_AppCpuTime");
			SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppGpuTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "OVR_AppGpuTime");
			SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_DroppedFrameCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "OVR_DroppedFrameCount");
			SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_GpuUtilPercentage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, "OVR_GpuUtilPercentage");
			SerializedBenchmarkSample.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr, 100688341);
		}

		// Token: 0x060139EA RID: 80362 RVA: 0x00002988 File Offset: 0x00000B88
		public SerializedBenchmarkSample(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006F44 RID: 28484
		// (get) Token: 0x060139EB RID: 80363 RVA: 0x004EFC8C File Offset: 0x004EDE8C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SerializedBenchmarkSample>.NativeClassPtr));
			}
		}

		// Token: 0x17006F45 RID: 28485
		// (get) Token: 0x060139EC RID: 80364 RVA: 0x004EFCA0 File Offset: 0x004EDEA0
		// (set) Token: 0x060139ED RID: 80365 RVA: 0x004EFCC9 File Offset: 0x004EDEC9
		public unsafe string GUID
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_GUID);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_GUID), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F46 RID: 28486
		// (get) Token: 0x060139EE RID: 80366 RVA: 0x004EFCF0 File Offset: 0x004EDEF0
		// (set) Token: 0x060139EF RID: 80367 RVA: 0x004EFD19 File Offset: 0x004EDF19
		public unsafe string LocationName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_LocationName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_LocationName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F47 RID: 28487
		// (get) Token: 0x060139F0 RID: 80368 RVA: 0x004EFD40 File Offset: 0x004EDF40
		// (set) Token: 0x060139F1 RID: 80369 RVA: 0x004EFD69 File Offset: 0x004EDF69
		public unsafe string LocationComment
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_LocationComment);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_LocationComment), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F48 RID: 28488
		// (get) Token: 0x060139F2 RID: 80370 RVA: 0x004EFD90 File Offset: 0x004EDF90
		// (set) Token: 0x060139F3 RID: 80371 RVA: 0x004EFDB8 File Offset: 0x004EDFB8
		public unsafe Vector3 Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x17006F49 RID: 28489
		// (get) Token: 0x060139F4 RID: 80372 RVA: 0x004EFDDC File Offset: 0x004EDFDC
		// (set) Token: 0x060139F5 RID: 80373 RVA: 0x004EFE04 File Offset: 0x004EE004
		public unsafe Quaternion Rotation
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_Rotation);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_Rotation)) = value;
			}
		}

		// Token: 0x17006F4A RID: 28490
		// (get) Token: 0x060139F6 RID: 80374 RVA: 0x004EFE28 File Offset: 0x004EE028
		// (set) Token: 0x060139F7 RID: 80375 RVA: 0x004EFE51 File Offset: 0x004EE051
		public unsafe string ImageName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_ImageName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_ImageName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F4B RID: 28491
		// (get) Token: 0x060139F8 RID: 80376 RVA: 0x004EFE78 File Offset: 0x004EE078
		// (set) Token: 0x060139F9 RID: 80377 RVA: 0x004EFEA0 File Offset: 0x004EE0A0
		public unsafe float CpuTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_CpuTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_CpuTime)) = value;
			}
		}

		// Token: 0x17006F4C RID: 28492
		// (get) Token: 0x060139FA RID: 80378 RVA: 0x004EFEC4 File Offset: 0x004EE0C4
		// (set) Token: 0x060139FB RID: 80379 RVA: 0x004EFEEC File Offset: 0x004EE0EC
		public unsafe float DrawCallCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_DrawCallCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_DrawCallCount)) = value;
			}
		}

		// Token: 0x17006F4D RID: 28493
		// (get) Token: 0x060139FC RID: 80380 RVA: 0x004EFF10 File Offset: 0x004EE110
		// (set) Token: 0x060139FD RID: 80381 RVA: 0x004EFF38 File Offset: 0x004EE138
		public unsafe float SetPassCallCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_SetPassCallCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_SetPassCallCount)) = value;
			}
		}

		// Token: 0x17006F4E RID: 28494
		// (get) Token: 0x060139FE RID: 80382 RVA: 0x004EFF5C File Offset: 0x004EE15C
		// (set) Token: 0x060139FF RID: 80383 RVA: 0x004EFF84 File Offset: 0x004EE184
		public unsafe float VerticesCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_VerticesCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_VerticesCount)) = value;
			}
		}

		// Token: 0x17006F4F RID: 28495
		// (get) Token: 0x06013A00 RID: 80384 RVA: 0x004EFFA8 File Offset: 0x004EE1A8
		// (set) Token: 0x06013A01 RID: 80385 RVA: 0x004EFFD0 File Offset: 0x004EE1D0
		public unsafe float TrianglesCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_TrianglesCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_TrianglesCount)) = value;
			}
		}

		// Token: 0x17006F50 RID: 28496
		// (get) Token: 0x06013A02 RID: 80386 RVA: 0x004EFFF4 File Offset: 0x004EE1F4
		// (set) Token: 0x06013A03 RID: 80387 RVA: 0x004F001C File Offset: 0x004EE21C
		public unsafe float OVR_AppCpuTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppCpuTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppCpuTime)) = value;
			}
		}

		// Token: 0x17006F51 RID: 28497
		// (get) Token: 0x06013A04 RID: 80388 RVA: 0x004F0040 File Offset: 0x004EE240
		// (set) Token: 0x06013A05 RID: 80389 RVA: 0x004F0068 File Offset: 0x004EE268
		public unsafe float OVR_AppGpuTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppGpuTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_AppGpuTime)) = value;
			}
		}

		// Token: 0x17006F52 RID: 28498
		// (get) Token: 0x06013A06 RID: 80390 RVA: 0x004F008C File Offset: 0x004EE28C
		// (set) Token: 0x06013A07 RID: 80391 RVA: 0x004F00B4 File Offset: 0x004EE2B4
		public unsafe float OVR_DroppedFrameCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_DroppedFrameCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_DroppedFrameCount)) = value;
			}
		}

		// Token: 0x17006F53 RID: 28499
		// (get) Token: 0x06013A08 RID: 80392 RVA: 0x004F00D8 File Offset: 0x004EE2D8
		// (set) Token: 0x06013A09 RID: 80393 RVA: 0x004F0100 File Offset: 0x004EE300
		public unsafe float OVR_GpuUtilPercentage
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_GpuUtilPercentage);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkSample.NativeFieldInfoPtr_OVR_GpuUtilPercentage)) = value;
			}
		}

		// Token: 0x0400C8AA RID: 51370
		private static readonly IntPtr NativeFieldInfoPtr_GUID;

		// Token: 0x0400C8AB RID: 51371
		private static readonly IntPtr NativeFieldInfoPtr_LocationName;

		// Token: 0x0400C8AC RID: 51372
		private static readonly IntPtr NativeFieldInfoPtr_LocationComment;

		// Token: 0x0400C8AD RID: 51373
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x0400C8AE RID: 51374
		private static readonly IntPtr NativeFieldInfoPtr_Rotation;

		// Token: 0x0400C8AF RID: 51375
		private static readonly IntPtr NativeFieldInfoPtr_ImageName;

		// Token: 0x0400C8B0 RID: 51376
		private static readonly IntPtr NativeFieldInfoPtr_CpuTime;

		// Token: 0x0400C8B1 RID: 51377
		private static readonly IntPtr NativeFieldInfoPtr_DrawCallCount;

		// Token: 0x0400C8B2 RID: 51378
		private static readonly IntPtr NativeFieldInfoPtr_SetPassCallCount;

		// Token: 0x0400C8B3 RID: 51379
		private static readonly IntPtr NativeFieldInfoPtr_VerticesCount;

		// Token: 0x0400C8B4 RID: 51380
		private static readonly IntPtr NativeFieldInfoPtr_TrianglesCount;

		// Token: 0x0400C8B5 RID: 51381
		private static readonly IntPtr NativeFieldInfoPtr_OVR_AppCpuTime;

		// Token: 0x0400C8B6 RID: 51382
		private static readonly IntPtr NativeFieldInfoPtr_OVR_AppGpuTime;

		// Token: 0x0400C8B7 RID: 51383
		private static readonly IntPtr NativeFieldInfoPtr_OVR_DroppedFrameCount;

		// Token: 0x0400C8B8 RID: 51384
		private static readonly IntPtr NativeFieldInfoPtr_OVR_GpuUtilPercentage;

		// Token: 0x0400C8B9 RID: 51385
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
