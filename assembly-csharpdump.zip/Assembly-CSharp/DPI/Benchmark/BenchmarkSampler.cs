﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Unity.Profiling;

namespace DPI.Benchmark
{
	// Token: 0x02000FFF RID: 4095
	public class BenchmarkSampler : Object
	{
		// Token: 0x060139AC RID: 80300 RVA: 0x004EEE28 File Offset: 0x004ED028
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139AD RID: 80301 RVA: 0x004EEE6C File Offset: 0x004ED06C
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139AE RID: 80302 RVA: 0x004EEEB0 File Offset: 0x004ED0B0
		[CallerCount(0)]
		public unsafe void Sample(SerializedBenchmarkSample sample)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(sample);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr_Sample_Public_Void_SerializedBenchmarkSample_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139AF RID: 80303 RVA: 0x004EEF0C File Offset: 0x004ED10C
		[CallerCount(0)]
		public unsafe double GetRecorderFrameAverage(ProfilerRecorder recorder)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref recorder;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr_GetRecorderFrameAverage_Private_Double_ProfilerRecorder_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060139B0 RID: 80304 RVA: 0x004EEF70 File Offset: 0x004ED170
		[CallerCount(0)]
		public unsafe void AddRecorder(ProfilerCategory category, string statName, int capacity)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref category;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(statName);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref capacity;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr_AddRecorder_Private_Void_ProfilerCategory_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139B1 RID: 80305 RVA: 0x004EEFF0 File Offset: 0x004ED1F0
		[CallerCount(0)]
		public unsafe BenchmarkSampler() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkSampler.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139B2 RID: 80306 RVA: 0x004EF03C File Offset: 0x004ED23C
		// Note: this type is marked as 'beforefieldinit'.
		static BenchmarkSampler()
		{
			Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "BenchmarkSampler");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr);
			BenchmarkSampler.NativeFieldInfoPtr__recorders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, "_recorders");
			BenchmarkSampler.NativeFieldInfoPtr_statNames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, "statNames");
			BenchmarkSampler.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688326);
			BenchmarkSampler.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688327);
			BenchmarkSampler.NativeMethodInfoPtr_Sample_Public_Void_SerializedBenchmarkSample_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688328);
			BenchmarkSampler.NativeMethodInfoPtr_GetRecorderFrameAverage_Private_Double_ProfilerRecorder_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688329);
			BenchmarkSampler.NativeMethodInfoPtr_AddRecorder_Private_Void_ProfilerCategory_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688330);
			BenchmarkSampler.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr, 100688331);
		}

		// Token: 0x060139B3 RID: 80307 RVA: 0x00002988 File Offset: 0x00000B88
		public BenchmarkSampler(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006F2D RID: 28461
		// (get) Token: 0x060139B4 RID: 80308 RVA: 0x004EF10C File Offset: 0x004ED30C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkSampler>.NativeClassPtr));
			}
		}

		// Token: 0x17006F2E RID: 28462
		// (get) Token: 0x060139B5 RID: 80309 RVA: 0x004EF120 File Offset: 0x004ED320
		// (set) Token: 0x060139B6 RID: 80310 RVA: 0x004EF154 File Offset: 0x004ED354
		public unsafe List<ProfilerRecorder> _recorders
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSampler.NativeFieldInfoPtr__recorders);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<ProfilerRecorder>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkSampler.NativeFieldInfoPtr__recorders), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006F2F RID: 28463
		// (get) Token: 0x060139B7 RID: 80311 RVA: 0x004EF17C File Offset: 0x004ED37C
		// (set) Token: 0x060139B8 RID: 80312 RVA: 0x004EF1A7 File Offset: 0x004ED3A7
		public unsafe static Il2CppStringArray statNames
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BenchmarkSampler.NativeFieldInfoPtr_statNames, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BenchmarkSampler.NativeFieldInfoPtr_statNames, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C888 RID: 51336
		private static readonly IntPtr NativeFieldInfoPtr__recorders;

		// Token: 0x0400C889 RID: 51337
		private static readonly IntPtr NativeFieldInfoPtr_statNames;

		// Token: 0x0400C88A RID: 51338
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

		// Token: 0x0400C88B RID: 51339
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400C88C RID: 51340
		private static readonly IntPtr NativeMethodInfoPtr_Sample_Public_Void_SerializedBenchmarkSample_0;

		// Token: 0x0400C88D RID: 51341
		private static readonly IntPtr NativeMethodInfoPtr_GetRecorderFrameAverage_Private_Double_ProfilerRecorder_0;

		// Token: 0x0400C88E RID: 51342
		private static readonly IntPtr NativeMethodInfoPtr_AddRecorder_Private_Void_ProfilerCategory_String_Int32_0;

		// Token: 0x0400C88F RID: 51343
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001000 RID: 4096
		public enum RecorderType
		{
			// Token: 0x0400C891 RID: 51345
			MainThread,
			// Token: 0x0400C892 RID: 51346
			DrawCallsCount,
			// Token: 0x0400C893 RID: 51347
			SetPassCallsCount,
			// Token: 0x0400C894 RID: 51348
			VerticesCount,
			// Token: 0x0400C895 RID: 51349
			TrianglesCount
		}
	}
}
