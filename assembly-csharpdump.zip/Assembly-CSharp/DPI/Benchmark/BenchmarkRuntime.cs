﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using Onward.Scenes;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;

namespace DPI.Benchmark
{
	// Token: 0x02000FF9 RID: 4089
	public class BenchmarkRuntime : MonoBehaviour
	{
		// Token: 0x17006EFC RID: 28412
		// (get) Token: 0x0601392A RID: 80170 RVA: 0x004ECF10 File Offset: 0x004EB110
		public unsafe static string _persistentPath
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_get__persistentPath_Private_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x0601392B RID: 80171 RVA: 0x004ECF4C File Offset: 0x004EB14C
		[CallerCount(0)]
		public unsafe static bool IsBenchmarkBuild()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_IsBenchmarkBuild_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601392C RID: 80172 RVA: 0x004ECF90 File Offset: 0x004EB190
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601392D RID: 80173 RVA: 0x004ECFC4 File Offset: 0x004EB1C4
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601392E RID: 80174 RVA: 0x004ED008 File Offset: 0x004EB208
		[CallerCount(0)]
		public unsafe IEnumerator Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_Start_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0601392F RID: 80175 RVA: 0x004ED060 File Offset: 0x004EB260
		[CallerCount(0)]
		public unsafe static bool ValidatePointOnNavMesh(Vector3 safePoint, ref Vector3 point)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref safePoint;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &point;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_ValidatePointOnNavMesh_Private_Static_Boolean_Vector3_byref_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013930 RID: 80176 RVA: 0x004ED0C8 File Offset: 0x004EB2C8
		[CallerCount(0)]
		public unsafe static List<BenchmarkSamplePoint> GenerateSamplingPoints(SceneData sceneData, int count)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(sceneData);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref count;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_GenerateSamplingPoints_Public_Static_List_1_BenchmarkSamplePoint_SceneData_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<BenchmarkSamplePoint>(intPtr2) : null;
		}

		// Token: 0x06013931 RID: 80177 RVA: 0x004ED13C File Offset: 0x004EB33C
		[CallerCount(0)]
		public unsafe IEnumerator PerformBenchmarkForOnwardMap(SerializedBenchmarkRoot serializedBenchmarkRoot, OnwardMap onwardMap, string benchmarkBaseDir)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(serializedBenchmarkRoot);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref onwardMap;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(benchmarkBaseDir);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_PerformBenchmarkForOnwardMap_Private_IEnumerator_SerializedBenchmarkRoot_OnwardMap_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06013932 RID: 80178 RVA: 0x004ED1D4 File Offset: 0x004EB3D4
		[CallerCount(0)]
		public unsafe IEnumerator LoadOnwardMap(OnwardMap onwardMap)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref onwardMap;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_LoadOnwardMap_Private_IEnumerator_OnwardMap_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06013933 RID: 80179 RVA: 0x004ED23C File Offset: 0x004EB43C
		[CallerCount(0)]
		public unsafe GameObject CreateCameraRig()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr_CreateCameraRig_Private_GameObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}

		// Token: 0x06013934 RID: 80180 RVA: 0x004ED294 File Offset: 0x004EB494
		[CallerCount(0)]
		public unsafe BenchmarkRuntime() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013935 RID: 80181 RVA: 0x004ED2E0 File Offset: 0x004EB4E0
		// Note: this type is marked as 'beforefieldinit'.
		static BenchmarkRuntime()
		{
			Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "BenchmarkRuntime");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr);
			BenchmarkRuntime.NativeFieldInfoPtr_BENCHMARKS_FOLDER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "BENCHMARKS_FOLDER");
			BenchmarkRuntime.NativeFieldInfoPtr__activeSceneData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "_activeSceneData");
			BenchmarkRuntime.NativeMethodInfoPtr_get__persistentPath_Private_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688291);
			BenchmarkRuntime.NativeMethodInfoPtr_IsBenchmarkBuild_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688292);
			BenchmarkRuntime.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688293);
			BenchmarkRuntime.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688294);
			BenchmarkRuntime.NativeMethodInfoPtr_Start_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688295);
			BenchmarkRuntime.NativeMethodInfoPtr_ValidatePointOnNavMesh_Private_Static_Boolean_Vector3_byref_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688296);
			BenchmarkRuntime.NativeMethodInfoPtr_GenerateSamplingPoints_Public_Static_List_1_BenchmarkSamplePoint_SceneData_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688297);
			BenchmarkRuntime.NativeMethodInfoPtr_PerformBenchmarkForOnwardMap_Private_IEnumerator_SerializedBenchmarkRoot_OnwardMap_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688298);
			BenchmarkRuntime.NativeMethodInfoPtr_LoadOnwardMap_Private_IEnumerator_OnwardMap_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688299);
			BenchmarkRuntime.NativeMethodInfoPtr_CreateCameraRig_Private_GameObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688300);
			BenchmarkRuntime.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, 100688301);
		}

		// Token: 0x06013936 RID: 80182 RVA: 0x0000210C File Offset: 0x0000030C
		public BenchmarkRuntime(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006EF9 RID: 28409
		// (get) Token: 0x06013937 RID: 80183 RVA: 0x004ED414 File Offset: 0x004EB614
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr));
			}
		}

		// Token: 0x17006EFA RID: 28410
		// (get) Token: 0x06013938 RID: 80184 RVA: 0x004ED428 File Offset: 0x004EB628
		// (set) Token: 0x06013939 RID: 80185 RVA: 0x004ED448 File Offset: 0x004EB648
		public unsafe static string BENCHMARKS_FOLDER
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(BenchmarkRuntime.NativeFieldInfoPtr_BENCHMARKS_FOLDER, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BenchmarkRuntime.NativeFieldInfoPtr_BENCHMARKS_FOLDER, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006EFB RID: 28411
		// (get) Token: 0x0601393A RID: 80186 RVA: 0x004ED460 File Offset: 0x004EB660
		// (set) Token: 0x0601393B RID: 80187 RVA: 0x004ED494 File Offset: 0x004EB694
		public unsafe SceneData _activeSceneData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime.NativeFieldInfoPtr__activeSceneData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new SceneData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime.NativeFieldInfoPtr__activeSceneData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C83F RID: 51263
		private static readonly IntPtr NativeFieldInfoPtr_BENCHMARKS_FOLDER;

		// Token: 0x0400C840 RID: 51264
		private static readonly IntPtr NativeFieldInfoPtr__activeSceneData;

		// Token: 0x0400C841 RID: 51265
		private static readonly IntPtr NativeMethodInfoPtr_get__persistentPath_Private_Static_get_String_0;

		// Token: 0x0400C842 RID: 51266
		private static readonly IntPtr NativeMethodInfoPtr_IsBenchmarkBuild_Public_Static_Boolean_0;

		// Token: 0x0400C843 RID: 51267
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400C844 RID: 51268
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400C845 RID: 51269
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_IEnumerator_0;

		// Token: 0x0400C846 RID: 51270
		private static readonly IntPtr NativeMethodInfoPtr_ValidatePointOnNavMesh_Private_Static_Boolean_Vector3_byref_Vector3_0;

		// Token: 0x0400C847 RID: 51271
		private static readonly IntPtr NativeMethodInfoPtr_GenerateSamplingPoints_Public_Static_List_1_BenchmarkSamplePoint_SceneData_Int32_0;

		// Token: 0x0400C848 RID: 51272
		private static readonly IntPtr NativeMethodInfoPtr_PerformBenchmarkForOnwardMap_Private_IEnumerator_SerializedBenchmarkRoot_OnwardMap_String_0;

		// Token: 0x0400C849 RID: 51273
		private static readonly IntPtr NativeMethodInfoPtr_LoadOnwardMap_Private_IEnumerator_OnwardMap_0;

		// Token: 0x0400C84A RID: 51274
		private static readonly IntPtr NativeMethodInfoPtr_CreateCameraRig_Private_GameObject_0;

		// Token: 0x0400C84B RID: 51275
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000FFA RID: 4090
		[ObfuscatedName("DPI.Benchmark.BenchmarkRuntime/<Start>d__7")]
		public sealed class _Start_d__7 : Il2CppSystem.Object
		{
			// Token: 0x0601393C RID: 80188 RVA: 0x004ED4BC File Offset: 0x004EB6BC
			[CallerCount(0)]
			public unsafe _Start_d__7(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601393D RID: 80189 RVA: 0x004ED51C File Offset: 0x004EB71C
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601393E RID: 80190 RVA: 0x004ED560 File Offset: 0x004EB760
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006F06 RID: 28422
			// (get) Token: 0x0601393F RID: 80191 RVA: 0x004ED5B0 File Offset: 0x004EB7B0
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013940 RID: 80192 RVA: 0x004ED608 File Offset: 0x004EB808
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006F07 RID: 28423
			// (get) Token: 0x06013941 RID: 80193 RVA: 0x004ED64C File Offset: 0x004EB84C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013942 RID: 80194 RVA: 0x004ED6A4 File Offset: 0x004EB8A4
			// Note: this type is marked as 'beforefieldinit'.
			static _Start_d__7()
			{
				Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "<Start>d__7");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr);
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<>1__state");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<>2__current");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<>4__this");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__benchmarkBaseDir_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<benchmarkBaseDir>5__2");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__serializedBenchmarkRoot_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<serializedBenchmarkRoot>5__3");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__startTime_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<startTime>5__4");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<>7__wrap4");
				BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, "<>7__wrap5");
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688302);
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688303);
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688304);
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688305);
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688306);
				BenchmarkRuntime._Start_d__7.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr, 100688307);
			}

			// Token: 0x06013943 RID: 80195 RVA: 0x00002988 File Offset: 0x00000B88
			public _Start_d__7(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006EFD RID: 28413
			// (get) Token: 0x06013944 RID: 80196 RVA: 0x004ED7E7 File Offset: 0x004EB9E7
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkRuntime._Start_d__7>.NativeClassPtr));
				}
			}

			// Token: 0x17006EFE RID: 28414
			// (get) Token: 0x06013945 RID: 80197 RVA: 0x004ED7F8 File Offset: 0x004EB9F8
			// (set) Token: 0x06013946 RID: 80198 RVA: 0x004ED820 File Offset: 0x004EBA20
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006EFF RID: 28415
			// (get) Token: 0x06013947 RID: 80199 RVA: 0x004ED844 File Offset: 0x004EBA44
			// (set) Token: 0x06013948 RID: 80200 RVA: 0x004ED878 File Offset: 0x004EBA78
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F00 RID: 28416
			// (get) Token: 0x06013949 RID: 80201 RVA: 0x004ED8A0 File Offset: 0x004EBAA0
			// (set) Token: 0x0601394A RID: 80202 RVA: 0x004ED8D4 File Offset: 0x004EBAD4
			public unsafe BenchmarkRuntime __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BenchmarkRuntime(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F01 RID: 28417
			// (get) Token: 0x0601394B RID: 80203 RVA: 0x004ED8FC File Offset: 0x004EBAFC
			// (set) Token: 0x0601394C RID: 80204 RVA: 0x004ED925 File Offset: 0x004EBB25
			public unsafe string _benchmarkBaseDir_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__benchmarkBaseDir_5__2);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__benchmarkBaseDir_5__2), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17006F02 RID: 28418
			// (get) Token: 0x0601394D RID: 80205 RVA: 0x004ED94C File Offset: 0x004EBB4C
			// (set) Token: 0x0601394E RID: 80206 RVA: 0x004ED980 File Offset: 0x004EBB80
			public unsafe SerializedBenchmarkRoot _serializedBenchmarkRoot_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__serializedBenchmarkRoot_5__3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new SerializedBenchmarkRoot(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__serializedBenchmarkRoot_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F03 RID: 28419
			// (get) Token: 0x0601394F RID: 80207 RVA: 0x004ED9A8 File Offset: 0x004EBBA8
			// (set) Token: 0x06013950 RID: 80208 RVA: 0x004ED9D0 File Offset: 0x004EBBD0
			public unsafe float _startTime_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__startTime_5__4);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr__startTime_5__4)) = value;
				}
			}

			// Token: 0x17006F04 RID: 28420
			// (get) Token: 0x06013951 RID: 80209 RVA: 0x004ED9F4 File Offset: 0x004EBBF4
			// (set) Token: 0x06013952 RID: 80210 RVA: 0x004EDA28 File Offset: 0x004EBC28
			public unsafe Il2CppStructArray<OnwardMap> __7__wrap4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<OnwardMap>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F05 RID: 28421
			// (get) Token: 0x06013953 RID: 80211 RVA: 0x004EDA50 File Offset: 0x004EBC50
			// (set) Token: 0x06013954 RID: 80212 RVA: 0x004EDA78 File Offset: 0x004EBC78
			public unsafe int __7__wrap5
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap5);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._Start_d__7.NativeFieldInfoPtr___7__wrap5)) = value;
				}
			}

			// Token: 0x0400C84C RID: 51276
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C84D RID: 51277
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C84E RID: 51278
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C84F RID: 51279
			private static readonly IntPtr NativeFieldInfoPtr__benchmarkBaseDir_5__2;

			// Token: 0x0400C850 RID: 51280
			private static readonly IntPtr NativeFieldInfoPtr__serializedBenchmarkRoot_5__3;

			// Token: 0x0400C851 RID: 51281
			private static readonly IntPtr NativeFieldInfoPtr__startTime_5__4;

			// Token: 0x0400C852 RID: 51282
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap4;

			// Token: 0x0400C853 RID: 51283
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap5;

			// Token: 0x0400C854 RID: 51284
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C855 RID: 51285
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C856 RID: 51286
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C857 RID: 51287
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C858 RID: 51288
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C859 RID: 51289
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}

		// Token: 0x02000FFB RID: 4091
		[ObfuscatedName("DPI.Benchmark.BenchmarkRuntime/<>c")]
		[Serializable]
		public sealed class __c : Il2CppSystem.Object
		{
			// Token: 0x06013955 RID: 80213 RVA: 0x004EDA9C File Offset: 0x004EBC9C
			[CallerCount(0)]
			public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013956 RID: 80214 RVA: 0x004EDAE8 File Offset: 0x004EBCE8
			[CallerCount(0)]
			public unsafe bool _GenerateSamplingPoints_b__9_0(GameVariantSpawnData variant)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(variant);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime.__c.NativeMethodInfoPtr__GenerateSamplingPoints_b__9_0_Internal_Boolean_GameVariantSpawnData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06013957 RID: 80215 RVA: 0x004EDB50 File Offset: 0x004EBD50
			// Note: this type is marked as 'beforefieldinit'.
			static __c()
			{
				Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "<>c");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr);
				BenchmarkRuntime.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr, "<>9");
				BenchmarkRuntime.__c.NativeFieldInfoPtr___9__9_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr, "<>9__9_0");
				BenchmarkRuntime.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr, 100688309);
				BenchmarkRuntime.__c.NativeMethodInfoPtr__GenerateSamplingPoints_b__9_0_Internal_Boolean_GameVariantSpawnData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr, 100688310);
			}

			// Token: 0x06013958 RID: 80216 RVA: 0x00002988 File Offset: 0x00000B88
			public __c(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006F08 RID: 28424
			// (get) Token: 0x06013959 RID: 80217 RVA: 0x004EDBCB File Offset: 0x004EBDCB
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkRuntime.__c>.NativeClassPtr));
				}
			}

			// Token: 0x17006F09 RID: 28425
			// (get) Token: 0x0601395A RID: 80218 RVA: 0x004EDBDC File Offset: 0x004EBDDC
			// (set) Token: 0x0601395B RID: 80219 RVA: 0x004EDC07 File Offset: 0x004EBE07
			public unsafe static BenchmarkRuntime.__c __9
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(BenchmarkRuntime.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new BenchmarkRuntime.__c(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(BenchmarkRuntime.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F0A RID: 28426
			// (get) Token: 0x0601395C RID: 80220 RVA: 0x004EDC1C File Offset: 0x004EBE1C
			// (set) Token: 0x0601395D RID: 80221 RVA: 0x004EDC47 File Offset: 0x004EBE47
			public unsafe static Func<GameVariantSpawnData, bool> __9__9_0
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(BenchmarkRuntime.__c.NativeFieldInfoPtr___9__9_0, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<GameVariantSpawnData, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(BenchmarkRuntime.__c.NativeFieldInfoPtr___9__9_0, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C85A RID: 51290
			private static readonly IntPtr NativeFieldInfoPtr___9;

			// Token: 0x0400C85B RID: 51291
			private static readonly IntPtr NativeFieldInfoPtr___9__9_0;

			// Token: 0x0400C85C RID: 51292
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400C85D RID: 51293
			private static readonly IntPtr NativeMethodInfoPtr__GenerateSamplingPoints_b__9_0_Internal_Boolean_GameVariantSpawnData_0;
		}

		// Token: 0x02000FFC RID: 4092
		[ObfuscatedName("DPI.Benchmark.BenchmarkRuntime/<PerformBenchmarkForOnwardMap>d__10")]
		public sealed class _PerformBenchmarkForOnwardMap_d__10 : Il2CppSystem.Object
		{
			// Token: 0x0601395E RID: 80222 RVA: 0x004EDC5C File Offset: 0x004EBE5C
			[CallerCount(0)]
			public unsafe _PerformBenchmarkForOnwardMap_d__10(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601395F RID: 80223 RVA: 0x004EDCBC File Offset: 0x004EBEBC
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013960 RID: 80224 RVA: 0x004EDD00 File Offset: 0x004EBF00
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006F1C RID: 28444
			// (get) Token: 0x06013961 RID: 80225 RVA: 0x004EDD50 File Offset: 0x004EBF50
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013962 RID: 80226 RVA: 0x004EDDA8 File Offset: 0x004EBFA8
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006F1D RID: 28445
			// (get) Token: 0x06013963 RID: 80227 RVA: 0x004EDDEC File Offset: 0x004EBFEC
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013964 RID: 80228 RVA: 0x004EDE44 File Offset: 0x004EC044
			// Note: this type is marked as 'beforefieldinit'.
			static _PerformBenchmarkForOnwardMap_d__10()
			{
				Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "<PerformBenchmarkForOnwardMap>d__10");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<>1__state");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<>2__current");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<>4__this");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_onwardMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "onwardMap");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_serializedBenchmarkRoot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "serializedBenchmarkRoot");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_benchmarkBaseDir = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "benchmarkBaseDir");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__startLoadTime_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<startLoadTime>5__2");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__endLoadTime_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<endLoadTime>5__3");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cameraRig_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<cameraRig>5__4");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cam_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<cam>5__5");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkMap_5__6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<serializedBenchmarkMap>5__6");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__samplePoints_5__7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<samplePoints>5__7");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__benchmarkSampler_5__8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<benchmarkSampler>5__8");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__indexSamplePoint_5__9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<indexSamplePoint>5__9");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__imageName_5__10 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<imageName>5__10");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkSample_5__11 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, "<serializedBenchmarkSample>5__11");
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688311);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688312);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688313);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688314);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688315);
				BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr, 100688316);
			}

			// Token: 0x06013965 RID: 80229 RVA: 0x00002988 File Offset: 0x00000B88
			public _PerformBenchmarkForOnwardMap_d__10(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006F0B RID: 28427
			// (get) Token: 0x06013966 RID: 80230 RVA: 0x004EE027 File Offset: 0x004EC227
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10>.NativeClassPtr));
				}
			}

			// Token: 0x17006F0C RID: 28428
			// (get) Token: 0x06013967 RID: 80231 RVA: 0x004EE038 File Offset: 0x004EC238
			// (set) Token: 0x06013968 RID: 80232 RVA: 0x004EE060 File Offset: 0x004EC260
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006F0D RID: 28429
			// (get) Token: 0x06013969 RID: 80233 RVA: 0x004EE084 File Offset: 0x004EC284
			// (set) Token: 0x0601396A RID: 80234 RVA: 0x004EE0B8 File Offset: 0x004EC2B8
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F0E RID: 28430
			// (get) Token: 0x0601396B RID: 80235 RVA: 0x004EE0E0 File Offset: 0x004EC2E0
			// (set) Token: 0x0601396C RID: 80236 RVA: 0x004EE114 File Offset: 0x004EC314
			public unsafe BenchmarkRuntime __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BenchmarkRuntime(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F0F RID: 28431
			// (get) Token: 0x0601396D RID: 80237 RVA: 0x004EE13C File Offset: 0x004EC33C
			// (set) Token: 0x0601396E RID: 80238 RVA: 0x004EE164 File Offset: 0x004EC364
			public unsafe OnwardMap onwardMap
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_onwardMap);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_onwardMap)) = value;
				}
			}

			// Token: 0x17006F10 RID: 28432
			// (get) Token: 0x0601396F RID: 80239 RVA: 0x004EE188 File Offset: 0x004EC388
			// (set) Token: 0x06013970 RID: 80240 RVA: 0x004EE1BC File Offset: 0x004EC3BC
			public unsafe SerializedBenchmarkRoot serializedBenchmarkRoot
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_serializedBenchmarkRoot);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new SerializedBenchmarkRoot(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_serializedBenchmarkRoot), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F11 RID: 28433
			// (get) Token: 0x06013971 RID: 80241 RVA: 0x004EE1E4 File Offset: 0x004EC3E4
			// (set) Token: 0x06013972 RID: 80242 RVA: 0x004EE20D File Offset: 0x004EC40D
			public unsafe string benchmarkBaseDir
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_benchmarkBaseDir);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr_benchmarkBaseDir), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17006F12 RID: 28434
			// (get) Token: 0x06013973 RID: 80243 RVA: 0x004EE234 File Offset: 0x004EC434
			// (set) Token: 0x06013974 RID: 80244 RVA: 0x004EE25C File Offset: 0x004EC45C
			public unsafe float _startLoadTime_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__startLoadTime_5__2);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__startLoadTime_5__2)) = value;
				}
			}

			// Token: 0x17006F13 RID: 28435
			// (get) Token: 0x06013975 RID: 80245 RVA: 0x004EE280 File Offset: 0x004EC480
			// (set) Token: 0x06013976 RID: 80246 RVA: 0x004EE2A8 File Offset: 0x004EC4A8
			public unsafe float _endLoadTime_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__endLoadTime_5__3);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__endLoadTime_5__3)) = value;
				}
			}

			// Token: 0x17006F14 RID: 28436
			// (get) Token: 0x06013977 RID: 80247 RVA: 0x004EE2CC File Offset: 0x004EC4CC
			// (set) Token: 0x06013978 RID: 80248 RVA: 0x004EE300 File Offset: 0x004EC500
			public unsafe GameObject _cameraRig_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cameraRig_5__4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cameraRig_5__4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F15 RID: 28437
			// (get) Token: 0x06013979 RID: 80249 RVA: 0x004EE328 File Offset: 0x004EC528
			// (set) Token: 0x0601397A RID: 80250 RVA: 0x004EE35C File Offset: 0x004EC55C
			public unsafe Camera _cam_5__5
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cam_5__5);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Camera(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__cam_5__5), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F16 RID: 28438
			// (get) Token: 0x0601397B RID: 80251 RVA: 0x004EE384 File Offset: 0x004EC584
			// (set) Token: 0x0601397C RID: 80252 RVA: 0x004EE3B8 File Offset: 0x004EC5B8
			public unsafe SerializedBenchmarkMap _serializedBenchmarkMap_5__6
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkMap_5__6);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new SerializedBenchmarkMap(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkMap_5__6), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F17 RID: 28439
			// (get) Token: 0x0601397D RID: 80253 RVA: 0x004EE3E0 File Offset: 0x004EC5E0
			// (set) Token: 0x0601397E RID: 80254 RVA: 0x004EE414 File Offset: 0x004EC614
			public unsafe List<BenchmarkSamplePoint> _samplePoints_5__7
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__samplePoints_5__7);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new List<BenchmarkSamplePoint>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__samplePoints_5__7), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F18 RID: 28440
			// (get) Token: 0x0601397F RID: 80255 RVA: 0x004EE43C File Offset: 0x004EC63C
			// (set) Token: 0x06013980 RID: 80256 RVA: 0x004EE470 File Offset: 0x004EC670
			public unsafe BenchmarkSampler _benchmarkSampler_5__8
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__benchmarkSampler_5__8);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BenchmarkSampler(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__benchmarkSampler_5__8), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F19 RID: 28441
			// (get) Token: 0x06013981 RID: 80257 RVA: 0x004EE498 File Offset: 0x004EC698
			// (set) Token: 0x06013982 RID: 80258 RVA: 0x004EE4C0 File Offset: 0x004EC6C0
			public unsafe int _indexSamplePoint_5__9
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__indexSamplePoint_5__9);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__indexSamplePoint_5__9)) = value;
				}
			}

			// Token: 0x17006F1A RID: 28442
			// (get) Token: 0x06013983 RID: 80259 RVA: 0x004EE4E4 File Offset: 0x004EC6E4
			// (set) Token: 0x06013984 RID: 80260 RVA: 0x004EE50D File Offset: 0x004EC70D
			public unsafe string _imageName_5__10
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__imageName_5__10);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__imageName_5__10), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17006F1B RID: 28443
			// (get) Token: 0x06013985 RID: 80261 RVA: 0x004EE534 File Offset: 0x004EC734
			// (set) Token: 0x06013986 RID: 80262 RVA: 0x004EE568 File Offset: 0x004EC768
			public unsafe SerializedBenchmarkSample _serializedBenchmarkSample_5__11
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkSample_5__11);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new SerializedBenchmarkSample(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._PerformBenchmarkForOnwardMap_d__10.NativeFieldInfoPtr__serializedBenchmarkSample_5__11), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C85E RID: 51294
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C85F RID: 51295
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C860 RID: 51296
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C861 RID: 51297
			private static readonly IntPtr NativeFieldInfoPtr_onwardMap;

			// Token: 0x0400C862 RID: 51298
			private static readonly IntPtr NativeFieldInfoPtr_serializedBenchmarkRoot;

			// Token: 0x0400C863 RID: 51299
			private static readonly IntPtr NativeFieldInfoPtr_benchmarkBaseDir;

			// Token: 0x0400C864 RID: 51300
			private static readonly IntPtr NativeFieldInfoPtr__startLoadTime_5__2;

			// Token: 0x0400C865 RID: 51301
			private static readonly IntPtr NativeFieldInfoPtr__endLoadTime_5__3;

			// Token: 0x0400C866 RID: 51302
			private static readonly IntPtr NativeFieldInfoPtr__cameraRig_5__4;

			// Token: 0x0400C867 RID: 51303
			private static readonly IntPtr NativeFieldInfoPtr__cam_5__5;

			// Token: 0x0400C868 RID: 51304
			private static readonly IntPtr NativeFieldInfoPtr__serializedBenchmarkMap_5__6;

			// Token: 0x0400C869 RID: 51305
			private static readonly IntPtr NativeFieldInfoPtr__samplePoints_5__7;

			// Token: 0x0400C86A RID: 51306
			private static readonly IntPtr NativeFieldInfoPtr__benchmarkSampler_5__8;

			// Token: 0x0400C86B RID: 51307
			private static readonly IntPtr NativeFieldInfoPtr__indexSamplePoint_5__9;

			// Token: 0x0400C86C RID: 51308
			private static readonly IntPtr NativeFieldInfoPtr__imageName_5__10;

			// Token: 0x0400C86D RID: 51309
			private static readonly IntPtr NativeFieldInfoPtr__serializedBenchmarkSample_5__11;

			// Token: 0x0400C86E RID: 51310
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C86F RID: 51311
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C870 RID: 51312
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C871 RID: 51313
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C872 RID: 51314
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C873 RID: 51315
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}

		// Token: 0x02000FFD RID: 4093
		[ObfuscatedName("DPI.Benchmark.BenchmarkRuntime/<LoadOnwardMap>d__11")]
		public sealed class _LoadOnwardMap_d__11 : Il2CppSystem.Object
		{
			// Token: 0x06013987 RID: 80263 RVA: 0x004EE590 File Offset: 0x004EC790
			[CallerCount(0)]
			public unsafe _LoadOnwardMap_d__11(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013988 RID: 80264 RVA: 0x004EE5F0 File Offset: 0x004EC7F0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013989 RID: 80265 RVA: 0x004EE634 File Offset: 0x004EC834
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006F24 RID: 28452
			// (get) Token: 0x0601398A RID: 80266 RVA: 0x004EE684 File Offset: 0x004EC884
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0601398B RID: 80267 RVA: 0x004EE6DC File Offset: 0x004EC8DC
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006F25 RID: 28453
			// (get) Token: 0x0601398C RID: 80268 RVA: 0x004EE720 File Offset: 0x004EC920
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0601398D RID: 80269 RVA: 0x004EE778 File Offset: 0x004EC978
			// Note: this type is marked as 'beforefieldinit'.
			static _LoadOnwardMap_d__11()
			{
				Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BenchmarkRuntime>.NativeClassPtr, "<LoadOnwardMap>d__11");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, "<>1__state");
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, "<>2__current");
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, "<>4__this");
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr_onwardMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, "onwardMap");
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr__sceneLoadOp_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, "<sceneLoadOp>5__2");
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688317);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688318);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688319);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688320);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688321);
				BenchmarkRuntime._LoadOnwardMap_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr, 100688322);
			}

			// Token: 0x0601398E RID: 80270 RVA: 0x00002988 File Offset: 0x00000B88
			public _LoadOnwardMap_d__11(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006F1E RID: 28446
			// (get) Token: 0x0601398F RID: 80271 RVA: 0x004EE87F File Offset: 0x004ECA7F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BenchmarkRuntime._LoadOnwardMap_d__11>.NativeClassPtr));
				}
			}

			// Token: 0x17006F1F RID: 28447
			// (get) Token: 0x06013990 RID: 80272 RVA: 0x004EE890 File Offset: 0x004ECA90
			// (set) Token: 0x06013991 RID: 80273 RVA: 0x004EE8B8 File Offset: 0x004ECAB8
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006F20 RID: 28448
			// (get) Token: 0x06013992 RID: 80274 RVA: 0x004EE8DC File Offset: 0x004ECADC
			// (set) Token: 0x06013993 RID: 80275 RVA: 0x004EE910 File Offset: 0x004ECB10
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F21 RID: 28449
			// (get) Token: 0x06013994 RID: 80276 RVA: 0x004EE938 File Offset: 0x004ECB38
			// (set) Token: 0x06013995 RID: 80277 RVA: 0x004EE96C File Offset: 0x004ECB6C
			public unsafe BenchmarkRuntime __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BenchmarkRuntime(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006F22 RID: 28450
			// (get) Token: 0x06013996 RID: 80278 RVA: 0x004EE994 File Offset: 0x004ECB94
			// (set) Token: 0x06013997 RID: 80279 RVA: 0x004EE9BC File Offset: 0x004ECBBC
			public unsafe OnwardMap onwardMap
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr_onwardMap);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr_onwardMap)) = value;
				}
			}

			// Token: 0x17006F23 RID: 28451
			// (get) Token: 0x06013998 RID: 80280 RVA: 0x004EE9E0 File Offset: 0x004ECBE0
			// (set) Token: 0x06013999 RID: 80281 RVA: 0x004EEA12 File Offset: 0x004ECC12
			public AsyncOperationHandle<SceneInstance> _sceneLoadOp_5__2
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr__sceneLoadOp_5__2);
					return new AsyncOperationHandle<SceneInstance>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncOperationHandle<SceneInstance>>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BenchmarkRuntime._LoadOnwardMap_d__11.NativeFieldInfoPtr__sceneLoadOp_5__2), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncOperationHandle<SceneInstance>>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x0400C874 RID: 51316
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C875 RID: 51317
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C876 RID: 51318
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C877 RID: 51319
			private static readonly IntPtr NativeFieldInfoPtr_onwardMap;

			// Token: 0x0400C878 RID: 51320
			private static readonly IntPtr NativeFieldInfoPtr__sceneLoadOp_5__2;

			// Token: 0x0400C879 RID: 51321
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C87A RID: 51322
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C87B RID: 51323
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C87C RID: 51324
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C87D RID: 51325
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C87E RID: 51326
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
