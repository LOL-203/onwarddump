﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Benchmark
{
	// Token: 0x02001003 RID: 4099
	[Serializable]
	public class SerializedBenchmarkRoot : Object
	{
		// Token: 0x060139CC RID: 80332 RVA: 0x004EF590 File Offset: 0x004ED790
		[CallerCount(0)]
		public unsafe SerializedBenchmarkRoot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializedBenchmarkRoot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060139CD RID: 80333 RVA: 0x004EF5DC File Offset: 0x004ED7DC
		// Note: this type is marked as 'beforefieldinit'.
		static SerializedBenchmarkRoot()
		{
			Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Benchmark", "SerializedBenchmarkRoot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr);
			SerializedBenchmarkRoot.NativeFieldInfoPtr_BuildVersion = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "BuildVersion");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_Time = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "Time");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_Platform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "Platform");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_GraphicsAPI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "GraphicsAPI");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_GUID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "GUID");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_RuntimeSeconds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "RuntimeSeconds");
			SerializedBenchmarkRoot.NativeFieldInfoPtr_Maps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, "Maps");
			SerializedBenchmarkRoot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr, 100688339);
		}

		// Token: 0x060139CE RID: 80334 RVA: 0x00002988 File Offset: 0x00000B88
		public SerializedBenchmarkRoot(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006F38 RID: 28472
		// (get) Token: 0x060139CF RID: 80335 RVA: 0x004EF6AC File Offset: 0x004ED8AC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SerializedBenchmarkRoot>.NativeClassPtr));
			}
		}

		// Token: 0x17006F39 RID: 28473
		// (get) Token: 0x060139D0 RID: 80336 RVA: 0x004EF6C0 File Offset: 0x004ED8C0
		// (set) Token: 0x060139D1 RID: 80337 RVA: 0x004EF6E9 File Offset: 0x004ED8E9
		public unsafe string BuildVersion
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_BuildVersion);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_BuildVersion), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F3A RID: 28474
		// (get) Token: 0x060139D2 RID: 80338 RVA: 0x004EF710 File Offset: 0x004ED910
		// (set) Token: 0x060139D3 RID: 80339 RVA: 0x004EF739 File Offset: 0x004ED939
		public unsafe string Time
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Time);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Time), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F3B RID: 28475
		// (get) Token: 0x060139D4 RID: 80340 RVA: 0x004EF760 File Offset: 0x004ED960
		// (set) Token: 0x060139D5 RID: 80341 RVA: 0x004EF789 File Offset: 0x004ED989
		public unsafe string Platform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Platform);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Platform), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F3C RID: 28476
		// (get) Token: 0x060139D6 RID: 80342 RVA: 0x004EF7B0 File Offset: 0x004ED9B0
		// (set) Token: 0x060139D7 RID: 80343 RVA: 0x004EF7D9 File Offset: 0x004ED9D9
		public unsafe string GraphicsAPI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_GraphicsAPI);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_GraphicsAPI), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F3D RID: 28477
		// (get) Token: 0x060139D8 RID: 80344 RVA: 0x004EF800 File Offset: 0x004EDA00
		// (set) Token: 0x060139D9 RID: 80345 RVA: 0x004EF829 File Offset: 0x004EDA29
		public unsafe string GUID
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_GUID);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_GUID), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17006F3E RID: 28478
		// (get) Token: 0x060139DA RID: 80346 RVA: 0x004EF850 File Offset: 0x004EDA50
		// (set) Token: 0x060139DB RID: 80347 RVA: 0x004EF878 File Offset: 0x004EDA78
		public unsafe float RuntimeSeconds
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_RuntimeSeconds);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_RuntimeSeconds)) = value;
			}
		}

		// Token: 0x17006F3F RID: 28479
		// (get) Token: 0x060139DC RID: 80348 RVA: 0x004EF89C File Offset: 0x004EDA9C
		// (set) Token: 0x060139DD RID: 80349 RVA: 0x004EF8D0 File Offset: 0x004EDAD0
		public unsafe List<SerializedBenchmarkMap> Maps
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Maps);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<SerializedBenchmarkMap>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedBenchmarkRoot.NativeFieldInfoPtr_Maps), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C89E RID: 51358
		private static readonly IntPtr NativeFieldInfoPtr_BuildVersion;

		// Token: 0x0400C89F RID: 51359
		private static readonly IntPtr NativeFieldInfoPtr_Time;

		// Token: 0x0400C8A0 RID: 51360
		private static readonly IntPtr NativeFieldInfoPtr_Platform;

		// Token: 0x0400C8A1 RID: 51361
		private static readonly IntPtr NativeFieldInfoPtr_GraphicsAPI;

		// Token: 0x0400C8A2 RID: 51362
		private static readonly IntPtr NativeFieldInfoPtr_GUID;

		// Token: 0x0400C8A3 RID: 51363
		private static readonly IntPtr NativeFieldInfoPtr_RuntimeSeconds;

		// Token: 0x0400C8A4 RID: 51364
		private static readonly IntPtr NativeFieldInfoPtr_Maps;

		// Token: 0x0400C8A5 RID: 51365
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
