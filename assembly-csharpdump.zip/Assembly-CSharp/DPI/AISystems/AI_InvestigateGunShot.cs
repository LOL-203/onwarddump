﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x0200116E RID: 4462
	public class AI_InvestigateGunShot : AIState
	{
		// Token: 0x06014C3E RID: 85054 RVA: 0x00539474 File Offset: 0x00537674
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateGunShot.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C3F RID: 85055 RVA: 0x005394C4 File Offset: 0x005376C4
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateGunShot.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C40 RID: 85056 RVA: 0x00539524 File Offset: 0x00537724
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateGunShot.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C41 RID: 85057 RVA: 0x00539574 File Offset: 0x00537774
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InvestigateGunShot.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C42 RID: 85058 RVA: 0x005395B8 File Offset: 0x005377B8
		[CallerCount(0)]
		public unsafe AI_InvestigateGunShot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InvestigateGunShot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C43 RID: 85059 RVA: 0x00539604 File Offset: 0x00537804
		// Note: this type is marked as 'beforefieldinit'.
		static AI_InvestigateGunShot()
		{
			Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_InvestigateGunShot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr);
			AI_InvestigateGunShot.NativeFieldInfoPtr_MinDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, "MinDistance");
			AI_InvestigateGunShot.NativeFieldInfoPtr_MaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, "MaxDistance");
			AI_InvestigateGunShot.NativeFieldInfoPtr_ChanceToTakeSafest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, "ChanceToTakeSafest");
			AI_InvestigateGunShot.NativeFieldInfoPtr__pathTarget = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, "_pathTarget");
			AI_InvestigateGunShot.NativeFieldInfoPtr__pathType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, "_pathType");
			AI_InvestigateGunShot.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, 100689788);
			AI_InvestigateGunShot.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, 100689789);
			AI_InvestigateGunShot.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, 100689790);
			AI_InvestigateGunShot.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, 100689791);
			AI_InvestigateGunShot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr, 100689792);
		}

		// Token: 0x06014C44 RID: 85060 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_InvestigateGunShot(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700757F RID: 30079
		// (get) Token: 0x06014C45 RID: 85061 RVA: 0x005396FC File Offset: 0x005378FC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_InvestigateGunShot>.NativeClassPtr));
			}
		}

		// Token: 0x17007580 RID: 30080
		// (get) Token: 0x06014C46 RID: 85062 RVA: 0x00539710 File Offset: 0x00537910
		// (set) Token: 0x06014C47 RID: 85063 RVA: 0x00539738 File Offset: 0x00537938
		public unsafe float MinDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_MinDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_MinDistance)) = value;
			}
		}

		// Token: 0x17007581 RID: 30081
		// (get) Token: 0x06014C48 RID: 85064 RVA: 0x0053975C File Offset: 0x0053795C
		// (set) Token: 0x06014C49 RID: 85065 RVA: 0x00539784 File Offset: 0x00537984
		public unsafe float MaxDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_MaxDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_MaxDistance)) = value;
			}
		}

		// Token: 0x17007582 RID: 30082
		// (get) Token: 0x06014C4A RID: 85066 RVA: 0x005397A8 File Offset: 0x005379A8
		// (set) Token: 0x06014C4B RID: 85067 RVA: 0x005397D0 File Offset: 0x005379D0
		public unsafe int ChanceToTakeSafest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_ChanceToTakeSafest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr_ChanceToTakeSafest)) = value;
			}
		}

		// Token: 0x17007583 RID: 30083
		// (get) Token: 0x06014C4C RID: 85068 RVA: 0x005397F4 File Offset: 0x005379F4
		// (set) Token: 0x06014C4D RID: 85069 RVA: 0x0053981C File Offset: 0x00537A1C
		public unsafe Vector3 _pathTarget
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr__pathTarget);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr__pathTarget)) = value;
			}
		}

		// Token: 0x17007584 RID: 30084
		// (get) Token: 0x06014C4E RID: 85070 RVA: 0x00539840 File Offset: 0x00537A40
		// (set) Token: 0x06014C4F RID: 85071 RVA: 0x00539868 File Offset: 0x00537A68
		public unsafe PathType _pathType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr__pathType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateGunShot.NativeFieldInfoPtr__pathType)) = value;
			}
		}

		// Token: 0x0400D440 RID: 54336
		private static readonly IntPtr NativeFieldInfoPtr_MinDistance;

		// Token: 0x0400D441 RID: 54337
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistance;

		// Token: 0x0400D442 RID: 54338
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToTakeSafest;

		// Token: 0x0400D443 RID: 54339
		private static readonly IntPtr NativeFieldInfoPtr__pathTarget;

		// Token: 0x0400D444 RID: 54340
		private static readonly IntPtr NativeFieldInfoPtr__pathType;

		// Token: 0x0400D445 RID: 54341
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D446 RID: 54342
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D447 RID: 54343
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D448 RID: 54344
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D449 RID: 54345
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
