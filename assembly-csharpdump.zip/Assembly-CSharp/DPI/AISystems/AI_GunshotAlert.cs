﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001168 RID: 4456
	public class AI_GunshotAlert : AIState
	{
		// Token: 0x06014BFB RID: 84987 RVA: 0x00538534 File Offset: 0x00536734
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GunshotAlert.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BFC RID: 84988 RVA: 0x00538584 File Offset: 0x00536784
		[CallerCount(0)]
		public unsafe AI_GunshotAlert() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GunshotAlert.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BFD RID: 84989 RVA: 0x005385D0 File Offset: 0x005367D0
		// Note: this type is marked as 'beforefieldinit'.
		static AI_GunshotAlert()
		{
			Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_GunshotAlert");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr);
			AI_GunshotAlert.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr, 100689767);
			AI_GunshotAlert.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr, 100689768);
		}

		// Token: 0x06014BFE RID: 84990 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_GunshotAlert(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700756B RID: 30059
		// (get) Token: 0x06014BFF RID: 84991 RVA: 0x00538628 File Offset: 0x00536828
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_GunshotAlert>.NativeClassPtr));
			}
		}

		// Token: 0x0400D41D RID: 54301
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D41E RID: 54302
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
