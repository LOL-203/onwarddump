﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001178 RID: 4472
	public class AI_ReactSuppression : AIState
	{
		// Token: 0x06014CCA RID: 85194 RVA: 0x0053B32C File Offset: 0x0053952C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactSuppression.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CCB RID: 85195 RVA: 0x0053B37C File Offset: 0x0053957C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactSuppression.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CCC RID: 85196 RVA: 0x0053B3DC File Offset: 0x005395DC
		[CallerCount(0)]
		public unsafe AI_ReactSuppression() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactSuppression.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CCD RID: 85197 RVA: 0x0053B428 File Offset: 0x00539628
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactSuppression()
		{
			Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactSuppression");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr);
			AI_ReactSuppression.NativeFieldInfoPtr_MinWaitTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, "MinWaitTime");
			AI_ReactSuppression.NativeFieldInfoPtr_MaxWaitTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, "MaxWaitTime");
			AI_ReactSuppression.NativeFieldInfoPtr_MinDistanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, "MinDistanceToThrowSmoke");
			AI_ReactSuppression.NativeFieldInfoPtr_ChanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, "ChanceToThrowSmoke");
			AI_ReactSuppression.NativeFieldInfoPtr__waitEndTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, "_waitEndTime");
			AI_ReactSuppression.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, 100689824);
			AI_ReactSuppression.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, 100689825);
			AI_ReactSuppression.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr, 100689826);
		}

		// Token: 0x06014CCE RID: 85198 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactSuppression(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075AE RID: 30126
		// (get) Token: 0x06014CCF RID: 85199 RVA: 0x0053B4F8 File Offset: 0x005396F8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactSuppression>.NativeClassPtr));
			}
		}

		// Token: 0x170075AF RID: 30127
		// (get) Token: 0x06014CD0 RID: 85200 RVA: 0x0053B50C File Offset: 0x0053970C
		// (set) Token: 0x06014CD1 RID: 85201 RVA: 0x0053B534 File Offset: 0x00539734
		public unsafe float MinWaitTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MinWaitTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MinWaitTime)) = value;
			}
		}

		// Token: 0x170075B0 RID: 30128
		// (get) Token: 0x06014CD2 RID: 85202 RVA: 0x0053B558 File Offset: 0x00539758
		// (set) Token: 0x06014CD3 RID: 85203 RVA: 0x0053B580 File Offset: 0x00539780
		public unsafe float MaxWaitTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MaxWaitTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MaxWaitTime)) = value;
			}
		}

		// Token: 0x170075B1 RID: 30129
		// (get) Token: 0x06014CD4 RID: 85204 RVA: 0x0053B5A4 File Offset: 0x005397A4
		// (set) Token: 0x06014CD5 RID: 85205 RVA: 0x0053B5CC File Offset: 0x005397CC
		public unsafe int MinDistanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MinDistanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_MinDistanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x170075B2 RID: 30130
		// (get) Token: 0x06014CD6 RID: 85206 RVA: 0x0053B5F0 File Offset: 0x005397F0
		// (set) Token: 0x06014CD7 RID: 85207 RVA: 0x0053B618 File Offset: 0x00539818
		public unsafe int ChanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_ChanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr_ChanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x170075B3 RID: 30131
		// (get) Token: 0x06014CD8 RID: 85208 RVA: 0x0053B63C File Offset: 0x0053983C
		// (set) Token: 0x06014CD9 RID: 85209 RVA: 0x0053B664 File Offset: 0x00539864
		public unsafe float _waitEndTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr__waitEndTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactSuppression.NativeFieldInfoPtr__waitEndTime)) = value;
			}
		}

		// Token: 0x0400D489 RID: 54409
		private static readonly IntPtr NativeFieldInfoPtr_MinWaitTime;

		// Token: 0x0400D48A RID: 54410
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaitTime;

		// Token: 0x0400D48B RID: 54411
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToThrowSmoke;

		// Token: 0x0400D48C RID: 54412
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowSmoke;

		// Token: 0x0400D48D RID: 54413
		private static readonly IntPtr NativeFieldInfoPtr__waitEndTime;

		// Token: 0x0400D48E RID: 54414
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D48F RID: 54415
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D490 RID: 54416
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
