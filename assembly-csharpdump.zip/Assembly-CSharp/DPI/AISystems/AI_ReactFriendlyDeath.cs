﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001176 RID: 4470
	public class AI_ReactFriendlyDeath : AIState
	{
		// Token: 0x06014CB1 RID: 85169 RVA: 0x0053ADF8 File Offset: 0x00538FF8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactFriendlyDeath.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CB2 RID: 85170 RVA: 0x0053AE48 File Offset: 0x00539048
		[CallerCount(0)]
		public unsafe AI_ReactFriendlyDeath() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactFriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CB3 RID: 85171 RVA: 0x0053AE94 File Offset: 0x00539094
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactFriendlyDeath()
		{
			Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactFriendlyDeath");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr);
			AI_ReactFriendlyDeath.NativeFieldInfoPtr_MinDistanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr, "MinDistanceToThrowSmoke");
			AI_ReactFriendlyDeath.NativeFieldInfoPtr_ChanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr, "ChanceToThrowSmoke");
			AI_ReactFriendlyDeath.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr, 100689819);
			AI_ReactFriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr, 100689820);
		}

		// Token: 0x06014CB4 RID: 85172 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactFriendlyDeath(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075A5 RID: 30117
		// (get) Token: 0x06014CB5 RID: 85173 RVA: 0x0053AF14 File Offset: 0x00539114
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactFriendlyDeath>.NativeClassPtr));
			}
		}

		// Token: 0x170075A6 RID: 30118
		// (get) Token: 0x06014CB6 RID: 85174 RVA: 0x0053AF28 File Offset: 0x00539128
		// (set) Token: 0x06014CB7 RID: 85175 RVA: 0x0053AF50 File Offset: 0x00539150
		public unsafe int MinDistanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeath.NativeFieldInfoPtr_MinDistanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeath.NativeFieldInfoPtr_MinDistanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x170075A7 RID: 30119
		// (get) Token: 0x06014CB8 RID: 85176 RVA: 0x0053AF74 File Offset: 0x00539174
		// (set) Token: 0x06014CB9 RID: 85177 RVA: 0x0053AF9C File Offset: 0x0053919C
		public unsafe int ChanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeath.NativeFieldInfoPtr_ChanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeath.NativeFieldInfoPtr_ChanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x0400D47D RID: 54397
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToThrowSmoke;

		// Token: 0x0400D47E RID: 54398
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowSmoke;

		// Token: 0x0400D47F RID: 54399
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D480 RID: 54400
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
