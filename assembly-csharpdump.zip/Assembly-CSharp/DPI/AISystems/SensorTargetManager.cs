﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001191 RID: 4497
	public class SensorTargetManager : Object
	{
		// Token: 0x06014E41 RID: 85569 RVA: 0x00540C44 File Offset: 0x0053EE44
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E42 RID: 85570 RVA: 0x00540C88 File Offset: 0x0053EE88
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E43 RID: 85571 RVA: 0x00540CCC File Offset: 0x0053EECC
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Update_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E44 RID: 85572 RVA: 0x00540D10 File Offset: 0x0053EF10
		[CallerCount(0)]
		public unsafe void Add(VisionTarget target)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Add_Public_Void_VisionTarget_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E45 RID: 85573 RVA: 0x00540D6C File Offset: 0x0053EF6C
		[CallerCount(0)]
		public unsafe void Remove(VisionTarget target)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Remove_Public_Void_VisionTarget_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E46 RID: 85574 RVA: 0x00540DC8 File Offset: 0x0053EFC8
		[CallerCount(0)]
		public unsafe void Clear()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_Clear_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E47 RID: 85575 RVA: 0x00540E0C File Offset: 0x0053F00C
		[CallerCount(0)]
		public unsafe List<SensorTargetManager.VisionTargetData> GetAllTargets()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_GetAllTargets_Public_List_1_VisionTargetData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<SensorTargetManager.VisionTargetData>(intPtr2) : null;
		}

		// Token: 0x06014E48 RID: 85576 RVA: 0x00540E64 File Offset: 0x0053F064
		[CallerCount(0)]
		public unsafe bool IsInitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr_IsInitialized_Public_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014E49 RID: 85577 RVA: 0x00540EB4 File Offset: 0x0053F0B4
		[CallerCount(0)]
		public unsafe SensorTargetManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E4A RID: 85578 RVA: 0x00540F00 File Offset: 0x0053F100
		// Note: this type is marked as 'beforefieldinit'.
		static SensorTargetManager()
		{
			Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "SensorTargetManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr);
			SensorTargetManager.NativeFieldInfoPtr__visionTargetDatas = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, "_visionTargetDatas");
			SensorTargetManager.NativeFieldInfoPtr__visionTargetToData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, "_visionTargetToData");
			SensorTargetManager.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689940);
			SensorTargetManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689941);
			SensorTargetManager.NativeMethodInfoPtr_Update_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689942);
			SensorTargetManager.NativeMethodInfoPtr_Add_Public_Void_VisionTarget_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689943);
			SensorTargetManager.NativeMethodInfoPtr_Remove_Public_Void_VisionTarget_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689944);
			SensorTargetManager.NativeMethodInfoPtr_Clear_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689945);
			SensorTargetManager.NativeMethodInfoPtr_GetAllTargets_Public_List_1_VisionTargetData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689946);
			SensorTargetManager.NativeMethodInfoPtr_IsInitialized_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689947);
			SensorTargetManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, 100689948);
		}

		// Token: 0x06014E4B RID: 85579 RVA: 0x00002988 File Offset: 0x00000B88
		public SensorTargetManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007629 RID: 30249
		// (get) Token: 0x06014E4C RID: 85580 RVA: 0x0054100C File Offset: 0x0053F20C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr));
			}
		}

		// Token: 0x1700762A RID: 30250
		// (get) Token: 0x06014E4D RID: 85581 RVA: 0x00541020 File Offset: 0x0053F220
		// (set) Token: 0x06014E4E RID: 85582 RVA: 0x00541054 File Offset: 0x0053F254
		public unsafe List<SensorTargetManager.VisionTargetData> _visionTargetDatas
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.NativeFieldInfoPtr__visionTargetDatas);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<SensorTargetManager.VisionTargetData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.NativeFieldInfoPtr__visionTargetDatas), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700762B RID: 30251
		// (get) Token: 0x06014E4F RID: 85583 RVA: 0x0054107C File Offset: 0x0053F27C
		// (set) Token: 0x06014E50 RID: 85584 RVA: 0x005410B0 File Offset: 0x0053F2B0
		public unsafe Dictionary<VisionTarget, SensorTargetManager.VisionTargetData> _visionTargetToData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.NativeFieldInfoPtr__visionTargetToData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<VisionTarget, SensorTargetManager.VisionTargetData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.NativeFieldInfoPtr__visionTargetToData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D559 RID: 54617
		private static readonly IntPtr NativeFieldInfoPtr__visionTargetDatas;

		// Token: 0x0400D55A RID: 54618
		private static readonly IntPtr NativeFieldInfoPtr__visionTargetToData;

		// Token: 0x0400D55B RID: 54619
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

		// Token: 0x0400D55C RID: 54620
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D55D RID: 54621
		private static readonly IntPtr NativeMethodInfoPtr_Update_Public_Void_0;

		// Token: 0x0400D55E RID: 54622
		private static readonly IntPtr NativeMethodInfoPtr_Add_Public_Void_VisionTarget_0;

		// Token: 0x0400D55F RID: 54623
		private static readonly IntPtr NativeMethodInfoPtr_Remove_Public_Void_VisionTarget_0;

		// Token: 0x0400D560 RID: 54624
		private static readonly IntPtr NativeMethodInfoPtr_Clear_Public_Void_0;

		// Token: 0x0400D561 RID: 54625
		private static readonly IntPtr NativeMethodInfoPtr_GetAllTargets_Public_List_1_VisionTargetData_0;

		// Token: 0x0400D562 RID: 54626
		private static readonly IntPtr NativeMethodInfoPtr_IsInitialized_Public_Boolean_0;

		// Token: 0x0400D563 RID: 54627
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001192 RID: 4498
		public class VisionTargetData : Object
		{
			// Token: 0x06014E51 RID: 85585 RVA: 0x005410D8 File Offset: 0x0053F2D8
			[CallerCount(0)]
			public unsafe VisionTargetData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SensorTargetManager.VisionTargetData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014E52 RID: 85586 RVA: 0x00541124 File Offset: 0x0053F324
			// Note: this type is marked as 'beforefieldinit'.
			static VisionTargetData()
			{
				Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<SensorTargetManager>.NativeClassPtr, "VisionTargetData");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr);
				SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr, "Target");
				SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_LastUpdate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr, "LastUpdate");
				SensorTargetManager.VisionTargetData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr, 100689949);
			}

			// Token: 0x06014E53 RID: 85587 RVA: 0x00002988 File Offset: 0x00000B88
			public VisionTargetData(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700762C RID: 30252
			// (get) Token: 0x06014E54 RID: 85588 RVA: 0x0054118B File Offset: 0x0053F38B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SensorTargetManager.VisionTargetData>.NativeClassPtr));
				}
			}

			// Token: 0x1700762D RID: 30253
			// (get) Token: 0x06014E55 RID: 85589 RVA: 0x0054119C File Offset: 0x0053F39C
			// (set) Token: 0x06014E56 RID: 85590 RVA: 0x005411D0 File Offset: 0x0053F3D0
			public unsafe VisionTarget Target
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_Target);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new VisionTarget(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x1700762E RID: 30254
			// (get) Token: 0x06014E57 RID: 85591 RVA: 0x005411F8 File Offset: 0x0053F3F8
			// (set) Token: 0x06014E58 RID: 85592 RVA: 0x00541220 File Offset: 0x0053F420
			public unsafe float LastUpdate
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_LastUpdate);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SensorTargetManager.VisionTargetData.NativeFieldInfoPtr_LastUpdate)) = value;
				}
			}

			// Token: 0x0400D564 RID: 54628
			private static readonly IntPtr NativeFieldInfoPtr_Target;

			// Token: 0x0400D565 RID: 54629
			private static readonly IntPtr NativeFieldInfoPtr_LastUpdate;

			// Token: 0x0400D566 RID: 54630
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}
	}
}
