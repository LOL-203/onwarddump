﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200115B RID: 4443
	public class AdditionalData : Object
	{
		// Token: 0x06014B32 RID: 84786 RVA: 0x00535830 File Offset: 0x00533A30
		[CallerCount(0)]
		public unsafe AdditionalData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AdditionalData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AdditionalData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B33 RID: 84787 RVA: 0x0053587B File Offset: 0x00533A7B
		// Note: this type is marked as 'beforefieldinit'.
		static AdditionalData()
		{
			Il2CppClassPointerStore<AdditionalData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AdditionalData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AdditionalData>.NativeClassPtr);
			AdditionalData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AdditionalData>.NativeClassPtr, 100689715);
		}

		// Token: 0x06014B34 RID: 84788 RVA: 0x00002988 File Offset: 0x00000B88
		public AdditionalData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007527 RID: 29991
		// (get) Token: 0x06014B35 RID: 84789 RVA: 0x005358B4 File Offset: 0x00533AB4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AdditionalData>.NativeClassPtr));
			}
		}

		// Token: 0x0400D3B2 RID: 54194
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
