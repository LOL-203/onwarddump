﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001175 RID: 4469
	public class AI_ReactFriendlyDeadBody : AIState
	{
		// Token: 0x06014CAA RID: 85162 RVA: 0x0053AC90 File Offset: 0x00538E90
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactFriendlyDeadBody.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CAB RID: 85163 RVA: 0x0053ACE0 File Offset: 0x00538EE0
		[CallerCount(0)]
		public unsafe AI_ReactFriendlyDeadBody() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactFriendlyDeadBody.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CAC RID: 85164 RVA: 0x0053AD2C File Offset: 0x00538F2C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactFriendlyDeadBody()
		{
			Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactFriendlyDeadBody");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr);
			AI_ReactFriendlyDeadBody.NativeFieldInfoPtr_ChanceToInvestigate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr, "ChanceToInvestigate");
			AI_ReactFriendlyDeadBody.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr, 100689817);
			AI_ReactFriendlyDeadBody.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr, 100689818);
		}

		// Token: 0x06014CAD RID: 85165 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactFriendlyDeadBody(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075A3 RID: 30115
		// (get) Token: 0x06014CAE RID: 85166 RVA: 0x0053AD98 File Offset: 0x00538F98
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactFriendlyDeadBody>.NativeClassPtr));
			}
		}

		// Token: 0x170075A4 RID: 30116
		// (get) Token: 0x06014CAF RID: 85167 RVA: 0x0053ADAC File Offset: 0x00538FAC
		// (set) Token: 0x06014CB0 RID: 85168 RVA: 0x0053ADD4 File Offset: 0x00538FD4
		public unsafe int ChanceToInvestigate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeadBody.NativeFieldInfoPtr_ChanceToInvestigate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFriendlyDeadBody.NativeFieldInfoPtr_ChanceToInvestigate)) = value;
			}
		}

		// Token: 0x0400D47A RID: 54394
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToInvestigate;

		// Token: 0x0400D47B RID: 54395
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D47C RID: 54396
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
