﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001181 RID: 4481
	public class AI_SuppressTarget : AIState
	{
		// Token: 0x06014D60 RID: 85344 RVA: 0x0053D490 File Offset: 0x0053B690
		[CallerCount(0)]
		public unsafe AI_SuppressTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_SuppressTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_SuppressTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D61 RID: 85345 RVA: 0x0053D4DB File Offset: 0x0053B6DB
		// Note: this type is marked as 'beforefieldinit'.
		static AI_SuppressTarget()
		{
			Il2CppClassPointerStore<AI_SuppressTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_SuppressTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_SuppressTarget>.NativeClassPtr);
			AI_SuppressTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SuppressTarget>.NativeClassPtr, 100689861);
		}

		// Token: 0x06014D62 RID: 85346 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_SuppressTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075E2 RID: 30178
		// (get) Token: 0x06014D63 RID: 85347 RVA: 0x0053D514 File Offset: 0x0053B714
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_SuppressTarget>.NativeClassPtr));
			}
		}

		// Token: 0x0400D4D9 RID: 54489
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
