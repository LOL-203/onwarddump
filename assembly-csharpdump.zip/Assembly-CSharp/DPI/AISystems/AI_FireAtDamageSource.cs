﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001161 RID: 4449
	public class AI_FireAtDamageSource : AI_ShootPosition
	{
		// Token: 0x06014B96 RID: 84886 RVA: 0x00536D28 File Offset: 0x00534F28
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FireAtDamageSource.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B97 RID: 84887 RVA: 0x00536D78 File Offset: 0x00534F78
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FireAtDamageSource.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B98 RID: 84888 RVA: 0x00536DC8 File Offset: 0x00534FC8
		[CallerCount(0)]
		public new unsafe Vector3 TargetRotationPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FireAtDamageSource.NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014B99 RID: 84889 RVA: 0x00536E24 File Offset: 0x00535024
		[CallerCount(0)]
		public new unsafe Vector3 TargetShootDirection()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FireAtDamageSource.NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014B9A RID: 84890 RVA: 0x00536E80 File Offset: 0x00535080
		[CallerCount(0)]
		public new unsafe void DoneShooting()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FireAtDamageSource.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B9B RID: 84891 RVA: 0x00536ED0 File Offset: 0x005350D0
		[CallerCount(0)]
		public unsafe AI_FireAtDamageSource() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_FireAtDamageSource.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B9C RID: 84892 RVA: 0x00536F1C File Offset: 0x0053511C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_FireAtDamageSource()
		{
			Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_FireAtDamageSource");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr);
			AI_FireAtDamageSource.NativeFieldInfoPtr_ChanceToFireAgainVsAdvanceInCover = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, "ChanceToFireAgainVsAdvanceInCover");
			AI_FireAtDamageSource.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689733);
			AI_FireAtDamageSource.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689734);
			AI_FireAtDamageSource.NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689735);
			AI_FireAtDamageSource.NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689736);
			AI_FireAtDamageSource.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689737);
			AI_FireAtDamageSource.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr, 100689738);
		}

		// Token: 0x06014B9D RID: 84893 RVA: 0x00536FD8 File Offset: 0x005351D8
		public AI_FireAtDamageSource(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700754D RID: 30029
		// (get) Token: 0x06014B9E RID: 84894 RVA: 0x00536FE1 File Offset: 0x005351E1
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_FireAtDamageSource>.NativeClassPtr));
			}
		}

		// Token: 0x1700754E RID: 30030
		// (get) Token: 0x06014B9F RID: 84895 RVA: 0x00536FF4 File Offset: 0x005351F4
		// (set) Token: 0x06014BA0 RID: 84896 RVA: 0x0053701C File Offset: 0x0053521C
		public unsafe int ChanceToFireAgainVsAdvanceInCover
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FireAtDamageSource.NativeFieldInfoPtr_ChanceToFireAgainVsAdvanceInCover);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FireAtDamageSource.NativeFieldInfoPtr_ChanceToFireAgainVsAdvanceInCover)) = value;
			}
		}

		// Token: 0x0400D3E4 RID: 54244
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToFireAgainVsAdvanceInCover;

		// Token: 0x0400D3E5 RID: 54245
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3E6 RID: 54246
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D3E7 RID: 54247
		private static readonly IntPtr NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_Vector3_0;

		// Token: 0x0400D3E8 RID: 54248
		private static readonly IntPtr NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_Vector3_0;

		// Token: 0x0400D3E9 RID: 54249
		private static readonly IntPtr NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0;

		// Token: 0x0400D3EA RID: 54250
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
