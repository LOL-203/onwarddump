﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001184 RID: 4484
	public class AI_TakeCoverFromGrenade : AIState
	{
		// Token: 0x06014D80 RID: 85376 RVA: 0x0053DC78 File Offset: 0x0053BE78
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D81 RID: 85377 RVA: 0x0053DCC8 File Offset: 0x0053BEC8
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFromGrenade.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D82 RID: 85378 RVA: 0x0053DD34 File Offset: 0x0053BF34
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D83 RID: 85379 RVA: 0x0053DD94 File Offset: 0x0053BF94
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D84 RID: 85380 RVA: 0x0053DDE4 File Offset: 0x0053BFE4
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFromGrenade.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D85 RID: 85381 RVA: 0x0053DE28 File Offset: 0x0053C028
		[CallerCount(0)]
		public unsafe AI_TakeCoverFromGrenade() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFromGrenade.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D86 RID: 85382 RVA: 0x0053DE74 File Offset: 0x0053C074
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCoverFromGrenade()
		{
			Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCoverFromGrenade");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr);
			AI_TakeCoverFromGrenade.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, "MaxCoverDistance");
			AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, "InCoverDurationMin");
			AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, "InCoverDurationMax");
			AI_TakeCoverFromGrenade.NativeFieldInfoPtr__inCover = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, "_inCover");
			AI_TakeCoverFromGrenade.NativeFieldInfoPtr__endCoverDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, "_endCoverDuration");
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689874);
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689875);
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689876);
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689877);
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689878);
			AI_TakeCoverFromGrenade.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr, 100689879);
		}

		// Token: 0x06014D87 RID: 85383 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCoverFromGrenade(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075EA RID: 30186
		// (get) Token: 0x06014D88 RID: 85384 RVA: 0x0053DF80 File Offset: 0x0053C180
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCoverFromGrenade>.NativeClassPtr));
			}
		}

		// Token: 0x170075EB RID: 30187
		// (get) Token: 0x06014D89 RID: 85385 RVA: 0x0053DF94 File Offset: 0x0053C194
		// (set) Token: 0x06014D8A RID: 85386 RVA: 0x0053DFBC File Offset: 0x0053C1BC
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x170075EC RID: 30188
		// (get) Token: 0x06014D8B RID: 85387 RVA: 0x0053DFE0 File Offset: 0x0053C1E0
		// (set) Token: 0x06014D8C RID: 85388 RVA: 0x0053E008 File Offset: 0x0053C208
		public unsafe float InCoverDurationMin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMin);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMin)) = value;
			}
		}

		// Token: 0x170075ED RID: 30189
		// (get) Token: 0x06014D8D RID: 85389 RVA: 0x0053E02C File Offset: 0x0053C22C
		// (set) Token: 0x06014D8E RID: 85390 RVA: 0x0053E054 File Offset: 0x0053C254
		public unsafe float InCoverDurationMax
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMax);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr_InCoverDurationMax)) = value;
			}
		}

		// Token: 0x170075EE RID: 30190
		// (get) Token: 0x06014D8F RID: 85391 RVA: 0x0053E078 File Offset: 0x0053C278
		// (set) Token: 0x06014D90 RID: 85392 RVA: 0x0053E0A0 File Offset: 0x0053C2A0
		public unsafe bool _inCover
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr__inCover);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr__inCover)) = value;
			}
		}

		// Token: 0x170075EF RID: 30191
		// (get) Token: 0x06014D91 RID: 85393 RVA: 0x0053E0C4 File Offset: 0x0053C2C4
		// (set) Token: 0x06014D92 RID: 85394 RVA: 0x0053E0EC File Offset: 0x0053C2EC
		public unsafe float _endCoverDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr__endCoverDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFromGrenade.NativeFieldInfoPtr__endCoverDuration)) = value;
			}
		}

		// Token: 0x0400D4EB RID: 54507
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D4EC RID: 54508
		private static readonly IntPtr NativeFieldInfoPtr_InCoverDurationMin;

		// Token: 0x0400D4ED RID: 54509
		private static readonly IntPtr NativeFieldInfoPtr_InCoverDurationMax;

		// Token: 0x0400D4EE RID: 54510
		private static readonly IntPtr NativeFieldInfoPtr__inCover;

		// Token: 0x0400D4EF RID: 54511
		private static readonly IntPtr NativeFieldInfoPtr__endCoverDuration;

		// Token: 0x0400D4F0 RID: 54512
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4F1 RID: 54513
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D4F2 RID: 54514
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D4F3 RID: 54515
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D4F4 RID: 54516
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D4F5 RID: 54517
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
