﻿using System;
using DPI.AISystems.Alerts;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001177 RID: 4471
	public class AI_ReactGunshot : AIState
	{
		// Token: 0x06014CBA RID: 85178 RVA: 0x0053AFC0 File Offset: 0x005391C0
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactGunshot.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CBB RID: 85179 RVA: 0x0053B010 File Offset: 0x00539210
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactGunshot.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CBC RID: 85180 RVA: 0x0053B070 File Offset: 0x00539270
		[CallerCount(0)]
		public unsafe AI_ReactGunshot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactGunshot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CBD RID: 85181 RVA: 0x0053B0BC File Offset: 0x005392BC
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactGunshot()
		{
			Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactGunshot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr);
			AI_ReactGunshot.NativeFieldInfoPtr_MinWaitTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, "MinWaitTime");
			AI_ReactGunshot.NativeFieldInfoPtr_MaxWaitTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, "MaxWaitTime");
			AI_ReactGunshot.NativeFieldInfoPtr_ChanceToInvestigate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, "ChanceToInvestigate");
			AI_ReactGunshot.NativeFieldInfoPtr__waitEndTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, "_waitEndTime");
			AI_ReactGunshot.NativeFieldInfoPtr__gunshotAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, "_gunshotAlert");
			AI_ReactGunshot.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, 100689821);
			AI_ReactGunshot.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, 100689822);
			AI_ReactGunshot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr, 100689823);
		}

		// Token: 0x06014CBE RID: 85182 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactGunshot(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075A8 RID: 30120
		// (get) Token: 0x06014CBF RID: 85183 RVA: 0x0053B18C File Offset: 0x0053938C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactGunshot>.NativeClassPtr));
			}
		}

		// Token: 0x170075A9 RID: 30121
		// (get) Token: 0x06014CC0 RID: 85184 RVA: 0x0053B1A0 File Offset: 0x005393A0
		// (set) Token: 0x06014CC1 RID: 85185 RVA: 0x0053B1C8 File Offset: 0x005393C8
		public unsafe float MinWaitTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_MinWaitTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_MinWaitTime)) = value;
			}
		}

		// Token: 0x170075AA RID: 30122
		// (get) Token: 0x06014CC2 RID: 85186 RVA: 0x0053B1EC File Offset: 0x005393EC
		// (set) Token: 0x06014CC3 RID: 85187 RVA: 0x0053B214 File Offset: 0x00539414
		public unsafe float MaxWaitTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_MaxWaitTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_MaxWaitTime)) = value;
			}
		}

		// Token: 0x170075AB RID: 30123
		// (get) Token: 0x06014CC4 RID: 85188 RVA: 0x0053B238 File Offset: 0x00539438
		// (set) Token: 0x06014CC5 RID: 85189 RVA: 0x0053B260 File Offset: 0x00539460
		public unsafe int ChanceToInvestigate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_ChanceToInvestigate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr_ChanceToInvestigate)) = value;
			}
		}

		// Token: 0x170075AC RID: 30124
		// (get) Token: 0x06014CC6 RID: 85190 RVA: 0x0053B284 File Offset: 0x00539484
		// (set) Token: 0x06014CC7 RID: 85191 RVA: 0x0053B2AC File Offset: 0x005394AC
		public unsafe float _waitEndTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr__waitEndTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr__waitEndTime)) = value;
			}
		}

		// Token: 0x170075AD RID: 30125
		// (get) Token: 0x06014CC8 RID: 85192 RVA: 0x0053B2D0 File Offset: 0x005394D0
		// (set) Token: 0x06014CC9 RID: 85193 RVA: 0x0053B304 File Offset: 0x00539504
		public unsafe AlertStruct _gunshotAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr__gunshotAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertStruct(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactGunshot.NativeFieldInfoPtr__gunshotAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D481 RID: 54401
		private static readonly IntPtr NativeFieldInfoPtr_MinWaitTime;

		// Token: 0x0400D482 RID: 54402
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaitTime;

		// Token: 0x0400D483 RID: 54403
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToInvestigate;

		// Token: 0x0400D484 RID: 54404
		private static readonly IntPtr NativeFieldInfoPtr__waitEndTime;

		// Token: 0x0400D485 RID: 54405
		private static readonly IntPtr NativeFieldInfoPtr__gunshotAlert;

		// Token: 0x0400D486 RID: 54406
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D487 RID: 54407
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D488 RID: 54408
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
