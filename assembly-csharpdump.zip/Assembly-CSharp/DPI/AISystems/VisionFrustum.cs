﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001193 RID: 4499
	[StructLayout(0)]
	public sealed class VisionFrustum : ValueType
	{
		// Token: 0x06014E59 RID: 85593 RVA: 0x00541244 File Offset: 0x0053F444
		[CallerCount(0)]
		public unsafe void Initialize(float minDist, float minWidth, float maxDist, float maxWidth, LayerMask layerMask, Transform parentTransform)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref minDist;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minWidth;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDist;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxWidth;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref layerMask;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(parentTransform);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionFrustum.NativeMethodInfoPtr_Initialize_Public_Void_Single_Single_Single_Single_LayerMask_Transform_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E5A RID: 85594 RVA: 0x005412FC File Offset: 0x0053F4FC
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionFrustum.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E5B RID: 85595 RVA: 0x0054133C File Offset: 0x0053F53C
		[CallerCount(0)]
		public unsafe void CheckTarget(Vector3 sightOrigin, VisionManager.TargetData target, Vector3 targetPos, SensorTargetManager targetManager)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref sightOrigin;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(target));
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPos;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(targetManager);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionFrustum.NativeMethodInfoPtr_CheckTarget_Public_Void_Vector3_TargetData_Vector3_SensorTargetManager_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E5C RID: 85596 RVA: 0x005413D8 File Offset: 0x0053F5D8
		[CallerCount(0)]
		public unsafe bool Contains(Vector3 targetPoint)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref targetPoint;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(VisionFrustum.NativeMethodInfoPtr_Contains_Private_Boolean_Vector3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014E5D RID: 85597 RVA: 0x00541438 File Offset: 0x0053F638
		// Note: this type is marked as 'beforefieldinit'.
		static VisionFrustum()
		{
			Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionFrustum");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr);
			VisionFrustum.NativeFieldInfoPtr__frustum = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_frustum");
			VisionFrustum.NativeFieldInfoPtr__layerMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_layerMask");
			VisionFrustum.NativeFieldInfoPtr__hasInit = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_hasInit");
			VisionFrustum.NativeFieldInfoPtr__minDis = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_minDis");
			VisionFrustum.NativeFieldInfoPtr__maxDis = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_maxDis");
			VisionFrustum.NativeFieldInfoPtr__minWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_minWidth");
			VisionFrustum.NativeFieldInfoPtr__minPosWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_minPosWidth");
			VisionFrustum.NativeFieldInfoPtr__maxWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_maxWidth");
			VisionFrustum.NativeFieldInfoPtr__inverted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_inverted");
			VisionFrustum.NativeFieldInfoPtr__parentTransform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_parentTransform");
			VisionFrustum.NativeFieldInfoPtr__visionCheckIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, "_visionCheckIndex");
			VisionFrustum.NativeMethodInfoPtr_Initialize_Public_Void_Single_Single_Single_Single_LayerMask_Transform_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, 100689950);
			VisionFrustum.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, 100689951);
			VisionFrustum.NativeMethodInfoPtr_CheckTarget_Public_Void_Vector3_TargetData_Vector3_SensorTargetManager_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, 100689952);
			VisionFrustum.NativeMethodInfoPtr_Contains_Private_Boolean_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, 100689953);
		}

		// Token: 0x06014E5E RID: 85598 RVA: 0x0002717B File Offset: 0x0002537B
		public VisionFrustum(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700762F RID: 30255
		// (get) Token: 0x06014E5F RID: 85599 RVA: 0x00541594 File Offset: 0x0053F794
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr));
			}
		}

		// Token: 0x06014E60 RID: 85600 RVA: 0x005415A8 File Offset: 0x0053F7A8
		public unsafe VisionFrustum()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<VisionFrustum>.NativeClassPtr, data));
		}

		// Token: 0x17007630 RID: 30256
		// (get) Token: 0x06014E61 RID: 85601 RVA: 0x005415D8 File Offset: 0x0053F7D8
		// (set) Token: 0x06014E62 RID: 85602 RVA: 0x0054160C File Offset: 0x0053F80C
		public unsafe Il2CppStructArray<Vector3> _frustum
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__frustum);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<Vector3>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__frustum), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007631 RID: 30257
		// (get) Token: 0x06014E63 RID: 85603 RVA: 0x00541634 File Offset: 0x0053F834
		// (set) Token: 0x06014E64 RID: 85604 RVA: 0x0054165C File Offset: 0x0053F85C
		public unsafe LayerMask _layerMask
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__layerMask);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__layerMask)) = value;
			}
		}

		// Token: 0x17007632 RID: 30258
		// (get) Token: 0x06014E65 RID: 85605 RVA: 0x00541680 File Offset: 0x0053F880
		// (set) Token: 0x06014E66 RID: 85606 RVA: 0x005416A8 File Offset: 0x0053F8A8
		public unsafe bool _hasInit
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__hasInit);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__hasInit)) = value;
			}
		}

		// Token: 0x17007633 RID: 30259
		// (get) Token: 0x06014E67 RID: 85607 RVA: 0x005416CC File Offset: 0x0053F8CC
		// (set) Token: 0x06014E68 RID: 85608 RVA: 0x005416F4 File Offset: 0x0053F8F4
		public unsafe float _minDis
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minDis);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minDis)) = value;
			}
		}

		// Token: 0x17007634 RID: 30260
		// (get) Token: 0x06014E69 RID: 85609 RVA: 0x00541718 File Offset: 0x0053F918
		// (set) Token: 0x06014E6A RID: 85610 RVA: 0x00541740 File Offset: 0x0053F940
		public unsafe float _maxDis
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__maxDis);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__maxDis)) = value;
			}
		}

		// Token: 0x17007635 RID: 30261
		// (get) Token: 0x06014E6B RID: 85611 RVA: 0x00541764 File Offset: 0x0053F964
		// (set) Token: 0x06014E6C RID: 85612 RVA: 0x0054178C File Offset: 0x0053F98C
		public unsafe float _minWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minWidth)) = value;
			}
		}

		// Token: 0x17007636 RID: 30262
		// (get) Token: 0x06014E6D RID: 85613 RVA: 0x005417B0 File Offset: 0x0053F9B0
		// (set) Token: 0x06014E6E RID: 85614 RVA: 0x005417D8 File Offset: 0x0053F9D8
		public unsafe float _minPosWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minPosWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__minPosWidth)) = value;
			}
		}

		// Token: 0x17007637 RID: 30263
		// (get) Token: 0x06014E6F RID: 85615 RVA: 0x005417FC File Offset: 0x0053F9FC
		// (set) Token: 0x06014E70 RID: 85616 RVA: 0x00541824 File Offset: 0x0053FA24
		public unsafe float _maxWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__maxWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__maxWidth)) = value;
			}
		}

		// Token: 0x17007638 RID: 30264
		// (get) Token: 0x06014E71 RID: 85617 RVA: 0x00541848 File Offset: 0x0053FA48
		// (set) Token: 0x06014E72 RID: 85618 RVA: 0x00541870 File Offset: 0x0053FA70
		public unsafe bool _inverted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__inverted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__inverted)) = value;
			}
		}

		// Token: 0x17007639 RID: 30265
		// (get) Token: 0x06014E73 RID: 85619 RVA: 0x00541894 File Offset: 0x0053FA94
		// (set) Token: 0x06014E74 RID: 85620 RVA: 0x005418C8 File Offset: 0x0053FAC8
		public unsafe Transform _parentTransform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__parentTransform);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__parentTransform), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700763A RID: 30266
		// (get) Token: 0x06014E75 RID: 85621 RVA: 0x005418F0 File Offset: 0x0053FAF0
		// (set) Token: 0x06014E76 RID: 85622 RVA: 0x00541918 File Offset: 0x0053FB18
		public unsafe int _visionCheckIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__visionCheckIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustum.NativeFieldInfoPtr__visionCheckIndex)) = value;
			}
		}

		// Token: 0x0400D567 RID: 54631
		private static readonly IntPtr NativeFieldInfoPtr__frustum;

		// Token: 0x0400D568 RID: 54632
		private static readonly IntPtr NativeFieldInfoPtr__layerMask;

		// Token: 0x0400D569 RID: 54633
		private static readonly IntPtr NativeFieldInfoPtr__hasInit;

		// Token: 0x0400D56A RID: 54634
		private static readonly IntPtr NativeFieldInfoPtr__minDis;

		// Token: 0x0400D56B RID: 54635
		private static readonly IntPtr NativeFieldInfoPtr__maxDis;

		// Token: 0x0400D56C RID: 54636
		private static readonly IntPtr NativeFieldInfoPtr__minWidth;

		// Token: 0x0400D56D RID: 54637
		private static readonly IntPtr NativeFieldInfoPtr__minPosWidth;

		// Token: 0x0400D56E RID: 54638
		private static readonly IntPtr NativeFieldInfoPtr__maxWidth;

		// Token: 0x0400D56F RID: 54639
		private static readonly IntPtr NativeFieldInfoPtr__inverted;

		// Token: 0x0400D570 RID: 54640
		private static readonly IntPtr NativeFieldInfoPtr__parentTransform;

		// Token: 0x0400D571 RID: 54641
		private static readonly IntPtr NativeFieldInfoPtr__visionCheckIndex;

		// Token: 0x0400D572 RID: 54642
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_Single_Single_Single_Single_LayerMask_Transform_0;

		// Token: 0x0400D573 RID: 54643
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D574 RID: 54644
		private static readonly IntPtr NativeMethodInfoPtr_CheckTarget_Public_Void_Vector3_TargetData_Vector3_SensorTargetManager_0;

		// Token: 0x0400D575 RID: 54645
		private static readonly IntPtr NativeMethodInfoPtr_Contains_Private_Boolean_Vector3_0;
	}
}
