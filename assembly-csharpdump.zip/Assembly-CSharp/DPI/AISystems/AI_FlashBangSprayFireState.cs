﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001163 RID: 4451
	public class AI_FlashBangSprayFireState : AIState
	{
		// Token: 0x06014BAD RID: 84909 RVA: 0x00537338 File Offset: 0x00535538
		[CallerCount(0)]
		public unsafe AI_FlashBangSprayFireState() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_FlashBangSprayFireState>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_FlashBangSprayFireState.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BAE RID: 84910 RVA: 0x00537383 File Offset: 0x00535583
		// Note: this type is marked as 'beforefieldinit'.
		static AI_FlashBangSprayFireState()
		{
			Il2CppClassPointerStore<AI_FlashBangSprayFireState>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_FlashBangSprayFireState");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_FlashBangSprayFireState>.NativeClassPtr);
			AI_FlashBangSprayFireState.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlashBangSprayFireState>.NativeClassPtr, 100689744);
		}

		// Token: 0x06014BAF RID: 84911 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_FlashBangSprayFireState(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007552 RID: 30034
		// (get) Token: 0x06014BB0 RID: 84912 RVA: 0x005373BC File Offset: 0x005355BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_FlashBangSprayFireState>.NativeClassPtr));
			}
		}

		// Token: 0x0400D3F2 RID: 54258
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
