﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200116A RID: 4458
	public class AI_InCover : AIState
	{
		// Token: 0x06014C0E RID: 85006 RVA: 0x00538940 File Offset: 0x00536B40
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C0F RID: 85007 RVA: 0x00538990 File Offset: 0x00536B90
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C10 RID: 85008 RVA: 0x005389E0 File Offset: 0x00536BE0
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C11 RID: 85009 RVA: 0x00538A40 File Offset: 0x00536C40
		[CallerCount(0)]
		public unsafe AI_InCover() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InCover.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C12 RID: 85010 RVA: 0x00538A8C File Offset: 0x00536C8C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_InCover()
		{
			Il2CppClassPointerStore<AI_InCover>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_InCover");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr);
			AI_InCover.NativeFieldInfoPtr_MinWaitInCoverTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, "MinWaitInCoverTime");
			AI_InCover.NativeFieldInfoPtr_MaxWaitInCoverTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, "MaxWaitInCoverTime");
			AI_InCover.NativeFieldInfoPtr__endTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, "_endTime");
			AI_InCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, 100689772);
			AI_InCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, 100689773);
			AI_InCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, 100689774);
			AI_InCover.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr, 100689775);
		}

		// Token: 0x06014C13 RID: 85011 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_InCover(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007571 RID: 30065
		// (get) Token: 0x06014C14 RID: 85012 RVA: 0x00538B48 File Offset: 0x00536D48
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_InCover>.NativeClassPtr));
			}
		}

		// Token: 0x17007572 RID: 30066
		// (get) Token: 0x06014C15 RID: 85013 RVA: 0x00538B5C File Offset: 0x00536D5C
		// (set) Token: 0x06014C16 RID: 85014 RVA: 0x00538B84 File Offset: 0x00536D84
		public unsafe float MinWaitInCoverTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr_MinWaitInCoverTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr_MinWaitInCoverTime)) = value;
			}
		}

		// Token: 0x17007573 RID: 30067
		// (get) Token: 0x06014C17 RID: 85015 RVA: 0x00538BA8 File Offset: 0x00536DA8
		// (set) Token: 0x06014C18 RID: 85016 RVA: 0x00538BD0 File Offset: 0x00536DD0
		public unsafe float MaxWaitInCoverTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr_MaxWaitInCoverTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr_MaxWaitInCoverTime)) = value;
			}
		}

		// Token: 0x17007574 RID: 30068
		// (get) Token: 0x06014C19 RID: 85017 RVA: 0x00538BF4 File Offset: 0x00536DF4
		// (set) Token: 0x06014C1A RID: 85018 RVA: 0x00538C1C File Offset: 0x00536E1C
		public unsafe float _endTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr__endTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCover.NativeFieldInfoPtr__endTime)) = value;
			}
		}

		// Token: 0x0400D426 RID: 54310
		private static readonly IntPtr NativeFieldInfoPtr_MinWaitInCoverTime;

		// Token: 0x0400D427 RID: 54311
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaitInCoverTime;

		// Token: 0x0400D428 RID: 54312
		private static readonly IntPtr NativeFieldInfoPtr__endTime;

		// Token: 0x0400D429 RID: 54313
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D42A RID: 54314
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D42B RID: 54315
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D42C RID: 54316
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
