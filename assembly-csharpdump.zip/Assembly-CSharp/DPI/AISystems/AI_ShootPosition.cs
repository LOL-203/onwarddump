﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x0200117E RID: 4478
	public class AI_ShootPosition : AIState
	{
		// Token: 0x06014D2F RID: 85295 RVA: 0x0053C934 File Offset: 0x0053AB34
		[CallerCount(0)]
		public new unsafe Vector3 GetStateDrivenLookPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014D30 RID: 85296 RVA: 0x0053C990 File Offset: 0x0053AB90
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D31 RID: 85297 RVA: 0x0053C9E0 File Offset: 0x0053ABE0
		[CallerCount(0)]
		public unsafe Vector3 TargetRotationPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_New_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014D32 RID: 85298 RVA: 0x0053CA3C File Offset: 0x0053AC3C
		[CallerCount(0)]
		public unsafe Vector3 TargetShootDirection()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_New_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014D33 RID: 85299 RVA: 0x0053CA98 File Offset: 0x0053AC98
		[CallerCount(0)]
		public new unsafe void Tick(float deltaTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref deltaTime;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D34 RID: 85300 RVA: 0x0053CAF8 File Offset: 0x0053ACF8
		[CallerCount(0)]
		public unsafe void LostTarget()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_LostTarget_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D35 RID: 85301 RVA: 0x0053CB48 File Offset: 0x0053AD48
		[CallerCount(0)]
		public unsafe void NeedToReload()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_NeedToReload_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D36 RID: 85302 RVA: 0x0053CB98 File Offset: 0x0053AD98
		[CallerCount(0)]
		public unsafe void DoneShooting()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootPosition.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D37 RID: 85303 RVA: 0x0053CBE8 File Offset: 0x0053ADE8
		[CallerCount(0)]
		public unsafe AI_ShootPosition() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ShootPosition.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D38 RID: 85304 RVA: 0x0053CC34 File Offset: 0x0053AE34
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ShootPosition()
		{
			Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ShootPosition");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr);
			AI_ShootPosition.NativeFieldInfoPtr_MinRotationTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MinRotationTime");
			AI_ShootPosition.NativeFieldInfoPtr_MaxRotationTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MaxRotationTime");
			AI_ShootPosition.NativeFieldInfoPtr_MinFireDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MinFireDelay");
			AI_ShootPosition.NativeFieldInfoPtr_MaxFireDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MaxFireDelay");
			AI_ShootPosition.NativeFieldInfoPtr_MinShotsToFire = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MinShotsToFire");
			AI_ShootPosition.NativeFieldInfoPtr_MaxShotsToFire = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "MaxShotsToFire");
			AI_ShootPosition.NativeFieldInfoPtr_ClearFireAngle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "ClearFireAngle");
			AI_ShootPosition.NativeFieldInfoPtr_ClearFrontRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "ClearFrontRange");
			AI_ShootPosition.NativeFieldInfoPtr__angleTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "_angleTimer");
			AI_ShootPosition.NativeFieldInfoPtr__fireDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "_fireDelay");
			AI_ShootPosition.NativeFieldInfoPtr__shotsToFire = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, "_shotsToFire");
			AI_ShootPosition.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689847);
			AI_ShootPosition.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689848);
			AI_ShootPosition.NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_New_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689849);
			AI_ShootPosition.NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_New_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689850);
			AI_ShootPosition.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689851);
			AI_ShootPosition.NativeMethodInfoPtr_LostTarget_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689852);
			AI_ShootPosition.NativeMethodInfoPtr_NeedToReload_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689853);
			AI_ShootPosition.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689854);
			AI_ShootPosition.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr, 100689855);
		}

		// Token: 0x06014D39 RID: 85305 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ShootPosition(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075D2 RID: 30162
		// (get) Token: 0x06014D3A RID: 85306 RVA: 0x0053CDF4 File Offset: 0x0053AFF4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ShootPosition>.NativeClassPtr));
			}
		}

		// Token: 0x170075D3 RID: 30163
		// (get) Token: 0x06014D3B RID: 85307 RVA: 0x0053CE08 File Offset: 0x0053B008
		// (set) Token: 0x06014D3C RID: 85308 RVA: 0x0053CE30 File Offset: 0x0053B030
		public unsafe float MinRotationTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinRotationTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinRotationTime)) = value;
			}
		}

		// Token: 0x170075D4 RID: 30164
		// (get) Token: 0x06014D3D RID: 85309 RVA: 0x0053CE54 File Offset: 0x0053B054
		// (set) Token: 0x06014D3E RID: 85310 RVA: 0x0053CE7C File Offset: 0x0053B07C
		public unsafe float MaxRotationTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxRotationTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxRotationTime)) = value;
			}
		}

		// Token: 0x170075D5 RID: 30165
		// (get) Token: 0x06014D3F RID: 85311 RVA: 0x0053CEA0 File Offset: 0x0053B0A0
		// (set) Token: 0x06014D40 RID: 85312 RVA: 0x0053CEC8 File Offset: 0x0053B0C8
		public unsafe float MinFireDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinFireDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinFireDelay)) = value;
			}
		}

		// Token: 0x170075D6 RID: 30166
		// (get) Token: 0x06014D41 RID: 85313 RVA: 0x0053CEEC File Offset: 0x0053B0EC
		// (set) Token: 0x06014D42 RID: 85314 RVA: 0x0053CF14 File Offset: 0x0053B114
		public unsafe float MaxFireDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxFireDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxFireDelay)) = value;
			}
		}

		// Token: 0x170075D7 RID: 30167
		// (get) Token: 0x06014D43 RID: 85315 RVA: 0x0053CF38 File Offset: 0x0053B138
		// (set) Token: 0x06014D44 RID: 85316 RVA: 0x0053CF60 File Offset: 0x0053B160
		public unsafe int MinShotsToFire
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinShotsToFire);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MinShotsToFire)) = value;
			}
		}

		// Token: 0x170075D8 RID: 30168
		// (get) Token: 0x06014D45 RID: 85317 RVA: 0x0053CF84 File Offset: 0x0053B184
		// (set) Token: 0x06014D46 RID: 85318 RVA: 0x0053CFAC File Offset: 0x0053B1AC
		public unsafe int MaxShotsToFire
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxShotsToFire);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_MaxShotsToFire)) = value;
			}
		}

		// Token: 0x170075D9 RID: 30169
		// (get) Token: 0x06014D47 RID: 85319 RVA: 0x0053CFD0 File Offset: 0x0053B1D0
		// (set) Token: 0x06014D48 RID: 85320 RVA: 0x0053CFF8 File Offset: 0x0053B1F8
		public unsafe float ClearFireAngle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_ClearFireAngle);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_ClearFireAngle)) = value;
			}
		}

		// Token: 0x170075DA RID: 30170
		// (get) Token: 0x06014D49 RID: 85321 RVA: 0x0053D01C File Offset: 0x0053B21C
		// (set) Token: 0x06014D4A RID: 85322 RVA: 0x0053D044 File Offset: 0x0053B244
		public unsafe float ClearFrontRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_ClearFrontRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr_ClearFrontRange)) = value;
			}
		}

		// Token: 0x170075DB RID: 30171
		// (get) Token: 0x06014D4B RID: 85323 RVA: 0x0053D068 File Offset: 0x0053B268
		// (set) Token: 0x06014D4C RID: 85324 RVA: 0x0053D090 File Offset: 0x0053B290
		public unsafe float _angleTimer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__angleTimer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__angleTimer)) = value;
			}
		}

		// Token: 0x170075DC RID: 30172
		// (get) Token: 0x06014D4D RID: 85325 RVA: 0x0053D0B4 File Offset: 0x0053B2B4
		// (set) Token: 0x06014D4E RID: 85326 RVA: 0x0053D0DC File Offset: 0x0053B2DC
		public unsafe float _fireDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__fireDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__fireDelay)) = value;
			}
		}

		// Token: 0x170075DD RID: 30173
		// (get) Token: 0x06014D4F RID: 85327 RVA: 0x0053D100 File Offset: 0x0053B300
		// (set) Token: 0x06014D50 RID: 85328 RVA: 0x0053D128 File Offset: 0x0053B328
		public unsafe float _shotsToFire
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__shotsToFire);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootPosition.NativeFieldInfoPtr__shotsToFire)) = value;
			}
		}

		// Token: 0x0400D4BE RID: 54462
		private static readonly IntPtr NativeFieldInfoPtr_MinRotationTime;

		// Token: 0x0400D4BF RID: 54463
		private static readonly IntPtr NativeFieldInfoPtr_MaxRotationTime;

		// Token: 0x0400D4C0 RID: 54464
		private static readonly IntPtr NativeFieldInfoPtr_MinFireDelay;

		// Token: 0x0400D4C1 RID: 54465
		private static readonly IntPtr NativeFieldInfoPtr_MaxFireDelay;

		// Token: 0x0400D4C2 RID: 54466
		private static readonly IntPtr NativeFieldInfoPtr_MinShotsToFire;

		// Token: 0x0400D4C3 RID: 54467
		private static readonly IntPtr NativeFieldInfoPtr_MaxShotsToFire;

		// Token: 0x0400D4C4 RID: 54468
		private static readonly IntPtr NativeFieldInfoPtr_ClearFireAngle;

		// Token: 0x0400D4C5 RID: 54469
		private static readonly IntPtr NativeFieldInfoPtr_ClearFrontRange;

		// Token: 0x0400D4C6 RID: 54470
		private static readonly IntPtr NativeFieldInfoPtr__angleTimer;

		// Token: 0x0400D4C7 RID: 54471
		private static readonly IntPtr NativeFieldInfoPtr__fireDelay;

		// Token: 0x0400D4C8 RID: 54472
		private static readonly IntPtr NativeFieldInfoPtr__shotsToFire;

		// Token: 0x0400D4C9 RID: 54473
		private static readonly IntPtr NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0;

		// Token: 0x0400D4CA RID: 54474
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4CB RID: 54475
		private static readonly IntPtr NativeMethodInfoPtr_TargetRotationPosition_Public_Virtual_New_Vector3_0;

		// Token: 0x0400D4CC RID: 54476
		private static readonly IntPtr NativeMethodInfoPtr_TargetShootDirection_Public_Virtual_New_Vector3_0;

		// Token: 0x0400D4CD RID: 54477
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D4CE RID: 54478
		private static readonly IntPtr NativeMethodInfoPtr_LostTarget_Protected_Virtual_New_Void_0;

		// Token: 0x0400D4CF RID: 54479
		private static readonly IntPtr NativeMethodInfoPtr_NeedToReload_Protected_Virtual_New_Void_0;

		// Token: 0x0400D4D0 RID: 54480
		private static readonly IntPtr NativeMethodInfoPtr_DoneShooting_Protected_Virtual_New_Void_0;

		// Token: 0x0400D4D1 RID: 54481
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
