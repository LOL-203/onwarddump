﻿using System;
using System.Runtime.InteropServices;
using AISystems;
using DPI.AISystems.Alerts;
using DPI.Data;
using DPI.Stats;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using Onward.AI.Voices;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001156 RID: 4438
	public class AIState : BaseData
	{
		// Token: 0x06014AE3 RID: 84707 RVA: 0x00534038 File Offset: 0x00532238
		[CallerCount(0)]
		public unsafe Vector3 GetStateDrivenLookPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_New_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AE4 RID: 84708 RVA: 0x00534094 File Offset: 0x00532294
		[CallerCount(0)]
		public unsafe void GoToState<TTargetState>([Optional] AlertStruct alertData, [Optional] Il2CppSystem.Object additionalData) where TTargetState : AIState
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(additionalData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIState.MethodInfoStoreGeneric_GoToState_Public_Void_AlertStruct_Object_0<TTargetState>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AE5 RID: 84709 RVA: 0x00534108 File Offset: 0x00532308
		[CallerCount(0)]
		public unsafe void Initialize(AIStateManager stateManager, AlertStruct alert, Il2CppSystem.Object additionalData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(stateManager);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(alert);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(additionalData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_AIStateManager_AlertStruct_Object_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AE6 RID: 84710 RVA: 0x0053419C File Offset: 0x0053239C
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AE7 RID: 84711 RVA: 0x005341EC File Offset: 0x005323EC
		[CallerCount(0)]
		public unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_Enter_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AE8 RID: 84712 RVA: 0x0053423C File Offset: 0x0053243C
		[CallerCount(0)]
		public unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_Exit_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AE9 RID: 84713 RVA: 0x0053428C File Offset: 0x0053248C
		[CallerCount(0)]
		public unsafe void OnUpdate(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_OnUpdate_Public_Virtual_New_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AEA RID: 84714 RVA: 0x005342EC File Offset: 0x005324EC
		[CallerCount(0)]
		public unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState.NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AEB RID: 84715 RVA: 0x0053434C File Offset: 0x0053254C
		[CallerCount(0)]
		public unsafe bool ConsolidatedPriorityStateChanges()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedPriorityStateChanges_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AEC RID: 84716 RVA: 0x0053439C File Offset: 0x0053259C
		[CallerCount(0)]
		public unsafe bool ConsolidatedObjectiveStateChanges()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedObjectiveStateChanges_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AED RID: 84717 RVA: 0x005343EC File Offset: 0x005325EC
		[CallerCount(0)]
		public unsafe bool ConsolidatedAlertStateChanges()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedAlertStateChanges_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AEE RID: 84718 RVA: 0x0053443C File Offset: 0x0053263C
		[CallerCount(0)]
		public unsafe bool ConsolidatedIdleStateChanges()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedIdleStateChanges_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AEF RID: 84719 RVA: 0x0053448C File Offset: 0x0053268C
		[CallerCount(0)]
		public unsafe bool ConsolidatedEnemyChecksWithEnemySpotted()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedEnemyChecksWithEnemySpotted_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF0 RID: 84720 RVA: 0x005344DC File Offset: 0x005326DC
		[CallerCount(0)]
		public unsafe bool ConsolidatedEnemyChecks()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_ConsolidatedEnemyChecks_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF1 RID: 84721 RVA: 0x0053452C File Offset: 0x0053272C
		[CallerCount(0)]
		public unsafe float GetEndRealTime(float min, float max)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref min;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_GetEndRealTime_Protected_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF2 RID: 84722 RVA: 0x005345A4 File Offset: 0x005327A4
		[CallerCount(0)]
		public unsafe float GetEndReactionTime(float min, float max)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref min;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_GetEndReactionTime_Protected_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF3 RID: 84723 RVA: 0x0053461C File Offset: 0x0053281C
		[CallerCount(0)]
		public unsafe float GetReactionDelay(float min, float max)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref min;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_GetReactionDelay_Protected_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF4 RID: 84724 RVA: 0x00534694 File Offset: 0x00532894
		[CallerCount(0)]
		public unsafe bool Roll100(int chance)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref chance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_Roll100_Protected_Boolean_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF5 RID: 84725 RVA: 0x005346F8 File Offset: 0x005328F8
		[CallerCount(0)]
		public unsafe bool Roll100WeightTowardStat(StatTypes statType, int chance)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref statType;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref chance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_Roll100WeightTowardStat_Protected_Boolean_StatTypes_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF6 RID: 84726 RVA: 0x00534770 File Offset: 0x00532970
		[CallerCount(0)]
		public unsafe void PlayWeightedVoice(VoiceType voiceType, bool isIdleChatter)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref voiceType;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isIdleChatter;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_PlayWeightedVoice_Protected_Void_VoiceType_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AF7 RID: 84727 RVA: 0x005347D8 File Offset: 0x005329D8
		[CallerCount(0)]
		public unsafe bool LiveFriendliesNearby(Vector3 position, float distance)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref position;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref distance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_LiveFriendliesNearby_Protected_Boolean_Vector3_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF8 RID: 84728 RVA: 0x00534850 File Offset: 0x00532A50
		[CallerCount(0)]
		public unsafe bool FlashBangCheck(Vector3 potentialThrowTargetPos, Vector3 flashTargetCharacter, float minThrowDistance, float maxThrowDistance, float minSafeDistance, float maxDistanceFromTarget)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref potentialThrowTargetPos;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref flashTargetCharacter;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minThrowDistance;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxThrowDistance;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minSafeDistance;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDistanceFromTarget;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr_FlashBangCheck_Public_Boolean_Vector3_Vector3_Single_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AF9 RID: 84729 RVA: 0x00534914 File Offset: 0x00532B14
		[CallerCount(0)]
		public unsafe AIState() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIState>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIState.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AFA RID: 84730 RVA: 0x00534960 File Offset: 0x00532B60
		// Note: this type is marked as 'beforefieldinit'.
		static AIState()
		{
			Il2CppClassPointerStore<AIState>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AIState");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIState>.NativeClassPtr);
			AIState.NativeFieldInfoPtr__aiStateManager = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState>.NativeClassPtr, "_aiStateManager");
			AIState.NativeFieldInfoPtr__owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState>.NativeClassPtr, "_owner");
			AIState.NativeFieldInfoPtr__alertStruct = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState>.NativeClassPtr, "_alertStruct");
			AIState.NativeFieldInfoPtr_LookPositionType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState>.NativeClassPtr, "LookPositionType");
			AIState.NativeFieldInfoPtr_AdditionalData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState>.NativeClassPtr, "AdditionalData");
			AIState.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_New_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689681);
			AIState.NativeMethodInfoPtr_GoToState_Public_Void_AlertStruct_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689682);
			AIState.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_AIStateManager_AlertStruct_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689683);
			AIState.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689684);
			AIState.NativeMethodInfoPtr_Enter_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689685);
			AIState.NativeMethodInfoPtr_Exit_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689686);
			AIState.NativeMethodInfoPtr_OnUpdate_Public_Virtual_New_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689687);
			AIState.NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689688);
			AIState.NativeMethodInfoPtr_ConsolidatedPriorityStateChanges_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689689);
			AIState.NativeMethodInfoPtr_ConsolidatedObjectiveStateChanges_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689690);
			AIState.NativeMethodInfoPtr_ConsolidatedAlertStateChanges_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689691);
			AIState.NativeMethodInfoPtr_ConsolidatedIdleStateChanges_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689692);
			AIState.NativeMethodInfoPtr_ConsolidatedEnemyChecksWithEnemySpotted_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689693);
			AIState.NativeMethodInfoPtr_ConsolidatedEnemyChecks_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689694);
			AIState.NativeMethodInfoPtr_GetEndRealTime_Protected_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689695);
			AIState.NativeMethodInfoPtr_GetEndReactionTime_Protected_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689696);
			AIState.NativeMethodInfoPtr_GetReactionDelay_Protected_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689697);
			AIState.NativeMethodInfoPtr_Roll100_Protected_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689698);
			AIState.NativeMethodInfoPtr_Roll100WeightTowardStat_Protected_Boolean_StatTypes_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689699);
			AIState.NativeMethodInfoPtr_PlayWeightedVoice_Protected_Void_VoiceType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689700);
			AIState.NativeMethodInfoPtr_LiveFriendliesNearby_Protected_Boolean_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689701);
			AIState.NativeMethodInfoPtr_FlashBangCheck_Public_Boolean_Vector3_Vector3_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689702);
			AIState.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState>.NativeClassPtr, 100689703);
		}

		// Token: 0x06014AFB RID: 84731 RVA: 0x000AD628 File Offset: 0x000AB828
		public AIState(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007510 RID: 29968
		// (get) Token: 0x06014AFC RID: 84732 RVA: 0x00534BC0 File Offset: 0x00532DC0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIState>.NativeClassPtr));
			}
		}

		// Token: 0x17007511 RID: 29969
		// (get) Token: 0x06014AFD RID: 84733 RVA: 0x00534BD4 File Offset: 0x00532DD4
		// (set) Token: 0x06014AFE RID: 84734 RVA: 0x00534C08 File Offset: 0x00532E08
		public unsafe AIStateManager _aiStateManager
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__aiStateManager);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIStateManager(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__aiStateManager), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007512 RID: 29970
		// (get) Token: 0x06014AFF RID: 84735 RVA: 0x00534C30 File Offset: 0x00532E30
		// (set) Token: 0x06014B00 RID: 84736 RVA: 0x00534C64 File Offset: 0x00532E64
		public unsafe HumanoidAI _owner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__owner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__owner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007513 RID: 29971
		// (get) Token: 0x06014B01 RID: 84737 RVA: 0x00534C8C File Offset: 0x00532E8C
		// (set) Token: 0x06014B02 RID: 84738 RVA: 0x00534CC0 File Offset: 0x00532EC0
		public unsafe AlertStruct _alertStruct
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__alertStruct);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertStruct(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr__alertStruct), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007514 RID: 29972
		// (get) Token: 0x06014B03 RID: 84739 RVA: 0x00534CE8 File Offset: 0x00532EE8
		// (set) Token: 0x06014B04 RID: 84740 RVA: 0x00534D10 File Offset: 0x00532F10
		public unsafe LookPositionTypes LookPositionType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr_LookPositionType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr_LookPositionType)) = value;
			}
		}

		// Token: 0x17007515 RID: 29973
		// (get) Token: 0x06014B05 RID: 84741 RVA: 0x00534D34 File Offset: 0x00532F34
		// (set) Token: 0x06014B06 RID: 84742 RVA: 0x00534D68 File Offset: 0x00532F68
		public unsafe Il2CppSystem.Object AdditionalData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr_AdditionalData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState.NativeFieldInfoPtr_AdditionalData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D37A RID: 54138
		private static readonly IntPtr NativeFieldInfoPtr__aiStateManager;

		// Token: 0x0400D37B RID: 54139
		private static readonly IntPtr NativeFieldInfoPtr__owner;

		// Token: 0x0400D37C RID: 54140
		private static readonly IntPtr NativeFieldInfoPtr__alertStruct;

		// Token: 0x0400D37D RID: 54141
		private static readonly IntPtr NativeFieldInfoPtr_LookPositionType;

		// Token: 0x0400D37E RID: 54142
		private static readonly IntPtr NativeFieldInfoPtr_AdditionalData;

		// Token: 0x0400D37F RID: 54143
		private static readonly IntPtr NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_New_Vector3_0;

		// Token: 0x0400D380 RID: 54144
		private static readonly IntPtr NativeMethodInfoPtr_GoToState_Public_Void_AlertStruct_Object_0;

		// Token: 0x0400D381 RID: 54145
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_AIStateManager_AlertStruct_Object_0;

		// Token: 0x0400D382 RID: 54146
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0;

		// Token: 0x0400D383 RID: 54147
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_New_Void_0;

		// Token: 0x0400D384 RID: 54148
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_New_Void_0;

		// Token: 0x0400D385 RID: 54149
		private static readonly IntPtr NativeMethodInfoPtr_OnUpdate_Public_Virtual_New_Void_Single_0;

		// Token: 0x0400D386 RID: 54150
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_Single_0;

		// Token: 0x0400D387 RID: 54151
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedPriorityStateChanges_Protected_Boolean_0;

		// Token: 0x0400D388 RID: 54152
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedObjectiveStateChanges_Protected_Boolean_0;

		// Token: 0x0400D389 RID: 54153
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedAlertStateChanges_Protected_Boolean_0;

		// Token: 0x0400D38A RID: 54154
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedIdleStateChanges_Protected_Boolean_0;

		// Token: 0x0400D38B RID: 54155
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedEnemyChecksWithEnemySpotted_Protected_Boolean_0;

		// Token: 0x0400D38C RID: 54156
		private static readonly IntPtr NativeMethodInfoPtr_ConsolidatedEnemyChecks_Protected_Boolean_0;

		// Token: 0x0400D38D RID: 54157
		private static readonly IntPtr NativeMethodInfoPtr_GetEndRealTime_Protected_Single_Single_Single_0;

		// Token: 0x0400D38E RID: 54158
		private static readonly IntPtr NativeMethodInfoPtr_GetEndReactionTime_Protected_Single_Single_Single_0;

		// Token: 0x0400D38F RID: 54159
		private static readonly IntPtr NativeMethodInfoPtr_GetReactionDelay_Protected_Single_Single_Single_0;

		// Token: 0x0400D390 RID: 54160
		private static readonly IntPtr NativeMethodInfoPtr_Roll100_Protected_Boolean_Int32_0;

		// Token: 0x0400D391 RID: 54161
		private static readonly IntPtr NativeMethodInfoPtr_Roll100WeightTowardStat_Protected_Boolean_StatTypes_Int32_0;

		// Token: 0x0400D392 RID: 54162
		private static readonly IntPtr NativeMethodInfoPtr_PlayWeightedVoice_Protected_Void_VoiceType_Boolean_0;

		// Token: 0x0400D393 RID: 54163
		private static readonly IntPtr NativeMethodInfoPtr_LiveFriendliesNearby_Protected_Boolean_Vector3_Single_0;

		// Token: 0x0400D394 RID: 54164
		private static readonly IntPtr NativeMethodInfoPtr_FlashBangCheck_Public_Boolean_Vector3_Vector3_Single_Single_Single_Single_0;

		// Token: 0x0400D395 RID: 54165
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001157 RID: 4439
		private sealed class MethodInfoStoreGeneric_GoToState_Public_Void_AlertStruct_Object_0<TTargetState>
		{
			// Token: 0x0400D396 RID: 54166
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AIState.NativeMethodInfoPtr_GoToState_Public_Void_AlertStruct_Object_0, Il2CppClassPointerStore<AIState>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TTargetState>.NativeClassPtr))
			}))));
		}
	}
}
