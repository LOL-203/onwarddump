﻿using System;

namespace DPI.AISystems
{
	// Token: 0x0200115A RID: 4442
	public enum PostureTypes
	{
		// Token: 0x0400D3AE RID: 54190
		Idle,
		// Token: 0x0400D3AF RID: 54191
		Alert,
		// Token: 0x0400D3B0 RID: 54192
		Combat,
		// Token: 0x0400D3B1 RID: 54193
		Sprinting
	}
}
