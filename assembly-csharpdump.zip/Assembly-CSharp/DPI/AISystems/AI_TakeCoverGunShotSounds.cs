﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001186 RID: 4486
	public class AI_TakeCoverGunShotSounds : AIState
	{
		// Token: 0x06014D9E RID: 85406 RVA: 0x0053E428 File Offset: 0x0053C628
		[CallerCount(0)]
		public unsafe AI_TakeCoverGunShotSounds() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCoverGunShotSounds>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverGunShotSounds.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D9F RID: 85407 RVA: 0x0053E473 File Offset: 0x0053C673
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCoverGunShotSounds()
		{
			Il2CppClassPointerStore<AI_TakeCoverGunShotSounds>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCoverGunShotSounds");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCoverGunShotSounds>.NativeClassPtr);
			AI_TakeCoverGunShotSounds.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverGunShotSounds>.NativeClassPtr, 100689886);
		}

		// Token: 0x06014DA0 RID: 85408 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCoverGunShotSounds(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075F2 RID: 30194
		// (get) Token: 0x06014DA1 RID: 85409 RVA: 0x0053E4AC File Offset: 0x0053C6AC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCoverGunShotSounds>.NativeClassPtr));
			}
		}

		// Token: 0x0400D4FD RID: 54525
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
