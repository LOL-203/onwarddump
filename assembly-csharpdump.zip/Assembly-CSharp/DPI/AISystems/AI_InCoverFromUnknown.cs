﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200116C RID: 4460
	public class AI_InCoverFromUnknown : AIState
	{
		// Token: 0x06014C22 RID: 85026 RVA: 0x00538E20 File Offset: 0x00537020
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCoverFromUnknown.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C23 RID: 85027 RVA: 0x00538E70 File Offset: 0x00537070
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCoverFromUnknown.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C24 RID: 85028 RVA: 0x00538ED0 File Offset: 0x005370D0
		[CallerCount(0)]
		public unsafe AI_InCoverFromUnknown() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InCoverFromUnknown.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C25 RID: 85029 RVA: 0x00538F1C File Offset: 0x0053711C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_InCoverFromUnknown()
		{
			Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_InCoverFromUnknown");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr);
			AI_InCoverFromUnknown.NativeFieldInfoPtr_MinWaitInCoverTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, "MinWaitInCoverTime");
			AI_InCoverFromUnknown.NativeFieldInfoPtr_MaxWaitInCoverTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, "MaxWaitInCoverTime");
			AI_InCoverFromUnknown.NativeFieldInfoPtr__endTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, "_endTime");
			AI_InCoverFromUnknown.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, 100689780);
			AI_InCoverFromUnknown.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, 100689781);
			AI_InCoverFromUnknown.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr, 100689782);
		}

		// Token: 0x06014C26 RID: 85030 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_InCoverFromUnknown(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007576 RID: 30070
		// (get) Token: 0x06014C27 RID: 85031 RVA: 0x00538FC4 File Offset: 0x005371C4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_InCoverFromUnknown>.NativeClassPtr));
			}
		}

		// Token: 0x17007577 RID: 30071
		// (get) Token: 0x06014C28 RID: 85032 RVA: 0x00538FD8 File Offset: 0x005371D8
		// (set) Token: 0x06014C29 RID: 85033 RVA: 0x00539000 File Offset: 0x00537200
		public unsafe float MinWaitInCoverTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr_MinWaitInCoverTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr_MinWaitInCoverTime)) = value;
			}
		}

		// Token: 0x17007578 RID: 30072
		// (get) Token: 0x06014C2A RID: 85034 RVA: 0x00539024 File Offset: 0x00537224
		// (set) Token: 0x06014C2B RID: 85035 RVA: 0x0053904C File Offset: 0x0053724C
		public unsafe float MaxWaitInCoverTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr_MaxWaitInCoverTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr_MaxWaitInCoverTime)) = value;
			}
		}

		// Token: 0x17007579 RID: 30073
		// (get) Token: 0x06014C2C RID: 85036 RVA: 0x00539070 File Offset: 0x00537270
		// (set) Token: 0x06014C2D RID: 85037 RVA: 0x00539098 File Offset: 0x00537298
		public unsafe float _endTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr__endTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InCoverFromUnknown.NativeFieldInfoPtr__endTime)) = value;
			}
		}

		// Token: 0x0400D431 RID: 54321
		private static readonly IntPtr NativeFieldInfoPtr_MinWaitInCoverTime;

		// Token: 0x0400D432 RID: 54322
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaitInCoverTime;

		// Token: 0x0400D433 RID: 54323
		private static readonly IntPtr NativeFieldInfoPtr__endTime;

		// Token: 0x0400D434 RID: 54324
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D435 RID: 54325
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D436 RID: 54326
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
