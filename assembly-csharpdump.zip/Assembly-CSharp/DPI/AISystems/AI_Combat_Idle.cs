﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200115F RID: 4447
	public class AI_Combat_Idle : AIState
	{
		// Token: 0x06014B5C RID: 84828 RVA: 0x00536190 File Offset: 0x00534390
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Combat_Idle.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B5D RID: 84829 RVA: 0x005361E0 File Offset: 0x005343E0
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Combat_Idle.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B5E RID: 84830 RVA: 0x00536240 File Offset: 0x00534440
		[CallerCount(0)]
		public unsafe AI_Combat_Idle() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Combat_Idle.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B5F RID: 84831 RVA: 0x0053628C File Offset: 0x0053448C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Combat_Idle()
		{
			Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Combat_Idle");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr);
			AI_Combat_Idle.NativeFieldInfoPtr_MinIdleTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MinIdleTime");
			AI_Combat_Idle.NativeFieldInfoPtr_MaxIdleTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MaxIdleTime");
			AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "ChanceToThrowGrenade");
			AI_Combat_Idle.NativeFieldInfoPtr_MinDistanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MinDistanceToThrowGrenade");
			AI_Combat_Idle.NativeFieldInfoPtr_MaxDistanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MaxDistanceToThrowGrenade");
			AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowFlash = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "ChanceToThrowFlash");
			AI_Combat_Idle.NativeFieldInfoPtr_MinFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MinFlashDistance");
			AI_Combat_Idle.NativeFieldInfoPtr_MaxFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MaxFlashDistance");
			AI_Combat_Idle.NativeFieldInfoPtr_MinFriendlySafeFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MinFriendlySafeFlashDistance");
			AI_Combat_Idle.NativeFieldInfoPtr_MaxTargetFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "MaxTargetFlashDistance");
			AI_Combat_Idle.NativeFieldInfoPtr__waitEndTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, "_waitEndTime");
			AI_Combat_Idle.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, 100689727);
			AI_Combat_Idle.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, 100689728);
			AI_Combat_Idle.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr, 100689729);
		}

		// Token: 0x06014B60 RID: 84832 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_Combat_Idle(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007534 RID: 30004
		// (get) Token: 0x06014B61 RID: 84833 RVA: 0x005363D4 File Offset: 0x005345D4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Combat_Idle>.NativeClassPtr));
			}
		}

		// Token: 0x17007535 RID: 30005
		// (get) Token: 0x06014B62 RID: 84834 RVA: 0x005363E8 File Offset: 0x005345E8
		// (set) Token: 0x06014B63 RID: 84835 RVA: 0x00536410 File Offset: 0x00534610
		public unsafe float MinIdleTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinIdleTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinIdleTime)) = value;
			}
		}

		// Token: 0x17007536 RID: 30006
		// (get) Token: 0x06014B64 RID: 84836 RVA: 0x00536434 File Offset: 0x00534634
		// (set) Token: 0x06014B65 RID: 84837 RVA: 0x0053645C File Offset: 0x0053465C
		public unsafe float MaxIdleTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxIdleTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxIdleTime)) = value;
			}
		}

		// Token: 0x17007537 RID: 30007
		// (get) Token: 0x06014B66 RID: 84838 RVA: 0x00536480 File Offset: 0x00534680
		// (set) Token: 0x06014B67 RID: 84839 RVA: 0x005364A8 File Offset: 0x005346A8
		public unsafe int ChanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x17007538 RID: 30008
		// (get) Token: 0x06014B68 RID: 84840 RVA: 0x005364CC File Offset: 0x005346CC
		// (set) Token: 0x06014B69 RID: 84841 RVA: 0x005364F4 File Offset: 0x005346F4
		public unsafe float MinDistanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinDistanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinDistanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x17007539 RID: 30009
		// (get) Token: 0x06014B6A RID: 84842 RVA: 0x00536518 File Offset: 0x00534718
		// (set) Token: 0x06014B6B RID: 84843 RVA: 0x00536540 File Offset: 0x00534740
		public unsafe float MaxDistanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxDistanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxDistanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x1700753A RID: 30010
		// (get) Token: 0x06014B6C RID: 84844 RVA: 0x00536564 File Offset: 0x00534764
		// (set) Token: 0x06014B6D RID: 84845 RVA: 0x0053658C File Offset: 0x0053478C
		public unsafe int ChanceToThrowFlash
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowFlash);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_ChanceToThrowFlash)) = value;
			}
		}

		// Token: 0x1700753B RID: 30011
		// (get) Token: 0x06014B6E RID: 84846 RVA: 0x005365B0 File Offset: 0x005347B0
		// (set) Token: 0x06014B6F RID: 84847 RVA: 0x005365D8 File Offset: 0x005347D8
		public unsafe float MinFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinFlashDistance)) = value;
			}
		}

		// Token: 0x1700753C RID: 30012
		// (get) Token: 0x06014B70 RID: 84848 RVA: 0x005365FC File Offset: 0x005347FC
		// (set) Token: 0x06014B71 RID: 84849 RVA: 0x00536624 File Offset: 0x00534824
		public unsafe float MaxFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxFlashDistance)) = value;
			}
		}

		// Token: 0x1700753D RID: 30013
		// (get) Token: 0x06014B72 RID: 84850 RVA: 0x00536648 File Offset: 0x00534848
		// (set) Token: 0x06014B73 RID: 84851 RVA: 0x00536670 File Offset: 0x00534870
		public unsafe float MinFriendlySafeFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinFriendlySafeFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MinFriendlySafeFlashDistance)) = value;
			}
		}

		// Token: 0x1700753E RID: 30014
		// (get) Token: 0x06014B74 RID: 84852 RVA: 0x00536694 File Offset: 0x00534894
		// (set) Token: 0x06014B75 RID: 84853 RVA: 0x005366BC File Offset: 0x005348BC
		public unsafe float MaxTargetFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxTargetFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr_MaxTargetFlashDistance)) = value;
			}
		}

		// Token: 0x1700753F RID: 30015
		// (get) Token: 0x06014B76 RID: 84854 RVA: 0x005366E0 File Offset: 0x005348E0
		// (set) Token: 0x06014B77 RID: 84855 RVA: 0x00536708 File Offset: 0x00534908
		public unsafe float _waitEndTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr__waitEndTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Combat_Idle.NativeFieldInfoPtr__waitEndTime)) = value;
			}
		}

		// Token: 0x0400D3C7 RID: 54215
		private static readonly IntPtr NativeFieldInfoPtr_MinIdleTime;

		// Token: 0x0400D3C8 RID: 54216
		private static readonly IntPtr NativeFieldInfoPtr_MaxIdleTime;

		// Token: 0x0400D3C9 RID: 54217
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowGrenade;

		// Token: 0x0400D3CA RID: 54218
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToThrowGrenade;

		// Token: 0x0400D3CB RID: 54219
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistanceToThrowGrenade;

		// Token: 0x0400D3CC RID: 54220
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowFlash;

		// Token: 0x0400D3CD RID: 54221
		private static readonly IntPtr NativeFieldInfoPtr_MinFlashDistance;

		// Token: 0x0400D3CE RID: 54222
		private static readonly IntPtr NativeFieldInfoPtr_MaxFlashDistance;

		// Token: 0x0400D3CF RID: 54223
		private static readonly IntPtr NativeFieldInfoPtr_MinFriendlySafeFlashDistance;

		// Token: 0x0400D3D0 RID: 54224
		private static readonly IntPtr NativeFieldInfoPtr_MaxTargetFlashDistance;

		// Token: 0x0400D3D1 RID: 54225
		private static readonly IntPtr NativeFieldInfoPtr__waitEndTime;

		// Token: 0x0400D3D2 RID: 54226
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3D3 RID: 54227
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3D4 RID: 54228
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
