﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001190 RID: 4496
	public class PlayerVisionTarget : VisionTarget
	{
		// Token: 0x06014E3B RID: 85563 RVA: 0x00540A84 File Offset: 0x0053EC84
		[CallerCount(0)]
		public unsafe void Initialize(Faction faction, Transform head, Transform leftHand, Transform rightHand)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref faction;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(head);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(leftHand);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(rightHand);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PlayerVisionTarget.NativeMethodInfoPtr_Initialize_Public_Void_Faction_Transform_Transform_Transform_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E3C RID: 85564 RVA: 0x00540B20 File Offset: 0x0053ED20
		[CallerCount(0)]
		public new unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), PlayerVisionTarget.NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E3D RID: 85565 RVA: 0x00540B70 File Offset: 0x0053ED70
		[CallerCount(0)]
		public unsafe PlayerVisionTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PlayerVisionTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E3E RID: 85566 RVA: 0x00540BBC File Offset: 0x0053EDBC
		// Note: this type is marked as 'beforefieldinit'.
		static PlayerVisionTarget()
		{
			Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "PlayerVisionTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr);
			PlayerVisionTarget.NativeMethodInfoPtr_Initialize_Public_Void_Faction_Transform_Transform_Transform_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr, 100689937);
			PlayerVisionTarget.NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr, 100689938);
			PlayerVisionTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr, 100689939);
		}

		// Token: 0x06014E3F RID: 85567 RVA: 0x00540C28 File Offset: 0x0053EE28
		public PlayerVisionTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007628 RID: 30248
		// (get) Token: 0x06014E40 RID: 85568 RVA: 0x00540C31 File Offset: 0x0053EE31
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PlayerVisionTarget>.NativeClassPtr));
			}
		}

		// Token: 0x0400D556 RID: 54614
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_Faction_Transform_Transform_Transform_0;

		// Token: 0x0400D557 RID: 54615
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0;

		// Token: 0x0400D558 RID: 54616
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
