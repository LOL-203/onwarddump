﻿using System;
using DPI.Data;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001199 RID: 4505
	public class VisionStatesData : BaseData
	{
		// Token: 0x06014EB4 RID: 85684 RVA: 0x00542630 File Offset: 0x00540830
		[CallerCount(0)]
		public unsafe VisionStatesData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionStatesData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EB5 RID: 85685 RVA: 0x0054267C File Offset: 0x0054087C
		// Note: this type is marked as 'beforefieldinit'.
		static VisionStatesData()
		{
			Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionStatesData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr);
			VisionStatesData.NativeFieldInfoPtr_Frustums = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr, "Frustums");
			VisionStatesData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr, 100689968);
		}

		// Token: 0x06014EB6 RID: 85686 RVA: 0x000AD628 File Offset: 0x000AB828
		public VisionStatesData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007650 RID: 30288
		// (get) Token: 0x06014EB7 RID: 85687 RVA: 0x005426D4 File Offset: 0x005408D4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionStatesData>.NativeClassPtr));
			}
		}

		// Token: 0x17007651 RID: 30289
		// (get) Token: 0x06014EB8 RID: 85688 RVA: 0x005426E8 File Offset: 0x005408E8
		// (set) Token: 0x06014EB9 RID: 85689 RVA: 0x0054271C File Offset: 0x0054091C
		public unsafe List<VisionFrustumData> Frustums
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionStatesData.NativeFieldInfoPtr_Frustums);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<VisionFrustumData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionStatesData.NativeFieldInfoPtr_Frustums), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D593 RID: 54675
		private static readonly IntPtr NativeFieldInfoPtr_Frustums;

		// Token: 0x0400D594 RID: 54676
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
