﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems.Waypoints
{
	// Token: 0x0200119F RID: 4511
	[Serializable]
	public class WayPointData : Il2CppSystem.Object
	{
		// Token: 0x06014F17 RID: 85783 RVA: 0x00543DF0 File Offset: 0x00541FF0
		[CallerCount(0)]
		public unsafe void RotatePoints()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WayPointData.NativeMethodInfoPtr_RotatePoints_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F18 RID: 85784 RVA: 0x00543E34 File Offset: 0x00542034
		[CallerCount(0)]
		public unsafe WayPointData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<WayPointData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WayPointData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F19 RID: 85785 RVA: 0x00543E80 File Offset: 0x00542080
		// Note: this type is marked as 'beforefieldinit'.
		static WayPointData()
		{
			Il2CppClassPointerStore<WayPointData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Waypoints", "WayPointData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<WayPointData>.NativeClassPtr);
			WayPointData.NativeFieldInfoPtr_DoesLoop = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WayPointData>.NativeClassPtr, "DoesLoop");
			WayPointData.NativeFieldInfoPtr_Points = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WayPointData>.NativeClassPtr, "Points");
			WayPointData.NativeMethodInfoPtr_RotatePoints_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WayPointData>.NativeClassPtr, 100689994);
			WayPointData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WayPointData>.NativeClassPtr, 100689995);
		}

		// Token: 0x06014F1A RID: 85786 RVA: 0x00002988 File Offset: 0x00000B88
		public WayPointData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007672 RID: 30322
		// (get) Token: 0x06014F1B RID: 85787 RVA: 0x00543F00 File Offset: 0x00542100
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<WayPointData>.NativeClassPtr));
			}
		}

		// Token: 0x17007673 RID: 30323
		// (get) Token: 0x06014F1C RID: 85788 RVA: 0x00543F14 File Offset: 0x00542114
		// (set) Token: 0x06014F1D RID: 85789 RVA: 0x00543F3C File Offset: 0x0054213C
		public unsafe bool DoesLoop
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WayPointData.NativeFieldInfoPtr_DoesLoop);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WayPointData.NativeFieldInfoPtr_DoesLoop)) = value;
			}
		}

		// Token: 0x17007674 RID: 30324
		// (get) Token: 0x06014F1E RID: 85790 RVA: 0x00543F60 File Offset: 0x00542160
		// (set) Token: 0x06014F1F RID: 85791 RVA: 0x00543F94 File Offset: 0x00542194
		public unsafe List<Vector3> Points
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WayPointData.NativeFieldInfoPtr_Points);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WayPointData.NativeFieldInfoPtr_Points), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D5C8 RID: 54728
		private static readonly IntPtr NativeFieldInfoPtr_DoesLoop;

		// Token: 0x0400D5C9 RID: 54729
		private static readonly IntPtr NativeFieldInfoPtr_Points;

		// Token: 0x0400D5CA RID: 54730
		private static readonly IntPtr NativeMethodInfoPtr_RotatePoints_Public_Void_0;

		// Token: 0x0400D5CB RID: 54731
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
