﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems.Waypoints
{
	// Token: 0x020011A0 RID: 4512
	public static class WaypointManager : Il2CppSystem.Object
	{
		// Token: 0x06014F20 RID: 85792 RVA: 0x00543FBC File Offset: 0x005421BC
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WaypointManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F21 RID: 85793 RVA: 0x00543FF0 File Offset: 0x005421F0
		[CallerCount(0)]
		public unsafe static void Uninitialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WaypointManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F22 RID: 85794 RVA: 0x00544024 File Offset: 0x00542224
		[CallerCount(0)]
		public unsafe static bool GetClosestWaypoint(Vector3 position, float maxRadius, out WayPointData wayPointData)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref position;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxRadius;
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(wayPointData);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WaypointManager.NativeMethodInfoPtr_GetClosestWaypoint_Public_Static_Boolean_Vector3_Single_byref_WayPointData_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			wayPointData = ((intPtr2 == 0) ? null : new WayPointData(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014F23 RID: 85795 RVA: 0x005440C4 File Offset: 0x005422C4
		// Note: this type is marked as 'beforefieldinit'.
		static WaypointManager()
		{
			Il2CppClassPointerStore<WaypointManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Waypoints", "WaypointManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr);
			WaypointManager.NativeFieldInfoPtr__waypoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr, "_waypoints");
			WaypointManager.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr, 100689996);
			WaypointManager.NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr, 100689997);
			WaypointManager.NativeMethodInfoPtr_GetClosestWaypoint_Public_Static_Boolean_Vector3_Single_byref_WayPointData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr, 100689998);
		}

		// Token: 0x06014F24 RID: 85796 RVA: 0x00002988 File Offset: 0x00000B88
		public WaypointManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007675 RID: 30325
		// (get) Token: 0x06014F25 RID: 85797 RVA: 0x00544144 File Offset: 0x00542344
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<WaypointManager>.NativeClassPtr));
			}
		}

		// Token: 0x17007676 RID: 30326
		// (get) Token: 0x06014F26 RID: 85798 RVA: 0x00544158 File Offset: 0x00542358
		// (set) Token: 0x06014F27 RID: 85799 RVA: 0x00544183 File Offset: 0x00542383
		public unsafe static List<WayPointData> _waypoints
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(WaypointManager.NativeFieldInfoPtr__waypoints, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<WayPointData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WaypointManager.NativeFieldInfoPtr__waypoints, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D5CC RID: 54732
		private static readonly IntPtr NativeFieldInfoPtr__waypoints;

		// Token: 0x0400D5CD RID: 54733
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400D5CE RID: 54734
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Static_Void_0;

		// Token: 0x0400D5CF RID: 54735
		private static readonly IntPtr NativeMethodInfoPtr_GetClosestWaypoint_Public_Static_Boolean_Vector3_Single_byref_WayPointData_0;
	}
}
