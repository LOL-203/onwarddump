﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001198 RID: 4504
	public class VisionSensor : MonoBehaviour
	{
		// Token: 0x06014E98 RID: 85656 RVA: 0x00541F18 File Offset: 0x00540118
		[CallerCount(0)]
		public unsafe void Initialize(VisionStatesData data)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_Initialize_Public_Void_VisionStatesData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E99 RID: 85657 RVA: 0x00541F74 File Offset: 0x00540174
		[CallerCount(0)]
		public unsafe void SetUpVision(VisionStatesData data)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_SetUpVision_Public_Void_VisionStatesData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E9A RID: 85658 RVA: 0x00541FD0 File Offset: 0x005401D0
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E9B RID: 85659 RVA: 0x00542014 File Offset: 0x00540214
		[CallerCount(0)]
		public unsafe bool CanSeeTarget(DamageController damageController)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(damageController);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_CanSeeTarget_Public_Boolean_DamageController_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014E9C RID: 85660 RVA: 0x0054207C File Offset: 0x0054027C
		[CallerCount(0)]
		public unsafe void CreateFrustums()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_CreateFrustums_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E9D RID: 85661 RVA: 0x005420C0 File Offset: 0x005402C0
		[CallerCount(0)]
		public unsafe void DestroyFrustums()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_DestroyFrustums_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E9E RID: 85662 RVA: 0x00542104 File Offset: 0x00540304
		[CallerCount(0)]
		public unsafe void Collect()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_Collect_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E9F RID: 85663 RVA: 0x00542148 File Offset: 0x00540348
		[CallerCount(0)]
		public unsafe void ClearSensor()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr_ClearSensor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EA0 RID: 85664 RVA: 0x0054218C File Offset: 0x0054038C
		[CallerCount(0)]
		public unsafe VisionSensor() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionSensor.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EA1 RID: 85665 RVA: 0x005421D8 File Offset: 0x005403D8
		// Note: this type is marked as 'beforefieldinit'.
		static VisionSensor()
		{
			Il2CppClassPointerStore<VisionSensor>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionSensor");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr);
			VisionSensor.NativeFieldInfoPtr_TargetManager = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "TargetManager");
			VisionSensor.NativeFieldInfoPtr_Factions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "Factions");
			VisionSensor.NativeFieldInfoPtr__frustums = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "_frustums");
			VisionSensor.NativeFieldInfoPtr_SightLayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "SightLayer");
			VisionSensor.NativeFieldInfoPtr_Self = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "Self");
			VisionSensor.NativeFieldInfoPtr_SightOrigin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "SightOrigin");
			VisionSensor.NativeFieldInfoPtr__data = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "_data");
			VisionSensor.NativeFieldInfoPtr__targetCheckOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, "_targetCheckOffset");
			VisionSensor.NativeMethodInfoPtr_Initialize_Public_Void_VisionStatesData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689959);
			VisionSensor.NativeMethodInfoPtr_SetUpVision_Public_Void_VisionStatesData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689960);
			VisionSensor.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689961);
			VisionSensor.NativeMethodInfoPtr_CanSeeTarget_Public_Boolean_DamageController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689962);
			VisionSensor.NativeMethodInfoPtr_CreateFrustums_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689963);
			VisionSensor.NativeMethodInfoPtr_DestroyFrustums_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689964);
			VisionSensor.NativeMethodInfoPtr_Collect_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689965);
			VisionSensor.NativeMethodInfoPtr_ClearSensor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689966);
			VisionSensor.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr, 100689967);
		}

		// Token: 0x06014EA2 RID: 85666 RVA: 0x0000210C File Offset: 0x0000030C
		public VisionSensor(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007647 RID: 30279
		// (get) Token: 0x06014EA3 RID: 85667 RVA: 0x0054235C File Offset: 0x0054055C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionSensor>.NativeClassPtr));
			}
		}

		// Token: 0x17007648 RID: 30280
		// (get) Token: 0x06014EA4 RID: 85668 RVA: 0x00542370 File Offset: 0x00540570
		// (set) Token: 0x06014EA5 RID: 85669 RVA: 0x005423A4 File Offset: 0x005405A4
		public unsafe SensorTargetManager TargetManager
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_TargetManager);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new SensorTargetManager(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_TargetManager), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007649 RID: 30281
		// (get) Token: 0x06014EA6 RID: 85670 RVA: 0x005423CC File Offset: 0x005405CC
		// (set) Token: 0x06014EA7 RID: 85671 RVA: 0x00542400 File Offset: 0x00540600
		public unsafe List<Faction> Factions
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_Factions);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Faction>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_Factions), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700764A RID: 30282
		// (get) Token: 0x06014EA8 RID: 85672 RVA: 0x00542428 File Offset: 0x00540628
		// (set) Token: 0x06014EA9 RID: 85673 RVA: 0x0054245C File Offset: 0x0054065C
		public unsafe List<VisionFrustum> _frustums
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__frustums);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<VisionFrustum>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__frustums), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700764B RID: 30283
		// (get) Token: 0x06014EAA RID: 85674 RVA: 0x00542484 File Offset: 0x00540684
		// (set) Token: 0x06014EAB RID: 85675 RVA: 0x005424AC File Offset: 0x005406AC
		public unsafe LayerMask SightLayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_SightLayer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_SightLayer)) = value;
			}
		}

		// Token: 0x1700764C RID: 30284
		// (get) Token: 0x06014EAC RID: 85676 RVA: 0x005424D0 File Offset: 0x005406D0
		// (set) Token: 0x06014EAD RID: 85677 RVA: 0x00542504 File Offset: 0x00540704
		public unsafe VisionTarget Self
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_Self);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new VisionTarget(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_Self), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700764D RID: 30285
		// (get) Token: 0x06014EAE RID: 85678 RVA: 0x0054252C File Offset: 0x0054072C
		// (set) Token: 0x06014EAF RID: 85679 RVA: 0x00542560 File Offset: 0x00540760
		public unsafe Transform SightOrigin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_SightOrigin);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr_SightOrigin), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700764E RID: 30286
		// (get) Token: 0x06014EB0 RID: 85680 RVA: 0x00542588 File Offset: 0x00540788
		// (set) Token: 0x06014EB1 RID: 85681 RVA: 0x005425BC File Offset: 0x005407BC
		public unsafe VisionStatesData _data
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__data);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new VisionStatesData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__data), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700764F RID: 30287
		// (get) Token: 0x06014EB2 RID: 85682 RVA: 0x005425E4 File Offset: 0x005407E4
		// (set) Token: 0x06014EB3 RID: 85683 RVA: 0x0054260C File Offset: 0x0054080C
		public unsafe int _targetCheckOffset
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__targetCheckOffset);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionSensor.NativeFieldInfoPtr__targetCheckOffset)) = value;
			}
		}

		// Token: 0x0400D582 RID: 54658
		private static readonly IntPtr NativeFieldInfoPtr_TargetManager;

		// Token: 0x0400D583 RID: 54659
		private static readonly IntPtr NativeFieldInfoPtr_Factions;

		// Token: 0x0400D584 RID: 54660
		private static readonly IntPtr NativeFieldInfoPtr__frustums;

		// Token: 0x0400D585 RID: 54661
		private static readonly IntPtr NativeFieldInfoPtr_SightLayer;

		// Token: 0x0400D586 RID: 54662
		private static readonly IntPtr NativeFieldInfoPtr_Self;

		// Token: 0x0400D587 RID: 54663
		private static readonly IntPtr NativeFieldInfoPtr_SightOrigin;

		// Token: 0x0400D588 RID: 54664
		private static readonly IntPtr NativeFieldInfoPtr__data;

		// Token: 0x0400D589 RID: 54665
		private static readonly IntPtr NativeFieldInfoPtr__targetCheckOffset;

		// Token: 0x0400D58A RID: 54666
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_VisionStatesData_0;

		// Token: 0x0400D58B RID: 54667
		private static readonly IntPtr NativeMethodInfoPtr_SetUpVision_Public_Void_VisionStatesData_0;

		// Token: 0x0400D58C RID: 54668
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D58D RID: 54669
		private static readonly IntPtr NativeMethodInfoPtr_CanSeeTarget_Public_Boolean_DamageController_0;

		// Token: 0x0400D58E RID: 54670
		private static readonly IntPtr NativeMethodInfoPtr_CreateFrustums_Private_Void_0;

		// Token: 0x0400D58F RID: 54671
		private static readonly IntPtr NativeMethodInfoPtr_DestroyFrustums_Private_Void_0;

		// Token: 0x0400D590 RID: 54672
		private static readonly IntPtr NativeMethodInfoPtr_Collect_Public_Void_0;

		// Token: 0x0400D591 RID: 54673
		private static readonly IntPtr NativeMethodInfoPtr_ClearSensor_Public_Void_0;

		// Token: 0x0400D592 RID: 54674
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
