﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200115E RID: 4446
	public class AI_AdvanceInCover : AIState
	{
		// Token: 0x06014B49 RID: 84809 RVA: 0x00535CF8 File Offset: 0x00533EF8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_AdvanceInCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4A RID: 84810 RVA: 0x00535D48 File Offset: 0x00533F48
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_AdvanceInCover.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4B RID: 84811 RVA: 0x00535DB4 File Offset: 0x00533FB4
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_AdvanceInCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4C RID: 84812 RVA: 0x00535E14 File Offset: 0x00534014
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_AdvanceInCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4D RID: 84813 RVA: 0x00535E64 File Offset: 0x00534064
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_AdvanceInCover.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4E RID: 84814 RVA: 0x00535EA8 File Offset: 0x005340A8
		[CallerCount(0)]
		public unsafe AI_AdvanceInCover() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_AdvanceInCover.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B4F RID: 84815 RVA: 0x00535EF4 File Offset: 0x005340F4
		// Note: this type is marked as 'beforefieldinit'.
		static AI_AdvanceInCover()
		{
			Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_AdvanceInCover");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr);
			AI_AdvanceInCover.NativeFieldInfoPtr_BufferZone = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, "BufferZone");
			AI_AdvanceInCover.NativeFieldInfoPtr_PreferredAdvanceDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, "PreferredAdvanceDistance");
			AI_AdvanceInCover.NativeFieldInfoPtr_SearchRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, "SearchRadius");
			AI_AdvanceInCover.NativeFieldInfoPtr_ChanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, "ChanceToThrowSmoke");
			AI_AdvanceInCover.NativeFieldInfoPtr_MinDistanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, "MinDistanceToThrowSmoke");
			AI_AdvanceInCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689721);
			AI_AdvanceInCover.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689722);
			AI_AdvanceInCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689723);
			AI_AdvanceInCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689724);
			AI_AdvanceInCover.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689725);
			AI_AdvanceInCover.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr, 100689726);
		}

		// Token: 0x06014B50 RID: 84816 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_AdvanceInCover(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700752E RID: 29998
		// (get) Token: 0x06014B51 RID: 84817 RVA: 0x00536000 File Offset: 0x00534200
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_AdvanceInCover>.NativeClassPtr));
			}
		}

		// Token: 0x1700752F RID: 29999
		// (get) Token: 0x06014B52 RID: 84818 RVA: 0x00536014 File Offset: 0x00534214
		// (set) Token: 0x06014B53 RID: 84819 RVA: 0x0053603C File Offset: 0x0053423C
		public unsafe float BufferZone
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_BufferZone);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_BufferZone)) = value;
			}
		}

		// Token: 0x17007530 RID: 30000
		// (get) Token: 0x06014B54 RID: 84820 RVA: 0x00536060 File Offset: 0x00534260
		// (set) Token: 0x06014B55 RID: 84821 RVA: 0x00536088 File Offset: 0x00534288
		public unsafe float PreferredAdvanceDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_PreferredAdvanceDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_PreferredAdvanceDistance)) = value;
			}
		}

		// Token: 0x17007531 RID: 30001
		// (get) Token: 0x06014B56 RID: 84822 RVA: 0x005360AC File Offset: 0x005342AC
		// (set) Token: 0x06014B57 RID: 84823 RVA: 0x005360D4 File Offset: 0x005342D4
		public unsafe float SearchRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_SearchRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_SearchRadius)) = value;
			}
		}

		// Token: 0x17007532 RID: 30002
		// (get) Token: 0x06014B58 RID: 84824 RVA: 0x005360F8 File Offset: 0x005342F8
		// (set) Token: 0x06014B59 RID: 84825 RVA: 0x00536120 File Offset: 0x00534320
		public unsafe int ChanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_ChanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_ChanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x17007533 RID: 30003
		// (get) Token: 0x06014B5A RID: 84826 RVA: 0x00536144 File Offset: 0x00534344
		// (set) Token: 0x06014B5B RID: 84827 RVA: 0x0053616C File Offset: 0x0053436C
		public unsafe int MinDistanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_MinDistanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_AdvanceInCover.NativeFieldInfoPtr_MinDistanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x0400D3BC RID: 54204
		private static readonly IntPtr NativeFieldInfoPtr_BufferZone;

		// Token: 0x0400D3BD RID: 54205
		private static readonly IntPtr NativeFieldInfoPtr_PreferredAdvanceDistance;

		// Token: 0x0400D3BE RID: 54206
		private static readonly IntPtr NativeFieldInfoPtr_SearchRadius;

		// Token: 0x0400D3BF RID: 54207
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowSmoke;

		// Token: 0x0400D3C0 RID: 54208
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToThrowSmoke;

		// Token: 0x0400D3C1 RID: 54209
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3C2 RID: 54210
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D3C3 RID: 54211
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3C4 RID: 54212
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D3C5 RID: 54213
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D3C6 RID: 54214
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
