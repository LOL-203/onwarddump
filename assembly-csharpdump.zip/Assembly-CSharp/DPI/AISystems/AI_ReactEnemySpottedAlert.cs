﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001172 RID: 4466
	public class AI_ReactEnemySpottedAlert : AIState
	{
		// Token: 0x06014C8D RID: 85133 RVA: 0x0053A6D8 File Offset: 0x005388D8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactEnemySpottedAlert.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C8E RID: 85134 RVA: 0x0053A728 File Offset: 0x00538928
		[CallerCount(0)]
		public unsafe AI_ReactEnemySpottedAlert() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactEnemySpottedAlert.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C8F RID: 85135 RVA: 0x0053A774 File Offset: 0x00538974
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactEnemySpottedAlert()
		{
			Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactEnemySpottedAlert");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr);
			AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_DistanceToSuppressPercent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, "DistanceToSuppressPercent");
			AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_ChanceToFlankVsSuppress = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, "ChanceToFlankVsSuppress");
			AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToFlank = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, "MinDistanceToFlank");
			AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToGoToTarget = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, "MinDistanceToGoToTarget");
			AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_SightLayers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, "SightLayers");
			AI_ReactEnemySpottedAlert.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, 100689811);
			AI_ReactEnemySpottedAlert.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr, 100689812);
		}

		// Token: 0x06014C90 RID: 85136 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactEnemySpottedAlert(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007599 RID: 30105
		// (get) Token: 0x06014C91 RID: 85137 RVA: 0x0053A830 File Offset: 0x00538A30
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactEnemySpottedAlert>.NativeClassPtr));
			}
		}

		// Token: 0x1700759A RID: 30106
		// (get) Token: 0x06014C92 RID: 85138 RVA: 0x0053A844 File Offset: 0x00538A44
		// (set) Token: 0x06014C93 RID: 85139 RVA: 0x0053A86C File Offset: 0x00538A6C
		public unsafe float DistanceToSuppressPercent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_DistanceToSuppressPercent);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_DistanceToSuppressPercent)) = value;
			}
		}

		// Token: 0x1700759B RID: 30107
		// (get) Token: 0x06014C94 RID: 85140 RVA: 0x0053A890 File Offset: 0x00538A90
		// (set) Token: 0x06014C95 RID: 85141 RVA: 0x0053A8B8 File Offset: 0x00538AB8
		public unsafe int ChanceToFlankVsSuppress
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_ChanceToFlankVsSuppress);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_ChanceToFlankVsSuppress)) = value;
			}
		}

		// Token: 0x1700759C RID: 30108
		// (get) Token: 0x06014C96 RID: 85142 RVA: 0x0053A8DC File Offset: 0x00538ADC
		// (set) Token: 0x06014C97 RID: 85143 RVA: 0x0053A904 File Offset: 0x00538B04
		public unsafe float MinDistanceToFlank
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToFlank);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToFlank)) = value;
			}
		}

		// Token: 0x1700759D RID: 30109
		// (get) Token: 0x06014C98 RID: 85144 RVA: 0x0053A928 File Offset: 0x00538B28
		// (set) Token: 0x06014C99 RID: 85145 RVA: 0x0053A950 File Offset: 0x00538B50
		public unsafe float MinDistanceToGoToTarget
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToGoToTarget);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_MinDistanceToGoToTarget)) = value;
			}
		}

		// Token: 0x1700759E RID: 30110
		// (get) Token: 0x06014C9A RID: 85146 RVA: 0x0053A974 File Offset: 0x00538B74
		// (set) Token: 0x06014C9B RID: 85147 RVA: 0x0053A99C File Offset: 0x00538B9C
		public unsafe LayerMask SightLayers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_SightLayers);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactEnemySpottedAlert.NativeFieldInfoPtr_SightLayers)) = value;
			}
		}

		// Token: 0x0400D46D RID: 54381
		private static readonly IntPtr NativeFieldInfoPtr_DistanceToSuppressPercent;

		// Token: 0x0400D46E RID: 54382
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToFlankVsSuppress;

		// Token: 0x0400D46F RID: 54383
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToFlank;

		// Token: 0x0400D470 RID: 54384
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToGoToTarget;

		// Token: 0x0400D471 RID: 54385
		private static readonly IntPtr NativeFieldInfoPtr_SightLayers;

		// Token: 0x0400D472 RID: 54386
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D473 RID: 54387
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
