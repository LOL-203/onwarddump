﻿using System;
using DPI.AISystems.Waypoints;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200116F RID: 4463
	public class AI_Patrol : AIState_PassiveBarks
	{
		// Token: 0x06014C50 RID: 85072 RVA: 0x0053988C File Offset: 0x00537A8C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Patrol.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C51 RID: 85073 RVA: 0x005398DC File Offset: 0x00537ADC
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Patrol.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C52 RID: 85074 RVA: 0x0053993C File Offset: 0x00537B3C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Patrol.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C53 RID: 85075 RVA: 0x0053998C File Offset: 0x00537B8C
		[CallerCount(0)]
		public unsafe void MoveNextPointLooping()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Patrol.NativeMethodInfoPtr_MoveNextPointLooping_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C54 RID: 85076 RVA: 0x005399D0 File Offset: 0x00537BD0
		[CallerCount(0)]
		public unsafe void MoveToNextPoint()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Patrol.NativeMethodInfoPtr_MoveToNextPoint_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C55 RID: 85077 RVA: 0x00539A14 File Offset: 0x00537C14
		[CallerCount(0)]
		public unsafe AI_Patrol() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Patrol.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C56 RID: 85078 RVA: 0x00539A60 File Offset: 0x00537C60
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Patrol()
		{
			Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Patrol");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr);
			AI_Patrol.NativeFieldInfoPtr_MaxWaypointSearchRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, "MaxWaypointSearchRadius");
			AI_Patrol.NativeFieldInfoPtr__waypointSet = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, "_waypointSet");
			AI_Patrol.NativeFieldInfoPtr__index = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, "_index");
			AI_Patrol.NativeFieldInfoPtr__forward = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, "_forward");
			AI_Patrol.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689793);
			AI_Patrol.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689794);
			AI_Patrol.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689795);
			AI_Patrol.NativeMethodInfoPtr_MoveNextPointLooping_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689796);
			AI_Patrol.NativeMethodInfoPtr_MoveToNextPoint_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689797);
			AI_Patrol.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr, 100689798);
		}

		// Token: 0x06014C57 RID: 85079 RVA: 0x005387F4 File Offset: 0x005369F4
		public AI_Patrol(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007585 RID: 30085
		// (get) Token: 0x06014C58 RID: 85080 RVA: 0x00539B58 File Offset: 0x00537D58
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Patrol>.NativeClassPtr));
			}
		}

		// Token: 0x17007586 RID: 30086
		// (get) Token: 0x06014C59 RID: 85081 RVA: 0x00539B6C File Offset: 0x00537D6C
		// (set) Token: 0x06014C5A RID: 85082 RVA: 0x00539B94 File Offset: 0x00537D94
		public unsafe float MaxWaypointSearchRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr_MaxWaypointSearchRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr_MaxWaypointSearchRadius)) = value;
			}
		}

		// Token: 0x17007587 RID: 30087
		// (get) Token: 0x06014C5B RID: 85083 RVA: 0x00539BB8 File Offset: 0x00537DB8
		// (set) Token: 0x06014C5C RID: 85084 RVA: 0x00539BEC File Offset: 0x00537DEC
		public unsafe WayPointData _waypointSet
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__waypointSet);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WayPointData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__waypointSet), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007588 RID: 30088
		// (get) Token: 0x06014C5D RID: 85085 RVA: 0x00539C14 File Offset: 0x00537E14
		// (set) Token: 0x06014C5E RID: 85086 RVA: 0x00539C3C File Offset: 0x00537E3C
		public unsafe int _index
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__index);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__index)) = value;
			}
		}

		// Token: 0x17007589 RID: 30089
		// (get) Token: 0x06014C5F RID: 85087 RVA: 0x00539C60 File Offset: 0x00537E60
		// (set) Token: 0x06014C60 RID: 85088 RVA: 0x00539C88 File Offset: 0x00537E88
		public unsafe bool _forward
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__forward);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Patrol.NativeFieldInfoPtr__forward)) = value;
			}
		}

		// Token: 0x0400D44A RID: 54346
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaypointSearchRadius;

		// Token: 0x0400D44B RID: 54347
		private static readonly IntPtr NativeFieldInfoPtr__waypointSet;

		// Token: 0x0400D44C RID: 54348
		private static readonly IntPtr NativeFieldInfoPtr__index;

		// Token: 0x0400D44D RID: 54349
		private static readonly IntPtr NativeFieldInfoPtr__forward;

		// Token: 0x0400D44E RID: 54350
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D44F RID: 54351
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D450 RID: 54352
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D451 RID: 54353
		private static readonly IntPtr NativeMethodInfoPtr_MoveNextPointLooping_Private_Void_0;

		// Token: 0x0400D452 RID: 54354
		private static readonly IntPtr NativeMethodInfoPtr_MoveToNextPoint_Private_Void_0;

		// Token: 0x0400D453 RID: 54355
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
