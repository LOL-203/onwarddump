﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001197 RID: 4503
	public class VisionPoint : MonoBehaviour
	{
		// Token: 0x06014E92 RID: 85650 RVA: 0x00541E04 File Offset: 0x00540004
		[CallerCount(0)]
		public unsafe VisionPoint() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisionPoint>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionPoint.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E93 RID: 85651 RVA: 0x00541E50 File Offset: 0x00540050
		// Note: this type is marked as 'beforefieldinit'.
		static VisionPoint()
		{
			Il2CppClassPointerStore<VisionPoint>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionPoint");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionPoint>.NativeClassPtr);
			VisionPoint.NativeFieldInfoPtr_Transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionPoint>.NativeClassPtr, "Transform");
			VisionPoint.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionPoint>.NativeClassPtr, 100689958);
		}

		// Token: 0x06014E94 RID: 85652 RVA: 0x0000210C File Offset: 0x0000030C
		public VisionPoint(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007645 RID: 30277
		// (get) Token: 0x06014E95 RID: 85653 RVA: 0x00541EA8 File Offset: 0x005400A8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionPoint>.NativeClassPtr));
			}
		}

		// Token: 0x17007646 RID: 30278
		// (get) Token: 0x06014E96 RID: 85654 RVA: 0x00541EBC File Offset: 0x005400BC
		// (set) Token: 0x06014E97 RID: 85655 RVA: 0x00541EF0 File Offset: 0x005400F0
		public unsafe Transform Transform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionPoint.NativeFieldInfoPtr_Transform);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionPoint.NativeFieldInfoPtr_Transform), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D580 RID: 54656
		private static readonly IntPtr NativeFieldInfoPtr_Transform;

		// Token: 0x0400D581 RID: 54657
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
