﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Locators;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x0200118D RID: 4493
	public class AI_ThrowSmokeGrenade : AIState
	{
		// Token: 0x06014E08 RID: 85512 RVA: 0x0053FE28 File Offset: 0x0053E028
		[CallerCount(0)]
		public new unsafe Vector3 GetStateDrivenLookPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowSmokeGrenade.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014E09 RID: 85513 RVA: 0x0053FE84 File Offset: 0x0053E084
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E0A RID: 85514 RVA: 0x0053FED4 File Offset: 0x0053E0D4
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E0B RID: 85515 RVA: 0x0053FF24 File Offset: 0x0053E124
		[CallerCount(0)]
		public unsafe IEnumerator Throw()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Throw_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06014E0C RID: 85516 RVA: 0x0053FF7C File Offset: 0x0053E17C
		[CallerCount(0)]
		public unsafe AI_ThrowSmokeGrenade() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E0D RID: 85517 RVA: 0x0053FFC8 File Offset: 0x0053E1C8
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ThrowSmokeGrenade()
		{
			Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ThrowSmokeGrenade");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr);
			AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MinThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "MinThrowAccuracy");
			AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "MaxThrowAccuracy");
			AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "MaxThrowDistance");
			AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwrutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "_throwrutine");
			AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "_throwPosition");
			AI_ThrowSmokeGrenade.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, 100689921);
			AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, 100689922);
			AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, 100689923);
			AI_ThrowSmokeGrenade.NativeMethodInfoPtr_Throw_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, 100689924);
			AI_ThrowSmokeGrenade.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, 100689925);
		}

		// Token: 0x06014E0E RID: 85518 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ThrowSmokeGrenade(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007616 RID: 30230
		// (get) Token: 0x06014E0F RID: 85519 RVA: 0x005400C0 File Offset: 0x0053E2C0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr));
			}
		}

		// Token: 0x17007617 RID: 30231
		// (get) Token: 0x06014E10 RID: 85520 RVA: 0x005400D4 File Offset: 0x0053E2D4
		// (set) Token: 0x06014E11 RID: 85521 RVA: 0x005400FC File Offset: 0x0053E2FC
		public unsafe float MinThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MinThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MinThrowAccuracy)) = value;
			}
		}

		// Token: 0x17007618 RID: 30232
		// (get) Token: 0x06014E12 RID: 85522 RVA: 0x00540120 File Offset: 0x0053E320
		// (set) Token: 0x06014E13 RID: 85523 RVA: 0x00540148 File Offset: 0x0053E348
		public unsafe float MaxThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowAccuracy)) = value;
			}
		}

		// Token: 0x17007619 RID: 30233
		// (get) Token: 0x06014E14 RID: 85524 RVA: 0x0054016C File Offset: 0x0053E36C
		// (set) Token: 0x06014E15 RID: 85525 RVA: 0x00540194 File Offset: 0x0053E394
		public unsafe float MaxThrowDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr_MaxThrowDistance)) = value;
			}
		}

		// Token: 0x1700761A RID: 30234
		// (get) Token: 0x06014E16 RID: 85526 RVA: 0x005401B8 File Offset: 0x0053E3B8
		// (set) Token: 0x06014E17 RID: 85527 RVA: 0x005401EC File Offset: 0x0053E3EC
		public unsafe Coroutine _throwrutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwrutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwrutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700761B RID: 30235
		// (get) Token: 0x06014E18 RID: 85528 RVA: 0x00540214 File Offset: 0x0053E414
		// (set) Token: 0x06014E19 RID: 85529 RVA: 0x0054023C File Offset: 0x0053E43C
		public unsafe Vector3 _throwPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade.NativeFieldInfoPtr__throwPosition)) = value;
			}
		}

		// Token: 0x0400D539 RID: 54585
		private static readonly IntPtr NativeFieldInfoPtr_MinThrowAccuracy;

		// Token: 0x0400D53A RID: 54586
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowAccuracy;

		// Token: 0x0400D53B RID: 54587
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowDistance;

		// Token: 0x0400D53C RID: 54588
		private static readonly IntPtr NativeFieldInfoPtr__throwrutine;

		// Token: 0x0400D53D RID: 54589
		private static readonly IntPtr NativeFieldInfoPtr__throwPosition;

		// Token: 0x0400D53E RID: 54590
		private static readonly IntPtr NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0;

		// Token: 0x0400D53F RID: 54591
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D540 RID: 54592
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D541 RID: 54593
		private static readonly IntPtr NativeMethodInfoPtr_Throw_Private_IEnumerator_0;

		// Token: 0x0400D542 RID: 54594
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200118E RID: 4494
		[ObfuscatedName("DPI.AISystems.AI_ThrowSmokeGrenade/<Throw>d__8")]
		public sealed class _Throw_d__8 : Il2CppSystem.Object
		{
			// Token: 0x06014E1A RID: 85530 RVA: 0x00540260 File Offset: 0x0053E460
			[CallerCount(0)]
			public unsafe _Throw_d__8(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014E1B RID: 85531 RVA: 0x005402C0 File Offset: 0x0053E4C0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014E1C RID: 85532 RVA: 0x00540304 File Offset: 0x0053E504
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17007623 RID: 30243
			// (get) Token: 0x06014E1D RID: 85533 RVA: 0x00540354 File Offset: 0x0053E554
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014E1E RID: 85534 RVA: 0x005403AC File Offset: 0x0053E5AC
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17007624 RID: 30244
			// (get) Token: 0x06014E1F RID: 85535 RVA: 0x005403F0 File Offset: 0x0053E5F0
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014E20 RID: 85536 RVA: 0x00540448 File Offset: 0x0053E648
			// Note: this type is marked as 'beforefieldinit'.
			static _Throw_d__8()
			{
				Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AI_ThrowSmokeGrenade>.NativeClassPtr, "<Throw>d__8");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<>1__state");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<>2__current");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<>4__this");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<startLocator>5__2");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<currentWeapon>5__3");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, "<grenade>5__4");
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689926);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689927);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689928);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689929);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689930);
				AI_ThrowSmokeGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr, 100689931);
			}

			// Token: 0x06014E21 RID: 85537 RVA: 0x00002988 File Offset: 0x00000B88
			public _Throw_d__8(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700761C RID: 30236
			// (get) Token: 0x06014E22 RID: 85538 RVA: 0x00540563 File Offset: 0x0053E763
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowSmokeGrenade._Throw_d__8>.NativeClassPtr));
				}
			}

			// Token: 0x1700761D RID: 30237
			// (get) Token: 0x06014E23 RID: 85539 RVA: 0x00540574 File Offset: 0x0053E774
			// (set) Token: 0x06014E24 RID: 85540 RVA: 0x0054059C File Offset: 0x0053E79C
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x1700761E RID: 30238
			// (get) Token: 0x06014E25 RID: 85541 RVA: 0x005405C0 File Offset: 0x0053E7C0
			// (set) Token: 0x06014E26 RID: 85542 RVA: 0x005405F4 File Offset: 0x0053E7F4
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x1700761F RID: 30239
			// (get) Token: 0x06014E27 RID: 85543 RVA: 0x0054061C File Offset: 0x0053E81C
			// (set) Token: 0x06014E28 RID: 85544 RVA: 0x00540650 File Offset: 0x0053E850
			public unsafe AI_ThrowSmokeGrenade __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new AI_ThrowSmokeGrenade(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007620 RID: 30240
			// (get) Token: 0x06014E29 RID: 85545 RVA: 0x00540678 File Offset: 0x0053E878
			// (set) Token: 0x06014E2A RID: 85546 RVA: 0x005406AC File Offset: 0x0053E8AC
			public unsafe Locator _startLocator_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Locator(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007621 RID: 30241
			// (get) Token: 0x06014E2B RID: 85547 RVA: 0x005406D4 File Offset: 0x0053E8D4
			// (set) Token: 0x06014E2C RID: 85548 RVA: 0x00540708 File Offset: 0x0053E908
			public unsafe Pickup _currentWeapon_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007622 RID: 30242
			// (get) Token: 0x06014E2D RID: 85549 RVA: 0x00540730 File Offset: 0x0053E930
			// (set) Token: 0x06014E2E RID: 85550 RVA: 0x00540764 File Offset: 0x0053E964
			public unsafe Pickup_Grenade _grenade_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup_Grenade(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowSmokeGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400D543 RID: 54595
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400D544 RID: 54596
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400D545 RID: 54597
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400D546 RID: 54598
			private static readonly IntPtr NativeFieldInfoPtr__startLocator_5__2;

			// Token: 0x0400D547 RID: 54599
			private static readonly IntPtr NativeFieldInfoPtr__currentWeapon_5__3;

			// Token: 0x0400D548 RID: 54600
			private static readonly IntPtr NativeFieldInfoPtr__grenade_5__4;

			// Token: 0x0400D549 RID: 54601
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400D54A RID: 54602
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D54B RID: 54603
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400D54C RID: 54604
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400D54D RID: 54605
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D54E RID: 54606
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
