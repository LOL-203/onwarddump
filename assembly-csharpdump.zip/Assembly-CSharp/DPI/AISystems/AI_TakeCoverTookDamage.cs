﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001188 RID: 4488
	public class AI_TakeCoverTookDamage : AIState
	{
		// Token: 0x06014DAD RID: 85421 RVA: 0x0053E7D8 File Offset: 0x0053C9D8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverTookDamage.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DAE RID: 85422 RVA: 0x0053E828 File Offset: 0x0053CA28
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverTookDamage.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DAF RID: 85423 RVA: 0x0053E894 File Offset: 0x0053CA94
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverTookDamage.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DB0 RID: 85424 RVA: 0x0053E8F4 File Offset: 0x0053CAF4
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverTookDamage.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DB1 RID: 85425 RVA: 0x0053E944 File Offset: 0x0053CB44
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverTookDamage.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DB2 RID: 85426 RVA: 0x0053E988 File Offset: 0x0053CB88
		[CallerCount(0)]
		public unsafe AI_TakeCoverTookDamage() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverTookDamage.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DB3 RID: 85427 RVA: 0x0053E9D4 File Offset: 0x0053CBD4
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCoverTookDamage()
		{
			Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCoverTookDamage");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr);
			AI_TakeCoverTookDamage.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, "MaxCoverDistance");
			AI_TakeCoverTookDamage.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689893);
			AI_TakeCoverTookDamage.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689894);
			AI_TakeCoverTookDamage.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689895);
			AI_TakeCoverTookDamage.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689896);
			AI_TakeCoverTookDamage.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689897);
			AI_TakeCoverTookDamage.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr, 100689898);
		}

		// Token: 0x06014DB4 RID: 85428 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCoverTookDamage(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075F5 RID: 30197
		// (get) Token: 0x06014DB5 RID: 85429 RVA: 0x0053EA90 File Offset: 0x0053CC90
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCoverTookDamage>.NativeClassPtr));
			}
		}

		// Token: 0x170075F6 RID: 30198
		// (get) Token: 0x06014DB6 RID: 85430 RVA: 0x0053EAA4 File Offset: 0x0053CCA4
		// (set) Token: 0x06014DB7 RID: 85431 RVA: 0x0053EACC File Offset: 0x0053CCCC
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverTookDamage.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverTookDamage.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x0400D505 RID: 54533
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D506 RID: 54534
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D507 RID: 54535
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D508 RID: 54536
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D509 RID: 54537
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D50A RID: 54538
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D50B RID: 54539
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
