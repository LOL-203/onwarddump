﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001174 RID: 4468
	public class AI_ReactFragGrenade : AIState
	{
		// Token: 0x06014CA3 RID: 85155 RVA: 0x0053AB28 File Offset: 0x00538D28
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactFragGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CA4 RID: 85156 RVA: 0x0053AB78 File Offset: 0x00538D78
		[CallerCount(0)]
		public unsafe AI_ReactFragGrenade() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactFragGrenade.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CA5 RID: 85157 RVA: 0x0053ABC4 File Offset: 0x00538DC4
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactFragGrenade()
		{
			Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactFragGrenade");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr);
			AI_ReactFragGrenade.NativeFieldInfoPtr_ChanceToRunFromGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr, "ChanceToRunFromGrenade");
			AI_ReactFragGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr, 100689815);
			AI_ReactFragGrenade.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr, 100689816);
		}

		// Token: 0x06014CA6 RID: 85158 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactFragGrenade(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075A1 RID: 30113
		// (get) Token: 0x06014CA7 RID: 85159 RVA: 0x0053AC30 File Offset: 0x00538E30
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactFragGrenade>.NativeClassPtr));
			}
		}

		// Token: 0x170075A2 RID: 30114
		// (get) Token: 0x06014CA8 RID: 85160 RVA: 0x0053AC44 File Offset: 0x00538E44
		// (set) Token: 0x06014CA9 RID: 85161 RVA: 0x0053AC6C File Offset: 0x00538E6C
		public unsafe int ChanceToRunFromGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFragGrenade.NativeFieldInfoPtr_ChanceToRunFromGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFragGrenade.NativeFieldInfoPtr_ChanceToRunFromGrenade)) = value;
			}
		}

		// Token: 0x0400D477 RID: 54391
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToRunFromGrenade;

		// Token: 0x0400D478 RID: 54392
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D479 RID: 54393
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
