﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001171 RID: 4465
	public class AI_Pursue : AIState
	{
		// Token: 0x06014C76 RID: 85110 RVA: 0x0053A18C File Offset: 0x0053838C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Pursue.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C77 RID: 85111 RVA: 0x0053A1DC File Offset: 0x005383DC
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Pursue.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C78 RID: 85112 RVA: 0x0053A22C File Offset: 0x0053842C
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Pursue.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C79 RID: 85113 RVA: 0x0053A270 File Offset: 0x00538470
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Pursue.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C7A RID: 85114 RVA: 0x0053A2D0 File Offset: 0x005384D0
		[CallerCount(0)]
		public unsafe void OnPathThroughDoor(NavigationNode doorNode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(doorNode));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Pursue.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C7B RID: 85115 RVA: 0x0053A330 File Offset: 0x00538530
		[CallerCount(0)]
		public unsafe AI_Pursue() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Pursue.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C7C RID: 85116 RVA: 0x0053A37C File Offset: 0x0053857C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Pursue()
		{
			Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Pursue");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr);
			AI_Pursue.NativeFieldInfoPtr_MinDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MinDistance");
			AI_Pursue.NativeFieldInfoPtr_MaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MaxDistance");
			AI_Pursue.NativeFieldInfoPtr_MinFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MinFlashDistance");
			AI_Pursue.NativeFieldInfoPtr_MaxFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MaxFlashDistance");
			AI_Pursue.NativeFieldInfoPtr_MinFriendlySafeFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MinFriendlySafeFlashDistance");
			AI_Pursue.NativeFieldInfoPtr_MaxTargetFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "MaxTargetFlashDistance");
			AI_Pursue.NativeFieldInfoPtr__movePosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, "_movePosition");
			AI_Pursue.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689805);
			AI_Pursue.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689806);
			AI_Pursue.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689807);
			AI_Pursue.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689808);
			AI_Pursue.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689809);
			AI_Pursue.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr, 100689810);
		}

		// Token: 0x06014C7D RID: 85117 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_Pursue(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007591 RID: 30097
		// (get) Token: 0x06014C7E RID: 85118 RVA: 0x0053A4B0 File Offset: 0x005386B0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Pursue>.NativeClassPtr));
			}
		}

		// Token: 0x17007592 RID: 30098
		// (get) Token: 0x06014C7F RID: 85119 RVA: 0x0053A4C4 File Offset: 0x005386C4
		// (set) Token: 0x06014C80 RID: 85120 RVA: 0x0053A4EC File Offset: 0x005386EC
		public unsafe float MinDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinDistance)) = value;
			}
		}

		// Token: 0x17007593 RID: 30099
		// (get) Token: 0x06014C81 RID: 85121 RVA: 0x0053A510 File Offset: 0x00538710
		// (set) Token: 0x06014C82 RID: 85122 RVA: 0x0053A538 File Offset: 0x00538738
		public unsafe float MaxDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxDistance)) = value;
			}
		}

		// Token: 0x17007594 RID: 30100
		// (get) Token: 0x06014C83 RID: 85123 RVA: 0x0053A55C File Offset: 0x0053875C
		// (set) Token: 0x06014C84 RID: 85124 RVA: 0x0053A584 File Offset: 0x00538784
		public unsafe float MinFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinFlashDistance)) = value;
			}
		}

		// Token: 0x17007595 RID: 30101
		// (get) Token: 0x06014C85 RID: 85125 RVA: 0x0053A5A8 File Offset: 0x005387A8
		// (set) Token: 0x06014C86 RID: 85126 RVA: 0x0053A5D0 File Offset: 0x005387D0
		public unsafe float MaxFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxFlashDistance)) = value;
			}
		}

		// Token: 0x17007596 RID: 30102
		// (get) Token: 0x06014C87 RID: 85127 RVA: 0x0053A5F4 File Offset: 0x005387F4
		// (set) Token: 0x06014C88 RID: 85128 RVA: 0x0053A61C File Offset: 0x0053881C
		public unsafe float MinFriendlySafeFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinFriendlySafeFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MinFriendlySafeFlashDistance)) = value;
			}
		}

		// Token: 0x17007597 RID: 30103
		// (get) Token: 0x06014C89 RID: 85129 RVA: 0x0053A640 File Offset: 0x00538840
		// (set) Token: 0x06014C8A RID: 85130 RVA: 0x0053A668 File Offset: 0x00538868
		public unsafe float MaxTargetFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxTargetFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr_MaxTargetFlashDistance)) = value;
			}
		}

		// Token: 0x17007598 RID: 30104
		// (get) Token: 0x06014C8B RID: 85131 RVA: 0x0053A68C File Offset: 0x0053888C
		// (set) Token: 0x06014C8C RID: 85132 RVA: 0x0053A6B4 File Offset: 0x005388B4
		public unsafe Vector3 _movePosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr__movePosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Pursue.NativeFieldInfoPtr__movePosition)) = value;
			}
		}

		// Token: 0x0400D460 RID: 54368
		private static readonly IntPtr NativeFieldInfoPtr_MinDistance;

		// Token: 0x0400D461 RID: 54369
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistance;

		// Token: 0x0400D462 RID: 54370
		private static readonly IntPtr NativeFieldInfoPtr_MinFlashDistance;

		// Token: 0x0400D463 RID: 54371
		private static readonly IntPtr NativeFieldInfoPtr_MaxFlashDistance;

		// Token: 0x0400D464 RID: 54372
		private static readonly IntPtr NativeFieldInfoPtr_MinFriendlySafeFlashDistance;

		// Token: 0x0400D465 RID: 54373
		private static readonly IntPtr NativeFieldInfoPtr_MaxTargetFlashDistance;

		// Token: 0x0400D466 RID: 54374
		private static readonly IntPtr NativeFieldInfoPtr__movePosition;

		// Token: 0x0400D467 RID: 54375
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D468 RID: 54376
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D469 RID: 54377
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D46A RID: 54378
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D46B RID: 54379
		private static readonly IntPtr NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0;

		// Token: 0x0400D46C RID: 54380
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
