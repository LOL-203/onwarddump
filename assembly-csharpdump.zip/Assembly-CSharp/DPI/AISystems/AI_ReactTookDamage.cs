﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001179 RID: 4473
	public class AI_ReactTookDamage : AIState
	{
		// Token: 0x06014CDA RID: 85210 RVA: 0x0053B688 File Offset: 0x00539888
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactTookDamage.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CDB RID: 85211 RVA: 0x0053B6D8 File Offset: 0x005398D8
		[CallerCount(0)]
		public unsafe AI_ReactTookDamage() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactTookDamage.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CDC RID: 85212 RVA: 0x0053B724 File Offset: 0x00539924
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactTookDamage()
		{
			Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactTookDamage");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr);
			AI_ReactTookDamage.NativeFieldInfoPtr_ChanceToReturnFire = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr, "ChanceToReturnFire");
			AI_ReactTookDamage.NativeFieldInfoPtr_ForceReturnFireDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr, "ForceReturnFireDistance");
			AI_ReactTookDamage.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr, 100689827);
			AI_ReactTookDamage.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr, 100689828);
		}

		// Token: 0x06014CDD RID: 85213 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactTookDamage(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075B4 RID: 30132
		// (get) Token: 0x06014CDE RID: 85214 RVA: 0x0053B7A4 File Offset: 0x005399A4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactTookDamage>.NativeClassPtr));
			}
		}

		// Token: 0x170075B5 RID: 30133
		// (get) Token: 0x06014CDF RID: 85215 RVA: 0x0053B7B8 File Offset: 0x005399B8
		// (set) Token: 0x06014CE0 RID: 85216 RVA: 0x0053B7E0 File Offset: 0x005399E0
		public unsafe int ChanceToReturnFire
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactTookDamage.NativeFieldInfoPtr_ChanceToReturnFire);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactTookDamage.NativeFieldInfoPtr_ChanceToReturnFire)) = value;
			}
		}

		// Token: 0x170075B6 RID: 30134
		// (get) Token: 0x06014CE1 RID: 85217 RVA: 0x0053B804 File Offset: 0x00539A04
		// (set) Token: 0x06014CE2 RID: 85218 RVA: 0x0053B82C File Offset: 0x00539A2C
		public unsafe float ForceReturnFireDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactTookDamage.NativeFieldInfoPtr_ForceReturnFireDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactTookDamage.NativeFieldInfoPtr_ForceReturnFireDistance)) = value;
			}
		}

		// Token: 0x0400D491 RID: 54417
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToReturnFire;

		// Token: 0x0400D492 RID: 54418
		private static readonly IntPtr NativeFieldInfoPtr_ForceReturnFireDistance;

		// Token: 0x0400D493 RID: 54419
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D494 RID: 54420
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
