﻿using System;
using DPI.Data;
using Il2CppSystem;
using Onward.AI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200119B RID: 4507
	public class EvacDifficultyData : BaseData
	{
		// Token: 0x06014ED7 RID: 85719 RVA: 0x00542E2C File Offset: 0x0054102C
		[CallerCount(0)]
		public unsafe EvacDifficultyData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacDifficultyData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014ED8 RID: 85720 RVA: 0x00542E78 File Offset: 0x00541078
		// Note: this type is marked as 'beforefieldinit'.
		static EvacDifficultyData()
		{
			Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "EvacDifficultyData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr);
			EvacDifficultyData.NativeFieldInfoPtr_DifficultyLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr, "DifficultyLevel");
			EvacDifficultyData.NativeFieldInfoPtr_SpawnInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr, "SpawnInterval");
			EvacDifficultyData.NativeFieldInfoPtr_SpawnenedPerWave = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr, "SpawnenedPerWave");
			EvacDifficultyData.NativeFieldInfoPtr_MaxLiveCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr, "MaxLiveCount");
			EvacDifficultyData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr, 100689978);
		}

		// Token: 0x06014ED9 RID: 85721 RVA: 0x000AD628 File Offset: 0x000AB828
		public EvacDifficultyData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700765C RID: 30300
		// (get) Token: 0x06014EDA RID: 85722 RVA: 0x00542F0C File Offset: 0x0054110C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<EvacDifficultyData>.NativeClassPtr));
			}
		}

		// Token: 0x1700765D RID: 30301
		// (get) Token: 0x06014EDB RID: 85723 RVA: 0x00542F20 File Offset: 0x00541120
		// (set) Token: 0x06014EDC RID: 85724 RVA: 0x00542F48 File Offset: 0x00541148
		public unsafe DifficultyLevel DifficultyLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_DifficultyLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_DifficultyLevel)) = value;
			}
		}

		// Token: 0x1700765E RID: 30302
		// (get) Token: 0x06014EDD RID: 85725 RVA: 0x00542F6C File Offset: 0x0054116C
		// (set) Token: 0x06014EDE RID: 85726 RVA: 0x00542F94 File Offset: 0x00541194
		public unsafe float SpawnInterval
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_SpawnInterval);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_SpawnInterval)) = value;
			}
		}

		// Token: 0x1700765F RID: 30303
		// (get) Token: 0x06014EDF RID: 85727 RVA: 0x00542FB8 File Offset: 0x005411B8
		// (set) Token: 0x06014EE0 RID: 85728 RVA: 0x00542FE0 File Offset: 0x005411E0
		public unsafe int SpawnenedPerWave
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_SpawnenedPerWave);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_SpawnenedPerWave)) = value;
			}
		}

		// Token: 0x17007660 RID: 30304
		// (get) Token: 0x06014EE1 RID: 85729 RVA: 0x00543004 File Offset: 0x00541204
		// (set) Token: 0x06014EE2 RID: 85730 RVA: 0x0054302C File Offset: 0x0054122C
		public unsafe int MaxLiveCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_MaxLiveCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacDifficultyData.NativeFieldInfoPtr_MaxLiveCount)) = value;
			}
		}

		// Token: 0x0400D5A6 RID: 54694
		private static readonly IntPtr NativeFieldInfoPtr_DifficultyLevel;

		// Token: 0x0400D5A7 RID: 54695
		private static readonly IntPtr NativeFieldInfoPtr_SpawnInterval;

		// Token: 0x0400D5A8 RID: 54696
		private static readonly IntPtr NativeFieldInfoPtr_SpawnenedPerWave;

		// Token: 0x0400D5A9 RID: 54697
		private static readonly IntPtr NativeFieldInfoPtr_MaxLiveCount;

		// Token: 0x0400D5AA RID: 54698
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
