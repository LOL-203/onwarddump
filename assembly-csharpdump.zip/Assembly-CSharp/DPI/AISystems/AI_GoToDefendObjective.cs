﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001165 RID: 4453
	public class AI_GoToDefendObjective : AIState
	{
		// Token: 0x06014BBE RID: 84926 RVA: 0x005376D0 File Offset: 0x005358D0
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToDefendObjective.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BBF RID: 84927 RVA: 0x00537720 File Offset: 0x00535920
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToDefendObjective.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BC0 RID: 84928 RVA: 0x0053778C File Offset: 0x0053598C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToDefendObjective.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BC1 RID: 84929 RVA: 0x005377DC File Offset: 0x005359DC
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToDefendObjective.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BC2 RID: 84930 RVA: 0x0053783C File Offset: 0x00535A3C
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToDefendObjective.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BC3 RID: 84931 RVA: 0x00537880 File Offset: 0x00535A80
		[CallerCount(0)]
		public unsafe AI_GoToDefendObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BC4 RID: 84932 RVA: 0x005378CC File Offset: 0x00535ACC
		// Note: this type is marked as 'beforefieldinit'.
		static AI_GoToDefendObjective()
		{
			Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_GoToDefendObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr);
			AI_GoToDefendObjective.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, "MaxCoverDistance");
			AI_GoToDefendObjective.NativeFieldInfoPtr__position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, "_position");
			AI_GoToDefendObjective.NativeFieldInfoPtr__direction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, "_direction");
			AI_GoToDefendObjective.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689749);
			AI_GoToDefendObjective.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689750);
			AI_GoToDefendObjective.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689751);
			AI_GoToDefendObjective.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689752);
			AI_GoToDefendObjective.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689753);
			AI_GoToDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr, 100689754);
		}

		// Token: 0x06014BC5 RID: 84933 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_GoToDefendObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007557 RID: 30039
		// (get) Token: 0x06014BC6 RID: 84934 RVA: 0x005379B0 File Offset: 0x00535BB0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_GoToDefendObjective>.NativeClassPtr));
			}
		}

		// Token: 0x17007558 RID: 30040
		// (get) Token: 0x06014BC7 RID: 84935 RVA: 0x005379C4 File Offset: 0x00535BC4
		// (set) Token: 0x06014BC8 RID: 84936 RVA: 0x005379EC File Offset: 0x00535BEC
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x17007559 RID: 30041
		// (get) Token: 0x06014BC9 RID: 84937 RVA: 0x00537A10 File Offset: 0x00535C10
		// (set) Token: 0x06014BCA RID: 84938 RVA: 0x00537A38 File Offset: 0x00535C38
		public unsafe Vector3 _position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr__position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr__position)) = value;
			}
		}

		// Token: 0x1700755A RID: 30042
		// (get) Token: 0x06014BCB RID: 84939 RVA: 0x00537A5C File Offset: 0x00535C5C
		// (set) Token: 0x06014BCC RID: 84940 RVA: 0x00537A84 File Offset: 0x00535C84
		public unsafe Vector3 _direction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr__direction);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToDefendObjective.NativeFieldInfoPtr__direction)) = value;
			}
		}

		// Token: 0x0400D3FA RID: 54266
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D3FB RID: 54267
		private static readonly IntPtr NativeFieldInfoPtr__position;

		// Token: 0x0400D3FC RID: 54268
		private static readonly IntPtr NativeFieldInfoPtr__direction;

		// Token: 0x0400D3FD RID: 54269
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3FE RID: 54270
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D3FF RID: 54271
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D400 RID: 54272
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D401 RID: 54273
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D402 RID: 54274
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
