﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011A2 RID: 4514
	public class AlertManager : Il2CppSystem.Object
	{
		// Token: 0x06014F34 RID: 85812 RVA: 0x005443BC File Offset: 0x005425BC
		[CallerCount(0)]
		public unsafe static void FireAlert(AlertData data, DamageController damageController, Vector3 positon)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(damageController);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref positon;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_FireAlert_Public_Static_Void_AlertData_DamageController_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F35 RID: 85813 RVA: 0x00544434 File Offset: 0x00542634
		[CallerCount(0)]
		public unsafe void Initialize(HumanoidAI owner)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F36 RID: 85814 RVA: 0x00544490 File Offset: 0x00542690
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F37 RID: 85815 RVA: 0x005444D4 File Offset: 0x005426D4
		[CallerCount(0)]
		public unsafe bool HasAlertOfType<T>() where T : AlertData
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AlertManager.MethodInfoStoreGeneric_HasAlertOfType_Public_Boolean_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014F38 RID: 85816 RVA: 0x00544524 File Offset: 0x00542724
		[CallerCount(0)]
		public unsafe bool GetAlertOfType<T>(out AlertStruct alert) where T : AlertData
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(alert);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AlertManager.MethodInfoStoreGeneric_GetAlertOfType_Public_Boolean_byref_AlertStruct_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			alert = ((intPtr2 == 0) ? null : new AlertStruct(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014F39 RID: 85817 RVA: 0x005445AC File Offset: 0x005427AC
		[CallerCount(0)]
		public unsafe void ConsumeAlert<T>() where T : AlertData
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.MethodInfoStoreGeneric_ConsumeAlert_Public_Void_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F3A RID: 85818 RVA: 0x005445F0 File Offset: 0x005427F0
		[CallerCount(0)]
		public unsafe void OnAudioAlertEventReceived(AlertData data, DamageController source, Vector3 position)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_OnAudioAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F3B RID: 85819 RVA: 0x00544674 File Offset: 0x00542874
		[CallerCount(0)]
		public unsafe void OnVisualAlertEventReceived(AlertData data, DamageController source, Vector3 position)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_OnVisualAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F3C RID: 85820 RVA: 0x005446F8 File Offset: 0x005428F8
		[CallerCount(0)]
		public unsafe void OnReceiveAlert(AlertData alertData, DamageController source, Vector3 positionOrigin, AlertType alertType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref positionOrigin;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref alertType;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_OnReceiveAlert_Private_Void_AlertData_DamageController_Vector3_AlertType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F3D RID: 85821 RVA: 0x00544790 File Offset: 0x00542990
		[CallerCount(0)]
		public unsafe HashSet<Faction> GetTargetFaction(Faction alertersFaction, AlertTargetTypes alertTargetType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref alertersFaction;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref alertTargetType;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr_GetTargetFaction_Private_HashSet_1_Faction_Faction_AlertTargetTypes_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new HashSet<Faction>(intPtr2) : null;
		}

		// Token: 0x06014F3E RID: 85822 RVA: 0x0054480C File Offset: 0x00542A0C
		[CallerCount(0)]
		public unsafe AlertManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AlertManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F3F RID: 85823 RVA: 0x00544858 File Offset: 0x00542A58
		// Note: this type is marked as 'beforefieldinit'.
		static AlertManager()
		{
			Il2CppClassPointerStore<AlertManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "AlertManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AlertManager>.NativeClassPtr);
			AlertManager.NativeFieldInfoPtr_AllFactions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "AllFactions");
			AlertManager.NativeFieldInfoPtr_MarsocFaction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "MarsocFaction");
			AlertManager.NativeFieldInfoPtr_VolkFaction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "VolkFaction");
			AlertManager.NativeFieldInfoPtr_OnAudioAlertEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "OnAudioAlertEvent");
			AlertManager.NativeFieldInfoPtr_OnVisualAlertEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "OnVisualAlertEvent");
			AlertManager.NativeFieldInfoPtr_Alerts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "Alerts");
			AlertManager.NativeFieldInfoPtr__owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, "_owner");
			AlertManager.NativeMethodInfoPtr_FireAlert_Public_Static_Void_AlertData_DamageController_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690001);
			AlertManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690002);
			AlertManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690003);
			AlertManager.NativeMethodInfoPtr_HasAlertOfType_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690004);
			AlertManager.NativeMethodInfoPtr_GetAlertOfType_Public_Boolean_byref_AlertStruct_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690005);
			AlertManager.NativeMethodInfoPtr_ConsumeAlert_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690006);
			AlertManager.NativeMethodInfoPtr_OnAudioAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690007);
			AlertManager.NativeMethodInfoPtr_OnVisualAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690008);
			AlertManager.NativeMethodInfoPtr_OnReceiveAlert_Private_Void_AlertData_DamageController_Vector3_AlertType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690009);
			AlertManager.NativeMethodInfoPtr_GetTargetFaction_Private_HashSet_1_Faction_Faction_AlertTargetTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690010);
			AlertManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertManager>.NativeClassPtr, 100690011);
		}

		// Token: 0x06014F40 RID: 85824 RVA: 0x00002988 File Offset: 0x00000B88
		public AlertManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700767C RID: 30332
		// (get) Token: 0x06014F41 RID: 85825 RVA: 0x005449F0 File Offset: 0x00542BF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AlertManager>.NativeClassPtr));
			}
		}

		// Token: 0x1700767D RID: 30333
		// (get) Token: 0x06014F42 RID: 85826 RVA: 0x00544A04 File Offset: 0x00542C04
		// (set) Token: 0x06014F43 RID: 85827 RVA: 0x00544A2F File Offset: 0x00542C2F
		public unsafe static HashSet<Faction> AllFactions
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AlertManager.NativeFieldInfoPtr_AllFactions, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new HashSet<Faction>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AlertManager.NativeFieldInfoPtr_AllFactions, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700767E RID: 30334
		// (get) Token: 0x06014F44 RID: 85828 RVA: 0x00544A44 File Offset: 0x00542C44
		// (set) Token: 0x06014F45 RID: 85829 RVA: 0x00544A6F File Offset: 0x00542C6F
		public unsafe static HashSet<Faction> MarsocFaction
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AlertManager.NativeFieldInfoPtr_MarsocFaction, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new HashSet<Faction>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AlertManager.NativeFieldInfoPtr_MarsocFaction, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700767F RID: 30335
		// (get) Token: 0x06014F46 RID: 85830 RVA: 0x00544A84 File Offset: 0x00542C84
		// (set) Token: 0x06014F47 RID: 85831 RVA: 0x00544AAF File Offset: 0x00542CAF
		public unsafe static HashSet<Faction> VolkFaction
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AlertManager.NativeFieldInfoPtr_VolkFaction, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new HashSet<Faction>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AlertManager.NativeFieldInfoPtr_VolkFaction, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007680 RID: 30336
		// (get) Token: 0x06014F48 RID: 85832 RVA: 0x00544AC4 File Offset: 0x00542CC4
		// (set) Token: 0x06014F49 RID: 85833 RVA: 0x00544AEF File Offset: 0x00542CEF
		public unsafe static Action<AlertData, DamageController, Vector3> OnAudioAlertEvent
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AlertManager.NativeFieldInfoPtr_OnAudioAlertEvent, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action<AlertData, DamageController, Vector3>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AlertManager.NativeFieldInfoPtr_OnAudioAlertEvent, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007681 RID: 30337
		// (get) Token: 0x06014F4A RID: 85834 RVA: 0x00544B04 File Offset: 0x00542D04
		// (set) Token: 0x06014F4B RID: 85835 RVA: 0x00544B2F File Offset: 0x00542D2F
		public unsafe static Action<AlertData, DamageController, Vector3> OnVisualAlertEvent
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AlertManager.NativeFieldInfoPtr_OnVisualAlertEvent, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action<AlertData, DamageController, Vector3>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AlertManager.NativeFieldInfoPtr_OnVisualAlertEvent, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007682 RID: 30338
		// (get) Token: 0x06014F4C RID: 85836 RVA: 0x00544B44 File Offset: 0x00542D44
		// (set) Token: 0x06014F4D RID: 85837 RVA: 0x00544B78 File Offset: 0x00542D78
		public unsafe Dictionary<Type, AlertStruct> Alerts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertManager.NativeFieldInfoPtr_Alerts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<Type, AlertStruct>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertManager.NativeFieldInfoPtr_Alerts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007683 RID: 30339
		// (get) Token: 0x06014F4E RID: 85838 RVA: 0x00544BA0 File Offset: 0x00542DA0
		// (set) Token: 0x06014F4F RID: 85839 RVA: 0x00544BD4 File Offset: 0x00542DD4
		public unsafe HumanoidAI _owner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertManager.NativeFieldInfoPtr__owner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertManager.NativeFieldInfoPtr__owner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D5D5 RID: 54741
		private static readonly IntPtr NativeFieldInfoPtr_AllFactions;

		// Token: 0x0400D5D6 RID: 54742
		private static readonly IntPtr NativeFieldInfoPtr_MarsocFaction;

		// Token: 0x0400D5D7 RID: 54743
		private static readonly IntPtr NativeFieldInfoPtr_VolkFaction;

		// Token: 0x0400D5D8 RID: 54744
		private static readonly IntPtr NativeFieldInfoPtr_OnAudioAlertEvent;

		// Token: 0x0400D5D9 RID: 54745
		private static readonly IntPtr NativeFieldInfoPtr_OnVisualAlertEvent;

		// Token: 0x0400D5DA RID: 54746
		private static readonly IntPtr NativeFieldInfoPtr_Alerts;

		// Token: 0x0400D5DB RID: 54747
		private static readonly IntPtr NativeFieldInfoPtr__owner;

		// Token: 0x0400D5DC RID: 54748
		private static readonly IntPtr NativeMethodInfoPtr_FireAlert_Public_Static_Void_AlertData_DamageController_Vector3_0;

		// Token: 0x0400D5DD RID: 54749
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0;

		// Token: 0x0400D5DE RID: 54750
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D5DF RID: 54751
		private static readonly IntPtr NativeMethodInfoPtr_HasAlertOfType_Public_Boolean_0;

		// Token: 0x0400D5E0 RID: 54752
		private static readonly IntPtr NativeMethodInfoPtr_GetAlertOfType_Public_Boolean_byref_AlertStruct_0;

		// Token: 0x0400D5E1 RID: 54753
		private static readonly IntPtr NativeMethodInfoPtr_ConsumeAlert_Public_Void_0;

		// Token: 0x0400D5E2 RID: 54754
		private static readonly IntPtr NativeMethodInfoPtr_OnAudioAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0;

		// Token: 0x0400D5E3 RID: 54755
		private static readonly IntPtr NativeMethodInfoPtr_OnVisualAlertEventReceived_Public_Void_AlertData_DamageController_Vector3_0;

		// Token: 0x0400D5E4 RID: 54756
		private static readonly IntPtr NativeMethodInfoPtr_OnReceiveAlert_Private_Void_AlertData_DamageController_Vector3_AlertType_0;

		// Token: 0x0400D5E5 RID: 54757
		private static readonly IntPtr NativeMethodInfoPtr_GetTargetFaction_Private_HashSet_1_Faction_Faction_AlertTargetTypes_0;

		// Token: 0x0400D5E6 RID: 54758
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x020011A3 RID: 4515
		private sealed class MethodInfoStoreGeneric_HasAlertOfType_Public_Boolean_0<T>
		{
			// Token: 0x0400D5E7 RID: 54759
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AlertManager.NativeMethodInfoPtr_HasAlertOfType_Public_Boolean_0, Il2CppClassPointerStore<AlertManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x020011A4 RID: 4516
		private sealed class MethodInfoStoreGeneric_GetAlertOfType_Public_Boolean_byref_AlertStruct_0<T>
		{
			// Token: 0x0400D5E8 RID: 54760
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AlertManager.NativeMethodInfoPtr_GetAlertOfType_Public_Boolean_byref_AlertStruct_0, Il2CppClassPointerStore<AlertManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x020011A5 RID: 4517
		private sealed class MethodInfoStoreGeneric_ConsumeAlert_Public_Void_0<T>
		{
			// Token: 0x0400D5E9 RID: 54761
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AlertManager.NativeMethodInfoPtr_ConsumeAlert_Public_Void_0, Il2CppClassPointerStore<AlertManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
