﻿using System;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011A8 RID: 4520
	public enum AlertType
	{
		// Token: 0x0400D5F3 RID: 54771
		Audio,
		// Token: 0x0400D5F4 RID: 54772
		Visual,
		// Token: 0x0400D5F5 RID: 54773
		All
	}
}
