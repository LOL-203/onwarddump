﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011B1 RID: 4529
	public class Alert_ShotPassBy : AlertData
	{
		// Token: 0x06014F81 RID: 85889 RVA: 0x00545440 File Offset: 0x00543640
		[CallerCount(0)]
		public unsafe Alert_ShotPassBy() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_ShotPassBy>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_ShotPassBy.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F82 RID: 85890 RVA: 0x0054548B File Offset: 0x0054368B
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_ShotPassBy()
		{
			Il2CppClassPointerStore<Alert_ShotPassBy>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_ShotPassBy");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_ShotPassBy>.NativeClassPtr);
			Alert_ShotPassBy.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_ShotPassBy>.NativeClassPtr, 100690022);
		}

		// Token: 0x06014F83 RID: 85891 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_ShotPassBy(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007692 RID: 30354
		// (get) Token: 0x06014F84 RID: 85892 RVA: 0x005454C4 File Offset: 0x005436C4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_ShotPassBy>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5FE RID: 54782
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
