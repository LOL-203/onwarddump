﻿using System;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011A7 RID: 4519
	public enum AlertTargetTypes
	{
		// Token: 0x0400D5EF RID: 54767
		All,
		// Token: 0x0400D5F0 RID: 54768
		Enemy,
		// Token: 0x0400D5F1 RID: 54769
		Friendly
	}
}
