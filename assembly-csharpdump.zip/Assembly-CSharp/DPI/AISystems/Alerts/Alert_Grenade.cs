﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011AF RID: 4527
	public class Alert_Grenade : AlertData
	{
		// Token: 0x06014F79 RID: 85881 RVA: 0x00545310 File Offset: 0x00543510
		[CallerCount(0)]
		public unsafe Alert_Grenade() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_Grenade>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_Grenade.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F7A RID: 85882 RVA: 0x0054535B File Offset: 0x0054355B
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_Grenade()
		{
			Il2CppClassPointerStore<Alert_Grenade>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_Grenade");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_Grenade>.NativeClassPtr);
			Alert_Grenade.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_Grenade>.NativeClassPtr, 100690020);
		}

		// Token: 0x06014F7B RID: 85883 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_Grenade(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007690 RID: 30352
		// (get) Token: 0x06014F7C RID: 85884 RVA: 0x00545394 File Offset: 0x00543594
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_Grenade>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5FC RID: 54780
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
