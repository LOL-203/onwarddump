﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011A6 RID: 4518
	public class AlertStruct : Il2CppSystem.Object
	{
		// Token: 0x06014F53 RID: 85843 RVA: 0x00544CF8 File Offset: 0x00542EF8
		[CallerCount(0)]
		public unsafe AlertStruct(AlertData data, DamageController source, Vector3 position) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(source);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref position;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertStruct.NativeMethodInfoPtr__ctor_Public_Void_AlertData_DamageController_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F54 RID: 85844 RVA: 0x00544D88 File Offset: 0x00542F88
		// Note: this type is marked as 'beforefieldinit'.
		static AlertStruct()
		{
			Il2CppClassPointerStore<AlertStruct>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "AlertStruct");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr);
			AlertStruct.NativeFieldInfoPtr_AlertData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr, "AlertData");
			AlertStruct.NativeFieldInfoPtr_Source = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr, "Source");
			AlertStruct.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr, "Position");
			AlertStruct.NativeMethodInfoPtr__ctor_Public_Void_AlertData_DamageController_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr, 100690013);
		}

		// Token: 0x06014F55 RID: 85845 RVA: 0x00002988 File Offset: 0x00000B88
		public AlertStruct(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007684 RID: 30340
		// (get) Token: 0x06014F56 RID: 85846 RVA: 0x00544E08 File Offset: 0x00543008
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AlertStruct>.NativeClassPtr));
			}
		}

		// Token: 0x17007685 RID: 30341
		// (get) Token: 0x06014F57 RID: 85847 RVA: 0x00544E1C File Offset: 0x0054301C
		// (set) Token: 0x06014F58 RID: 85848 RVA: 0x00544E50 File Offset: 0x00543050
		public unsafe AlertData AlertData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_AlertData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_AlertData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007686 RID: 30342
		// (get) Token: 0x06014F59 RID: 85849 RVA: 0x00544E78 File Offset: 0x00543078
		// (set) Token: 0x06014F5A RID: 85850 RVA: 0x00544EAC File Offset: 0x005430AC
		public unsafe DamageController Source
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_Source);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_Source), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007687 RID: 30343
		// (get) Token: 0x06014F5B RID: 85851 RVA: 0x00544ED4 File Offset: 0x005430D4
		// (set) Token: 0x06014F5C RID: 85852 RVA: 0x00544EFC File Offset: 0x005430FC
		public unsafe Vector3 Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertStruct.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x0400D5EA RID: 54762
		private static readonly IntPtr NativeFieldInfoPtr_AlertData;

		// Token: 0x0400D5EB RID: 54763
		private static readonly IntPtr NativeFieldInfoPtr_Source;

		// Token: 0x0400D5EC RID: 54764
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x0400D5ED RID: 54765
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_AlertData_DamageController_Vector3_0;
	}
}
