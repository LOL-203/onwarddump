﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011AB RID: 4523
	public class Alert_EnemyDeath : AlertData
	{
		// Token: 0x06014F69 RID: 85865 RVA: 0x005450B0 File Offset: 0x005432B0
		[CallerCount(0)]
		public unsafe Alert_EnemyDeath() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_EnemyDeath>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_EnemyDeath.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F6A RID: 85866 RVA: 0x005450FB File Offset: 0x005432FB
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_EnemyDeath()
		{
			Il2CppClassPointerStore<Alert_EnemyDeath>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_EnemyDeath");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_EnemyDeath>.NativeClassPtr);
			Alert_EnemyDeath.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_EnemyDeath>.NativeClassPtr, 100690016);
		}

		// Token: 0x06014F6B RID: 85867 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_EnemyDeath(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700768C RID: 30348
		// (get) Token: 0x06014F6C RID: 85868 RVA: 0x00545134 File Offset: 0x00543334
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_EnemyDeath>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5F8 RID: 54776
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
