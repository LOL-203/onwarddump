﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011B2 RID: 4530
	public class Alert_TakeDamage : AlertData
	{
		// Token: 0x06014F85 RID: 85893 RVA: 0x005454D8 File Offset: 0x005436D8
		[CallerCount(0)]
		public unsafe Alert_TakeDamage() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_TakeDamage>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_TakeDamage.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F86 RID: 85894 RVA: 0x00545523 File Offset: 0x00543723
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_TakeDamage()
		{
			Il2CppClassPointerStore<Alert_TakeDamage>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_TakeDamage");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_TakeDamage>.NativeClassPtr);
			Alert_TakeDamage.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_TakeDamage>.NativeClassPtr, 100690023);
		}

		// Token: 0x06014F87 RID: 85895 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_TakeDamage(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007693 RID: 30355
		// (get) Token: 0x06014F88 RID: 85896 RVA: 0x0054555C File Offset: 0x0054375C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_TakeDamage>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5FF RID: 54783
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
