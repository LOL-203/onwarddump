﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011B0 RID: 4528
	public class Alert_GunShot : AlertData
	{
		// Token: 0x06014F7D RID: 85885 RVA: 0x005453A8 File Offset: 0x005435A8
		[CallerCount(0)]
		public unsafe Alert_GunShot() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_GunShot>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_GunShot.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F7E RID: 85886 RVA: 0x005453F3 File Offset: 0x005435F3
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_GunShot()
		{
			Il2CppClassPointerStore<Alert_GunShot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_GunShot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_GunShot>.NativeClassPtr);
			Alert_GunShot.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_GunShot>.NativeClassPtr, 100690021);
		}

		// Token: 0x06014F7F RID: 85887 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_GunShot(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007691 RID: 30353
		// (get) Token: 0x06014F80 RID: 85888 RVA: 0x0054542C File Offset: 0x0054362C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_GunShot>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5FD RID: 54781
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
