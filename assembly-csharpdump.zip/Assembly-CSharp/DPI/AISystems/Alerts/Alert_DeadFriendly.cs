﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011AA RID: 4522
	public class Alert_DeadFriendly : AlertData
	{
		// Token: 0x06014F65 RID: 85861 RVA: 0x00545018 File Offset: 0x00543218
		[CallerCount(0)]
		public unsafe Alert_DeadFriendly() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_DeadFriendly>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_DeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F66 RID: 85862 RVA: 0x00545063 File Offset: 0x00543263
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_DeadFriendly()
		{
			Il2CppClassPointerStore<Alert_DeadFriendly>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_DeadFriendly");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_DeadFriendly>.NativeClassPtr);
			Alert_DeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_DeadFriendly>.NativeClassPtr, 100690015);
		}

		// Token: 0x06014F67 RID: 85863 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_DeadFriendly(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700768B RID: 30347
		// (get) Token: 0x06014F68 RID: 85864 RVA: 0x0054509C File Offset: 0x0054329C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_DeadFriendly>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5F7 RID: 54775
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
