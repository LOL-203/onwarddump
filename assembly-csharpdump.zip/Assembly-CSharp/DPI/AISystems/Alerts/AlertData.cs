﻿using System;
using DPI.Data;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011A1 RID: 4513
	public class AlertData : BaseData
	{
		// Token: 0x06014F28 RID: 85800 RVA: 0x00544198 File Offset: 0x00542398
		[CallerCount(0)]
		public unsafe AlertData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AlertData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AlertData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F29 RID: 85801 RVA: 0x005441E4 File Offset: 0x005423E4
		// Note: this type is marked as 'beforefieldinit'.
		static AlertData()
		{
			Il2CppClassPointerStore<AlertData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "AlertData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AlertData>.NativeClassPtr);
			AlertData.NativeFieldInfoPtr_AlertType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertData>.NativeClassPtr, "AlertType");
			AlertData.NativeFieldInfoPtr_AlertTargetTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertData>.NativeClassPtr, "AlertTargetTypes");
			AlertData.NativeFieldInfoPtr_AudioRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertData>.NativeClassPtr, "AudioRange");
			AlertData.NativeFieldInfoPtr_VisualRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AlertData>.NativeClassPtr, "VisualRange");
			AlertData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AlertData>.NativeClassPtr, 100690000);
		}

		// Token: 0x06014F2A RID: 85802 RVA: 0x000AD628 File Offset: 0x000AB828
		public AlertData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007677 RID: 30327
		// (get) Token: 0x06014F2B RID: 85803 RVA: 0x00544278 File Offset: 0x00542478
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AlertData>.NativeClassPtr));
			}
		}

		// Token: 0x17007678 RID: 30328
		// (get) Token: 0x06014F2C RID: 85804 RVA: 0x0054428C File Offset: 0x0054248C
		// (set) Token: 0x06014F2D RID: 85805 RVA: 0x005442B4 File Offset: 0x005424B4
		public unsafe AlertType AlertType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AlertType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AlertType)) = value;
			}
		}

		// Token: 0x17007679 RID: 30329
		// (get) Token: 0x06014F2E RID: 85806 RVA: 0x005442D8 File Offset: 0x005424D8
		// (set) Token: 0x06014F2F RID: 85807 RVA: 0x00544300 File Offset: 0x00542500
		public unsafe AlertTargetTypes AlertTargetTypes
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AlertTargetTypes);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AlertTargetTypes)) = value;
			}
		}

		// Token: 0x1700767A RID: 30330
		// (get) Token: 0x06014F30 RID: 85808 RVA: 0x00544324 File Offset: 0x00542524
		// (set) Token: 0x06014F31 RID: 85809 RVA: 0x0054434C File Offset: 0x0054254C
		public unsafe float AudioRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AudioRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_AudioRange)) = value;
			}
		}

		// Token: 0x1700767B RID: 30331
		// (get) Token: 0x06014F32 RID: 85810 RVA: 0x00544370 File Offset: 0x00542570
		// (set) Token: 0x06014F33 RID: 85811 RVA: 0x00544398 File Offset: 0x00542598
		public unsafe float VisualRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_VisualRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AlertData.NativeFieldInfoPtr_VisualRange)) = value;
			}
		}

		// Token: 0x0400D5D0 RID: 54736
		private static readonly IntPtr NativeFieldInfoPtr_AlertType;

		// Token: 0x0400D5D1 RID: 54737
		private static readonly IntPtr NativeFieldInfoPtr_AlertTargetTypes;

		// Token: 0x0400D5D2 RID: 54738
		private static readonly IntPtr NativeFieldInfoPtr_AudioRange;

		// Token: 0x0400D5D3 RID: 54739
		private static readonly IntPtr NativeFieldInfoPtr_VisualRange;

		// Token: 0x0400D5D4 RID: 54740
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
