﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Alerts
{
	// Token: 0x020011AE RID: 4526
	public class Alert_FriendlyDeath : AlertData
	{
		// Token: 0x06014F75 RID: 85877 RVA: 0x00545278 File Offset: 0x00543478
		[CallerCount(0)]
		public unsafe Alert_FriendlyDeath() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Alert_FriendlyDeath>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Alert_FriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F76 RID: 85878 RVA: 0x005452C3 File Offset: 0x005434C3
		// Note: this type is marked as 'beforefieldinit'.
		static Alert_FriendlyDeath()
		{
			Il2CppClassPointerStore<Alert_FriendlyDeath>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Alerts", "Alert_FriendlyDeath");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Alert_FriendlyDeath>.NativeClassPtr);
			Alert_FriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Alert_FriendlyDeath>.NativeClassPtr, 100690019);
		}

		// Token: 0x06014F77 RID: 85879 RVA: 0x00544FFC File Offset: 0x005431FC
		public Alert_FriendlyDeath(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700768F RID: 30351
		// (get) Token: 0x06014F78 RID: 85880 RVA: 0x005452FC File Offset: 0x005434FC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Alert_FriendlyDeath>.NativeClassPtr));
			}
		}

		// Token: 0x0400D5FB RID: 54779
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
