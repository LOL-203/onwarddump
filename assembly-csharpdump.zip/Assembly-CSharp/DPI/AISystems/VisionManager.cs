﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001195 RID: 4501
	public static class VisionManager : Object
	{
		// Token: 0x06014E83 RID: 85635 RVA: 0x00541B60 File Offset: 0x0053FD60
		[CallerCount(0)]
		public unsafe static void AddVisionTarget(VisionTarget target)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionManager.NativeMethodInfoPtr_AddVisionTarget_Public_Static_Void_VisionTarget_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E84 RID: 85636 RVA: 0x00541BAC File Offset: 0x0053FDAC
		[CallerCount(0)]
		public unsafe static void RemoveVisionTarget(VisionTarget target)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionManager.NativeMethodInfoPtr_RemoveVisionTarget_Public_Static_Void_VisionTarget_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E85 RID: 85637 RVA: 0x00541BF8 File Offset: 0x0053FDF8
		// Note: this type is marked as 'beforefieldinit'.
		static VisionManager()
		{
			Il2CppClassPointerStore<VisionManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionManager>.NativeClassPtr);
			VisionManager.NativeFieldInfoPtr_AllTargetDatas = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionManager>.NativeClassPtr, "AllTargetDatas");
			VisionManager.NativeMethodInfoPtr_AddVisionTarget_Public_Static_Void_VisionTarget_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionManager>.NativeClassPtr, 100689955);
			VisionManager.NativeMethodInfoPtr_RemoveVisionTarget_Public_Static_Void_VisionTarget_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionManager>.NativeClassPtr, 100689956);
		}

		// Token: 0x06014E86 RID: 85638 RVA: 0x00002988 File Offset: 0x00000B88
		public VisionManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007640 RID: 30272
		// (get) Token: 0x06014E87 RID: 85639 RVA: 0x00541C64 File Offset: 0x0053FE64
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionManager>.NativeClassPtr));
			}
		}

		// Token: 0x17007641 RID: 30273
		// (get) Token: 0x06014E88 RID: 85640 RVA: 0x00541C78 File Offset: 0x0053FE78
		// (set) Token: 0x06014E89 RID: 85641 RVA: 0x00541CA3 File Offset: 0x0053FEA3
		public unsafe static List<VisionManager.TargetData> AllTargetDatas
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(VisionManager.NativeFieldInfoPtr_AllTargetDatas, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<VisionManager.TargetData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VisionManager.NativeFieldInfoPtr_AllTargetDatas, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D57B RID: 54651
		private static readonly IntPtr NativeFieldInfoPtr_AllTargetDatas;

		// Token: 0x0400D57C RID: 54652
		private static readonly IntPtr NativeMethodInfoPtr_AddVisionTarget_Public_Static_Void_VisionTarget_0;

		// Token: 0x0400D57D RID: 54653
		private static readonly IntPtr NativeMethodInfoPtr_RemoveVisionTarget_Public_Static_Void_VisionTarget_0;

		// Token: 0x02001196 RID: 4502
		[StructLayout(0)]
		public sealed class TargetData : ValueType
		{
			// Token: 0x06014E8A RID: 85642 RVA: 0x00541CB8 File Offset: 0x0053FEB8
			// Note: this type is marked as 'beforefieldinit'.
			static TargetData()
			{
				Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<VisionManager>.NativeClassPtr, "TargetData");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr);
				VisionManager.TargetData.NativeFieldInfoPtr_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr, "Target");
				VisionManager.TargetData.NativeFieldInfoPtr_Points = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr, "Points");
			}

			// Token: 0x06014E8B RID: 85643 RVA: 0x0002717B File Offset: 0x0002537B
			public TargetData(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17007642 RID: 30274
			// (get) Token: 0x06014E8C RID: 85644 RVA: 0x00541D0B File Offset: 0x0053FF0B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr));
				}
			}

			// Token: 0x06014E8D RID: 85645 RVA: 0x00541D1C File Offset: 0x0053FF1C
			public unsafe TargetData()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<VisionManager.TargetData>.NativeClassPtr, data));
			}

			// Token: 0x17007643 RID: 30275
			// (get) Token: 0x06014E8E RID: 85646 RVA: 0x00541D4C File Offset: 0x0053FF4C
			// (set) Token: 0x06014E8F RID: 85647 RVA: 0x00541D80 File Offset: 0x0053FF80
			public unsafe VisionTarget Target
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionManager.TargetData.NativeFieldInfoPtr_Target);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new VisionTarget(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionManager.TargetData.NativeFieldInfoPtr_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007644 RID: 30276
			// (get) Token: 0x06014E90 RID: 85648 RVA: 0x00541DA8 File Offset: 0x0053FFA8
			// (set) Token: 0x06014E91 RID: 85649 RVA: 0x00541DDC File Offset: 0x0053FFDC
			public unsafe Il2CppReferenceArray<VisionPoint> Points
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionManager.TargetData.NativeFieldInfoPtr_Points);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppReferenceArray<VisionPoint>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionManager.TargetData.NativeFieldInfoPtr_Points), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400D57E RID: 54654
			private static readonly IntPtr NativeFieldInfoPtr_Target;

			// Token: 0x0400D57F RID: 54655
			private static readonly IntPtr NativeFieldInfoPtr_Points;
		}
	}
}
