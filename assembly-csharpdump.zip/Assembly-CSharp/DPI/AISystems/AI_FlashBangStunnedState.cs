﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001164 RID: 4452
	public class AI_FlashBangStunnedState : AIState
	{
		// Token: 0x06014BB1 RID: 84913 RVA: 0x005373D0 File Offset: 0x005355D0
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlashBangStunnedState.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BB2 RID: 84914 RVA: 0x00537420 File Offset: 0x00535620
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlashBangStunnedState.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BB3 RID: 84915 RVA: 0x00537480 File Offset: 0x00535680
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlashBangStunnedState.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BB4 RID: 84916 RVA: 0x005374D0 File Offset: 0x005356D0
		[CallerCount(0)]
		public unsafe AI_FlashBangStunnedState() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_FlashBangStunnedState.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BB5 RID: 84917 RVA: 0x0053751C File Offset: 0x0053571C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_FlashBangStunnedState()
		{
			Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_FlashBangStunnedState");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr);
			AI_FlashBangStunnedState.NativeFieldInfoPtr_MinStunTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, "MinStunTime");
			AI_FlashBangStunnedState.NativeFieldInfoPtr_MaxStunTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, "MaxStunTime");
			AI_FlashBangStunnedState.NativeFieldInfoPtr__endStunTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, "_endStunTime");
			AI_FlashBangStunnedState.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, 100689745);
			AI_FlashBangStunnedState.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, 100689746);
			AI_FlashBangStunnedState.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, 100689747);
			AI_FlashBangStunnedState.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr, 100689748);
		}

		// Token: 0x06014BB6 RID: 84918 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_FlashBangStunnedState(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007553 RID: 30035
		// (get) Token: 0x06014BB7 RID: 84919 RVA: 0x005375D8 File Offset: 0x005357D8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_FlashBangStunnedState>.NativeClassPtr));
			}
		}

		// Token: 0x17007554 RID: 30036
		// (get) Token: 0x06014BB8 RID: 84920 RVA: 0x005375EC File Offset: 0x005357EC
		// (set) Token: 0x06014BB9 RID: 84921 RVA: 0x00537614 File Offset: 0x00535814
		public unsafe float MinStunTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr_MinStunTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr_MinStunTime)) = value;
			}
		}

		// Token: 0x17007555 RID: 30037
		// (get) Token: 0x06014BBA RID: 84922 RVA: 0x00537638 File Offset: 0x00535838
		// (set) Token: 0x06014BBB RID: 84923 RVA: 0x00537660 File Offset: 0x00535860
		public unsafe float MaxStunTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr_MaxStunTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr_MaxStunTime)) = value;
			}
		}

		// Token: 0x17007556 RID: 30038
		// (get) Token: 0x06014BBC RID: 84924 RVA: 0x00537684 File Offset: 0x00535884
		// (set) Token: 0x06014BBD RID: 84925 RVA: 0x005376AC File Offset: 0x005358AC
		public unsafe float _endStunTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr__endStunTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlashBangStunnedState.NativeFieldInfoPtr__endStunTime)) = value;
			}
		}

		// Token: 0x0400D3F3 RID: 54259
		private static readonly IntPtr NativeFieldInfoPtr_MinStunTime;

		// Token: 0x0400D3F4 RID: 54260
		private static readonly IntPtr NativeFieldInfoPtr_MaxStunTime;

		// Token: 0x0400D3F5 RID: 54261
		private static readonly IntPtr NativeFieldInfoPtr__endStunTime;

		// Token: 0x0400D3F6 RID: 54262
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3F7 RID: 54263
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3F8 RID: 54264
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D3F9 RID: 54265
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
