﻿using System;
using DPI.AISystems.Alerts;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001158 RID: 4440
	public class AIStateManager : Object
	{
		// Token: 0x1700751F RID: 29983
		// (get) Token: 0x06014B08 RID: 84744 RVA: 0x00534DE4 File Offset: 0x00532FE4
		public unsafe AIState CurrentState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_get_CurrentState_Public_get_AIState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new AIState(intPtr2) : null;
			}
		}

		// Token: 0x17007520 RID: 29984
		// (get) Token: 0x06014B09 RID: 84745 RVA: 0x00534E3C File Offset: 0x0053303C
		public unsafe AIState PreviousState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_get_PreviousState_Public_get_AIState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new AIState(intPtr2) : null;
			}
		}

		// Token: 0x06014B0A RID: 84746 RVA: 0x00534E94 File Offset: 0x00533094
		[CallerCount(0)]
		public unsafe AIStateManager(AIData data) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr__ctor_Public_Void_AIData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B0B RID: 84747 RVA: 0x00534EF8 File Offset: 0x005330F8
		[CallerCount(0)]
		public unsafe void Initialize(HumanoidAI owner, Type initialState)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(initialState);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B0C RID: 84748 RVA: 0x00534F6C File Offset: 0x0053316C
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIStateManager.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B0D RID: 84749 RVA: 0x00534FBC File Offset: 0x005331BC
		[CallerCount(0)]
		public unsafe void OnUpdate(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_OnUpdate_Public_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B0E RID: 84750 RVA: 0x00535010 File Offset: 0x00533210
		[CallerCount(0)]
		public unsafe void SetState(AIState newState, AlertStruct alertData, Object additionalData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(newState);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(additionalData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_SetState_Public_Void_AIState_AlertStruct_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B0F RID: 84751 RVA: 0x0053509C File Offset: 0x0053329C
		[CallerCount(0)]
		public unsafe AIState DuplicateGameState(AIState sourceGameState, AlertStruct alertData, Object additionalData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(sourceGameState);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(additionalData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_DuplicateGameState_Private_AIState_AIState_AlertStruct_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new AIState(intPtr2) : null;
		}

		// Token: 0x06014B10 RID: 84752 RVA: 0x0053513C File Offset: 0x0053333C
		[CallerCount(0)]
		public unsafe void GoToState(Type nextState, AlertStruct alertData, Object additionalData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(nextState);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(additionalData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_GoToState_Public_Void_Type_AlertStruct_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B11 RID: 84753 RVA: 0x005351C8 File Offset: 0x005333C8
		[CallerCount(0)]
		public unsafe void AddEditorOnlyLog(string message)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(message);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIStateManager.NativeMethodInfoPtr_AddEditorOnlyLog_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B12 RID: 84754 RVA: 0x00535224 File Offset: 0x00533424
		// Note: this type is marked as 'beforefieldinit'.
		static AIStateManager()
		{
			Il2CppClassPointerStore<AIStateManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AIStateManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr);
			AIStateManager.NativeFieldInfoPtr_OnPreStateInitialize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "OnPreStateInitialize");
			AIStateManager.NativeFieldInfoPtr_OnPostStateInitialize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "OnPostStateInitialize");
			AIStateManager.NativeFieldInfoPtr_States = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "States");
			AIStateManager.NativeFieldInfoPtr__previousState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "_previousState");
			AIStateManager.NativeFieldInfoPtr__currentState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "_currentState");
			AIStateManager.NativeFieldInfoPtr_StatesByType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "StatesByType");
			AIStateManager.NativeFieldInfoPtr_PreviousStates = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "PreviousStates");
			AIStateManager.NativeFieldInfoPtr_Owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, "Owner");
			AIStateManager.NativeMethodInfoPtr_get_CurrentState_Public_get_AIState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689704);
			AIStateManager.NativeMethodInfoPtr_get_PreviousState_Public_get_AIState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689705);
			AIStateManager.NativeMethodInfoPtr__ctor_Public_Void_AIData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689706);
			AIStateManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689707);
			AIStateManager.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689708);
			AIStateManager.NativeMethodInfoPtr_OnUpdate_Public_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689709);
			AIStateManager.NativeMethodInfoPtr_SetState_Public_Void_AIState_AlertStruct_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689710);
			AIStateManager.NativeMethodInfoPtr_DuplicateGameState_Private_AIState_AIState_AlertStruct_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689711);
			AIStateManager.NativeMethodInfoPtr_GoToState_Public_Void_Type_AlertStruct_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689712);
			AIStateManager.NativeMethodInfoPtr_AddEditorOnlyLog_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr, 100689713);
		}

		// Token: 0x06014B13 RID: 84755 RVA: 0x00002988 File Offset: 0x00000B88
		public AIStateManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007516 RID: 29974
		// (get) Token: 0x06014B14 RID: 84756 RVA: 0x005353BC File Offset: 0x005335BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIStateManager>.NativeClassPtr));
			}
		}

		// Token: 0x17007517 RID: 29975
		// (get) Token: 0x06014B15 RID: 84757 RVA: 0x005353D0 File Offset: 0x005335D0
		// (set) Token: 0x06014B16 RID: 84758 RVA: 0x00535404 File Offset: 0x00533604
		public unsafe Action<AIState> OnPreStateInitialize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_OnPreStateInitialize);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<AIState>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_OnPreStateInitialize), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007518 RID: 29976
		// (get) Token: 0x06014B17 RID: 84759 RVA: 0x0053542C File Offset: 0x0053362C
		// (set) Token: 0x06014B18 RID: 84760 RVA: 0x00535460 File Offset: 0x00533660
		public unsafe Action<AIState> OnPostStateInitialize
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_OnPostStateInitialize);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<AIState>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_OnPostStateInitialize), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007519 RID: 29977
		// (get) Token: 0x06014B19 RID: 84761 RVA: 0x00535488 File Offset: 0x00533688
		// (set) Token: 0x06014B1A RID: 84762 RVA: 0x005354BC File Offset: 0x005336BC
		public unsafe Dictionary<Type, AIState> States
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_States);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<Type, AIState>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_States), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700751A RID: 29978
		// (get) Token: 0x06014B1B RID: 84763 RVA: 0x005354E4 File Offset: 0x005336E4
		// (set) Token: 0x06014B1C RID: 84764 RVA: 0x00535518 File Offset: 0x00533718
		public unsafe AIState _previousState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr__previousState);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIState(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr__previousState), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700751B RID: 29979
		// (get) Token: 0x06014B1D RID: 84765 RVA: 0x00535540 File Offset: 0x00533740
		// (set) Token: 0x06014B1E RID: 84766 RVA: 0x00535574 File Offset: 0x00533774
		public unsafe AIState _currentState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr__currentState);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIState(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr__currentState), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700751C RID: 29980
		// (get) Token: 0x06014B1F RID: 84767 RVA: 0x0053559C File Offset: 0x0053379C
		// (set) Token: 0x06014B20 RID: 84768 RVA: 0x005355D0 File Offset: 0x005337D0
		public unsafe Dictionary<Type, AIState> StatesByType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_StatesByType);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<Type, AIState>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_StatesByType), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700751D RID: 29981
		// (get) Token: 0x06014B21 RID: 84769 RVA: 0x005355F8 File Offset: 0x005337F8
		// (set) Token: 0x06014B22 RID: 84770 RVA: 0x0053562C File Offset: 0x0053382C
		public unsafe List<string> PreviousStates
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_PreviousStates);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<string>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_PreviousStates), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700751E RID: 29982
		// (get) Token: 0x06014B23 RID: 84771 RVA: 0x00535654 File Offset: 0x00533854
		// (set) Token: 0x06014B24 RID: 84772 RVA: 0x00535688 File Offset: 0x00533888
		public unsafe HumanoidAI Owner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_Owner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIStateManager.NativeFieldInfoPtr_Owner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D397 RID: 54167
		private static readonly IntPtr NativeFieldInfoPtr_OnPreStateInitialize;

		// Token: 0x0400D398 RID: 54168
		private static readonly IntPtr NativeFieldInfoPtr_OnPostStateInitialize;

		// Token: 0x0400D399 RID: 54169
		private static readonly IntPtr NativeFieldInfoPtr_States;

		// Token: 0x0400D39A RID: 54170
		private static readonly IntPtr NativeFieldInfoPtr__previousState;

		// Token: 0x0400D39B RID: 54171
		private static readonly IntPtr NativeFieldInfoPtr__currentState;

		// Token: 0x0400D39C RID: 54172
		private static readonly IntPtr NativeFieldInfoPtr_StatesByType;

		// Token: 0x0400D39D RID: 54173
		private static readonly IntPtr NativeFieldInfoPtr_PreviousStates;

		// Token: 0x0400D39E RID: 54174
		private static readonly IntPtr NativeFieldInfoPtr_Owner;

		// Token: 0x0400D39F RID: 54175
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentState_Public_get_AIState_0;

		// Token: 0x0400D3A0 RID: 54176
		private static readonly IntPtr NativeMethodInfoPtr_get_PreviousState_Public_get_AIState_0;

		// Token: 0x0400D3A1 RID: 54177
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_AIData_0;

		// Token: 0x0400D3A2 RID: 54178
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_Type_0;

		// Token: 0x0400D3A3 RID: 54179
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0;

		// Token: 0x0400D3A4 RID: 54180
		private static readonly IntPtr NativeMethodInfoPtr_OnUpdate_Public_Void_Single_0;

		// Token: 0x0400D3A5 RID: 54181
		private static readonly IntPtr NativeMethodInfoPtr_SetState_Public_Void_AIState_AlertStruct_Object_0;

		// Token: 0x0400D3A6 RID: 54182
		private static readonly IntPtr NativeMethodInfoPtr_DuplicateGameState_Private_AIState_AIState_AlertStruct_Object_0;

		// Token: 0x0400D3A7 RID: 54183
		private static readonly IntPtr NativeMethodInfoPtr_GoToState_Public_Void_Type_AlertStruct_Object_0;

		// Token: 0x0400D3A8 RID: 54184
		private static readonly IntPtr NativeMethodInfoPtr_AddEditorOnlyLog_Public_Void_String_0;
	}
}
