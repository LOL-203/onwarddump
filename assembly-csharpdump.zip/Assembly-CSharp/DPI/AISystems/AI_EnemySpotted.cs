﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001160 RID: 4448
	public class AI_EnemySpotted : AIState
	{
		// Token: 0x06014B78 RID: 84856 RVA: 0x0053672C File Offset: 0x0053492C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_EnemySpotted.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B79 RID: 84857 RVA: 0x0053677C File Offset: 0x0053497C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_EnemySpotted.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B7A RID: 84858 RVA: 0x005367DC File Offset: 0x005349DC
		[CallerCount(0)]
		public unsafe AI_EnemySpotted() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_EnemySpotted.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B7B RID: 84859 RVA: 0x00536828 File Offset: 0x00534A28
		// Note: this type is marked as 'beforefieldinit'.
		static AI_EnemySpotted()
		{
			Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_EnemySpotted");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr);
			AI_EnemySpotted.NativeFieldInfoPtr_MinReactionTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MinReactionTime");
			AI_EnemySpotted.NativeFieldInfoPtr_MaxReactionTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MaxReactionTime");
			AI_EnemySpotted.NativeFieldInfoPtr_ChanceToShoot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "ChanceToShoot");
			AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "ChanceToThrowGrenade");
			AI_EnemySpotted.NativeFieldInfoPtr_MinDistanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MinDistanceToThrowGrenade");
			AI_EnemySpotted.NativeFieldInfoPtr_MaxDistanceToThrowGrenade = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MaxDistanceToThrowGrenade");
			AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowFlash = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "ChanceToThrowFlash");
			AI_EnemySpotted.NativeFieldInfoPtr_MinFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MinFlashDistance");
			AI_EnemySpotted.NativeFieldInfoPtr_MaxFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MaxFlashDistance");
			AI_EnemySpotted.NativeFieldInfoPtr_MinFriendlySafeFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MinFriendlySafeFlashDistance");
			AI_EnemySpotted.NativeFieldInfoPtr_MaxTargetFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "MaxTargetFlashDistance");
			AI_EnemySpotted.NativeFieldInfoPtr__endReactionTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, "_endReactionTime");
			AI_EnemySpotted.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, 100689730);
			AI_EnemySpotted.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, 100689731);
			AI_EnemySpotted.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr, 100689732);
		}

		// Token: 0x06014B7C RID: 84860 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_EnemySpotted(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007540 RID: 30016
		// (get) Token: 0x06014B7D RID: 84861 RVA: 0x00536984 File Offset: 0x00534B84
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_EnemySpotted>.NativeClassPtr));
			}
		}

		// Token: 0x17007541 RID: 30017
		// (get) Token: 0x06014B7E RID: 84862 RVA: 0x00536998 File Offset: 0x00534B98
		// (set) Token: 0x06014B7F RID: 84863 RVA: 0x005369C0 File Offset: 0x00534BC0
		public unsafe float MinReactionTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinReactionTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinReactionTime)) = value;
			}
		}

		// Token: 0x17007542 RID: 30018
		// (get) Token: 0x06014B80 RID: 84864 RVA: 0x005369E4 File Offset: 0x00534BE4
		// (set) Token: 0x06014B81 RID: 84865 RVA: 0x00536A0C File Offset: 0x00534C0C
		public unsafe float MaxReactionTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxReactionTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxReactionTime)) = value;
			}
		}

		// Token: 0x17007543 RID: 30019
		// (get) Token: 0x06014B82 RID: 84866 RVA: 0x00536A30 File Offset: 0x00534C30
		// (set) Token: 0x06014B83 RID: 84867 RVA: 0x00536A58 File Offset: 0x00534C58
		public unsafe int ChanceToShoot
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToShoot);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToShoot)) = value;
			}
		}

		// Token: 0x17007544 RID: 30020
		// (get) Token: 0x06014B84 RID: 84868 RVA: 0x00536A7C File Offset: 0x00534C7C
		// (set) Token: 0x06014B85 RID: 84869 RVA: 0x00536AA4 File Offset: 0x00534CA4
		public unsafe int ChanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x17007545 RID: 30021
		// (get) Token: 0x06014B86 RID: 84870 RVA: 0x00536AC8 File Offset: 0x00534CC8
		// (set) Token: 0x06014B87 RID: 84871 RVA: 0x00536AF0 File Offset: 0x00534CF0
		public unsafe float MinDistanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinDistanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinDistanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x17007546 RID: 30022
		// (get) Token: 0x06014B88 RID: 84872 RVA: 0x00536B14 File Offset: 0x00534D14
		// (set) Token: 0x06014B89 RID: 84873 RVA: 0x00536B3C File Offset: 0x00534D3C
		public unsafe float MaxDistanceToThrowGrenade
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxDistanceToThrowGrenade);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxDistanceToThrowGrenade)) = value;
			}
		}

		// Token: 0x17007547 RID: 30023
		// (get) Token: 0x06014B8A RID: 84874 RVA: 0x00536B60 File Offset: 0x00534D60
		// (set) Token: 0x06014B8B RID: 84875 RVA: 0x00536B88 File Offset: 0x00534D88
		public unsafe int ChanceToThrowFlash
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowFlash);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_ChanceToThrowFlash)) = value;
			}
		}

		// Token: 0x17007548 RID: 30024
		// (get) Token: 0x06014B8C RID: 84876 RVA: 0x00536BAC File Offset: 0x00534DAC
		// (set) Token: 0x06014B8D RID: 84877 RVA: 0x00536BD4 File Offset: 0x00534DD4
		public unsafe float MinFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinFlashDistance)) = value;
			}
		}

		// Token: 0x17007549 RID: 30025
		// (get) Token: 0x06014B8E RID: 84878 RVA: 0x00536BF8 File Offset: 0x00534DF8
		// (set) Token: 0x06014B8F RID: 84879 RVA: 0x00536C20 File Offset: 0x00534E20
		public unsafe float MaxFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxFlashDistance)) = value;
			}
		}

		// Token: 0x1700754A RID: 30026
		// (get) Token: 0x06014B90 RID: 84880 RVA: 0x00536C44 File Offset: 0x00534E44
		// (set) Token: 0x06014B91 RID: 84881 RVA: 0x00536C6C File Offset: 0x00534E6C
		public unsafe float MinFriendlySafeFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinFriendlySafeFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MinFriendlySafeFlashDistance)) = value;
			}
		}

		// Token: 0x1700754B RID: 30027
		// (get) Token: 0x06014B92 RID: 84882 RVA: 0x00536C90 File Offset: 0x00534E90
		// (set) Token: 0x06014B93 RID: 84883 RVA: 0x00536CB8 File Offset: 0x00534EB8
		public unsafe float MaxTargetFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxTargetFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr_MaxTargetFlashDistance)) = value;
			}
		}

		// Token: 0x1700754C RID: 30028
		// (get) Token: 0x06014B94 RID: 84884 RVA: 0x00536CDC File Offset: 0x00534EDC
		// (set) Token: 0x06014B95 RID: 84885 RVA: 0x00536D04 File Offset: 0x00534F04
		public unsafe float _endReactionTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr__endReactionTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_EnemySpotted.NativeFieldInfoPtr__endReactionTime)) = value;
			}
		}

		// Token: 0x0400D3D5 RID: 54229
		private static readonly IntPtr NativeFieldInfoPtr_MinReactionTime;

		// Token: 0x0400D3D6 RID: 54230
		private static readonly IntPtr NativeFieldInfoPtr_MaxReactionTime;

		// Token: 0x0400D3D7 RID: 54231
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToShoot;

		// Token: 0x0400D3D8 RID: 54232
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowGrenade;

		// Token: 0x0400D3D9 RID: 54233
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToThrowGrenade;

		// Token: 0x0400D3DA RID: 54234
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistanceToThrowGrenade;

		// Token: 0x0400D3DB RID: 54235
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowFlash;

		// Token: 0x0400D3DC RID: 54236
		private static readonly IntPtr NativeFieldInfoPtr_MinFlashDistance;

		// Token: 0x0400D3DD RID: 54237
		private static readonly IntPtr NativeFieldInfoPtr_MaxFlashDistance;

		// Token: 0x0400D3DE RID: 54238
		private static readonly IntPtr NativeFieldInfoPtr_MinFriendlySafeFlashDistance;

		// Token: 0x0400D3DF RID: 54239
		private static readonly IntPtr NativeFieldInfoPtr_MaxTargetFlashDistance;

		// Token: 0x0400D3E0 RID: 54240
		private static readonly IntPtr NativeFieldInfoPtr__endReactionTime;

		// Token: 0x0400D3E1 RID: 54241
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3E2 RID: 54242
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3E3 RID: 54243
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
