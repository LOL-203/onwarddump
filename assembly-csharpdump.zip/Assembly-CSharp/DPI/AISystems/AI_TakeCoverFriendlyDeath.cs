﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001183 RID: 4483
	public class AI_TakeCoverFriendlyDeath : AIState
	{
		// Token: 0x06014D6F RID: 85359 RVA: 0x0053D840 File Offset: 0x0053BA40
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D70 RID: 85360 RVA: 0x0053D890 File Offset: 0x0053BA90
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint cover)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(cover);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D71 RID: 85361 RVA: 0x0053D8FC File Offset: 0x0053BAFC
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D72 RID: 85362 RVA: 0x0053D95C File Offset: 0x0053BB5C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D73 RID: 85363 RVA: 0x0053D9AC File Offset: 0x0053BBAC
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D74 RID: 85364 RVA: 0x0053D9F0 File Offset: 0x0053BBF0
		[CallerCount(0)]
		public unsafe AI_TakeCoverFriendlyDeath() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D75 RID: 85365 RVA: 0x0053DA3C File Offset: 0x0053BC3C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCoverFriendlyDeath()
		{
			Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCoverFriendlyDeath");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr);
			AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, "MaxCoverDistance");
			AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MinWaitInCover = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, "MinWaitInCover");
			AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxWaitInCover = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, "MaxWaitInCover");
			AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr__waitEndTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, "_waitEndTime");
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689868);
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689869);
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689870);
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689871);
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689872);
			AI_TakeCoverFriendlyDeath.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr, 100689873);
		}

		// Token: 0x06014D76 RID: 85366 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCoverFriendlyDeath(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075E5 RID: 30181
		// (get) Token: 0x06014D77 RID: 85367 RVA: 0x0053DB34 File Offset: 0x0053BD34
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCoverFriendlyDeath>.NativeClassPtr));
			}
		}

		// Token: 0x170075E6 RID: 30182
		// (get) Token: 0x06014D78 RID: 85368 RVA: 0x0053DB48 File Offset: 0x0053BD48
		// (set) Token: 0x06014D79 RID: 85369 RVA: 0x0053DB70 File Offset: 0x0053BD70
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x170075E7 RID: 30183
		// (get) Token: 0x06014D7A RID: 85370 RVA: 0x0053DB94 File Offset: 0x0053BD94
		// (set) Token: 0x06014D7B RID: 85371 RVA: 0x0053DBBC File Offset: 0x0053BDBC
		public unsafe float MinWaitInCover
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MinWaitInCover);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MinWaitInCover)) = value;
			}
		}

		// Token: 0x170075E8 RID: 30184
		// (get) Token: 0x06014D7C RID: 85372 RVA: 0x0053DBE0 File Offset: 0x0053BDE0
		// (set) Token: 0x06014D7D RID: 85373 RVA: 0x0053DC08 File Offset: 0x0053BE08
		public unsafe float MaxWaitInCover
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxWaitInCover);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr_MaxWaitInCover)) = value;
			}
		}

		// Token: 0x170075E9 RID: 30185
		// (get) Token: 0x06014D7E RID: 85374 RVA: 0x0053DC2C File Offset: 0x0053BE2C
		// (set) Token: 0x06014D7F RID: 85375 RVA: 0x0053DC54 File Offset: 0x0053BE54
		public unsafe float _waitEndTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr__waitEndTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverFriendlyDeath.NativeFieldInfoPtr__waitEndTime)) = value;
			}
		}

		// Token: 0x0400D4E1 RID: 54497
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D4E2 RID: 54498
		private static readonly IntPtr NativeFieldInfoPtr_MinWaitInCover;

		// Token: 0x0400D4E3 RID: 54499
		private static readonly IntPtr NativeFieldInfoPtr_MaxWaitInCover;

		// Token: 0x0400D4E4 RID: 54500
		private static readonly IntPtr NativeFieldInfoPtr__waitEndTime;

		// Token: 0x0400D4E5 RID: 54501
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4E6 RID: 54502
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D4E7 RID: 54503
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D4E8 RID: 54504
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D4E9 RID: 54505
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D4EA RID: 54506
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
