﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001169 RID: 4457
	public class AI_Idle : AIState_PassiveBarks
	{
		// Token: 0x06014C00 RID: 84992 RVA: 0x0053863C File Offset: 0x0053683C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Idle.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C01 RID: 84993 RVA: 0x0053868C File Offset: 0x0053688C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Idle.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C02 RID: 84994 RVA: 0x005386EC File Offset: 0x005368EC
		[CallerCount(0)]
		public unsafe AI_Idle() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Idle.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C03 RID: 84995 RVA: 0x00538738 File Offset: 0x00536938
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Idle()
		{
			Il2CppClassPointerStore<AI_Idle>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Idle");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr);
			AI_Idle.NativeFieldInfoPtr_MinIdleTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, "MinIdleTime");
			AI_Idle.NativeFieldInfoPtr_MaxIdleTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, "MaxIdleTime");
			AI_Idle.NativeFieldInfoPtr_MaxWayPointSearchRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, "MaxWayPointSearchRadius");
			AI_Idle.NativeFieldInfoPtr__idleEnd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, "_idleEnd");
			AI_Idle.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, 100689769);
			AI_Idle.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, 100689770);
			AI_Idle.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr, 100689771);
		}

		// Token: 0x06014C04 RID: 84996 RVA: 0x005387F4 File Offset: 0x005369F4
		public AI_Idle(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700756C RID: 30060
		// (get) Token: 0x06014C05 RID: 84997 RVA: 0x005387FD File Offset: 0x005369FD
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Idle>.NativeClassPtr));
			}
		}

		// Token: 0x1700756D RID: 30061
		// (get) Token: 0x06014C06 RID: 84998 RVA: 0x00538810 File Offset: 0x00536A10
		// (set) Token: 0x06014C07 RID: 84999 RVA: 0x00538838 File Offset: 0x00536A38
		public unsafe float MinIdleTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MinIdleTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MinIdleTime)) = value;
			}
		}

		// Token: 0x1700756E RID: 30062
		// (get) Token: 0x06014C08 RID: 85000 RVA: 0x0053885C File Offset: 0x00536A5C
		// (set) Token: 0x06014C09 RID: 85001 RVA: 0x00538884 File Offset: 0x00536A84
		public unsafe float MaxIdleTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MaxIdleTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MaxIdleTime)) = value;
			}
		}

		// Token: 0x1700756F RID: 30063
		// (get) Token: 0x06014C0A RID: 85002 RVA: 0x005388A8 File Offset: 0x00536AA8
		// (set) Token: 0x06014C0B RID: 85003 RVA: 0x005388D0 File Offset: 0x00536AD0
		public unsafe float MaxWayPointSearchRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MaxWayPointSearchRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr_MaxWayPointSearchRadius)) = value;
			}
		}

		// Token: 0x17007570 RID: 30064
		// (get) Token: 0x06014C0C RID: 85004 RVA: 0x005388F4 File Offset: 0x00536AF4
		// (set) Token: 0x06014C0D RID: 85005 RVA: 0x0053891C File Offset: 0x00536B1C
		public unsafe float _idleEnd
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr__idleEnd);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Idle.NativeFieldInfoPtr__idleEnd)) = value;
			}
		}

		// Token: 0x0400D41F RID: 54303
		private static readonly IntPtr NativeFieldInfoPtr_MinIdleTime;

		// Token: 0x0400D420 RID: 54304
		private static readonly IntPtr NativeFieldInfoPtr_MaxIdleTime;

		// Token: 0x0400D421 RID: 54305
		private static readonly IntPtr NativeFieldInfoPtr_MaxWayPointSearchRadius;

		// Token: 0x0400D422 RID: 54306
		private static readonly IntPtr NativeFieldInfoPtr__idleEnd;

		// Token: 0x0400D423 RID: 54307
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D424 RID: 54308
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D425 RID: 54309
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
