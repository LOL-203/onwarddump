﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001162 RID: 4450
	public class AI_FlankTarget : AIState
	{
		// Token: 0x06014BA1 RID: 84897 RVA: 0x00537040 File Offset: 0x00535240
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlankTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BA2 RID: 84898 RVA: 0x00537090 File Offset: 0x00535290
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlankTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BA3 RID: 84899 RVA: 0x005370E0 File Offset: 0x005352E0
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_FlankTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BA4 RID: 84900 RVA: 0x00537124 File Offset: 0x00535324
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_FlankTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BA5 RID: 84901 RVA: 0x00537184 File Offset: 0x00535384
		[CallerCount(0)]
		public unsafe AI_FlankTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_FlankTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BA6 RID: 84902 RVA: 0x005371D0 File Offset: 0x005353D0
		// Note: this type is marked as 'beforefieldinit'.
		static AI_FlankTarget()
		{
			Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_FlankTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr);
			AI_FlankTarget.NativeFieldInfoPtr_MinDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, "MinDistance");
			AI_FlankTarget.NativeFieldInfoPtr_MaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, "MaxDistance");
			AI_FlankTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, 100689739);
			AI_FlankTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, 100689740);
			AI_FlankTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, 100689741);
			AI_FlankTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, 100689742);
			AI_FlankTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr, 100689743);
		}

		// Token: 0x06014BA7 RID: 84903 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_FlankTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700754F RID: 30031
		// (get) Token: 0x06014BA8 RID: 84904 RVA: 0x0053728C File Offset: 0x0053548C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_FlankTarget>.NativeClassPtr));
			}
		}

		// Token: 0x17007550 RID: 30032
		// (get) Token: 0x06014BA9 RID: 84905 RVA: 0x005372A0 File Offset: 0x005354A0
		// (set) Token: 0x06014BAA RID: 84906 RVA: 0x005372C8 File Offset: 0x005354C8
		public unsafe float MinDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlankTarget.NativeFieldInfoPtr_MinDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlankTarget.NativeFieldInfoPtr_MinDistance)) = value;
			}
		}

		// Token: 0x17007551 RID: 30033
		// (get) Token: 0x06014BAB RID: 84907 RVA: 0x005372EC File Offset: 0x005354EC
		// (set) Token: 0x06014BAC RID: 84908 RVA: 0x00537314 File Offset: 0x00535514
		public unsafe float MaxDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlankTarget.NativeFieldInfoPtr_MaxDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_FlankTarget.NativeFieldInfoPtr_MaxDistance)) = value;
			}
		}

		// Token: 0x0400D3EB RID: 54251
		private static readonly IntPtr NativeFieldInfoPtr_MinDistance;

		// Token: 0x0400D3EC RID: 54252
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistance;

		// Token: 0x0400D3ED RID: 54253
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3EE RID: 54254
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D3EF RID: 54255
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D3F0 RID: 54256
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3F1 RID: 54257
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
