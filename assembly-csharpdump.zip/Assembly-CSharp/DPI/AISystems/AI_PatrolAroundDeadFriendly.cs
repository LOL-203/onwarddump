﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001170 RID: 4464
	public class AI_PatrolAroundDeadFriendly : AIState
	{
		// Token: 0x06014C61 RID: 85089 RVA: 0x00539CAC File Offset: 0x00537EAC
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C62 RID: 85090 RVA: 0x00539CFC File Offset: 0x00537EFC
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C63 RID: 85091 RVA: 0x00539D5C File Offset: 0x00537F5C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C64 RID: 85092 RVA: 0x00539DAC File Offset: 0x00537FAC
		[CallerCount(0)]
		public unsafe void MovePosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_MovePosition_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C65 RID: 85093 RVA: 0x00539DF0 File Offset: 0x00537FF0
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C66 RID: 85094 RVA: 0x00539E34 File Offset: 0x00538034
		[CallerCount(0)]
		public unsafe AI_PatrolAroundDeadFriendly() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C67 RID: 85095 RVA: 0x00539E80 File Offset: 0x00538080
		// Note: this type is marked as 'beforefieldinit'.
		static AI_PatrolAroundDeadFriendly()
		{
			Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_PatrolAroundDeadFriendly");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr);
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "PatrolCountsMin");
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "PatrolCountsMax");
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MinPatrolDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "MinPatrolDistance");
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MaxPatrolDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "MaxPatrolDistance");
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__remainingPatrols = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "_remainingPatrols");
			AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__patrolPoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, "_patrolPoints");
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689799);
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689800);
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689801);
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_MovePosition_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689802);
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689803);
			AI_PatrolAroundDeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr, 100689804);
		}

		// Token: 0x06014C68 RID: 85096 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_PatrolAroundDeadFriendly(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700758A RID: 30090
		// (get) Token: 0x06014C69 RID: 85097 RVA: 0x00539FA0 File Offset: 0x005381A0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_PatrolAroundDeadFriendly>.NativeClassPtr));
			}
		}

		// Token: 0x1700758B RID: 30091
		// (get) Token: 0x06014C6A RID: 85098 RVA: 0x00539FB4 File Offset: 0x005381B4
		// (set) Token: 0x06014C6B RID: 85099 RVA: 0x00539FDC File Offset: 0x005381DC
		public unsafe int PatrolCountsMin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMin);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMin)) = value;
			}
		}

		// Token: 0x1700758C RID: 30092
		// (get) Token: 0x06014C6C RID: 85100 RVA: 0x0053A000 File Offset: 0x00538200
		// (set) Token: 0x06014C6D RID: 85101 RVA: 0x0053A028 File Offset: 0x00538228
		public unsafe int PatrolCountsMax
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMax);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_PatrolCountsMax)) = value;
			}
		}

		// Token: 0x1700758D RID: 30093
		// (get) Token: 0x06014C6E RID: 85102 RVA: 0x0053A04C File Offset: 0x0053824C
		// (set) Token: 0x06014C6F RID: 85103 RVA: 0x0053A074 File Offset: 0x00538274
		public unsafe float MinPatrolDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MinPatrolDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MinPatrolDistance)) = value;
			}
		}

		// Token: 0x1700758E RID: 30094
		// (get) Token: 0x06014C70 RID: 85104 RVA: 0x0053A098 File Offset: 0x00538298
		// (set) Token: 0x06014C71 RID: 85105 RVA: 0x0053A0C0 File Offset: 0x005382C0
		public unsafe float MaxPatrolDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MaxPatrolDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr_MaxPatrolDistance)) = value;
			}
		}

		// Token: 0x1700758F RID: 30095
		// (get) Token: 0x06014C72 RID: 85106 RVA: 0x0053A0E4 File Offset: 0x005382E4
		// (set) Token: 0x06014C73 RID: 85107 RVA: 0x0053A10C File Offset: 0x0053830C
		public unsafe int _remainingPatrols
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__remainingPatrols);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__remainingPatrols)) = value;
			}
		}

		// Token: 0x17007590 RID: 30096
		// (get) Token: 0x06014C74 RID: 85108 RVA: 0x0053A130 File Offset: 0x00538330
		// (set) Token: 0x06014C75 RID: 85109 RVA: 0x0053A164 File Offset: 0x00538364
		public unsafe List<Vector3> _patrolPoints
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__patrolPoints);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_PatrolAroundDeadFriendly.NativeFieldInfoPtr__patrolPoints), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D454 RID: 54356
		private static readonly IntPtr NativeFieldInfoPtr_PatrolCountsMin;

		// Token: 0x0400D455 RID: 54357
		private static readonly IntPtr NativeFieldInfoPtr_PatrolCountsMax;

		// Token: 0x0400D456 RID: 54358
		private static readonly IntPtr NativeFieldInfoPtr_MinPatrolDistance;

		// Token: 0x0400D457 RID: 54359
		private static readonly IntPtr NativeFieldInfoPtr_MaxPatrolDistance;

		// Token: 0x0400D458 RID: 54360
		private static readonly IntPtr NativeFieldInfoPtr__remainingPatrols;

		// Token: 0x0400D459 RID: 54361
		private static readonly IntPtr NativeFieldInfoPtr__patrolPoints;

		// Token: 0x0400D45A RID: 54362
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D45B RID: 54363
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D45C RID: 54364
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D45D RID: 54365
		private static readonly IntPtr NativeMethodInfoPtr_MovePosition_Private_Void_0;

		// Token: 0x0400D45E RID: 54366
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D45F RID: 54367
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
