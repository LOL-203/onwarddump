﻿using System;
using AISystems;
using DPI.AISystems.Alerts;
using DPI.Data;
using DPI.Stats;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.AI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001155 RID: 4437
	public class AIData : BaseData
	{
		// Token: 0x06014AC0 RID: 84672 RVA: 0x005338D0 File Offset: 0x00531AD0
		[CallerCount(0)]
		public new unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIData.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AC1 RID: 84673 RVA: 0x00533920 File Offset: 0x00531B20
		[CallerCount(0)]
		public unsafe AIData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AC2 RID: 84674 RVA: 0x0053396C File Offset: 0x00531B6C
		// Note: this type is marked as 'beforefieldinit'.
		static AIData()
		{
			Il2CppClassPointerStore<AIData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AIData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIData>.NativeClassPtr);
			AIData.NativeFieldInfoPtr_ClassType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "ClassType");
			AIData.NativeFieldInfoPtr_PossibleStates = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "PossibleStates");
			AIData.NativeFieldInfoPtr_FactionData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "FactionData");
			AIData.NativeFieldInfoPtr_FactionDataByFaction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "FactionDataByFaction");
			AIData.NativeFieldInfoPtr_StatsPerDifficultyLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "StatsPerDifficultyLevel");
			AIData.NativeFieldInfoPtr_IdleVisionPerDifficultyLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "IdleVisionPerDifficultyLevel");
			AIData.NativeFieldInfoPtr_CombatVisionPerDifficultyLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "CombatVisionPerDifficultyLevel");
			AIData.NativeFieldInfoPtr_FriendlyDeathAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "FriendlyDeathAlert");
			AIData.NativeFieldInfoPtr_FriendlyDeadAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "FriendlyDeadAlert");
			AIData.NativeFieldInfoPtr_EnemyDeathAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "EnemyDeathAlert");
			AIData.NativeFieldInfoPtr_EnemyDeadAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "EnemyDeadAlert");
			AIData.NativeFieldInfoPtr_TookDamageAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "TookDamageAlert");
			AIData.NativeFieldInfoPtr_EnemySpottedAlert = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "EnemySpottedAlert");
			AIData.NativeFieldInfoPtr_GrenadeHeightCheckLayers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "GrenadeHeightCheckLayers");
			AIData.NativeFieldInfoPtr_FragGrenadeMinCeilingHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIData>.NativeClassPtr, "FragGrenadeMinCeilingHeight");
			AIData.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIData>.NativeClassPtr, 100689679);
			AIData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIData>.NativeClassPtr, 100689680);
		}

		// Token: 0x06014AC3 RID: 84675 RVA: 0x000AD628 File Offset: 0x000AB828
		public AIData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007500 RID: 29952
		// (get) Token: 0x06014AC4 RID: 84676 RVA: 0x00533AF0 File Offset: 0x00531CF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIData>.NativeClassPtr));
			}
		}

		// Token: 0x17007501 RID: 29953
		// (get) Token: 0x06014AC5 RID: 84677 RVA: 0x00533B04 File Offset: 0x00531D04
		// (set) Token: 0x06014AC6 RID: 84678 RVA: 0x00533B2C File Offset: 0x00531D2C
		public unsafe AIClassTypes ClassType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_ClassType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_ClassType)) = value;
			}
		}

		// Token: 0x17007502 RID: 29954
		// (get) Token: 0x06014AC7 RID: 84679 RVA: 0x00533B50 File Offset: 0x00531D50
		// (set) Token: 0x06014AC8 RID: 84680 RVA: 0x00533B84 File Offset: 0x00531D84
		public unsafe List<AIState> PossibleStates
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_PossibleStates);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<AIState>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_PossibleStates), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007503 RID: 29955
		// (get) Token: 0x06014AC9 RID: 84681 RVA: 0x00533BAC File Offset: 0x00531DAC
		// (set) Token: 0x06014ACA RID: 84682 RVA: 0x00533BE0 File Offset: 0x00531DE0
		public unsafe List<FactionPrefabData> FactionData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FactionData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<FactionPrefabData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FactionData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007504 RID: 29956
		// (get) Token: 0x06014ACB RID: 84683 RVA: 0x00533C08 File Offset: 0x00531E08
		// (set) Token: 0x06014ACC RID: 84684 RVA: 0x00533C3C File Offset: 0x00531E3C
		public unsafe Dictionary<Faction, FactionPrefabData> FactionDataByFaction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FactionDataByFaction);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<Faction, FactionPrefabData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FactionDataByFaction), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007505 RID: 29957
		// (get) Token: 0x06014ACD RID: 84685 RVA: 0x00533C64 File Offset: 0x00531E64
		// (set) Token: 0x06014ACE RID: 84686 RVA: 0x00533C98 File Offset: 0x00531E98
		public unsafe List<StatsData> StatsPerDifficultyLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_StatsPerDifficultyLevel);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<StatsData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_StatsPerDifficultyLevel), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007506 RID: 29958
		// (get) Token: 0x06014ACF RID: 84687 RVA: 0x00533CC0 File Offset: 0x00531EC0
		// (set) Token: 0x06014AD0 RID: 84688 RVA: 0x00533CF4 File Offset: 0x00531EF4
		public unsafe List<VisionStatesData> IdleVisionPerDifficultyLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_IdleVisionPerDifficultyLevel);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<VisionStatesData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_IdleVisionPerDifficultyLevel), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007507 RID: 29959
		// (get) Token: 0x06014AD1 RID: 84689 RVA: 0x00533D1C File Offset: 0x00531F1C
		// (set) Token: 0x06014AD2 RID: 84690 RVA: 0x00533D50 File Offset: 0x00531F50
		public unsafe List<VisionStatesData> CombatVisionPerDifficultyLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_CombatVisionPerDifficultyLevel);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<VisionStatesData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_CombatVisionPerDifficultyLevel), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007508 RID: 29960
		// (get) Token: 0x06014AD3 RID: 84691 RVA: 0x00533D78 File Offset: 0x00531F78
		// (set) Token: 0x06014AD4 RID: 84692 RVA: 0x00533DAC File Offset: 0x00531FAC
		public unsafe AlertData FriendlyDeathAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FriendlyDeathAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FriendlyDeathAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007509 RID: 29961
		// (get) Token: 0x06014AD5 RID: 84693 RVA: 0x00533DD4 File Offset: 0x00531FD4
		// (set) Token: 0x06014AD6 RID: 84694 RVA: 0x00533E08 File Offset: 0x00532008
		public unsafe AlertData FriendlyDeadAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FriendlyDeadAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FriendlyDeadAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700750A RID: 29962
		// (get) Token: 0x06014AD7 RID: 84695 RVA: 0x00533E30 File Offset: 0x00532030
		// (set) Token: 0x06014AD8 RID: 84696 RVA: 0x00533E64 File Offset: 0x00532064
		public unsafe AlertData EnemyDeathAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemyDeathAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemyDeathAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700750B RID: 29963
		// (get) Token: 0x06014AD9 RID: 84697 RVA: 0x00533E8C File Offset: 0x0053208C
		// (set) Token: 0x06014ADA RID: 84698 RVA: 0x00533EC0 File Offset: 0x005320C0
		public unsafe AlertData EnemyDeadAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemyDeadAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemyDeadAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700750C RID: 29964
		// (get) Token: 0x06014ADB RID: 84699 RVA: 0x00533EE8 File Offset: 0x005320E8
		// (set) Token: 0x06014ADC RID: 84700 RVA: 0x00533F1C File Offset: 0x0053211C
		public unsafe AlertData TookDamageAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_TookDamageAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_TookDamageAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700750D RID: 29965
		// (get) Token: 0x06014ADD RID: 84701 RVA: 0x00533F44 File Offset: 0x00532144
		// (set) Token: 0x06014ADE RID: 84702 RVA: 0x00533F78 File Offset: 0x00532178
		public unsafe AlertData EnemySpottedAlert
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemySpottedAlert);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AlertData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_EnemySpottedAlert), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700750E RID: 29966
		// (get) Token: 0x06014ADF RID: 84703 RVA: 0x00533FA0 File Offset: 0x005321A0
		// (set) Token: 0x06014AE0 RID: 84704 RVA: 0x00533FC8 File Offset: 0x005321C8
		public unsafe LayerMask GrenadeHeightCheckLayers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_GrenadeHeightCheckLayers);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_GrenadeHeightCheckLayers)) = value;
			}
		}

		// Token: 0x1700750F RID: 29967
		// (get) Token: 0x06014AE1 RID: 84705 RVA: 0x00533FEC File Offset: 0x005321EC
		// (set) Token: 0x06014AE2 RID: 84706 RVA: 0x00534014 File Offset: 0x00532214
		public unsafe float FragGrenadeMinCeilingHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FragGrenadeMinCeilingHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIData.NativeFieldInfoPtr_FragGrenadeMinCeilingHeight)) = value;
			}
		}

		// Token: 0x0400D369 RID: 54121
		private static readonly IntPtr NativeFieldInfoPtr_ClassType;

		// Token: 0x0400D36A RID: 54122
		private static readonly IntPtr NativeFieldInfoPtr_PossibleStates;

		// Token: 0x0400D36B RID: 54123
		private static readonly IntPtr NativeFieldInfoPtr_FactionData;

		// Token: 0x0400D36C RID: 54124
		private static readonly IntPtr NativeFieldInfoPtr_FactionDataByFaction;

		// Token: 0x0400D36D RID: 54125
		private static readonly IntPtr NativeFieldInfoPtr_StatsPerDifficultyLevel;

		// Token: 0x0400D36E RID: 54126
		private static readonly IntPtr NativeFieldInfoPtr_IdleVisionPerDifficultyLevel;

		// Token: 0x0400D36F RID: 54127
		private static readonly IntPtr NativeFieldInfoPtr_CombatVisionPerDifficultyLevel;

		// Token: 0x0400D370 RID: 54128
		private static readonly IntPtr NativeFieldInfoPtr_FriendlyDeathAlert;

		// Token: 0x0400D371 RID: 54129
		private static readonly IntPtr NativeFieldInfoPtr_FriendlyDeadAlert;

		// Token: 0x0400D372 RID: 54130
		private static readonly IntPtr NativeFieldInfoPtr_EnemyDeathAlert;

		// Token: 0x0400D373 RID: 54131
		private static readonly IntPtr NativeFieldInfoPtr_EnemyDeadAlert;

		// Token: 0x0400D374 RID: 54132
		private static readonly IntPtr NativeFieldInfoPtr_TookDamageAlert;

		// Token: 0x0400D375 RID: 54133
		private static readonly IntPtr NativeFieldInfoPtr_EnemySpottedAlert;

		// Token: 0x0400D376 RID: 54134
		private static readonly IntPtr NativeFieldInfoPtr_GrenadeHeightCheckLayers;

		// Token: 0x0400D377 RID: 54135
		private static readonly IntPtr NativeFieldInfoPtr_FragGrenadeMinCeilingHeight;

		// Token: 0x0400D378 RID: 54136
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_Void_0;

		// Token: 0x0400D379 RID: 54137
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
