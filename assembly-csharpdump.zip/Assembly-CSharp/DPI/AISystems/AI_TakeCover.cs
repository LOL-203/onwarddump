﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001182 RID: 4482
	public class AI_TakeCover : AIState
	{
		// Token: 0x06014D64 RID: 85348 RVA: 0x0053D528 File Offset: 0x0053B728
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D65 RID: 85349 RVA: 0x0053D578 File Offset: 0x0053B778
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCover.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D66 RID: 85350 RVA: 0x0053D5E4 File Offset: 0x0053B7E4
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D67 RID: 85351 RVA: 0x0053D634 File Offset: 0x0053B834
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D68 RID: 85352 RVA: 0x0053D694 File Offset: 0x0053B894
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCover.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D69 RID: 85353 RVA: 0x0053D6D8 File Offset: 0x0053B8D8
		[CallerCount(0)]
		public unsafe AI_TakeCover() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCover.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D6A RID: 85354 RVA: 0x0053D724 File Offset: 0x0053B924
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCover()
		{
			Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCover");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr);
			AI_TakeCover.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, "MaxCoverDistance");
			AI_TakeCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689862);
			AI_TakeCover.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689863);
			AI_TakeCover.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689864);
			AI_TakeCover.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689865);
			AI_TakeCover.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689866);
			AI_TakeCover.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr, 100689867);
		}

		// Token: 0x06014D6B RID: 85355 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCover(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075E3 RID: 30179
		// (get) Token: 0x06014D6C RID: 85356 RVA: 0x0053D7E0 File Offset: 0x0053B9E0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCover>.NativeClassPtr));
			}
		}

		// Token: 0x170075E4 RID: 30180
		// (get) Token: 0x06014D6D RID: 85357 RVA: 0x0053D7F4 File Offset: 0x0053B9F4
		// (set) Token: 0x06014D6E RID: 85358 RVA: 0x0053D81C File Offset: 0x0053BA1C
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCover.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCover.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x0400D4DA RID: 54490
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D4DB RID: 54491
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4DC RID: 54492
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D4DD RID: 54493
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D4DE RID: 54494
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D4DF RID: 54495
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D4E0 RID: 54496
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
