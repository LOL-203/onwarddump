﻿using System;
using AISystems.Objectives;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001166 RID: 4454
	public class AI_GoToPlayer : AIState
	{
		// Token: 0x06014BCD RID: 84941 RVA: 0x00537AA8 File Offset: 0x00535CA8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToPlayer.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BCE RID: 84942 RVA: 0x00537AF8 File Offset: 0x00535CF8
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToPlayer.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BCF RID: 84943 RVA: 0x00537B48 File Offset: 0x00535D48
		[CallerCount(0)]
		public unsafe void CalculatePath()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToPlayer.NativeMethodInfoPtr_CalculatePath_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BD0 RID: 84944 RVA: 0x00537B8C File Offset: 0x00535D8C
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToPlayer.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BD1 RID: 84945 RVA: 0x00537BD0 File Offset: 0x00535DD0
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToPlayer.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BD2 RID: 84946 RVA: 0x00537C30 File Offset: 0x00535E30
		[CallerCount(0)]
		public unsafe AI_GoToPlayer() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToPlayer.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BD3 RID: 84947 RVA: 0x00537C7C File Offset: 0x00535E7C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_GoToPlayer()
		{
			Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_GoToPlayer");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr);
			AI_GoToPlayer.NativeFieldInfoPtr_MinDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "MinDistance");
			AI_GoToPlayer.NativeFieldInfoPtr_MaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "MaxDistance");
			AI_GoToPlayer.NativeFieldInfoPtr_RecalcDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "RecalcDistance");
			AI_GoToPlayer.NativeFieldInfoPtr__recalcDistSqrd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "_recalcDistSqrd");
			AI_GoToPlayer.NativeFieldInfoPtr__pathType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "_pathType");
			AI_GoToPlayer.NativeFieldInfoPtr__pathPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "_pathPos");
			AI_GoToPlayer.NativeFieldInfoPtr__objective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, "_objective");
			AI_GoToPlayer.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689755);
			AI_GoToPlayer.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689756);
			AI_GoToPlayer.NativeMethodInfoPtr_CalculatePath_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689757);
			AI_GoToPlayer.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689758);
			AI_GoToPlayer.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689759);
			AI_GoToPlayer.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr, 100689760);
		}

		// Token: 0x06014BD4 RID: 84948 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_GoToPlayer(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700755B RID: 30043
		// (get) Token: 0x06014BD5 RID: 84949 RVA: 0x00537DB0 File Offset: 0x00535FB0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_GoToPlayer>.NativeClassPtr));
			}
		}

		// Token: 0x1700755C RID: 30044
		// (get) Token: 0x06014BD6 RID: 84950 RVA: 0x00537DC4 File Offset: 0x00535FC4
		// (set) Token: 0x06014BD7 RID: 84951 RVA: 0x00537DEC File Offset: 0x00535FEC
		public unsafe float MinDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_MinDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_MinDistance)) = value;
			}
		}

		// Token: 0x1700755D RID: 30045
		// (get) Token: 0x06014BD8 RID: 84952 RVA: 0x00537E10 File Offset: 0x00536010
		// (set) Token: 0x06014BD9 RID: 84953 RVA: 0x00537E38 File Offset: 0x00536038
		public unsafe float MaxDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_MaxDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_MaxDistance)) = value;
			}
		}

		// Token: 0x1700755E RID: 30046
		// (get) Token: 0x06014BDA RID: 84954 RVA: 0x00537E5C File Offset: 0x0053605C
		// (set) Token: 0x06014BDB RID: 84955 RVA: 0x00537E84 File Offset: 0x00536084
		public unsafe float RecalcDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_RecalcDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr_RecalcDistance)) = value;
			}
		}

		// Token: 0x1700755F RID: 30047
		// (get) Token: 0x06014BDC RID: 84956 RVA: 0x00537EA8 File Offset: 0x005360A8
		// (set) Token: 0x06014BDD RID: 84957 RVA: 0x00537ED0 File Offset: 0x005360D0
		public unsafe float _recalcDistSqrd
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__recalcDistSqrd);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__recalcDistSqrd)) = value;
			}
		}

		// Token: 0x17007560 RID: 30048
		// (get) Token: 0x06014BDE RID: 84958 RVA: 0x00537EF4 File Offset: 0x005360F4
		// (set) Token: 0x06014BDF RID: 84959 RVA: 0x00537F1C File Offset: 0x0053611C
		public unsafe PathType _pathType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__pathType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__pathType)) = value;
			}
		}

		// Token: 0x17007561 RID: 30049
		// (get) Token: 0x06014BE0 RID: 84960 RVA: 0x00537F40 File Offset: 0x00536140
		// (set) Token: 0x06014BE1 RID: 84961 RVA: 0x00537F68 File Offset: 0x00536168
		public unsafe Vector3 _pathPos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__pathPos);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__pathPos)) = value;
			}
		}

		// Token: 0x17007562 RID: 30050
		// (get) Token: 0x06014BE2 RID: 84962 RVA: 0x00537F8C File Offset: 0x0053618C
		// (set) Token: 0x06014BE3 RID: 84963 RVA: 0x00537FC0 File Offset: 0x005361C0
		public unsafe TrackPlayerObjective _objective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__objective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TrackPlayerObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToPlayer.NativeFieldInfoPtr__objective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D403 RID: 54275
		private static readonly IntPtr NativeFieldInfoPtr_MinDistance;

		// Token: 0x0400D404 RID: 54276
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistance;

		// Token: 0x0400D405 RID: 54277
		private static readonly IntPtr NativeFieldInfoPtr_RecalcDistance;

		// Token: 0x0400D406 RID: 54278
		private static readonly IntPtr NativeFieldInfoPtr__recalcDistSqrd;

		// Token: 0x0400D407 RID: 54279
		private static readonly IntPtr NativeFieldInfoPtr__pathType;

		// Token: 0x0400D408 RID: 54280
		private static readonly IntPtr NativeFieldInfoPtr__pathPos;

		// Token: 0x0400D409 RID: 54281
		private static readonly IntPtr NativeFieldInfoPtr__objective;

		// Token: 0x0400D40A RID: 54282
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D40B RID: 54283
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D40C RID: 54284
		private static readonly IntPtr NativeMethodInfoPtr_CalculatePath_Private_Void_0;

		// Token: 0x0400D40D RID: 54285
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D40E RID: 54286
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D40F RID: 54287
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
