﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Locators;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x0200118B RID: 4491
	public class AI_ThrowFragGrenade : AIState
	{
		// Token: 0x06014DE1 RID: 85473 RVA: 0x0053F4C4 File Offset: 0x0053D6C4
		[CallerCount(0)]
		public new unsafe Vector3 GetStateDrivenLookPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFragGrenade.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014DE2 RID: 85474 RVA: 0x0053F520 File Offset: 0x0053D720
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFragGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DE3 RID: 85475 RVA: 0x0053F570 File Offset: 0x0053D770
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFragGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DE4 RID: 85476 RVA: 0x0053F5C0 File Offset: 0x0053D7C0
		[CallerCount(0)]
		public unsafe IEnumerator Throw()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade.NativeMethodInfoPtr_Throw_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06014DE5 RID: 85477 RVA: 0x0053F618 File Offset: 0x0053D818
		[CallerCount(0)]
		public unsafe AI_ThrowFragGrenade() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DE6 RID: 85478 RVA: 0x0053F664 File Offset: 0x0053D864
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ThrowFragGrenade()
		{
			Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ThrowFragGrenade");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr);
			AI_ThrowFragGrenade.NativeFieldInfoPtr_MinThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "MinThrowAccuracy");
			AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "MaxThrowAccuracy");
			AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "MaxThrowDistance");
			AI_ThrowFragGrenade.NativeFieldInfoPtr__throwrutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "_throwrutine");
			AI_ThrowFragGrenade.NativeFieldInfoPtr__throwPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "_throwPosition");
			AI_ThrowFragGrenade.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, 100689910);
			AI_ThrowFragGrenade.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, 100689911);
			AI_ThrowFragGrenade.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, 100689912);
			AI_ThrowFragGrenade.NativeMethodInfoPtr_Throw_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, 100689913);
			AI_ThrowFragGrenade.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, 100689914);
		}

		// Token: 0x06014DE7 RID: 85479 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ThrowFragGrenade(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007607 RID: 30215
		// (get) Token: 0x06014DE8 RID: 85480 RVA: 0x0053F75C File Offset: 0x0053D95C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr));
			}
		}

		// Token: 0x17007608 RID: 30216
		// (get) Token: 0x06014DE9 RID: 85481 RVA: 0x0053F770 File Offset: 0x0053D970
		// (set) Token: 0x06014DEA RID: 85482 RVA: 0x0053F798 File Offset: 0x0053D998
		public unsafe float MinThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MinThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MinThrowAccuracy)) = value;
			}
		}

		// Token: 0x17007609 RID: 30217
		// (get) Token: 0x06014DEB RID: 85483 RVA: 0x0053F7BC File Offset: 0x0053D9BC
		// (set) Token: 0x06014DEC RID: 85484 RVA: 0x0053F7E4 File Offset: 0x0053D9E4
		public unsafe float MaxThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowAccuracy)) = value;
			}
		}

		// Token: 0x1700760A RID: 30218
		// (get) Token: 0x06014DED RID: 85485 RVA: 0x0053F808 File Offset: 0x0053DA08
		// (set) Token: 0x06014DEE RID: 85486 RVA: 0x0053F830 File Offset: 0x0053DA30
		public unsafe float MaxThrowDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr_MaxThrowDistance)) = value;
			}
		}

		// Token: 0x1700760B RID: 30219
		// (get) Token: 0x06014DEF RID: 85487 RVA: 0x0053F854 File Offset: 0x0053DA54
		// (set) Token: 0x06014DF0 RID: 85488 RVA: 0x0053F888 File Offset: 0x0053DA88
		public unsafe Coroutine _throwrutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr__throwrutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr__throwrutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700760C RID: 30220
		// (get) Token: 0x06014DF1 RID: 85489 RVA: 0x0053F8B0 File Offset: 0x0053DAB0
		// (set) Token: 0x06014DF2 RID: 85490 RVA: 0x0053F8D8 File Offset: 0x0053DAD8
		public unsafe Vector3 _throwPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr__throwPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade.NativeFieldInfoPtr__throwPosition)) = value;
			}
		}

		// Token: 0x0400D523 RID: 54563
		private static readonly IntPtr NativeFieldInfoPtr_MinThrowAccuracy;

		// Token: 0x0400D524 RID: 54564
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowAccuracy;

		// Token: 0x0400D525 RID: 54565
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowDistance;

		// Token: 0x0400D526 RID: 54566
		private static readonly IntPtr NativeFieldInfoPtr__throwrutine;

		// Token: 0x0400D527 RID: 54567
		private static readonly IntPtr NativeFieldInfoPtr__throwPosition;

		// Token: 0x0400D528 RID: 54568
		private static readonly IntPtr NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0;

		// Token: 0x0400D529 RID: 54569
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D52A RID: 54570
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D52B RID: 54571
		private static readonly IntPtr NativeMethodInfoPtr_Throw_Private_IEnumerator_0;

		// Token: 0x0400D52C RID: 54572
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200118C RID: 4492
		[ObfuscatedName("DPI.AISystems.AI_ThrowFragGrenade/<Throw>d__8")]
		public sealed class _Throw_d__8 : Il2CppSystem.Object
		{
			// Token: 0x06014DF3 RID: 85491 RVA: 0x0053F8FC File Offset: 0x0053DAFC
			[CallerCount(0)]
			public unsafe _Throw_d__8(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014DF4 RID: 85492 RVA: 0x0053F95C File Offset: 0x0053DB5C
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014DF5 RID: 85493 RVA: 0x0053F9A0 File Offset: 0x0053DBA0
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17007614 RID: 30228
			// (get) Token: 0x06014DF6 RID: 85494 RVA: 0x0053F9F0 File Offset: 0x0053DBF0
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014DF7 RID: 85495 RVA: 0x0053FA48 File Offset: 0x0053DC48
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17007615 RID: 30229
			// (get) Token: 0x06014DF8 RID: 85496 RVA: 0x0053FA8C File Offset: 0x0053DC8C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014DF9 RID: 85497 RVA: 0x0053FAE4 File Offset: 0x0053DCE4
			// Note: this type is marked as 'beforefieldinit'.
			static _Throw_d__8()
			{
				Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AI_ThrowFragGrenade>.NativeClassPtr, "<Throw>d__8");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr);
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<>1__state");
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<>2__current");
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<>4__this");
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<currentWeapon>5__2");
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<grenade>5__3");
				AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, "<startLocator>5__4");
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689915);
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689916);
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689917);
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689918);
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689919);
				AI_ThrowFragGrenade._Throw_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr, 100689920);
			}

			// Token: 0x06014DFA RID: 85498 RVA: 0x00002988 File Offset: 0x00000B88
			public _Throw_d__8(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700760D RID: 30221
			// (get) Token: 0x06014DFB RID: 85499 RVA: 0x0053FBFF File Offset: 0x0053DDFF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowFragGrenade._Throw_d__8>.NativeClassPtr));
				}
			}

			// Token: 0x1700760E RID: 30222
			// (get) Token: 0x06014DFC RID: 85500 RVA: 0x0053FC10 File Offset: 0x0053DE10
			// (set) Token: 0x06014DFD RID: 85501 RVA: 0x0053FC38 File Offset: 0x0053DE38
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x1700760F RID: 30223
			// (get) Token: 0x06014DFE RID: 85502 RVA: 0x0053FC5C File Offset: 0x0053DE5C
			// (set) Token: 0x06014DFF RID: 85503 RVA: 0x0053FC90 File Offset: 0x0053DE90
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007610 RID: 30224
			// (get) Token: 0x06014E00 RID: 85504 RVA: 0x0053FCB8 File Offset: 0x0053DEB8
			// (set) Token: 0x06014E01 RID: 85505 RVA: 0x0053FCEC File Offset: 0x0053DEEC
			public unsafe AI_ThrowFragGrenade __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new AI_ThrowFragGrenade(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007611 RID: 30225
			// (get) Token: 0x06014E02 RID: 85506 RVA: 0x0053FD14 File Offset: 0x0053DF14
			// (set) Token: 0x06014E03 RID: 85507 RVA: 0x0053FD48 File Offset: 0x0053DF48
			public unsafe Pickup _currentWeapon_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__currentWeapon_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007612 RID: 30226
			// (get) Token: 0x06014E04 RID: 85508 RVA: 0x0053FD70 File Offset: 0x0053DF70
			// (set) Token: 0x06014E05 RID: 85509 RVA: 0x0053FDA4 File Offset: 0x0053DFA4
			public unsafe Pickup_Grenade _grenade_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup_Grenade(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__grenade_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007613 RID: 30227
			// (get) Token: 0x06014E06 RID: 85510 RVA: 0x0053FDCC File Offset: 0x0053DFCC
			// (set) Token: 0x06014E07 RID: 85511 RVA: 0x0053FE00 File Offset: 0x0053E000
			public unsafe Locator _startLocator_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Locator(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFragGrenade._Throw_d__8.NativeFieldInfoPtr__startLocator_5__4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400D52D RID: 54573
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400D52E RID: 54574
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400D52F RID: 54575
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400D530 RID: 54576
			private static readonly IntPtr NativeFieldInfoPtr__currentWeapon_5__2;

			// Token: 0x0400D531 RID: 54577
			private static readonly IntPtr NativeFieldInfoPtr__grenade_5__3;

			// Token: 0x0400D532 RID: 54578
			private static readonly IntPtr NativeFieldInfoPtr__startLocator_5__4;

			// Token: 0x0400D533 RID: 54579
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400D534 RID: 54580
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D535 RID: 54581
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400D536 RID: 54582
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400D537 RID: 54583
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D538 RID: 54584
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
