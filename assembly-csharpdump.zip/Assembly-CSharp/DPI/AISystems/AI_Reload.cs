﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200117A RID: 4474
	public class AI_Reload : AIState
	{
		// Token: 0x06014CE3 RID: 85219 RVA: 0x0053B850 File Offset: 0x00539A50
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Reload.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CE4 RID: 85220 RVA: 0x0053B8A0 File Offset: 0x00539AA0
		[CallerCount(0)]
		public new unsafe void Tick(float deltaTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref deltaTime;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Reload.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CE5 RID: 85221 RVA: 0x0053B900 File Offset: 0x00539B00
		[CallerCount(0)]
		public unsafe AI_Reload() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Reload.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CE6 RID: 85222 RVA: 0x0053B94C File Offset: 0x00539B4C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Reload()
		{
			Il2CppClassPointerStore<AI_Reload>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Reload");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr);
			AI_Reload.NativeFieldInfoPtr_ReloadDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr, "ReloadDuration");
			AI_Reload.NativeFieldInfoPtr__reloadEnd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr, "_reloadEnd");
			AI_Reload.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr, 100689829);
			AI_Reload.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr, 100689830);
			AI_Reload.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr, 100689831);
		}

		// Token: 0x06014CE7 RID: 85223 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_Reload(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075B7 RID: 30135
		// (get) Token: 0x06014CE8 RID: 85224 RVA: 0x0053B9E0 File Offset: 0x00539BE0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Reload>.NativeClassPtr));
			}
		}

		// Token: 0x170075B8 RID: 30136
		// (get) Token: 0x06014CE9 RID: 85225 RVA: 0x0053B9F4 File Offset: 0x00539BF4
		// (set) Token: 0x06014CEA RID: 85226 RVA: 0x0053BA1C File Offset: 0x00539C1C
		public unsafe float ReloadDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Reload.NativeFieldInfoPtr_ReloadDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Reload.NativeFieldInfoPtr_ReloadDuration)) = value;
			}
		}

		// Token: 0x170075B9 RID: 30137
		// (get) Token: 0x06014CEB RID: 85227 RVA: 0x0053BA40 File Offset: 0x00539C40
		// (set) Token: 0x06014CEC RID: 85228 RVA: 0x0053BA68 File Offset: 0x00539C68
		public unsafe float _reloadEnd
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Reload.NativeFieldInfoPtr__reloadEnd);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Reload.NativeFieldInfoPtr__reloadEnd)) = value;
			}
		}

		// Token: 0x0400D495 RID: 54421
		private static readonly IntPtr NativeFieldInfoPtr_ReloadDuration;

		// Token: 0x0400D496 RID: 54422
		private static readonly IntPtr NativeFieldInfoPtr__reloadEnd;

		// Token: 0x0400D497 RID: 54423
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D498 RID: 54424
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D499 RID: 54425
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
