﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200117B RID: 4475
	public class AI_SearchForTarget : AIState
	{
		// Token: 0x06014CED RID: 85229 RVA: 0x0053BA8C File Offset: 0x00539C8C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_SearchForTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CEE RID: 85230 RVA: 0x0053BADC File Offset: 0x00539CDC
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_SearchForTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CEF RID: 85231 RVA: 0x0053BB2C File Offset: 0x00539D2C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_SearchForTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CF0 RID: 85232 RVA: 0x0053BB8C File Offset: 0x00539D8C
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_SearchForTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CF1 RID: 85233 RVA: 0x0053BBD0 File Offset: 0x00539DD0
		[CallerCount(0)]
		public unsafe void OnPathThroughDoor(NavigationNode doorNode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(doorNode));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_SearchForTarget.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CF2 RID: 85234 RVA: 0x0053BC30 File Offset: 0x00539E30
		[CallerCount(0)]
		public unsafe AI_SearchForTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_SearchForTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014CF3 RID: 85235 RVA: 0x0053BC7C File Offset: 0x00539E7C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_SearchForTarget()
		{
			Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_SearchForTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr);
			AI_SearchForTarget.NativeFieldInfoPtr_MinWanderDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MinWanderDistance");
			AI_SearchForTarget.NativeFieldInfoPtr_MaxWanderDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MaxWanderDistance");
			AI_SearchForTarget.NativeFieldInfoPtr_MinFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MinFlashDistance");
			AI_SearchForTarget.NativeFieldInfoPtr_MaxFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MaxFlashDistance");
			AI_SearchForTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MinFriendlySafeFlashDistance");
			AI_SearchForTarget.NativeFieldInfoPtr_MaxTargetFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, "MaxTargetFlashDistance");
			AI_SearchForTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689832);
			AI_SearchForTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689833);
			AI_SearchForTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689834);
			AI_SearchForTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689835);
			AI_SearchForTarget.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689836);
			AI_SearchForTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr, 100689837);
		}

		// Token: 0x06014CF4 RID: 85236 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_SearchForTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075BA RID: 30138
		// (get) Token: 0x06014CF5 RID: 85237 RVA: 0x0053BD9C File Offset: 0x00539F9C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_SearchForTarget>.NativeClassPtr));
			}
		}

		// Token: 0x170075BB RID: 30139
		// (get) Token: 0x06014CF6 RID: 85238 RVA: 0x0053BDB0 File Offset: 0x00539FB0
		// (set) Token: 0x06014CF7 RID: 85239 RVA: 0x0053BDD8 File Offset: 0x00539FD8
		public unsafe float MinWanderDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinWanderDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinWanderDistance)) = value;
			}
		}

		// Token: 0x170075BC RID: 30140
		// (get) Token: 0x06014CF8 RID: 85240 RVA: 0x0053BDFC File Offset: 0x00539FFC
		// (set) Token: 0x06014CF9 RID: 85241 RVA: 0x0053BE24 File Offset: 0x0053A024
		public unsafe float MaxWanderDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxWanderDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxWanderDistance)) = value;
			}
		}

		// Token: 0x170075BD RID: 30141
		// (get) Token: 0x06014CFA RID: 85242 RVA: 0x0053BE48 File Offset: 0x0053A048
		// (set) Token: 0x06014CFB RID: 85243 RVA: 0x0053BE70 File Offset: 0x0053A070
		public unsafe float MinFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinFlashDistance)) = value;
			}
		}

		// Token: 0x170075BE RID: 30142
		// (get) Token: 0x06014CFC RID: 85244 RVA: 0x0053BE94 File Offset: 0x0053A094
		// (set) Token: 0x06014CFD RID: 85245 RVA: 0x0053BEBC File Offset: 0x0053A0BC
		public unsafe float MaxFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxFlashDistance)) = value;
			}
		}

		// Token: 0x170075BF RID: 30143
		// (get) Token: 0x06014CFE RID: 85246 RVA: 0x0053BEE0 File Offset: 0x0053A0E0
		// (set) Token: 0x06014CFF RID: 85247 RVA: 0x0053BF08 File Offset: 0x0053A108
		public unsafe float MinFriendlySafeFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance)) = value;
			}
		}

		// Token: 0x170075C0 RID: 30144
		// (get) Token: 0x06014D00 RID: 85248 RVA: 0x0053BF2C File Offset: 0x0053A12C
		// (set) Token: 0x06014D01 RID: 85249 RVA: 0x0053BF54 File Offset: 0x0053A154
		public unsafe float MaxTargetFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxTargetFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_SearchForTarget.NativeFieldInfoPtr_MaxTargetFlashDistance)) = value;
			}
		}

		// Token: 0x0400D49A RID: 54426
		private static readonly IntPtr NativeFieldInfoPtr_MinWanderDistance;

		// Token: 0x0400D49B RID: 54427
		private static readonly IntPtr NativeFieldInfoPtr_MaxWanderDistance;

		// Token: 0x0400D49C RID: 54428
		private static readonly IntPtr NativeFieldInfoPtr_MinFlashDistance;

		// Token: 0x0400D49D RID: 54429
		private static readonly IntPtr NativeFieldInfoPtr_MaxFlashDistance;

		// Token: 0x0400D49E RID: 54430
		private static readonly IntPtr NativeFieldInfoPtr_MinFriendlySafeFlashDistance;

		// Token: 0x0400D49F RID: 54431
		private static readonly IntPtr NativeFieldInfoPtr_MaxTargetFlashDistance;

		// Token: 0x0400D4A0 RID: 54432
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4A1 RID: 54433
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D4A2 RID: 54434
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D4A3 RID: 54435
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D4A4 RID: 54436
		private static readonly IntPtr NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0;

		// Token: 0x0400D4A5 RID: 54437
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
