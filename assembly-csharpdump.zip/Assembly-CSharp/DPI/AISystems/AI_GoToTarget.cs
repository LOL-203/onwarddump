﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001167 RID: 4455
	public class AI_GoToTarget : AIState
	{
		// Token: 0x06014BE4 RID: 84964 RVA: 0x00537FE8 File Offset: 0x005361E8
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BE5 RID: 84965 RVA: 0x00538038 File Offset: 0x00536238
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BE6 RID: 84966 RVA: 0x00538088 File Offset: 0x00536288
		[CallerCount(0)]
		public unsafe void OnReachedDestination()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BE7 RID: 84967 RVA: 0x005380CC File Offset: 0x005362CC
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_GoToTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BE8 RID: 84968 RVA: 0x0053812C File Offset: 0x0053632C
		[CallerCount(0)]
		public unsafe void OnPathThroughDoor(NavigationNode doorNode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(doorNode));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToTarget.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BE9 RID: 84969 RVA: 0x0053818C File Offset: 0x0053638C
		[CallerCount(0)]
		public unsafe AI_GoToTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_GoToTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014BEA RID: 84970 RVA: 0x005381D8 File Offset: 0x005363D8
		// Note: this type is marked as 'beforefieldinit'.
		static AI_GoToTarget()
		{
			Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_GoToTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr);
			AI_GoToTarget.NativeFieldInfoPtr_MinDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MinDistance");
			AI_GoToTarget.NativeFieldInfoPtr_MaxDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MaxDistance");
			AI_GoToTarget.NativeFieldInfoPtr_MinFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MinFlashDistance");
			AI_GoToTarget.NativeFieldInfoPtr_MaxFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MaxFlashDistance");
			AI_GoToTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MinFriendlySafeFlashDistance");
			AI_GoToTarget.NativeFieldInfoPtr_MaxTargetFlashDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "MaxTargetFlashDistance");
			AI_GoToTarget.NativeFieldInfoPtr__movePosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, "_movePosition");
			AI_GoToTarget.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689761);
			AI_GoToTarget.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689762);
			AI_GoToTarget.NativeMethodInfoPtr_OnReachedDestination_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689763);
			AI_GoToTarget.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689764);
			AI_GoToTarget.NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689765);
			AI_GoToTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr, 100689766);
		}

		// Token: 0x06014BEB RID: 84971 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_GoToTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007563 RID: 30051
		// (get) Token: 0x06014BEC RID: 84972 RVA: 0x0053830C File Offset: 0x0053650C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_GoToTarget>.NativeClassPtr));
			}
		}

		// Token: 0x17007564 RID: 30052
		// (get) Token: 0x06014BED RID: 84973 RVA: 0x00538320 File Offset: 0x00536520
		// (set) Token: 0x06014BEE RID: 84974 RVA: 0x00538348 File Offset: 0x00536548
		public unsafe float MinDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinDistance)) = value;
			}
		}

		// Token: 0x17007565 RID: 30053
		// (get) Token: 0x06014BEF RID: 84975 RVA: 0x0053836C File Offset: 0x0053656C
		// (set) Token: 0x06014BF0 RID: 84976 RVA: 0x00538394 File Offset: 0x00536594
		public unsafe float MaxDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxDistance)) = value;
			}
		}

		// Token: 0x17007566 RID: 30054
		// (get) Token: 0x06014BF1 RID: 84977 RVA: 0x005383B8 File Offset: 0x005365B8
		// (set) Token: 0x06014BF2 RID: 84978 RVA: 0x005383E0 File Offset: 0x005365E0
		public unsafe float MinFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinFlashDistance)) = value;
			}
		}

		// Token: 0x17007567 RID: 30055
		// (get) Token: 0x06014BF3 RID: 84979 RVA: 0x00538404 File Offset: 0x00536604
		// (set) Token: 0x06014BF4 RID: 84980 RVA: 0x0053842C File Offset: 0x0053662C
		public unsafe float MaxFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxFlashDistance)) = value;
			}
		}

		// Token: 0x17007568 RID: 30056
		// (get) Token: 0x06014BF5 RID: 84981 RVA: 0x00538450 File Offset: 0x00536650
		// (set) Token: 0x06014BF6 RID: 84982 RVA: 0x00538478 File Offset: 0x00536678
		public unsafe float MinFriendlySafeFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MinFriendlySafeFlashDistance)) = value;
			}
		}

		// Token: 0x17007569 RID: 30057
		// (get) Token: 0x06014BF7 RID: 84983 RVA: 0x0053849C File Offset: 0x0053669C
		// (set) Token: 0x06014BF8 RID: 84984 RVA: 0x005384C4 File Offset: 0x005366C4
		public unsafe float MaxTargetFlashDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxTargetFlashDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr_MaxTargetFlashDistance)) = value;
			}
		}

		// Token: 0x1700756A RID: 30058
		// (get) Token: 0x06014BF9 RID: 84985 RVA: 0x005384E8 File Offset: 0x005366E8
		// (set) Token: 0x06014BFA RID: 84986 RVA: 0x00538510 File Offset: 0x00536710
		public unsafe Vector3 _movePosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr__movePosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_GoToTarget.NativeFieldInfoPtr__movePosition)) = value;
			}
		}

		// Token: 0x0400D410 RID: 54288
		private static readonly IntPtr NativeFieldInfoPtr_MinDistance;

		// Token: 0x0400D411 RID: 54289
		private static readonly IntPtr NativeFieldInfoPtr_MaxDistance;

		// Token: 0x0400D412 RID: 54290
		private static readonly IntPtr NativeFieldInfoPtr_MinFlashDistance;

		// Token: 0x0400D413 RID: 54291
		private static readonly IntPtr NativeFieldInfoPtr_MaxFlashDistance;

		// Token: 0x0400D414 RID: 54292
		private static readonly IntPtr NativeFieldInfoPtr_MinFriendlySafeFlashDistance;

		// Token: 0x0400D415 RID: 54293
		private static readonly IntPtr NativeFieldInfoPtr_MaxTargetFlashDistance;

		// Token: 0x0400D416 RID: 54294
		private static readonly IntPtr NativeFieldInfoPtr__movePosition;

		// Token: 0x0400D417 RID: 54295
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D418 RID: 54296
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D419 RID: 54297
		private static readonly IntPtr NativeMethodInfoPtr_OnReachedDestination_Private_Void_0;

		// Token: 0x0400D41A RID: 54298
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D41B RID: 54299
		private static readonly IntPtr NativeMethodInfoPtr_OnPathThroughDoor_Private_Void_NavigationNode_0;

		// Token: 0x0400D41C RID: 54300
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
