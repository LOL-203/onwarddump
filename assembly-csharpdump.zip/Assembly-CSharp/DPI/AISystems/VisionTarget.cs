﻿using System;
using DPI.AISystems.Alerts;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x0200119A RID: 4506
	public class VisionTarget : MonoBehaviour
	{
		// Token: 0x06014EBA RID: 85690 RVA: 0x00542744 File Offset: 0x00540944
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), VisionTarget.NativeMethodInfoPtr_OnEnable_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EBB RID: 85691 RVA: 0x00542794 File Offset: 0x00540994
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EBC RID: 85692 RVA: 0x005427D8 File Offset: 0x005409D8
		[CallerCount(0)]
		public unsafe void AddTarget()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_AddTarget_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EBD RID: 85693 RVA: 0x0054281C File Offset: 0x00540A1C
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EBE RID: 85694 RVA: 0x00542860 File Offset: 0x00540A60
		[CallerCount(0)]
		public unsafe void AddAlert(AlertData alertData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_AddAlert_Public_Void_AlertData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EBF RID: 85695 RVA: 0x005428BC File Offset: 0x00540ABC
		[CallerCount(0)]
		public unsafe void RemoveAlert(AlertData alertData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(alertData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_RemoveAlert_Public_Void_AlertData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EC0 RID: 85696 RVA: 0x00542918 File Offset: 0x00540B18
		[CallerCount(0)]
		public unsafe int GetID()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr_GetID_Public_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014EC1 RID: 85697 RVA: 0x00542968 File Offset: 0x00540B68
		[CallerCount(0)]
		public unsafe VisionTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EC2 RID: 85698 RVA: 0x005429B4 File Offset: 0x00540BB4
		// Note: this type is marked as 'beforefieldinit'.
		static VisionTarget()
		{
			Il2CppClassPointerStore<VisionTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr);
			VisionTarget.NativeFieldInfoPtr_AllVisionTargets = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "AllVisionTargets");
			VisionTarget.NativeFieldInfoPtr_Faction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "Faction");
			VisionTarget.NativeFieldInfoPtr_VisionPoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "VisionPoints");
			VisionTarget.NativeFieldInfoPtr_DamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "DamageController");
			VisionTarget.NativeFieldInfoPtr_ActiveAlerts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "ActiveAlerts");
			VisionTarget.NativeFieldInfoPtr_Transform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "Transform");
			VisionTarget.NativeFieldInfoPtr_Direction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "Direction");
			VisionTarget.NativeFieldInfoPtr__lastPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "_lastPosition");
			VisionTarget.NativeFieldInfoPtr__cachedID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, "_cachedID");
			VisionTarget.NativeMethodInfoPtr_OnEnable_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689969);
			VisionTarget.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689970);
			VisionTarget.NativeMethodInfoPtr_AddTarget_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689971);
			VisionTarget.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689972);
			VisionTarget.NativeMethodInfoPtr_AddAlert_Public_Void_AlertData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689973);
			VisionTarget.NativeMethodInfoPtr_RemoveAlert_Public_Void_AlertData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689974);
			VisionTarget.NativeMethodInfoPtr_GetID_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689975);
			VisionTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr, 100689976);
		}

		// Token: 0x06014EC3 RID: 85699 RVA: 0x0000210C File Offset: 0x0000030C
		public VisionTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007652 RID: 30290
		// (get) Token: 0x06014EC4 RID: 85700 RVA: 0x00542B38 File Offset: 0x00540D38
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionTarget>.NativeClassPtr));
			}
		}

		// Token: 0x17007653 RID: 30291
		// (get) Token: 0x06014EC5 RID: 85701 RVA: 0x00542B4C File Offset: 0x00540D4C
		// (set) Token: 0x06014EC6 RID: 85702 RVA: 0x00542B77 File Offset: 0x00540D77
		public unsafe static Dictionary<int, VisionTarget> AllVisionTargets
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(VisionTarget.NativeFieldInfoPtr_AllVisionTargets, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<int, VisionTarget>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(VisionTarget.NativeFieldInfoPtr_AllVisionTargets, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007654 RID: 30292
		// (get) Token: 0x06014EC7 RID: 85703 RVA: 0x00542B8C File Offset: 0x00540D8C
		// (set) Token: 0x06014EC8 RID: 85704 RVA: 0x00542BB4 File Offset: 0x00540DB4
		public unsafe Faction Faction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Faction);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Faction)) = value;
			}
		}

		// Token: 0x17007655 RID: 30293
		// (get) Token: 0x06014EC9 RID: 85705 RVA: 0x00542BD8 File Offset: 0x00540DD8
		// (set) Token: 0x06014ECA RID: 85706 RVA: 0x00542C0C File Offset: 0x00540E0C
		public unsafe List<VisionPoint> VisionPoints
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_VisionPoints);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<VisionPoint>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_VisionPoints), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007656 RID: 30294
		// (get) Token: 0x06014ECB RID: 85707 RVA: 0x00542C34 File Offset: 0x00540E34
		// (set) Token: 0x06014ECC RID: 85708 RVA: 0x00542C68 File Offset: 0x00540E68
		public unsafe DamageController DamageController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_DamageController);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_DamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007657 RID: 30295
		// (get) Token: 0x06014ECD RID: 85709 RVA: 0x00542C90 File Offset: 0x00540E90
		// (set) Token: 0x06014ECE RID: 85710 RVA: 0x00542CC4 File Offset: 0x00540EC4
		public unsafe HashSet<AlertData> ActiveAlerts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_ActiveAlerts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HashSet<AlertData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_ActiveAlerts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007658 RID: 30296
		// (get) Token: 0x06014ECF RID: 85711 RVA: 0x00542CEC File Offset: 0x00540EEC
		// (set) Token: 0x06014ED0 RID: 85712 RVA: 0x00542D20 File Offset: 0x00540F20
		public unsafe Transform Transform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Transform);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Transform), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007659 RID: 30297
		// (get) Token: 0x06014ED1 RID: 85713 RVA: 0x00542D48 File Offset: 0x00540F48
		// (set) Token: 0x06014ED2 RID: 85714 RVA: 0x00542D70 File Offset: 0x00540F70
		public unsafe Vector3 Direction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Direction);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr_Direction)) = value;
			}
		}

		// Token: 0x1700765A RID: 30298
		// (get) Token: 0x06014ED3 RID: 85715 RVA: 0x00542D94 File Offset: 0x00540F94
		// (set) Token: 0x06014ED4 RID: 85716 RVA: 0x00542DBC File Offset: 0x00540FBC
		public unsafe Vector3 _lastPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr__lastPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr__lastPosition)) = value;
			}
		}

		// Token: 0x1700765B RID: 30299
		// (get) Token: 0x06014ED5 RID: 85717 RVA: 0x00542DE0 File Offset: 0x00540FE0
		// (set) Token: 0x06014ED6 RID: 85718 RVA: 0x00542E08 File Offset: 0x00541008
		public unsafe int _cachedID
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr__cachedID);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionTarget.NativeFieldInfoPtr__cachedID)) = value;
			}
		}

		// Token: 0x0400D595 RID: 54677
		private static readonly IntPtr NativeFieldInfoPtr_AllVisionTargets;

		// Token: 0x0400D596 RID: 54678
		private static readonly IntPtr NativeFieldInfoPtr_Faction;

		// Token: 0x0400D597 RID: 54679
		private static readonly IntPtr NativeFieldInfoPtr_VisionPoints;

		// Token: 0x0400D598 RID: 54680
		private static readonly IntPtr NativeFieldInfoPtr_DamageController;

		// Token: 0x0400D599 RID: 54681
		private static readonly IntPtr NativeFieldInfoPtr_ActiveAlerts;

		// Token: 0x0400D59A RID: 54682
		private static readonly IntPtr NativeFieldInfoPtr_Transform;

		// Token: 0x0400D59B RID: 54683
		private static readonly IntPtr NativeFieldInfoPtr_Direction;

		// Token: 0x0400D59C RID: 54684
		private static readonly IntPtr NativeFieldInfoPtr__lastPosition;

		// Token: 0x0400D59D RID: 54685
		private static readonly IntPtr NativeFieldInfoPtr__cachedID;

		// Token: 0x0400D59E RID: 54686
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Virtual_New_Void_0;

		// Token: 0x0400D59F RID: 54687
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x0400D5A0 RID: 54688
		private static readonly IntPtr NativeMethodInfoPtr_AddTarget_Protected_Void_0;

		// Token: 0x0400D5A1 RID: 54689
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x0400D5A2 RID: 54690
		private static readonly IntPtr NativeMethodInfoPtr_AddAlert_Public_Void_AlertData_0;

		// Token: 0x0400D5A3 RID: 54691
		private static readonly IntPtr NativeMethodInfoPtr_RemoveAlert_Public_Void_AlertData_0;

		// Token: 0x0400D5A4 RID: 54692
		private static readonly IntPtr NativeMethodInfoPtr_GetID_Public_Int32_0;

		// Token: 0x0400D5A5 RID: 54693
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
