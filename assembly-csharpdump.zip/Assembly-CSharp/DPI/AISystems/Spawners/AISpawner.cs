﻿using System;
using AISystems;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using Onward.TeamManagement;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Spawners
{
	// Token: 0x0200119C RID: 4508
	public class AISpawner : Object
	{
		// Token: 0x06014EE3 RID: 85731 RVA: 0x00543050 File Offset: 0x00541250
		[CallerCount(0)]
		public unsafe AISpawner(GameVariant owner, int missionIndex, int maxSpawns, Dictionary<AIClassTypes, float> classWeightDistribution) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AISpawner>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxSpawns;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(classWeightDistribution);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE4 RID: 85732 RVA: 0x005430F0 File Offset: 0x005412F0
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE5 RID: 85733 RVA: 0x00543134 File Offset: 0x00541334
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE6 RID: 85734 RVA: 0x00543178 File Offset: 0x00541378
		[CallerCount(0)]
		public unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr_TickMaster_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE7 RID: 85735 RVA: 0x005431BC File Offset: 0x005413BC
		[CallerCount(0)]
		public unsafe void OnInitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawner.NativeMethodInfoPtr_OnInitialized_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE8 RID: 85736 RVA: 0x0054320C File Offset: 0x0054140C
		[CallerCount(0)]
		public unsafe void OnUninitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawner.NativeMethodInfoPtr_OnUninitialized_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EE9 RID: 85737 RVA: 0x0054325C File Offset: 0x0054145C
		[CallerCount(0)]
		public unsafe void OnTickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawner.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EEA RID: 85738 RVA: 0x005432AC File Offset: 0x005414AC
		[CallerCount(0)]
		public unsafe void GetAICounts(out int alive, out int dead, out int total)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = &alive;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &dead;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &total;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr_GetAICounts_Protected_Void_byref_Int32_byref_Int32_byref_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EEB RID: 85739 RVA: 0x0054332C File Offset: 0x0054152C
		[CallerCount(0)]
		public unsafe void Spawn(int numberToSpawn, float minimumDistance, bool refreshSpawns)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref numberToSpawn;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref minimumDistance;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref refreshSpawns;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawner.NativeMethodInfoPtr_Spawn_Protected_Void_Int32_Single_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014EEC RID: 85740 RVA: 0x005433A8 File Offset: 0x005415A8
		// Note: this type is marked as 'beforefieldinit'.
		static AISpawner()
		{
			Il2CppClassPointerStore<AISpawner>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Spawners", "AISpawner");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AISpawner>.NativeClassPtr);
			AISpawner.NativeFieldInfoPtr_AI_FACTION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "AI_FACTION");
			AISpawner.NativeFieldInfoPtr__owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_owner");
			AISpawner.NativeFieldInfoPtr__missionIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_missionIndex");
			AISpawner.NativeFieldInfoPtr__isInitialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_isInitialized");
			AISpawner.NativeFieldInfoPtr__maxSpawns = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_maxSpawns");
			AISpawner.NativeFieldInfoPtr__aiTeam = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_aiTeam");
			AISpawner.NativeFieldInfoPtr__lastSpawn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_lastSpawn");
			AISpawner.NativeFieldInfoPtr__classWeightDistribution = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, "_classWeightDistribution");
			AISpawner.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689979);
			AISpawner.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689980);
			AISpawner.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689981);
			AISpawner.NativeMethodInfoPtr_TickMaster_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689982);
			AISpawner.NativeMethodInfoPtr_OnInitialized_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689983);
			AISpawner.NativeMethodInfoPtr_OnUninitialized_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689984);
			AISpawner.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689985);
			AISpawner.NativeMethodInfoPtr_GetAICounts_Protected_Void_byref_Int32_byref_Int32_byref_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689986);
			AISpawner.NativeMethodInfoPtr_Spawn_Protected_Void_Int32_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawner>.NativeClassPtr, 100689987);
		}

		// Token: 0x06014EED RID: 85741 RVA: 0x00002988 File Offset: 0x00000B88
		public AISpawner(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007661 RID: 30305
		// (get) Token: 0x06014EEE RID: 85742 RVA: 0x0054352C File Offset: 0x0054172C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AISpawner>.NativeClassPtr));
			}
		}

		// Token: 0x17007662 RID: 30306
		// (get) Token: 0x06014EEF RID: 85743 RVA: 0x00543540 File Offset: 0x00541740
		// (set) Token: 0x06014EF0 RID: 85744 RVA: 0x0054355E File Offset: 0x0054175E
		public unsafe static Faction AI_FACTION
		{
			get
			{
				Faction result;
				IL2CPP.il2cpp_field_static_get_value(AISpawner.NativeFieldInfoPtr_AI_FACTION, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AISpawner.NativeFieldInfoPtr_AI_FACTION, (void*)(&value));
			}
		}

		// Token: 0x17007663 RID: 30307
		// (get) Token: 0x06014EF1 RID: 85745 RVA: 0x00543570 File Offset: 0x00541770
		// (set) Token: 0x06014EF2 RID: 85746 RVA: 0x005435A4 File Offset: 0x005417A4
		public unsafe GameVariant _owner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__owner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameVariant(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__owner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007664 RID: 30308
		// (get) Token: 0x06014EF3 RID: 85747 RVA: 0x005435CC File Offset: 0x005417CC
		// (set) Token: 0x06014EF4 RID: 85748 RVA: 0x005435F4 File Offset: 0x005417F4
		public unsafe int _missionIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__missionIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__missionIndex)) = value;
			}
		}

		// Token: 0x17007665 RID: 30309
		// (get) Token: 0x06014EF5 RID: 85749 RVA: 0x00543618 File Offset: 0x00541818
		// (set) Token: 0x06014EF6 RID: 85750 RVA: 0x00543640 File Offset: 0x00541840
		public unsafe bool _isInitialized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__isInitialized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__isInitialized)) = value;
			}
		}

		// Token: 0x17007666 RID: 30310
		// (get) Token: 0x06014EF7 RID: 85751 RVA: 0x00543664 File Offset: 0x00541864
		// (set) Token: 0x06014EF8 RID: 85752 RVA: 0x0054368C File Offset: 0x0054188C
		public unsafe int _maxSpawns
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__maxSpawns);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__maxSpawns)) = value;
			}
		}

		// Token: 0x17007667 RID: 30311
		// (get) Token: 0x06014EF9 RID: 85753 RVA: 0x005436B0 File Offset: 0x005418B0
		// (set) Token: 0x06014EFA RID: 85754 RVA: 0x005436E4 File Offset: 0x005418E4
		public unsafe Team _aiTeam
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__aiTeam);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Team(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__aiTeam), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007668 RID: 30312
		// (get) Token: 0x06014EFB RID: 85755 RVA: 0x0054370C File Offset: 0x0054190C
		// (set) Token: 0x06014EFC RID: 85756 RVA: 0x00543734 File Offset: 0x00541934
		public unsafe float _lastSpawn
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__lastSpawn);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__lastSpawn)) = value;
			}
		}

		// Token: 0x17007669 RID: 30313
		// (get) Token: 0x06014EFD RID: 85757 RVA: 0x00543758 File Offset: 0x00541958
		// (set) Token: 0x06014EFE RID: 85758 RVA: 0x0054378C File Offset: 0x0054198C
		public unsafe Dictionary<AIClassTypes, float> _classWeightDistribution
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__classWeightDistribution);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<AIClassTypes, float>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawner.NativeFieldInfoPtr__classWeightDistribution), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D5AB RID: 54699
		private static readonly IntPtr NativeFieldInfoPtr_AI_FACTION;

		// Token: 0x0400D5AC RID: 54700
		private static readonly IntPtr NativeFieldInfoPtr__owner;

		// Token: 0x0400D5AD RID: 54701
		private static readonly IntPtr NativeFieldInfoPtr__missionIndex;

		// Token: 0x0400D5AE RID: 54702
		private static readonly IntPtr NativeFieldInfoPtr__isInitialized;

		// Token: 0x0400D5AF RID: 54703
		private static readonly IntPtr NativeFieldInfoPtr__maxSpawns;

		// Token: 0x0400D5B0 RID: 54704
		private static readonly IntPtr NativeFieldInfoPtr__aiTeam;

		// Token: 0x0400D5B1 RID: 54705
		private static readonly IntPtr NativeFieldInfoPtr__lastSpawn;

		// Token: 0x0400D5B2 RID: 54706
		private static readonly IntPtr NativeFieldInfoPtr__classWeightDistribution;

		// Token: 0x0400D5B3 RID: 54707
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400D5B4 RID: 54708
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

		// Token: 0x0400D5B5 RID: 54709
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D5B6 RID: 54710
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Void_0;

		// Token: 0x0400D5B7 RID: 54711
		private static readonly IntPtr NativeMethodInfoPtr_OnInitialized_Protected_Virtual_New_Void_0;

		// Token: 0x0400D5B8 RID: 54712
		private static readonly IntPtr NativeMethodInfoPtr_OnUninitialized_Protected_Virtual_New_Void_0;

		// Token: 0x0400D5B9 RID: 54713
		private static readonly IntPtr NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_New_Void_0;

		// Token: 0x0400D5BA RID: 54714
		private static readonly IntPtr NativeMethodInfoPtr_GetAICounts_Protected_Void_byref_Int32_byref_Int32_byref_Int32_0;

		// Token: 0x0400D5BB RID: 54715
		private static readonly IntPtr NativeMethodInfoPtr_Spawn_Protected_Void_Int32_Single_Boolean_0;
	}
}
