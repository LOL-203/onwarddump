﻿using System;
using AISystems;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Spawners
{
	// Token: 0x0200119E RID: 4510
	public class AISpawnerWaves : AISpawner
	{
		// Token: 0x06014F09 RID: 85769 RVA: 0x00543A30 File Offset: 0x00541C30
		[CallerCount(0)]
		public unsafe static AISpawnerWaves Create(GameVariant owner, int missionIndex, int spawnCountOverride, bool spawnUpFront, Dictionary<AIClassTypes, float> classWeightDistribution)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnCountOverride;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnUpFront;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(classWeightDistribution);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawnerWaves.NativeMethodInfoPtr_Create_Public_Static_AISpawnerWaves_GameVariant_Int32_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new AISpawnerWaves(intPtr2) : null;
		}

		// Token: 0x06014F0A RID: 85770 RVA: 0x00543AE0 File Offset: 0x00541CE0
		[CallerCount(0)]
		public unsafe AISpawnerWaves(GameVariant owner, int missionIndex, int maxSpawns, float waveSpawnInterval, int waveSpawnAmount, bool spawnUpFront, Dictionary<AIClassTypes, float> classWeightDistribution) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxSpawns;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref waveSpawnInterval;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref waveSpawnAmount;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnUpFront;
			ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(classWeightDistribution);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawnerWaves.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Single_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F0B RID: 85771 RVA: 0x00543BBC File Offset: 0x00541DBC
		[CallerCount(0)]
		public new unsafe void OnTickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawnerWaves.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F0C RID: 85772 RVA: 0x00543C0C File Offset: 0x00541E0C
		// Note: this type is marked as 'beforefieldinit'.
		static AISpawnerWaves()
		{
			Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Spawners", "AISpawnerWaves");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr);
			AISpawnerWaves.NativeFieldInfoPtr_INITIAL_SPAWN_INTERVAL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, "INITIAL_SPAWN_INTERVAL");
			AISpawnerWaves.NativeFieldInfoPtr__waveSpawnInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, "_waveSpawnInterval");
			AISpawnerWaves.NativeFieldInfoPtr__waveSpawnAmount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, "_waveSpawnAmount");
			AISpawnerWaves.NativeFieldInfoPtr__spawnUpFront = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, "_spawnUpFront");
			AISpawnerWaves.NativeMethodInfoPtr_Create_Public_Static_AISpawnerWaves_GameVariant_Int32_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, 100689991);
			AISpawnerWaves.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Single_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, 100689992);
			AISpawnerWaves.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr, 100689993);
		}

		// Token: 0x06014F0D RID: 85773 RVA: 0x00543988 File Offset: 0x00541B88
		public AISpawnerWaves(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700766D RID: 30317
		// (get) Token: 0x06014F0E RID: 85774 RVA: 0x00543CC8 File Offset: 0x00541EC8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AISpawnerWaves>.NativeClassPtr));
			}
		}

		// Token: 0x1700766E RID: 30318
		// (get) Token: 0x06014F0F RID: 85775 RVA: 0x00543CDC File Offset: 0x00541EDC
		// (set) Token: 0x06014F10 RID: 85776 RVA: 0x00543CFA File Offset: 0x00541EFA
		public unsafe static float INITIAL_SPAWN_INTERVAL
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(AISpawnerWaves.NativeFieldInfoPtr_INITIAL_SPAWN_INTERVAL, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AISpawnerWaves.NativeFieldInfoPtr_INITIAL_SPAWN_INTERVAL, (void*)(&value));
			}
		}

		// Token: 0x1700766F RID: 30319
		// (get) Token: 0x06014F11 RID: 85777 RVA: 0x00543D0C File Offset: 0x00541F0C
		// (set) Token: 0x06014F12 RID: 85778 RVA: 0x00543D34 File Offset: 0x00541F34
		public unsafe float _waveSpawnInterval
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__waveSpawnInterval);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__waveSpawnInterval)) = value;
			}
		}

		// Token: 0x17007670 RID: 30320
		// (get) Token: 0x06014F13 RID: 85779 RVA: 0x00543D58 File Offset: 0x00541F58
		// (set) Token: 0x06014F14 RID: 85780 RVA: 0x00543D80 File Offset: 0x00541F80
		public unsafe int _waveSpawnAmount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__waveSpawnAmount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__waveSpawnAmount)) = value;
			}
		}

		// Token: 0x17007671 RID: 30321
		// (get) Token: 0x06014F15 RID: 85781 RVA: 0x00543DA4 File Offset: 0x00541FA4
		// (set) Token: 0x06014F16 RID: 85782 RVA: 0x00543DCC File Offset: 0x00541FCC
		public unsafe bool _spawnUpFront
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__spawnUpFront);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerWaves.NativeFieldInfoPtr__spawnUpFront)) = value;
			}
		}

		// Token: 0x0400D5C1 RID: 54721
		private static readonly IntPtr NativeFieldInfoPtr_INITIAL_SPAWN_INTERVAL;

		// Token: 0x0400D5C2 RID: 54722
		private static readonly IntPtr NativeFieldInfoPtr__waveSpawnInterval;

		// Token: 0x0400D5C3 RID: 54723
		private static readonly IntPtr NativeFieldInfoPtr__waveSpawnAmount;

		// Token: 0x0400D5C4 RID: 54724
		private static readonly IntPtr NativeFieldInfoPtr__spawnUpFront;

		// Token: 0x0400D5C5 RID: 54725
		private static readonly IntPtr NativeMethodInfoPtr_Create_Public_Static_AISpawnerWaves_GameVariant_Int32_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400D5C6 RID: 54726
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Single_Int32_Boolean_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400D5C7 RID: 54727
		private static readonly IntPtr NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0;
	}
}
