﻿using System;
using AISystems;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems.Spawners
{
	// Token: 0x0200119D RID: 4509
	public class AISpawnerOneShot : AISpawner
	{
		// Token: 0x06014EFF RID: 85759 RVA: 0x005437B4 File Offset: 0x005419B4
		[CallerCount(0)]
		public unsafe AISpawnerOneShot(GameVariant owner, int missionIndex, int maxSpawns, Dictionary<AIClassTypes, float> classWeightDistribution) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref missionIndex;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxSpawns;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(classWeightDistribution);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AISpawnerOneShot.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F00 RID: 85760 RVA: 0x00543854 File Offset: 0x00541A54
		[CallerCount(0)]
		public new unsafe void OnInitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawnerOneShot.NativeMethodInfoPtr_OnInitialized_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F01 RID: 85761 RVA: 0x005438A4 File Offset: 0x00541AA4
		[CallerCount(0)]
		public new unsafe void OnTickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AISpawnerOneShot.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014F02 RID: 85762 RVA: 0x005438F4 File Offset: 0x00541AF4
		// Note: this type is marked as 'beforefieldinit'.
		static AISpawnerOneShot()
		{
			Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems.Spawners", "AISpawnerOneShot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr);
			AISpawnerOneShot.NativeFieldInfoPtr_OnAllAISpawned = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr, "OnAllAISpawned");
			AISpawnerOneShot.NativeFieldInfoPtr__hasFinished = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr, "_hasFinished");
			AISpawnerOneShot.NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr, 100689988);
			AISpawnerOneShot.NativeMethodInfoPtr_OnInitialized_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr, 100689989);
			AISpawnerOneShot.NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr, 100689990);
		}

		// Token: 0x06014F03 RID: 85763 RVA: 0x00543988 File Offset: 0x00541B88
		public AISpawnerOneShot(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700766A RID: 30314
		// (get) Token: 0x06014F04 RID: 85764 RVA: 0x00543991 File Offset: 0x00541B91
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AISpawnerOneShot>.NativeClassPtr));
			}
		}

		// Token: 0x1700766B RID: 30315
		// (get) Token: 0x06014F05 RID: 85765 RVA: 0x005439A4 File Offset: 0x00541BA4
		// (set) Token: 0x06014F06 RID: 85766 RVA: 0x005439CF File Offset: 0x00541BCF
		public unsafe static Action OnAllAISpawned
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AISpawnerOneShot.NativeFieldInfoPtr_OnAllAISpawned, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AISpawnerOneShot.NativeFieldInfoPtr_OnAllAISpawned, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700766C RID: 30316
		// (get) Token: 0x06014F07 RID: 85767 RVA: 0x005439E4 File Offset: 0x00541BE4
		// (set) Token: 0x06014F08 RID: 85768 RVA: 0x00543A0C File Offset: 0x00541C0C
		public unsafe bool _hasFinished
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerOneShot.NativeFieldInfoPtr__hasFinished);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AISpawnerOneShot.NativeFieldInfoPtr__hasFinished)) = value;
			}
		}

		// Token: 0x0400D5BC RID: 54716
		private static readonly IntPtr NativeFieldInfoPtr_OnAllAISpawned;

		// Token: 0x0400D5BD RID: 54717
		private static readonly IntPtr NativeFieldInfoPtr__hasFinished;

		// Token: 0x0400D5BE RID: 54718
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_GameVariant_Int32_Int32_Dictionary_2_AIClassTypes_Single_0;

		// Token: 0x0400D5BF RID: 54719
		private static readonly IntPtr NativeMethodInfoPtr_OnInitialized_Protected_Virtual_Void_0;

		// Token: 0x0400D5C0 RID: 54720
		private static readonly IntPtr NativeMethodInfoPtr_OnTickMaster_Protected_Virtual_Void_0;
	}
}
