﻿using System;
using DPI.CoverSystems;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001187 RID: 4487
	public class AI_TakeCoverSuppression : AIState
	{
		// Token: 0x06014DA2 RID: 85410 RVA: 0x0053E4C0 File Offset: 0x0053C6C0
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverSuppression.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA3 RID: 85411 RVA: 0x0053E510 File Offset: 0x0053C710
		[CallerCount(0)]
		public unsafe void OnCoverComplete(bool foundCover, CoverPoint coverPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref foundCover;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverSuppression.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA4 RID: 85412 RVA: 0x0053E57C File Offset: 0x0053C77C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverSuppression.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA5 RID: 85413 RVA: 0x0053E5DC File Offset: 0x0053C7DC
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_TakeCoverSuppression.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA6 RID: 85414 RVA: 0x0053E62C File Offset: 0x0053C82C
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverSuppression.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA7 RID: 85415 RVA: 0x0053E670 File Offset: 0x0053C870
		[CallerCount(0)]
		public unsafe AI_TakeCoverSuppression() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_TakeCoverSuppression.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DA8 RID: 85416 RVA: 0x0053E6BC File Offset: 0x0053C8BC
		// Note: this type is marked as 'beforefieldinit'.
		static AI_TakeCoverSuppression()
		{
			Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_TakeCoverSuppression");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr);
			AI_TakeCoverSuppression.NativeFieldInfoPtr_MaxCoverDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, "MaxCoverDistance");
			AI_TakeCoverSuppression.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689887);
			AI_TakeCoverSuppression.NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689888);
			AI_TakeCoverSuppression.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689889);
			AI_TakeCoverSuppression.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689890);
			AI_TakeCoverSuppression.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689891);
			AI_TakeCoverSuppression.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr, 100689892);
		}

		// Token: 0x06014DA9 RID: 85417 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_TakeCoverSuppression(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075F3 RID: 30195
		// (get) Token: 0x06014DAA RID: 85418 RVA: 0x0053E778 File Offset: 0x0053C978
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_TakeCoverSuppression>.NativeClassPtr));
			}
		}

		// Token: 0x170075F4 RID: 30196
		// (get) Token: 0x06014DAB RID: 85419 RVA: 0x0053E78C File Offset: 0x0053C98C
		// (set) Token: 0x06014DAC RID: 85420 RVA: 0x0053E7B4 File Offset: 0x0053C9B4
		public unsafe float MaxCoverDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverSuppression.NativeFieldInfoPtr_MaxCoverDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_TakeCoverSuppression.NativeFieldInfoPtr_MaxCoverDistance)) = value;
			}
		}

		// Token: 0x0400D4FE RID: 54526
		private static readonly IntPtr NativeFieldInfoPtr_MaxCoverDistance;

		// Token: 0x0400D4FF RID: 54527
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D500 RID: 54528
		private static readonly IntPtr NativeMethodInfoPtr_OnCoverComplete_Private_Void_Boolean_CoverPoint_0;

		// Token: 0x0400D501 RID: 54529
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D502 RID: 54530
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D503 RID: 54531
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D504 RID: 54532
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
