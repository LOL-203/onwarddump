﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace DPI.AISystems
{
	// Token: 0x02001159 RID: 4441
	public static class AIStatics : Object
	{
		// Token: 0x06014B25 RID: 84773 RVA: 0x005356B0 File Offset: 0x005338B0
		// Note: this type is marked as 'beforefieldinit'.
		static AIStatics()
		{
			Il2CppClassPointerStore<AIStatics>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AIStatics");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIStatics>.NativeClassPtr);
			AIStatics.NativeFieldInfoPtr_ReactionsOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStatics>.NativeClassPtr, "ReactionsOn");
			AIStatics.NativeFieldInfoPtr_AIVisionOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStatics>.NativeClassPtr, "AIVisionOn");
			AIStatics.NativeFieldInfoPtr_AIDamagePlayersOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStatics>.NativeClassPtr, "AIDamagePlayersOn");
			AIStatics.NativeFieldInfoPtr_AIDamageableOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIStatics>.NativeClassPtr, "AIDamageableOn");
		}

		// Token: 0x06014B26 RID: 84774 RVA: 0x00002988 File Offset: 0x00000B88
		public AIStatics(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007521 RID: 29985
		// (get) Token: 0x06014B27 RID: 84775 RVA: 0x00535730 File Offset: 0x00533930
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIStatics>.NativeClassPtr));
			}
		}

		// Token: 0x17007522 RID: 29986
		// (get) Token: 0x06014B28 RID: 84776 RVA: 0x00535744 File Offset: 0x00533944
		// (set) Token: 0x06014B29 RID: 84777 RVA: 0x00535762 File Offset: 0x00533962
		public unsafe static bool ReactionsOn
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(AIStatics.NativeFieldInfoPtr_ReactionsOn, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIStatics.NativeFieldInfoPtr_ReactionsOn, (void*)(&value));
			}
		}

		// Token: 0x17007523 RID: 29987
		// (get) Token: 0x06014B2A RID: 84778 RVA: 0x00535774 File Offset: 0x00533974
		// (set) Token: 0x06014B2B RID: 84779 RVA: 0x00535792 File Offset: 0x00533992
		public unsafe static bool AIVisionOn
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(AIStatics.NativeFieldInfoPtr_AIVisionOn, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIStatics.NativeFieldInfoPtr_AIVisionOn, (void*)(&value));
			}
		}

		// Token: 0x17007524 RID: 29988
		// (get) Token: 0x06014B2C RID: 84780 RVA: 0x005357A4 File Offset: 0x005339A4
		// (set) Token: 0x06014B2D RID: 84781 RVA: 0x005357C2 File Offset: 0x005339C2
		public unsafe static bool AIDamagePlayersOn
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(AIStatics.NativeFieldInfoPtr_AIDamagePlayersOn, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIStatics.NativeFieldInfoPtr_AIDamagePlayersOn, (void*)(&value));
			}
		}

		// Token: 0x17007525 RID: 29989
		// (get) Token: 0x06014B2E RID: 84782 RVA: 0x005357D4 File Offset: 0x005339D4
		// (set) Token: 0x06014B2F RID: 84783 RVA: 0x005357F2 File Offset: 0x005339F2
		public unsafe static bool AIDamageableOn
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(AIStatics.NativeFieldInfoPtr_AIDamageableOn, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIStatics.NativeFieldInfoPtr_AIDamageableOn, (void*)(&value));
			}
		}

		// Token: 0x0400D3A9 RID: 54185
		private static readonly IntPtr NativeFieldInfoPtr_ReactionsOn;

		// Token: 0x0400D3AA RID: 54186
		private static readonly IntPtr NativeFieldInfoPtr_AIVisionOn;

		// Token: 0x0400D3AB RID: 54187
		private static readonly IntPtr NativeFieldInfoPtr_AIDamagePlayersOn;

		// Token: 0x0400D3AC RID: 54188
		private static readonly IntPtr NativeFieldInfoPtr_AIDamageableOn;
	}
}
