﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200116B RID: 4459
	public class AI_InCoverDefendObjective : AIState
	{
		// Token: 0x06014C1B RID: 85019 RVA: 0x00538C40 File Offset: 0x00536E40
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCoverDefendObjective.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C1C RID: 85020 RVA: 0x00538C90 File Offset: 0x00536E90
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCoverDefendObjective.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C1D RID: 85021 RVA: 0x00538CE0 File Offset: 0x00536EE0
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InCoverDefendObjective.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C1E RID: 85022 RVA: 0x00538D40 File Offset: 0x00536F40
		[CallerCount(0)]
		public unsafe AI_InCoverDefendObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InCoverDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C1F RID: 85023 RVA: 0x00538D8C File Offset: 0x00536F8C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_InCoverDefendObjective()
		{
			Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_InCoverDefendObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr);
			AI_InCoverDefendObjective.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr, 100689776);
			AI_InCoverDefendObjective.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr, 100689777);
			AI_InCoverDefendObjective.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr, 100689778);
			AI_InCoverDefendObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr, 100689779);
		}

		// Token: 0x06014C20 RID: 85024 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_InCoverDefendObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007575 RID: 30069
		// (get) Token: 0x06014C21 RID: 85025 RVA: 0x00538E0C File Offset: 0x0053700C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_InCoverDefendObjective>.NativeClassPtr));
			}
		}

		// Token: 0x0400D42D RID: 54317
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D42E RID: 54318
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D42F RID: 54319
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D430 RID: 54320
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
