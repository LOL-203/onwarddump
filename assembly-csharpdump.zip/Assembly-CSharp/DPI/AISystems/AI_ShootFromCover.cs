﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200117D RID: 4477
	public class AI_ShootFromCover : AI_Shoot
	{
		// Token: 0x06014D25 RID: 85285 RVA: 0x0053C700 File Offset: 0x0053A900
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootFromCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D26 RID: 85286 RVA: 0x0053C750 File Offset: 0x0053A950
		[CallerCount(0)]
		public new unsafe void DoneShooting()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ShootFromCover.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D27 RID: 85287 RVA: 0x0053C7A0 File Offset: 0x0053A9A0
		[CallerCount(0)]
		public unsafe AI_ShootFromCover() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ShootFromCover.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014D28 RID: 85288 RVA: 0x0053C7EC File Offset: 0x0053A9EC
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ShootFromCover()
		{
			Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ShootFromCover");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr);
			AI_ShootFromCover.NativeFieldInfoPtr_ChanceToThrowSmoke = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr, "ChanceToThrowSmoke");
			AI_ShootFromCover.NativeFieldInfoPtr_ChanceToAdvance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr, "ChanceToAdvance");
			AI_ShootFromCover.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr, 100689844);
			AI_ShootFromCover.NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr, 100689845);
			AI_ShootFromCover.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr, 100689846);
		}

		// Token: 0x06014D29 RID: 85289 RVA: 0x0053C880 File Offset: 0x0053AA80
		public AI_ShootFromCover(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075CF RID: 30159
		// (get) Token: 0x06014D2A RID: 85290 RVA: 0x0053C889 File Offset: 0x0053AA89
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ShootFromCover>.NativeClassPtr));
			}
		}

		// Token: 0x170075D0 RID: 30160
		// (get) Token: 0x06014D2B RID: 85291 RVA: 0x0053C89C File Offset: 0x0053AA9C
		// (set) Token: 0x06014D2C RID: 85292 RVA: 0x0053C8C4 File Offset: 0x0053AAC4
		public unsafe int ChanceToThrowSmoke
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootFromCover.NativeFieldInfoPtr_ChanceToThrowSmoke);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootFromCover.NativeFieldInfoPtr_ChanceToThrowSmoke)) = value;
			}
		}

		// Token: 0x170075D1 RID: 30161
		// (get) Token: 0x06014D2D RID: 85293 RVA: 0x0053C8E8 File Offset: 0x0053AAE8
		// (set) Token: 0x06014D2E RID: 85294 RVA: 0x0053C910 File Offset: 0x0053AB10
		public unsafe int ChanceToAdvance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootFromCover.NativeFieldInfoPtr_ChanceToAdvance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ShootFromCover.NativeFieldInfoPtr_ChanceToAdvance)) = value;
			}
		}

		// Token: 0x0400D4B9 RID: 54457
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToThrowSmoke;

		// Token: 0x0400D4BA RID: 54458
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToAdvance;

		// Token: 0x0400D4BB RID: 54459
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D4BC RID: 54460
		private static readonly IntPtr NativeMethodInfoPtr_DoneShooting_Protected_Virtual_Void_0;

		// Token: 0x0400D4BD RID: 54461
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
