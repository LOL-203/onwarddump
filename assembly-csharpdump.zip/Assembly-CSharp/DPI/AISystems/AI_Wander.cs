﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200118F RID: 4495
	public class AI_Wander : AIState_PassiveBarks
	{
		// Token: 0x06014E2F RID: 85551 RVA: 0x0054078C File Offset: 0x0053E98C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Wander.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E30 RID: 85552 RVA: 0x005407DC File Offset: 0x0053E9DC
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Wander.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E31 RID: 85553 RVA: 0x0054082C File Offset: 0x0053EA2C
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Wander.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E32 RID: 85554 RVA: 0x00540870 File Offset: 0x0053EA70
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_Wander.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E33 RID: 85555 RVA: 0x005408D0 File Offset: 0x0053EAD0
		[CallerCount(0)]
		public unsafe AI_Wander() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_Wander.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E34 RID: 85556 RVA: 0x0054091C File Offset: 0x0053EB1C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_Wander()
		{
			Il2CppClassPointerStore<AI_Wander>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_Wander");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr);
			AI_Wander.NativeFieldInfoPtr_MinRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, "MinRange");
			AI_Wander.NativeFieldInfoPtr_MaxRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, "MaxRange");
			AI_Wander.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, 100689932);
			AI_Wander.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, 100689933);
			AI_Wander.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, 100689934);
			AI_Wander.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, 100689935);
			AI_Wander.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr, 100689936);
		}

		// Token: 0x06014E35 RID: 85557 RVA: 0x005387F4 File Offset: 0x005369F4
		public AI_Wander(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007625 RID: 30245
		// (get) Token: 0x06014E36 RID: 85558 RVA: 0x005409D8 File Offset: 0x0053EBD8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_Wander>.NativeClassPtr));
			}
		}

		// Token: 0x17007626 RID: 30246
		// (get) Token: 0x06014E37 RID: 85559 RVA: 0x005409EC File Offset: 0x0053EBEC
		// (set) Token: 0x06014E38 RID: 85560 RVA: 0x00540A14 File Offset: 0x0053EC14
		public unsafe float MinRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Wander.NativeFieldInfoPtr_MinRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Wander.NativeFieldInfoPtr_MinRange)) = value;
			}
		}

		// Token: 0x17007627 RID: 30247
		// (get) Token: 0x06014E39 RID: 85561 RVA: 0x00540A38 File Offset: 0x0053EC38
		// (set) Token: 0x06014E3A RID: 85562 RVA: 0x00540A60 File Offset: 0x0053EC60
		public unsafe float MaxRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Wander.NativeFieldInfoPtr_MaxRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_Wander.NativeFieldInfoPtr_MaxRange)) = value;
			}
		}

		// Token: 0x0400D54F RID: 54607
		private static readonly IntPtr NativeFieldInfoPtr_MinRange;

		// Token: 0x0400D550 RID: 54608
		private static readonly IntPtr NativeFieldInfoPtr_MaxRange;

		// Token: 0x0400D551 RID: 54609
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D552 RID: 54610
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D553 RID: 54611
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D554 RID: 54612
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D555 RID: 54613
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
