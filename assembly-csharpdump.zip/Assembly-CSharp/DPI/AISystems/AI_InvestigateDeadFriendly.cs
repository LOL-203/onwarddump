﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200116D RID: 4461
	public class AI_InvestigateDeadFriendly : AIState
	{
		// Token: 0x06014C2E RID: 85038 RVA: 0x005390BC File Offset: 0x005372BC
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C2F RID: 85039 RVA: 0x0053910C File Offset: 0x0053730C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C30 RID: 85040 RVA: 0x0053915C File Offset: 0x0053735C
		[CallerCount(0)]
		public unsafe void OnArrived()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InvestigateDeadFriendly.NativeMethodInfoPtr_OnArrived_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C31 RID: 85041 RVA: 0x005391A0 File Offset: 0x005373A0
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C32 RID: 85042 RVA: 0x00539200 File Offset: 0x00537400
		[CallerCount(0)]
		public unsafe AI_InvestigateDeadFriendly() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_InvestigateDeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C33 RID: 85043 RVA: 0x0053924C File Offset: 0x0053744C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_InvestigateDeadFriendly()
		{
			Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_InvestigateDeadFriendly");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr);
			AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, "InvestigateMin");
			AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, "InvestigateMax");
			AI_InvestigateDeadFriendly.NativeFieldInfoPtr__atBody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, "_atBody");
			AI_InvestigateDeadFriendly.NativeFieldInfoPtr__endTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, "_endTime");
			AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, 100689783);
			AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, 100689784);
			AI_InvestigateDeadFriendly.NativeMethodInfoPtr_OnArrived_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, 100689785);
			AI_InvestigateDeadFriendly.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, 100689786);
			AI_InvestigateDeadFriendly.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr, 100689787);
		}

		// Token: 0x06014C34 RID: 85044 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_InvestigateDeadFriendly(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700757A RID: 30074
		// (get) Token: 0x06014C35 RID: 85045 RVA: 0x00539330 File Offset: 0x00537530
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_InvestigateDeadFriendly>.NativeClassPtr));
			}
		}

		// Token: 0x1700757B RID: 30075
		// (get) Token: 0x06014C36 RID: 85046 RVA: 0x00539344 File Offset: 0x00537544
		// (set) Token: 0x06014C37 RID: 85047 RVA: 0x0053936C File Offset: 0x0053756C
		public unsafe float InvestigateMin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMin);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMin)) = value;
			}
		}

		// Token: 0x1700757C RID: 30076
		// (get) Token: 0x06014C38 RID: 85048 RVA: 0x00539390 File Offset: 0x00537590
		// (set) Token: 0x06014C39 RID: 85049 RVA: 0x005393B8 File Offset: 0x005375B8
		public unsafe float InvestigateMax
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMax);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr_InvestigateMax)) = value;
			}
		}

		// Token: 0x1700757D RID: 30077
		// (get) Token: 0x06014C3A RID: 85050 RVA: 0x005393DC File Offset: 0x005375DC
		// (set) Token: 0x06014C3B RID: 85051 RVA: 0x00539404 File Offset: 0x00537604
		public unsafe bool _atBody
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr__atBody);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr__atBody)) = value;
			}
		}

		// Token: 0x1700757E RID: 30078
		// (get) Token: 0x06014C3C RID: 85052 RVA: 0x00539428 File Offset: 0x00537628
		// (set) Token: 0x06014C3D RID: 85053 RVA: 0x00539450 File Offset: 0x00537650
		public unsafe float _endTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr__endTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_InvestigateDeadFriendly.NativeFieldInfoPtr__endTime)) = value;
			}
		}

		// Token: 0x0400D437 RID: 54327
		private static readonly IntPtr NativeFieldInfoPtr_InvestigateMin;

		// Token: 0x0400D438 RID: 54328
		private static readonly IntPtr NativeFieldInfoPtr_InvestigateMax;

		// Token: 0x0400D439 RID: 54329
		private static readonly IntPtr NativeFieldInfoPtr__atBody;

		// Token: 0x0400D43A RID: 54330
		private static readonly IntPtr NativeFieldInfoPtr__endTime;

		// Token: 0x0400D43B RID: 54331
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D43C RID: 54332
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D43D RID: 54333
		private static readonly IntPtr NativeMethodInfoPtr_OnArrived_Private_Void_0;

		// Token: 0x0400D43E RID: 54334
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D43F RID: 54335
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
