﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001173 RID: 4467
	public class AI_ReactFlashBang : AIState
	{
		// Token: 0x06014C9C RID: 85148 RVA: 0x0053A9C0 File Offset: 0x00538BC0
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ReactFlashBang.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C9D RID: 85149 RVA: 0x0053AA10 File Offset: 0x00538C10
		[CallerCount(0)]
		public unsafe AI_ReactFlashBang() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ReactFlashBang.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014C9E RID: 85150 RVA: 0x0053AA5C File Offset: 0x00538C5C
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ReactFlashBang()
		{
			Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ReactFlashBang");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr);
			AI_ReactFlashBang.NativeFieldInfoPtr_ChanceToSprayRandomly = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr, "ChanceToSprayRandomly");
			AI_ReactFlashBang.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr, 100689813);
			AI_ReactFlashBang.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr, 100689814);
		}

		// Token: 0x06014C9F RID: 85151 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ReactFlashBang(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700759F RID: 30111
		// (get) Token: 0x06014CA0 RID: 85152 RVA: 0x0053AAC8 File Offset: 0x00538CC8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ReactFlashBang>.NativeClassPtr));
			}
		}

		// Token: 0x170075A0 RID: 30112
		// (get) Token: 0x06014CA1 RID: 85153 RVA: 0x0053AADC File Offset: 0x00538CDC
		// (set) Token: 0x06014CA2 RID: 85154 RVA: 0x0053AB04 File Offset: 0x00538D04
		public unsafe int ChanceToSprayRandomly
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFlashBang.NativeFieldInfoPtr_ChanceToSprayRandomly);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ReactFlashBang.NativeFieldInfoPtr_ChanceToSprayRandomly)) = value;
			}
		}

		// Token: 0x0400D474 RID: 54388
		private static readonly IntPtr NativeFieldInfoPtr_ChanceToSprayRandomly;

		// Token: 0x0400D475 RID: 54389
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D476 RID: 54390
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
