﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Locators;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.AISystems
{
	// Token: 0x02001189 RID: 4489
	public class AI_ThrowFlashbang : AIState
	{
		// Token: 0x06014DB8 RID: 85432 RVA: 0x0053EAF0 File Offset: 0x0053CCF0
		[CallerCount(0)]
		public new unsafe Vector3 GetStateDrivenLookPosition()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFlashbang.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014DB9 RID: 85433 RVA: 0x0053EB4C File Offset: 0x0053CD4C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFlashbang.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DBA RID: 85434 RVA: 0x0053EB9C File Offset: 0x0053CD9C
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AI_ThrowFlashbang.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DBB RID: 85435 RVA: 0x0053EBEC File Offset: 0x0053CDEC
		[CallerCount(0)]
		public unsafe IEnumerator Throw()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang.NativeMethodInfoPtr_Throw_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06014DBC RID: 85436 RVA: 0x0053EC44 File Offset: 0x0053CE44
		[CallerCount(0)]
		public unsafe AI_ThrowFlashbang() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014DBD RID: 85437 RVA: 0x0053EC90 File Offset: 0x0053CE90
		// Note: this type is marked as 'beforefieldinit'.
		static AI_ThrowFlashbang()
		{
			Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AI_ThrowFlashbang");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr);
			AI_ThrowFlashbang.NativeFieldInfoPtr_MinThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "MinThrowAccuracy");
			AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowAccuracy = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "MaxThrowAccuracy");
			AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "MaxThrowDistance");
			AI_ThrowFlashbang.NativeFieldInfoPtr__throwrutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "_throwrutine");
			AI_ThrowFlashbang.NativeFieldInfoPtr__throwPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "_throwPosition");
			AI_ThrowFlashbang.NativeFieldInfoPtr__flashData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "_flashData");
			AI_ThrowFlashbang.NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, 100689899);
			AI_ThrowFlashbang.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, 100689900);
			AI_ThrowFlashbang.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, 100689901);
			AI_ThrowFlashbang.NativeMethodInfoPtr_Throw_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, 100689902);
			AI_ThrowFlashbang.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, 100689903);
		}

		// Token: 0x06014DBE RID: 85438 RVA: 0x00535C60 File Offset: 0x00533E60
		public AI_ThrowFlashbang(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170075F7 RID: 30199
		// (get) Token: 0x06014DBF RID: 85439 RVA: 0x0053ED9C File Offset: 0x0053CF9C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr));
			}
		}

		// Token: 0x170075F8 RID: 30200
		// (get) Token: 0x06014DC0 RID: 85440 RVA: 0x0053EDB0 File Offset: 0x0053CFB0
		// (set) Token: 0x06014DC1 RID: 85441 RVA: 0x0053EDD8 File Offset: 0x0053CFD8
		public unsafe float MinThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MinThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MinThrowAccuracy)) = value;
			}
		}

		// Token: 0x170075F9 RID: 30201
		// (get) Token: 0x06014DC2 RID: 85442 RVA: 0x0053EDFC File Offset: 0x0053CFFC
		// (set) Token: 0x06014DC3 RID: 85443 RVA: 0x0053EE24 File Offset: 0x0053D024
		public unsafe float MaxThrowAccuracy
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowAccuracy);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowAccuracy)) = value;
			}
		}

		// Token: 0x170075FA RID: 30202
		// (get) Token: 0x06014DC4 RID: 85444 RVA: 0x0053EE48 File Offset: 0x0053D048
		// (set) Token: 0x06014DC5 RID: 85445 RVA: 0x0053EE70 File Offset: 0x0053D070
		public unsafe float MaxThrowDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr_MaxThrowDistance)) = value;
			}
		}

		// Token: 0x170075FB RID: 30203
		// (get) Token: 0x06014DC6 RID: 85446 RVA: 0x0053EE94 File Offset: 0x0053D094
		// (set) Token: 0x06014DC7 RID: 85447 RVA: 0x0053EEC8 File Offset: 0x0053D0C8
		public unsafe Coroutine _throwrutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__throwrutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__throwrutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170075FC RID: 30204
		// (get) Token: 0x06014DC8 RID: 85448 RVA: 0x0053EEF0 File Offset: 0x0053D0F0
		// (set) Token: 0x06014DC9 RID: 85449 RVA: 0x0053EF18 File Offset: 0x0053D118
		public unsafe Vector3 _throwPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__throwPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__throwPosition)) = value;
			}
		}

		// Token: 0x170075FD RID: 30205
		// (get) Token: 0x06014DCA RID: 85450 RVA: 0x0053EF3C File Offset: 0x0053D13C
		// (set) Token: 0x06014DCB RID: 85451 RVA: 0x0053EF70 File Offset: 0x0053D170
		public unsafe ThrowFlashBangAdditionalData _flashData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__flashData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ThrowFlashBangAdditionalData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang.NativeFieldInfoPtr__flashData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D50C RID: 54540
		private static readonly IntPtr NativeFieldInfoPtr_MinThrowAccuracy;

		// Token: 0x0400D50D RID: 54541
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowAccuracy;

		// Token: 0x0400D50E RID: 54542
		private static readonly IntPtr NativeFieldInfoPtr_MaxThrowDistance;

		// Token: 0x0400D50F RID: 54543
		private static readonly IntPtr NativeFieldInfoPtr__throwrutine;

		// Token: 0x0400D510 RID: 54544
		private static readonly IntPtr NativeFieldInfoPtr__throwPosition;

		// Token: 0x0400D511 RID: 54545
		private static readonly IntPtr NativeFieldInfoPtr__flashData;

		// Token: 0x0400D512 RID: 54546
		private static readonly IntPtr NativeMethodInfoPtr_GetStateDrivenLookPosition_Public_Virtual_Vector3_0;

		// Token: 0x0400D513 RID: 54547
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D514 RID: 54548
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D515 RID: 54549
		private static readonly IntPtr NativeMethodInfoPtr_Throw_Private_IEnumerator_0;

		// Token: 0x0400D516 RID: 54550
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200118A RID: 4490
		[ObfuscatedName("DPI.AISystems.AI_ThrowFlashbang/<Throw>d__9")]
		public sealed class _Throw_d__9 : Il2CppSystem.Object
		{
			// Token: 0x06014DCC RID: 85452 RVA: 0x0053EF98 File Offset: 0x0053D198
			[CallerCount(0)]
			public unsafe _Throw_d__9(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014DCD RID: 85453 RVA: 0x0053EFF8 File Offset: 0x0053D1F8
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014DCE RID: 85454 RVA: 0x0053F03C File Offset: 0x0053D23C
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17007605 RID: 30213
			// (get) Token: 0x06014DCF RID: 85455 RVA: 0x0053F08C File Offset: 0x0053D28C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014DD0 RID: 85456 RVA: 0x0053F0E4 File Offset: 0x0053D2E4
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17007606 RID: 30214
			// (get) Token: 0x06014DD1 RID: 85457 RVA: 0x0053F128 File Offset: 0x0053D328
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014DD2 RID: 85458 RVA: 0x0053F180 File Offset: 0x0053D380
			// Note: this type is marked as 'beforefieldinit'.
			static _Throw_d__9()
			{
				Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AI_ThrowFlashbang>.NativeClassPtr, "<Throw>d__9");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr);
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<>1__state");
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<>2__current");
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<>4__this");
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__currentWeapon_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<currentWeapon>5__2");
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__grenade_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<grenade>5__3");
				AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__startLocator_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, "<startLocator>5__4");
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689904);
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689905);
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689906);
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689907);
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689908);
				AI_ThrowFlashbang._Throw_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr, 100689909);
			}

			// Token: 0x06014DD3 RID: 85459 RVA: 0x00002988 File Offset: 0x00000B88
			public _Throw_d__9(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170075FE RID: 30206
			// (get) Token: 0x06014DD4 RID: 85460 RVA: 0x0053F29B File Offset: 0x0053D49B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AI_ThrowFlashbang._Throw_d__9>.NativeClassPtr));
				}
			}

			// Token: 0x170075FF RID: 30207
			// (get) Token: 0x06014DD5 RID: 85461 RVA: 0x0053F2AC File Offset: 0x0053D4AC
			// (set) Token: 0x06014DD6 RID: 85462 RVA: 0x0053F2D4 File Offset: 0x0053D4D4
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17007600 RID: 30208
			// (get) Token: 0x06014DD7 RID: 85463 RVA: 0x0053F2F8 File Offset: 0x0053D4F8
			// (set) Token: 0x06014DD8 RID: 85464 RVA: 0x0053F32C File Offset: 0x0053D52C
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007601 RID: 30209
			// (get) Token: 0x06014DD9 RID: 85465 RVA: 0x0053F354 File Offset: 0x0053D554
			// (set) Token: 0x06014DDA RID: 85466 RVA: 0x0053F388 File Offset: 0x0053D588
			public unsafe AI_ThrowFlashbang __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new AI_ThrowFlashbang(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007602 RID: 30210
			// (get) Token: 0x06014DDB RID: 85467 RVA: 0x0053F3B0 File Offset: 0x0053D5B0
			// (set) Token: 0x06014DDC RID: 85468 RVA: 0x0053F3E4 File Offset: 0x0053D5E4
			public unsafe Pickup _currentWeapon_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__currentWeapon_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__currentWeapon_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007603 RID: 30211
			// (get) Token: 0x06014DDD RID: 85469 RVA: 0x0053F40C File Offset: 0x0053D60C
			// (set) Token: 0x06014DDE RID: 85470 RVA: 0x0053F440 File Offset: 0x0053D640
			public unsafe Pickup_Stun_Grenade _grenade_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__grenade_5__3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Pickup_Stun_Grenade(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__grenade_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007604 RID: 30212
			// (get) Token: 0x06014DDF RID: 85471 RVA: 0x0053F468 File Offset: 0x0053D668
			// (set) Token: 0x06014DE0 RID: 85472 RVA: 0x0053F49C File Offset: 0x0053D69C
			public unsafe Locator _startLocator_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__startLocator_5__4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Locator(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AI_ThrowFlashbang._Throw_d__9.NativeFieldInfoPtr__startLocator_5__4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400D517 RID: 54551
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400D518 RID: 54552
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400D519 RID: 54553
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400D51A RID: 54554
			private static readonly IntPtr NativeFieldInfoPtr__currentWeapon_5__2;

			// Token: 0x0400D51B RID: 54555
			private static readonly IntPtr NativeFieldInfoPtr__grenade_5__3;

			// Token: 0x0400D51C RID: 54556
			private static readonly IntPtr NativeFieldInfoPtr__startLocator_5__4;

			// Token: 0x0400D51D RID: 54557
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400D51E RID: 54558
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D51F RID: 54559
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400D520 RID: 54560
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400D521 RID: 54561
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D522 RID: 54562
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
