﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x02001194 RID: 4500
	[Serializable]
	public class VisionFrustumData : Object
	{
		// Token: 0x06014E77 RID: 85623 RVA: 0x0054193C File Offset: 0x0053FB3C
		[CallerCount(0)]
		public unsafe VisionFrustumData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VisionFrustumData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014E78 RID: 85624 RVA: 0x00541988 File Offset: 0x0053FB88
		// Note: this type is marked as 'beforefieldinit'.
		static VisionFrustumData()
		{
			Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "VisionFrustumData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr);
			VisionFrustumData.NativeFieldInfoPtr_MinDist = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr, "MinDist");
			VisionFrustumData.NativeFieldInfoPtr_MinWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr, "MinWidth");
			VisionFrustumData.NativeFieldInfoPtr_MaxDist = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr, "MaxDist");
			VisionFrustumData.NativeFieldInfoPtr_MaxWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr, "MaxWidth");
			VisionFrustumData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr, 100689954);
		}

		// Token: 0x06014E79 RID: 85625 RVA: 0x00002988 File Offset: 0x00000B88
		public VisionFrustumData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700763B RID: 30267
		// (get) Token: 0x06014E7A RID: 85626 RVA: 0x00541A1C File Offset: 0x0053FC1C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VisionFrustumData>.NativeClassPtr));
			}
		}

		// Token: 0x1700763C RID: 30268
		// (get) Token: 0x06014E7B RID: 85627 RVA: 0x00541A30 File Offset: 0x0053FC30
		// (set) Token: 0x06014E7C RID: 85628 RVA: 0x00541A58 File Offset: 0x0053FC58
		public unsafe float MinDist
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MinDist);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MinDist)) = value;
			}
		}

		// Token: 0x1700763D RID: 30269
		// (get) Token: 0x06014E7D RID: 85629 RVA: 0x00541A7C File Offset: 0x0053FC7C
		// (set) Token: 0x06014E7E RID: 85630 RVA: 0x00541AA4 File Offset: 0x0053FCA4
		public unsafe float MinWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MinWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MinWidth)) = value;
			}
		}

		// Token: 0x1700763E RID: 30270
		// (get) Token: 0x06014E7F RID: 85631 RVA: 0x00541AC8 File Offset: 0x0053FCC8
		// (set) Token: 0x06014E80 RID: 85632 RVA: 0x00541AF0 File Offset: 0x0053FCF0
		public unsafe float MaxDist
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MaxDist);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MaxDist)) = value;
			}
		}

		// Token: 0x1700763F RID: 30271
		// (get) Token: 0x06014E81 RID: 85633 RVA: 0x00541B14 File Offset: 0x0053FD14
		// (set) Token: 0x06014E82 RID: 85634 RVA: 0x00541B3C File Offset: 0x0053FD3C
		public unsafe float MaxWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MaxWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(VisionFrustumData.NativeFieldInfoPtr_MaxWidth)) = value;
			}
		}

		// Token: 0x0400D576 RID: 54646
		private static readonly IntPtr NativeFieldInfoPtr_MinDist;

		// Token: 0x0400D577 RID: 54647
		private static readonly IntPtr NativeFieldInfoPtr_MinWidth;

		// Token: 0x0400D578 RID: 54648
		private static readonly IntPtr NativeFieldInfoPtr_MaxDist;

		// Token: 0x0400D579 RID: 54649
		private static readonly IntPtr NativeFieldInfoPtr_MaxWidth;

		// Token: 0x0400D57A RID: 54650
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
