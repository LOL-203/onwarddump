﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.AISystems
{
	// Token: 0x0200115D RID: 4445
	public class AIState_PassiveBarks : AIState
	{
		// Token: 0x06014B3E RID: 84798 RVA: 0x00535A6C File Offset: 0x00533C6C
		[CallerCount(0)]
		public new unsafe void Enter()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState_PassiveBarks.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B3F RID: 84799 RVA: 0x00535ABC File Offset: 0x00533CBC
		[CallerCount(0)]
		public new unsafe void Exit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState_PassiveBarks.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B40 RID: 84800 RVA: 0x00535B0C File Offset: 0x00533D0C
		[CallerCount(0)]
		public new unsafe void Tick(float dt)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dt;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AIState_PassiveBarks.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B41 RID: 84801 RVA: 0x00535B6C File Offset: 0x00533D6C
		[CallerCount(0)]
		public unsafe AIState_PassiveBarks() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AIState_PassiveBarks.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014B42 RID: 84802 RVA: 0x00535BB8 File Offset: 0x00533DB8
		// Note: this type is marked as 'beforefieldinit'.
		static AIState_PassiveBarks()
		{
			Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.AISystems", "AIState_PassiveBarks");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr);
			AIState_PassiveBarks.NativeFieldInfoPtr_IDLE_BARK_TIME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, "IDLE_BARK_TIME");
			AIState_PassiveBarks.NativeFieldInfoPtr__idleBarkTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, "_idleBarkTimer");
			AIState_PassiveBarks.NativeMethodInfoPtr_Enter_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, 100689717);
			AIState_PassiveBarks.NativeMethodInfoPtr_Exit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, 100689718);
			AIState_PassiveBarks.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, 100689719);
			AIState_PassiveBarks.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr, 100689720);
		}

		// Token: 0x06014B43 RID: 84803 RVA: 0x00535C60 File Offset: 0x00533E60
		public AIState_PassiveBarks(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700752B RID: 29995
		// (get) Token: 0x06014B44 RID: 84804 RVA: 0x00535C69 File Offset: 0x00533E69
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AIState_PassiveBarks>.NativeClassPtr));
			}
		}

		// Token: 0x1700752C RID: 29996
		// (get) Token: 0x06014B45 RID: 84805 RVA: 0x00535C7C File Offset: 0x00533E7C
		// (set) Token: 0x06014B46 RID: 84806 RVA: 0x00535C9A File Offset: 0x00533E9A
		public unsafe static float IDLE_BARK_TIME
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(AIState_PassiveBarks.NativeFieldInfoPtr_IDLE_BARK_TIME, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AIState_PassiveBarks.NativeFieldInfoPtr_IDLE_BARK_TIME, (void*)(&value));
			}
		}

		// Token: 0x1700752D RID: 29997
		// (get) Token: 0x06014B47 RID: 84807 RVA: 0x00535CAC File Offset: 0x00533EAC
		// (set) Token: 0x06014B48 RID: 84808 RVA: 0x00535CD4 File Offset: 0x00533ED4
		public unsafe float _idleBarkTimer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState_PassiveBarks.NativeFieldInfoPtr__idleBarkTimer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AIState_PassiveBarks.NativeFieldInfoPtr__idleBarkTimer)) = value;
			}
		}

		// Token: 0x0400D3B6 RID: 54198
		private static readonly IntPtr NativeFieldInfoPtr_IDLE_BARK_TIME;

		// Token: 0x0400D3B7 RID: 54199
		private static readonly IntPtr NativeFieldInfoPtr__idleBarkTimer;

		// Token: 0x0400D3B8 RID: 54200
		private static readonly IntPtr NativeMethodInfoPtr_Enter_Public_Virtual_Void_0;

		// Token: 0x0400D3B9 RID: 54201
		private static readonly IntPtr NativeMethodInfoPtr_Exit_Public_Virtual_Void_0;

		// Token: 0x0400D3BA RID: 54202
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_Single_0;

		// Token: 0x0400D3BB RID: 54203
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
