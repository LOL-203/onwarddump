﻿using System;
using DPI.Data;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.CoverSystems
{
	// Token: 0x0200114D RID: 4429
	public class CoverData : BaseData
	{
		// Token: 0x06014A17 RID: 84503 RVA: 0x00530F1C File Offset: 0x0052F11C
		[CallerCount(0)]
		public unsafe CoverData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A18 RID: 84504 RVA: 0x00530F68 File Offset: 0x0052F168
		// Note: this type is marked as 'beforefieldinit'.
		static CoverData()
		{
			Il2CppClassPointerStore<CoverData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "CoverData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverData>.NativeClassPtr);
			CoverData.NativeFieldInfoPtr_CoverLayers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "CoverLayers");
			CoverData.NativeFieldInfoPtr_searchInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "searchInterval");
			CoverData.NativeFieldInfoPtr_HeightInterval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "HeightInterval");
			CoverData.NativeFieldInfoPtr_CrouchCoverHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "CrouchCoverHeight");
			CoverData.NativeFieldInfoPtr_CrouchFireHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "CrouchFireHeight");
			CoverData.NativeFieldInfoPtr_StandFireHeight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "StandFireHeight");
			CoverData.NativeFieldInfoPtr_DefaultWidth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "DefaultWidth");
			CoverData.NativeFieldInfoPtr_DefaultDepth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "DefaultDepth");
			CoverData.NativeFieldInfoPtr_DefaultStartingDepth = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "DefaultStartingDepth");
			CoverData.NativeFieldInfoPtr_DefaultHeightLevels = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "DefaultHeightLevels");
			CoverData.NativeFieldInfoPtr_MinDistanceToTeammate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverData>.NativeClassPtr, "MinDistanceToTeammate");
			CoverData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverData>.NativeClassPtr, 100689642);
		}

		// Token: 0x06014A19 RID: 84505 RVA: 0x000AD628 File Offset: 0x000AB828
		public CoverData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074C0 RID: 29888
		// (get) Token: 0x06014A1A RID: 84506 RVA: 0x00531088 File Offset: 0x0052F288
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverData>.NativeClassPtr));
			}
		}

		// Token: 0x170074C1 RID: 29889
		// (get) Token: 0x06014A1B RID: 84507 RVA: 0x0053109C File Offset: 0x0052F29C
		// (set) Token: 0x06014A1C RID: 84508 RVA: 0x005310C4 File Offset: 0x0052F2C4
		public unsafe LayerMask CoverLayers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CoverLayers);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CoverLayers)) = value;
			}
		}

		// Token: 0x170074C2 RID: 29890
		// (get) Token: 0x06014A1D RID: 84509 RVA: 0x005310E8 File Offset: 0x0052F2E8
		// (set) Token: 0x06014A1E RID: 84510 RVA: 0x00531110 File Offset: 0x0052F310
		public unsafe float searchInterval
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_searchInterval);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_searchInterval)) = value;
			}
		}

		// Token: 0x170074C3 RID: 29891
		// (get) Token: 0x06014A1F RID: 84511 RVA: 0x00531134 File Offset: 0x0052F334
		// (set) Token: 0x06014A20 RID: 84512 RVA: 0x0053115C File Offset: 0x0052F35C
		public unsafe float HeightInterval
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_HeightInterval);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_HeightInterval)) = value;
			}
		}

		// Token: 0x170074C4 RID: 29892
		// (get) Token: 0x06014A21 RID: 84513 RVA: 0x00531180 File Offset: 0x0052F380
		// (set) Token: 0x06014A22 RID: 84514 RVA: 0x005311A8 File Offset: 0x0052F3A8
		public unsafe float CrouchCoverHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CrouchCoverHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CrouchCoverHeight)) = value;
			}
		}

		// Token: 0x170074C5 RID: 29893
		// (get) Token: 0x06014A23 RID: 84515 RVA: 0x005311CC File Offset: 0x0052F3CC
		// (set) Token: 0x06014A24 RID: 84516 RVA: 0x005311F4 File Offset: 0x0052F3F4
		public unsafe float CrouchFireHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CrouchFireHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_CrouchFireHeight)) = value;
			}
		}

		// Token: 0x170074C6 RID: 29894
		// (get) Token: 0x06014A25 RID: 84517 RVA: 0x00531218 File Offset: 0x0052F418
		// (set) Token: 0x06014A26 RID: 84518 RVA: 0x00531240 File Offset: 0x0052F440
		public unsafe float StandFireHeight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_StandFireHeight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_StandFireHeight)) = value;
			}
		}

		// Token: 0x170074C7 RID: 29895
		// (get) Token: 0x06014A27 RID: 84519 RVA: 0x00531264 File Offset: 0x0052F464
		// (set) Token: 0x06014A28 RID: 84520 RVA: 0x0053128C File Offset: 0x0052F48C
		public unsafe float DefaultWidth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultWidth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultWidth)) = value;
			}
		}

		// Token: 0x170074C8 RID: 29896
		// (get) Token: 0x06014A29 RID: 84521 RVA: 0x005312B0 File Offset: 0x0052F4B0
		// (set) Token: 0x06014A2A RID: 84522 RVA: 0x005312D8 File Offset: 0x0052F4D8
		public unsafe float DefaultDepth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultDepth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultDepth)) = value;
			}
		}

		// Token: 0x170074C9 RID: 29897
		// (get) Token: 0x06014A2B RID: 84523 RVA: 0x005312FC File Offset: 0x0052F4FC
		// (set) Token: 0x06014A2C RID: 84524 RVA: 0x00531324 File Offset: 0x0052F524
		public unsafe float DefaultStartingDepth
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultStartingDepth);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultStartingDepth)) = value;
			}
		}

		// Token: 0x170074CA RID: 29898
		// (get) Token: 0x06014A2D RID: 84525 RVA: 0x00531348 File Offset: 0x0052F548
		// (set) Token: 0x06014A2E RID: 84526 RVA: 0x00531370 File Offset: 0x0052F570
		public unsafe int DefaultHeightLevels
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultHeightLevels);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_DefaultHeightLevels)) = value;
			}
		}

		// Token: 0x170074CB RID: 29899
		// (get) Token: 0x06014A2F RID: 84527 RVA: 0x00531394 File Offset: 0x0052F594
		// (set) Token: 0x06014A30 RID: 84528 RVA: 0x005313BC File Offset: 0x0052F5BC
		public unsafe float MinDistanceToTeammate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_MinDistanceToTeammate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverData.NativeFieldInfoPtr_MinDistanceToTeammate)) = value;
			}
		}

		// Token: 0x0400D310 RID: 54032
		private static readonly IntPtr NativeFieldInfoPtr_CoverLayers;

		// Token: 0x0400D311 RID: 54033
		private static readonly IntPtr NativeFieldInfoPtr_searchInterval;

		// Token: 0x0400D312 RID: 54034
		private static readonly IntPtr NativeFieldInfoPtr_HeightInterval;

		// Token: 0x0400D313 RID: 54035
		private static readonly IntPtr NativeFieldInfoPtr_CrouchCoverHeight;

		// Token: 0x0400D314 RID: 54036
		private static readonly IntPtr NativeFieldInfoPtr_CrouchFireHeight;

		// Token: 0x0400D315 RID: 54037
		private static readonly IntPtr NativeFieldInfoPtr_StandFireHeight;

		// Token: 0x0400D316 RID: 54038
		private static readonly IntPtr NativeFieldInfoPtr_DefaultWidth;

		// Token: 0x0400D317 RID: 54039
		private static readonly IntPtr NativeFieldInfoPtr_DefaultDepth;

		// Token: 0x0400D318 RID: 54040
		private static readonly IntPtr NativeFieldInfoPtr_DefaultStartingDepth;

		// Token: 0x0400D319 RID: 54041
		private static readonly IntPtr NativeFieldInfoPtr_DefaultHeightLevels;

		// Token: 0x0400D31A RID: 54042
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToTeammate;

		// Token: 0x0400D31B RID: 54043
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
