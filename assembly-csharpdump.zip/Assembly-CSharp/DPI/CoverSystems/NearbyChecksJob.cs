﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Unity.Collections;
using Unity.Mathematics;

namespace DPI.CoverSystems
{
	// Token: 0x02001153 RID: 4435
	[StructLayout(0)]
	public sealed class NearbyChecksJob : ValueType
	{
		// Token: 0x06014A91 RID: 84625 RVA: 0x00532D74 File Offset: 0x00530F74
		[CallerCount(0)]
		public unsafe void Execute()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(NearbyChecksJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A92 RID: 84626 RVA: 0x00532DB4 File Offset: 0x00530FB4
		[CallerCount(0)]
		public unsafe bool TooCloseToTeammate(float3 point)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(NearbyChecksJob.NativeMethodInfoPtr_TooCloseToTeammate_Private_Boolean_float3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A93 RID: 84627 RVA: 0x00532E14 File Offset: 0x00531014
		[CallerCount(0)]
		public unsafe float QuickSqrDistanceXZ(float3 pointOne, float3 pointTwo)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pointOne;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pointTwo;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(NearbyChecksJob.NativeMethodInfoPtr_QuickSqrDistanceXZ_Private_Single_float3_float3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A94 RID: 84628 RVA: 0x00532E88 File Offset: 0x00531088
		// Note: this type is marked as 'beforefieldinit'.
		static NearbyChecksJob()
		{
			Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "NearbyChecksJob");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr);
			NearbyChecksJob.NativeFieldInfoPtr_PossiblePositions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "PossiblePositions");
			NearbyChecksJob.NativeFieldInfoPtr_FriendlyPositions = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "FriendlyPositions");
			NearbyChecksJob.NativeFieldInfoPtr_ValidFriendlyCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "ValidFriendlyCount");
			NearbyChecksJob.NativeFieldInfoPtr_IsValid = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "IsValid");
			NearbyChecksJob.NativeFieldInfoPtr_MinDistanceToTeammate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "MinDistanceToTeammate");
			NearbyChecksJob.NativeFieldInfoPtr_ValidCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, "ValidCount");
			NearbyChecksJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, 100689672);
			NearbyChecksJob.NativeMethodInfoPtr_TooCloseToTeammate_Private_Boolean_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, 100689673);
			NearbyChecksJob.NativeMethodInfoPtr_QuickSqrDistanceXZ_Private_Single_float3_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, 100689674);
		}

		// Token: 0x06014A95 RID: 84629 RVA: 0x0002717B File Offset: 0x0002537B
		public NearbyChecksJob(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074EE RID: 29934
		// (get) Token: 0x06014A96 RID: 84630 RVA: 0x00532F6C File Offset: 0x0053116C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr));
			}
		}

		// Token: 0x06014A97 RID: 84631 RVA: 0x00532F80 File Offset: 0x00531180
		public unsafe NearbyChecksJob()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NearbyChecksJob>.NativeClassPtr, data));
		}

		// Token: 0x170074EF RID: 29935
		// (get) Token: 0x06014A98 RID: 84632 RVA: 0x00532FB0 File Offset: 0x005311B0
		// (set) Token: 0x06014A99 RID: 84633 RVA: 0x00532FE2 File Offset: 0x005311E2
		public NativeArray<float3> PossiblePositions
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_PossiblePositions);
				return new NativeArray<float3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_PossiblePositions), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074F0 RID: 29936
		// (get) Token: 0x06014A9A RID: 84634 RVA: 0x00533018 File Offset: 0x00531218
		// (set) Token: 0x06014A9B RID: 84635 RVA: 0x0053304A File Offset: 0x0053124A
		public NativeArray<float3> FriendlyPositions
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_FriendlyPositions);
				return new NativeArray<float3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_FriendlyPositions), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074F1 RID: 29937
		// (get) Token: 0x06014A9C RID: 84636 RVA: 0x00533080 File Offset: 0x00531280
		// (set) Token: 0x06014A9D RID: 84637 RVA: 0x005330A8 File Offset: 0x005312A8
		public unsafe int ValidFriendlyCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_ValidFriendlyCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_ValidFriendlyCount)) = value;
			}
		}

		// Token: 0x170074F2 RID: 29938
		// (get) Token: 0x06014A9E RID: 84638 RVA: 0x005330CC File Offset: 0x005312CC
		// (set) Token: 0x06014A9F RID: 84639 RVA: 0x005330FE File Offset: 0x005312FE
		public NativeArray<int> IsValid
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_IsValid);
				return new NativeArray<int>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_IsValid), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074F3 RID: 29939
		// (get) Token: 0x06014AA0 RID: 84640 RVA: 0x00533134 File Offset: 0x00531334
		// (set) Token: 0x06014AA1 RID: 84641 RVA: 0x0053315C File Offset: 0x0053135C
		public unsafe float MinDistanceToTeammate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_MinDistanceToTeammate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_MinDistanceToTeammate)) = value;
			}
		}

		// Token: 0x170074F4 RID: 29940
		// (get) Token: 0x06014AA2 RID: 84642 RVA: 0x00533180 File Offset: 0x00531380
		// (set) Token: 0x06014AA3 RID: 84643 RVA: 0x005331B2 File Offset: 0x005313B2
		public NativeArray<int> ValidCount
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_ValidCount);
				return new NativeArray<int>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(NearbyChecksJob.NativeFieldInfoPtr_ValidCount), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x0400D352 RID: 54098
		private static readonly IntPtr NativeFieldInfoPtr_PossiblePositions;

		// Token: 0x0400D353 RID: 54099
		private static readonly IntPtr NativeFieldInfoPtr_FriendlyPositions;

		// Token: 0x0400D354 RID: 54100
		private static readonly IntPtr NativeFieldInfoPtr_ValidFriendlyCount;

		// Token: 0x0400D355 RID: 54101
		private static readonly IntPtr NativeFieldInfoPtr_IsValid;

		// Token: 0x0400D356 RID: 54102
		private static readonly IntPtr NativeFieldInfoPtr_MinDistanceToTeammate;

		// Token: 0x0400D357 RID: 54103
		private static readonly IntPtr NativeFieldInfoPtr_ValidCount;

		// Token: 0x0400D358 RID: 54104
		private static readonly IntPtr NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400D359 RID: 54105
		private static readonly IntPtr NativeMethodInfoPtr_TooCloseToTeammate_Private_Boolean_float3_0;

		// Token: 0x0400D35A RID: 54106
		private static readonly IntPtr NativeMethodInfoPtr_QuickSqrDistanceXZ_Private_Single_float3_float3_0;
	}
}
