﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace DPI.CoverSystems
{
	// Token: 0x02001154 RID: 4436
	[StructLayout(0)]
	public sealed class ScoreCoverJob : ValueType
	{
		// Token: 0x06014AA4 RID: 84644 RVA: 0x005331E8 File Offset: 0x005313E8
		[CallerCount(0)]
		public unsafe void Execute()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScoreCoverJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014AA5 RID: 84645 RVA: 0x00533228 File Offset: 0x00531428
		[CallerCount(0)]
		public unsafe float ScoreNode(float3 node, float heightMin, float heightMax, float maxDistance)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref node;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMin;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMax;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDistance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScoreCoverJob.NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AA6 RID: 84646 RVA: 0x005332C4 File Offset: 0x005314C4
		[CallerCount(0)]
		public unsafe float Distance(float3 a, float3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScoreCoverJob.NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AA7 RID: 84647 RVA: 0x00533338 File Offset: 0x00531538
		[CallerCount(0)]
		public unsafe float NormalizeValues(float dataValue, float min, float max)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dataValue;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref min;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScoreCoverJob.NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014AA8 RID: 84648 RVA: 0x005333C0 File Offset: 0x005315C0
		// Note: this type is marked as 'beforefieldinit'.
		static ScoreCoverJob()
		{
			Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "ScoreCoverJob");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr);
			ScoreCoverJob.NativeFieldInfoPtr_RaycastCountPerPoint = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "RaycastCountPerPoint");
			ScoreCoverJob.NativeFieldInfoPtr_CoverPoints = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "CoverPoints");
			ScoreCoverJob.NativeFieldInfoPtr_IsValid = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "IsValid");
			ScoreCoverJob.NativeFieldInfoPtr_HitResults = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "HitResults");
			ScoreCoverJob.NativeFieldInfoPtr_PreferredPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "PreferredPosition");
			ScoreCoverJob.NativeFieldInfoPtr_HeightMin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "HeightMin");
			ScoreCoverJob.NativeFieldInfoPtr_HeightMax = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "HeightMax");
			ScoreCoverJob.NativeFieldInfoPtr_SearchRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "SearchRadius");
			ScoreCoverJob.NativeFieldInfoPtr_BestCover = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "BestCover");
			ScoreCoverJob.NativeFieldInfoPtr_BestCoverFound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, "BestCoverFound");
			ScoreCoverJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, 100689675);
			ScoreCoverJob.NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, 100689676);
			ScoreCoverJob.NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, 100689677);
			ScoreCoverJob.NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, 100689678);
		}

		// Token: 0x06014AA9 RID: 84649 RVA: 0x0002717B File Offset: 0x0002537B
		public ScoreCoverJob(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074F5 RID: 29941
		// (get) Token: 0x06014AAA RID: 84650 RVA: 0x00533508 File Offset: 0x00531708
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr));
			}
		}

		// Token: 0x06014AAB RID: 84651 RVA: 0x0053351C File Offset: 0x0053171C
		public unsafe ScoreCoverJob()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ScoreCoverJob>.NativeClassPtr, data));
		}

		// Token: 0x170074F6 RID: 29942
		// (get) Token: 0x06014AAC RID: 84652 RVA: 0x0053354C File Offset: 0x0053174C
		// (set) Token: 0x06014AAD RID: 84653 RVA: 0x00533574 File Offset: 0x00531774
		public unsafe int RaycastCountPerPoint
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_RaycastCountPerPoint);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_RaycastCountPerPoint)) = value;
			}
		}

		// Token: 0x170074F7 RID: 29943
		// (get) Token: 0x06014AAE RID: 84654 RVA: 0x00533598 File Offset: 0x00531798
		// (set) Token: 0x06014AAF RID: 84655 RVA: 0x005335CA File Offset: 0x005317CA
		public NativeArray<float3> CoverPoints
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_CoverPoints);
				return new NativeArray<float3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_CoverPoints), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074F8 RID: 29944
		// (get) Token: 0x06014AB0 RID: 84656 RVA: 0x00533600 File Offset: 0x00531800
		// (set) Token: 0x06014AB1 RID: 84657 RVA: 0x00533632 File Offset: 0x00531832
		public NativeArray<int> IsValid
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_IsValid);
				return new NativeArray<int>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_IsValid), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074F9 RID: 29945
		// (get) Token: 0x06014AB2 RID: 84658 RVA: 0x00533668 File Offset: 0x00531868
		// (set) Token: 0x06014AB3 RID: 84659 RVA: 0x0053369A File Offset: 0x0053189A
		public NativeArray<RaycastHit> HitResults
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HitResults);
				return new NativeArray<RaycastHit>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<RaycastHit>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HitResults), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<RaycastHit>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074FA RID: 29946
		// (get) Token: 0x06014AB4 RID: 84660 RVA: 0x005336D0 File Offset: 0x005318D0
		// (set) Token: 0x06014AB5 RID: 84661 RVA: 0x005336F8 File Offset: 0x005318F8
		public unsafe float3 PreferredPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_PreferredPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_PreferredPosition)) = value;
			}
		}

		// Token: 0x170074FB RID: 29947
		// (get) Token: 0x06014AB6 RID: 84662 RVA: 0x0053371C File Offset: 0x0053191C
		// (set) Token: 0x06014AB7 RID: 84663 RVA: 0x00533744 File Offset: 0x00531944
		public unsafe float HeightMin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HeightMin);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HeightMin)) = value;
			}
		}

		// Token: 0x170074FC RID: 29948
		// (get) Token: 0x06014AB8 RID: 84664 RVA: 0x00533768 File Offset: 0x00531968
		// (set) Token: 0x06014AB9 RID: 84665 RVA: 0x00533790 File Offset: 0x00531990
		public unsafe float HeightMax
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HeightMax);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_HeightMax)) = value;
			}
		}

		// Token: 0x170074FD RID: 29949
		// (get) Token: 0x06014ABA RID: 84666 RVA: 0x005337B4 File Offset: 0x005319B4
		// (set) Token: 0x06014ABB RID: 84667 RVA: 0x005337DC File Offset: 0x005319DC
		public unsafe float SearchRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_SearchRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_SearchRadius)) = value;
			}
		}

		// Token: 0x170074FE RID: 29950
		// (get) Token: 0x06014ABC RID: 84668 RVA: 0x00533800 File Offset: 0x00531A00
		// (set) Token: 0x06014ABD RID: 84669 RVA: 0x00533832 File Offset: 0x00531A32
		public NativeArray<float3> BestCover
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_BestCover);
				return new NativeArray<float3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_BestCover), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x170074FF RID: 29951
		// (get) Token: 0x06014ABE RID: 84670 RVA: 0x00533868 File Offset: 0x00531A68
		// (set) Token: 0x06014ABF RID: 84671 RVA: 0x0053389A File Offset: 0x00531A9A
		public NativeArray<int> BestCoverFound
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_BestCoverFound);
				return new NativeArray<int>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScoreCoverJob.NativeFieldInfoPtr_BestCoverFound), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x0400D35B RID: 54107
		private static readonly IntPtr NativeFieldInfoPtr_RaycastCountPerPoint;

		// Token: 0x0400D35C RID: 54108
		private static readonly IntPtr NativeFieldInfoPtr_CoverPoints;

		// Token: 0x0400D35D RID: 54109
		private static readonly IntPtr NativeFieldInfoPtr_IsValid;

		// Token: 0x0400D35E RID: 54110
		private static readonly IntPtr NativeFieldInfoPtr_HitResults;

		// Token: 0x0400D35F RID: 54111
		private static readonly IntPtr NativeFieldInfoPtr_PreferredPosition;

		// Token: 0x0400D360 RID: 54112
		private static readonly IntPtr NativeFieldInfoPtr_HeightMin;

		// Token: 0x0400D361 RID: 54113
		private static readonly IntPtr NativeFieldInfoPtr_HeightMax;

		// Token: 0x0400D362 RID: 54114
		private static readonly IntPtr NativeFieldInfoPtr_SearchRadius;

		// Token: 0x0400D363 RID: 54115
		private static readonly IntPtr NativeFieldInfoPtr_BestCover;

		// Token: 0x0400D364 RID: 54116
		private static readonly IntPtr NativeFieldInfoPtr_BestCoverFound;

		// Token: 0x0400D365 RID: 54117
		private static readonly IntPtr NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400D366 RID: 54118
		private static readonly IntPtr NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_0;

		// Token: 0x0400D367 RID: 54119
		private static readonly IntPtr NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0;

		// Token: 0x0400D368 RID: 54120
		private static readonly IntPtr NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0;
	}
}
