﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Unity.Mathematics;
using UnityEngine;

namespace DPI.CoverSystems
{
	// Token: 0x0200114F RID: 4431
	public class CoverManager : MonoBehaviour
	{
		// Token: 0x06014A36 RID: 84534 RVA: 0x005314DC File Offset: 0x0052F6DC
		[CallerCount(0)]
		public unsafe void Initialize(HumanoidAI owner)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A37 RID: 84535 RVA: 0x00531538 File Offset: 0x0052F738
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A38 RID: 84536 RVA: 0x0053157C File Offset: 0x0052F77C
		[CallerCount(0)]
		public unsafe void GetCover(Vector3 preferredPosition, float searchRadius, Vector3 dangerPosition, Faction faction)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref preferredPosition;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref searchRadius;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dangerPosition;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_GetCover_Public_Void_Vector3_Single_Vector3_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A39 RID: 84537 RVA: 0x0053160C File Offset: 0x0052F80C
		[CallerCount(0)]
		public unsafe IEnumerator RunCover(Vector3 preferredPosition, float searchRadius, Vector3 dangerPosition, Faction faction)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref preferredPosition;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref searchRadius;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dangerPosition;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_RunCover_Private_IEnumerator_Vector3_Single_Vector3_Faction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06014A3A RID: 84538 RVA: 0x005316B0 File Offset: 0x0052F8B0
		[CallerCount(0)]
		public unsafe float ScoreNode(float3 node, float heightMin, float heightMax, float maxDistance, float3 preferredPosition, Vector3 dangerPosition)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref node;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMin;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMax;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDistance;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref preferredPosition;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dangerPosition;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_float3_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A3B RID: 84539 RVA: 0x00531774 File Offset: 0x0052F974
		[CallerCount(0)]
		public unsafe float Distance(float3 a, float3 b)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A3C RID: 84540 RVA: 0x005317EC File Offset: 0x0052F9EC
		[CallerCount(0)]
		public unsafe float NormalizeValues(float dataValue, float min, float max)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dataValue;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref min;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref max;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A3D RID: 84541 RVA: 0x00531874 File Offset: 0x0052FA74
		[CallerCount(0)]
		public unsafe static List<Vector3> GetTeamPoints(Faction faction, HumanoidAI requestingAI, Vector3 pos, float distance)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref faction;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(requestingAI);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pos;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref distance;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_GetTeamPoints_Public_Static_List_1_Vector3_Faction_HumanoidAI_Vector3_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
		}

		// Token: 0x06014A3E RID: 84542 RVA: 0x0053190C File Offset: 0x0052FB0C
		[CallerCount(0)]
		public unsafe float CheckCoverAtPoint(Vector3 point, Vector3 targetPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPoint;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_CheckCoverAtPoint_Private_Single_Vector3_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A3F RID: 84543 RVA: 0x00531984 File Offset: 0x0052FB84
		[CallerCount(0)]
		public unsafe bool SightBlocked(Vector3 point, Vector3 targetPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPoint;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr_SightBlocked_Private_Boolean_Vector3_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A40 RID: 84544 RVA: 0x005319FC File Offset: 0x0052FBFC
		[CallerCount(0)]
		public unsafe CoverManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A41 RID: 84545 RVA: 0x00531A48 File Offset: 0x0052FC48
		// Note: this type is marked as 'beforefieldinit'.
		static CoverManager()
		{
			Il2CppClassPointerStore<CoverManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "CoverManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverManager>.NativeClassPtr);
			CoverManager.NativeFieldInfoPtr_MaxRaycastCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "MaxRaycastCount");
			CoverManager.NativeFieldInfoPtr_CoverIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "CoverIterations");
			CoverManager.NativeFieldInfoPtr_TempNodesList = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "TempNodesList");
			CoverManager.NativeFieldInfoPtr_OnCoverComplete = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "OnCoverComplete");
			CoverManager.NativeFieldInfoPtr__coverData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "_coverData");
			CoverManager.NativeFieldInfoPtr__owner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "_owner");
			CoverManager.NativeFieldInfoPtr__coverRunner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "_coverRunner");
			CoverManager.NativeFieldInfoPtr__iterationsPerFrame = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "_iterationsPerFrame");
			CoverManager.NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689645);
			CoverManager.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689646);
			CoverManager.NativeMethodInfoPtr_GetCover_Public_Void_Vector3_Single_Vector3_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689647);
			CoverManager.NativeMethodInfoPtr_RunCover_Private_IEnumerator_Vector3_Single_Vector3_Faction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689648);
			CoverManager.NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_float3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689649);
			CoverManager.NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689650);
			CoverManager.NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689651);
			CoverManager.NativeMethodInfoPtr_GetTeamPoints_Public_Static_List_1_Vector3_Faction_HumanoidAI_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689652);
			CoverManager.NativeMethodInfoPtr_CheckCoverAtPoint_Private_Single_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689653);
			CoverManager.NativeMethodInfoPtr_SightBlocked_Private_Boolean_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689654);
			CoverManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, 100689655);
		}

		// Token: 0x06014A42 RID: 84546 RVA: 0x0000210C File Offset: 0x0000030C
		public CoverManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074CD RID: 29901
		// (get) Token: 0x06014A43 RID: 84547 RVA: 0x00531BF4 File Offset: 0x0052FDF4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverManager>.NativeClassPtr));
			}
		}

		// Token: 0x170074CE RID: 29902
		// (get) Token: 0x06014A44 RID: 84548 RVA: 0x00531C08 File Offset: 0x0052FE08
		// (set) Token: 0x06014A45 RID: 84549 RVA: 0x00531C26 File Offset: 0x0052FE26
		public unsafe static int MaxRaycastCount
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(CoverManager.NativeFieldInfoPtr_MaxRaycastCount, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CoverManager.NativeFieldInfoPtr_MaxRaycastCount, (void*)(&value));
			}
		}

		// Token: 0x170074CF RID: 29903
		// (get) Token: 0x06014A46 RID: 84550 RVA: 0x00531C38 File Offset: 0x0052FE38
		// (set) Token: 0x06014A47 RID: 84551 RVA: 0x00531C56 File Offset: 0x0052FE56
		public unsafe static float CoverIterations
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(CoverManager.NativeFieldInfoPtr_CoverIterations, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CoverManager.NativeFieldInfoPtr_CoverIterations, (void*)(&value));
			}
		}

		// Token: 0x170074D0 RID: 29904
		// (get) Token: 0x06014A48 RID: 84552 RVA: 0x00531C68 File Offset: 0x0052FE68
		// (set) Token: 0x06014A49 RID: 84553 RVA: 0x00531C9C File Offset: 0x0052FE9C
		public unsafe List<NavigationNode> TempNodesList
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr_TempNodesList);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<NavigationNode>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr_TempNodesList), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074D1 RID: 29905
		// (get) Token: 0x06014A4A RID: 84554 RVA: 0x00531CC4 File Offset: 0x0052FEC4
		// (set) Token: 0x06014A4B RID: 84555 RVA: 0x00531CF8 File Offset: 0x0052FEF8
		public unsafe Action<bool, CoverPoint> OnCoverComplete
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr_OnCoverComplete);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<bool, CoverPoint>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr_OnCoverComplete), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074D2 RID: 29906
		// (get) Token: 0x06014A4C RID: 84556 RVA: 0x00531D20 File Offset: 0x0052FF20
		// (set) Token: 0x06014A4D RID: 84557 RVA: 0x00531D54 File Offset: 0x0052FF54
		public unsafe CoverData _coverData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__coverData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CoverData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__coverData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074D3 RID: 29907
		// (get) Token: 0x06014A4E RID: 84558 RVA: 0x00531D7C File Offset: 0x0052FF7C
		// (set) Token: 0x06014A4F RID: 84559 RVA: 0x00531DB0 File Offset: 0x0052FFB0
		public unsafe HumanoidAI _owner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__owner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new HumanoidAI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__owner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074D4 RID: 29908
		// (get) Token: 0x06014A50 RID: 84560 RVA: 0x00531DD8 File Offset: 0x0052FFD8
		// (set) Token: 0x06014A51 RID: 84561 RVA: 0x00531E0C File Offset: 0x0053000C
		public unsafe Coroutine _coverRunner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__coverRunner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__coverRunner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074D5 RID: 29909
		// (get) Token: 0x06014A52 RID: 84562 RVA: 0x00531E34 File Offset: 0x00530034
		// (set) Token: 0x06014A53 RID: 84563 RVA: 0x00531E5C File Offset: 0x0053005C
		public unsafe int _iterationsPerFrame
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__iterationsPerFrame);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager.NativeFieldInfoPtr__iterationsPerFrame)) = value;
			}
		}

		// Token: 0x0400D31E RID: 54046
		private static readonly IntPtr NativeFieldInfoPtr_MaxRaycastCount;

		// Token: 0x0400D31F RID: 54047
		private static readonly IntPtr NativeFieldInfoPtr_CoverIterations;

		// Token: 0x0400D320 RID: 54048
		private static readonly IntPtr NativeFieldInfoPtr_TempNodesList;

		// Token: 0x0400D321 RID: 54049
		private static readonly IntPtr NativeFieldInfoPtr_OnCoverComplete;

		// Token: 0x0400D322 RID: 54050
		private static readonly IntPtr NativeFieldInfoPtr__coverData;

		// Token: 0x0400D323 RID: 54051
		private static readonly IntPtr NativeFieldInfoPtr__owner;

		// Token: 0x0400D324 RID: 54052
		private static readonly IntPtr NativeFieldInfoPtr__coverRunner;

		// Token: 0x0400D325 RID: 54053
		private static readonly IntPtr NativeFieldInfoPtr__iterationsPerFrame;

		// Token: 0x0400D326 RID: 54054
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_HumanoidAI_0;

		// Token: 0x0400D327 RID: 54055
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400D328 RID: 54056
		private static readonly IntPtr NativeMethodInfoPtr_GetCover_Public_Void_Vector3_Single_Vector3_Faction_0;

		// Token: 0x0400D329 RID: 54057
		private static readonly IntPtr NativeMethodInfoPtr_RunCover_Private_IEnumerator_Vector3_Single_Vector3_Faction_0;

		// Token: 0x0400D32A RID: 54058
		private static readonly IntPtr NativeMethodInfoPtr_ScoreNode_Private_Single_float3_Single_Single_Single_float3_Vector3_0;

		// Token: 0x0400D32B RID: 54059
		private static readonly IntPtr NativeMethodInfoPtr_Distance_Private_Single_float3_float3_0;

		// Token: 0x0400D32C RID: 54060
		private static readonly IntPtr NativeMethodInfoPtr_NormalizeValues_Private_Single_Single_Single_Single_0;

		// Token: 0x0400D32D RID: 54061
		private static readonly IntPtr NativeMethodInfoPtr_GetTeamPoints_Public_Static_List_1_Vector3_Faction_HumanoidAI_Vector3_Single_0;

		// Token: 0x0400D32E RID: 54062
		private static readonly IntPtr NativeMethodInfoPtr_CheckCoverAtPoint_Private_Single_Vector3_Vector3_0;

		// Token: 0x0400D32F RID: 54063
		private static readonly IntPtr NativeMethodInfoPtr_SightBlocked_Private_Boolean_Vector3_Vector3_0;

		// Token: 0x0400D330 RID: 54064
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001150 RID: 4432
		[ObfuscatedName("DPI.CoverSystems.CoverManager/<RunCover>d__11")]
		public sealed class _RunCover_d__11 : Il2CppSystem.Object
		{
			// Token: 0x06014A54 RID: 84564 RVA: 0x00531E80 File Offset: 0x00530080
			[CallerCount(0)]
			public unsafe _RunCover_d__11(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014A55 RID: 84565 RVA: 0x00531EE0 File Offset: 0x005300E0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06014A56 RID: 84566 RVA: 0x00531F24 File Offset: 0x00530124
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x170074E4 RID: 29924
			// (get) Token: 0x06014A57 RID: 84567 RVA: 0x00531F74 File Offset: 0x00530174
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014A58 RID: 84568 RVA: 0x00531FCC File Offset: 0x005301CC
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x170074E5 RID: 29925
			// (get) Token: 0x06014A59 RID: 84569 RVA: 0x00532010 File Offset: 0x00530210
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06014A5A RID: 84570 RVA: 0x00532068 File Offset: 0x00530268
			// Note: this type is marked as 'beforefieldinit'.
			static _RunCover_d__11()
			{
				Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CoverManager>.NativeClassPtr, "<RunCover>d__11");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr);
				CoverManager._RunCover_d__11.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<>1__state");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<>2__current");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr_preferredPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "preferredPosition");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr_searchRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "searchRadius");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<>4__this");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr_dangerPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "dangerPosition");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__coverPoint_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<coverPoint>5__2");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__friendPoints_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<friendPoints>5__3");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__topScore_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<topScore>5__4");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__remainingIterations_5__5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<remainingIterations>5__5");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__i_5__6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<i>5__6");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__count_5__7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<count>5__7");
				CoverManager._RunCover_d__11.NativeFieldInfoPtr__node_5__8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, "<node>5__8");
				CoverManager._RunCover_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689657);
				CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689658);
				CoverManager._RunCover_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689659);
				CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689660);
				CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689661);
				CoverManager._RunCover_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr, 100689662);
			}

			// Token: 0x06014A5B RID: 84571 RVA: 0x00002988 File Offset: 0x00000B88
			public _RunCover_d__11(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170074D6 RID: 29910
			// (get) Token: 0x06014A5C RID: 84572 RVA: 0x0053220F File Offset: 0x0053040F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverManager._RunCover_d__11>.NativeClassPtr));
				}
			}

			// Token: 0x170074D7 RID: 29911
			// (get) Token: 0x06014A5D RID: 84573 RVA: 0x00532220 File Offset: 0x00530420
			// (set) Token: 0x06014A5E RID: 84574 RVA: 0x00532248 File Offset: 0x00530448
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x170074D8 RID: 29912
			// (get) Token: 0x06014A5F RID: 84575 RVA: 0x0053226C File Offset: 0x0053046C
			// (set) Token: 0x06014A60 RID: 84576 RVA: 0x005322A0 File Offset: 0x005304A0
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170074D9 RID: 29913
			// (get) Token: 0x06014A61 RID: 84577 RVA: 0x005322C8 File Offset: 0x005304C8
			// (set) Token: 0x06014A62 RID: 84578 RVA: 0x005322F0 File Offset: 0x005304F0
			public unsafe Vector3 preferredPosition
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_preferredPosition);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_preferredPosition)) = value;
				}
			}

			// Token: 0x170074DA RID: 29914
			// (get) Token: 0x06014A63 RID: 84579 RVA: 0x00532314 File Offset: 0x00530514
			// (set) Token: 0x06014A64 RID: 84580 RVA: 0x0053233C File Offset: 0x0053053C
			public unsafe float searchRadius
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_searchRadius);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_searchRadius)) = value;
				}
			}

			// Token: 0x170074DB RID: 29915
			// (get) Token: 0x06014A65 RID: 84581 RVA: 0x00532360 File Offset: 0x00530560
			// (set) Token: 0x06014A66 RID: 84582 RVA: 0x00532394 File Offset: 0x00530594
			public unsafe CoverManager __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new CoverManager(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170074DC RID: 29916
			// (get) Token: 0x06014A67 RID: 84583 RVA: 0x005323BC File Offset: 0x005305BC
			// (set) Token: 0x06014A68 RID: 84584 RVA: 0x005323E4 File Offset: 0x005305E4
			public unsafe Vector3 dangerPosition
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_dangerPosition);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr_dangerPosition)) = value;
				}
			}

			// Token: 0x170074DD RID: 29917
			// (get) Token: 0x06014A69 RID: 84585 RVA: 0x00532408 File Offset: 0x00530608
			// (set) Token: 0x06014A6A RID: 84586 RVA: 0x0053243C File Offset: 0x0053063C
			public unsafe CoverPoint _coverPoint_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__coverPoint_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new CoverPoint(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__coverPoint_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170074DE RID: 29918
			// (get) Token: 0x06014A6B RID: 84587 RVA: 0x00532464 File Offset: 0x00530664
			// (set) Token: 0x06014A6C RID: 84588 RVA: 0x00532498 File Offset: 0x00530698
			public unsafe List<Vector3> _friendPoints_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__friendPoints_5__3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__friendPoints_5__3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170074DF RID: 29919
			// (get) Token: 0x06014A6D RID: 84589 RVA: 0x005324C0 File Offset: 0x005306C0
			// (set) Token: 0x06014A6E RID: 84590 RVA: 0x005324E8 File Offset: 0x005306E8
			public unsafe float _topScore_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__topScore_5__4);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__topScore_5__4)) = value;
				}
			}

			// Token: 0x170074E0 RID: 29920
			// (get) Token: 0x06014A6F RID: 84591 RVA: 0x0053250C File Offset: 0x0053070C
			// (set) Token: 0x06014A70 RID: 84592 RVA: 0x00532534 File Offset: 0x00530734
			public unsafe int _remainingIterations_5__5
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__remainingIterations_5__5);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__remainingIterations_5__5)) = value;
				}
			}

			// Token: 0x170074E1 RID: 29921
			// (get) Token: 0x06014A71 RID: 84593 RVA: 0x00532558 File Offset: 0x00530758
			// (set) Token: 0x06014A72 RID: 84594 RVA: 0x00532580 File Offset: 0x00530780
			public unsafe int _i_5__6
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__i_5__6);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__i_5__6)) = value;
				}
			}

			// Token: 0x170074E2 RID: 29922
			// (get) Token: 0x06014A73 RID: 84595 RVA: 0x005325A4 File Offset: 0x005307A4
			// (set) Token: 0x06014A74 RID: 84596 RVA: 0x005325CC File Offset: 0x005307CC
			public unsafe int _count_5__7
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__count_5__7);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__count_5__7)) = value;
				}
			}

			// Token: 0x170074E3 RID: 29923
			// (get) Token: 0x06014A75 RID: 84597 RVA: 0x005325F0 File Offset: 0x005307F0
			// (set) Token: 0x06014A76 RID: 84598 RVA: 0x00532622 File Offset: 0x00530822
			public NavigationNode _node_5__8
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__node_5__8);
					return new NavigationNode(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NavigationNode>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverManager._RunCover_d__11.NativeFieldInfoPtr__node_5__8), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NavigationNode>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x0400D331 RID: 54065
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400D332 RID: 54066
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400D333 RID: 54067
			private static readonly IntPtr NativeFieldInfoPtr_preferredPosition;

			// Token: 0x0400D334 RID: 54068
			private static readonly IntPtr NativeFieldInfoPtr_searchRadius;

			// Token: 0x0400D335 RID: 54069
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400D336 RID: 54070
			private static readonly IntPtr NativeFieldInfoPtr_dangerPosition;

			// Token: 0x0400D337 RID: 54071
			private static readonly IntPtr NativeFieldInfoPtr__coverPoint_5__2;

			// Token: 0x0400D338 RID: 54072
			private static readonly IntPtr NativeFieldInfoPtr__friendPoints_5__3;

			// Token: 0x0400D339 RID: 54073
			private static readonly IntPtr NativeFieldInfoPtr__topScore_5__4;

			// Token: 0x0400D33A RID: 54074
			private static readonly IntPtr NativeFieldInfoPtr__remainingIterations_5__5;

			// Token: 0x0400D33B RID: 54075
			private static readonly IntPtr NativeFieldInfoPtr__i_5__6;

			// Token: 0x0400D33C RID: 54076
			private static readonly IntPtr NativeFieldInfoPtr__count_5__7;

			// Token: 0x0400D33D RID: 54077
			private static readonly IntPtr NativeFieldInfoPtr__node_5__8;

			// Token: 0x0400D33E RID: 54078
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400D33F RID: 54079
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D340 RID: 54080
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400D341 RID: 54081
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400D342 RID: 54082
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400D343 RID: 54083
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
