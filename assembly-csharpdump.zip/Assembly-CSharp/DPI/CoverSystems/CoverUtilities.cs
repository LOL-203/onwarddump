﻿using System;
using DPI.Navigation;
using Il2CppSystem;
using OnwardAI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.CoverSystems
{
	// Token: 0x02001152 RID: 4434
	public static class CoverUtilities : Il2CppSystem.Object
	{
		// Token: 0x06014A83 RID: 84611 RVA: 0x0053287C File Offset: 0x00530A7C
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A84 RID: 84612 RVA: 0x005328B0 File Offset: 0x00530AB0
		[CallerCount(0)]
		public unsafe static void FindCover(ref CoverPoint coverPoint, Vector3 dangerPosition, Vector3 preferredPosition, float searchRadius, Faction faction, HumanoidAI requestingAI)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(coverPoint);
			ptr2 = &intPtr;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dangerPosition;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref preferredPosition;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref searchRadius;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(requestingAI);
			IntPtr returnedException;
			IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_FindCover_Public_Static_Void_byref_CoverPoint_Vector3_Vector3_Single_Faction_HumanoidAI_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr3 = intPtr;
			coverPoint = ((intPtr3 == 0) ? null : new CoverPoint(intPtr3));
		}

		// Token: 0x06014A85 RID: 84613 RVA: 0x00532980 File Offset: 0x00530B80
		[CallerCount(0)]
		public unsafe static float ScoreNode(NavigationNode node, Vector3 center, float heightMin, float heightMax, float maxDistance, Vector3 dangerPosition)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(node));
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref center;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMin;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref heightMax;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxDistance;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dangerPosition;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_ScoreNode_Private_Static_Single_NavigationNode_Vector3_Single_Single_Single_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A86 RID: 84614 RVA: 0x00532A3C File Offset: 0x00530C3C
		[CallerCount(0)]
		public unsafe static bool TooCloseToTeammate(Vector3 point, Faction faction, HumanoidAI requestingAI)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref faction;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(requestingAI);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_TooCloseToTeammate_Public_Static_Boolean_Vector3_Faction_HumanoidAI_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A87 RID: 84615 RVA: 0x00532ABC File Offset: 0x00530CBC
		[CallerCount(0)]
		public unsafe static float CheckCoverAtPoint(Vector3 point, Vector3 targetPoint)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPoint;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_CheckCoverAtPoint_Private_Static_Single_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A88 RID: 84616 RVA: 0x00532B24 File Offset: 0x00530D24
		[CallerCount(0)]
		public unsafe static bool SightBlocked(Vector3 point, Vector3 targetPoint)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref point;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPoint;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_SightBlocked_Private_Static_Boolean_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06014A89 RID: 84617 RVA: 0x00532B8C File Offset: 0x00530D8C
		[CallerCount(0)]
		public unsafe static void DrawDebug(Vector3 start, Vector3 end, Color color, float duration)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref start;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref end;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref color;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverUtilities.NativeMethodInfoPtr_DrawDebug_Private_Static_Void_Vector3_Vector3_Color_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A8A RID: 84618 RVA: 0x00532C0C File Offset: 0x00530E0C
		// Note: this type is marked as 'beforefieldinit'.
		static CoverUtilities()
		{
			Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "CoverUtilities");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr);
			CoverUtilities.NativeFieldInfoPtr_CoverIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, "CoverIterations");
			CoverUtilities.NativeFieldInfoPtr__coverData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, "_coverData");
			CoverUtilities.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689664);
			CoverUtilities.NativeMethodInfoPtr_FindCover_Public_Static_Void_byref_CoverPoint_Vector3_Vector3_Single_Faction_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689665);
			CoverUtilities.NativeMethodInfoPtr_ScoreNode_Private_Static_Single_NavigationNode_Vector3_Single_Single_Single_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689666);
			CoverUtilities.NativeMethodInfoPtr_TooCloseToTeammate_Public_Static_Boolean_Vector3_Faction_HumanoidAI_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689667);
			CoverUtilities.NativeMethodInfoPtr_CheckCoverAtPoint_Private_Static_Single_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689668);
			CoverUtilities.NativeMethodInfoPtr_SightBlocked_Private_Static_Boolean_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689669);
			CoverUtilities.NativeMethodInfoPtr_DrawDebug_Private_Static_Void_Vector3_Vector3_Color_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr, 100689670);
		}

		// Token: 0x06014A8B RID: 84619 RVA: 0x00002988 File Offset: 0x00000B88
		public CoverUtilities(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074EB RID: 29931
		// (get) Token: 0x06014A8C RID: 84620 RVA: 0x00532CF0 File Offset: 0x00530EF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverUtilities>.NativeClassPtr));
			}
		}

		// Token: 0x170074EC RID: 29932
		// (get) Token: 0x06014A8D RID: 84621 RVA: 0x00532D04 File Offset: 0x00530F04
		// (set) Token: 0x06014A8E RID: 84622 RVA: 0x00532D22 File Offset: 0x00530F22
		public unsafe static float CoverIterations
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(CoverUtilities.NativeFieldInfoPtr_CoverIterations, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CoverUtilities.NativeFieldInfoPtr_CoverIterations, (void*)(&value));
			}
		}

		// Token: 0x170074ED RID: 29933
		// (get) Token: 0x06014A8F RID: 84623 RVA: 0x00532D34 File Offset: 0x00530F34
		// (set) Token: 0x06014A90 RID: 84624 RVA: 0x00532D5F File Offset: 0x00530F5F
		public unsafe static CoverData _coverData
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(CoverUtilities.NativeFieldInfoPtr__coverData, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new CoverData(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CoverUtilities.NativeFieldInfoPtr__coverData, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D349 RID: 54089
		private static readonly IntPtr NativeFieldInfoPtr_CoverIterations;

		// Token: 0x0400D34A RID: 54090
		private static readonly IntPtr NativeFieldInfoPtr__coverData;

		// Token: 0x0400D34B RID: 54091
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400D34C RID: 54092
		private static readonly IntPtr NativeMethodInfoPtr_FindCover_Public_Static_Void_byref_CoverPoint_Vector3_Vector3_Single_Faction_HumanoidAI_0;

		// Token: 0x0400D34D RID: 54093
		private static readonly IntPtr NativeMethodInfoPtr_ScoreNode_Private_Static_Single_NavigationNode_Vector3_Single_Single_Single_Vector3_0;

		// Token: 0x0400D34E RID: 54094
		private static readonly IntPtr NativeMethodInfoPtr_TooCloseToTeammate_Public_Static_Boolean_Vector3_Faction_HumanoidAI_0;

		// Token: 0x0400D34F RID: 54095
		private static readonly IntPtr NativeMethodInfoPtr_CheckCoverAtPoint_Private_Static_Single_Vector3_Vector3_0;

		// Token: 0x0400D350 RID: 54096
		private static readonly IntPtr NativeMethodInfoPtr_SightBlocked_Private_Static_Boolean_Vector3_Vector3_0;

		// Token: 0x0400D351 RID: 54097
		private static readonly IntPtr NativeMethodInfoPtr_DrawDebug_Private_Static_Void_Vector3_Vector3_Color_Single_0;
	}
}
