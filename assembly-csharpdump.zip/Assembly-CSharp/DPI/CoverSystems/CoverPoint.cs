﻿using System;
using Il2CppSystem;
using Onward.AI.Animations;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.CoverSystems
{
	// Token: 0x02001151 RID: 4433
	public class CoverPoint : Il2CppSystem.Object
	{
		// Token: 0x06014A77 RID: 84599 RVA: 0x00532658 File Offset: 0x00530858
		[CallerCount(0)]
		public unsafe CoverPoint() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverPoint.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A78 RID: 84600 RVA: 0x005326A4 File Offset: 0x005308A4
		// Note: this type is marked as 'beforefieldinit'.
		static CoverPoint()
		{
			Il2CppClassPointerStore<CoverPoint>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "CoverPoint");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr);
			CoverPoint.NativeFieldInfoPtr_Position = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr, "Position");
			CoverPoint.NativeFieldInfoPtr_Direction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr, "Direction");
			CoverPoint.NativeFieldInfoPtr_CoverType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr, "CoverType");
			CoverPoint.NativeFieldInfoPtr_FireType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr, "FireType");
			CoverPoint.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr, 100689663);
		}

		// Token: 0x06014A79 RID: 84601 RVA: 0x00002988 File Offset: 0x00000B88
		public CoverPoint(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074E6 RID: 29926
		// (get) Token: 0x06014A7A RID: 84602 RVA: 0x00532738 File Offset: 0x00530938
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverPoint>.NativeClassPtr));
			}
		}

		// Token: 0x170074E7 RID: 29927
		// (get) Token: 0x06014A7B RID: 84603 RVA: 0x0053274C File Offset: 0x0053094C
		// (set) Token: 0x06014A7C RID: 84604 RVA: 0x00532774 File Offset: 0x00530974
		public unsafe Vector3 Position
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_Position);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_Position)) = value;
			}
		}

		// Token: 0x170074E8 RID: 29928
		// (get) Token: 0x06014A7D RID: 84605 RVA: 0x00532798 File Offset: 0x00530998
		// (set) Token: 0x06014A7E RID: 84606 RVA: 0x005327C0 File Offset: 0x005309C0
		public unsafe Vector3 Direction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_Direction);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_Direction)) = value;
			}
		}

		// Token: 0x170074E9 RID: 29929
		// (get) Token: 0x06014A7F RID: 84607 RVA: 0x005327E4 File Offset: 0x005309E4
		// (set) Token: 0x06014A80 RID: 84608 RVA: 0x0053280C File Offset: 0x00530A0C
		public unsafe AnimationStanceTypes CoverType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_CoverType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_CoverType)) = value;
			}
		}

		// Token: 0x170074EA RID: 29930
		// (get) Token: 0x06014A81 RID: 84609 RVA: 0x00532830 File Offset: 0x00530A30
		// (set) Token: 0x06014A82 RID: 84610 RVA: 0x00532858 File Offset: 0x00530A58
		public unsafe AnimationStanceTypes FireType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_FireType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CoverPoint.NativeFieldInfoPtr_FireType)) = value;
			}
		}

		// Token: 0x0400D344 RID: 54084
		private static readonly IntPtr NativeFieldInfoPtr_Position;

		// Token: 0x0400D345 RID: 54085
		private static readonly IntPtr NativeFieldInfoPtr_Direction;

		// Token: 0x0400D346 RID: 54086
		private static readonly IntPtr NativeFieldInfoPtr_CoverType;

		// Token: 0x0400D347 RID: 54087
		private static readonly IntPtr NativeFieldInfoPtr_FireType;

		// Token: 0x0400D348 RID: 54088
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
