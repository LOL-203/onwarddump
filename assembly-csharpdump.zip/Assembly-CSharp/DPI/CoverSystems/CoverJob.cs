﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.CoverSystems
{
	// Token: 0x0200114E RID: 4430
	public class CoverJob : Object
	{
		// Token: 0x06014A31 RID: 84529 RVA: 0x005313E0 File Offset: 0x0052F5E0
		[CallerCount(0)]
		public unsafe void Execute()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A32 RID: 84530 RVA: 0x00531424 File Offset: 0x0052F624
		[CallerCount(0)]
		public unsafe CoverJob() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CoverJob>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CoverJob.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A33 RID: 84531 RVA: 0x00531470 File Offset: 0x0052F670
		// Note: this type is marked as 'beforefieldinit'.
		static CoverJob()
		{
			Il2CppClassPointerStore<CoverJob>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CoverSystems", "CoverJob");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CoverJob>.NativeClassPtr);
			CoverJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverJob>.NativeClassPtr, 100689643);
			CoverJob.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CoverJob>.NativeClassPtr, 100689644);
		}

		// Token: 0x06014A34 RID: 84532 RVA: 0x00002988 File Offset: 0x00000B88
		public CoverJob(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074CC RID: 29900
		// (get) Token: 0x06014A35 RID: 84533 RVA: 0x005314C8 File Offset: 0x0052F6C8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CoverJob>.NativeClassPtr));
			}
		}

		// Token: 0x0400D31C RID: 54044
		private static readonly IntPtr NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400D31D RID: 54045
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
