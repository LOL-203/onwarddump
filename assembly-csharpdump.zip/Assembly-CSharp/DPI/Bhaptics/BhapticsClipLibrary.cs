﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Bhaptics
{
	// Token: 0x02000FEF RID: 4079
	public static class BhapticsClipLibrary : Object
	{
		// Token: 0x06013895 RID: 80021 RVA: 0x004EA41C File Offset: 0x004E861C
		[CallerCount(0)]
		public unsafe static int GetClipKey(BhapticsClipType type, BhapticsDamageContext context, BhapticsClipIdentifier identifier)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref context;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref identifier;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipLibrary.NativeMethodInfoPtr_GetClipKey_Public_Static_Int32_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013896 RID: 80022 RVA: 0x004EA498 File Offset: 0x004E8698
		[CallerCount(0)]
		public unsafe static void Initialize()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipLibrary.NativeMethodInfoPtr_Initialize_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013897 RID: 80023 RVA: 0x004EA4CC File Offset: 0x004E86CC
		[CallerCount(0)]
		public unsafe static bool TryGetClip(BhapticsClipContext context, out BhapticsClipData clip)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(clip);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipLibrary.NativeMethodInfoPtr_TryGetClip_Public_Static_Boolean_BhapticsClipContext_byref_BhapticsClipData_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			clip = ((intPtr2 == 0) ? null : new BhapticsClipData(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013898 RID: 80024 RVA: 0x004EA558 File Offset: 0x004E8758
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsClipLibrary()
		{
			Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsClipLibrary");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr);
			BhapticsClipLibrary.NativeFieldInfoPtr__cache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr, "_cache");
			BhapticsClipLibrary.NativeMethodInfoPtr_GetClipKey_Public_Static_Int32_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr, 100688223);
			BhapticsClipLibrary.NativeMethodInfoPtr_Initialize_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr, 100688224);
			BhapticsClipLibrary.NativeMethodInfoPtr_TryGetClip_Public_Static_Boolean_BhapticsClipContext_byref_BhapticsClipData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr, 100688225);
		}

		// Token: 0x06013899 RID: 80025 RVA: 0x00002988 File Offset: 0x00000B88
		public BhapticsClipLibrary(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006ECA RID: 28362
		// (get) Token: 0x0601389A RID: 80026 RVA: 0x004EA5D8 File Offset: 0x004E87D8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipLibrary>.NativeClassPtr));
			}
		}

		// Token: 0x17006ECB RID: 28363
		// (get) Token: 0x0601389B RID: 80027 RVA: 0x004EA5EC File Offset: 0x004E87EC
		// (set) Token: 0x0601389C RID: 80028 RVA: 0x004EA617 File Offset: 0x004E8817
		public unsafe static Dictionary<int, BhapticsClipData> _cache
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BhapticsClipLibrary.NativeFieldInfoPtr__cache, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<int, BhapticsClipData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsClipLibrary.NativeFieldInfoPtr__cache, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C7BA RID: 51130
		private static readonly IntPtr NativeFieldInfoPtr__cache;

		// Token: 0x0400C7BB RID: 51131
		private static readonly IntPtr NativeMethodInfoPtr_GetClipKey_Public_Static_Int32_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0;

		// Token: 0x0400C7BC RID: 51132
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Static_Void_0;

		// Token: 0x0400C7BD RID: 51133
		private static readonly IntPtr NativeMethodInfoPtr_TryGetClip_Public_Static_Boolean_BhapticsClipContext_byref_BhapticsClipData_0;
	}
}
