﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF6 RID: 4086
	public class BhapticsVestBounds : MonoBehaviour
	{
		// Token: 0x17006EEA RID: 28394
		// (get) Token: 0x060138FB RID: 80123 RVA: 0x004EC2DC File Offset: 0x004EA4DC
		public unsafe Vector3 Position
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsVestBounds.NativeMethodInfoPtr_get_Position_Public_get_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17006EEB RID: 28395
		// (get) Token: 0x060138FC RID: 80124 RVA: 0x004EC32C File Offset: 0x004EA52C
		public unsafe Vector3 Forward
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsVestBounds.NativeMethodInfoPtr_get_Forward_Public_get_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17006EEC RID: 28396
		// (get) Token: 0x060138FD RID: 80125 RVA: 0x004EC37C File Offset: 0x004EA57C
		public unsafe float Height
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsVestBounds.NativeMethodInfoPtr_get_Height_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x060138FE RID: 80126 RVA: 0x004EC3CC File Offset: 0x004EA5CC
		[CallerCount(0)]
		public unsafe BhapticsVestBounds() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsVestBounds.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138FF RID: 80127 RVA: 0x004EC418 File Offset: 0x004EA618
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsVestBounds()
		{
			Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsVestBounds");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr);
			BhapticsVestBounds.NativeFieldInfoPtr_Bounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr, "Bounds");
			BhapticsVestBounds.NativeMethodInfoPtr_get_Position_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr, 100688271);
			BhapticsVestBounds.NativeMethodInfoPtr_get_Forward_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr, 100688272);
			BhapticsVestBounds.NativeMethodInfoPtr_get_Height_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr, 100688273);
			BhapticsVestBounds.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr, 100688274);
		}

		// Token: 0x06013900 RID: 80128 RVA: 0x0000210C File Offset: 0x0000030C
		public BhapticsVestBounds(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006EE8 RID: 28392
		// (get) Token: 0x06013901 RID: 80129 RVA: 0x004EC4AC File Offset: 0x004EA6AC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsVestBounds>.NativeClassPtr));
			}
		}

		// Token: 0x17006EE9 RID: 28393
		// (get) Token: 0x06013902 RID: 80130 RVA: 0x004EC4C0 File Offset: 0x004EA6C0
		// (set) Token: 0x06013903 RID: 80131 RVA: 0x004EC4E8 File Offset: 0x004EA6E8
		public unsafe Bounds Bounds
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsVestBounds.NativeFieldInfoPtr_Bounds);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsVestBounds.NativeFieldInfoPtr_Bounds)) = value;
			}
		}

		// Token: 0x0400C822 RID: 51234
		private static readonly IntPtr NativeFieldInfoPtr_Bounds;

		// Token: 0x0400C823 RID: 51235
		private static readonly IntPtr NativeMethodInfoPtr_get_Position_Public_get_Vector3_0;

		// Token: 0x0400C824 RID: 51236
		private static readonly IntPtr NativeMethodInfoPtr_get_Forward_Public_get_Vector3_0;

		// Token: 0x0400C825 RID: 51237
		private static readonly IntPtr NativeMethodInfoPtr_get_Height_Public_get_Single_0;

		// Token: 0x0400C826 RID: 51238
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
