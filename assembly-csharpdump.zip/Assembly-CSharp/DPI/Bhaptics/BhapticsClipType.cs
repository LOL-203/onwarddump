﻿using System;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF3 RID: 4083
	public enum BhapticsClipType
	{
		// Token: 0x0400C801 RID: 51201
		None,
		// Token: 0x0400C802 RID: 51202
		Vest,
		// Token: 0x0400C803 RID: 51203
		Head,
		// Token: 0x0400C804 RID: 51204
		LeftArm,
		// Token: 0x0400C805 RID: 51205
		RightArm,
		// Token: 0x0400C806 RID: 51206
		BothArms
	}
}
