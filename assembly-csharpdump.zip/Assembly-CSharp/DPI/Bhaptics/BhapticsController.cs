﻿using System;
using System.Runtime.InteropServices;
using Bhaptics.Tact.Unity;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using Onward.Utilities;
using Onward.Weapons;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF0 RID: 4080
	public class BhapticsController : PermissionFlagBehaviour
	{
		// Token: 0x17006EDC RID: 28380
		// (get) Token: 0x0601389D RID: 80029 RVA: 0x004EA62C File Offset: 0x004E882C
		// (set) Token: 0x0601389E RID: 80030 RVA: 0x004EA670 File Offset: 0x004E8870
		public unsafe static bool IsActive
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_get_IsActive_Public_Static_get_Boolean_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_set_IsActive_Private_Static_set_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17006EDD RID: 28381
		// (get) Token: 0x0601389F RID: 80031 RVA: 0x004EA6B8 File Offset: 0x004E88B8
		public unsafe static bool IsPlayerInstalled
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_get_IsPlayerInstalled_Public_Static_get_Boolean_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x060138A0 RID: 80032 RVA: 0x004EA6FC File Offset: 0x004E88FC
		[CallerCount(0)]
		public unsafe static void RefreshIsActive()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_RefreshIsActive_Private_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A1 RID: 80033 RVA: 0x004EA730 File Offset: 0x004E8930
		[CallerCount(0)]
		public new unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BhapticsController.NativeMethodInfoPtr_Initialize_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A2 RID: 80034 RVA: 0x004EA780 File Offset: 0x004E8980
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_OnDestroy_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A3 RID: 80035 RVA: 0x004EA7C4 File Offset: 0x004E89C4
		[CallerCount(0)]
		public unsafe void PostSetDefault(PermissionFlag flag)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(flag);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_PostSetDefault_Private_Void_PermissionFlag_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A4 RID: 80036 RVA: 0x004EA820 File Offset: 0x004E8A20
		[CallerCount(0)]
		public unsafe void SetActive(BhapticsActiveState newState)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newState;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_SetActive_Public_Void_BhapticsActiveState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A5 RID: 80037 RVA: 0x004EA874 File Offset: 0x004E8A74
		[CallerCount(0)]
		public unsafe BhapticsClipData GetClipData(BhapticsClipContext context)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetClipData_Public_BhapticsClipData_BhapticsClipContext_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new BhapticsClipData(intPtr2) : null;
		}

		// Token: 0x060138A6 RID: 80038 RVA: 0x004EA8DC File Offset: 0x004E8ADC
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipContext context)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A7 RID: 80039 RVA: 0x004EA930 File Offset: 0x004E8B30
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipContext context, Vector3 contactPos, Collider targetCollider)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref contactPos;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(targetCollider);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A8 RID: 80040 RVA: 0x004EA9B0 File Offset: 0x004E8BB0
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipContext context, RaycastHit hit)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hit;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_RaycastHit_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138A9 RID: 80041 RVA: 0x004EAA18 File Offset: 0x004E8C18
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipContext context, Vector3 contactPosDirectional, Vector3 contactPosPositional, Vector3 targetPos, Vector3 targetForward, float targetHeight)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref contactPosDirectional;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref contactPosPositional;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetPos;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetForward;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref targetHeight;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Vector3_Vector3_Vector3_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AA RID: 80042 RVA: 0x004EAACC File Offset: 0x004E8CCC
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipContext context, float angleX, float offsetY)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref context;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angleX;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AB RID: 80043 RVA: 0x004EAB48 File Offset: 0x004E8D48
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipData data, float angleX, float offsetY)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angleX;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AC RID: 80044 RVA: 0x004EABC8 File Offset: 0x004E8DC8
		[CallerCount(0)]
		public unsafe void Play(BhapticsClipData data, float angleX, float offsetY, float intensityNormalized, float durationNormalized)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angleX;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref offsetY;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensityNormalized;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref durationNormalized;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AD RID: 80045 RVA: 0x004EAC70 File Offset: 0x004E8E70
		[CallerCount(0)]
		public unsafe void GetStabbed(WarPlayerScript wps, BodyParts damagedPart, DamageType damageType, Vector3 hitPosition)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(wps);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damagedPart;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref damageType;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hitPosition;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetStabbed_Public_Void_WarPlayerScript_BodyParts_DamageType_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AE RID: 80046 RVA: 0x004EAD04 File Offset: 0x004E8F04
		[CallerCount(0)]
		public unsafe void GetShot(DamageBody body, Collider hitCollider, Vector3 hitPointDirectional, Vector3 hitPointPositional, WeaponType firingWeaponType, WeaponName firingWeaponName, Firemode firingWeaponMode, bool armorPiercing)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)8) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(body);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(hitCollider);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hitPointDirectional;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref hitPointPositional;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref firingWeaponType;
			ptr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref firingWeaponName;
			ptr[checked(unchecked((UIntPtr)6) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref firingWeaponMode;
			ptr[checked(unchecked((UIntPtr)7) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref armorPiercing;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetShot_Public_Void_DamageBody_Collider_Vector3_Vector3_WeaponType_WeaponName_Firemode_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138AF RID: 80047 RVA: 0x004EADE8 File Offset: 0x004E8FE8
		[CallerCount(0)]
		public unsafe void DoShot(Pickup_Gun gun, WeaponType firingWeaponType, WeaponName firingWeaponName, bool kickChest = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(gun);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref firingWeaponType;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref firingWeaponName;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref kickChest;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_DoShot_Public_Void_Pickup_Gun_WeaponType_WeaponName_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B0 RID: 80048 RVA: 0x004EAE7C File Offset: 0x004E907C
		[CallerCount(0)]
		public unsafe void DoTase()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_DoTase_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B1 RID: 80049 RVA: 0x004EAEC0 File Offset: 0x004E90C0
		[CallerCount(0)]
		public unsafe void DoArmEffect(InputGlobal.Hand arm, BhapticsDamageContext context, BhapticsKeyword effect, [Optional] float intensity, [Optional] float duration)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref arm;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref context;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref effect;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensity;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_DoArmEffect_Public_Void_Hand_BhapticsDamageContext_BhapticsKeyword_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B2 RID: 80050 RVA: 0x004EAF60 File Offset: 0x004E9160
		[CallerCount(0)]
		public unsafe void DoShotgunBlast(Pickup_Gun gun)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(gun);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_DoShotgunBlast_Public_Void_Pickup_Gun_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B3 RID: 80051 RVA: 0x004EAFBC File Offset: 0x004E91BC
		[CallerCount(0)]
		public unsafe void DoExplosion(BhapticsKeyword explosionKeyword, Vector3 explosionPosition, float explosionRadius)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref explosionKeyword;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref explosionPosition;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref explosionRadius;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_DoExplosion_Public_Void_BhapticsKeyword_Vector3_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B4 RID: 80052 RVA: 0x004EB038 File Offset: 0x004E9238
		[CallerCount(0)]
		public unsafe BhapticsClipContext GetGunFiringContext(WeaponType weaponType, WeaponName weaponName, BhapticsClipType side, bool isSuppressed)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref weaponType;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref weaponName;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref side;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isSuppressed;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetGunFiringContext_Public_BhapticsClipContext_WeaponType_WeaponName_BhapticsClipType_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060138B5 RID: 80053 RVA: 0x004EB0D4 File Offset: 0x004E92D4
		[CallerCount(0)]
		public unsafe float GetNormalizedExplosionIntensity(Vector3 playerPosition, Vector3 explosionPosition, float radius)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref playerPosition;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref explosionPosition;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref radius;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetNormalizedExplosionIntensity_Private_Single_Vector3_Vector3_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060138B6 RID: 80054 RVA: 0x004EB15C File Offset: 0x004E935C
		[CallerCount(0)]
		public unsafe void FlushContexts(float vestAngleX, float vestOffsetY, float intensity, float duration)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref vestAngleX;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vestOffsetY;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref intensity;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_FlushContexts_Private_Void_Single_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138B7 RID: 80055 RVA: 0x004EB1EC File Offset: 0x004E93EC
		[CallerCount(0)]
		public unsafe BhapticsClipType HandToClipType(InputGlobal.Hand hand)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref hand;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_HandToClipType_Private_BhapticsClipType_Hand_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060138B8 RID: 80056 RVA: 0x004EB250 File Offset: 0x004E9450
		[CallerCount(0)]
		public unsafe BhapticsClipContext GetChestKickContext(InputGlobal.Hand hand)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref hand;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetChestKickContext_Private_BhapticsClipContext_Hand_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060138B9 RID: 80057 RVA: 0x004EB2B4 File Offset: 0x004E94B4
		[CallerCount(0)]
		public unsafe void StartAPI()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_StartAPI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BA RID: 80058 RVA: 0x004EB2F8 File Offset: 0x004E94F8
		[CallerCount(0)]
		public unsafe void StopAPI()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_StopAPI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BB RID: 80059 RVA: 0x004EB33C File Offset: 0x004E953C
		[CallerCount(0)]
		public unsafe void SwapArms()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_SwapArms_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BC RID: 80060 RVA: 0x004EB380 File Offset: 0x004E9580
		[CallerCount(0)]
		public unsafe void WaitForAndroidDeviceUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_WaitForAndroidDeviceUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BD RID: 80061 RVA: 0x004EB3C4 File Offset: 0x004E95C4
		[CallerCount(0)]
		public unsafe void OnAndroidDeviceUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_OnAndroidDeviceUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BE RID: 80062 RVA: 0x004EB408 File Offset: 0x004E9608
		[CallerCount(0)]
		public unsafe void StartInitializationClips()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_StartInitializationClips_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138BF RID: 80063 RVA: 0x004EB44C File Offset: 0x004E964C
		[CallerCount(0)]
		public unsafe void StopInitializationClips()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_StopInitializationClips_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138C0 RID: 80064 RVA: 0x004EB490 File Offset: 0x004E9690
		[CallerCount(0)]
		public unsafe bool GetCanInitializationClipsPlay()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_GetCanInitializationClipsPlay_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060138C1 RID: 80065 RVA: 0x004EB4E0 File Offset: 0x004E96E0
		[CallerCount(0)]
		public unsafe IEnumerator InitializationClipsRoutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr_InitializationClipsRoutine_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x060138C2 RID: 80066 RVA: 0x004EB538 File Offset: 0x004E9738
		[CallerCount(0)]
		public unsafe BhapticsController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060138C3 RID: 80067 RVA: 0x004EB584 File Offset: 0x004E9784
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsController()
		{
			Il2CppClassPointerStore<BhapticsController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsController");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr);
			BhapticsController.NativeFieldInfoPtr__IsActive_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "<IsActive>k__BackingField");
			BhapticsController.NativeFieldInfoPtr_Singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "Singleton");
			BhapticsController.NativeFieldInfoPtr_INITIALIZATION_TIME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "INITIALIZATION_TIME");
			BhapticsController.NativeFieldInfoPtr_EXPLOSION_MAX_HEIGHT_OFFSET = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "EXPLOSION_MAX_HEIGHT_OFFSET");
			BhapticsController.NativeFieldInfoPtr_Config = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "Config");
			BhapticsController.NativeFieldInfoPtr_InitializationClipData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "InitializationClipData");
			BhapticsController.NativeFieldInfoPtr_YMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "YMultiplier");
			BhapticsController.NativeFieldInfoPtr__androidManager = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_androidManager");
			BhapticsController.NativeFieldInfoPtr__initializationClipsCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_initializationClipsCoroutine");
			BhapticsController.NativeFieldInfoPtr__activeState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_activeState");
			BhapticsController.NativeFieldInfoPtr__startedAPI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_startedAPI");
			BhapticsController.NativeFieldInfoPtr__setupLibrary = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_setupLibrary");
			BhapticsController.NativeFieldInfoPtr__receivedAndroidDeviceUpdate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_receivedAndroidDeviceUpdate");
			BhapticsController.NativeFieldInfoPtr__accumulatedInitializationTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_accumulatedInitializationTime");
			BhapticsController.NativeFieldInfoPtr__contexts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "_contexts");
			BhapticsController.NativeMethodInfoPtr_get_IsActive_Public_Static_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688227);
			BhapticsController.NativeMethodInfoPtr_set_IsActive_Private_Static_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688228);
			BhapticsController.NativeMethodInfoPtr_get_IsPlayerInstalled_Public_Static_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688229);
			BhapticsController.NativeMethodInfoPtr_RefreshIsActive_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688230);
			BhapticsController.NativeMethodInfoPtr_Initialize_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688231);
			BhapticsController.NativeMethodInfoPtr_OnDestroy_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688232);
			BhapticsController.NativeMethodInfoPtr_PostSetDefault_Private_Void_PermissionFlag_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688233);
			BhapticsController.NativeMethodInfoPtr_SetActive_Public_Void_BhapticsActiveState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688234);
			BhapticsController.NativeMethodInfoPtr_GetClipData_Public_BhapticsClipData_BhapticsClipContext_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688235);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688236);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688237);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_RaycastHit_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688238);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Vector3_Vector3_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688239);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688240);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688241);
			BhapticsController.NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688242);
			BhapticsController.NativeMethodInfoPtr_GetStabbed_Public_Void_WarPlayerScript_BodyParts_DamageType_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688243);
			BhapticsController.NativeMethodInfoPtr_GetShot_Public_Void_DamageBody_Collider_Vector3_Vector3_WeaponType_WeaponName_Firemode_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688244);
			BhapticsController.NativeMethodInfoPtr_DoShot_Public_Void_Pickup_Gun_WeaponType_WeaponName_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688245);
			BhapticsController.NativeMethodInfoPtr_DoTase_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688246);
			BhapticsController.NativeMethodInfoPtr_DoArmEffect_Public_Void_Hand_BhapticsDamageContext_BhapticsKeyword_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688247);
			BhapticsController.NativeMethodInfoPtr_DoShotgunBlast_Public_Void_Pickup_Gun_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688248);
			BhapticsController.NativeMethodInfoPtr_DoExplosion_Public_Void_BhapticsKeyword_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688249);
			BhapticsController.NativeMethodInfoPtr_GetGunFiringContext_Public_BhapticsClipContext_WeaponType_WeaponName_BhapticsClipType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688250);
			BhapticsController.NativeMethodInfoPtr_GetNormalizedExplosionIntensity_Private_Single_Vector3_Vector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688251);
			BhapticsController.NativeMethodInfoPtr_FlushContexts_Private_Void_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688252);
			BhapticsController.NativeMethodInfoPtr_HandToClipType_Private_BhapticsClipType_Hand_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688253);
			BhapticsController.NativeMethodInfoPtr_GetChestKickContext_Private_BhapticsClipContext_Hand_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688254);
			BhapticsController.NativeMethodInfoPtr_StartAPI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688255);
			BhapticsController.NativeMethodInfoPtr_StopAPI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688256);
			BhapticsController.NativeMethodInfoPtr_SwapArms_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688257);
			BhapticsController.NativeMethodInfoPtr_WaitForAndroidDeviceUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688258);
			BhapticsController.NativeMethodInfoPtr_OnAndroidDeviceUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688259);
			BhapticsController.NativeMethodInfoPtr_StartInitializationClips_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688260);
			BhapticsController.NativeMethodInfoPtr_StopInitializationClips_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688261);
			BhapticsController.NativeMethodInfoPtr_GetCanInitializationClipsPlay_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688262);
			BhapticsController.NativeMethodInfoPtr_InitializationClipsRoutine_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688263);
			BhapticsController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, 100688264);
		}

		// Token: 0x060138C4 RID: 80068 RVA: 0x0008F028 File Offset: 0x0008D228
		public BhapticsController(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006ECC RID: 28364
		// (get) Token: 0x060138C5 RID: 80069 RVA: 0x004EB9D8 File Offset: 0x004E9BD8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr));
			}
		}

		// Token: 0x17006ECD RID: 28365
		// (get) Token: 0x060138C6 RID: 80070 RVA: 0x004EB9EC File Offset: 0x004E9BEC
		// (set) Token: 0x060138C7 RID: 80071 RVA: 0x004EBA0A File Offset: 0x004E9C0A
		public unsafe static bool _IsActive_k__BackingField
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsController.NativeFieldInfoPtr__IsActive_k__BackingField, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsController.NativeFieldInfoPtr__IsActive_k__BackingField, (void*)(&value));
			}
		}

		// Token: 0x17006ECE RID: 28366
		// (get) Token: 0x060138C8 RID: 80072 RVA: 0x004EBA1C File Offset: 0x004E9C1C
		// (set) Token: 0x060138C9 RID: 80073 RVA: 0x004EBA47 File Offset: 0x004E9C47
		public unsafe static BhapticsController Singleton
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BhapticsController.NativeFieldInfoPtr_Singleton, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new BhapticsController(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsController.NativeFieldInfoPtr_Singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006ECF RID: 28367
		// (get) Token: 0x060138CA RID: 80074 RVA: 0x004EBA5C File Offset: 0x004E9C5C
		// (set) Token: 0x060138CB RID: 80075 RVA: 0x004EBA7A File Offset: 0x004E9C7A
		public unsafe static float INITIALIZATION_TIME
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsController.NativeFieldInfoPtr_INITIALIZATION_TIME, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsController.NativeFieldInfoPtr_INITIALIZATION_TIME, (void*)(&value));
			}
		}

		// Token: 0x17006ED0 RID: 28368
		// (get) Token: 0x060138CC RID: 80076 RVA: 0x004EBA8C File Offset: 0x004E9C8C
		// (set) Token: 0x060138CD RID: 80077 RVA: 0x004EBAAA File Offset: 0x004E9CAA
		public unsafe static float EXPLOSION_MAX_HEIGHT_OFFSET
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsController.NativeFieldInfoPtr_EXPLOSION_MAX_HEIGHT_OFFSET, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsController.NativeFieldInfoPtr_EXPLOSION_MAX_HEIGHT_OFFSET, (void*)(&value));
			}
		}

		// Token: 0x17006ED1 RID: 28369
		// (get) Token: 0x060138CE RID: 80078 RVA: 0x004EBABC File Offset: 0x004E9CBC
		// (set) Token: 0x060138CF RID: 80079 RVA: 0x004EBAF0 File Offset: 0x004E9CF0
		public unsafe BhapticsConfig Config
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_Config);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BhapticsConfig(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_Config), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006ED2 RID: 28370
		// (get) Token: 0x060138D0 RID: 80080 RVA: 0x004EBB18 File Offset: 0x004E9D18
		// (set) Token: 0x060138D1 RID: 80081 RVA: 0x004EBB4C File Offset: 0x004E9D4C
		public unsafe Il2CppReferenceArray<BhapticsClipData> InitializationClipData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_InitializationClipData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<BhapticsClipData>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_InitializationClipData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006ED3 RID: 28371
		// (get) Token: 0x060138D2 RID: 80082 RVA: 0x004EBB74 File Offset: 0x004E9D74
		// (set) Token: 0x060138D3 RID: 80083 RVA: 0x004EBB9C File Offset: 0x004E9D9C
		public unsafe float YMultiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_YMultiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr_YMultiplier)) = value;
			}
		}

		// Token: 0x17006ED4 RID: 28372
		// (get) Token: 0x060138D4 RID: 80084 RVA: 0x004EBBC0 File Offset: 0x004E9DC0
		// (set) Token: 0x060138D5 RID: 80085 RVA: 0x004EBBF4 File Offset: 0x004E9DF4
		public unsafe BhapticsAndroidManager _androidManager
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__androidManager);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BhapticsAndroidManager(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__androidManager), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006ED5 RID: 28373
		// (get) Token: 0x060138D6 RID: 80086 RVA: 0x004EBC1C File Offset: 0x004E9E1C
		// (set) Token: 0x060138D7 RID: 80087 RVA: 0x004EBC50 File Offset: 0x004E9E50
		public unsafe Coroutine _initializationClipsCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__initializationClipsCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__initializationClipsCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006ED6 RID: 28374
		// (get) Token: 0x060138D8 RID: 80088 RVA: 0x004EBC78 File Offset: 0x004E9E78
		// (set) Token: 0x060138D9 RID: 80089 RVA: 0x004EBCA0 File Offset: 0x004E9EA0
		public unsafe BhapticsActiveState _activeState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__activeState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__activeState)) = value;
			}
		}

		// Token: 0x17006ED7 RID: 28375
		// (get) Token: 0x060138DA RID: 80090 RVA: 0x004EBCC4 File Offset: 0x004E9EC4
		// (set) Token: 0x060138DB RID: 80091 RVA: 0x004EBCEC File Offset: 0x004E9EEC
		public unsafe bool _startedAPI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__startedAPI);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__startedAPI)) = value;
			}
		}

		// Token: 0x17006ED8 RID: 28376
		// (get) Token: 0x060138DC RID: 80092 RVA: 0x004EBD10 File Offset: 0x004E9F10
		// (set) Token: 0x060138DD RID: 80093 RVA: 0x004EBD38 File Offset: 0x004E9F38
		public unsafe bool _setupLibrary
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__setupLibrary);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__setupLibrary)) = value;
			}
		}

		// Token: 0x17006ED9 RID: 28377
		// (get) Token: 0x060138DE RID: 80094 RVA: 0x004EBD5C File Offset: 0x004E9F5C
		// (set) Token: 0x060138DF RID: 80095 RVA: 0x004EBD84 File Offset: 0x004E9F84
		public unsafe bool _receivedAndroidDeviceUpdate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__receivedAndroidDeviceUpdate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__receivedAndroidDeviceUpdate)) = value;
			}
		}

		// Token: 0x17006EDA RID: 28378
		// (get) Token: 0x060138E0 RID: 80096 RVA: 0x004EBDA8 File Offset: 0x004E9FA8
		// (set) Token: 0x060138E1 RID: 80097 RVA: 0x004EBDD0 File Offset: 0x004E9FD0
		public unsafe float _accumulatedInitializationTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__accumulatedInitializationTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__accumulatedInitializationTime)) = value;
			}
		}

		// Token: 0x17006EDB RID: 28379
		// (get) Token: 0x060138E2 RID: 80098 RVA: 0x004EBDF4 File Offset: 0x004E9FF4
		// (set) Token: 0x060138E3 RID: 80099 RVA: 0x004EBE28 File Offset: 0x004EA028
		public unsafe List<BhapticsClipContext> _contexts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__contexts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<BhapticsClipContext>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController.NativeFieldInfoPtr__contexts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C7BE RID: 51134
		private static readonly IntPtr NativeFieldInfoPtr__IsActive_k__BackingField;

		// Token: 0x0400C7BF RID: 51135
		private static readonly IntPtr NativeFieldInfoPtr_Singleton;

		// Token: 0x0400C7C0 RID: 51136
		private static readonly IntPtr NativeFieldInfoPtr_INITIALIZATION_TIME;

		// Token: 0x0400C7C1 RID: 51137
		private static readonly IntPtr NativeFieldInfoPtr_EXPLOSION_MAX_HEIGHT_OFFSET;

		// Token: 0x0400C7C2 RID: 51138
		private static readonly IntPtr NativeFieldInfoPtr_Config;

		// Token: 0x0400C7C3 RID: 51139
		private static readonly IntPtr NativeFieldInfoPtr_InitializationClipData;

		// Token: 0x0400C7C4 RID: 51140
		private static readonly IntPtr NativeFieldInfoPtr_YMultiplier;

		// Token: 0x0400C7C5 RID: 51141
		private static readonly IntPtr NativeFieldInfoPtr__androidManager;

		// Token: 0x0400C7C6 RID: 51142
		private static readonly IntPtr NativeFieldInfoPtr__initializationClipsCoroutine;

		// Token: 0x0400C7C7 RID: 51143
		private static readonly IntPtr NativeFieldInfoPtr__activeState;

		// Token: 0x0400C7C8 RID: 51144
		private static readonly IntPtr NativeFieldInfoPtr__startedAPI;

		// Token: 0x0400C7C9 RID: 51145
		private static readonly IntPtr NativeFieldInfoPtr__setupLibrary;

		// Token: 0x0400C7CA RID: 51146
		private static readonly IntPtr NativeFieldInfoPtr__receivedAndroidDeviceUpdate;

		// Token: 0x0400C7CB RID: 51147
		private static readonly IntPtr NativeFieldInfoPtr__accumulatedInitializationTime;

		// Token: 0x0400C7CC RID: 51148
		private static readonly IntPtr NativeFieldInfoPtr__contexts;

		// Token: 0x0400C7CD RID: 51149
		private static readonly IntPtr NativeMethodInfoPtr_get_IsActive_Public_Static_get_Boolean_0;

		// Token: 0x0400C7CE RID: 51150
		private static readonly IntPtr NativeMethodInfoPtr_set_IsActive_Private_Static_set_Void_Boolean_0;

		// Token: 0x0400C7CF RID: 51151
		private static readonly IntPtr NativeMethodInfoPtr_get_IsPlayerInstalled_Public_Static_get_Boolean_0;

		// Token: 0x0400C7D0 RID: 51152
		private static readonly IntPtr NativeMethodInfoPtr_RefreshIsActive_Private_Static_Void_0;

		// Token: 0x0400C7D1 RID: 51153
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Protected_Virtual_Void_0;

		// Token: 0x0400C7D2 RID: 51154
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Void_0;

		// Token: 0x0400C7D3 RID: 51155
		private static readonly IntPtr NativeMethodInfoPtr_PostSetDefault_Private_Void_PermissionFlag_0;

		// Token: 0x0400C7D4 RID: 51156
		private static readonly IntPtr NativeMethodInfoPtr_SetActive_Public_Void_BhapticsActiveState_0;

		// Token: 0x0400C7D5 RID: 51157
		private static readonly IntPtr NativeMethodInfoPtr_GetClipData_Public_BhapticsClipData_BhapticsClipContext_0;

		// Token: 0x0400C7D6 RID: 51158
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_0;

		// Token: 0x0400C7D7 RID: 51159
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Collider_0;

		// Token: 0x0400C7D8 RID: 51160
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_RaycastHit_0;

		// Token: 0x0400C7D9 RID: 51161
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Vector3_Vector3_Vector3_Vector3_Single_0;

		// Token: 0x0400C7DA RID: 51162
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipContext_Single_Single_0;

		// Token: 0x0400C7DB RID: 51163
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_0;

		// Token: 0x0400C7DC RID: 51164
		private static readonly IntPtr NativeMethodInfoPtr_Play_Public_Void_BhapticsClipData_Single_Single_Single_Single_0;

		// Token: 0x0400C7DD RID: 51165
		private static readonly IntPtr NativeMethodInfoPtr_GetStabbed_Public_Void_WarPlayerScript_BodyParts_DamageType_Vector3_0;

		// Token: 0x0400C7DE RID: 51166
		private static readonly IntPtr NativeMethodInfoPtr_GetShot_Public_Void_DamageBody_Collider_Vector3_Vector3_WeaponType_WeaponName_Firemode_Boolean_0;

		// Token: 0x0400C7DF RID: 51167
		private static readonly IntPtr NativeMethodInfoPtr_DoShot_Public_Void_Pickup_Gun_WeaponType_WeaponName_Boolean_0;

		// Token: 0x0400C7E0 RID: 51168
		private static readonly IntPtr NativeMethodInfoPtr_DoTase_Public_Void_0;

		// Token: 0x0400C7E1 RID: 51169
		private static readonly IntPtr NativeMethodInfoPtr_DoArmEffect_Public_Void_Hand_BhapticsDamageContext_BhapticsKeyword_Single_Single_0;

		// Token: 0x0400C7E2 RID: 51170
		private static readonly IntPtr NativeMethodInfoPtr_DoShotgunBlast_Public_Void_Pickup_Gun_0;

		// Token: 0x0400C7E3 RID: 51171
		private static readonly IntPtr NativeMethodInfoPtr_DoExplosion_Public_Void_BhapticsKeyword_Vector3_Single_0;

		// Token: 0x0400C7E4 RID: 51172
		private static readonly IntPtr NativeMethodInfoPtr_GetGunFiringContext_Public_BhapticsClipContext_WeaponType_WeaponName_BhapticsClipType_Boolean_0;

		// Token: 0x0400C7E5 RID: 51173
		private static readonly IntPtr NativeMethodInfoPtr_GetNormalizedExplosionIntensity_Private_Single_Vector3_Vector3_Single_0;

		// Token: 0x0400C7E6 RID: 51174
		private static readonly IntPtr NativeMethodInfoPtr_FlushContexts_Private_Void_Single_Single_Single_Single_0;

		// Token: 0x0400C7E7 RID: 51175
		private static readonly IntPtr NativeMethodInfoPtr_HandToClipType_Private_BhapticsClipType_Hand_0;

		// Token: 0x0400C7E8 RID: 51176
		private static readonly IntPtr NativeMethodInfoPtr_GetChestKickContext_Private_BhapticsClipContext_Hand_0;

		// Token: 0x0400C7E9 RID: 51177
		private static readonly IntPtr NativeMethodInfoPtr_StartAPI_Private_Void_0;

		// Token: 0x0400C7EA RID: 51178
		private static readonly IntPtr NativeMethodInfoPtr_StopAPI_Private_Void_0;

		// Token: 0x0400C7EB RID: 51179
		private static readonly IntPtr NativeMethodInfoPtr_SwapArms_Public_Void_0;

		// Token: 0x0400C7EC RID: 51180
		private static readonly IntPtr NativeMethodInfoPtr_WaitForAndroidDeviceUpdate_Private_Void_0;

		// Token: 0x0400C7ED RID: 51181
		private static readonly IntPtr NativeMethodInfoPtr_OnAndroidDeviceUpdate_Private_Void_0;

		// Token: 0x0400C7EE RID: 51182
		private static readonly IntPtr NativeMethodInfoPtr_StartInitializationClips_Private_Void_0;

		// Token: 0x0400C7EF RID: 51183
		private static readonly IntPtr NativeMethodInfoPtr_StopInitializationClips_Private_Void_0;

		// Token: 0x0400C7F0 RID: 51184
		private static readonly IntPtr NativeMethodInfoPtr_GetCanInitializationClipsPlay_Private_Boolean_0;

		// Token: 0x0400C7F1 RID: 51185
		private static readonly IntPtr NativeMethodInfoPtr_InitializationClipsRoutine_Private_IEnumerator_0;

		// Token: 0x0400C7F2 RID: 51186
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000FF1 RID: 4081
		[ObfuscatedName("DPI.Bhaptics.BhapticsController/<InitializationClipsRoutine>d__53")]
		public sealed class _InitializationClipsRoutine_d__53 : Il2CppSystem.Object
		{
			// Token: 0x060138E4 RID: 80100 RVA: 0x004EBE50 File Offset: 0x004EA050
			[CallerCount(0)]
			public unsafe _InitializationClipsRoutine_d__53(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x060138E5 RID: 80101 RVA: 0x004EBEB0 File Offset: 0x004EA0B0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x060138E6 RID: 80102 RVA: 0x004EBEF4 File Offset: 0x004EA0F4
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006EE2 RID: 28386
			// (get) Token: 0x060138E7 RID: 80103 RVA: 0x004EBF44 File Offset: 0x004EA144
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x060138E8 RID: 80104 RVA: 0x004EBF9C File Offset: 0x004EA19C
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006EE3 RID: 28387
			// (get) Token: 0x060138E9 RID: 80105 RVA: 0x004EBFE0 File Offset: 0x004EA1E0
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x060138EA RID: 80106 RVA: 0x004EC038 File Offset: 0x004EA238
			// Note: this type is marked as 'beforefieldinit'.
			static _InitializationClipsRoutine_d__53()
			{
				Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BhapticsController>.NativeClassPtr, "<InitializationClipsRoutine>d__53");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr);
				BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, "<>1__state");
				BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, "<>2__current");
				BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, "<>4__this");
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688265);
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688266);
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688267);
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688268);
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688269);
				BhapticsController._InitializationClipsRoutine_d__53.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr, 100688270);
			}

			// Token: 0x060138EB RID: 80107 RVA: 0x00002988 File Offset: 0x00000B88
			public _InitializationClipsRoutine_d__53(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006EDE RID: 28382
			// (get) Token: 0x060138EC RID: 80108 RVA: 0x004EC117 File Offset: 0x004EA317
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsController._InitializationClipsRoutine_d__53>.NativeClassPtr));
				}
			}

			// Token: 0x17006EDF RID: 28383
			// (get) Token: 0x060138ED RID: 80109 RVA: 0x004EC128 File Offset: 0x004EA328
			// (set) Token: 0x060138EE RID: 80110 RVA: 0x004EC150 File Offset: 0x004EA350
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006EE0 RID: 28384
			// (get) Token: 0x060138EF RID: 80111 RVA: 0x004EC174 File Offset: 0x004EA374
			// (set) Token: 0x060138F0 RID: 80112 RVA: 0x004EC1A8 File Offset: 0x004EA3A8
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EE1 RID: 28385
			// (get) Token: 0x060138F1 RID: 80113 RVA: 0x004EC1D0 File Offset: 0x004EA3D0
			// (set) Token: 0x060138F2 RID: 80114 RVA: 0x004EC204 File Offset: 0x004EA404
			public unsafe BhapticsController __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BhapticsController(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsController._InitializationClipsRoutine_d__53.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C7F3 RID: 51187
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C7F4 RID: 51188
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C7F5 RID: 51189
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C7F6 RID: 51190
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C7F7 RID: 51191
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C7F8 RID: 51192
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C7F9 RID: 51193
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C7FA RID: 51194
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C7FB RID: 51195
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
