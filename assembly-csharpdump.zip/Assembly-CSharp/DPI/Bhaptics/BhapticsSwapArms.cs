﻿using System;
using DPI.Async;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF7 RID: 4087
	public class BhapticsSwapArms : MonoBehaviour
	{
		// Token: 0x06013904 RID: 80132 RVA: 0x004EC50C File Offset: 0x004EA70C
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013905 RID: 80133 RVA: 0x004EC550 File Offset: 0x004EA750
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013906 RID: 80134 RVA: 0x004EC594 File Offset: 0x004EA794
		[CallerCount(0)]
		public unsafe void OnClicked()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_OnClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013907 RID: 80135 RVA: 0x004EC5D8 File Offset: 0x004EA7D8
		[CallerCount(0)]
		public unsafe void SetState(AsyncProcessState newState)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newState;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_SetState_Private_Void_AsyncProcessState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013908 RID: 80136 RVA: 0x004EC62C File Offset: 0x004EA82C
		[CallerCount(0)]
		public unsafe void StopSwapRoutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_StopSwapRoutine_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013909 RID: 80137 RVA: 0x004EC670 File Offset: 0x004EA870
		[CallerCount(0)]
		public unsafe void StartSwapRoutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_StartSwapRoutine_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601390A RID: 80138 RVA: 0x004EC6B4 File Offset: 0x004EA8B4
		[CallerCount(0)]
		public unsafe IEnumerator SwapRoutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_SwapRoutine_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0601390B RID: 80139 RVA: 0x004EC70C File Offset: 0x004EA90C
		[CallerCount(0)]
		public unsafe void SetButtonDisabled(bool disabled)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref disabled;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_SetButtonDisabled_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601390C RID: 80140 RVA: 0x004EC760 File Offset: 0x004EA960
		[CallerCount(0)]
		public unsafe void StopClip(BhapticsClipData data)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr_StopClip_Private_Void_BhapticsClipData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601390D RID: 80141 RVA: 0x004EC7BC File Offset: 0x004EA9BC
		[CallerCount(0)]
		public unsafe BhapticsSwapArms() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601390E RID: 80142 RVA: 0x004EC808 File Offset: 0x004EAA08
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsSwapArms()
		{
			Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsSwapArms");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr);
			BhapticsSwapArms.NativeFieldInfoPtr__mip = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "_mip");
			BhapticsSwapArms.NativeFieldInfoPtr__leftData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "_leftData");
			BhapticsSwapArms.NativeFieldInfoPtr__rightData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "_rightData");
			BhapticsSwapArms.NativeFieldInfoPtr__swapCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "_swapCoroutine");
			BhapticsSwapArms.NativeFieldInfoPtr__effectState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "_effectState");
			BhapticsSwapArms.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688275);
			BhapticsSwapArms.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688276);
			BhapticsSwapArms.NativeMethodInfoPtr_OnClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688277);
			BhapticsSwapArms.NativeMethodInfoPtr_SetState_Private_Void_AsyncProcessState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688278);
			BhapticsSwapArms.NativeMethodInfoPtr_StopSwapRoutine_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688279);
			BhapticsSwapArms.NativeMethodInfoPtr_StartSwapRoutine_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688280);
			BhapticsSwapArms.NativeMethodInfoPtr_SwapRoutine_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688281);
			BhapticsSwapArms.NativeMethodInfoPtr_SetButtonDisabled_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688282);
			BhapticsSwapArms.NativeMethodInfoPtr_StopClip_Private_Void_BhapticsClipData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688283);
			BhapticsSwapArms.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, 100688284);
		}

		// Token: 0x0601390F RID: 80143 RVA: 0x0000210C File Offset: 0x0000030C
		public BhapticsSwapArms(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006EED RID: 28397
		// (get) Token: 0x06013910 RID: 80144 RVA: 0x004EC964 File Offset: 0x004EAB64
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr));
			}
		}

		// Token: 0x17006EEE RID: 28398
		// (get) Token: 0x06013911 RID: 80145 RVA: 0x004EC978 File Offset: 0x004EAB78
		// (set) Token: 0x06013912 RID: 80146 RVA: 0x004EC9AC File Offset: 0x004EABAC
		public unsafe MenuItemPopout _mip
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__mip);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__mip), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EEF RID: 28399
		// (get) Token: 0x06013913 RID: 80147 RVA: 0x004EC9D4 File Offset: 0x004EABD4
		// (set) Token: 0x06013914 RID: 80148 RVA: 0x004ECA08 File Offset: 0x004EAC08
		public unsafe BhapticsClipData _leftData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__leftData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BhapticsClipData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__leftData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EF0 RID: 28400
		// (get) Token: 0x06013915 RID: 80149 RVA: 0x004ECA30 File Offset: 0x004EAC30
		// (set) Token: 0x06013916 RID: 80150 RVA: 0x004ECA64 File Offset: 0x004EAC64
		public unsafe BhapticsClipData _rightData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__rightData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BhapticsClipData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__rightData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EF1 RID: 28401
		// (get) Token: 0x06013917 RID: 80151 RVA: 0x004ECA8C File Offset: 0x004EAC8C
		// (set) Token: 0x06013918 RID: 80152 RVA: 0x004ECAC0 File Offset: 0x004EACC0
		public unsafe Coroutine _swapCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__swapCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__swapCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EF2 RID: 28402
		// (get) Token: 0x06013919 RID: 80153 RVA: 0x004ECAE8 File Offset: 0x004EACE8
		// (set) Token: 0x0601391A RID: 80154 RVA: 0x004ECB10 File Offset: 0x004EAD10
		public unsafe AsyncProcessState _effectState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__effectState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms.NativeFieldInfoPtr__effectState)) = value;
			}
		}

		// Token: 0x0400C827 RID: 51239
		private static readonly IntPtr NativeFieldInfoPtr__mip;

		// Token: 0x0400C828 RID: 51240
		private static readonly IntPtr NativeFieldInfoPtr__leftData;

		// Token: 0x0400C829 RID: 51241
		private static readonly IntPtr NativeFieldInfoPtr__rightData;

		// Token: 0x0400C82A RID: 51242
		private static readonly IntPtr NativeFieldInfoPtr__swapCoroutine;

		// Token: 0x0400C82B RID: 51243
		private static readonly IntPtr NativeFieldInfoPtr__effectState;

		// Token: 0x0400C82C RID: 51244
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x0400C82D RID: 51245
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x0400C82E RID: 51246
		private static readonly IntPtr NativeMethodInfoPtr_OnClicked_Private_Void_0;

		// Token: 0x0400C82F RID: 51247
		private static readonly IntPtr NativeMethodInfoPtr_SetState_Private_Void_AsyncProcessState_0;

		// Token: 0x0400C830 RID: 51248
		private static readonly IntPtr NativeMethodInfoPtr_StopSwapRoutine_Private_Void_0;

		// Token: 0x0400C831 RID: 51249
		private static readonly IntPtr NativeMethodInfoPtr_StartSwapRoutine_Private_Void_0;

		// Token: 0x0400C832 RID: 51250
		private static readonly IntPtr NativeMethodInfoPtr_SwapRoutine_Private_IEnumerator_0;

		// Token: 0x0400C833 RID: 51251
		private static readonly IntPtr NativeMethodInfoPtr_SetButtonDisabled_Private_Void_Boolean_0;

		// Token: 0x0400C834 RID: 51252
		private static readonly IntPtr NativeMethodInfoPtr_StopClip_Private_Void_BhapticsClipData_0;

		// Token: 0x0400C835 RID: 51253
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000FF8 RID: 4088
		[ObfuscatedName("DPI.Bhaptics.BhapticsSwapArms/<SwapRoutine>d__11")]
		public sealed class _SwapRoutine_d__11 : Il2CppSystem.Object
		{
			// Token: 0x0601391B RID: 80155 RVA: 0x004ECB34 File Offset: 0x004EAD34
			[CallerCount(0)]
			public unsafe _SwapRoutine_d__11(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601391C RID: 80156 RVA: 0x004ECB94 File Offset: 0x004EAD94
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601391D RID: 80157 RVA: 0x004ECBD8 File Offset: 0x004EADD8
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006EF7 RID: 28407
			// (get) Token: 0x0601391E RID: 80158 RVA: 0x004ECC28 File Offset: 0x004EAE28
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0601391F RID: 80159 RVA: 0x004ECC80 File Offset: 0x004EAE80
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006EF8 RID: 28408
			// (get) Token: 0x06013920 RID: 80160 RVA: 0x004ECCC4 File Offset: 0x004EAEC4
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013921 RID: 80161 RVA: 0x004ECD1C File Offset: 0x004EAF1C
			// Note: this type is marked as 'beforefieldinit'.
			static _SwapRoutine_d__11()
			{
				Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BhapticsSwapArms>.NativeClassPtr, "<SwapRoutine>d__11");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr);
				BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, "<>1__state");
				BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, "<>2__current");
				BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, "<>4__this");
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688285);
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688286);
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688287);
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688288);
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688289);
				BhapticsSwapArms._SwapRoutine_d__11.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr, 100688290);
			}

			// Token: 0x06013922 RID: 80162 RVA: 0x00002988 File Offset: 0x00000B88
			public _SwapRoutine_d__11(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006EF3 RID: 28403
			// (get) Token: 0x06013923 RID: 80163 RVA: 0x004ECDFB File Offset: 0x004EAFFB
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsSwapArms._SwapRoutine_d__11>.NativeClassPtr));
				}
			}

			// Token: 0x17006EF4 RID: 28404
			// (get) Token: 0x06013924 RID: 80164 RVA: 0x004ECE0C File Offset: 0x004EB00C
			// (set) Token: 0x06013925 RID: 80165 RVA: 0x004ECE34 File Offset: 0x004EB034
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006EF5 RID: 28405
			// (get) Token: 0x06013926 RID: 80166 RVA: 0x004ECE58 File Offset: 0x004EB058
			// (set) Token: 0x06013927 RID: 80167 RVA: 0x004ECE8C File Offset: 0x004EB08C
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EF6 RID: 28406
			// (get) Token: 0x06013928 RID: 80168 RVA: 0x004ECEB4 File Offset: 0x004EB0B4
			// (set) Token: 0x06013929 RID: 80169 RVA: 0x004ECEE8 File Offset: 0x004EB0E8
			public unsafe BhapticsSwapArms __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BhapticsSwapArms(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsSwapArms._SwapRoutine_d__11.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C836 RID: 51254
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C837 RID: 51255
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C838 RID: 51256
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C839 RID: 51257
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C83A RID: 51258
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C83B RID: 51259
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C83C RID: 51260
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C83D RID: 51261
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C83E RID: 51262
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
