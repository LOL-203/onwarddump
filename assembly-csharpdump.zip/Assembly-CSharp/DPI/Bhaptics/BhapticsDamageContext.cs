﻿using System;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF5 RID: 4085
	public enum BhapticsDamageContext
	{
		// Token: 0x0400C81D RID: 51229
		None,
		// Token: 0x0400C81E RID: 51230
		DealingDamageUnsuppressed,
		// Token: 0x0400C81F RID: 51231
		DealingDamageSuppressed,
		// Token: 0x0400C820 RID: 51232
		ReceivingDamageUnarmored,
		// Token: 0x0400C821 RID: 51233
		ReceivingDamageArmored
	}
}
