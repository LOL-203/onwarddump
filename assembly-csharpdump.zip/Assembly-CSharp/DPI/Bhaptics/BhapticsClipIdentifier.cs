﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Bhaptics
{
	// Token: 0x02000FEE RID: 4078
	[StructLayout(2)]
	public struct BhapticsClipIdentifier
	{
		// Token: 0x06013888 RID: 80008 RVA: 0x004EA084 File Offset: 0x004E8284
		[CallerCount(0)]
		public unsafe BhapticsClipIdentifier(int hash)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref hash;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013889 RID: 80009 RVA: 0x004EA0CC File Offset: 0x004E82CC
		[CallerCount(0)]
		public unsafe BhapticsClipIdentifier(WeaponType type)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_WeaponType_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601388A RID: 80010 RVA: 0x004EA114 File Offset: 0x004E8314
		[CallerCount(0)]
		public unsafe BhapticsClipIdentifier(WeaponName name)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref name;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_WeaponName_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601388B RID: 80011 RVA: 0x004EA15C File Offset: 0x004E835C
		[CallerCount(0)]
		public unsafe BhapticsClipIdentifier(BhapticsKeyword keyword)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref keyword;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_BhapticsKeyword_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601388C RID: 80012 RVA: 0x004EA1A4 File Offset: 0x004E83A4
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601388D RID: 80013 RVA: 0x004EA1E8 File Offset: 0x004E83E8
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0601388E RID: 80014 RVA: 0x004EA224 File Offset: 0x004E8424
		[CallerCount(0)]
		public unsafe bool Equals(BhapticsClipIdentifier other)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref other;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_BhapticsClipIdentifier_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0601388F RID: 80015 RVA: 0x004EA278 File Offset: 0x004E8478
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(BhapticsClipIdentifier.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06013890 RID: 80016 RVA: 0x004EA2D0 File Offset: 0x004E84D0
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsClipIdentifier()
		{
			Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsClipIdentifier");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr);
			BhapticsClipIdentifier.NativeFieldInfoPtr__hash = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, "_hash");
			BhapticsClipIdentifier.NativeFieldInfoPtr_HASH_SEPARATION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, "HASH_SEPARATION");
			BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688215);
			BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_WeaponType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688216);
			BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_WeaponName_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688217);
			BhapticsClipIdentifier.NativeMethodInfoPtr__ctor_Public_Void_BhapticsKeyword_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688218);
			BhapticsClipIdentifier.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688219);
			BhapticsClipIdentifier.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688220);
			BhapticsClipIdentifier.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688221);
			BhapticsClipIdentifier.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, 100688222);
		}

		// Token: 0x06013891 RID: 80017 RVA: 0x004EA3C8 File Offset: 0x004E85C8
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr, ref this));
		}

		// Token: 0x17006EC8 RID: 28360
		// (get) Token: 0x06013892 RID: 80018 RVA: 0x004EA3DA File Offset: 0x004E85DA
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipIdentifier>.NativeClassPtr));
			}
		}

		// Token: 0x17006EC9 RID: 28361
		// (get) Token: 0x06013893 RID: 80019 RVA: 0x004EA3EC File Offset: 0x004E85EC
		// (set) Token: 0x06013894 RID: 80020 RVA: 0x004EA40A File Offset: 0x004E860A
		public unsafe static int HASH_SEPARATION
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(BhapticsClipIdentifier.NativeFieldInfoPtr_HASH_SEPARATION, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BhapticsClipIdentifier.NativeFieldInfoPtr_HASH_SEPARATION, (void*)(&value));
			}
		}

		// Token: 0x0400C7AF RID: 51119
		private static readonly IntPtr NativeFieldInfoPtr__hash;

		// Token: 0x0400C7B0 RID: 51120
		private static readonly IntPtr NativeFieldInfoPtr_HASH_SEPARATION;

		// Token: 0x0400C7B1 RID: 51121
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x0400C7B2 RID: 51122
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_WeaponType_0;

		// Token: 0x0400C7B3 RID: 51123
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_WeaponName_0;

		// Token: 0x0400C7B4 RID: 51124
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_BhapticsKeyword_0;

		// Token: 0x0400C7B5 RID: 51125
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x0400C7B6 RID: 51126
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x0400C7B7 RID: 51127
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_BhapticsClipIdentifier_0;

		// Token: 0x0400C7B8 RID: 51128
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x0400C7B9 RID: 51129
		[FieldOffset(0)]
		public readonly int _hash;
	}
}
