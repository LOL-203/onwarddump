﻿using System;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF4 RID: 4084
	public enum BhapticsKeyword
	{
		// Token: 0x0400C808 RID: 51208
		None,
		// Token: 0x0400C809 RID: 51209
		ExplosionC4,
		// Token: 0x0400C80A RID: 51210
		ExplosionFlash,
		// Token: 0x0400C80B RID: 51211
		ExplosionGrenade,
		// Token: 0x0400C80C RID: 51212
		ExplosionRocket,
		// Token: 0x0400C80D RID: 51213
		Tased,
		// Token: 0x0400C80E RID: 51214
		TasedBack,
		// Token: 0x0400C80F RID: 51215
		GrenadePin,
		// Token: 0x0400C810 RID: 51216
		Lighter,
		// Token: 0x0400C811 RID: 51217
		C4Clacker,
		// Token: 0x0400C812 RID: 51218
		ShotgunFireChestLeft,
		// Token: 0x0400C813 RID: 51219
		ShotgunFireChestRight,
		// Token: 0x0400C814 RID: 51220
		Stabbing,
		// Token: 0x0400C815 RID: 51221
		ShotgunFireArmLeft,
		// Token: 0x0400C816 RID: 51222
		ShotgunFireArmRight,
		// Token: 0x0400C817 RID: 51223
		HeartbeatLoop,
		// Token: 0x0400C818 RID: 51224
		HeartbeatStop,
		// Token: 0x0400C819 RID: 51225
		Initialize,
		// Token: 0x0400C81A RID: 51226
		Buzz,
		// Token: 0x0400C81B RID: 51227
		PiercingShot
	}
}
