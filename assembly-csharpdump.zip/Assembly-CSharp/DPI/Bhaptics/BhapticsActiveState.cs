﻿using System;

namespace DPI.Bhaptics
{
	// Token: 0x02000FF2 RID: 4082
	public enum BhapticsActiveState
	{
		// Token: 0x0400C7FD RID: 51197
		Uninitialized,
		// Token: 0x0400C7FE RID: 51198
		Active,
		// Token: 0x0400C7FF RID: 51199
		Inactive
	}
}
