﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Bhaptics
{
	// Token: 0x02000FEA RID: 4074
	[StructLayout(2)]
	public struct BhapticsClipContext
	{
		// Token: 0x06013836 RID: 79926 RVA: 0x004E8C18 File Offset: 0x004E6E18
		[CallerCount(0)]
		public unsafe BhapticsClipContext(BhapticsClipType type, BhapticsDamageContext context, BhapticsClipIdentifier primary)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref context;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref primary;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipContext.NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013837 RID: 79927 RVA: 0x004E8C84 File Offset: 0x004E6E84
		[CallerCount(0)]
		public unsafe BhapticsClipContext(BhapticsClipType type, BhapticsDamageContext context, BhapticsClipIdentifier primary, BhapticsClipIdentifier secondary)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref context;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref primary;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref secondary;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipContext.NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_BhapticsClipIdentifier_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013838 RID: 79928 RVA: 0x004E8D04 File Offset: 0x004E6F04
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsClipContext()
		{
			Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsClipContext");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr);
			BhapticsClipContext.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "Type");
			BhapticsClipContext.NativeFieldInfoPtr_Context = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "Context");
			BhapticsClipContext.NativeFieldInfoPtr_PrimaryIdentifier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "PrimaryIdentifier");
			BhapticsClipContext.NativeFieldInfoPtr_SecondaryIdentifier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "SecondaryIdentifier");
			BhapticsClipContext.NativeFieldInfoPtr_HasSecondary = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "HasSecondary");
			BhapticsClipContext.NativeFieldInfoPtr_GenericFallback = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, "GenericFallback");
			BhapticsClipContext.NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, 100688193);
			BhapticsClipContext.NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, 100688194);
		}

		// Token: 0x06013839 RID: 79929 RVA: 0x004E8DD4 File Offset: 0x004E6FD4
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr, ref this));
		}

		// Token: 0x17006EA8 RID: 28328
		// (get) Token: 0x0601383A RID: 79930 RVA: 0x004E8DE6 File Offset: 0x004E6FE6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipContext>.NativeClassPtr));
			}
		}

		// Token: 0x0400C775 RID: 51061
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x0400C776 RID: 51062
		private static readonly IntPtr NativeFieldInfoPtr_Context;

		// Token: 0x0400C777 RID: 51063
		private static readonly IntPtr NativeFieldInfoPtr_PrimaryIdentifier;

		// Token: 0x0400C778 RID: 51064
		private static readonly IntPtr NativeFieldInfoPtr_SecondaryIdentifier;

		// Token: 0x0400C779 RID: 51065
		private static readonly IntPtr NativeFieldInfoPtr_HasSecondary;

		// Token: 0x0400C77A RID: 51066
		private static readonly IntPtr NativeFieldInfoPtr_GenericFallback;

		// Token: 0x0400C77B RID: 51067
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_0;

		// Token: 0x0400C77C RID: 51068
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_BhapticsClipType_BhapticsDamageContext_BhapticsClipIdentifier_BhapticsClipIdentifier_0;

		// Token: 0x0400C77D RID: 51069
		[FieldOffset(0)]
		public readonly BhapticsClipType Type;

		// Token: 0x0400C77E RID: 51070
		[FieldOffset(4)]
		public readonly BhapticsDamageContext Context;

		// Token: 0x0400C77F RID: 51071
		[FieldOffset(8)]
		public readonly BhapticsClipIdentifier PrimaryIdentifier;

		// Token: 0x0400C780 RID: 51072
		[FieldOffset(12)]
		public readonly BhapticsClipIdentifier SecondaryIdentifier;

		// Token: 0x0400C781 RID: 51073
		[FieldOffset(16)]
		public readonly bool HasSecondary;

		// Token: 0x0400C782 RID: 51074
		[FieldOffset(17)]
		public bool GenericFallback;
	}
}
