﻿using System;
using Bhaptics.Tact.Unity;
using DPI.Data;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Bhaptics
{
	// Token: 0x02000FEB RID: 4075
	public class BhapticsClipData : BaseData
	{
		// Token: 0x0601383B RID: 79931 RVA: 0x004E8DF8 File Offset: 0x004E6FF8
		[CallerCount(0)]
		public unsafe IEnumerable<BhapticsClipIdentifier> GetClipIdentifiers()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData.NativeMethodInfoPtr_GetClipIdentifiers_Protected_IEnumerable_1_BhapticsClipIdentifier_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerable<BhapticsClipIdentifier>(intPtr2) : null;
		}

		// Token: 0x0601383C RID: 79932 RVA: 0x004E8E50 File Offset: 0x004E7050
		[CallerCount(0)]
		public unsafe IEnumerable<int> GetClipKeys()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData.NativeMethodInfoPtr_GetClipKeys_Public_IEnumerable_1_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerable<int>(intPtr2) : null;
		}

		// Token: 0x0601383D RID: 79933 RVA: 0x004E8EA8 File Offset: 0x004E70A8
		[CallerCount(0)]
		public unsafe BhapticsClipData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0601383E RID: 79934 RVA: 0x004E8EF4 File Offset: 0x004E70F4
		// Note: this type is marked as 'beforefieldinit'.
		static BhapticsClipData()
		{
			Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Bhaptics", "BhapticsClipData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr);
			BhapticsClipData.NativeFieldInfoPtr_Clip = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "Clip");
			BhapticsClipData.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "Type");
			BhapticsClipData.NativeFieldInfoPtr_Contexts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "Contexts");
			BhapticsClipData.NativeFieldInfoPtr_WeaponTypeIdentifiers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "WeaponTypeIdentifiers");
			BhapticsClipData.NativeFieldInfoPtr_WeaponNameIdentifiers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "WeaponNameIdentifiers");
			BhapticsClipData.NativeFieldInfoPtr_FeedbackKeywordIdentifiers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "FeedbackKeywordIdentifiers");
			BhapticsClipData.NativeFieldInfoPtr_IntensityCurve = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "IntensityCurve");
			BhapticsClipData.NativeFieldInfoPtr_DurationCurve = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "DurationCurve");
			BhapticsClipData.NativeMethodInfoPtr_GetClipIdentifiers_Protected_IEnumerable_1_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, 100688195);
			BhapticsClipData.NativeMethodInfoPtr_GetClipKeys_Public_IEnumerable_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, 100688196);
			BhapticsClipData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, 100688197);
		}

		// Token: 0x0601383F RID: 79935 RVA: 0x000AD628 File Offset: 0x000AB828
		public BhapticsClipData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006EA9 RID: 28329
		// (get) Token: 0x06013840 RID: 79936 RVA: 0x004E9000 File Offset: 0x004E7200
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr));
			}
		}

		// Token: 0x17006EAA RID: 28330
		// (get) Token: 0x06013841 RID: 79937 RVA: 0x004E9014 File Offset: 0x004E7214
		// (set) Token: 0x06013842 RID: 79938 RVA: 0x004E9048 File Offset: 0x004E7248
		public unsafe FileHapticClip Clip
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Clip);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new FileHapticClip(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Clip), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EAB RID: 28331
		// (get) Token: 0x06013843 RID: 79939 RVA: 0x004E9070 File Offset: 0x004E7270
		// (set) Token: 0x06013844 RID: 79940 RVA: 0x004E9098 File Offset: 0x004E7298
		public unsafe BhapticsClipType Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x17006EAC RID: 28332
		// (get) Token: 0x06013845 RID: 79941 RVA: 0x004E90BC File Offset: 0x004E72BC
		// (set) Token: 0x06013846 RID: 79942 RVA: 0x004E90F0 File Offset: 0x004E72F0
		public unsafe Il2CppStructArray<BhapticsDamageContext> Contexts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Contexts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<BhapticsDamageContext>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_Contexts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EAD RID: 28333
		// (get) Token: 0x06013847 RID: 79943 RVA: 0x004E9118 File Offset: 0x004E7318
		// (set) Token: 0x06013848 RID: 79944 RVA: 0x004E914C File Offset: 0x004E734C
		public unsafe Il2CppStructArray<WeaponType> WeaponTypeIdentifiers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_WeaponTypeIdentifiers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<WeaponType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_WeaponTypeIdentifiers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EAE RID: 28334
		// (get) Token: 0x06013849 RID: 79945 RVA: 0x004E9174 File Offset: 0x004E7374
		// (set) Token: 0x0601384A RID: 79946 RVA: 0x004E91A8 File Offset: 0x004E73A8
		public unsafe Il2CppStructArray<WeaponName> WeaponNameIdentifiers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_WeaponNameIdentifiers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<WeaponName>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_WeaponNameIdentifiers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EAF RID: 28335
		// (get) Token: 0x0601384B RID: 79947 RVA: 0x004E91D0 File Offset: 0x004E73D0
		// (set) Token: 0x0601384C RID: 79948 RVA: 0x004E9204 File Offset: 0x004E7404
		public unsafe Il2CppStructArray<BhapticsKeyword> FeedbackKeywordIdentifiers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_FeedbackKeywordIdentifiers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<BhapticsKeyword>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_FeedbackKeywordIdentifiers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EB0 RID: 28336
		// (get) Token: 0x0601384D RID: 79949 RVA: 0x004E922C File Offset: 0x004E742C
		// (set) Token: 0x0601384E RID: 79950 RVA: 0x004E9260 File Offset: 0x004E7460
		public unsafe AnimationCurve IntensityCurve
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_IntensityCurve);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AnimationCurve(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_IntensityCurve), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006EB1 RID: 28337
		// (get) Token: 0x0601384F RID: 79951 RVA: 0x004E9288 File Offset: 0x004E7488
		// (set) Token: 0x06013850 RID: 79952 RVA: 0x004E92BC File Offset: 0x004E74BC
		public unsafe AnimationCurve DurationCurve
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_DurationCurve);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AnimationCurve(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData.NativeFieldInfoPtr_DurationCurve), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400C783 RID: 51075
		private static readonly IntPtr NativeFieldInfoPtr_Clip;

		// Token: 0x0400C784 RID: 51076
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x0400C785 RID: 51077
		private static readonly IntPtr NativeFieldInfoPtr_Contexts;

		// Token: 0x0400C786 RID: 51078
		private static readonly IntPtr NativeFieldInfoPtr_WeaponTypeIdentifiers;

		// Token: 0x0400C787 RID: 51079
		private static readonly IntPtr NativeFieldInfoPtr_WeaponNameIdentifiers;

		// Token: 0x0400C788 RID: 51080
		private static readonly IntPtr NativeFieldInfoPtr_FeedbackKeywordIdentifiers;

		// Token: 0x0400C789 RID: 51081
		private static readonly IntPtr NativeFieldInfoPtr_IntensityCurve;

		// Token: 0x0400C78A RID: 51082
		private static readonly IntPtr NativeFieldInfoPtr_DurationCurve;

		// Token: 0x0400C78B RID: 51083
		private static readonly IntPtr NativeMethodInfoPtr_GetClipIdentifiers_Protected_IEnumerable_1_BhapticsClipIdentifier_0;

		// Token: 0x0400C78C RID: 51084
		private static readonly IntPtr NativeMethodInfoPtr_GetClipKeys_Public_IEnumerable_1_Int32_0;

		// Token: 0x0400C78D RID: 51085
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000FEC RID: 4076
		[ObfuscatedName("DPI.Bhaptics.BhapticsClipData/<GetClipIdentifiers>d__8")]
		public sealed class _GetClipIdentifiers_d__8 : Il2CppSystem.Object
		{
			// Token: 0x06013851 RID: 79953 RVA: 0x004E92E4 File Offset: 0x004E74E4
			[CallerCount(0)]
			public unsafe _GetClipIdentifiers_d__8(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013852 RID: 79954 RVA: 0x004E9344 File Offset: 0x004E7544
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013853 RID: 79955 RVA: 0x004E9388 File Offset: 0x004E7588
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17006EBB RID: 28347
			// (get) Token: 0x06013854 RID: 79956 RVA: 0x004E93D8 File Offset: 0x004E75D8
			public unsafe BhapticsClipIdentifier Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_DPI_Bhaptics_BhapticsClipIdentifier__get_Current_Private_Virtual_Final_New_get_BhapticsClipIdentifier_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return *IL2CPP.il2cpp_object_unbox(obj);
				}
			}

			// Token: 0x06013855 RID: 79957 RVA: 0x004E9428 File Offset: 0x004E7628
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006EBC RID: 28348
			// (get) Token: 0x06013856 RID: 79958 RVA: 0x004E946C File Offset: 0x004E766C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013857 RID: 79959 RVA: 0x004E94C4 File Offset: 0x004E76C4
			[CallerCount(0)]
			public unsafe IEnumerator<BhapticsClipIdentifier> System_Collections_Generic_IEnumerable_DPI_Bhaptics_BhapticsClipIdentifier__GetEnumerator()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_DPI_Bhaptics_BhapticsClipIdentifier__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_BhapticsClipIdentifier_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new IEnumerator<BhapticsClipIdentifier>(intPtr2) : null;
			}

			// Token: 0x06013858 RID: 79960 RVA: 0x004E951C File Offset: 0x004E771C
			[CallerCount(0)]
			public unsafe IEnumerator System_Collections_IEnumerable_GetEnumerator()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
			}

			// Token: 0x06013859 RID: 79961 RVA: 0x004E9574 File Offset: 0x004E7774
			// Note: this type is marked as 'beforefieldinit'.
			static _GetClipIdentifiers_d__8()
			{
				Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "<GetClipIdentifiers>d__8");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>1__state");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>2__current");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___l__initialThreadId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>l__initialThreadId");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>4__this");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>7__wrap1");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>7__wrap2");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>7__wrap3");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, "<>7__wrap4");
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688198);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688199);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688200);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_DPI_Bhaptics_BhapticsClipIdentifier__get_Current_Private_Virtual_Final_New_get_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688201);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688202);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688203);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_DPI_Bhaptics_BhapticsClipIdentifier__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_BhapticsClipIdentifier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688204);
				BhapticsClipData._GetClipIdentifiers_d__8.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr, 100688205);
			}

			// Token: 0x0601385A RID: 79962 RVA: 0x00002988 File Offset: 0x00000B88
			public _GetClipIdentifiers_d__8(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006EB2 RID: 28338
			// (get) Token: 0x0601385B RID: 79963 RVA: 0x004E96DF File Offset: 0x004E78DF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipData._GetClipIdentifiers_d__8>.NativeClassPtr));
				}
			}

			// Token: 0x17006EB3 RID: 28339
			// (get) Token: 0x0601385C RID: 79964 RVA: 0x004E96F0 File Offset: 0x004E78F0
			// (set) Token: 0x0601385D RID: 79965 RVA: 0x004E9718 File Offset: 0x004E7918
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006EB4 RID: 28340
			// (get) Token: 0x0601385E RID: 79966 RVA: 0x004E973C File Offset: 0x004E793C
			// (set) Token: 0x0601385F RID: 79967 RVA: 0x004E9764 File Offset: 0x004E7964
			public unsafe BhapticsClipIdentifier __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___2__current);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___2__current)) = value;
				}
			}

			// Token: 0x17006EB5 RID: 28341
			// (get) Token: 0x06013860 RID: 79968 RVA: 0x004E9788 File Offset: 0x004E7988
			// (set) Token: 0x06013861 RID: 79969 RVA: 0x004E97B0 File Offset: 0x004E79B0
			public unsafe int __l__initialThreadId
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___l__initialThreadId);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___l__initialThreadId)) = value;
				}
			}

			// Token: 0x17006EB6 RID: 28342
			// (get) Token: 0x06013862 RID: 79970 RVA: 0x004E97D4 File Offset: 0x004E79D4
			// (set) Token: 0x06013863 RID: 79971 RVA: 0x004E9808 File Offset: 0x004E7A08
			public unsafe BhapticsClipData __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BhapticsClipData(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EB7 RID: 28343
			// (get) Token: 0x06013864 RID: 79972 RVA: 0x004E9830 File Offset: 0x004E7A30
			// (set) Token: 0x06013865 RID: 79973 RVA: 0x004E9864 File Offset: 0x004E7A64
			public unsafe Il2CppStructArray<WeaponType> __7__wrap1
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap1);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<WeaponType>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap1), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EB8 RID: 28344
			// (get) Token: 0x06013866 RID: 79974 RVA: 0x004E988C File Offset: 0x004E7A8C
			// (set) Token: 0x06013867 RID: 79975 RVA: 0x004E98B4 File Offset: 0x004E7AB4
			public unsafe int __7__wrap2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap2);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap2)) = value;
				}
			}

			// Token: 0x17006EB9 RID: 28345
			// (get) Token: 0x06013868 RID: 79976 RVA: 0x004E98D8 File Offset: 0x004E7AD8
			// (set) Token: 0x06013869 RID: 79977 RVA: 0x004E990C File Offset: 0x004E7B0C
			public unsafe Il2CppStructArray<WeaponName> __7__wrap3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap3);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<WeaponName>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap3), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EBA RID: 28346
			// (get) Token: 0x0601386A RID: 79978 RVA: 0x004E9934 File Offset: 0x004E7B34
			// (set) Token: 0x0601386B RID: 79979 RVA: 0x004E9968 File Offset: 0x004E7B68
			public unsafe Il2CppStructArray<BhapticsKeyword> __7__wrap4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<BhapticsKeyword>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipIdentifiers_d__8.NativeFieldInfoPtr___7__wrap4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C78E RID: 51086
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C78F RID: 51087
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C790 RID: 51088
			private static readonly IntPtr NativeFieldInfoPtr___l__initialThreadId;

			// Token: 0x0400C791 RID: 51089
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C792 RID: 51090
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap1;

			// Token: 0x0400C793 RID: 51091
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap2;

			// Token: 0x0400C794 RID: 51092
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap3;

			// Token: 0x0400C795 RID: 51093
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap4;

			// Token: 0x0400C796 RID: 51094
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C797 RID: 51095
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C798 RID: 51096
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C799 RID: 51097
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_DPI_Bhaptics_BhapticsClipIdentifier__get_Current_Private_Virtual_Final_New_get_BhapticsClipIdentifier_0;

			// Token: 0x0400C79A RID: 51098
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C79B RID: 51099
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C79C RID: 51100
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_DPI_Bhaptics_BhapticsClipIdentifier__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_BhapticsClipIdentifier_0;

			// Token: 0x0400C79D RID: 51101
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0;
		}

		// Token: 0x02000FED RID: 4077
		[ObfuscatedName("DPI.Bhaptics.BhapticsClipData/<GetClipKeys>d__9")]
		public sealed class _GetClipKeys_d__9 : Il2CppSystem.Object
		{
			// Token: 0x0601386C RID: 79980 RVA: 0x004E9990 File Offset: 0x004E7B90
			[CallerCount(0)]
			public unsafe _GetClipKeys_d__9(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601386D RID: 79981 RVA: 0x004E99F0 File Offset: 0x004E7BF0
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0601386E RID: 79982 RVA: 0x004E9A34 File Offset: 0x004E7C34
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0601386F RID: 79983 RVA: 0x004E9A84 File Offset: 0x004E7C84
			[CallerCount(0)]
			public unsafe void __m__Finally1()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr___m__Finally1_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006EC6 RID: 28358
			// (get) Token: 0x06013870 RID: 79984 RVA: 0x004E9AC8 File Offset: 0x004E7CC8
			public unsafe int Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Int32__get_Current_Private_Virtual_Final_New_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return *IL2CPP.il2cpp_object_unbox(obj);
				}
			}

			// Token: 0x06013871 RID: 79985 RVA: 0x004E9B18 File Offset: 0x004E7D18
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17006EC7 RID: 28359
			// (get) Token: 0x06013872 RID: 79986 RVA: 0x004E9B5C File Offset: 0x004E7D5C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013873 RID: 79987 RVA: 0x004E9BB4 File Offset: 0x004E7DB4
			[CallerCount(0)]
			public unsafe IEnumerator<int> System_Collections_Generic_IEnumerable_System_Int32__GetEnumerator()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_System_Int32__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new IEnumerator<int>(intPtr2) : null;
			}

			// Token: 0x06013874 RID: 79988 RVA: 0x004E9C0C File Offset: 0x004E7E0C
			[CallerCount(0)]
			public unsafe IEnumerator System_Collections_IEnumerable_GetEnumerator()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
			}

			// Token: 0x06013875 RID: 79989 RVA: 0x004E9C64 File Offset: 0x004E7E64
			// Note: this type is marked as 'beforefieldinit'.
			static _GetClipKeys_d__9()
			{
				Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<BhapticsClipData>.NativeClassPtr, "<GetClipKeys>d__9");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr);
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>1__state");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>2__current");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___l__initialThreadId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>l__initialThreadId");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>4__this");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>7__wrap1");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>7__wrap2");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr__context_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<context>5__4");
				BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, "<>7__wrap4");
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688206);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688207);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688208);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr___m__Finally1_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688209);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Int32__get_Current_Private_Virtual_Final_New_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688210);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688211);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688212);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_System_Int32__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688213);
				BhapticsClipData._GetClipKeys_d__9.NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr, 100688214);
			}

			// Token: 0x06013876 RID: 79990 RVA: 0x00002988 File Offset: 0x00000B88
			public _GetClipKeys_d__9(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006EBD RID: 28349
			// (get) Token: 0x06013877 RID: 79991 RVA: 0x004E9DE3 File Offset: 0x004E7FE3
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BhapticsClipData._GetClipKeys_d__9>.NativeClassPtr));
				}
			}

			// Token: 0x17006EBE RID: 28350
			// (get) Token: 0x06013878 RID: 79992 RVA: 0x004E9DF4 File Offset: 0x004E7FF4
			// (set) Token: 0x06013879 RID: 79993 RVA: 0x004E9E1C File Offset: 0x004E801C
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17006EBF RID: 28351
			// (get) Token: 0x0601387A RID: 79994 RVA: 0x004E9E40 File Offset: 0x004E8040
			// (set) Token: 0x0601387B RID: 79995 RVA: 0x004E9E68 File Offset: 0x004E8068
			public unsafe int __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___2__current);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___2__current)) = value;
				}
			}

			// Token: 0x17006EC0 RID: 28352
			// (get) Token: 0x0601387C RID: 79996 RVA: 0x004E9E8C File Offset: 0x004E808C
			// (set) Token: 0x0601387D RID: 79997 RVA: 0x004E9EB4 File Offset: 0x004E80B4
			public unsafe int __l__initialThreadId
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___l__initialThreadId);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___l__initialThreadId)) = value;
				}
			}

			// Token: 0x17006EC1 RID: 28353
			// (get) Token: 0x0601387E RID: 79998 RVA: 0x004E9ED8 File Offset: 0x004E80D8
			// (set) Token: 0x0601387F RID: 79999 RVA: 0x004E9F0C File Offset: 0x004E810C
			public unsafe BhapticsClipData __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new BhapticsClipData(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EC2 RID: 28354
			// (get) Token: 0x06013880 RID: 80000 RVA: 0x004E9F34 File Offset: 0x004E8134
			// (set) Token: 0x06013881 RID: 80001 RVA: 0x004E9F68 File Offset: 0x004E8168
			public unsafe Il2CppStructArray<BhapticsDamageContext> __7__wrap1
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap1);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<BhapticsDamageContext>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap1), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17006EC3 RID: 28355
			// (get) Token: 0x06013882 RID: 80002 RVA: 0x004E9F90 File Offset: 0x004E8190
			// (set) Token: 0x06013883 RID: 80003 RVA: 0x004E9FB8 File Offset: 0x004E81B8
			public unsafe int __7__wrap2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap2);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap2)) = value;
				}
			}

			// Token: 0x17006EC4 RID: 28356
			// (get) Token: 0x06013884 RID: 80004 RVA: 0x004E9FDC File Offset: 0x004E81DC
			// (set) Token: 0x06013885 RID: 80005 RVA: 0x004EA004 File Offset: 0x004E8204
			public unsafe BhapticsDamageContext _context_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr__context_5__4);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr__context_5__4)) = value;
				}
			}

			// Token: 0x17006EC5 RID: 28357
			// (get) Token: 0x06013886 RID: 80006 RVA: 0x004EA028 File Offset: 0x004E8228
			// (set) Token: 0x06013887 RID: 80007 RVA: 0x004EA05C File Offset: 0x004E825C
			public unsafe IEnumerator<BhapticsClipIdentifier> __7__wrap4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap4);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new IEnumerator<BhapticsClipIdentifier>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BhapticsClipData._GetClipKeys_d__9.NativeFieldInfoPtr___7__wrap4), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400C79E RID: 51102
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400C79F RID: 51103
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400C7A0 RID: 51104
			private static readonly IntPtr NativeFieldInfoPtr___l__initialThreadId;

			// Token: 0x0400C7A1 RID: 51105
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400C7A2 RID: 51106
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap1;

			// Token: 0x0400C7A3 RID: 51107
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap2;

			// Token: 0x0400C7A4 RID: 51108
			private static readonly IntPtr NativeFieldInfoPtr__context_5__4;

			// Token: 0x0400C7A5 RID: 51109
			private static readonly IntPtr NativeFieldInfoPtr___7__wrap4;

			// Token: 0x0400C7A6 RID: 51110
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400C7A7 RID: 51111
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C7A8 RID: 51112
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400C7A9 RID: 51113
			private static readonly IntPtr NativeMethodInfoPtr___m__Finally1_Private_Void_0;

			// Token: 0x0400C7AA RID: 51114
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Int32__get_Current_Private_Virtual_Final_New_get_Int32_0;

			// Token: 0x0400C7AB RID: 51115
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400C7AC RID: 51116
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400C7AD RID: 51117
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerable_System_Int32__GetEnumerator_Private_Virtual_Final_New_IEnumerator_1_Int32_0;

			// Token: 0x0400C7AE RID: 51118
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerable_GetEnumerator_Private_Virtual_Final_New_IEnumerator_0;
		}
	}
}
