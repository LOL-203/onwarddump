﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI
{
	// Token: 0x02000F35 RID: 3893
	public static class ClientEncryptionUtil : Object
	{
		// Token: 0x17006A2E RID: 27182
		// (get) Token: 0x06012C2C RID: 76844 RVA: 0x004BA5D4 File Offset: 0x004B87D4
		public unsafe static string CertificateData
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ClientEncryptionUtil.NativeMethodInfoPtr_get_CertificateData_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x06012C2D RID: 76845 RVA: 0x004BA610 File Offset: 0x004B8810
		// Note: this type is marked as 'beforefieldinit'.
		static ClientEncryptionUtil()
		{
			Il2CppClassPointerStore<ClientEncryptionUtil>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI", "ClientEncryptionUtil");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ClientEncryptionUtil>.NativeClassPtr);
			ClientEncryptionUtil.NativeFieldInfoPtr_AWS_ROOT_CERTIFICATE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ClientEncryptionUtil>.NativeClassPtr, "AWS_ROOT_CERTIFICATE");
			ClientEncryptionUtil.NativeMethodInfoPtr_get_CertificateData_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ClientEncryptionUtil>.NativeClassPtr, 100687355);
		}

		// Token: 0x06012C2E RID: 76846 RVA: 0x00002988 File Offset: 0x00000B88
		public ClientEncryptionUtil(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006A2C RID: 27180
		// (get) Token: 0x06012C2F RID: 76847 RVA: 0x004BA668 File Offset: 0x004B8868
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ClientEncryptionUtil>.NativeClassPtr));
			}
		}

		// Token: 0x17006A2D RID: 27181
		// (get) Token: 0x06012C30 RID: 76848 RVA: 0x004BA67C File Offset: 0x004B887C
		// (set) Token: 0x06012C31 RID: 76849 RVA: 0x004BA69C File Offset: 0x004B889C
		public unsafe static string AWS_ROOT_CERTIFICATE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ClientEncryptionUtil.NativeFieldInfoPtr_AWS_ROOT_CERTIFICATE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ClientEncryptionUtil.NativeFieldInfoPtr_AWS_ROOT_CERTIFICATE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400C039 RID: 49209
		private static readonly IntPtr NativeFieldInfoPtr_AWS_ROOT_CERTIFICATE;

		// Token: 0x0400C03A RID: 49210
		private static readonly IntPtr NativeMethodInfoPtr_get_CertificateData_Public_Static_get_String_0;
	}
}
