﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.App
{
	// Token: 0x0200102E RID: 4142
	public class ApplicationMonitorEventsOculus : ApplicationMonitorEvents
	{
		// Token: 0x06013D12 RID: 81170 RVA: 0x004FC2F4 File Offset: 0x004FA4F4
		[CallerCount(0)]
		public unsafe ApplicationMonitorEventsOculus(ApplicationMonitor monitor) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(monitor);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEventsOculus.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D13 RID: 81171 RVA: 0x004FC358 File Offset: 0x004FA558
		[CallerCount(0)]
		public new unsafe void Register()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Register_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D14 RID: 81172 RVA: 0x004FC3A8 File Offset: 0x004FA5A8
		[CallerCount(0)]
		public new unsafe void Unregister()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D15 RID: 81173 RVA: 0x004FC3F8 File Offset: 0x004FA5F8
		[CallerCount(0)]
		public new unsafe void Tick()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D16 RID: 81174 RVA: 0x004FC448 File Offset: 0x004FA648
		[CallerCount(0)]
		public unsafe void OVRManagerOnRecenteredPose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEventsOculus.NativeMethodInfoPtr_OVRManagerOnRecenteredPose_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D17 RID: 81175 RVA: 0x004FC48C File Offset: 0x004FA68C
		// Note: this type is marked as 'beforefieldinit'.
		static ApplicationMonitorEventsOculus()
		{
			Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.App", "ApplicationMonitorEventsOculus");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr);
			ApplicationMonitorEventsOculus.NativeFieldInfoPtr_lastPose = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, "lastPose");
			ApplicationMonitorEventsOculus.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, 100688593);
			ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Register_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, 100688594);
			ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, 100688595);
			ApplicationMonitorEventsOculus.NativeMethodInfoPtr_Tick_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, 100688596);
			ApplicationMonitorEventsOculus.NativeMethodInfoPtr_OVRManagerOnRecenteredPose_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr, 100688597);
		}

		// Token: 0x06013D18 RID: 81176 RVA: 0x004FC534 File Offset: 0x004FA734
		public ApplicationMonitorEventsOculus(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700706C RID: 28780
		// (get) Token: 0x06013D19 RID: 81177 RVA: 0x004FC53D File Offset: 0x004FA73D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ApplicationMonitorEventsOculus>.NativeClassPtr));
			}
		}

		// Token: 0x1700706D RID: 28781
		// (get) Token: 0x06013D1A RID: 81178 RVA: 0x004FC550 File Offset: 0x004FA750
		// (set) Token: 0x06013D1B RID: 81179 RVA: 0x004FC578 File Offset: 0x004FA778
		public unsafe OVRPlugin.Posef lastPose
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEventsOculus.NativeFieldInfoPtr_lastPose);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEventsOculus.NativeFieldInfoPtr_lastPose)) = value;
			}
		}

		// Token: 0x0400CAAA RID: 51882
		private static readonly IntPtr NativeFieldInfoPtr_lastPose;

		// Token: 0x0400CAAB RID: 51883
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0;

		// Token: 0x0400CAAC RID: 51884
		private static readonly IntPtr NativeMethodInfoPtr_Register_Public_Virtual_Void_0;

		// Token: 0x0400CAAD RID: 51885
		private static readonly IntPtr NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0;

		// Token: 0x0400CAAE RID: 51886
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_Void_0;

		// Token: 0x0400CAAF RID: 51887
		private static readonly IntPtr NativeMethodInfoPtr_OVRManagerOnRecenteredPose_Private_Void_0;
	}
}
