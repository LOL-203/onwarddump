﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Valve.VR;

namespace DPI.App
{
	// Token: 0x0200102F RID: 4143
	public class ApplicationMonitorEventsSteam : ApplicationMonitorEvents
	{
		// Token: 0x06013D1C RID: 81180 RVA: 0x004FC59C File Offset: 0x004FA79C
		[CallerCount(0)]
		public unsafe ApplicationMonitorEventsSteam(ApplicationMonitor monitor) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(monitor);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEventsSteam.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D1D RID: 81181 RVA: 0x004FC600 File Offset: 0x004FA800
		[CallerCount(0)]
		public new unsafe void Register()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEventsSteam.NativeMethodInfoPtr_Register_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D1E RID: 81182 RVA: 0x004FC650 File Offset: 0x004FA850
		[CallerCount(0)]
		public new unsafe void Unregister()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEventsSteam.NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D1F RID: 81183 RVA: 0x004FC6A0 File Offset: 0x004FA8A0
		[CallerCount(0)]
		public unsafe void OnInputFocus(bool inputFocus)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref inputFocus;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEventsSteam.NativeMethodInfoPtr_OnInputFocus_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D20 RID: 81184 RVA: 0x004FC6F4 File Offset: 0x004FA8F4
		[CallerCount(0)]
		public unsafe void SteamVROnPoseReset(VREvent_t vrEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref vrEvent;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEventsSteam.NativeMethodInfoPtr_SteamVROnPoseReset_Private_Void_VREvent_t_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D21 RID: 81185 RVA: 0x004FC748 File Offset: 0x004FA948
		// Note: this type is marked as 'beforefieldinit'.
		static ApplicationMonitorEventsSteam()
		{
			Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.App", "ApplicationMonitorEventsSteam");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr);
			ApplicationMonitorEventsSteam.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr, 100688598);
			ApplicationMonitorEventsSteam.NativeMethodInfoPtr_Register_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr, 100688599);
			ApplicationMonitorEventsSteam.NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr, 100688600);
			ApplicationMonitorEventsSteam.NativeMethodInfoPtr_OnInputFocus_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr, 100688601);
			ApplicationMonitorEventsSteam.NativeMethodInfoPtr_SteamVROnPoseReset_Private_Void_VREvent_t_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr, 100688602);
		}

		// Token: 0x06013D22 RID: 81186 RVA: 0x004FC534 File Offset: 0x004FA734
		public ApplicationMonitorEventsSteam(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700706E RID: 28782
		// (get) Token: 0x06013D23 RID: 81187 RVA: 0x004FC7DC File Offset: 0x004FA9DC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ApplicationMonitorEventsSteam>.NativeClassPtr));
			}
		}

		// Token: 0x0400CAB0 RID: 51888
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0;

		// Token: 0x0400CAB1 RID: 51889
		private static readonly IntPtr NativeMethodInfoPtr_Register_Public_Virtual_Void_0;

		// Token: 0x0400CAB2 RID: 51890
		private static readonly IntPtr NativeMethodInfoPtr_Unregister_Public_Virtual_Void_0;

		// Token: 0x0400CAB3 RID: 51891
		private static readonly IntPtr NativeMethodInfoPtr_OnInputFocus_Private_Void_Boolean_0;

		// Token: 0x0400CAB4 RID: 51892
		private static readonly IntPtr NativeMethodInfoPtr_SteamVROnPoseReset_Private_Void_VREvent_t_0;
	}
}
