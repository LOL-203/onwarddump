﻿using System;

namespace DPI.App
{
	// Token: 0x02001030 RID: 4144
	[Flags]
	public enum ApplicationStateType
	{
		// Token: 0x0400CAB6 RID: 51894
		None = 0,
		// Token: 0x0400CAB7 RID: 51895
		ApplicationPause = 1,
		// Token: 0x0400CAB8 RID: 51896
		ApplicationFocus = 2,
		// Token: 0x0400CAB9 RID: 51897
		InputFocus = 4,
		// Token: 0x0400CABA RID: 51898
		PlayerPresence = 8,
		// Token: 0x0400CABB RID: 51899
		TimeScalePause = 16,
		// Token: 0x0400CABC RID: 51900
		AnyPause = 32
	}
}
