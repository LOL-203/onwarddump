﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.App
{
	// Token: 0x0200102C RID: 4140
	public class ApplicationMonitorEvents : Il2CppSystem.Object
	{
		// Token: 0x17007065 RID: 28773
		// (get) Token: 0x06013CE1 RID: 81121 RVA: 0x004FB4C4 File Offset: 0x004F96C4
		// (set) Token: 0x06013CE2 RID: 81122 RVA: 0x004FB514 File Offset: 0x004F9714
		public unsafe bool ManagedLateUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013CE3 RID: 81123 RVA: 0x004FB568 File Offset: 0x004F9768
		[CallerCount(0)]
		public unsafe ApplicationMonitorEvents(ApplicationMonitor monitor) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(monitor);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE4 RID: 81124 RVA: 0x004FB5CC File Offset: 0x004F97CC
		[CallerCount(0)]
		public unsafe void Register()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_Register_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE5 RID: 81125 RVA: 0x004FB61C File Offset: 0x004F981C
		[CallerCount(0)]
		public unsafe void Unregister()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_Unregister_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE6 RID: 81126 RVA: 0x004FB66C File Offset: 0x004F986C
		[CallerCount(0)]
		public unsafe void OnApplicationFocus(bool hasFocus)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref hasFocus;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_OnApplicationFocus_Public_Virtual_New_Void_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE7 RID: 81127 RVA: 0x004FB6CC File Offset: 0x004F98CC
		[CallerCount(0)]
		public unsafe void OnApplicationPause(bool paused)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref paused;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_OnApplicationPause_Public_Virtual_New_Void_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE8 RID: 81128 RVA: 0x004FB72C File Offset: 0x004F992C
		[CallerCount(0)]
		public unsafe void OnTimeScalePause(bool paused)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref paused;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_OnTimeScalePause_Public_Virtual_New_Void_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CE9 RID: 81129 RVA: 0x004FB78C File Offset: 0x004F998C
		[CallerCount(0)]
		public unsafe void OnManagedLateUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CEA RID: 81130 RVA: 0x004FB7D0 File Offset: 0x004F99D0
		[CallerCount(0)]
		public unsafe void Tick()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ApplicationMonitorEvents.NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CEB RID: 81131 RVA: 0x004FB820 File Offset: 0x004F9A20
		[CallerCount(0)]
		public unsafe void InvokeOnPlaySpaceCentered()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_InvokeOnPlaySpaceCentered_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CEC RID: 81132 RVA: 0x004FB864 File Offset: 0x004F9A64
		[CallerCount(0)]
		public unsafe bool GetState(ApplicationStateType type)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_GetState_Public_Boolean_ApplicationStateType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013CED RID: 81133 RVA: 0x004FB8C8 File Offset: 0x004F9AC8
		[CallerCount(0)]
		public unsafe void SetState(ApplicationStateType type, bool value, bool initializing = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref initializing;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_SetState_Protected_Void_ApplicationStateType_Boolean_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CEE RID: 81134 RVA: 0x004FB944 File Offset: 0x004F9B44
		[CallerCount(0)]
		public unsafe IEnumerator PlayspaceCenterRoutine()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_PlayspaceCenterRoutine_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06013CEF RID: 81135 RVA: 0x004FB99C File Offset: 0x004F9B9C
		[CallerCount(0)]
		public unsafe void RefreshAnyPause(bool initializing = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref initializing;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_RefreshAnyPause_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CF0 RID: 81136 RVA: 0x004FB9F0 File Offset: 0x004F9BF0
		[CallerCount(0)]
		public unsafe void RefreshPlayerPresence(bool initializing = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref initializing;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_RefreshPlayerPresence_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CF1 RID: 81137 RVA: 0x004FBA44 File Offset: 0x004F9C44
		[CallerCount(0)]
		public unsafe void ApplicationMonitorLog(string log)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(log);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents.NativeMethodInfoPtr_ApplicationMonitorLog_Protected_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CF2 RID: 81138 RVA: 0x004FBAA0 File Offset: 0x004F9CA0
		// Note: this type is marked as 'beforefieldinit'.
		static ApplicationMonitorEvents()
		{
			Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.App", "ApplicationMonitorEvents");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr);
			ApplicationMonitorEvents.NativeFieldInfoPtr_OnApplicationStateChange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "OnApplicationStateChange");
			ApplicationMonitorEvents.NativeFieldInfoPtr_OnPlaySpaceCentered = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "OnPlaySpaceCentered");
			ApplicationMonitorEvents.NativeFieldInfoPtr__monitor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "_monitor");
			ApplicationMonitorEvents.NativeFieldInfoPtr__eventsRegistered = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "_eventsRegistered");
			ApplicationMonitorEvents.NativeFieldInfoPtr__currentState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "_currentState");
			ApplicationMonitorEvents.NativeFieldInfoPtr__playspaceCenterCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "_playspaceCenterCoroutine");
			ApplicationMonitorEvents.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "<ManagedLateUpdateRemoval>k__BackingField");
			ApplicationMonitorEvents.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688570);
			ApplicationMonitorEvents.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688571);
			ApplicationMonitorEvents.NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688572);
			ApplicationMonitorEvents.NativeMethodInfoPtr_Register_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688573);
			ApplicationMonitorEvents.NativeMethodInfoPtr_Unregister_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688574);
			ApplicationMonitorEvents.NativeMethodInfoPtr_OnApplicationFocus_Public_Virtual_New_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688575);
			ApplicationMonitorEvents.NativeMethodInfoPtr_OnApplicationPause_Public_Virtual_New_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688576);
			ApplicationMonitorEvents.NativeMethodInfoPtr_OnTimeScalePause_Public_Virtual_New_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688577);
			ApplicationMonitorEvents.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688578);
			ApplicationMonitorEvents.NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688579);
			ApplicationMonitorEvents.NativeMethodInfoPtr_InvokeOnPlaySpaceCentered_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688580);
			ApplicationMonitorEvents.NativeMethodInfoPtr_GetState_Public_Boolean_ApplicationStateType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688581);
			ApplicationMonitorEvents.NativeMethodInfoPtr_SetState_Protected_Void_ApplicationStateType_Boolean_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688582);
			ApplicationMonitorEvents.NativeMethodInfoPtr_PlayspaceCenterRoutine_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688583);
			ApplicationMonitorEvents.NativeMethodInfoPtr_RefreshAnyPause_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688584);
			ApplicationMonitorEvents.NativeMethodInfoPtr_RefreshPlayerPresence_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688585);
			ApplicationMonitorEvents.NativeMethodInfoPtr_ApplicationMonitorLog_Protected_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, 100688586);
		}

		// Token: 0x06013CF3 RID: 81139 RVA: 0x00002988 File Offset: 0x00000B88
		public ApplicationMonitorEvents(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700705D RID: 28765
		// (get) Token: 0x06013CF4 RID: 81140 RVA: 0x004FBCB0 File Offset: 0x004F9EB0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr));
			}
		}

		// Token: 0x1700705E RID: 28766
		// (get) Token: 0x06013CF5 RID: 81141 RVA: 0x004FBCC4 File Offset: 0x004F9EC4
		// (set) Token: 0x06013CF6 RID: 81142 RVA: 0x004FBCF8 File Offset: 0x004F9EF8
		public unsafe Action<ApplicationStateType, bool> OnApplicationStateChange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr_OnApplicationStateChange);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<ApplicationStateType, bool>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr_OnApplicationStateChange), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700705F RID: 28767
		// (get) Token: 0x06013CF7 RID: 81143 RVA: 0x004FBD20 File Offset: 0x004F9F20
		// (set) Token: 0x06013CF8 RID: 81144 RVA: 0x004FBD54 File Offset: 0x004F9F54
		public unsafe Action OnPlaySpaceCentered
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr_OnPlaySpaceCentered);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr_OnPlaySpaceCentered), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007060 RID: 28768
		// (get) Token: 0x06013CF9 RID: 81145 RVA: 0x004FBD7C File Offset: 0x004F9F7C
		// (set) Token: 0x06013CFA RID: 81146 RVA: 0x004FBDB0 File Offset: 0x004F9FB0
		public unsafe ApplicationMonitor _monitor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__monitor);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ApplicationMonitor(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__monitor), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007061 RID: 28769
		// (get) Token: 0x06013CFB RID: 81147 RVA: 0x004FBDD8 File Offset: 0x004F9FD8
		// (set) Token: 0x06013CFC RID: 81148 RVA: 0x004FBE00 File Offset: 0x004FA000
		public unsafe bool _eventsRegistered
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__eventsRegistered);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__eventsRegistered)) = value;
			}
		}

		// Token: 0x17007062 RID: 28770
		// (get) Token: 0x06013CFD RID: 81149 RVA: 0x004FBE24 File Offset: 0x004FA024
		// (set) Token: 0x06013CFE RID: 81150 RVA: 0x004FBE4C File Offset: 0x004FA04C
		public unsafe ApplicationStateType _currentState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__currentState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__currentState)) = value;
			}
		}

		// Token: 0x17007063 RID: 28771
		// (get) Token: 0x06013CFF RID: 81151 RVA: 0x004FBE70 File Offset: 0x004FA070
		// (set) Token: 0x06013D00 RID: 81152 RVA: 0x004FBEA4 File Offset: 0x004FA0A4
		public unsafe Coroutine _playspaceCenterCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__playspaceCenterCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__playspaceCenterCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007064 RID: 28772
		// (get) Token: 0x06013D01 RID: 81153 RVA: 0x004FBECC File Offset: 0x004FA0CC
		// (set) Token: 0x06013D02 RID: 81154 RVA: 0x004FBEF4 File Offset: 0x004FA0F4
		public unsafe bool _ManagedLateUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x0400CA89 RID: 51849
		private static readonly IntPtr NativeFieldInfoPtr_OnApplicationStateChange;

		// Token: 0x0400CA8A RID: 51850
		private static readonly IntPtr NativeFieldInfoPtr_OnPlaySpaceCentered;

		// Token: 0x0400CA8B RID: 51851
		private static readonly IntPtr NativeFieldInfoPtr__monitor;

		// Token: 0x0400CA8C RID: 51852
		private static readonly IntPtr NativeFieldInfoPtr__eventsRegistered;

		// Token: 0x0400CA8D RID: 51853
		private static readonly IntPtr NativeFieldInfoPtr__currentState;

		// Token: 0x0400CA8E RID: 51854
		private static readonly IntPtr NativeFieldInfoPtr__playspaceCenterCoroutine;

		// Token: 0x0400CA8F RID: 51855
		private static readonly IntPtr NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField;

		// Token: 0x0400CA90 RID: 51856
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400CA91 RID: 51857
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400CA92 RID: 51858
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ApplicationMonitor_0;

		// Token: 0x0400CA93 RID: 51859
		private static readonly IntPtr NativeMethodInfoPtr_Register_Public_Virtual_New_Void_0;

		// Token: 0x0400CA94 RID: 51860
		private static readonly IntPtr NativeMethodInfoPtr_Unregister_Public_Virtual_New_Void_0;

		// Token: 0x0400CA95 RID: 51861
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationFocus_Public_Virtual_New_Void_Boolean_0;

		// Token: 0x0400CA96 RID: 51862
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationPause_Public_Virtual_New_Void_Boolean_0;

		// Token: 0x0400CA97 RID: 51863
		private static readonly IntPtr NativeMethodInfoPtr_OnTimeScalePause_Public_Virtual_New_Void_Boolean_0;

		// Token: 0x0400CA98 RID: 51864
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400CA99 RID: 51865
		private static readonly IntPtr NativeMethodInfoPtr_Tick_Protected_Virtual_New_Void_0;

		// Token: 0x0400CA9A RID: 51866
		private static readonly IntPtr NativeMethodInfoPtr_InvokeOnPlaySpaceCentered_Protected_Void_0;

		// Token: 0x0400CA9B RID: 51867
		private static readonly IntPtr NativeMethodInfoPtr_GetState_Public_Boolean_ApplicationStateType_0;

		// Token: 0x0400CA9C RID: 51868
		private static readonly IntPtr NativeMethodInfoPtr_SetState_Protected_Void_ApplicationStateType_Boolean_Boolean_0;

		// Token: 0x0400CA9D RID: 51869
		private static readonly IntPtr NativeMethodInfoPtr_PlayspaceCenterRoutine_Private_IEnumerator_0;

		// Token: 0x0400CA9E RID: 51870
		private static readonly IntPtr NativeMethodInfoPtr_RefreshAnyPause_Protected_Void_Boolean_0;

		// Token: 0x0400CA9F RID: 51871
		private static readonly IntPtr NativeMethodInfoPtr_RefreshPlayerPresence_Protected_Void_Boolean_0;

		// Token: 0x0400CAA0 RID: 51872
		private static readonly IntPtr NativeMethodInfoPtr_ApplicationMonitorLog_Protected_Void_String_0;

		// Token: 0x0200102D RID: 4141
		[ObfuscatedName("DPI.App.ApplicationMonitorEvents/<PlayspaceCenterRoutine>d__21")]
		public sealed class _PlayspaceCenterRoutine_d__21 : Il2CppSystem.Object
		{
			// Token: 0x06013D03 RID: 81155 RVA: 0x004FBF18 File Offset: 0x004FA118
			[CallerCount(0)]
			public unsafe _PlayspaceCenterRoutine_d__21(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013D04 RID: 81156 RVA: 0x004FBF78 File Offset: 0x004FA178
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013D05 RID: 81157 RVA: 0x004FBFBC File Offset: 0x004FA1BC
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x1700706A RID: 28778
			// (get) Token: 0x06013D06 RID: 81158 RVA: 0x004FC00C File Offset: 0x004FA20C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013D07 RID: 81159 RVA: 0x004FC064 File Offset: 0x004FA264
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x1700706B RID: 28779
			// (get) Token: 0x06013D08 RID: 81160 RVA: 0x004FC0A8 File Offset: 0x004FA2A8
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06013D09 RID: 81161 RVA: 0x004FC100 File Offset: 0x004FA300
			// Note: this type is marked as 'beforefieldinit'.
			static _PlayspaceCenterRoutine_d__21()
			{
				Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ApplicationMonitorEvents>.NativeClassPtr, "<PlayspaceCenterRoutine>d__21");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, "<>1__state");
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, "<>2__current");
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, "<>4__this");
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688587);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688588);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688589);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688590);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688591);
				ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr, 100688592);
			}

			// Token: 0x06013D0A RID: 81162 RVA: 0x00002988 File Offset: 0x00000B88
			public _PlayspaceCenterRoutine_d__21(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17007066 RID: 28774
			// (get) Token: 0x06013D0B RID: 81163 RVA: 0x004FC1DF File Offset: 0x004FA3DF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21>.NativeClassPtr));
				}
			}

			// Token: 0x17007067 RID: 28775
			// (get) Token: 0x06013D0C RID: 81164 RVA: 0x004FC1F0 File Offset: 0x004FA3F0
			// (set) Token: 0x06013D0D RID: 81165 RVA: 0x004FC218 File Offset: 0x004FA418
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17007068 RID: 28776
			// (get) Token: 0x06013D0E RID: 81166 RVA: 0x004FC23C File Offset: 0x004FA43C
			// (set) Token: 0x06013D0F RID: 81167 RVA: 0x004FC270 File Offset: 0x004FA470
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17007069 RID: 28777
			// (get) Token: 0x06013D10 RID: 81168 RVA: 0x004FC298 File Offset: 0x004FA498
			// (set) Token: 0x06013D11 RID: 81169 RVA: 0x004FC2CC File Offset: 0x004FA4CC
			public unsafe ApplicationMonitorEvents __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new ApplicationMonitorEvents(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ApplicationMonitorEvents._PlayspaceCenterRoutine_d__21.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400CAA1 RID: 51873
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400CAA2 RID: 51874
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400CAA3 RID: 51875
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400CAA4 RID: 51876
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400CAA5 RID: 51877
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400CAA6 RID: 51878
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400CAA7 RID: 51879
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400CAA8 RID: 51880
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400CAA9 RID: 51881
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
