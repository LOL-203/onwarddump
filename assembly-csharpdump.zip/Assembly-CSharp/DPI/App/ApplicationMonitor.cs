﻿using System;
using Il2CppSystem;
using Onward.GameStates;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.App
{
	// Token: 0x0200102B RID: 4139
	public class ApplicationMonitor : MonoBehaviour
	{
		// Token: 0x1700705A RID: 28762
		// (get) Token: 0x06013CCB RID: 81099 RVA: 0x004FADF0 File Offset: 0x004F8FF0
		// (set) Token: 0x06013CCC RID: 81100 RVA: 0x004FAE38 File Offset: 0x004F9038
		public unsafe static ApplicationMonitorEvents Events
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_get_Events_Public_Static_get_ApplicationMonitorEvents_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ApplicationMonitorEvents(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_set_Events_Private_Static_set_Void_ApplicationMonitorEvents_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700705B RID: 28763
		// (get) Token: 0x06013CCD RID: 81101 RVA: 0x004FAE84 File Offset: 0x004F9084
		public unsafe bool IsGamePausable
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_get_IsGamePausable_Private_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x1700705C RID: 28764
		// (get) Token: 0x06013CCE RID: 81102 RVA: 0x004FAED4 File Offset: 0x004F90D4
		public unsafe bool ShouldGameBePaused
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_get_ShouldGameBePaused_Private_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06013CCF RID: 81103 RVA: 0x004FAF24 File Offset: 0x004F9124
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD0 RID: 81104 RVA: 0x004FAF68 File Offset: 0x004F9168
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD1 RID: 81105 RVA: 0x004FAFAC File Offset: 0x004F91AC
		[CallerCount(0)]
		public unsafe void OnApplicationFocus(bool hasFocus)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref hasFocus;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD2 RID: 81106 RVA: 0x004FB000 File Offset: 0x004F9200
		[CallerCount(0)]
		public unsafe void OnApplicationPause(bool paused)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref paused;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD3 RID: 81107 RVA: 0x004FB054 File Offset: 0x004F9254
		[CallerCount(0)]
		public unsafe void RefreshGamePause()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_RefreshGamePause_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD4 RID: 81108 RVA: 0x004FB098 File Offset: 0x004F9298
		[CallerCount(0)]
		public unsafe void OnApplicationStateChange(ApplicationStateType type, bool state)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref type;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref state;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnApplicationStateChange_Private_Void_ApplicationStateType_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD5 RID: 81109 RVA: 0x004FB100 File Offset: 0x004F9300
		[CallerCount(0)]
		public unsafe void OnLoadedLevel(OnwardMap map)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref map;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnLoadedLevel_Private_Void_OnwardMap_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD6 RID: 81110 RVA: 0x004FB154 File Offset: 0x004F9354
		[CallerCount(0)]
		public unsafe void OnLocalGameStateExited(LocalGameState state)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(state);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnLocalGameStateExited_Private_Void_LocalGameState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD7 RID: 81111 RVA: 0x004FB1B0 File Offset: 0x004F93B0
		[CallerCount(0)]
		public unsafe void OnLocalGameStateEntered(LocalGameState state)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(state);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnLocalGameStateEntered_Private_Void_LocalGameState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD8 RID: 81112 RVA: 0x004FB20C File Offset: 0x004F940C
		[CallerCount(0)]
		public unsafe void OnOfflineModeChanged(bool offlineMode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref offlineMode;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr_OnOfflineModeChanged_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CD9 RID: 81113 RVA: 0x004FB260 File Offset: 0x004F9460
		[CallerCount(0)]
		public unsafe ApplicationMonitor() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ApplicationMonitor.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013CDA RID: 81114 RVA: 0x004FB2AC File Offset: 0x004F94AC
		// Note: this type is marked as 'beforefieldinit'.
		static ApplicationMonitor()
		{
			Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.App", "ApplicationMonitor");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr);
			ApplicationMonitor.NativeFieldInfoPtr__Events_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, "<Events>k__BackingField");
			ApplicationMonitor.NativeFieldInfoPtr__singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, "_singleton");
			ApplicationMonitor.NativeMethodInfoPtr_get_Events_Public_Static_get_ApplicationMonitorEvents_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688555);
			ApplicationMonitor.NativeMethodInfoPtr_set_Events_Private_Static_set_Void_ApplicationMonitorEvents_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688556);
			ApplicationMonitor.NativeMethodInfoPtr_get_IsGamePausable_Private_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688557);
			ApplicationMonitor.NativeMethodInfoPtr_get_ShouldGameBePaused_Private_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688558);
			ApplicationMonitor.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688559);
			ApplicationMonitor.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688560);
			ApplicationMonitor.NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688561);
			ApplicationMonitor.NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688562);
			ApplicationMonitor.NativeMethodInfoPtr_RefreshGamePause_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688563);
			ApplicationMonitor.NativeMethodInfoPtr_OnApplicationStateChange_Private_Void_ApplicationStateType_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688564);
			ApplicationMonitor.NativeMethodInfoPtr_OnLoadedLevel_Private_Void_OnwardMap_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688565);
			ApplicationMonitor.NativeMethodInfoPtr_OnLocalGameStateExited_Private_Void_LocalGameState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688566);
			ApplicationMonitor.NativeMethodInfoPtr_OnLocalGameStateEntered_Private_Void_LocalGameState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688567);
			ApplicationMonitor.NativeMethodInfoPtr_OnOfflineModeChanged_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688568);
			ApplicationMonitor.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr, 100688569);
		}

		// Token: 0x06013CDB RID: 81115 RVA: 0x0000210C File Offset: 0x0000030C
		public ApplicationMonitor(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007057 RID: 28759
		// (get) Token: 0x06013CDC RID: 81116 RVA: 0x004FB430 File Offset: 0x004F9630
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ApplicationMonitor>.NativeClassPtr));
			}
		}

		// Token: 0x17007058 RID: 28760
		// (get) Token: 0x06013CDD RID: 81117 RVA: 0x004FB444 File Offset: 0x004F9644
		// (set) Token: 0x06013CDE RID: 81118 RVA: 0x004FB46F File Offset: 0x004F966F
		public unsafe static ApplicationMonitorEvents _Events_k__BackingField
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ApplicationMonitor.NativeFieldInfoPtr__Events_k__BackingField, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ApplicationMonitorEvents(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ApplicationMonitor.NativeFieldInfoPtr__Events_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007059 RID: 28761
		// (get) Token: 0x06013CDF RID: 81119 RVA: 0x004FB484 File Offset: 0x004F9684
		// (set) Token: 0x06013CE0 RID: 81120 RVA: 0x004FB4AF File Offset: 0x004F96AF
		public unsafe static ApplicationMonitor _singleton
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ApplicationMonitor.NativeFieldInfoPtr__singleton, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ApplicationMonitor(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ApplicationMonitor.NativeFieldInfoPtr__singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CA78 RID: 51832
		private static readonly IntPtr NativeFieldInfoPtr__Events_k__BackingField;

		// Token: 0x0400CA79 RID: 51833
		private static readonly IntPtr NativeFieldInfoPtr__singleton;

		// Token: 0x0400CA7A RID: 51834
		private static readonly IntPtr NativeMethodInfoPtr_get_Events_Public_Static_get_ApplicationMonitorEvents_0;

		// Token: 0x0400CA7B RID: 51835
		private static readonly IntPtr NativeMethodInfoPtr_set_Events_Private_Static_set_Void_ApplicationMonitorEvents_0;

		// Token: 0x0400CA7C RID: 51836
		private static readonly IntPtr NativeMethodInfoPtr_get_IsGamePausable_Private_get_Boolean_0;

		// Token: 0x0400CA7D RID: 51837
		private static readonly IntPtr NativeMethodInfoPtr_get_ShouldGameBePaused_Private_get_Boolean_0;

		// Token: 0x0400CA7E RID: 51838
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400CA7F RID: 51839
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x0400CA80 RID: 51840
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationFocus_Private_Void_Boolean_0;

		// Token: 0x0400CA81 RID: 51841
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0;

		// Token: 0x0400CA82 RID: 51842
		private static readonly IntPtr NativeMethodInfoPtr_RefreshGamePause_Private_Void_0;

		// Token: 0x0400CA83 RID: 51843
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationStateChange_Private_Void_ApplicationStateType_Boolean_0;

		// Token: 0x0400CA84 RID: 51844
		private static readonly IntPtr NativeMethodInfoPtr_OnLoadedLevel_Private_Void_OnwardMap_0;

		// Token: 0x0400CA85 RID: 51845
		private static readonly IntPtr NativeMethodInfoPtr_OnLocalGameStateExited_Private_Void_LocalGameState_0;

		// Token: 0x0400CA86 RID: 51846
		private static readonly IntPtr NativeMethodInfoPtr_OnLocalGameStateEntered_Private_Void_LocalGameState_0;

		// Token: 0x0400CA87 RID: 51847
		private static readonly IntPtr NativeMethodInfoPtr_OnOfflineModeChanged_Private_Void_Boolean_0;

		// Token: 0x0400CA88 RID: 51848
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
