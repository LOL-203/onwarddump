﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200104D RID: 4173
	[Serializable]
	[StructLayout(0)]
	public sealed class ScribeAnalyticsEvent : ValueType
	{
		// Token: 0x170070B4 RID: 28852
		// (get) Token: 0x06013E05 RID: 81413 RVA: 0x00500074 File Offset: 0x004FE274
		public unsafe AnalyticsEventType EventType
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsEvent.NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06013E06 RID: 81414 RVA: 0x005000C4 File Offset: 0x004FE2C4
		[CallerCount(0)]
		public unsafe void SetEventType(AnalyticsEventType eventType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref eventType;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsEvent.NativeMethodInfoPtr_SetEventType_Public_Void_AnalyticsEventType_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E07 RID: 81415 RVA: 0x00500118 File Offset: 0x004FE318
		[CallerCount(0)]
		public unsafe ScribeAnalyticsEvent(AnalyticsEventType eventType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref eventType;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsEvent.NativeMethodInfoPtr__ctor_Public_Void_AnalyticsEventType_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E08 RID: 81416 RVA: 0x0050016C File Offset: 0x004FE36C
		// Note: this type is marked as 'beforefieldinit'.
		static ScribeAnalyticsEvent()
		{
			Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "ScribeAnalyticsEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr);
			ScribeAnalyticsEvent.NativeFieldInfoPtr__eventType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, "_eventType");
			ScribeAnalyticsEvent.NativeFieldInfoPtr_category = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, "category");
			ScribeAnalyticsEvent.NativeFieldInfoPtr_message = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, "message");
			ScribeAnalyticsEvent.NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, 100688696);
			ScribeAnalyticsEvent.NativeMethodInfoPtr_SetEventType_Public_Void_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, 100688697);
			ScribeAnalyticsEvent.NativeMethodInfoPtr__ctor_Public_Void_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, 100688698);
		}

		// Token: 0x06013E09 RID: 81417 RVA: 0x0002717B File Offset: 0x0002537B
		public ScribeAnalyticsEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070B0 RID: 28848
		// (get) Token: 0x06013E0A RID: 81418 RVA: 0x00500214 File Offset: 0x004FE414
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr));
			}
		}

		// Token: 0x06013E0B RID: 81419 RVA: 0x00500228 File Offset: 0x004FE428
		public unsafe ScribeAnalyticsEvent()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ScribeAnalyticsEvent>.NativeClassPtr, data));
		}

		// Token: 0x170070B1 RID: 28849
		// (get) Token: 0x06013E0C RID: 81420 RVA: 0x00500258 File Offset: 0x004FE458
		// (set) Token: 0x06013E0D RID: 81421 RVA: 0x00500280 File Offset: 0x004FE480
		public unsafe AnalyticsEventType _eventType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr__eventType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr__eventType)) = value;
			}
		}

		// Token: 0x170070B2 RID: 28850
		// (get) Token: 0x06013E0E RID: 81422 RVA: 0x005002A4 File Offset: 0x004FE4A4
		// (set) Token: 0x06013E0F RID: 81423 RVA: 0x005002CD File Offset: 0x004FE4CD
		public unsafe string category
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr_category);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr_category), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070B3 RID: 28851
		// (get) Token: 0x06013E10 RID: 81424 RVA: 0x005002F4 File Offset: 0x004FE4F4
		// (set) Token: 0x06013E11 RID: 81425 RVA: 0x0050031D File Offset: 0x004FE51D
		public unsafe string message
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr_message);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsEvent.NativeFieldInfoPtr_message), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CB55 RID: 52053
		private static readonly IntPtr NativeFieldInfoPtr__eventType;

		// Token: 0x0400CB56 RID: 52054
		private static readonly IntPtr NativeFieldInfoPtr_category;

		// Token: 0x0400CB57 RID: 52055
		private static readonly IntPtr NativeFieldInfoPtr_message;

		// Token: 0x0400CB58 RID: 52056
		private static readonly IntPtr NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0;

		// Token: 0x0400CB59 RID: 52057
		private static readonly IntPtr NativeMethodInfoPtr_SetEventType_Public_Void_AnalyticsEventType_0;

		// Token: 0x0400CB5A RID: 52058
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_AnalyticsEventType_0;
	}
}
