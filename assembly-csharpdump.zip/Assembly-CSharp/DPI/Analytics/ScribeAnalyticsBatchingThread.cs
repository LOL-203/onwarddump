﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Runtime.CompilerServices;
using Il2CppSystem.Threading;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001053 RID: 4179
	public class ScribeAnalyticsBatchingThread : Object
	{
		// Token: 0x170070D4 RID: 28884
		// (get) Token: 0x06013E4C RID: 81484 RVA: 0x00501184 File Offset: 0x004FF384
		public unsafe int Count
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_Count_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070D5 RID: 28885
		// (get) Token: 0x06013E4D RID: 81485 RVA: 0x005011D4 File Offset: 0x004FF3D4
		public unsafe ScribeAnalyticsBatch ActiveBatch
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_ActiveBatch_Public_get_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ScribeAnalyticsBatch(intPtr2) : null;
			}
		}

		// Token: 0x170070D6 RID: 28886
		// (get) Token: 0x06013E4E RID: 81486 RVA: 0x0050122C File Offset: 0x004FF42C
		public unsafe bool IsSending
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_IsSending_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070D7 RID: 28887
		// (get) Token: 0x06013E4F RID: 81487 RVA: 0x0050127C File Offset: 0x004FF47C
		public unsafe float TimeOfLastSend
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_TimeOfLastSend_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06013E50 RID: 81488 RVA: 0x005012CC File Offset: 0x004FF4CC
		[CallerCount(0)]
		public unsafe void Initialize(Action<ScribeAnalyticsBatch> sendBatchEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(sendBatchEvent);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_Initialize_Public_Void_Action_1_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E51 RID: 81489 RVA: 0x00501328 File Offset: 0x004FF528
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_Uninitialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E52 RID: 81490 RVA: 0x0050136C File Offset: 0x004FF56C
		[CallerCount(0)]
		public unsafe void OnBatchFinished()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_OnBatchFinished_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E53 RID: 81491 RVA: 0x005013B0 File Offset: 0x004FF5B0
		[CallerCount(0)]
		public unsafe void QueueBatch(ScribeAnalyticsBatch batch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_QueueBatch_Public_Void_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E54 RID: 81492 RVA: 0x0050140C File Offset: 0x004FF60C
		[CallerCount(0)]
		public unsafe void TriggerAsyncSend()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_TriggerAsyncSend_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E55 RID: 81493 RVA: 0x00501450 File Offset: 0x004FF650
		[CallerCount(0)]
		public unsafe void TriggerImmediateSend(ScribeAnalyticsBatch batch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_TriggerImmediateSend_Public_Void_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E56 RID: 81494 RVA: 0x005014AC File Offset: 0x004FF6AC
		[CallerCount(0)]
		public unsafe ScribeAnalyticsBatch FlushToSingleBatch(ScribeAnalyticsBatch batch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_FlushToSingleBatch_Private_ScribeAnalyticsBatch_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new ScribeAnalyticsBatch(intPtr2) : null;
		}

		// Token: 0x06013E57 RID: 81495 RVA: 0x0050151C File Offset: 0x004FF71C
		[CallerCount(0)]
		public unsafe void ThreadedBatchSender()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_ThreadedBatchSender_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E58 RID: 81496 RVA: 0x00501560 File Offset: 0x004FF760
		[CallerCount(0)]
		public unsafe ScribeAnalyticsBatchingThread() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E59 RID: 81497 RVA: 0x005015AC File Offset: 0x004FF7AC
		// Note: this type is marked as 'beforefieldinit'.
		static ScribeAnalyticsBatchingThread()
		{
			Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "ScribeAnalyticsBatchingThread");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr);
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__lock = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_lock");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchingThread = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_batchingThread");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__cancelSource = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_cancelSource");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchSendWaitEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_batchSendWaitEvent");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchedAnalytics = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_batchedAnalytics");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__sendBatch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_sendBatch");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__activeBatch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_activeBatch");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__timeOfLastBatchSend = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_timeOfLastBatchSend");
			ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__isSendingBatch = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "_isSendingBatch");
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_Count_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688718);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_ActiveBatch_Public_get_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688719);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_IsSending_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688720);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_get_TimeOfLastSend_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688721);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_Initialize_Public_Void_Action_1_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688722);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_Uninitialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688723);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_OnBatchFinished_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688724);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_QueueBatch_Public_Void_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688725);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_TriggerAsyncSend_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688726);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_TriggerImmediateSend_Public_Void_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688727);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_FlushToSingleBatch_Private_ScribeAnalyticsBatch_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688728);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr_ThreadedBatchSender_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688729);
			ScribeAnalyticsBatchingThread.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, 100688730);
		}

		// Token: 0x06013E5A RID: 81498 RVA: 0x00002988 File Offset: 0x00000B88
		public ScribeAnalyticsBatchingThread(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070CA RID: 28874
		// (get) Token: 0x06013E5B RID: 81499 RVA: 0x00501794 File Offset: 0x004FF994
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr));
			}
		}

		// Token: 0x170070CB RID: 28875
		// (get) Token: 0x06013E5C RID: 81500 RVA: 0x005017A8 File Offset: 0x004FF9A8
		// (set) Token: 0x06013E5D RID: 81501 RVA: 0x005017DC File Offset: 0x004FF9DC
		public unsafe Object _lock
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__lock);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__lock), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070CC RID: 28876
		// (get) Token: 0x06013E5E RID: 81502 RVA: 0x00501804 File Offset: 0x004FFA04
		// (set) Token: 0x06013E5F RID: 81503 RVA: 0x00501838 File Offset: 0x004FFA38
		public unsafe Thread _batchingThread
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchingThread);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Thread(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchingThread), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070CD RID: 28877
		// (get) Token: 0x06013E60 RID: 81504 RVA: 0x00501860 File Offset: 0x004FFA60
		// (set) Token: 0x06013E61 RID: 81505 RVA: 0x00501894 File Offset: 0x004FFA94
		public unsafe CancellationTokenSource _cancelSource
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__cancelSource);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CancellationTokenSource(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__cancelSource), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070CE RID: 28878
		// (get) Token: 0x06013E62 RID: 81506 RVA: 0x005018BC File Offset: 0x004FFABC
		// (set) Token: 0x06013E63 RID: 81507 RVA: 0x005018F0 File Offset: 0x004FFAF0
		public unsafe AutoResetEvent _batchSendWaitEvent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchSendWaitEvent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AutoResetEvent(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchSendWaitEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070CF RID: 28879
		// (get) Token: 0x06013E64 RID: 81508 RVA: 0x00501918 File Offset: 0x004FFB18
		// (set) Token: 0x06013E65 RID: 81509 RVA: 0x0050194C File Offset: 0x004FFB4C
		public unsafe Queue<ScribeAnalyticsBatch> _batchedAnalytics
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchedAnalytics);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Queue<ScribeAnalyticsBatch>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__batchedAnalytics), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070D0 RID: 28880
		// (get) Token: 0x06013E66 RID: 81510 RVA: 0x00501974 File Offset: 0x004FFB74
		// (set) Token: 0x06013E67 RID: 81511 RVA: 0x005019A8 File Offset: 0x004FFBA8
		public unsafe Action<ScribeAnalyticsBatch> _sendBatch
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__sendBatch);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<ScribeAnalyticsBatch>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__sendBatch), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070D1 RID: 28881
		// (get) Token: 0x06013E68 RID: 81512 RVA: 0x005019D0 File Offset: 0x004FFBD0
		// (set) Token: 0x06013E69 RID: 81513 RVA: 0x00501A04 File Offset: 0x004FFC04
		public unsafe ScribeAnalyticsBatch _activeBatch
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__activeBatch);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ScribeAnalyticsBatch(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__activeBatch), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070D2 RID: 28882
		// (get) Token: 0x06013E6A RID: 81514 RVA: 0x00501A2C File Offset: 0x004FFC2C
		// (set) Token: 0x06013E6B RID: 81515 RVA: 0x00501A54 File Offset: 0x004FFC54
		public unsafe float _timeOfLastBatchSend
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__timeOfLastBatchSend);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__timeOfLastBatchSend)) = value;
			}
		}

		// Token: 0x170070D3 RID: 28883
		// (get) Token: 0x06013E6C RID: 81516 RVA: 0x00501A78 File Offset: 0x004FFC78
		// (set) Token: 0x06013E6D RID: 81517 RVA: 0x00501AA0 File Offset: 0x004FFCA0
		public unsafe bool _isSendingBatch
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__isSendingBatch);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread.NativeFieldInfoPtr__isSendingBatch)) = value;
			}
		}

		// Token: 0x0400CB79 RID: 52089
		private static readonly IntPtr NativeFieldInfoPtr__lock;

		// Token: 0x0400CB7A RID: 52090
		private static readonly IntPtr NativeFieldInfoPtr__batchingThread;

		// Token: 0x0400CB7B RID: 52091
		private static readonly IntPtr NativeFieldInfoPtr__cancelSource;

		// Token: 0x0400CB7C RID: 52092
		private static readonly IntPtr NativeFieldInfoPtr__batchSendWaitEvent;

		// Token: 0x0400CB7D RID: 52093
		private static readonly IntPtr NativeFieldInfoPtr__batchedAnalytics;

		// Token: 0x0400CB7E RID: 52094
		private static readonly IntPtr NativeFieldInfoPtr__sendBatch;

		// Token: 0x0400CB7F RID: 52095
		private static readonly IntPtr NativeFieldInfoPtr__activeBatch;

		// Token: 0x0400CB80 RID: 52096
		private static readonly IntPtr NativeFieldInfoPtr__timeOfLastBatchSend;

		// Token: 0x0400CB81 RID: 52097
		private static readonly IntPtr NativeFieldInfoPtr__isSendingBatch;

		// Token: 0x0400CB82 RID: 52098
		private static readonly IntPtr NativeMethodInfoPtr_get_Count_Public_get_Int32_0;

		// Token: 0x0400CB83 RID: 52099
		private static readonly IntPtr NativeMethodInfoPtr_get_ActiveBatch_Public_get_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB84 RID: 52100
		private static readonly IntPtr NativeMethodInfoPtr_get_IsSending_Public_get_Boolean_0;

		// Token: 0x0400CB85 RID: 52101
		private static readonly IntPtr NativeMethodInfoPtr_get_TimeOfLastSend_Public_get_Single_0;

		// Token: 0x0400CB86 RID: 52102
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_Action_1_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB87 RID: 52103
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Void_0;

		// Token: 0x0400CB88 RID: 52104
		private static readonly IntPtr NativeMethodInfoPtr_OnBatchFinished_Public_Void_0;

		// Token: 0x0400CB89 RID: 52105
		private static readonly IntPtr NativeMethodInfoPtr_QueueBatch_Public_Void_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB8A RID: 52106
		private static readonly IntPtr NativeMethodInfoPtr_TriggerAsyncSend_Public_Void_0;

		// Token: 0x0400CB8B RID: 52107
		private static readonly IntPtr NativeMethodInfoPtr_TriggerImmediateSend_Public_Void_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB8C RID: 52108
		private static readonly IntPtr NativeMethodInfoPtr_FlushToSingleBatch_Private_ScribeAnalyticsBatch_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB8D RID: 52109
		private static readonly IntPtr NativeMethodInfoPtr_ThreadedBatchSender_Private_Void_0;

		// Token: 0x0400CB8E RID: 52110
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001054 RID: 4180
		[ObfuscatedName("DPI.Analytics.ScribeAnalyticsBatchingThread/<ThreadedBatchSender>d__24")]
		public sealed class _ThreadedBatchSender_d__24 : ValueType
		{
			// Token: 0x06013E6E RID: 81518 RVA: 0x00501AC4 File Offset: 0x004FFCC4
			[CallerCount(0)]
			public unsafe void MoveNext()
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013E6F RID: 81519 RVA: 0x00501B04 File Offset: 0x004FFD04
			[CallerCount(0)]
			public unsafe void SetStateMachine(IAsyncStateMachine stateMachine)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(stateMachine);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013E70 RID: 81520 RVA: 0x00501B5C File Offset: 0x004FFD5C
			// Note: this type is marked as 'beforefieldinit'.
			static _ThreadedBatchSender_d__24()
			{
				Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread>.NativeClassPtr, "<ThreadedBatchSender>d__24");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr);
				ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, "<>1__state");
				ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___t__builder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, "<>t__builder");
				ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, "<>4__this");
				ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, 100688731);
				ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, 100688732);
			}

			// Token: 0x06013E71 RID: 81521 RVA: 0x0002717B File Offset: 0x0002537B
			public _ThreadedBatchSender_d__24(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170070D8 RID: 28888
			// (get) Token: 0x06013E72 RID: 81522 RVA: 0x00501BEB File Offset: 0x004FFDEB
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr));
				}
			}

			// Token: 0x06013E73 RID: 81523 RVA: 0x00501BFC File Offset: 0x004FFDFC
			public unsafe _ThreadedBatchSender_d__24()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24>.NativeClassPtr, data));
			}

			// Token: 0x170070D9 RID: 28889
			// (get) Token: 0x06013E74 RID: 81524 RVA: 0x00501C2C File Offset: 0x004FFE2C
			// (set) Token: 0x06013E75 RID: 81525 RVA: 0x00501C54 File Offset: 0x004FFE54
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x170070DA RID: 28890
			// (get) Token: 0x06013E76 RID: 81526 RVA: 0x00501C78 File Offset: 0x004FFE78
			// (set) Token: 0x06013E77 RID: 81527 RVA: 0x00501CAA File Offset: 0x004FFEAA
			public AsyncVoidMethodBuilder __t__builder
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___t__builder);
					return new AsyncVoidMethodBuilder(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncVoidMethodBuilder>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___t__builder), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncVoidMethodBuilder>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x170070DB RID: 28891
			// (get) Token: 0x06013E78 RID: 81528 RVA: 0x00501CE0 File Offset: 0x004FFEE0
			// (set) Token: 0x06013E79 RID: 81529 RVA: 0x00501D14 File Offset: 0x004FFF14
			public unsafe ScribeAnalyticsBatchingThread __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new ScribeAnalyticsBatchingThread(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatchingThread._ThreadedBatchSender_d__24.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400CB8F RID: 52111
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400CB90 RID: 52112
			private static readonly IntPtr NativeFieldInfoPtr___t__builder;

			// Token: 0x0400CB91 RID: 52113
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400CB92 RID: 52114
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400CB93 RID: 52115
			private static readonly IntPtr NativeMethodInfoPtr_SetStateMachine_Private_Virtual_Final_New_Void_IAsyncStateMachine_0;
		}
	}
}
