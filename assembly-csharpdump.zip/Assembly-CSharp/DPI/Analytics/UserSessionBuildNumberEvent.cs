﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001037 RID: 4151
	public class UserSessionBuildNumberEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D63 RID: 81251 RVA: 0x004FD8C8 File Offset: 0x004FBAC8
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionBuildNumberEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D64 RID: 81252 RVA: 0x004FD918 File Offset: 0x004FBB18
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionBuildNumberEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D65 RID: 81253 RVA: 0x004FD968 File Offset: 0x004FBB68
		[CallerCount(0)]
		public unsafe UserSessionBuildNumberEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionBuildNumberEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D66 RID: 81254 RVA: 0x004FD9B4 File Offset: 0x004FBBB4
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionBuildNumberEvent()
		{
			Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionBuildNumberEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr);
			UserSessionBuildNumberEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr, 100688633);
			UserSessionBuildNumberEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr, 100688634);
			UserSessionBuildNumberEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr, 100688635);
		}

		// Token: 0x06013D67 RID: 81255 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionBuildNumberEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007086 RID: 28806
		// (get) Token: 0x06013D68 RID: 81256 RVA: 0x004FDA29 File Offset: 0x004FBC29
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionBuildNumberEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CAF8 RID: 51960
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAF9 RID: 51961
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAFA RID: 51962
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
