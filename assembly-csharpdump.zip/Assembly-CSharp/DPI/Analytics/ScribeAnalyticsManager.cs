﻿using System;
using DPI.Web;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001055 RID: 4181
	public class ScribeAnalyticsManager : AnalyticsManager
	{
		// Token: 0x06013E7A RID: 81530 RVA: 0x00501D3C File Offset: 0x004FFF3C
		[CallerCount(0)]
		public new unsafe void OnAnalyticsInitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ScribeAnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E7B RID: 81531 RVA: 0x00501D8C File Offset: 0x004FFF8C
		[CallerCount(0)]
		public new unsafe void OnApplicationQuit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ScribeAnalyticsManager.NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E7C RID: 81532 RVA: 0x00501DDC File Offset: 0x004FFFDC
		[CallerCount(0)]
		public new unsafe void InternalSendAnalyticsEvent<T>(T newEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = newEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref newEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ScribeAnalyticsManager.MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0<T>.Pointer), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E7D RID: 81533 RVA: 0x00501E94 File Offset: 0x00500094
		[CallerCount(0)]
		public new unsafe void InternalUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ScribeAnalyticsManager.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E7E RID: 81534 RVA: 0x00501EE4 File Offset: 0x005000E4
		[CallerCount(0)]
		public new unsafe void FlushAllEvents()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ScribeAnalyticsManager.NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E7F RID: 81535 RVA: 0x00501F34 File Offset: 0x00500134
		[CallerCount(0)]
		public unsafe bool TryGetBatchOfType(AnalyticsEventType eventType, out ScribeAnalyticsBatch batch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref eventType;
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_TryGetBatchOfType_Private_Boolean_AnalyticsEventType_byref_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			batch = ((intPtr2 == 0) ? null : new ScribeAnalyticsBatch(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013E80 RID: 81536 RVA: 0x00501FD0 File Offset: 0x005001D0
		[CallerCount(0)]
		public unsafe void OnBatchAttempted(ScribeAnalyticsBatch batch, bool success)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref success;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchAttempted_Private_Void_ScribeAnalyticsBatch_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E81 RID: 81537 RVA: 0x0050203C File Offset: 0x0050023C
		[CallerCount(0)]
		public unsafe void CheckToQueueStandardAndUserEvents()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_CheckToQueueStandardAndUserEvents_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E82 RID: 81538 RVA: 0x00502080 File Offset: 0x00500280
		[CallerCount(0)]
		public unsafe void CheckToSendNextBatch()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_CheckToSendNextBatch_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E83 RID: 81539 RVA: 0x005020C4 File Offset: 0x005002C4
		[CallerCount(0)]
		public unsafe void SendBatch(ScribeAnalyticsBatch batch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(batch);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_SendBatch_Private_Void_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E84 RID: 81540 RVA: 0x00502120 File Offset: 0x00500320
		[CallerCount(0)]
		public unsafe void OnBatchSuccess(string responseJson)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(responseJson);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchSuccess_Private_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E85 RID: 81541 RVA: 0x0050217C File Offset: 0x0050037C
		[CallerCount(0)]
		public unsafe void OnBatchFailed(Exception e, FailedPostRequest failedPostRequest)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(e);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(failedPostRequest));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchFailed_Private_Void_Exception_FailedPostRequest_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E86 RID: 81542 RVA: 0x005021F4 File Offset: 0x005003F4
		[CallerCount(0)]
		public unsafe string GetScribeCategory<T>(T scribeEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = scribeEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref scribeEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.MethodInfoStoreGeneric_GetScribeCategory_Private_String_T_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06013E87 RID: 81543 RVA: 0x005022AC File Offset: 0x005004AC
		[CallerCount(0)]
		public unsafe ScribeAnalyticsManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E88 RID: 81544 RVA: 0x005022F8 File Offset: 0x005004F8
		// Note: this type is marked as 'beforefieldinit'.
		static ScribeAnalyticsManager()
		{
			Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "ScribeAnalyticsManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr);
			ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_BETWEEN_STANDARD_BATCHING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "SECONDS_BETWEEN_STANDARD_BATCHING");
			ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_TO_WAIT_BETWEEN_SENDS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "SECONDS_TO_WAIT_BETWEEN_SENDS");
			ScribeAnalyticsManager.NativeFieldInfoPtr_ONWARD_USER_SESSION_CAT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "ONWARD_USER_SESSION_CAT");
			ScribeAnalyticsManager.NativeFieldInfoPtr__unsentScribeEvents = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "_unsentScribeEvents");
			ScribeAnalyticsManager.NativeFieldInfoPtr__scribeAnalyticsBatchingThread = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "_scribeAnalyticsBatchingThread");
			ScribeAnalyticsManager.NativeFieldInfoPtr__timeOfNextStandardBatchCheck = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, "_timeOfNextStandardBatchCheck");
			ScribeAnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688733);
			ScribeAnalyticsManager.NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688734);
			ScribeAnalyticsManager.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688735);
			ScribeAnalyticsManager.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688736);
			ScribeAnalyticsManager.NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688737);
			ScribeAnalyticsManager.NativeMethodInfoPtr_TryGetBatchOfType_Private_Boolean_AnalyticsEventType_byref_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688738);
			ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchAttempted_Private_Void_ScribeAnalyticsBatch_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688739);
			ScribeAnalyticsManager.NativeMethodInfoPtr_CheckToQueueStandardAndUserEvents_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688740);
			ScribeAnalyticsManager.NativeMethodInfoPtr_CheckToSendNextBatch_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688741);
			ScribeAnalyticsManager.NativeMethodInfoPtr_SendBatch_Private_Void_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688742);
			ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchSuccess_Private_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688743);
			ScribeAnalyticsManager.NativeMethodInfoPtr_OnBatchFailed_Private_Void_Exception_FailedPostRequest_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688744);
			ScribeAnalyticsManager.NativeMethodInfoPtr_GetScribeCategory_Private_String_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688745);
			ScribeAnalyticsManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr, 100688746);
		}

		// Token: 0x06013E89 RID: 81545 RVA: 0x004FF7F0 File Offset: 0x004FD9F0
		public ScribeAnalyticsManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070DC RID: 28892
		// (get) Token: 0x06013E8A RID: 81546 RVA: 0x005024B8 File Offset: 0x005006B8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr));
			}
		}

		// Token: 0x170070DD RID: 28893
		// (get) Token: 0x06013E8B RID: 81547 RVA: 0x005024CC File Offset: 0x005006CC
		// (set) Token: 0x06013E8C RID: 81548 RVA: 0x005024EA File Offset: 0x005006EA
		public unsafe static int SECONDS_BETWEEN_STANDARD_BATCHING
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_BETWEEN_STANDARD_BATCHING, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_BETWEEN_STANDARD_BATCHING, (void*)(&value));
			}
		}

		// Token: 0x170070DE RID: 28894
		// (get) Token: 0x06013E8D RID: 81549 RVA: 0x005024FC File Offset: 0x005006FC
		// (set) Token: 0x06013E8E RID: 81550 RVA: 0x0050251A File Offset: 0x0050071A
		public unsafe static int SECONDS_TO_WAIT_BETWEEN_SENDS
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_TO_WAIT_BETWEEN_SENDS, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ScribeAnalyticsManager.NativeFieldInfoPtr_SECONDS_TO_WAIT_BETWEEN_SENDS, (void*)(&value));
			}
		}

		// Token: 0x170070DF RID: 28895
		// (get) Token: 0x06013E8F RID: 81551 RVA: 0x0050252C File Offset: 0x0050072C
		// (set) Token: 0x06013E90 RID: 81552 RVA: 0x0050254C File Offset: 0x0050074C
		public unsafe static string ONWARD_USER_SESSION_CAT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ScribeAnalyticsManager.NativeFieldInfoPtr_ONWARD_USER_SESSION_CAT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ScribeAnalyticsManager.NativeFieldInfoPtr_ONWARD_USER_SESSION_CAT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070E0 RID: 28896
		// (get) Token: 0x06013E91 RID: 81553 RVA: 0x00502564 File Offset: 0x00500764
		// (set) Token: 0x06013E92 RID: 81554 RVA: 0x00502598 File Offset: 0x00500798
		public unsafe List<ScribeAnalyticsEvent> _unsentScribeEvents
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__unsentScribeEvents);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<ScribeAnalyticsEvent>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__unsentScribeEvents), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070E1 RID: 28897
		// (get) Token: 0x06013E93 RID: 81555 RVA: 0x005025C0 File Offset: 0x005007C0
		// (set) Token: 0x06013E94 RID: 81556 RVA: 0x005025F4 File Offset: 0x005007F4
		public unsafe ScribeAnalyticsBatchingThread _scribeAnalyticsBatchingThread
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__scribeAnalyticsBatchingThread);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ScribeAnalyticsBatchingThread(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__scribeAnalyticsBatchingThread), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070E2 RID: 28898
		// (get) Token: 0x06013E95 RID: 81557 RVA: 0x0050261C File Offset: 0x0050081C
		// (set) Token: 0x06013E96 RID: 81558 RVA: 0x00502644 File Offset: 0x00500844
		public unsafe float _timeOfNextStandardBatchCheck
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__timeOfNextStandardBatchCheck);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsManager.NativeFieldInfoPtr__timeOfNextStandardBatchCheck)) = value;
			}
		}

		// Token: 0x0400CB94 RID: 52116
		private static readonly IntPtr NativeFieldInfoPtr_SECONDS_BETWEEN_STANDARD_BATCHING;

		// Token: 0x0400CB95 RID: 52117
		private static readonly IntPtr NativeFieldInfoPtr_SECONDS_TO_WAIT_BETWEEN_SENDS;

		// Token: 0x0400CB96 RID: 52118
		private static readonly IntPtr NativeFieldInfoPtr_ONWARD_USER_SESSION_CAT;

		// Token: 0x0400CB97 RID: 52119
		private static readonly IntPtr NativeFieldInfoPtr__unsentScribeEvents;

		// Token: 0x0400CB98 RID: 52120
		private static readonly IntPtr NativeFieldInfoPtr__scribeAnalyticsBatchingThread;

		// Token: 0x0400CB99 RID: 52121
		private static readonly IntPtr NativeFieldInfoPtr__timeOfNextStandardBatchCheck;

		// Token: 0x0400CB9A RID: 52122
		private static readonly IntPtr NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_Void_0;

		// Token: 0x0400CB9B RID: 52123
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_Void_0;

		// Token: 0x0400CB9C RID: 52124
		private static readonly IntPtr NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0;

		// Token: 0x0400CB9D RID: 52125
		private static readonly IntPtr NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0;

		// Token: 0x0400CB9E RID: 52126
		private static readonly IntPtr NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0;

		// Token: 0x0400CB9F RID: 52127
		private static readonly IntPtr NativeMethodInfoPtr_TryGetBatchOfType_Private_Boolean_AnalyticsEventType_byref_ScribeAnalyticsBatch_0;

		// Token: 0x0400CBA0 RID: 52128
		private static readonly IntPtr NativeMethodInfoPtr_OnBatchAttempted_Private_Void_ScribeAnalyticsBatch_Boolean_0;

		// Token: 0x0400CBA1 RID: 52129
		private static readonly IntPtr NativeMethodInfoPtr_CheckToQueueStandardAndUserEvents_Private_Void_0;

		// Token: 0x0400CBA2 RID: 52130
		private static readonly IntPtr NativeMethodInfoPtr_CheckToSendNextBatch_Private_Void_0;

		// Token: 0x0400CBA3 RID: 52131
		private static readonly IntPtr NativeMethodInfoPtr_SendBatch_Private_Void_ScribeAnalyticsBatch_0;

		// Token: 0x0400CBA4 RID: 52132
		private static readonly IntPtr NativeMethodInfoPtr_OnBatchSuccess_Private_Void_String_0;

		// Token: 0x0400CBA5 RID: 52133
		private static readonly IntPtr NativeMethodInfoPtr_OnBatchFailed_Private_Void_Exception_FailedPostRequest_0;

		// Token: 0x0400CBA6 RID: 52134
		private static readonly IntPtr NativeMethodInfoPtr_GetScribeCategory_Private_String_T_0;

		// Token: 0x0400CBA7 RID: 52135
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001056 RID: 4182
		private sealed class MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0<T>
		{
			// Token: 0x0400CBA8 RID: 52136
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(ScribeAnalyticsManager.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0, Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x02001057 RID: 4183
		private sealed class MethodInfoStoreGeneric_GetScribeCategory_Private_String_T_0<T>
		{
			// Token: 0x0400CBA9 RID: 52137
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(ScribeAnalyticsManager.NativeMethodInfoPtr_GetScribeCategory_Private_String_T_0, Il2CppClassPointerStore<ScribeAnalyticsManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
