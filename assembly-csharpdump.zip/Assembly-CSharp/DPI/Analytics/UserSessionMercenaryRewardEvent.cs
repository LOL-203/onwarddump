﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103D RID: 4157
	public class UserSessionMercenaryRewardEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D8E RID: 81294 RVA: 0x004FE354 File Offset: 0x004FC554
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionMercenaryRewardEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D8F RID: 81295 RVA: 0x004FE3A4 File Offset: 0x004FC5A4
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionMercenaryRewardEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D90 RID: 81296 RVA: 0x004FE3F4 File Offset: 0x004FC5F4
		[CallerCount(0)]
		public unsafe UserSessionMercenaryRewardEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionMercenaryRewardEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D91 RID: 81297 RVA: 0x004FE440 File Offset: 0x004FC640
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionMercenaryRewardEvent()
		{
			Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionMercenaryRewardEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr);
			UserSessionMercenaryRewardEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr, 100688654);
			UserSessionMercenaryRewardEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr, 100688655);
			UserSessionMercenaryRewardEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr, 100688656);
		}

		// Token: 0x06013D92 RID: 81298 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionMercenaryRewardEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007090 RID: 28816
		// (get) Token: 0x06013D93 RID: 81299 RVA: 0x004FE4AC File Offset: 0x004FC6AC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionMercenaryRewardEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB0F RID: 51983
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB10 RID: 51984
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB11 RID: 51985
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
