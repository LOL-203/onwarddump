﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001038 RID: 4152
	public class UserSessionDeeplinkEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D69 RID: 81257 RVA: 0x004FDA3C File Offset: 0x004FBC3C
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionDeeplinkEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D6A RID: 81258 RVA: 0x004FDA8C File Offset: 0x004FBC8C
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionDeeplinkEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D6B RID: 81259 RVA: 0x004FDADC File Offset: 0x004FBCDC
		[CallerCount(0)]
		public unsafe UserSessionDeeplinkEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionDeeplinkEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D6C RID: 81260 RVA: 0x004FDB28 File Offset: 0x004FBD28
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionDeeplinkEvent()
		{
			Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionDeeplinkEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr);
			UserSessionDeeplinkEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr, 100688636);
			UserSessionDeeplinkEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr, 100688637);
			UserSessionDeeplinkEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr, 100688638);
		}

		// Token: 0x06013D6D RID: 81261 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionDeeplinkEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007087 RID: 28807
		// (get) Token: 0x06013D6E RID: 81262 RVA: 0x004FDB94 File Offset: 0x004FBD94
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionDeeplinkEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CAFB RID: 51963
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAFC RID: 51964
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAFD RID: 51965
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
