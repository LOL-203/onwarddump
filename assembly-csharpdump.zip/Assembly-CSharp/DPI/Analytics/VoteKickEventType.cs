﻿using System;

namespace DPI.Analytics
{
	// Token: 0x02001034 RID: 4148
	public enum VoteKickEventType
	{
		// Token: 0x0400CAD5 RID: 51925
		NULL,
		// Token: 0x0400CAD6 RID: 51926
		INITIATED,
		// Token: 0x0400CAD7 RID: 51927
		VOTED_NO,
		// Token: 0x0400CAD8 RID: 51928
		VOTED_YES,
		// Token: 0x0400CAD9 RID: 51929
		IGNORED,
		// Token: 0x0400CADA RID: 51930
		KICKED,
		// Token: 0x0400CADB RID: 51931
		PUNISH_VOTE,
		// Token: 0x0400CADC RID: 51932
		FORGIVE
	}
}
