﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103B RID: 4155
	public class UserSessionGameModeEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D82 RID: 81282 RVA: 0x004FE07C File Offset: 0x004FC27C
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionGameModeEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D83 RID: 81283 RVA: 0x004FE0CC File Offset: 0x004FC2CC
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionGameModeEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D84 RID: 81284 RVA: 0x004FE11C File Offset: 0x004FC31C
		[CallerCount(0)]
		public unsafe UserSessionGameModeEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionGameModeEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D85 RID: 81285 RVA: 0x004FE168 File Offset: 0x004FC368
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionGameModeEvent()
		{
			Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionGameModeEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr);
			UserSessionGameModeEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr, 100688648);
			UserSessionGameModeEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr, 100688649);
			UserSessionGameModeEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr, 100688650);
		}

		// Token: 0x06013D86 RID: 81286 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionGameModeEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700708E RID: 28814
		// (get) Token: 0x06013D87 RID: 81287 RVA: 0x004FE1D4 File Offset: 0x004FC3D4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionGameModeEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB09 RID: 51977
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB0A RID: 51978
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB0B RID: 51979
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
