﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103E RID: 4158
	public class UserSessionMercenaryRoundEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D94 RID: 81300 RVA: 0x004FE4C0 File Offset: 0x004FC6C0
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionMercenaryRoundEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D95 RID: 81301 RVA: 0x004FE510 File Offset: 0x004FC710
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionMercenaryRoundEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D96 RID: 81302 RVA: 0x004FE560 File Offset: 0x004FC760
		[CallerCount(0)]
		public unsafe UserSessionMercenaryRoundEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionMercenaryRoundEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D97 RID: 81303 RVA: 0x004FE5AC File Offset: 0x004FC7AC
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionMercenaryRoundEvent()
		{
			Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionMercenaryRoundEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr);
			UserSessionMercenaryRoundEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr, 100688657);
			UserSessionMercenaryRoundEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr, 100688658);
			UserSessionMercenaryRoundEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr, 100688659);
		}

		// Token: 0x06013D98 RID: 81304 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionMercenaryRoundEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007091 RID: 28817
		// (get) Token: 0x06013D99 RID: 81305 RVA: 0x004FE618 File Offset: 0x004FC818
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionMercenaryRoundEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB12 RID: 51986
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB13 RID: 51987
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB14 RID: 51988
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
