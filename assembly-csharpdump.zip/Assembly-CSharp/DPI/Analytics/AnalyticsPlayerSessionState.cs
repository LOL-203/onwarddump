﻿using System;

namespace DPI.Analytics
{
	// Token: 0x02001058 RID: 4184
	public enum AnalyticsPlayerSessionState
	{
		// Token: 0x0400CBAB RID: 52139
		START,
		// Token: 0x0400CBAC RID: 52140
		PAUSE,
		// Token: 0x0400CBAD RID: 52141
		RESUME,
		// Token: 0x0400CBAE RID: 52142
		END
	}
}
