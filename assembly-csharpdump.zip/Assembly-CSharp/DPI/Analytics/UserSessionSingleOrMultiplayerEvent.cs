﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001040 RID: 4160
	public class UserSessionSingleOrMultiplayerEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013DA0 RID: 81312 RVA: 0x004FE798 File Offset: 0x004FC998
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA1 RID: 81313 RVA: 0x004FE7E8 File Offset: 0x004FC9E8
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA2 RID: 81314 RVA: 0x004FE838 File Offset: 0x004FCA38
		[CallerCount(0)]
		public unsafe UserSessionSingleOrMultiplayerEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA3 RID: 81315 RVA: 0x004FE884 File Offset: 0x004FCA84
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionSingleOrMultiplayerEvent()
		{
			Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionSingleOrMultiplayerEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr);
			UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr, 100688663);
			UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr, 100688664);
			UserSessionSingleOrMultiplayerEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr, 100688665);
		}

		// Token: 0x06013DA4 RID: 81316 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionSingleOrMultiplayerEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007093 RID: 28819
		// (get) Token: 0x06013DA5 RID: 81317 RVA: 0x004FE8F0 File Offset: 0x004FCAF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionSingleOrMultiplayerEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB18 RID: 51992
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB19 RID: 51993
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB1A RID: 51994
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
