﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using Il2CppSystem.Text;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001048 RID: 4168
	public class AnalyticsManagerLogsOnly : AnalyticsManager
	{
		// Token: 0x06013DCE RID: 81358 RVA: 0x004FF54C File Offset: 0x004FD74C
		[CallerCount(0)]
		public unsafe void SendBatch()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManagerLogsOnly.NativeMethodInfoPtr_SendBatch_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DCF RID: 81359 RVA: 0x004FF590 File Offset: 0x004FD790
		[CallerCount(0)]
		public new unsafe void InternalSendAnalyticsEvent<T>(T newEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = newEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref newEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManagerLogsOnly.MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0<T>.Pointer), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DD0 RID: 81360 RVA: 0x004FF648 File Offset: 0x004FD848
		[CallerCount(0)]
		public new unsafe void InternalUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManagerLogsOnly.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DD1 RID: 81361 RVA: 0x004FF698 File Offset: 0x004FD898
		[CallerCount(0)]
		public new unsafe void FlushAllEvents()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManagerLogsOnly.NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DD2 RID: 81362 RVA: 0x004FF6E8 File Offset: 0x004FD8E8
		[CallerCount(0)]
		public unsafe AnalyticsManagerLogsOnly() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManagerLogsOnly.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DD3 RID: 81363 RVA: 0x004FF734 File Offset: 0x004FD934
		// Note: this type is marked as 'beforefieldinit'.
		static AnalyticsManagerLogsOnly()
		{
			Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "AnalyticsManagerLogsOnly");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr);
			AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsEvents = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, "_analyticsEvents");
			AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsLog = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, "_analyticsLog");
			AnalyticsManagerLogsOnly.NativeMethodInfoPtr_SendBatch_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, 100688687);
			AnalyticsManagerLogsOnly.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, 100688688);
			AnalyticsManagerLogsOnly.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, 100688689);
			AnalyticsManagerLogsOnly.NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, 100688690);
			AnalyticsManagerLogsOnly.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr, 100688691);
		}

		// Token: 0x06013DD4 RID: 81364 RVA: 0x004FF7F0 File Offset: 0x004FD9F0
		public AnalyticsManagerLogsOnly(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700709A RID: 28826
		// (get) Token: 0x06013DD5 RID: 81365 RVA: 0x004FF7F9 File Offset: 0x004FD9F9
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr));
			}
		}

		// Token: 0x1700709B RID: 28827
		// (get) Token: 0x06013DD6 RID: 81366 RVA: 0x004FF80C File Offset: 0x004FDA0C
		// (set) Token: 0x06013DD7 RID: 81367 RVA: 0x004FF840 File Offset: 0x004FDA40
		public unsafe List<IBaseAnalyticsEvent> _analyticsEvents
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsEvents);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<IBaseAnalyticsEvent>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsEvents), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700709C RID: 28828
		// (get) Token: 0x06013DD8 RID: 81368 RVA: 0x004FF868 File Offset: 0x004FDA68
		// (set) Token: 0x06013DD9 RID: 81369 RVA: 0x004FF89C File Offset: 0x004FDA9C
		public unsafe StringBuilder _analyticsLog
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsLog);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new StringBuilder(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManagerLogsOnly.NativeFieldInfoPtr__analyticsLog), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CB35 RID: 52021
		private static readonly IntPtr NativeFieldInfoPtr__analyticsEvents;

		// Token: 0x0400CB36 RID: 52022
		private static readonly IntPtr NativeFieldInfoPtr__analyticsLog;

		// Token: 0x0400CB37 RID: 52023
		private static readonly IntPtr NativeMethodInfoPtr_SendBatch_Private_Void_0;

		// Token: 0x0400CB38 RID: 52024
		private static readonly IntPtr NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0;

		// Token: 0x0400CB39 RID: 52025
		private static readonly IntPtr NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_Void_0;

		// Token: 0x0400CB3A RID: 52026
		private static readonly IntPtr NativeMethodInfoPtr_FlushAllEvents_Public_Virtual_Void_0;

		// Token: 0x0400CB3B RID: 52027
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001049 RID: 4169
		private sealed class MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0<T>
		{
			// Token: 0x0400CB3C RID: 52028
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AnalyticsManagerLogsOnly.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Virtual_Void_T_0, Il2CppClassPointerStore<AnalyticsManagerLogsOnly>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
