﻿using System;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001044 RID: 4164
	public class AnalyticsManager : Object
	{
		// Token: 0x06013DB8 RID: 81336 RVA: 0x004FED48 File Offset: 0x004FCF48
		[CallerCount(0)]
		public unsafe void InternalSendAnalyticsEvent<T>(T newEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = newEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref newEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Abstract_Virtual_New_Void_T_0<T>.Pointer), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DB9 RID: 81337 RVA: 0x004FEE00 File Offset: 0x004FD000
		[CallerCount(0)]
		public unsafe void FlushAllEvents()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_FlushAllEvents_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBA RID: 81338 RVA: 0x004FEE50 File Offset: 0x004FD050
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBB RID: 81339 RVA: 0x004FEEA0 File Offset: 0x004FD0A0
		[CallerCount(0)]
		public unsafe void OnAnalyticsInitialized()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBC RID: 81340 RVA: 0x004FEEF0 File Offset: 0x004FD0F0
		[CallerCount(0)]
		public unsafe void OnAnalyticsInitializationFailed()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitializationFailed_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBD RID: 81341 RVA: 0x004FEF34 File Offset: 0x004FD134
		[CallerCount(0)]
		public unsafe void OnUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManager.NativeMethodInfoPtr_OnUpdate_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBE RID: 81342 RVA: 0x004FEF78 File Offset: 0x004FD178
		[CallerCount(0)]
		public unsafe void InternalUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DBF RID: 81343 RVA: 0x004FEFC8 File Offset: 0x004FD1C8
		[CallerCount(0)]
		public unsafe void OnApplicationQuit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DC0 RID: 81344 RVA: 0x004FF018 File Offset: 0x004FD218
		[CallerCount(0)]
		public unsafe void SendAnalyticsEvent<T>(T newEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = newEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref newEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManager.MethodInfoStoreGeneric_SendAnalyticsEvent_Public_Void_T_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DC1 RID: 81345 RVA: 0x004FF0C4 File Offset: 0x004FD2C4
		[CallerCount(0)]
		public unsafe T ApplyUserSessionData<T>(T userSessionEvent) where T : UserSessionAnalyticsEvent
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			IntPtr* ptr2 = ptr;
			T ptr4;
			if (!typeof(T).IsValueType)
			{
				T t = userSessionEvent;
				if (!(t is string))
				{
					ref T ptr3 = ptr4 = IL2CPP.Il2CppObjectBaseToPtr(t as Il2CppObjectBase);
					if (ref ptr3 != null)
					{
						ptr4 = ref ptr3;
						if (IL2CPP.il2cpp_class_is_valuetype(IL2CPP.il2cpp_object_get_class(ref ptr3)))
						{
							ptr4 = IL2CPP.il2cpp_object_unbox(ref ptr3);
						}
					}
				}
				else
				{
					ptr4 = IL2CPP.ManagedStringToIl2Cpp(t as string);
				}
			}
			else
			{
				ptr4 = ref userSessionEvent;
			}
			*ptr2 = ref ptr4;
			IntPtr returnedException;
			IntPtr objectPointer = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.MethodInfoStoreGeneric_ApplyUserSessionData_Public_Virtual_New_T_T_0<T>.Pointer), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.PointerToValueGeneric<T>(objectPointer, false, true);
		}

		// Token: 0x06013DC2 RID: 81346 RVA: 0x004FF188 File Offset: 0x004FD388
		[CallerCount(0)]
		public unsafe string GetDateTimeStringForData(DateTime dateTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dateTime;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsManager.NativeMethodInfoPtr_GetDateTimeStringForData_Protected_Virtual_New_String_DateTime_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06013DC3 RID: 81347 RVA: 0x004FF1F0 File Offset: 0x004FD3F0
		[CallerCount(0)]
		public unsafe AnalyticsManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsManager.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DC4 RID: 81348 RVA: 0x004FF23C File Offset: 0x004FD43C
		// Note: this type is marked as 'beforefieldinit'.
		static AnalyticsManager()
		{
			Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "AnalyticsManager");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr);
			AnalyticsManager.NativeFieldInfoPtr__sessionMonitor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, "_sessionMonitor");
			AnalyticsManager.NativeFieldInfoPtr__systemStatus = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, "_systemStatus");
			AnalyticsManager.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Abstract_Virtual_New_Void_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688675);
			AnalyticsManager.NativeMethodInfoPtr_FlushAllEvents_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688676);
			AnalyticsManager.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688677);
			AnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688678);
			AnalyticsManager.NativeMethodInfoPtr_OnAnalyticsInitializationFailed_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688679);
			AnalyticsManager.NativeMethodInfoPtr_OnUpdate_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688680);
			AnalyticsManager.NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688681);
			AnalyticsManager.NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688682);
			AnalyticsManager.NativeMethodInfoPtr_SendAnalyticsEvent_Public_Void_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688683);
			AnalyticsManager.NativeMethodInfoPtr_ApplyUserSessionData_Public_Virtual_New_T_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688684);
			AnalyticsManager.NativeMethodInfoPtr_GetDateTimeStringForData_Protected_Virtual_New_String_DateTime_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688685);
			AnalyticsManager.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr, 100688686);
		}

		// Token: 0x06013DC5 RID: 81349 RVA: 0x00002988 File Offset: 0x00000B88
		public AnalyticsManager(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007097 RID: 28823
		// (get) Token: 0x06013DC6 RID: 81350 RVA: 0x004FF384 File Offset: 0x004FD584
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr));
			}
		}

		// Token: 0x17007098 RID: 28824
		// (get) Token: 0x06013DC7 RID: 81351 RVA: 0x004FF398 File Offset: 0x004FD598
		// (set) Token: 0x06013DC8 RID: 81352 RVA: 0x004FF3CC File Offset: 0x004FD5CC
		public unsafe SessionMonitor _sessionMonitor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManager.NativeFieldInfoPtr__sessionMonitor);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new SessionMonitor(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManager.NativeFieldInfoPtr__sessionMonitor), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007099 RID: 28825
		// (get) Token: 0x06013DC9 RID: 81353 RVA: 0x004FF3F4 File Offset: 0x004FD5F4
		// (set) Token: 0x06013DCA RID: 81354 RVA: 0x004FF428 File Offset: 0x004FD628
		public unsafe AnalyticsSystemStatus _systemStatus
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManager.NativeFieldInfoPtr__systemStatus);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AnalyticsSystemStatus(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsManager.NativeFieldInfoPtr__systemStatus), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CB24 RID: 52004
		private static readonly IntPtr NativeFieldInfoPtr__sessionMonitor;

		// Token: 0x0400CB25 RID: 52005
		private static readonly IntPtr NativeFieldInfoPtr__systemStatus;

		// Token: 0x0400CB26 RID: 52006
		private static readonly IntPtr NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Abstract_Virtual_New_Void_T_0;

		// Token: 0x0400CB27 RID: 52007
		private static readonly IntPtr NativeMethodInfoPtr_FlushAllEvents_Public_Abstract_Virtual_New_Void_0;

		// Token: 0x0400CB28 RID: 52008
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0;

		// Token: 0x0400CB29 RID: 52009
		private static readonly IntPtr NativeMethodInfoPtr_OnAnalyticsInitialized_Protected_Virtual_New_Void_0;

		// Token: 0x0400CB2A RID: 52010
		private static readonly IntPtr NativeMethodInfoPtr_OnAnalyticsInitializationFailed_Private_Void_0;

		// Token: 0x0400CB2B RID: 52011
		private static readonly IntPtr NativeMethodInfoPtr_OnUpdate_Public_Void_0;

		// Token: 0x0400CB2C RID: 52012
		private static readonly IntPtr NativeMethodInfoPtr_InternalUpdate_Protected_Virtual_New_Void_0;

		// Token: 0x0400CB2D RID: 52013
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationQuit_Public_Virtual_New_Void_0;

		// Token: 0x0400CB2E RID: 52014
		private static readonly IntPtr NativeMethodInfoPtr_SendAnalyticsEvent_Public_Void_T_0;

		// Token: 0x0400CB2F RID: 52015
		private static readonly IntPtr NativeMethodInfoPtr_ApplyUserSessionData_Public_Virtual_New_T_T_0;

		// Token: 0x0400CB30 RID: 52016
		private static readonly IntPtr NativeMethodInfoPtr_GetDateTimeStringForData_Protected_Virtual_New_String_DateTime_0;

		// Token: 0x0400CB31 RID: 52017
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;

		// Token: 0x02001045 RID: 4165
		private sealed class MethodInfoStoreGeneric_InternalSendAnalyticsEvent_Protected_Abstract_Virtual_New_Void_T_0<T>
		{
			// Token: 0x0400CB32 RID: 52018
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AnalyticsManager.NativeMethodInfoPtr_InternalSendAnalyticsEvent_Protected_Abstract_Virtual_New_Void_T_0, Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x02001046 RID: 4166
		private sealed class MethodInfoStoreGeneric_SendAnalyticsEvent_Public_Void_T_0<T>
		{
			// Token: 0x0400CB33 RID: 52019
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AnalyticsManager.NativeMethodInfoPtr_SendAnalyticsEvent_Public_Void_T_0, Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}

		// Token: 0x02001047 RID: 4167
		private sealed class MethodInfoStoreGeneric_ApplyUserSessionData_Public_Virtual_New_T_T_0<T>
		{
			// Token: 0x0400CB34 RID: 52020
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(AnalyticsManager.NativeMethodInfoPtr_ApplyUserSessionData_Public_Virtual_New_T_T_0, Il2CppClassPointerStore<AnalyticsManager>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
