﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103F RID: 4159
	public class UserSessionPlayedMapEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D9A RID: 81306 RVA: 0x004FE62C File Offset: 0x004FC82C
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionPlayedMapEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D9B RID: 81307 RVA: 0x004FE67C File Offset: 0x004FC87C
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionPlayedMapEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D9C RID: 81308 RVA: 0x004FE6CC File Offset: 0x004FC8CC
		[CallerCount(0)]
		public unsafe UserSessionPlayedMapEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionPlayedMapEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D9D RID: 81309 RVA: 0x004FE718 File Offset: 0x004FC918
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionPlayedMapEvent()
		{
			Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionPlayedMapEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr);
			UserSessionPlayedMapEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr, 100688660);
			UserSessionPlayedMapEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr, 100688661);
			UserSessionPlayedMapEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr, 100688662);
		}

		// Token: 0x06013D9E RID: 81310 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionPlayedMapEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007092 RID: 28818
		// (get) Token: 0x06013D9F RID: 81311 RVA: 0x004FE784 File Offset: 0x004FC984
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionPlayedMapEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB15 RID: 51989
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB16 RID: 51990
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB17 RID: 51991
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
