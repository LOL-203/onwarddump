﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001033 RID: 4147
	[Serializable]
	public class BaseAnalyticsEvent : Object
	{
		// Token: 0x17007075 RID: 28789
		// (get) Token: 0x06013D2A RID: 81194 RVA: 0x004FC874 File Offset: 0x004FAA74
		// (set) Token: 0x06013D2B RID: 81195 RVA: 0x004FC8C4 File Offset: 0x004FAAC4
		public unsafe int time
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BaseAnalyticsEvent.NativeMethodInfoPtr_get_time_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseAnalyticsEvent.NativeMethodInfoPtr_set_time_Public_set_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007076 RID: 28790
		// (get) Token: 0x06013D2C RID: 81196 RVA: 0x004FC918 File Offset: 0x004FAB18
		// (set) Token: 0x06013D2D RID: 81197 RVA: 0x004FC968 File Offset: 0x004FAB68
		public unsafe bool CreatedByPool
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BaseAnalyticsEvent.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseAnalyticsEvent.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013D2E RID: 81198 RVA: 0x004FC9BC File Offset: 0x004FABBC
		[CallerCount(0)]
		public unsafe AnalyticsDataType GetEventDataType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Virtual_New_AnalyticsDataType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D2F RID: 81199 RVA: 0x004FCA18 File Offset: 0x004FAC18
		[CallerCount(0)]
		public unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseAnalyticsEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D30 RID: 81200 RVA: 0x004FCA68 File Offset: 0x004FAC68
		[CallerCount(0)]
		public unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D31 RID: 81201 RVA: 0x004FCAB8 File Offset: 0x004FACB8
		[CallerCount(0)]
		public unsafe AnalyticsEventType GetEventType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Virtual_New_AnalyticsEventType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D32 RID: 81202 RVA: 0x004FCB14 File Offset: 0x004FAD14
		[CallerCount(0)]
		public unsafe BaseAnalyticsEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseAnalyticsEvent.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D33 RID: 81203 RVA: 0x004FCB60 File Offset: 0x004FAD60
		// Note: this type is marked as 'beforefieldinit'.
		static BaseAnalyticsEvent()
		{
			Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "BaseAnalyticsEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr);
			BaseAnalyticsEvent.NativeFieldInfoPtr__time_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, "<time>k__BackingField");
			BaseAnalyticsEvent.NativeFieldInfoPtr__CreatedByPool_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, "<CreatedByPool>k__BackingField");
			BaseAnalyticsEvent.NativeMethodInfoPtr_get_time_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688603);
			BaseAnalyticsEvent.NativeMethodInfoPtr_set_time_Public_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688604);
			BaseAnalyticsEvent.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688605);
			BaseAnalyticsEvent.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688606);
			BaseAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Virtual_New_AnalyticsDataType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688607);
			BaseAnalyticsEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688608);
			BaseAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688609);
			BaseAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Virtual_New_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688610);
			BaseAnalyticsEvent.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr, 100688611);
		}

		// Token: 0x06013D34 RID: 81204 RVA: 0x00002988 File Offset: 0x00000B88
		public BaseAnalyticsEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007072 RID: 28786
		// (get) Token: 0x06013D35 RID: 81205 RVA: 0x004FCC6C File Offset: 0x004FAE6C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BaseAnalyticsEvent>.NativeClassPtr));
			}
		}

		// Token: 0x17007073 RID: 28787
		// (get) Token: 0x06013D36 RID: 81206 RVA: 0x004FCC80 File Offset: 0x004FAE80
		// (set) Token: 0x06013D37 RID: 81207 RVA: 0x004FCCA8 File Offset: 0x004FAEA8
		public unsafe int _time_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseAnalyticsEvent.NativeFieldInfoPtr__time_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseAnalyticsEvent.NativeFieldInfoPtr__time_k__BackingField)) = value;
			}
		}

		// Token: 0x17007074 RID: 28788
		// (get) Token: 0x06013D38 RID: 81208 RVA: 0x004FCCCC File Offset: 0x004FAECC
		// (set) Token: 0x06013D39 RID: 81209 RVA: 0x004FCCF4 File Offset: 0x004FAEF4
		public unsafe bool _CreatedByPool_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseAnalyticsEvent.NativeFieldInfoPtr__CreatedByPool_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseAnalyticsEvent.NativeFieldInfoPtr__CreatedByPool_k__BackingField)) = value;
			}
		}

		// Token: 0x0400CAC9 RID: 51913
		private static readonly IntPtr NativeFieldInfoPtr__time_k__BackingField;

		// Token: 0x0400CACA RID: 51914
		private static readonly IntPtr NativeFieldInfoPtr__CreatedByPool_k__BackingField;

		// Token: 0x0400CACB RID: 51915
		private static readonly IntPtr NativeMethodInfoPtr_get_time_Public_get_Int32_0;

		// Token: 0x0400CACC RID: 51916
		private static readonly IntPtr NativeMethodInfoPtr_set_time_Public_set_Void_Int32_0;

		// Token: 0x0400CACD RID: 51917
		private static readonly IntPtr NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400CACE RID: 51918
		private static readonly IntPtr NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400CACF RID: 51919
		private static readonly IntPtr NativeMethodInfoPtr_GetEventDataType_Public_Virtual_New_AnalyticsDataType_0;

		// Token: 0x0400CAD0 RID: 51920
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Abstract_Virtual_New_Void_0;

		// Token: 0x0400CAD1 RID: 51921
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0;

		// Token: 0x0400CAD2 RID: 51922
		private static readonly IntPtr NativeMethodInfoPtr_GetEventType_Public_Virtual_New_AnalyticsEventType_0;

		// Token: 0x0400CAD3 RID: 51923
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
