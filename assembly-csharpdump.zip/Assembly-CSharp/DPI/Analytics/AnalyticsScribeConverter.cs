﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using Newtonsoft.Json;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200104F RID: 4175
	public class AnalyticsScribeConverter : JsonConverter
	{
		// Token: 0x06013E1B RID: 81435 RVA: 0x0050046C File Offset: 0x004FE66C
		[CallerCount(0)]
		public new unsafe bool CanConvert(Type objectType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(objectType);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsScribeConverter.NativeMethodInfoPtr_CanConvert_Public_Virtual_Boolean_Type_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013E1C RID: 81436 RVA: 0x005004E0 File Offset: 0x004FE6E0
		[CallerCount(0)]
		public new unsafe Object ReadJson(JsonReader reader, Type objectType, Object existingValue, JsonSerializer serializer)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(reader);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(objectType);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(existingValue);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(serializer);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsScribeConverter.NativeMethodInfoPtr_ReadJson_Public_Virtual_Object_JsonReader_Type_Object_JsonSerializer_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Object(intPtr2) : null;
		}

		// Token: 0x06013E1D RID: 81437 RVA: 0x005005A0 File Offset: 0x004FE7A0
		[CallerCount(0)]
		public new unsafe void WriteJson(JsonWriter writer, Object value, JsonSerializer serializer)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(writer);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(serializer);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsScribeConverter.NativeMethodInfoPtr_WriteJson_Public_Virtual_Void_JsonWriter_Object_JsonSerializer_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E1E RID: 81438 RVA: 0x00500634 File Offset: 0x004FE834
		[CallerCount(0)]
		public unsafe void CacheAndWriteTypePropertiesForType(UserSessionAnalyticsEvent userSessionEvent, Type elementType, string scribeTypeString, JsonWriter writer, JsonSerializer serializer)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(userSessionEvent);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(elementType);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(scribeTypeString);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(writer);
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(serializer);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsScribeConverter.NativeMethodInfoPtr_CacheAndWriteTypePropertiesForType_Private_Void_UserSessionAnalyticsEvent_Type_String_JsonWriter_JsonSerializer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E1F RID: 81439 RVA: 0x005006F0 File Offset: 0x004FE8F0
		[CallerCount(0)]
		public unsafe AnalyticsScribeConverter() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsScribeConverter.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E20 RID: 81440 RVA: 0x0050073C File Offset: 0x004FE93C
		// Note: this type is marked as 'beforefieldinit'.
		static AnalyticsScribeConverter()
		{
			Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "AnalyticsScribeConverter");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr);
			AnalyticsScribeConverter.NativeFieldInfoPtr__cachedPropertyInfoByType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, "_cachedPropertyInfoByType");
			AnalyticsScribeConverter.NativeMethodInfoPtr_CanConvert_Public_Virtual_Boolean_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, 100688699);
			AnalyticsScribeConverter.NativeMethodInfoPtr_ReadJson_Public_Virtual_Object_JsonReader_Type_Object_JsonSerializer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, 100688700);
			AnalyticsScribeConverter.NativeMethodInfoPtr_WriteJson_Public_Virtual_Void_JsonWriter_Object_JsonSerializer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, 100688701);
			AnalyticsScribeConverter.NativeMethodInfoPtr_CacheAndWriteTypePropertiesForType_Private_Void_UserSessionAnalyticsEvent_Type_String_JsonWriter_JsonSerializer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, 100688702);
			AnalyticsScribeConverter.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, 100688703);
		}

		// Token: 0x06013E21 RID: 81441 RVA: 0x005007E4 File Offset: 0x004FE9E4
		public AnalyticsScribeConverter(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070B9 RID: 28857
		// (get) Token: 0x06013E22 RID: 81442 RVA: 0x005007ED File Offset: 0x004FE9ED
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr));
			}
		}

		// Token: 0x170070BA RID: 28858
		// (get) Token: 0x06013E23 RID: 81443 RVA: 0x00500800 File Offset: 0x004FEA00
		// (set) Token: 0x06013E24 RID: 81444 RVA: 0x0050082B File Offset: 0x004FEA2B
		public unsafe static Dictionary<Type, Dictionary<string, List<AnalyticsScribeConverter.AnalyticsEventProperty>>> _cachedPropertyInfoByType
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(AnalyticsScribeConverter.NativeFieldInfoPtr__cachedPropertyInfoByType, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Dictionary<Type, Dictionary<string, List<AnalyticsScribeConverter.AnalyticsEventProperty>>>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AnalyticsScribeConverter.NativeFieldInfoPtr__cachedPropertyInfoByType, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CB5E RID: 52062
		private static readonly IntPtr NativeFieldInfoPtr__cachedPropertyInfoByType;

		// Token: 0x0400CB5F RID: 52063
		private static readonly IntPtr NativeMethodInfoPtr_CanConvert_Public_Virtual_Boolean_Type_0;

		// Token: 0x0400CB60 RID: 52064
		private static readonly IntPtr NativeMethodInfoPtr_ReadJson_Public_Virtual_Object_JsonReader_Type_Object_JsonSerializer_0;

		// Token: 0x0400CB61 RID: 52065
		private static readonly IntPtr NativeMethodInfoPtr_WriteJson_Public_Virtual_Void_JsonWriter_Object_JsonSerializer_0;

		// Token: 0x0400CB62 RID: 52066
		private static readonly IntPtr NativeMethodInfoPtr_CacheAndWriteTypePropertiesForType_Private_Void_UserSessionAnalyticsEvent_Type_String_JsonWriter_JsonSerializer_0;

		// Token: 0x0400CB63 RID: 52067
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001050 RID: 4176
		[StructLayout(0)]
		public sealed class AnalyticsEventProperty : ValueType
		{
			// Token: 0x06013E25 RID: 81445 RVA: 0x00500840 File Offset: 0x004FEA40
			// Note: this type is marked as 'beforefieldinit'.
			static AnalyticsEventProperty()
			{
				Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, "AnalyticsEventProperty");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr);
				AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_IsBaseEventProperty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr, "IsBaseEventProperty");
				AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_PropertyInfo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr, "PropertyInfo");
			}

			// Token: 0x06013E26 RID: 81446 RVA: 0x0002717B File Offset: 0x0002537B
			public AnalyticsEventProperty(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170070BB RID: 28859
			// (get) Token: 0x06013E27 RID: 81447 RVA: 0x00500893 File Offset: 0x004FEA93
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr));
				}
			}

			// Token: 0x06013E28 RID: 81448 RVA: 0x005008A4 File Offset: 0x004FEAA4
			public unsafe AnalyticsEventProperty()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AnalyticsScribeConverter.AnalyticsEventProperty>.NativeClassPtr, data));
			}

			// Token: 0x170070BC RID: 28860
			// (get) Token: 0x06013E29 RID: 81449 RVA: 0x005008D4 File Offset: 0x004FEAD4
			// (set) Token: 0x06013E2A RID: 81450 RVA: 0x005008FC File Offset: 0x004FEAFC
			public unsafe bool IsBaseEventProperty
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_IsBaseEventProperty);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_IsBaseEventProperty)) = value;
				}
			}

			// Token: 0x170070BD RID: 28861
			// (get) Token: 0x06013E2B RID: 81451 RVA: 0x00500920 File Offset: 0x004FEB20
			// (set) Token: 0x06013E2C RID: 81452 RVA: 0x00500954 File Offset: 0x004FEB54
			public unsafe PropertyInfo PropertyInfo
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_PropertyInfo);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new PropertyInfo(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.AnalyticsEventProperty.NativeFieldInfoPtr_PropertyInfo), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400CB64 RID: 52068
			private static readonly IntPtr NativeFieldInfoPtr_IsBaseEventProperty;

			// Token: 0x0400CB65 RID: 52069
			private static readonly IntPtr NativeFieldInfoPtr_PropertyInfo;
		}

		// Token: 0x02001051 RID: 4177
		[ObfuscatedName("DPI.Analytics.AnalyticsScribeConverter/<>c__DisplayClass4_0")]
		public sealed class __c__DisplayClass4_0 : Object
		{
			// Token: 0x06013E2D RID: 81453 RVA: 0x0050097C File Offset: 0x004FEB7C
			[CallerCount(0)]
			public unsafe __c__DisplayClass4_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06013E2E RID: 81454 RVA: 0x005009C8 File Offset: 0x004FEBC8
			[CallerCount(0)]
			public unsafe bool _CacheAndWriteTypePropertiesForType_b__0(PropertyInfo prop)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(prop);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__0_Internal_Boolean_PropertyInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06013E2F RID: 81455 RVA: 0x00500A30 File Offset: 0x004FEC30
			[CallerCount(0)]
			public unsafe bool _CacheAndWriteTypePropertiesForType_b__1(PropertyInfo prop)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(prop);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__1_Internal_Boolean_PropertyInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06013E30 RID: 81456 RVA: 0x00500A98 File Offset: 0x004FEC98
			// Note: this type is marked as 'beforefieldinit'.
			static __c__DisplayClass4_0()
			{
				Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AnalyticsScribeConverter>.NativeClassPtr, "<>c__DisplayClass4_0");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr);
				AnalyticsScribeConverter.__c__DisplayClass4_0.NativeFieldInfoPtr_elementType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr, "elementType");
				AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr, 100688705);
				AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__0_Internal_Boolean_PropertyInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr, 100688706);
				AnalyticsScribeConverter.__c__DisplayClass4_0.NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__1_Internal_Boolean_PropertyInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr, 100688707);
			}

			// Token: 0x06013E31 RID: 81457 RVA: 0x00002988 File Offset: 0x00000B88
			public __c__DisplayClass4_0(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170070BE RID: 28862
			// (get) Token: 0x06013E32 RID: 81458 RVA: 0x00500B13 File Offset: 0x004FED13
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsScribeConverter.__c__DisplayClass4_0>.NativeClassPtr));
				}
			}

			// Token: 0x170070BF RID: 28863
			// (get) Token: 0x06013E33 RID: 81459 RVA: 0x00500B24 File Offset: 0x004FED24
			// (set) Token: 0x06013E34 RID: 81460 RVA: 0x00500B58 File Offset: 0x004FED58
			public unsafe Type elementType
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.__c__DisplayClass4_0.NativeFieldInfoPtr_elementType);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Type(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsScribeConverter.__c__DisplayClass4_0.NativeFieldInfoPtr_elementType), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400CB66 RID: 52070
			private static readonly IntPtr NativeFieldInfoPtr_elementType;

			// Token: 0x0400CB67 RID: 52071
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400CB68 RID: 52072
			private static readonly IntPtr NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__0_Internal_Boolean_PropertyInfo_0;

			// Token: 0x0400CB69 RID: 52073
			private static readonly IntPtr NativeMethodInfoPtr__CacheAndWriteTypePropertiesForType_b__1_Internal_Boolean_PropertyInfo_0;
		}
	}
}
