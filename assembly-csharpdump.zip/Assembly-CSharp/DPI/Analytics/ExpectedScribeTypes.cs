﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace DPI.Analytics
{
	// Token: 0x0200104E RID: 4174
	public static class ExpectedScribeTypes : Object
	{
		// Token: 0x06013E12 RID: 81426 RVA: 0x00500344 File Offset: 0x004FE544
		// Note: this type is marked as 'beforefieldinit'.
		static ExpectedScribeTypes()
		{
			Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "ExpectedScribeTypes");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr);
			ExpectedScribeTypes.NativeFieldInfoPtr_INT_TYPE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr, "INT_TYPE");
			ExpectedScribeTypes.NativeFieldInfoPtr_STRING_TYPE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr, "STRING_TYPE");
			ExpectedScribeTypes.NativeFieldInfoPtr_STRING_VECTOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr, "STRING_VECTOR");
		}

		// Token: 0x06013E13 RID: 81427 RVA: 0x00002988 File Offset: 0x00000B88
		public ExpectedScribeTypes(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070B5 RID: 28853
		// (get) Token: 0x06013E14 RID: 81428 RVA: 0x005003B0 File Offset: 0x004FE5B0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ExpectedScribeTypes>.NativeClassPtr));
			}
		}

		// Token: 0x170070B6 RID: 28854
		// (get) Token: 0x06013E15 RID: 81429 RVA: 0x005003C4 File Offset: 0x004FE5C4
		// (set) Token: 0x06013E16 RID: 81430 RVA: 0x005003E4 File Offset: 0x004FE5E4
		public unsafe static string INT_TYPE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ExpectedScribeTypes.NativeFieldInfoPtr_INT_TYPE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ExpectedScribeTypes.NativeFieldInfoPtr_INT_TYPE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070B7 RID: 28855
		// (get) Token: 0x06013E17 RID: 81431 RVA: 0x005003FC File Offset: 0x004FE5FC
		// (set) Token: 0x06013E18 RID: 81432 RVA: 0x0050041C File Offset: 0x004FE61C
		public unsafe static string STRING_TYPE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ExpectedScribeTypes.NativeFieldInfoPtr_STRING_TYPE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ExpectedScribeTypes.NativeFieldInfoPtr_STRING_TYPE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070B8 RID: 28856
		// (get) Token: 0x06013E19 RID: 81433 RVA: 0x00500434 File Offset: 0x004FE634
		// (set) Token: 0x06013E1A RID: 81434 RVA: 0x00500454 File Offset: 0x004FE654
		public unsafe static string STRING_VECTOR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ExpectedScribeTypes.NativeFieldInfoPtr_STRING_VECTOR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ExpectedScribeTypes.NativeFieldInfoPtr_STRING_VECTOR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CB5B RID: 52059
		private static readonly IntPtr NativeFieldInfoPtr_INT_TYPE;

		// Token: 0x0400CB5C RID: 52060
		private static readonly IntPtr NativeFieldInfoPtr_STRING_TYPE;

		// Token: 0x0400CB5D RID: 52061
		private static readonly IntPtr NativeFieldInfoPtr_STRING_VECTOR;
	}
}
