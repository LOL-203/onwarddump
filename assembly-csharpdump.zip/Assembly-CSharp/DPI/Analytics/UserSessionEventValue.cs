﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103A RID: 4154
	public class UserSessionEventValue : Object
	{
		// Token: 0x1700708C RID: 28812
		// (get) Token: 0x06013D75 RID: 81269 RVA: 0x004FDD14 File Offset: 0x004FBF14
		// (set) Token: 0x06013D76 RID: 81270 RVA: 0x004FDD64 File Offset: 0x004FBF64
		public unsafe bool CreatedByPool
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(UserSessionEventValue.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionEventValue.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700708D RID: 28813
		// (get) Token: 0x06013D77 RID: 81271 RVA: 0x004FDDB8 File Offset: 0x004FBFB8
		// (set) Token: 0x06013D78 RID: 81272 RVA: 0x004FDE04 File Offset: 0x004FC004
		public unsafe string value
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionEventValue.NativeMethodInfoPtr_get_value_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionEventValue.NativeMethodInfoPtr_set_value_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013D79 RID: 81273 RVA: 0x004FDE60 File Offset: 0x004FC060
		[CallerCount(0)]
		public unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionEventValue.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D7A RID: 81274 RVA: 0x004FDEB0 File Offset: 0x004FC0B0
		[CallerCount(0)]
		public unsafe UserSessionEventValue() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionEventValue.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D7B RID: 81275 RVA: 0x004FDEFC File Offset: 0x004FC0FC
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionEventValue()
		{
			Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionEventValue");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr);
			UserSessionEventValue.NativeFieldInfoPtr__CreatedByPool_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, "<CreatedByPool>k__BackingField");
			UserSessionEventValue.NativeFieldInfoPtr__value_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, "<value>k__BackingField");
			UserSessionEventValue.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688642);
			UserSessionEventValue.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688643);
			UserSessionEventValue.NativeMethodInfoPtr_get_value_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688644);
			UserSessionEventValue.NativeMethodInfoPtr_set_value_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688645);
			UserSessionEventValue.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688646);
			UserSessionEventValue.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr, 100688647);
		}

		// Token: 0x06013D7C RID: 81276 RVA: 0x00002988 File Offset: 0x00000B88
		public UserSessionEventValue(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007089 RID: 28809
		// (get) Token: 0x06013D7D RID: 81277 RVA: 0x004FDFCC File Offset: 0x004FC1CC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionEventValue>.NativeClassPtr));
			}
		}

		// Token: 0x1700708A RID: 28810
		// (get) Token: 0x06013D7E RID: 81278 RVA: 0x004FDFE0 File Offset: 0x004FC1E0
		// (set) Token: 0x06013D7F RID: 81279 RVA: 0x004FE008 File Offset: 0x004FC208
		public unsafe bool _CreatedByPool_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionEventValue.NativeFieldInfoPtr__CreatedByPool_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionEventValue.NativeFieldInfoPtr__CreatedByPool_k__BackingField)) = value;
			}
		}

		// Token: 0x1700708B RID: 28811
		// (get) Token: 0x06013D80 RID: 81280 RVA: 0x004FE02C File Offset: 0x004FC22C
		// (set) Token: 0x06013D81 RID: 81281 RVA: 0x004FE055 File Offset: 0x004FC255
		public unsafe string _value_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionEventValue.NativeFieldInfoPtr__value_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionEventValue.NativeFieldInfoPtr__value_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CB01 RID: 51969
		private static readonly IntPtr NativeFieldInfoPtr__CreatedByPool_k__BackingField;

		// Token: 0x0400CB02 RID: 51970
		private static readonly IntPtr NativeFieldInfoPtr__value_k__BackingField;

		// Token: 0x0400CB03 RID: 51971
		private static readonly IntPtr NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400CB04 RID: 51972
		private static readonly IntPtr NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400CB05 RID: 51973
		private static readonly IntPtr NativeMethodInfoPtr_get_value_Public_get_String_0;

		// Token: 0x0400CB06 RID: 51974
		private static readonly IntPtr NativeMethodInfoPtr_set_value_Public_set_Void_String_0;

		// Token: 0x0400CB07 RID: 51975
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_New_Void_0;

		// Token: 0x0400CB08 RID: 51976
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
