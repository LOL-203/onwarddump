﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001043 RID: 4163
	public class UserSessionVoteKickEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013DB2 RID: 81330 RVA: 0x004FEBDC File Offset: 0x004FCDDC
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionVoteKickEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DB3 RID: 81331 RVA: 0x004FEC2C File Offset: 0x004FCE2C
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionVoteKickEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DB4 RID: 81332 RVA: 0x004FEC7C File Offset: 0x004FCE7C
		[CallerCount(0)]
		public unsafe UserSessionVoteKickEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionVoteKickEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DB5 RID: 81333 RVA: 0x004FECC8 File Offset: 0x004FCEC8
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionVoteKickEvent()
		{
			Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionVoteKickEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr);
			UserSessionVoteKickEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr, 100688672);
			UserSessionVoteKickEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr, 100688673);
			UserSessionVoteKickEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr, 100688674);
		}

		// Token: 0x06013DB6 RID: 81334 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionVoteKickEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007096 RID: 28822
		// (get) Token: 0x06013DB7 RID: 81335 RVA: 0x004FED34 File Offset: 0x004FCF34
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionVoteKickEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB21 RID: 52001
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB22 RID: 52002
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB23 RID: 52003
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
