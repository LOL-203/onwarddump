﻿using System;

namespace DPI.Analytics
{
	// Token: 0x0200104A RID: 4170
	public enum AnalyticsSystemState
	{
		// Token: 0x0400CB3E RID: 52030
		UNINITIALIZED,
		// Token: 0x0400CB3F RID: 52031
		INITIALIZING,
		// Token: 0x0400CB40 RID: 52032
		ACTIVE,
		// Token: 0x0400CB41 RID: 52033
		FAILED
	}
}
