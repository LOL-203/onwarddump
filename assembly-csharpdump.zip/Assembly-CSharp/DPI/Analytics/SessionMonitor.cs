﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001059 RID: 4185
	public class SessionMonitor : Object
	{
		// Token: 0x170070E6 RID: 28902
		// (get) Token: 0x06013E9B RID: 81563 RVA: 0x0050273C File Offset: 0x0050093C
		public unsafe string UserId
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_get_UserId_Public_Abstract_Virtual_New_get_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x170070E7 RID: 28903
		// (get) Token: 0x06013E9C RID: 81564 RVA: 0x00502794 File Offset: 0x00500994
		public unsafe string UserSessionId
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(SessionMonitor.NativeMethodInfoPtr_get_UserSessionId_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x170070E8 RID: 28904
		// (get) Token: 0x06013E9D RID: 81565 RVA: 0x005027E0 File Offset: 0x005009E0
		public unsafe string GameSessionId
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_get_GameSessionId_Public_Abstract_Virtual_New_get_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x170070E9 RID: 28905
		// (get) Token: 0x06013E9E RID: 81566 RVA: 0x00502838 File Offset: 0x00500A38
		public unsafe string MatchSessionId
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_get_MatchSessionId_Public_Abstract_Virtual_New_get_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x170070EA RID: 28906
		// (get) Token: 0x06013E9F RID: 81567 RVA: 0x00502890 File Offset: 0x00500A90
		public unsafe int CurrentSessionStartTime
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_get_CurrentSessionStartTime_Public_Abstract_Virtual_New_get_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070EB RID: 28907
		// (get) Token: 0x06013EA0 RID: 81568 RVA: 0x005028EC File Offset: 0x00500AEC
		public unsafe int CurrentSessionLength
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_get_CurrentSessionLength_Public_Abstract_Virtual_New_get_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06013EA1 RID: 81569 RVA: 0x00502948 File Offset: 0x00500B48
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA2 RID: 81570 RVA: 0x00502998 File Offset: 0x00500B98
		[CallerCount(0)]
		public unsafe void OnApplicationExit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_OnApplicationExit_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA3 RID: 81571 RVA: 0x005029E8 File Offset: 0x00500BE8
		[CallerCount(0)]
		public unsafe void StartNewSession()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_StartNewSession_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA4 RID: 81572 RVA: 0x00502A38 File Offset: 0x00500C38
		[CallerCount(0)]
		public unsafe void OnSessionPaused()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_OnSessionPaused_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA5 RID: 81573 RVA: 0x00502A88 File Offset: 0x00500C88
		[CallerCount(0)]
		public unsafe void OnSessionResumed()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_OnSessionResumed_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA6 RID: 81574 RVA: 0x00502AD8 File Offset: 0x00500CD8
		[CallerCount(0)]
		public unsafe void EndSession()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SessionMonitor.NativeMethodInfoPtr_EndSession_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA7 RID: 81575 RVA: 0x00502B28 File Offset: 0x00500D28
		[CallerCount(0)]
		public unsafe SessionMonitor() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SessionMonitor.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013EA8 RID: 81576 RVA: 0x00502B74 File Offset: 0x00500D74
		// Note: this type is marked as 'beforefieldinit'.
		static SessionMonitor()
		{
			Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "SessionMonitor");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr);
			SessionMonitor.NativeFieldInfoPtr__userSessionId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, "_userSessionId");
			SessionMonitor.NativeMethodInfoPtr_get_UserId_Public_Abstract_Virtual_New_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688747);
			SessionMonitor.NativeMethodInfoPtr_get_UserSessionId_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688748);
			SessionMonitor.NativeMethodInfoPtr_get_GameSessionId_Public_Abstract_Virtual_New_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688749);
			SessionMonitor.NativeMethodInfoPtr_get_MatchSessionId_Public_Abstract_Virtual_New_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688750);
			SessionMonitor.NativeMethodInfoPtr_get_CurrentSessionStartTime_Public_Abstract_Virtual_New_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688751);
			SessionMonitor.NativeMethodInfoPtr_get_CurrentSessionLength_Public_Abstract_Virtual_New_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688752);
			SessionMonitor.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688753);
			SessionMonitor.NativeMethodInfoPtr_OnApplicationExit_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688754);
			SessionMonitor.NativeMethodInfoPtr_StartNewSession_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688755);
			SessionMonitor.NativeMethodInfoPtr_OnSessionPaused_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688756);
			SessionMonitor.NativeMethodInfoPtr_OnSessionResumed_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688757);
			SessionMonitor.NativeMethodInfoPtr_EndSession_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688758);
			SessionMonitor.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr, 100688759);
		}

		// Token: 0x06013EA9 RID: 81577 RVA: 0x00002988 File Offset: 0x00000B88
		public SessionMonitor(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070E4 RID: 28900
		// (get) Token: 0x06013EAA RID: 81578 RVA: 0x00502CBC File Offset: 0x00500EBC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SessionMonitor>.NativeClassPtr));
			}
		}

		// Token: 0x170070E5 RID: 28901
		// (get) Token: 0x06013EAB RID: 81579 RVA: 0x00502CD0 File Offset: 0x00500ED0
		// (set) Token: 0x06013EAC RID: 81580 RVA: 0x00502CF9 File Offset: 0x00500EF9
		public unsafe string _userSessionId
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SessionMonitor.NativeFieldInfoPtr__userSessionId);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SessionMonitor.NativeFieldInfoPtr__userSessionId), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CBAF RID: 52143
		private static readonly IntPtr NativeFieldInfoPtr__userSessionId;

		// Token: 0x0400CBB0 RID: 52144
		private static readonly IntPtr NativeMethodInfoPtr_get_UserId_Public_Abstract_Virtual_New_get_String_0;

		// Token: 0x0400CBB1 RID: 52145
		private static readonly IntPtr NativeMethodInfoPtr_get_UserSessionId_Public_get_String_0;

		// Token: 0x0400CBB2 RID: 52146
		private static readonly IntPtr NativeMethodInfoPtr_get_GameSessionId_Public_Abstract_Virtual_New_get_String_0;

		// Token: 0x0400CBB3 RID: 52147
		private static readonly IntPtr NativeMethodInfoPtr_get_MatchSessionId_Public_Abstract_Virtual_New_get_String_0;

		// Token: 0x0400CBB4 RID: 52148
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentSessionStartTime_Public_Abstract_Virtual_New_get_Int32_0;

		// Token: 0x0400CBB5 RID: 52149
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentSessionLength_Public_Abstract_Virtual_New_get_Int32_0;

		// Token: 0x0400CBB6 RID: 52150
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_0;

		// Token: 0x0400CBB7 RID: 52151
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationExit_Public_Virtual_New_Void_0;

		// Token: 0x0400CBB8 RID: 52152
		private static readonly IntPtr NativeMethodInfoPtr_StartNewSession_Protected_Virtual_New_Void_0;

		// Token: 0x0400CBB9 RID: 52153
		private static readonly IntPtr NativeMethodInfoPtr_OnSessionPaused_Protected_Virtual_New_Void_0;

		// Token: 0x0400CBBA RID: 52154
		private static readonly IntPtr NativeMethodInfoPtr_OnSessionResumed_Protected_Virtual_New_Void_0;

		// Token: 0x0400CBBB RID: 52155
		private static readonly IntPtr NativeMethodInfoPtr_EndSession_Protected_Virtual_New_Void_0;

		// Token: 0x0400CBBC RID: 52156
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
