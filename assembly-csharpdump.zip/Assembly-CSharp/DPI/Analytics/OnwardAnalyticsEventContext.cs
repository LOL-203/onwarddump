﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace DPI.Analytics
{
	// Token: 0x0200104C RID: 4172
	public static class OnwardAnalyticsEventContext : Object
	{
		// Token: 0x06013DEA RID: 81386 RVA: 0x004FFCA0 File Offset: 0x004FDEA0
		// Note: this type is marked as 'beforefieldinit'.
		static OnwardAnalyticsEventContext()
		{
			Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "OnwardAnalyticsEventContext");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr);
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_USER_STATE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "USER_STATE");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_GAME_MODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "GAME_MODE");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_IS_MULTIPLAYER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "IS_MULTIPLAYER");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_VOTE_KICK = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "VOTE_KICK");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_BUILD_NUMBER = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "BUILD_NUMBER");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_MAP_PLAYED_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "MAP_PLAYED_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_DEEPLINK_EVENT_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "DEEPLINK_EVENT_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_ENVIRONMENT_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "ENVIRONMENT_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_TUTORIAL_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "TUTORIAL_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_LOADOUT_EVENT_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "LOADOUT_EVENT_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_ROUND_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "MERCENARY_ROUND_CONTEXT");
			OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_REWARD_CONTEXT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr, "MERCENARY_REWARD_CONTEXT");
		}

		// Token: 0x06013DEB RID: 81387 RVA: 0x00002988 File Offset: 0x00000B88
		public OnwardAnalyticsEventContext(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070A3 RID: 28835
		// (get) Token: 0x06013DEC RID: 81388 RVA: 0x004FFDC0 File Offset: 0x004FDFC0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<OnwardAnalyticsEventContext>.NativeClassPtr));
			}
		}

		// Token: 0x170070A4 RID: 28836
		// (get) Token: 0x06013DED RID: 81389 RVA: 0x004FFDD4 File Offset: 0x004FDFD4
		// (set) Token: 0x06013DEE RID: 81390 RVA: 0x004FFDF4 File Offset: 0x004FDFF4
		public unsafe static string USER_STATE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_USER_STATE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_USER_STATE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070A5 RID: 28837
		// (get) Token: 0x06013DEF RID: 81391 RVA: 0x004FFE0C File Offset: 0x004FE00C
		// (set) Token: 0x06013DF0 RID: 81392 RVA: 0x004FFE2C File Offset: 0x004FE02C
		public unsafe static string GAME_MODE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_GAME_MODE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_GAME_MODE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070A6 RID: 28838
		// (get) Token: 0x06013DF1 RID: 81393 RVA: 0x004FFE44 File Offset: 0x004FE044
		// (set) Token: 0x06013DF2 RID: 81394 RVA: 0x004FFE64 File Offset: 0x004FE064
		public unsafe static string IS_MULTIPLAYER
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_IS_MULTIPLAYER, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_IS_MULTIPLAYER, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070A7 RID: 28839
		// (get) Token: 0x06013DF3 RID: 81395 RVA: 0x004FFE7C File Offset: 0x004FE07C
		// (set) Token: 0x06013DF4 RID: 81396 RVA: 0x004FFE9C File Offset: 0x004FE09C
		public unsafe static string VOTE_KICK
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_VOTE_KICK, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_VOTE_KICK, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070A8 RID: 28840
		// (get) Token: 0x06013DF5 RID: 81397 RVA: 0x004FFEB4 File Offset: 0x004FE0B4
		// (set) Token: 0x06013DF6 RID: 81398 RVA: 0x004FFED4 File Offset: 0x004FE0D4
		public unsafe static string BUILD_NUMBER
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_BUILD_NUMBER, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_BUILD_NUMBER, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070A9 RID: 28841
		// (get) Token: 0x06013DF7 RID: 81399 RVA: 0x004FFEEC File Offset: 0x004FE0EC
		// (set) Token: 0x06013DF8 RID: 81400 RVA: 0x004FFF0C File Offset: 0x004FE10C
		public unsafe static string MAP_PLAYED_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MAP_PLAYED_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MAP_PLAYED_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AA RID: 28842
		// (get) Token: 0x06013DF9 RID: 81401 RVA: 0x004FFF24 File Offset: 0x004FE124
		// (set) Token: 0x06013DFA RID: 81402 RVA: 0x004FFF44 File Offset: 0x004FE144
		public unsafe static string DEEPLINK_EVENT_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_DEEPLINK_EVENT_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_DEEPLINK_EVENT_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AB RID: 28843
		// (get) Token: 0x06013DFB RID: 81403 RVA: 0x004FFF5C File Offset: 0x004FE15C
		// (set) Token: 0x06013DFC RID: 81404 RVA: 0x004FFF7C File Offset: 0x004FE17C
		public unsafe static string ENVIRONMENT_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_ENVIRONMENT_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_ENVIRONMENT_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AC RID: 28844
		// (get) Token: 0x06013DFD RID: 81405 RVA: 0x004FFF94 File Offset: 0x004FE194
		// (set) Token: 0x06013DFE RID: 81406 RVA: 0x004FFFB4 File Offset: 0x004FE1B4
		public unsafe static string TUTORIAL_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_TUTORIAL_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_TUTORIAL_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AD RID: 28845
		// (get) Token: 0x06013DFF RID: 81407 RVA: 0x004FFFCC File Offset: 0x004FE1CC
		// (set) Token: 0x06013E00 RID: 81408 RVA: 0x004FFFEC File Offset: 0x004FE1EC
		public unsafe static string LOADOUT_EVENT_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_LOADOUT_EVENT_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_LOADOUT_EVENT_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AE RID: 28846
		// (get) Token: 0x06013E01 RID: 81409 RVA: 0x00500004 File Offset: 0x004FE204
		// (set) Token: 0x06013E02 RID: 81410 RVA: 0x00500024 File Offset: 0x004FE224
		public unsafe static string MERCENARY_ROUND_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_ROUND_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_ROUND_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170070AF RID: 28847
		// (get) Token: 0x06013E03 RID: 81411 RVA: 0x0050003C File Offset: 0x004FE23C
		// (set) Token: 0x06013E04 RID: 81412 RVA: 0x0050005C File Offset: 0x004FE25C
		public unsafe static string MERCENARY_REWARD_CONTEXT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_REWARD_CONTEXT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(OnwardAnalyticsEventContext.NativeFieldInfoPtr_MERCENARY_REWARD_CONTEXT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CB49 RID: 52041
		private static readonly IntPtr NativeFieldInfoPtr_USER_STATE;

		// Token: 0x0400CB4A RID: 52042
		private static readonly IntPtr NativeFieldInfoPtr_GAME_MODE;

		// Token: 0x0400CB4B RID: 52043
		private static readonly IntPtr NativeFieldInfoPtr_IS_MULTIPLAYER;

		// Token: 0x0400CB4C RID: 52044
		private static readonly IntPtr NativeFieldInfoPtr_VOTE_KICK;

		// Token: 0x0400CB4D RID: 52045
		private static readonly IntPtr NativeFieldInfoPtr_BUILD_NUMBER;

		// Token: 0x0400CB4E RID: 52046
		private static readonly IntPtr NativeFieldInfoPtr_MAP_PLAYED_CONTEXT;

		// Token: 0x0400CB4F RID: 52047
		private static readonly IntPtr NativeFieldInfoPtr_DEEPLINK_EVENT_CONTEXT;

		// Token: 0x0400CB50 RID: 52048
		private static readonly IntPtr NativeFieldInfoPtr_ENVIRONMENT_CONTEXT;

		// Token: 0x0400CB51 RID: 52049
		private static readonly IntPtr NativeFieldInfoPtr_TUTORIAL_CONTEXT;

		// Token: 0x0400CB52 RID: 52050
		private static readonly IntPtr NativeFieldInfoPtr_LOADOUT_EVENT_CONTEXT;

		// Token: 0x0400CB53 RID: 52051
		private static readonly IntPtr NativeFieldInfoPtr_MERCENARY_ROUND_CONTEXT;

		// Token: 0x0400CB54 RID: 52052
		private static readonly IntPtr NativeFieldInfoPtr_MERCENARY_REWARD_CONTEXT;
	}
}
