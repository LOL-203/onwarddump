﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001035 RID: 4149
	public class IBaseAnalyticsEvent : Il2CppObjectBase
	{
		// Token: 0x06013D3C RID: 81212 RVA: 0x004FCD44 File Offset: 0x004FAF44
		[CallerCount(0)]
		public unsafe AnalyticsEventType GetEventType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IBaseAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Abstract_Virtual_New_AnalyticsEventType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D3D RID: 81213 RVA: 0x004FCDA0 File Offset: 0x004FAFA0
		[CallerCount(0)]
		public unsafe AnalyticsDataType GetEventDataType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IBaseAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Abstract_Virtual_New_AnalyticsDataType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D3E RID: 81214 RVA: 0x004FCDFC File Offset: 0x004FAFFC
		[CallerCount(0)]
		public unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), IBaseAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D3F RID: 81215 RVA: 0x004FCE4C File Offset: 0x004FB04C
		// Note: this type is marked as 'beforefieldinit'.
		static IBaseAnalyticsEvent()
		{
			Il2CppClassPointerStore<IBaseAnalyticsEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "IBaseAnalyticsEvent");
			IBaseAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Abstract_Virtual_New_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IBaseAnalyticsEvent>.NativeClassPtr, 100688612);
			IBaseAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Abstract_Virtual_New_AnalyticsDataType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IBaseAnalyticsEvent>.NativeClassPtr, 100688613);
			IBaseAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<IBaseAnalyticsEvent>.NativeClassPtr, 100688614);
		}

		// Token: 0x06013D40 RID: 81216 RVA: 0x0000206B File Offset: 0x0000026B
		public IBaseAnalyticsEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007078 RID: 28792
		// (get) Token: 0x06013D41 RID: 81217 RVA: 0x004FCEAE File Offset: 0x004FB0AE
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<IBaseAnalyticsEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CADD RID: 51933
		private static readonly IntPtr NativeMethodInfoPtr_GetEventType_Public_Abstract_Virtual_New_AnalyticsEventType_0;

		// Token: 0x0400CADE RID: 51934
		private static readonly IntPtr NativeMethodInfoPtr_GetEventDataType_Public_Abstract_Virtual_New_AnalyticsDataType_0;

		// Token: 0x0400CADF RID: 51935
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Abstract_Virtual_New_Void_0;
	}
}
