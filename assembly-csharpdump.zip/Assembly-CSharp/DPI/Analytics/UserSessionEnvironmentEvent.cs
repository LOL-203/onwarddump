﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001039 RID: 4153
	public class UserSessionEnvironmentEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D6F RID: 81263 RVA: 0x004FDBA8 File Offset: 0x004FBDA8
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionEnvironmentEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D70 RID: 81264 RVA: 0x004FDBF8 File Offset: 0x004FBDF8
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionEnvironmentEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D71 RID: 81265 RVA: 0x004FDC48 File Offset: 0x004FBE48
		[CallerCount(0)]
		public unsafe UserSessionEnvironmentEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionEnvironmentEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D72 RID: 81266 RVA: 0x004FDC94 File Offset: 0x004FBE94
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionEnvironmentEvent()
		{
			Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionEnvironmentEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr);
			UserSessionEnvironmentEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr, 100688639);
			UserSessionEnvironmentEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr, 100688640);
			UserSessionEnvironmentEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr, 100688641);
		}

		// Token: 0x06013D73 RID: 81267 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionEnvironmentEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007088 RID: 28808
		// (get) Token: 0x06013D74 RID: 81268 RVA: 0x004FDD00 File Offset: 0x004FBF00
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionEnvironmentEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CAFE RID: 51966
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAFF RID: 51967
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB00 RID: 51968
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
