﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001052 RID: 4178
	[Serializable]
	public class ScribeAnalyticsBatch : Object
	{
		// Token: 0x170070C6 RID: 28870
		// (get) Token: 0x06013E35 RID: 81461 RVA: 0x00500B80 File Offset: 0x004FED80
		public unsafe AnalyticsEventType EventType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070C7 RID: 28871
		// (get) Token: 0x06013E36 RID: 81462 RVA: 0x00500BD0 File Offset: 0x004FEDD0
		public unsafe int Count
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_get_Count_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070C8 RID: 28872
		// (get) Token: 0x06013E37 RID: 81463 RVA: 0x00500C20 File Offset: 0x004FEE20
		public unsafe int FailedAttempts
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_get_FailedAttempts_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170070C9 RID: 28873
		// (get) Token: 0x06013E38 RID: 81464 RVA: 0x00500C70 File Offset: 0x004FEE70
		// (set) Token: 0x06013E39 RID: 81465 RVA: 0x00500CC0 File Offset: 0x004FEEC0
		public unsafe bool CreatedByPool
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013E3A RID: 81466 RVA: 0x00500D14 File Offset: 0x004FEF14
		[CallerCount(0)]
		public unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E3B RID: 81467 RVA: 0x00500D58 File Offset: 0x004FEF58
		[CallerCount(0)]
		public unsafe void AddEvent(ScribeAnalyticsEvent scribeEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(scribeEvent));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_AddEvent_Public_Void_ScribeAnalyticsEvent_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E3C RID: 81468 RVA: 0x00500DB8 File Offset: 0x004FEFB8
		[CallerCount(0)]
		public unsafe void ApplyOtherBatch(ScribeAnalyticsBatch otherBatch)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(otherBatch);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_ApplyOtherBatch_Public_Void_ScribeAnalyticsBatch_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E3D RID: 81469 RVA: 0x00500E14 File Offset: 0x004FF014
		[CallerCount(0)]
		public unsafe void OnBatchFailed()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr_OnBatchFailed_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E3E RID: 81470 RVA: 0x00500E58 File Offset: 0x004FF058
		[CallerCount(0)]
		public unsafe ScribeAnalyticsBatch() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ScribeAnalyticsBatch.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013E3F RID: 81471 RVA: 0x00500EA4 File Offset: 0x004FF0A4
		// Note: this type is marked as 'beforefieldinit'.
		static ScribeAnalyticsBatch()
		{
			Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "ScribeAnalyticsBatch");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr);
			ScribeAnalyticsBatch.NativeFieldInfoPtr_FAILED_BATCH_RETRIES = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, "FAILED_BATCH_RETRIES");
			ScribeAnalyticsBatch.NativeFieldInfoPtr__eventType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, "_eventType");
			ScribeAnalyticsBatch.NativeFieldInfoPtr_logs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, "logs");
			ScribeAnalyticsBatch.NativeFieldInfoPtr__failedAttempts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, "_failedAttempts");
			ScribeAnalyticsBatch.NativeFieldInfoPtr__CreatedByPool_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, "<CreatedByPool>k__BackingField");
			ScribeAnalyticsBatch.NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688708);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_get_Count_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688709);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_get_FailedAttempts_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688710);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688711);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688712);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688713);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_AddEvent_Public_Void_ScribeAnalyticsEvent_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688714);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_ApplyOtherBatch_Public_Void_ScribeAnalyticsBatch_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688715);
			ScribeAnalyticsBatch.NativeMethodInfoPtr_OnBatchFailed_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688716);
			ScribeAnalyticsBatch.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr, 100688717);
		}

		// Token: 0x06013E40 RID: 81472 RVA: 0x00002988 File Offset: 0x00000B88
		public ScribeAnalyticsBatch(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170070C0 RID: 28864
		// (get) Token: 0x06013E41 RID: 81473 RVA: 0x00501000 File Offset: 0x004FF200
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ScribeAnalyticsBatch>.NativeClassPtr));
			}
		}

		// Token: 0x170070C1 RID: 28865
		// (get) Token: 0x06013E42 RID: 81474 RVA: 0x00501014 File Offset: 0x004FF214
		// (set) Token: 0x06013E43 RID: 81475 RVA: 0x00501032 File Offset: 0x004FF232
		public unsafe static int FAILED_BATCH_RETRIES
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ScribeAnalyticsBatch.NativeFieldInfoPtr_FAILED_BATCH_RETRIES, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ScribeAnalyticsBatch.NativeFieldInfoPtr_FAILED_BATCH_RETRIES, (void*)(&value));
			}
		}

		// Token: 0x170070C2 RID: 28866
		// (get) Token: 0x06013E44 RID: 81476 RVA: 0x00501044 File Offset: 0x004FF244
		// (set) Token: 0x06013E45 RID: 81477 RVA: 0x0050106C File Offset: 0x004FF26C
		public unsafe AnalyticsEventType _eventType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__eventType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__eventType)) = value;
			}
		}

		// Token: 0x170070C3 RID: 28867
		// (get) Token: 0x06013E46 RID: 81478 RVA: 0x00501090 File Offset: 0x004FF290
		// (set) Token: 0x06013E47 RID: 81479 RVA: 0x005010C4 File Offset: 0x004FF2C4
		public unsafe List<ScribeAnalyticsEvent> logs
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr_logs);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<ScribeAnalyticsEvent>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr_logs), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070C4 RID: 28868
		// (get) Token: 0x06013E48 RID: 81480 RVA: 0x005010EC File Offset: 0x004FF2EC
		// (set) Token: 0x06013E49 RID: 81481 RVA: 0x00501114 File Offset: 0x004FF314
		public unsafe int _failedAttempts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__failedAttempts);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__failedAttempts)) = value;
			}
		}

		// Token: 0x170070C5 RID: 28869
		// (get) Token: 0x06013E4A RID: 81482 RVA: 0x00501138 File Offset: 0x004FF338
		// (set) Token: 0x06013E4B RID: 81483 RVA: 0x00501160 File Offset: 0x004FF360
		public unsafe bool _CreatedByPool_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__CreatedByPool_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ScribeAnalyticsBatch.NativeFieldInfoPtr__CreatedByPool_k__BackingField)) = value;
			}
		}

		// Token: 0x0400CB6A RID: 52074
		private static readonly IntPtr NativeFieldInfoPtr_FAILED_BATCH_RETRIES;

		// Token: 0x0400CB6B RID: 52075
		private static readonly IntPtr NativeFieldInfoPtr__eventType;

		// Token: 0x0400CB6C RID: 52076
		private static readonly IntPtr NativeFieldInfoPtr_logs;

		// Token: 0x0400CB6D RID: 52077
		private static readonly IntPtr NativeFieldInfoPtr__failedAttempts;

		// Token: 0x0400CB6E RID: 52078
		private static readonly IntPtr NativeFieldInfoPtr__CreatedByPool_k__BackingField;

		// Token: 0x0400CB6F RID: 52079
		private static readonly IntPtr NativeMethodInfoPtr_get_EventType_Public_get_AnalyticsEventType_0;

		// Token: 0x0400CB70 RID: 52080
		private static readonly IntPtr NativeMethodInfoPtr_get_Count_Public_get_Int32_0;

		// Token: 0x0400CB71 RID: 52081
		private static readonly IntPtr NativeMethodInfoPtr_get_FailedAttempts_Public_get_Int32_0;

		// Token: 0x0400CB72 RID: 52082
		private static readonly IntPtr NativeMethodInfoPtr_get_CreatedByPool_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400CB73 RID: 52083
		private static readonly IntPtr NativeMethodInfoPtr_set_CreatedByPool_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400CB74 RID: 52084
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400CB75 RID: 52085
		private static readonly IntPtr NativeMethodInfoPtr_AddEvent_Public_Void_ScribeAnalyticsEvent_0;

		// Token: 0x0400CB76 RID: 52086
		private static readonly IntPtr NativeMethodInfoPtr_ApplyOtherBatch_Public_Void_ScribeAnalyticsBatch_0;

		// Token: 0x0400CB77 RID: 52087
		private static readonly IntPtr NativeMethodInfoPtr_OnBatchFailed_Public_Void_0;

		// Token: 0x0400CB78 RID: 52088
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
