﻿using System;

namespace DPI.Analytics
{
	// Token: 0x02001031 RID: 4145
	[Flags]
	public enum AnalyticsDataType
	{
		// Token: 0x0400CABE RID: 51902
		None = 0,
		// Token: 0x0400CABF RID: 51903
		Aggregated = 1,
		// Token: 0x0400CAC0 RID: 51904
		User = 2,
		// Token: 0x0400CAC1 RID: 51905
		All = -1
	}
}
