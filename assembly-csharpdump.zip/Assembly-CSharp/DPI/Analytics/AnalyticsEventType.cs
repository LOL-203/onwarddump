﻿using System;

namespace DPI.Analytics
{
	// Token: 0x02001032 RID: 4146
	[Flags]
	public enum AnalyticsEventType
	{
		// Token: 0x0400CAC3 RID: 51907
		Undefined = 0,
		// Token: 0x0400CAC4 RID: 51908
		Standard = 1,
		// Token: 0x0400CAC5 RID: 51909
		RoundEnd = 2,
		// Token: 0x0400CAC6 RID: 51910
		MapChanged = 4,
		// Token: 0x0400CAC7 RID: 51911
		UserSession = 8,
		// Token: 0x0400CAC8 RID: 51912
		All = -1
	}
}
