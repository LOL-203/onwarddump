﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200104B RID: 4171
	public class AnalyticsSystemStatus : Object
	{
		// Token: 0x170070A2 RID: 28834
		// (get) Token: 0x06013DDD RID: 81373 RVA: 0x004FF944 File Offset: 0x004FDB44
		public unsafe AnalyticsSystemState State
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(AnalyticsSystemStatus.NativeMethodInfoPtr_get_State_Public_get_AnalyticsSystemState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06013DDE RID: 81374 RVA: 0x004FF994 File Offset: 0x004FDB94
		[CallerCount(0)]
		public unsafe void Initialize(Action onSystemActive, Action onSystemFailed)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(onSystemActive);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(onSystemFailed);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsSystemStatus.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_Action_Action_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DDF RID: 81375 RVA: 0x004FFA10 File Offset: 0x004FDC10
		[CallerCount(0)]
		public unsafe bool CanSendAnalyticsEvent(AnalyticsDataType dataType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dataType;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AnalyticsSystemStatus.NativeMethodInfoPtr_CanSendAnalyticsEvent_Public_Abstract_Virtual_New_Boolean_AnalyticsDataType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013DE0 RID: 81376 RVA: 0x004FFA80 File Offset: 0x004FDC80
		[CallerCount(0)]
		public unsafe AnalyticsSystemStatus() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AnalyticsSystemStatus.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DE1 RID: 81377 RVA: 0x004FFACC File Offset: 0x004FDCCC
		// Note: this type is marked as 'beforefieldinit'.
		static AnalyticsSystemStatus()
		{
			Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "AnalyticsSystemStatus");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr);
			AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemActive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, "_onSystemActive");
			AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemFailed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, "_onSystemFailed");
			AnalyticsSystemStatus.NativeFieldInfoPtr__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, "_state");
			AnalyticsSystemStatus.NativeMethodInfoPtr_get_State_Public_get_AnalyticsSystemState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, 100688692);
			AnalyticsSystemStatus.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_Action_Action_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, 100688693);
			AnalyticsSystemStatus.NativeMethodInfoPtr_CanSendAnalyticsEvent_Public_Abstract_Virtual_New_Boolean_AnalyticsDataType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, 100688694);
			AnalyticsSystemStatus.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr, 100688695);
		}

		// Token: 0x06013DE2 RID: 81378 RVA: 0x00002988 File Offset: 0x00000B88
		public AnalyticsSystemStatus(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700709E RID: 28830
		// (get) Token: 0x06013DE3 RID: 81379 RVA: 0x004FFB88 File Offset: 0x004FDD88
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AnalyticsSystemStatus>.NativeClassPtr));
			}
		}

		// Token: 0x1700709F RID: 28831
		// (get) Token: 0x06013DE4 RID: 81380 RVA: 0x004FFB9C File Offset: 0x004FDD9C
		// (set) Token: 0x06013DE5 RID: 81381 RVA: 0x004FFBD0 File Offset: 0x004FDDD0
		public unsafe Action _onSystemActive
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemActive);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemActive), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070A0 RID: 28832
		// (get) Token: 0x06013DE6 RID: 81382 RVA: 0x004FFBF8 File Offset: 0x004FDDF8
		// (set) Token: 0x06013DE7 RID: 81383 RVA: 0x004FFC2C File Offset: 0x004FDE2C
		public unsafe Action _onSystemFailed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemFailed);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__onSystemFailed), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170070A1 RID: 28833
		// (get) Token: 0x06013DE8 RID: 81384 RVA: 0x004FFC54 File Offset: 0x004FDE54
		// (set) Token: 0x06013DE9 RID: 81385 RVA: 0x004FFC7C File Offset: 0x004FDE7C
		public unsafe AnalyticsSystemState _state
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__state);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AnalyticsSystemStatus.NativeFieldInfoPtr__state)) = value;
			}
		}

		// Token: 0x0400CB42 RID: 52034
		private static readonly IntPtr NativeFieldInfoPtr__onSystemActive;

		// Token: 0x0400CB43 RID: 52035
		private static readonly IntPtr NativeFieldInfoPtr__onSystemFailed;

		// Token: 0x0400CB44 RID: 52036
		private static readonly IntPtr NativeFieldInfoPtr__state;

		// Token: 0x0400CB45 RID: 52037
		private static readonly IntPtr NativeMethodInfoPtr_get_State_Public_get_AnalyticsSystemState_0;

		// Token: 0x0400CB46 RID: 52038
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_Action_Action_0;

		// Token: 0x0400CB47 RID: 52039
		private static readonly IntPtr NativeMethodInfoPtr_CanSendAnalyticsEvent_Public_Abstract_Virtual_New_Boolean_AnalyticsDataType_0;

		// Token: 0x0400CB48 RID: 52040
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
