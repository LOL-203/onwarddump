﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001036 RID: 4150
	[Serializable]
	public class UserSessionAnalyticsEvent : BaseAnalyticsEvent
	{
		// Token: 0x17007080 RID: 28800
		// (get) Token: 0x06013D42 RID: 81218 RVA: 0x004FCEC0 File Offset: 0x004FB0C0
		// (set) Token: 0x06013D43 RID: 81219 RVA: 0x004FCF0C File Offset: 0x004FB10C
		public unsafe string timestamp
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_timestamp_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_timestamp_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007081 RID: 28801
		// (get) Token: 0x06013D44 RID: 81220 RVA: 0x004FCF68 File Offset: 0x004FB168
		// (set) Token: 0x06013D45 RID: 81221 RVA: 0x004FCFB4 File Offset: 0x004FB1B4
		public unsafe string user_id
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_user_id_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_user_id_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007082 RID: 28802
		// (get) Token: 0x06013D46 RID: 81222 RVA: 0x004FD010 File Offset: 0x004FB210
		// (set) Token: 0x06013D47 RID: 81223 RVA: 0x004FD05C File Offset: 0x004FB25C
		public unsafe string session_id
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_session_id_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_session_id_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007083 RID: 28803
		// (get) Token: 0x06013D48 RID: 81224 RVA: 0x004FD0B8 File Offset: 0x004FB2B8
		// (set) Token: 0x06013D49 RID: 81225 RVA: 0x004FD104 File Offset: 0x004FB304
		public unsafe string match_id
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_match_id_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_match_id_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007084 RID: 28804
		// (get) Token: 0x06013D4A RID: 81226 RVA: 0x004FD160 File Offset: 0x004FB360
		// (set) Token: 0x06013D4B RID: 81227 RVA: 0x004FD1AC File Offset: 0x004FB3AC
		public unsafe string context
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_context_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_context_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17007085 RID: 28805
		// (get) Token: 0x06013D4C RID: 81228 RVA: 0x004FD208 File Offset: 0x004FB408
		// (set) Token: 0x06013D4D RID: 81229 RVA: 0x004FD260 File Offset: 0x004FB460
		public unsafe UserSessionEventValue innerEventData
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_innerEventData_Public_get_UserSessionEventValue_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new UserSessionEventValue(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_innerEventData_Public_set_Void_UserSessionEventValue_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013D4E RID: 81230 RVA: 0x004FD2BC File Offset: 0x004FB4BC
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionAnalyticsEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D4F RID: 81231 RVA: 0x004FD30C File Offset: 0x004FB50C
		[CallerCount(0)]
		public unsafe void SetInnerEventDataObject()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionAnalyticsEvent.NativeMethodInfoPtr_SetInnerEventDataObject_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D50 RID: 81232 RVA: 0x004FD35C File Offset: 0x004FB55C
		[CallerCount(0)]
		public new unsafe AnalyticsDataType GetEventDataType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Virtual_AnalyticsDataType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D51 RID: 81233 RVA: 0x004FD3B8 File Offset: 0x004FB5B8
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D52 RID: 81234 RVA: 0x004FD408 File Offset: 0x004FB608
		[CallerCount(0)]
		public new unsafe AnalyticsEventType GetEventType()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Virtual_AnalyticsEventType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013D53 RID: 81235 RVA: 0x004FD464 File Offset: 0x004FB664
		[CallerCount(0)]
		public unsafe UserSessionAnalyticsEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionAnalyticsEvent.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D54 RID: 81236 RVA: 0x004FD4B0 File Offset: 0x004FB6B0
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionAnalyticsEvent()
		{
			Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionAnalyticsEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr);
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__timestamp_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<timestamp>k__BackingField");
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__user_id_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<user_id>k__BackingField");
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__session_id_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<session_id>k__BackingField");
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__match_id_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<match_id>k__BackingField");
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__context_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<context>k__BackingField");
			UserSessionAnalyticsEvent.NativeFieldInfoPtr__innerEventData_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, "<innerEventData>k__BackingField");
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_timestamp_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688615);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_timestamp_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688616);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_user_id_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688617);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_user_id_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688618);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_session_id_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688619);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_session_id_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688620);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_match_id_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688621);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_match_id_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688622);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_context_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688623);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_context_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688624);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_get_innerEventData_Public_get_UserSessionEventValue_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688625);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_set_innerEventData_Public_set_Void_UserSessionEventValue_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688626);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688627);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_SetInnerEventDataObject_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688628);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_GetEventDataType_Public_Virtual_AnalyticsDataType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688629);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688630);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr_GetEventType_Public_Virtual_AnalyticsEventType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688631);
			UserSessionAnalyticsEvent.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr, 100688632);
		}

		// Token: 0x06013D55 RID: 81237 RVA: 0x004FD6C0 File Offset: 0x004FB8C0
		public UserSessionAnalyticsEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007079 RID: 28793
		// (get) Token: 0x06013D56 RID: 81238 RVA: 0x004FD6C9 File Offset: 0x004FB8C9
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionAnalyticsEvent>.NativeClassPtr));
			}
		}

		// Token: 0x1700707A RID: 28794
		// (get) Token: 0x06013D57 RID: 81239 RVA: 0x004FD6DC File Offset: 0x004FB8DC
		// (set) Token: 0x06013D58 RID: 81240 RVA: 0x004FD705 File Offset: 0x004FB905
		public unsafe string _timestamp_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__timestamp_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__timestamp_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700707B RID: 28795
		// (get) Token: 0x06013D59 RID: 81241 RVA: 0x004FD72C File Offset: 0x004FB92C
		// (set) Token: 0x06013D5A RID: 81242 RVA: 0x004FD755 File Offset: 0x004FB955
		public unsafe string _user_id_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__user_id_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__user_id_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700707C RID: 28796
		// (get) Token: 0x06013D5B RID: 81243 RVA: 0x004FD77C File Offset: 0x004FB97C
		// (set) Token: 0x06013D5C RID: 81244 RVA: 0x004FD7A5 File Offset: 0x004FB9A5
		public unsafe string _session_id_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__session_id_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__session_id_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700707D RID: 28797
		// (get) Token: 0x06013D5D RID: 81245 RVA: 0x004FD7CC File Offset: 0x004FB9CC
		// (set) Token: 0x06013D5E RID: 81246 RVA: 0x004FD7F5 File Offset: 0x004FB9F5
		public unsafe string _match_id_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__match_id_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__match_id_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700707E RID: 28798
		// (get) Token: 0x06013D5F RID: 81247 RVA: 0x004FD81C File Offset: 0x004FBA1C
		// (set) Token: 0x06013D60 RID: 81248 RVA: 0x004FD845 File Offset: 0x004FBA45
		public unsafe string _context_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__context_k__BackingField);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__context_k__BackingField), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700707F RID: 28799
		// (get) Token: 0x06013D61 RID: 81249 RVA: 0x004FD86C File Offset: 0x004FBA6C
		// (set) Token: 0x06013D62 RID: 81250 RVA: 0x004FD8A0 File Offset: 0x004FBAA0
		public unsafe UserSessionEventValue _innerEventData_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__innerEventData_k__BackingField);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UserSessionEventValue(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UserSessionAnalyticsEvent.NativeFieldInfoPtr__innerEventData_k__BackingField), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CAE0 RID: 51936
		private static readonly IntPtr NativeFieldInfoPtr__timestamp_k__BackingField;

		// Token: 0x0400CAE1 RID: 51937
		private static readonly IntPtr NativeFieldInfoPtr__user_id_k__BackingField;

		// Token: 0x0400CAE2 RID: 51938
		private static readonly IntPtr NativeFieldInfoPtr__session_id_k__BackingField;

		// Token: 0x0400CAE3 RID: 51939
		private static readonly IntPtr NativeFieldInfoPtr__match_id_k__BackingField;

		// Token: 0x0400CAE4 RID: 51940
		private static readonly IntPtr NativeFieldInfoPtr__context_k__BackingField;

		// Token: 0x0400CAE5 RID: 51941
		private static readonly IntPtr NativeFieldInfoPtr__innerEventData_k__BackingField;

		// Token: 0x0400CAE6 RID: 51942
		private static readonly IntPtr NativeMethodInfoPtr_get_timestamp_Public_get_String_0;

		// Token: 0x0400CAE7 RID: 51943
		private static readonly IntPtr NativeMethodInfoPtr_set_timestamp_Public_set_Void_String_0;

		// Token: 0x0400CAE8 RID: 51944
		private static readonly IntPtr NativeMethodInfoPtr_get_user_id_Public_get_String_0;

		// Token: 0x0400CAE9 RID: 51945
		private static readonly IntPtr NativeMethodInfoPtr_set_user_id_Public_set_Void_String_0;

		// Token: 0x0400CAEA RID: 51946
		private static readonly IntPtr NativeMethodInfoPtr_get_session_id_Public_get_String_0;

		// Token: 0x0400CAEB RID: 51947
		private static readonly IntPtr NativeMethodInfoPtr_set_session_id_Public_set_Void_String_0;

		// Token: 0x0400CAEC RID: 51948
		private static readonly IntPtr NativeMethodInfoPtr_get_match_id_Public_get_String_0;

		// Token: 0x0400CAED RID: 51949
		private static readonly IntPtr NativeMethodInfoPtr_set_match_id_Public_set_Void_String_0;

		// Token: 0x0400CAEE RID: 51950
		private static readonly IntPtr NativeMethodInfoPtr_get_context_Public_get_String_0;

		// Token: 0x0400CAEF RID: 51951
		private static readonly IntPtr NativeMethodInfoPtr_set_context_Public_set_Void_String_0;

		// Token: 0x0400CAF0 RID: 51952
		private static readonly IntPtr NativeMethodInfoPtr_get_innerEventData_Public_get_UserSessionEventValue_0;

		// Token: 0x0400CAF1 RID: 51953
		private static readonly IntPtr NativeMethodInfoPtr_set_innerEventData_Public_set_Void_UserSessionEventValue_0;

		// Token: 0x0400CAF2 RID: 51954
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAF3 RID: 51955
		private static readonly IntPtr NativeMethodInfoPtr_SetInnerEventDataObject_Public_Virtual_New_Void_0;

		// Token: 0x0400CAF4 RID: 51956
		private static readonly IntPtr NativeMethodInfoPtr_GetEventDataType_Public_Virtual_AnalyticsDataType_0;

		// Token: 0x0400CAF5 RID: 51957
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CAF6 RID: 51958
		private static readonly IntPtr NativeMethodInfoPtr_GetEventType_Public_Virtual_AnalyticsEventType_0;

		// Token: 0x0400CAF7 RID: 51959
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
