﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001042 RID: 4162
	public class UserSessionTutorialEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013DAC RID: 81324 RVA: 0x004FEA70 File Offset: 0x004FCC70
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionTutorialEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DAD RID: 81325 RVA: 0x004FEAC0 File Offset: 0x004FCCC0
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionTutorialEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DAE RID: 81326 RVA: 0x004FEB10 File Offset: 0x004FCD10
		[CallerCount(0)]
		public unsafe UserSessionTutorialEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionTutorialEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DAF RID: 81327 RVA: 0x004FEB5C File Offset: 0x004FCD5C
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionTutorialEvent()
		{
			Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionTutorialEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr);
			UserSessionTutorialEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr, 100688669);
			UserSessionTutorialEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr, 100688670);
			UserSessionTutorialEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr, 100688671);
		}

		// Token: 0x06013DB0 RID: 81328 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionTutorialEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007095 RID: 28821
		// (get) Token: 0x06013DB1 RID: 81329 RVA: 0x004FEBC8 File Offset: 0x004FCDC8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionTutorialEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB1E RID: 51998
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB1F RID: 51999
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB20 RID: 52000
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
