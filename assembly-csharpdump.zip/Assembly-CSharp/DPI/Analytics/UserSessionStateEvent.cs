﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x02001041 RID: 4161
	public class UserSessionStateEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013DA6 RID: 81318 RVA: 0x004FE904 File Offset: 0x004FCB04
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionStateEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA7 RID: 81319 RVA: 0x004FE954 File Offset: 0x004FCB54
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionStateEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA8 RID: 81320 RVA: 0x004FE9A4 File Offset: 0x004FCBA4
		[CallerCount(0)]
		public unsafe UserSessionStateEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionStateEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013DA9 RID: 81321 RVA: 0x004FE9F0 File Offset: 0x004FCBF0
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionStateEvent()
		{
			Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionStateEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr);
			UserSessionStateEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr, 100688666);
			UserSessionStateEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr, 100688667);
			UserSessionStateEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr, 100688668);
		}

		// Token: 0x06013DAA RID: 81322 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionStateEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007094 RID: 28820
		// (get) Token: 0x06013DAB RID: 81323 RVA: 0x004FEA5C File Offset: 0x004FCC5C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionStateEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB1B RID: 51995
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB1C RID: 51996
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB1D RID: 51997
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
