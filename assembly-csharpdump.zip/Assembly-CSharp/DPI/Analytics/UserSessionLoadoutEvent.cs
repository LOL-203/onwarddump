﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Analytics
{
	// Token: 0x0200103C RID: 4156
	public class UserSessionLoadoutEvent : UserSessionAnalyticsEvent
	{
		// Token: 0x06013D88 RID: 81288 RVA: 0x004FE1E8 File Offset: 0x004FC3E8
		[CallerCount(0)]
		public new unsafe void ReturnedToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionLoadoutEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D89 RID: 81289 RVA: 0x004FE238 File Offset: 0x004FC438
		[CallerCount(0)]
		public new unsafe void ReturnEventToPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UserSessionLoadoutEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D8A RID: 81290 RVA: 0x004FE288 File Offset: 0x004FC488
		[CallerCount(0)]
		public unsafe UserSessionLoadoutEvent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UserSessionLoadoutEvent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013D8B RID: 81291 RVA: 0x004FE2D4 File Offset: 0x004FC4D4
		// Note: this type is marked as 'beforefieldinit'.
		static UserSessionLoadoutEvent()
		{
			Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Analytics", "UserSessionLoadoutEvent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr);
			UserSessionLoadoutEvent.NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr, 100688651);
			UserSessionLoadoutEvent.NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr, 100688652);
			UserSessionLoadoutEvent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr, 100688653);
		}

		// Token: 0x06013D8C RID: 81292 RVA: 0x004FDA20 File Offset: 0x004FBC20
		public UserSessionLoadoutEvent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700708F RID: 28815
		// (get) Token: 0x06013D8D RID: 81293 RVA: 0x004FE340 File Offset: 0x004FC540
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UserSessionLoadoutEvent>.NativeClassPtr));
			}
		}

		// Token: 0x0400CB0C RID: 51980
		private static readonly IntPtr NativeMethodInfoPtr_ReturnedToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB0D RID: 51981
		private static readonly IntPtr NativeMethodInfoPtr_ReturnEventToPool_Public_Virtual_Void_0;

		// Token: 0x0400CB0E RID: 51982
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
