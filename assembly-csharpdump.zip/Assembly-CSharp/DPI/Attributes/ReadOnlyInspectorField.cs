﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Attributes
{
	// Token: 0x0200114B RID: 4427
	public class ReadOnlyInspectorField : PropertyAttribute
	{
		// Token: 0x06014A0D RID: 84493 RVA: 0x00530D58 File Offset: 0x0052EF58
		[CallerCount(0)]
		public unsafe ReadOnlyInspectorField() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ReadOnlyInspectorField>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ReadOnlyInspectorField.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A0E RID: 84494 RVA: 0x00530DA3 File Offset: 0x0052EFA3
		// Note: this type is marked as 'beforefieldinit'.
		static ReadOnlyInspectorField()
		{
			Il2CppClassPointerStore<ReadOnlyInspectorField>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Attributes", "ReadOnlyInspectorField");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ReadOnlyInspectorField>.NativeClassPtr);
			ReadOnlyInspectorField.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ReadOnlyInspectorField>.NativeClassPtr, 100689640);
		}

		// Token: 0x06014A0F RID: 84495 RVA: 0x0003500C File Offset: 0x0003320C
		public ReadOnlyInspectorField(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074BD RID: 29885
		// (get) Token: 0x06014A10 RID: 84496 RVA: 0x00530DDC File Offset: 0x0052EFDC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ReadOnlyInspectorField>.NativeClassPtr));
			}
		}

		// Token: 0x0400D30D RID: 54029
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
