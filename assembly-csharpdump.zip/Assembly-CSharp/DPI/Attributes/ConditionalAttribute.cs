﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Attributes
{
	// Token: 0x02001149 RID: 4425
	public class ConditionalAttribute : PropertyAttribute
	{
		// Token: 0x060149FF RID: 84479 RVA: 0x00530AA4 File Offset: 0x0052ECA4
		[CallerCount(0)]
		public unsafe ConditionalAttribute(string propertyName, Il2CppSystem.Object value, bool invertCheck = true) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(propertyName);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref invertCheck;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ConditionalAttribute.NativeMethodInfoPtr__ctor_Public_Void_String_Object_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A00 RID: 84480 RVA: 0x00530B34 File Offset: 0x0052ED34
		// Note: this type is marked as 'beforefieldinit'.
		static ConditionalAttribute()
		{
			Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Attributes", "ConditionalAttribute");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr);
			ConditionalAttribute.NativeFieldInfoPtr_PropertyName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr, "PropertyName");
			ConditionalAttribute.NativeFieldInfoPtr_TargetValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr, "TargetValue");
			ConditionalAttribute.NativeFieldInfoPtr_InvertCheck = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr, "InvertCheck");
			ConditionalAttribute.NativeMethodInfoPtr__ctor_Public_Void_String_Object_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr, 100689638);
		}

		// Token: 0x06014A01 RID: 84481 RVA: 0x0003500C File Offset: 0x0003320C
		public ConditionalAttribute(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074B8 RID: 29880
		// (get) Token: 0x06014A02 RID: 84482 RVA: 0x00530BB4 File Offset: 0x0052EDB4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ConditionalAttribute>.NativeClassPtr));
			}
		}

		// Token: 0x170074B9 RID: 29881
		// (get) Token: 0x06014A03 RID: 84483 RVA: 0x00530BC8 File Offset: 0x0052EDC8
		// (set) Token: 0x06014A04 RID: 84484 RVA: 0x00530BF1 File Offset: 0x0052EDF1
		public unsafe string PropertyName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_PropertyName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_PropertyName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170074BA RID: 29882
		// (get) Token: 0x06014A05 RID: 84485 RVA: 0x00530C18 File Offset: 0x0052EE18
		// (set) Token: 0x06014A06 RID: 84486 RVA: 0x00530C4C File Offset: 0x0052EE4C
		public unsafe Il2CppSystem.Object TargetValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_TargetValue);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_TargetValue), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170074BB RID: 29883
		// (get) Token: 0x06014A07 RID: 84487 RVA: 0x00530C74 File Offset: 0x0052EE74
		// (set) Token: 0x06014A08 RID: 84488 RVA: 0x00530C9C File Offset: 0x0052EE9C
		public unsafe bool InvertCheck
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_InvertCheck);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ConditionalAttribute.NativeFieldInfoPtr_InvertCheck)) = value;
			}
		}

		// Token: 0x0400D308 RID: 54024
		private static readonly IntPtr NativeFieldInfoPtr_PropertyName;

		// Token: 0x0400D309 RID: 54025
		private static readonly IntPtr NativeFieldInfoPtr_TargetValue;

		// Token: 0x0400D30A RID: 54026
		private static readonly IntPtr NativeFieldInfoPtr_InvertCheck;

		// Token: 0x0400D30B RID: 54027
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_Object_Boolean_0;
	}
}
