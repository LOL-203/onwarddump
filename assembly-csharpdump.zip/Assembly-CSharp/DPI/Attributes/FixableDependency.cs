﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Attributes
{
	// Token: 0x0200114A RID: 4426
	public class FixableDependency : PropertyAttribute
	{
		// Token: 0x06014A09 RID: 84489 RVA: 0x00530CC0 File Offset: 0x0052EEC0
		[CallerCount(0)]
		public unsafe FixableDependency() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<FixableDependency>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(FixableDependency.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A0A RID: 84490 RVA: 0x00530D0B File Offset: 0x0052EF0B
		// Note: this type is marked as 'beforefieldinit'.
		static FixableDependency()
		{
			Il2CppClassPointerStore<FixableDependency>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Attributes", "FixableDependency");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<FixableDependency>.NativeClassPtr);
			FixableDependency.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<FixableDependency>.NativeClassPtr, 100689639);
		}

		// Token: 0x06014A0B RID: 84491 RVA: 0x0003500C File Offset: 0x0003320C
		public FixableDependency(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074BC RID: 29884
		// (get) Token: 0x06014A0C RID: 84492 RVA: 0x00530D44 File Offset: 0x0052EF44
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<FixableDependency>.NativeClassPtr));
			}
		}

		// Token: 0x0400D30C RID: 54028
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
