﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Attributes
{
	// Token: 0x0200114C RID: 4428
	public class SerializedUlongEnumAttribute : PropertyAttribute
	{
		// Token: 0x06014A11 RID: 84497 RVA: 0x00530DF0 File Offset: 0x0052EFF0
		[CallerCount(0)]
		public unsafe SerializedUlongEnumAttribute(Type type) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(type);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SerializedUlongEnumAttribute.NativeMethodInfoPtr__ctor_Public_Void_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06014A12 RID: 84498 RVA: 0x00530E54 File Offset: 0x0052F054
		// Note: this type is marked as 'beforefieldinit'.
		static SerializedUlongEnumAttribute()
		{
			Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Attributes", "SerializedUlongEnumAttribute");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr);
			SerializedUlongEnumAttribute.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr, "Type");
			SerializedUlongEnumAttribute.NativeMethodInfoPtr__ctor_Public_Void_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr, 100689641);
		}

		// Token: 0x06014A13 RID: 84499 RVA: 0x0003500C File Offset: 0x0003320C
		public SerializedUlongEnumAttribute(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170074BE RID: 29886
		// (get) Token: 0x06014A14 RID: 84500 RVA: 0x00530EAC File Offset: 0x0052F0AC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SerializedUlongEnumAttribute>.NativeClassPtr));
			}
		}

		// Token: 0x170074BF RID: 29887
		// (get) Token: 0x06014A15 RID: 84501 RVA: 0x00530EC0 File Offset: 0x0052F0C0
		// (set) Token: 0x06014A16 RID: 84502 RVA: 0x00530EF4 File Offset: 0x0052F0F4
		public unsafe Type Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedUlongEnumAttribute.NativeFieldInfoPtr_Type);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Type(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SerializedUlongEnumAttribute.NativeFieldInfoPtr_Type), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D30E RID: 54030
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x0400D30F RID: 54031
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Type_0;
	}
}
