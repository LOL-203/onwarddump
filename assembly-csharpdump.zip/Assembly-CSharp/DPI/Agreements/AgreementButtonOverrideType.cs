﻿using System;

namespace DPI.Agreements
{
	// Token: 0x0200106C RID: 4204
	public enum AgreementButtonOverrideType
	{
		// Token: 0x0400CC2A RID: 52266
		NONE,
		// Token: 0x0400CC2B RID: 52267
		ACKNOWLEDGE,
		// Token: 0x0400CC2C RID: 52268
		OPTIN,
		// Token: 0x0400CC2D RID: 52269
		OPTOUT,
		// Token: 0x0400CC2E RID: 52270
		INFO,
		// Token: 0x0400CC2F RID: 52271
		BACK
	}
}
