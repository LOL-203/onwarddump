﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Agreements
{
	// Token: 0x0200106D RID: 4205
	public static class AgreementsUtils : Object
	{
		// Token: 0x1700712E RID: 28974
		// (get) Token: 0x06013F58 RID: 81752 RVA: 0x005052C4 File Offset: 0x005034C4
		public unsafe static string AGREEMENTS_RESOURCES_PATH
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(AgreementsUtils.NativeMethodInfoPtr_get_AGREEMENTS_RESOURCES_PATH_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x06013F59 RID: 81753 RVA: 0x00505300 File Offset: 0x00503500
		// Note: this type is marked as 'beforefieldinit'.
		static AgreementsUtils()
		{
			Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Agreements", "AgreementsUtils");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr);
			AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_WITH_EXTENSION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr, "AGREEMENT_FILENAME_WITH_EXTENSION");
			AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_NO_EXTENSION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr, "AGREEMENT_FILENAME_NO_EXTENSION");
			AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_EXTENSION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr, "AGREEMENT_EXTENSION");
			AgreementsUtils.NativeMethodInfoPtr_get_AGREEMENTS_RESOURCES_PATH_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr, 100688799);
		}

		// Token: 0x06013F5A RID: 81754 RVA: 0x00002988 File Offset: 0x00000B88
		public AgreementsUtils(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700712A RID: 28970
		// (get) Token: 0x06013F5B RID: 81755 RVA: 0x00505380 File Offset: 0x00503580
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AgreementsUtils>.NativeClassPtr));
			}
		}

		// Token: 0x1700712B RID: 28971
		// (get) Token: 0x06013F5C RID: 81756 RVA: 0x00505394 File Offset: 0x00503594
		// (set) Token: 0x06013F5D RID: 81757 RVA: 0x005053B4 File Offset: 0x005035B4
		public unsafe static string AGREEMENT_FILENAME_WITH_EXTENSION
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_WITH_EXTENSION, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_WITH_EXTENSION, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700712C RID: 28972
		// (get) Token: 0x06013F5E RID: 81758 RVA: 0x005053CC File Offset: 0x005035CC
		// (set) Token: 0x06013F5F RID: 81759 RVA: 0x005053EC File Offset: 0x005035EC
		public unsafe static string AGREEMENT_FILENAME_NO_EXTENSION
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_NO_EXTENSION, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_FILENAME_NO_EXTENSION, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700712D RID: 28973
		// (get) Token: 0x06013F60 RID: 81760 RVA: 0x00505404 File Offset: 0x00503604
		// (set) Token: 0x06013F61 RID: 81761 RVA: 0x00505424 File Offset: 0x00503624
		public unsafe static string AGREEMENT_EXTENSION
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_EXTENSION, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(AgreementsUtils.NativeFieldInfoPtr_AGREEMENT_EXTENSION, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CC30 RID: 52272
		private static readonly IntPtr NativeFieldInfoPtr_AGREEMENT_FILENAME_WITH_EXTENSION;

		// Token: 0x0400CC31 RID: 52273
		private static readonly IntPtr NativeFieldInfoPtr_AGREEMENT_FILENAME_NO_EXTENSION;

		// Token: 0x0400CC32 RID: 52274
		private static readonly IntPtr NativeFieldInfoPtr_AGREEMENT_EXTENSION;

		// Token: 0x0400CC33 RID: 52275
		private static readonly IntPtr NativeMethodInfoPtr_get_AGREEMENTS_RESOURCES_PATH_Public_Static_get_String_0;
	}
}
