﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Agreements
{
	// Token: 0x0200106E RID: 4206
	[Serializable]
	public class DownpourAgreements : Object
	{
		// Token: 0x06013F62 RID: 81762 RVA: 0x0050543C File Offset: 0x0050363C
		[CallerCount(0)]
		public unsafe DownpourAgreements() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DownpourAgreements.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013F63 RID: 81763 RVA: 0x00505488 File Offset: 0x00503688
		// Note: this type is marked as 'beforefieldinit'.
		static DownpourAgreements()
		{
			Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Agreements", "DownpourAgreements");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr);
			DownpourAgreements.NativeFieldInfoPtr_Agreements = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr, "Agreements");
			DownpourAgreements.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr, 100688800);
		}

		// Token: 0x06013F64 RID: 81764 RVA: 0x00002988 File Offset: 0x00000B88
		public DownpourAgreements(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700712F RID: 28975
		// (get) Token: 0x06013F65 RID: 81765 RVA: 0x005054E0 File Offset: 0x005036E0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DownpourAgreements>.NativeClassPtr));
			}
		}

		// Token: 0x17007130 RID: 28976
		// (get) Token: 0x06013F66 RID: 81766 RVA: 0x005054F4 File Offset: 0x005036F4
		// (set) Token: 0x06013F67 RID: 81767 RVA: 0x00505528 File Offset: 0x00503728
		public unsafe List<LicenseAgreement> Agreements
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DownpourAgreements.NativeFieldInfoPtr_Agreements);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<LicenseAgreement>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DownpourAgreements.NativeFieldInfoPtr_Agreements), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CC34 RID: 52276
		private static readonly IntPtr NativeFieldInfoPtr_Agreements;

		// Token: 0x0400CC35 RID: 52277
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
