﻿using System;

namespace DPI.Agreements
{
	// Token: 0x02001070 RID: 4208
	[Serializable]
	public enum LicenseAgreementType
	{
		// Token: 0x0400CC44 RID: 52292
		NONE,
		// Token: 0x0400CC45 RID: 52293
		ANALYTICS_USER_DATA,
		// Token: 0x0400CC46 RID: 52294
		ANALTICS_AGGREGATED,
		// Token: 0x0400CC47 RID: 52295
		USER_AGREEMENT,
		// Token: 0x0400CC48 RID: 52296
		THIRD_PARTY
	}
}
