﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace DPI.Agreements
{
	// Token: 0x0200106F RID: 4207
	[Serializable]
	public class LicenseAgreement : Object
	{
		// Token: 0x06013F68 RID: 81768 RVA: 0x00505550 File Offset: 0x00503750
		[CallerCount(0)]
		public unsafe LicenseAgreement() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreement.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013F69 RID: 81769 RVA: 0x0050559C File Offset: 0x0050379C
		// Note: this type is marked as 'beforefieldinit'.
		static LicenseAgreement()
		{
			Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Agreements", "LicenseAgreement");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr);
			LicenseAgreement.NativeFieldInfoPtr_ID = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "ID");
			LicenseAgreement.NativeFieldInfoPtr_LicenseType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "LicenseType");
			LicenseAgreement.NativeFieldInfoPtr_Name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "Name");
			LicenseAgreement.NativeFieldInfoPtr_Version = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "Version");
			LicenseAgreement.NativeFieldInfoPtr_Body = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "Body");
			LicenseAgreement.NativeFieldInfoPtr_Accepted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "Accepted");
			LicenseAgreement.NativeFieldInfoPtr_HasResponded = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "HasResponded");
			LicenseAgreement.NativeFieldInfoPtr_CanDecline = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "CanDecline");
			LicenseAgreement.NativeFieldInfoPtr_RequiresAcceptance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "RequiresAcceptance");
			LicenseAgreement.NativeFieldInfoPtr_InformationOnly = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "InformationOnly");
			LicenseAgreement.NativeFieldInfoPtr_InfoURL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "InfoURL");
			LicenseAgreement.NativeFieldInfoPtr_ButtonOverrides = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, "ButtonOverrides");
			LicenseAgreement.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr, 100688801);
		}

		// Token: 0x06013F6A RID: 81770 RVA: 0x00002988 File Offset: 0x00000B88
		public LicenseAgreement(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007131 RID: 28977
		// (get) Token: 0x06013F6B RID: 81771 RVA: 0x005056D0 File Offset: 0x005038D0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<LicenseAgreement>.NativeClassPtr));
			}
		}

		// Token: 0x17007132 RID: 28978
		// (get) Token: 0x06013F6C RID: 81772 RVA: 0x005056E4 File Offset: 0x005038E4
		// (set) Token: 0x06013F6D RID: 81773 RVA: 0x0050570D File Offset: 0x0050390D
		public unsafe string ID
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_ID);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_ID), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17007133 RID: 28979
		// (get) Token: 0x06013F6E RID: 81774 RVA: 0x00505734 File Offset: 0x00503934
		// (set) Token: 0x06013F6F RID: 81775 RVA: 0x0050575C File Offset: 0x0050395C
		public unsafe LicenseAgreementType LicenseType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_LicenseType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_LicenseType)) = value;
			}
		}

		// Token: 0x17007134 RID: 28980
		// (get) Token: 0x06013F70 RID: 81776 RVA: 0x00505780 File Offset: 0x00503980
		// (set) Token: 0x06013F71 RID: 81777 RVA: 0x005057A9 File Offset: 0x005039A9
		public unsafe string Name
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Name);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Name), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17007135 RID: 28981
		// (get) Token: 0x06013F72 RID: 81778 RVA: 0x005057D0 File Offset: 0x005039D0
		// (set) Token: 0x06013F73 RID: 81779 RVA: 0x005057F8 File Offset: 0x005039F8
		public unsafe int Version
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Version);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Version)) = value;
			}
		}

		// Token: 0x17007136 RID: 28982
		// (get) Token: 0x06013F74 RID: 81780 RVA: 0x0050581C File Offset: 0x00503A1C
		// (set) Token: 0x06013F75 RID: 81781 RVA: 0x00505845 File Offset: 0x00503A45
		public unsafe string Body
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Body);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Body), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17007137 RID: 28983
		// (get) Token: 0x06013F76 RID: 81782 RVA: 0x0050586C File Offset: 0x00503A6C
		// (set) Token: 0x06013F77 RID: 81783 RVA: 0x00505894 File Offset: 0x00503A94
		public unsafe bool Accepted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Accepted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_Accepted)) = value;
			}
		}

		// Token: 0x17007138 RID: 28984
		// (get) Token: 0x06013F78 RID: 81784 RVA: 0x005058B8 File Offset: 0x00503AB8
		// (set) Token: 0x06013F79 RID: 81785 RVA: 0x005058E0 File Offset: 0x00503AE0
		public unsafe bool HasResponded
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_HasResponded);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_HasResponded)) = value;
			}
		}

		// Token: 0x17007139 RID: 28985
		// (get) Token: 0x06013F7A RID: 81786 RVA: 0x00505904 File Offset: 0x00503B04
		// (set) Token: 0x06013F7B RID: 81787 RVA: 0x0050592C File Offset: 0x00503B2C
		public unsafe bool CanDecline
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_CanDecline);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_CanDecline)) = value;
			}
		}

		// Token: 0x1700713A RID: 28986
		// (get) Token: 0x06013F7C RID: 81788 RVA: 0x00505950 File Offset: 0x00503B50
		// (set) Token: 0x06013F7D RID: 81789 RVA: 0x00505978 File Offset: 0x00503B78
		public unsafe bool RequiresAcceptance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_RequiresAcceptance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_RequiresAcceptance)) = value;
			}
		}

		// Token: 0x1700713B RID: 28987
		// (get) Token: 0x06013F7E RID: 81790 RVA: 0x0050599C File Offset: 0x00503B9C
		// (set) Token: 0x06013F7F RID: 81791 RVA: 0x005059C4 File Offset: 0x00503BC4
		public unsafe bool InformationOnly
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_InformationOnly);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_InformationOnly)) = value;
			}
		}

		// Token: 0x1700713C RID: 28988
		// (get) Token: 0x06013F80 RID: 81792 RVA: 0x005059E8 File Offset: 0x00503BE8
		// (set) Token: 0x06013F81 RID: 81793 RVA: 0x00505A11 File Offset: 0x00503C11
		public unsafe string InfoURL
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_InfoURL);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_InfoURL), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700713D RID: 28989
		// (get) Token: 0x06013F82 RID: 81794 RVA: 0x00505A38 File Offset: 0x00503C38
		// (set) Token: 0x06013F83 RID: 81795 RVA: 0x00505A6C File Offset: 0x00503C6C
		public unsafe Il2CppReferenceArray<AgreementButtonOverride> ButtonOverrides
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_ButtonOverrides);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<AgreementButtonOverride>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreement.NativeFieldInfoPtr_ButtonOverrides), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400CC36 RID: 52278
		private static readonly IntPtr NativeFieldInfoPtr_ID;

		// Token: 0x0400CC37 RID: 52279
		private static readonly IntPtr NativeFieldInfoPtr_LicenseType;

		// Token: 0x0400CC38 RID: 52280
		private static readonly IntPtr NativeFieldInfoPtr_Name;

		// Token: 0x0400CC39 RID: 52281
		private static readonly IntPtr NativeFieldInfoPtr_Version;

		// Token: 0x0400CC3A RID: 52282
		private static readonly IntPtr NativeFieldInfoPtr_Body;

		// Token: 0x0400CC3B RID: 52283
		private static readonly IntPtr NativeFieldInfoPtr_Accepted;

		// Token: 0x0400CC3C RID: 52284
		private static readonly IntPtr NativeFieldInfoPtr_HasResponded;

		// Token: 0x0400CC3D RID: 52285
		private static readonly IntPtr NativeFieldInfoPtr_CanDecline;

		// Token: 0x0400CC3E RID: 52286
		private static readonly IntPtr NativeFieldInfoPtr_RequiresAcceptance;

		// Token: 0x0400CC3F RID: 52287
		private static readonly IntPtr NativeFieldInfoPtr_InformationOnly;

		// Token: 0x0400CC40 RID: 52288
		private static readonly IntPtr NativeFieldInfoPtr_InfoURL;

		// Token: 0x0400CC41 RID: 52289
		private static readonly IntPtr NativeFieldInfoPtr_ButtonOverrides;

		// Token: 0x0400CC42 RID: 52290
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
