﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace DPI.Agreements
{
	// Token: 0x0200106B RID: 4203
	[Serializable]
	[StructLayout(0)]
	public sealed class AgreementButtonOverride : ValueType
	{
		// Token: 0x06013F4C RID: 81740 RVA: 0x005050FC File Offset: 0x005032FC
		// Note: this type is marked as 'beforefieldinit'.
		static AgreementButtonOverride()
		{
			Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Agreements", "AgreementButtonOverride");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr);
			AgreementButtonOverride.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr, "Type");
			AgreementButtonOverride.NativeFieldInfoPtr_Region = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr, "Region");
			AgreementButtonOverride.NativeFieldInfoPtr_Caption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr, "Caption");
		}

		// Token: 0x06013F4D RID: 81741 RVA: 0x0002717B File Offset: 0x0002537B
		public AgreementButtonOverride(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007125 RID: 28965
		// (get) Token: 0x06013F4E RID: 81742 RVA: 0x00505168 File Offset: 0x00503368
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr));
			}
		}

		// Token: 0x06013F4F RID: 81743 RVA: 0x0050517C File Offset: 0x0050337C
		public unsafe AgreementButtonOverride()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AgreementButtonOverride>.NativeClassPtr, data));
		}

		// Token: 0x17007126 RID: 28966
		// (get) Token: 0x06013F50 RID: 81744 RVA: 0x005051AC File Offset: 0x005033AC
		// (set) Token: 0x06013F51 RID: 81745 RVA: 0x005051D4 File Offset: 0x005033D4
		public unsafe AgreementButtonOverrideType Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x17007127 RID: 28967
		// (get) Token: 0x06013F52 RID: 81746 RVA: 0x005051F8 File Offset: 0x005033F8
		// (set) Token: 0x06013F53 RID: 81747 RVA: 0x00505221 File Offset: 0x00503421
		public unsafe string Region
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Region);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Region), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17007128 RID: 28968
		// (get) Token: 0x06013F54 RID: 81748 RVA: 0x00505248 File Offset: 0x00503448
		// (set) Token: 0x06013F55 RID: 81749 RVA: 0x00505271 File Offset: 0x00503471
		public unsafe string Caption
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Caption);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AgreementButtonOverride.NativeFieldInfoPtr_Caption), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400CC26 RID: 52262
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x0400CC27 RID: 52263
		private static readonly IntPtr NativeFieldInfoPtr_Region;

		// Token: 0x0400CC28 RID: 52264
		private static readonly IntPtr NativeFieldInfoPtr_Caption;
	}
}
