﻿using System;
using System.Runtime.InteropServices;
using DPI.MeshCombination;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace DPI
{
	// Token: 0x02000F3F RID: 3903
	public static class CullBelowTerrainUtil : Il2CppSystem.Object
	{
		// Token: 0x06012CBE RID: 76990 RVA: 0x004BC50C File Offset: 0x004BA70C
		[CallerCount(0)]
		public unsafe static void CullBelowTerrain(CullBelowTerrainUtil.JobCompatibleTerrain terrain, Mesh originalMesh, Transform meshTransform, out Mesh culledMesh)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(terrain));
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(originalMesh);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(meshTransform);
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(culledMesh);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.NativeMethodInfoPtr_CullBelowTerrain_Public_Static_Void_JobCompatibleTerrain_Mesh_Transform_byref_Mesh_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr3 = intPtr;
			culledMesh = ((intPtr3 == 0) ? null : new Mesh(intPtr3));
		}

		// Token: 0x06012CBF RID: 76991 RVA: 0x004BC5C3 File Offset: 0x004BA7C3
		// Note: this type is marked as 'beforefieldinit'.
		static CullBelowTerrainUtil()
		{
			Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI", "CullBelowTerrainUtil");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr);
			CullBelowTerrainUtil.NativeMethodInfoPtr_CullBelowTerrain_Public_Static_Void_JobCompatibleTerrain_Mesh_Transform_byref_Mesh_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr, 100687389);
		}

		// Token: 0x06012CC0 RID: 76992 RVA: 0x00002988 File Offset: 0x00000B88
		public CullBelowTerrainUtil(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006A66 RID: 27238
		// (get) Token: 0x06012CC1 RID: 76993 RVA: 0x004BC5FC File Offset: 0x004BA7FC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr));
			}
		}

		// Token: 0x0400C090 RID: 49296
		private static readonly IntPtr NativeMethodInfoPtr_CullBelowTerrain_Public_Static_Void_JobCompatibleTerrain_Mesh_Transform_byref_Mesh_0;

		// Token: 0x02000F40 RID: 3904
		[StructLayout(0)]
		public sealed class JobCompatibleTerrain : ValueType
		{
			// Token: 0x17006A6E RID: 27246
			// (get) Token: 0x06012CC2 RID: 76994 RVA: 0x004BC610 File Offset: 0x004BA810
			public unsafe Bounds Bounds
			{
				[CallerCount(0)]
				get
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_get_Bounds_Public_get_Bounds_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return *IL2CPP.il2cpp_object_unbox(obj);
				}
			}

			// Token: 0x17006A6F RID: 27247
			// (get) Token: 0x06012CC3 RID: 76995 RVA: 0x004BC660 File Offset: 0x004BA860
			public unsafe Vector3 Pos
			{
				[CallerCount(0)]
				get
				{
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_get_Pos_Public_get_Vector3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return *IL2CPP.il2cpp_object_unbox(obj);
				}
			}

			// Token: 0x06012CC4 RID: 76996 RVA: 0x004BC6B0 File Offset: 0x004BA8B0
			[CallerCount(0)]
			public unsafe float SampleHeight(Vector3 worldPos)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref worldPos;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_SampleHeight_Public_Single_Vector3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06012CC5 RID: 76997 RVA: 0x004BC710 File Offset: 0x004BA910
			[CallerCount(0)]
			public unsafe static CullBelowTerrainUtil.JobCompatibleTerrain Create(Terrain terrain, out NativeArray<float3> nativeTerrainData)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(terrain);
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(nativeTerrainData);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_Create_Public_Static_JobCompatibleTerrain_Terrain_byref_NativeArray_1_float3_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return new CullBelowTerrainUtil.JobCompatibleTerrain(intPtr);
			}

			// Token: 0x06012CC6 RID: 76998 RVA: 0x004BC77C File Offset: 0x004BA97C
			// Note: this type is marked as 'beforefieldinit'.
			static JobCompatibleTerrain()
			{
				Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr, "JobCompatibleTerrain");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr);
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_X = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "MESH_RESOLUTION_X");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_Z = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "MESH_RESOLUTION_Z");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "_terrainData");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__bounds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "_bounds");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "_terrainPos");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainSize = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, "_terrainSize");
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_get_Bounds_Public_get_Bounds_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, 100687390);
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_get_Pos_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, 100687391);
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_SampleHeight_Public_Single_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, 100687392);
				CullBelowTerrainUtil.JobCompatibleTerrain.NativeMethodInfoPtr_Create_Public_Static_JobCompatibleTerrain_Terrain_byref_NativeArray_1_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, 100687393);
			}

			// Token: 0x06012CC7 RID: 76999 RVA: 0x0002717B File Offset: 0x0002537B
			public JobCompatibleTerrain(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006A67 RID: 27239
			// (get) Token: 0x06012CC8 RID: 77000 RVA: 0x004BC86F File Offset: 0x004BAA6F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr));
				}
			}

			// Token: 0x06012CC9 RID: 77001 RVA: 0x004BC880 File Offset: 0x004BAA80
			public unsafe JobCompatibleTerrain()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, data));
			}

			// Token: 0x17006A68 RID: 27240
			// (get) Token: 0x06012CCA RID: 77002 RVA: 0x004BC8B0 File Offset: 0x004BAAB0
			// (set) Token: 0x06012CCB RID: 77003 RVA: 0x004BC8CE File Offset: 0x004BAACE
			public unsafe static int MESH_RESOLUTION_X
			{
				get
				{
					int result;
					IL2CPP.il2cpp_field_static_get_value(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_X, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_X, (void*)(&value));
				}
			}

			// Token: 0x17006A69 RID: 27241
			// (get) Token: 0x06012CCC RID: 77004 RVA: 0x004BC8E0 File Offset: 0x004BAAE0
			// (set) Token: 0x06012CCD RID: 77005 RVA: 0x004BC8FE File Offset: 0x004BAAFE
			public unsafe static int MESH_RESOLUTION_Z
			{
				get
				{
					int result;
					IL2CPP.il2cpp_field_static_get_value(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_Z, (void*)(&result));
					return result;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr_MESH_RESOLUTION_Z, (void*)(&value));
				}
			}

			// Token: 0x17006A6A RID: 27242
			// (get) Token: 0x06012CCE RID: 77006 RVA: 0x004BC910 File Offset: 0x004BAB10
			// (set) Token: 0x06012CCF RID: 77007 RVA: 0x004BC942 File Offset: 0x004BAB42
			public NativeArray<float3> _terrainData
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainData);
					return new NativeArray<float3>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainData), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<float3>>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x17006A6B RID: 27243
			// (get) Token: 0x06012CD0 RID: 77008 RVA: 0x004BC978 File Offset: 0x004BAB78
			// (set) Token: 0x06012CD1 RID: 77009 RVA: 0x004BC9A0 File Offset: 0x004BABA0
			public unsafe Bounds _bounds
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__bounds);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__bounds)) = value;
				}
			}

			// Token: 0x17006A6C RID: 27244
			// (get) Token: 0x06012CD2 RID: 77010 RVA: 0x004BC9C4 File Offset: 0x004BABC4
			// (set) Token: 0x06012CD3 RID: 77011 RVA: 0x004BC9EC File Offset: 0x004BABEC
			public unsafe Vector3 _terrainPos
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainPos);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainPos)) = value;
				}
			}

			// Token: 0x17006A6D RID: 27245
			// (get) Token: 0x06012CD4 RID: 77012 RVA: 0x004BCA10 File Offset: 0x004BAC10
			// (set) Token: 0x06012CD5 RID: 77013 RVA: 0x004BCA38 File Offset: 0x004BAC38
			public unsafe Vector3 _terrainSize
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainSize);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.JobCompatibleTerrain.NativeFieldInfoPtr__terrainSize)) = value;
				}
			}

			// Token: 0x0400C091 RID: 49297
			private static readonly IntPtr NativeFieldInfoPtr_MESH_RESOLUTION_X;

			// Token: 0x0400C092 RID: 49298
			private static readonly IntPtr NativeFieldInfoPtr_MESH_RESOLUTION_Z;

			// Token: 0x0400C093 RID: 49299
			private static readonly IntPtr NativeFieldInfoPtr__terrainData;

			// Token: 0x0400C094 RID: 49300
			private static readonly IntPtr NativeFieldInfoPtr__bounds;

			// Token: 0x0400C095 RID: 49301
			private static readonly IntPtr NativeFieldInfoPtr__terrainPos;

			// Token: 0x0400C096 RID: 49302
			private static readonly IntPtr NativeFieldInfoPtr__terrainSize;

			// Token: 0x0400C097 RID: 49303
			private static readonly IntPtr NativeMethodInfoPtr_get_Bounds_Public_get_Bounds_0;

			// Token: 0x0400C098 RID: 49304
			private static readonly IntPtr NativeMethodInfoPtr_get_Pos_Public_get_Vector3_0;

			// Token: 0x0400C099 RID: 49305
			private static readonly IntPtr NativeMethodInfoPtr_SampleHeight_Public_Single_Vector3_0;

			// Token: 0x0400C09A RID: 49306
			private static readonly IntPtr NativeMethodInfoPtr_Create_Public_Static_JobCompatibleTerrain_Terrain_byref_NativeArray_1_float3_0;
		}

		// Token: 0x02000F41 RID: 3905
		[StructLayout(0)]
		public sealed class CullBelowTerrainJob : ValueType
		{
			// Token: 0x06012CD6 RID: 77014 RVA: 0x004BCA5C File Offset: 0x004BAC5C
			[CallerCount(0)]
			public unsafe void Execute(int index)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref index;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.CullBelowTerrainJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06012CD7 RID: 77015 RVA: 0x004BCAB0 File Offset: 0x004BACB0
			[CallerCount(0)]
			public unsafe bool IsBelowTerrain(float3 v1, float3 v2, float3 v3)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref v1;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v2;
				ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref v3;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CullBelowTerrainUtil.CullBelowTerrainJob.NativeMethodInfoPtr_IsBelowTerrain_Private_Boolean_float3_float3_float3_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06012CD8 RID: 77016 RVA: 0x004BCB38 File Offset: 0x004BAD38
			// Note: this type is marked as 'beforefieldinit'.
			static CullBelowTerrainJob()
			{
				Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<CullBelowTerrainUtil>.NativeClassPtr, "CullBelowTerrainJob");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr);
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Terrain = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, "Terrain");
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Indices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, "Indices");
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Vertices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, "Vertices");
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_TransformMatrix = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, "TransformMatrix");
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_OutTriangleIndices = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, "OutTriangleIndices");
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, 100687394);
				CullBelowTerrainUtil.CullBelowTerrainJob.NativeMethodInfoPtr_IsBelowTerrain_Private_Boolean_float3_float3_float3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, 100687395);
			}

			// Token: 0x06012CD9 RID: 77017 RVA: 0x0002717B File Offset: 0x0002537B
			public CullBelowTerrainJob(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17006A70 RID: 27248
			// (get) Token: 0x06012CDA RID: 77018 RVA: 0x004BCBEF File Offset: 0x004BADEF
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr));
				}
			}

			// Token: 0x06012CDB RID: 77019 RVA: 0x004BCC00 File Offset: 0x004BAE00
			public unsafe CullBelowTerrainJob()
			{
				IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, (UIntPtr)0)];
				base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CullBelowTerrainUtil.CullBelowTerrainJob>.NativeClassPtr, data));
			}

			// Token: 0x17006A71 RID: 27249
			// (get) Token: 0x06012CDC RID: 77020 RVA: 0x004BCC30 File Offset: 0x004BAE30
			// (set) Token: 0x06012CDD RID: 77021 RVA: 0x004BCC62 File Offset: 0x004BAE62
			public CullBelowTerrainUtil.JobCompatibleTerrain Terrain
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Terrain);
					return new CullBelowTerrainUtil.JobCompatibleTerrain(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Terrain), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<CullBelowTerrainUtil.JobCompatibleTerrain>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x17006A72 RID: 27250
			// (get) Token: 0x06012CDE RID: 77022 RVA: 0x004BCC98 File Offset: 0x004BAE98
			// (set) Token: 0x06012CDF RID: 77023 RVA: 0x004BCCCA File Offset: 0x004BAECA
			public NativeArray<int> Indices
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Indices);
					return new NativeArray<int>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Indices), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<int>>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x17006A73 RID: 27251
			// (get) Token: 0x06012CE0 RID: 77024 RVA: 0x004BCD00 File Offset: 0x004BAF00
			// (set) Token: 0x06012CE1 RID: 77025 RVA: 0x004BCD32 File Offset: 0x004BAF32
			public NativeArray<CompleteVertexData> Vertices
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Vertices);
					return new NativeArray<CompleteVertexData>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeArray<CompleteVertexData>>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_Vertices), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeArray<CompleteVertexData>>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x17006A74 RID: 27252
			// (get) Token: 0x06012CE2 RID: 77026 RVA: 0x004BCD68 File Offset: 0x004BAF68
			// (set) Token: 0x06012CE3 RID: 77027 RVA: 0x004BCD90 File Offset: 0x004BAF90
			public unsafe float4x4 TransformMatrix
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_TransformMatrix);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_TransformMatrix)) = value;
				}
			}

			// Token: 0x17006A75 RID: 27253
			// (get) Token: 0x06012CE4 RID: 77028 RVA: 0x004BCDB4 File Offset: 0x004BAFB4
			// (set) Token: 0x06012CE5 RID: 77029 RVA: 0x004BCDE6 File Offset: 0x004BAFE6
			public NativeList<TriangleIndices>.ParallelWriter OutTriangleIndices
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_OutTriangleIndices);
					return new NativeList<TriangleIndices>.ParallelWriter(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<NativeList<TriangleIndices>.ParallelWriter>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CullBelowTerrainUtil.CullBelowTerrainJob.NativeFieldInfoPtr_OutTriangleIndices), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<NativeList<TriangleIndices>.ParallelWriter>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x0400C09B RID: 49307
			private static readonly IntPtr NativeFieldInfoPtr_Terrain;

			// Token: 0x0400C09C RID: 49308
			private static readonly IntPtr NativeFieldInfoPtr_Indices;

			// Token: 0x0400C09D RID: 49309
			private static readonly IntPtr NativeFieldInfoPtr_Vertices;

			// Token: 0x0400C09E RID: 49310
			private static readonly IntPtr NativeFieldInfoPtr_TransformMatrix;

			// Token: 0x0400C09F RID: 49311
			private static readonly IntPtr NativeFieldInfoPtr_OutTriangleIndices;

			// Token: 0x0400C0A0 RID: 49312
			private static readonly IntPtr NativeMethodInfoPtr_Execute_Public_Virtual_Final_New_Void_Int32_0;

			// Token: 0x0400C0A1 RID: 49313
			private static readonly IntPtr NativeMethodInfoPtr_IsBelowTerrain_Private_Boolean_float3_float3_float3_0;
		}
	}
}
