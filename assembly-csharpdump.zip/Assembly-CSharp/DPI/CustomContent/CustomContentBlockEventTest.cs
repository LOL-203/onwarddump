﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine.Events;

namespace DPI.CustomContent
{
	// Token: 0x02001108 RID: 4360
	public class CustomContentBlockEventTest : UnityEvent
	{
		// Token: 0x060147BD RID: 83901 RVA: 0x005272B0 File Offset: 0x005254B0
		[CallerCount(0)]
		public unsafe CustomContentBlockEventTest() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentBlockEventTest>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentBlockEventTest.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060147BE RID: 83902 RVA: 0x005272FB File Offset: 0x005254FB
		// Note: this type is marked as 'beforefieldinit'.
		static CustomContentBlockEventTest()
		{
			Il2CppClassPointerStore<CustomContentBlockEventTest>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CustomContent", "CustomContentBlockEventTest");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentBlockEventTest>.NativeClassPtr);
			CustomContentBlockEventTest.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentBlockEventTest>.NativeClassPtr, 100689422);
		}

		// Token: 0x060147BF RID: 83903 RVA: 0x00527334 File Offset: 0x00525534
		public CustomContentBlockEventTest(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700740E RID: 29710
		// (get) Token: 0x060147C0 RID: 83904 RVA: 0x0052733D File Offset: 0x0052553D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentBlockEventTest>.NativeClassPtr));
			}
		}

		// Token: 0x0400D1A4 RID: 53668
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
