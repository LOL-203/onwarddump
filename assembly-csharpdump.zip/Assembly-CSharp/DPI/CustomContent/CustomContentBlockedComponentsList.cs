﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;

namespace DPI.CustomContent
{
	// Token: 0x02001107 RID: 4359
	public static class CustomContentBlockedComponentsList : Object
	{
		// Token: 0x060147B8 RID: 83896 RVA: 0x00527225 File Offset: 0x00525425
		// Note: this type is marked as 'beforefieldinit'.
		static CustomContentBlockedComponentsList()
		{
			Il2CppClassPointerStore<CustomContentBlockedComponentsList>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CustomContent", "CustomContentBlockedComponentsList");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentBlockedComponentsList>.NativeClassPtr);
			CustomContentBlockedComponentsList.NativeFieldInfoPtr_BlockedTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentBlockedComponentsList>.NativeClassPtr, "BlockedTypes");
		}

		// Token: 0x060147B9 RID: 83897 RVA: 0x00002988 File Offset: 0x00000B88
		public CustomContentBlockedComponentsList(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700740C RID: 29708
		// (get) Token: 0x060147BA RID: 83898 RVA: 0x0052725E File Offset: 0x0052545E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentBlockedComponentsList>.NativeClassPtr));
			}
		}

		// Token: 0x1700740D RID: 29709
		// (get) Token: 0x060147BB RID: 83899 RVA: 0x00527270 File Offset: 0x00525470
		// (set) Token: 0x060147BC RID: 83900 RVA: 0x0052729B File Offset: 0x0052549B
		public unsafe static HashSet<Type> BlockedTypes
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(CustomContentBlockedComponentsList.NativeFieldInfoPtr_BlockedTypes, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new HashSet<Type>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CustomContentBlockedComponentsList.NativeFieldInfoPtr_BlockedTypes, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D1A3 RID: 53667
		private static readonly IntPtr NativeFieldInfoPtr_BlockedTypes;
	}
}
