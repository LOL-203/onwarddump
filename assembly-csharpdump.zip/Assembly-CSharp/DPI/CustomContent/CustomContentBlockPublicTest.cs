﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.Events;

namespace DPI.CustomContent
{
	// Token: 0x0200110A RID: 4362
	public class CustomContentBlockPublicTest : MonoBehaviour
	{
		// Token: 0x060147C5 RID: 83909 RVA: 0x005273F0 File Offset: 0x005255F0
		[CallerCount(0)]
		public unsafe CustomContentBlockPublicTest() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomContentBlockPublicTest.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060147C6 RID: 83910 RVA: 0x0052743C File Offset: 0x0052563C
		// Note: this type is marked as 'beforefieldinit'.
		static CustomContentBlockPublicTest()
		{
			Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.CustomContent", "CustomContentBlockPublicTest");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr);
			CustomContentBlockPublicTest.NativeFieldInfoPtr_Event = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr, "Event");
			CustomContentBlockPublicTest.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr, 100689424);
		}

		// Token: 0x060147C7 RID: 83911 RVA: 0x0000210C File Offset: 0x0000030C
		public CustomContentBlockPublicTest(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007410 RID: 29712
		// (get) Token: 0x060147C8 RID: 83912 RVA: 0x00527494 File Offset: 0x00525694
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomContentBlockPublicTest>.NativeClassPtr));
			}
		}

		// Token: 0x17007411 RID: 29713
		// (get) Token: 0x060147C9 RID: 83913 RVA: 0x005274A8 File Offset: 0x005256A8
		// (set) Token: 0x060147CA RID: 83914 RVA: 0x005274DC File Offset: 0x005256DC
		public unsafe UnityEvent Event
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentBlockPublicTest.NativeFieldInfoPtr_Event);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UnityEvent(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomContentBlockPublicTest.NativeFieldInfoPtr_Event), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400D1A6 RID: 53670
		private static readonly IntPtr NativeFieldInfoPtr_Event;

		// Token: 0x0400D1A7 RID: 53671
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
