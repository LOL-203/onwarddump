﻿using System;

namespace DPI.Basketball
{
	// Token: 0x02001022 RID: 4130
	public enum BasketballPhysicsState
	{
		// Token: 0x0400CA00 RID: 51712
		Resting,
		// Token: 0x0400CA01 RID: 51713
		Held,
		// Token: 0x0400CA02 RID: 51714
		Rolling,
		// Token: 0x0400CA03 RID: 51715
		InAir,
		// Token: 0x0400CA04 RID: 51716
		InitialDribble
	}
}
