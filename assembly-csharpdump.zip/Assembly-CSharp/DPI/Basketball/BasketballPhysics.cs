﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Basketball
{
	// Token: 0x02001021 RID: 4129
	public class BasketballPhysics : MonoBehaviour
	{
		// Token: 0x17007019 RID: 28697
		// (get) Token: 0x06013BD4 RID: 80852 RVA: 0x004F6C24 File Offset: 0x004F4E24
		// (set) Token: 0x06013BD5 RID: 80853 RVA: 0x004F6C74 File Offset: 0x004F4E74
		public unsafe bool DeadBall
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_DeadBall_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_DeadBall_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700701A RID: 28698
		// (get) Token: 0x06013BD6 RID: 80854 RVA: 0x004F6CC8 File Offset: 0x004F4EC8
		// (set) Token: 0x06013BD7 RID: 80855 RVA: 0x004F6D18 File Offset: 0x004F4F18
		public unsafe Vector3 LastPosition
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_LastPosition_Public_get_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_LastPosition_Private_set_Void_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700701B RID: 28699
		// (get) Token: 0x06013BD8 RID: 80856 RVA: 0x004F6D6C File Offset: 0x004F4F6C
		// (set) Token: 0x06013BD9 RID: 80857 RVA: 0x004F6DBC File Offset: 0x004F4FBC
		public unsafe Vector3 CurrentPosition
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_CurrentPosition_Public_get_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_CurrentPosition_Private_set_Void_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700701C RID: 28700
		// (get) Token: 0x06013BDA RID: 80858 RVA: 0x004F6E10 File Offset: 0x004F5010
		// (set) Token: 0x06013BDB RID: 80859 RVA: 0x004F6E60 File Offset: 0x004F5060
		public unsafe Vector3 ThrowPosition
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_ThrowPosition_Public_get_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_ThrowPosition_Private_set_Void_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700701D RID: 28701
		// (get) Token: 0x06013BDC RID: 80860 RVA: 0x004F6EB4 File Offset: 0x004F50B4
		// (set) Token: 0x06013BDD RID: 80861 RVA: 0x004F6F04 File Offset: 0x004F5104
		public unsafe BasketballPhysicsState State
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_State_Public_get_BasketballPhysicsState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_State_Private_set_Void_BasketballPhysicsState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700701E RID: 28702
		// (get) Token: 0x06013BDE RID: 80862 RVA: 0x004F6F58 File Offset: 0x004F5158
		// (set) Token: 0x06013BDF RID: 80863 RVA: 0x004F6FA8 File Offset: 0x004F51A8
		public unsafe bool ManagedFixedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_get_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_set_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013BE0 RID: 80864 RVA: 0x004F6FFC File Offset: 0x004F51FC
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE1 RID: 80865 RVA: 0x004F7040 File Offset: 0x004F5240
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE2 RID: 80866 RVA: 0x004F7084 File Offset: 0x004F5284
		[CallerCount(0)]
		public unsafe void RegisterEvents(bool registered)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref registered;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_RegisterEvents_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE3 RID: 80867 RVA: 0x004F70D8 File Offset: 0x004F52D8
		[CallerCount(0)]
		public unsafe void SetDefaults()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_SetDefaults_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE4 RID: 80868 RVA: 0x004F711C File Offset: 0x004F531C
		[CallerCount(0)]
		public unsafe void OnManagedFixedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnManagedFixedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE5 RID: 80869 RVA: 0x004F7160 File Offset: 0x004F5360
		[CallerCount(0)]
		public unsafe void OnPickupGrabbed(Pickup pickup)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(pickup);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnPickupGrabbed_Private_Void_Pickup_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE6 RID: 80870 RVA: 0x004F71BC File Offset: 0x004F53BC
		[CallerCount(0)]
		public unsafe void OnPickupReleased()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnPickupReleased_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE7 RID: 80871 RVA: 0x004F7200 File Offset: 0x004F5400
		[CallerCount(0)]
		public unsafe void EquipReset()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_EquipReset_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE8 RID: 80872 RVA: 0x004F7244 File Offset: 0x004F5444
		[CallerCount(0)]
		public unsafe void SetState(BasketballPhysicsState newState, bool force = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newState;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref force;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_SetState_Private_Void_BasketballPhysicsState_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BE9 RID: 80873 RVA: 0x004F72AC File Offset: 0x004F54AC
		[CallerCount(0)]
		public unsafe BasketballPhysicsState GetActiveState()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_GetActiveState_Private_BasketballPhysicsState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013BEA RID: 80874 RVA: 0x004F72FC File Offset: 0x004F54FC
		[CallerCount(0)]
		public unsafe bool IsOnGround()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_IsOnGround_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013BEB RID: 80875 RVA: 0x004F734C File Offset: 0x004F554C
		[CallerCount(0)]
		public unsafe void SetInMotion(bool inMotion)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref inMotion;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_SetInMotion_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BEC RID: 80876 RVA: 0x004F73A0 File Offset: 0x004F55A0
		[CallerCount(0)]
		public unsafe void OnCollisionEnter(Collision collision)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(collision);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BED RID: 80877 RVA: 0x004F73FC File Offset: 0x004F55FC
		[CallerCount(0)]
		public unsafe void OnCollisionStay(Collision collision)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(collision);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnCollisionStay_Private_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BEE RID: 80878 RVA: 0x004F7458 File Offset: 0x004F5658
		[CallerCount(0)]
		public unsafe void OnCollisionExit(Collision collision)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(collision);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnCollisionExit_Private_Void_Collision_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BEF RID: 80879 RVA: 0x004F74B4 File Offset: 0x004F56B4
		[CallerCount(0)]
		public unsafe void OnExitAllCollisions()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_OnExitAllCollisions_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BF0 RID: 80880 RVA: 0x004F74F8 File Offset: 0x004F56F8
		[CallerCount(0)]
		public unsafe void ClearAllCollisions()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr_ClearAllCollisions_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BF1 RID: 80881 RVA: 0x004F753C File Offset: 0x004F573C
		[CallerCount(0)]
		public unsafe BasketballPhysics() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballPhysics.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BF2 RID: 80882 RVA: 0x004F7588 File Offset: 0x004F5788
		// Note: this type is marked as 'beforefieldinit'.
		static BasketballPhysics()
		{
			Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Basketball", "BasketballPhysics");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr);
			BasketballPhysics.NativeFieldInfoPtr_BallsInMotion = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "BallsInMotion");
			BasketballPhysics.NativeFieldInfoPtr_Pickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "Pickup");
			BasketballPhysics.NativeFieldInfoPtr_Rigidbody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "Rigidbody");
			BasketballPhysics.NativeFieldInfoPtr_Collider = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "Collider");
			BasketballPhysics.NativeFieldInfoPtr_DribbleMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "DribbleMaterial");
			BasketballPhysics.NativeFieldInfoPtr_NonDribbleMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "NonDribbleMaterial");
			BasketballPhysics.NativeFieldInfoPtr_AirDrag = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "AirDrag");
			BasketballPhysics.NativeFieldInfoPtr_AirAngularDrag = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "AirAngularDrag");
			BasketballPhysics.NativeFieldInfoPtr_GroundDetectionAngle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "GroundDetectionAngle");
			BasketballPhysics.NativeFieldInfoPtr_GroundDragIncreaseFactor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "GroundDragIncreaseFactor");
			BasketballPhysics.NativeFieldInfoPtr_GroundAngularDragIncreaseFactor = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "GroundAngularDragIncreaseFactor");
			BasketballPhysics.NativeFieldInfoPtr__t = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_t");
			BasketballPhysics.NativeFieldInfoPtr__bounces = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_bounces");
			BasketballPhysics.NativeFieldInfoPtr__hasTravelledUpwards = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_hasTravelledUpwards");
			BasketballPhysics.NativeFieldInfoPtr__active = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_active");
			BasketballPhysics.NativeFieldInfoPtr__collisionColliders = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_collisionColliders");
			BasketballPhysics.NativeFieldInfoPtr__collisionNormals = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "_collisionNormals");
			BasketballPhysics.NativeFieldInfoPtr__DeadBall_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<DeadBall>k__BackingField");
			BasketballPhysics.NativeFieldInfoPtr__LastPosition_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<LastPosition>k__BackingField");
			BasketballPhysics.NativeFieldInfoPtr__CurrentPosition_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<CurrentPosition>k__BackingField");
			BasketballPhysics.NativeFieldInfoPtr__ThrowPosition_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<ThrowPosition>k__BackingField");
			BasketballPhysics.NativeFieldInfoPtr__State_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<State>k__BackingField");
			BasketballPhysics.NativeFieldInfoPtr__ManagedFixedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, "<ManagedFixedUpdateRemoval>k__BackingField");
			BasketballPhysics.NativeMethodInfoPtr_get_DeadBall_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688457);
			BasketballPhysics.NativeMethodInfoPtr_set_DeadBall_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688458);
			BasketballPhysics.NativeMethodInfoPtr_get_LastPosition_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688459);
			BasketballPhysics.NativeMethodInfoPtr_set_LastPosition_Private_set_Void_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688460);
			BasketballPhysics.NativeMethodInfoPtr_get_CurrentPosition_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688461);
			BasketballPhysics.NativeMethodInfoPtr_set_CurrentPosition_Private_set_Void_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688462);
			BasketballPhysics.NativeMethodInfoPtr_get_ThrowPosition_Public_get_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688463);
			BasketballPhysics.NativeMethodInfoPtr_set_ThrowPosition_Private_set_Void_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688464);
			BasketballPhysics.NativeMethodInfoPtr_get_State_Public_get_BasketballPhysicsState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688465);
			BasketballPhysics.NativeMethodInfoPtr_set_State_Private_set_Void_BasketballPhysicsState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688466);
			BasketballPhysics.NativeMethodInfoPtr_get_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688467);
			BasketballPhysics.NativeMethodInfoPtr_set_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688468);
			BasketballPhysics.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688469);
			BasketballPhysics.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688470);
			BasketballPhysics.NativeMethodInfoPtr_RegisterEvents_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688471);
			BasketballPhysics.NativeMethodInfoPtr_SetDefaults_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688472);
			BasketballPhysics.NativeMethodInfoPtr_OnManagedFixedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688473);
			BasketballPhysics.NativeMethodInfoPtr_OnPickupGrabbed_Private_Void_Pickup_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688474);
			BasketballPhysics.NativeMethodInfoPtr_OnPickupReleased_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688475);
			BasketballPhysics.NativeMethodInfoPtr_EquipReset_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688476);
			BasketballPhysics.NativeMethodInfoPtr_SetState_Private_Void_BasketballPhysicsState_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688477);
			BasketballPhysics.NativeMethodInfoPtr_GetActiveState_Private_BasketballPhysicsState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688478);
			BasketballPhysics.NativeMethodInfoPtr_IsOnGround_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688479);
			BasketballPhysics.NativeMethodInfoPtr_SetInMotion_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688480);
			BasketballPhysics.NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688481);
			BasketballPhysics.NativeMethodInfoPtr_OnCollisionStay_Private_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688482);
			BasketballPhysics.NativeMethodInfoPtr_OnCollisionExit_Private_Void_Collision_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688483);
			BasketballPhysics.NativeMethodInfoPtr_OnExitAllCollisions_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688484);
			BasketballPhysics.NativeMethodInfoPtr_ClearAllCollisions_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688485);
			BasketballPhysics.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr, 100688486);
		}

		// Token: 0x06013BF3 RID: 80883 RVA: 0x0000210C File Offset: 0x0000030C
		public BasketballPhysics(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17007001 RID: 28673
		// (get) Token: 0x06013BF4 RID: 80884 RVA: 0x004F79DC File Offset: 0x004F5BDC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BasketballPhysics>.NativeClassPtr));
			}
		}

		// Token: 0x17007002 RID: 28674
		// (get) Token: 0x06013BF5 RID: 80885 RVA: 0x004F79F0 File Offset: 0x004F5BF0
		// (set) Token: 0x06013BF6 RID: 80886 RVA: 0x004F7A1B File Offset: 0x004F5C1B
		public unsafe static ConstantList<BasketballPhysics> BallsInMotion
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(BasketballPhysics.NativeFieldInfoPtr_BallsInMotion, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ConstantList<BasketballPhysics>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(BasketballPhysics.NativeFieldInfoPtr_BallsInMotion, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007003 RID: 28675
		// (get) Token: 0x06013BF7 RID: 80887 RVA: 0x004F7A30 File Offset: 0x004F5C30
		// (set) Token: 0x06013BF8 RID: 80888 RVA: 0x004F7A64 File Offset: 0x004F5C64
		public unsafe Pickup Pickup
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Pickup);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Pickup(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Pickup), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007004 RID: 28676
		// (get) Token: 0x06013BF9 RID: 80889 RVA: 0x004F7A8C File Offset: 0x004F5C8C
		// (set) Token: 0x06013BFA RID: 80890 RVA: 0x004F7AC0 File Offset: 0x004F5CC0
		public unsafe Rigidbody Rigidbody
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Rigidbody);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Rigidbody), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007005 RID: 28677
		// (get) Token: 0x06013BFB RID: 80891 RVA: 0x004F7AE8 File Offset: 0x004F5CE8
		// (set) Token: 0x06013BFC RID: 80892 RVA: 0x004F7B1C File Offset: 0x004F5D1C
		public unsafe Collider Collider
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Collider);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Collider(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_Collider), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007006 RID: 28678
		// (get) Token: 0x06013BFD RID: 80893 RVA: 0x004F7B44 File Offset: 0x004F5D44
		// (set) Token: 0x06013BFE RID: 80894 RVA: 0x004F7B78 File Offset: 0x004F5D78
		public unsafe PhysicMaterial DribbleMaterial
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_DribbleMaterial);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PhysicMaterial(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_DribbleMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007007 RID: 28679
		// (get) Token: 0x06013BFF RID: 80895 RVA: 0x004F7BA0 File Offset: 0x004F5DA0
		// (set) Token: 0x06013C00 RID: 80896 RVA: 0x004F7BD4 File Offset: 0x004F5DD4
		public unsafe PhysicMaterial NonDribbleMaterial
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_NonDribbleMaterial);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PhysicMaterial(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_NonDribbleMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007008 RID: 28680
		// (get) Token: 0x06013C01 RID: 80897 RVA: 0x004F7BFC File Offset: 0x004F5DFC
		// (set) Token: 0x06013C02 RID: 80898 RVA: 0x004F7C24 File Offset: 0x004F5E24
		public unsafe float AirDrag
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_AirDrag);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_AirDrag)) = value;
			}
		}

		// Token: 0x17007009 RID: 28681
		// (get) Token: 0x06013C03 RID: 80899 RVA: 0x004F7C48 File Offset: 0x004F5E48
		// (set) Token: 0x06013C04 RID: 80900 RVA: 0x004F7C70 File Offset: 0x004F5E70
		public unsafe float AirAngularDrag
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_AirAngularDrag);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_AirAngularDrag)) = value;
			}
		}

		// Token: 0x1700700A RID: 28682
		// (get) Token: 0x06013C05 RID: 80901 RVA: 0x004F7C94 File Offset: 0x004F5E94
		// (set) Token: 0x06013C06 RID: 80902 RVA: 0x004F7CBC File Offset: 0x004F5EBC
		public unsafe float GroundDetectionAngle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundDetectionAngle);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundDetectionAngle)) = value;
			}
		}

		// Token: 0x1700700B RID: 28683
		// (get) Token: 0x06013C07 RID: 80903 RVA: 0x004F7CE0 File Offset: 0x004F5EE0
		// (set) Token: 0x06013C08 RID: 80904 RVA: 0x004F7D08 File Offset: 0x004F5F08
		public unsafe float GroundDragIncreaseFactor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundDragIncreaseFactor);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundDragIncreaseFactor)) = value;
			}
		}

		// Token: 0x1700700C RID: 28684
		// (get) Token: 0x06013C09 RID: 80905 RVA: 0x004F7D2C File Offset: 0x004F5F2C
		// (set) Token: 0x06013C0A RID: 80906 RVA: 0x004F7D54 File Offset: 0x004F5F54
		public unsafe float GroundAngularDragIncreaseFactor
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundAngularDragIncreaseFactor);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr_GroundAngularDragIncreaseFactor)) = value;
			}
		}

		// Token: 0x1700700D RID: 28685
		// (get) Token: 0x06013C0B RID: 80907 RVA: 0x004F7D78 File Offset: 0x004F5F78
		// (set) Token: 0x06013C0C RID: 80908 RVA: 0x004F7DAC File Offset: 0x004F5FAC
		public unsafe Transform _t
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__t);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__t), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700700E RID: 28686
		// (get) Token: 0x06013C0D RID: 80909 RVA: 0x004F7DD4 File Offset: 0x004F5FD4
		// (set) Token: 0x06013C0E RID: 80910 RVA: 0x004F7DFC File Offset: 0x004F5FFC
		public unsafe int _bounces
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__bounces);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__bounces)) = value;
			}
		}

		// Token: 0x1700700F RID: 28687
		// (get) Token: 0x06013C0F RID: 80911 RVA: 0x004F7E20 File Offset: 0x004F6020
		// (set) Token: 0x06013C10 RID: 80912 RVA: 0x004F7E48 File Offset: 0x004F6048
		public unsafe bool _hasTravelledUpwards
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__hasTravelledUpwards);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__hasTravelledUpwards)) = value;
			}
		}

		// Token: 0x17007010 RID: 28688
		// (get) Token: 0x06013C11 RID: 80913 RVA: 0x004F7E6C File Offset: 0x004F606C
		// (set) Token: 0x06013C12 RID: 80914 RVA: 0x004F7E94 File Offset: 0x004F6094
		public unsafe bool _active
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__active);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__active)) = value;
			}
		}

		// Token: 0x17007011 RID: 28689
		// (get) Token: 0x06013C13 RID: 80915 RVA: 0x004F7EB8 File Offset: 0x004F60B8
		// (set) Token: 0x06013C14 RID: 80916 RVA: 0x004F7EEC File Offset: 0x004F60EC
		public unsafe List<Collider> _collisionColliders
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__collisionColliders);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Collider>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__collisionColliders), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007012 RID: 28690
		// (get) Token: 0x06013C15 RID: 80917 RVA: 0x004F7F14 File Offset: 0x004F6114
		// (set) Token: 0x06013C16 RID: 80918 RVA: 0x004F7F48 File Offset: 0x004F6148
		public unsafe Dictionary<Collider, Vector3> _collisionNormals
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__collisionNormals);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<Collider, Vector3>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__collisionNormals), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17007013 RID: 28691
		// (get) Token: 0x06013C17 RID: 80919 RVA: 0x004F7F70 File Offset: 0x004F6170
		// (set) Token: 0x06013C18 RID: 80920 RVA: 0x004F7F98 File Offset: 0x004F6198
		public unsafe bool _DeadBall_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__DeadBall_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__DeadBall_k__BackingField)) = value;
			}
		}

		// Token: 0x17007014 RID: 28692
		// (get) Token: 0x06013C19 RID: 80921 RVA: 0x004F7FBC File Offset: 0x004F61BC
		// (set) Token: 0x06013C1A RID: 80922 RVA: 0x004F7FE4 File Offset: 0x004F61E4
		public unsafe Vector3 _LastPosition_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__LastPosition_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__LastPosition_k__BackingField)) = value;
			}
		}

		// Token: 0x17007015 RID: 28693
		// (get) Token: 0x06013C1B RID: 80923 RVA: 0x004F8008 File Offset: 0x004F6208
		// (set) Token: 0x06013C1C RID: 80924 RVA: 0x004F8030 File Offset: 0x004F6230
		public unsafe Vector3 _CurrentPosition_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__CurrentPosition_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__CurrentPosition_k__BackingField)) = value;
			}
		}

		// Token: 0x17007016 RID: 28694
		// (get) Token: 0x06013C1D RID: 80925 RVA: 0x004F8054 File Offset: 0x004F6254
		// (set) Token: 0x06013C1E RID: 80926 RVA: 0x004F807C File Offset: 0x004F627C
		public unsafe Vector3 _ThrowPosition_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__ThrowPosition_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__ThrowPosition_k__BackingField)) = value;
			}
		}

		// Token: 0x17007017 RID: 28695
		// (get) Token: 0x06013C1F RID: 80927 RVA: 0x004F80A0 File Offset: 0x004F62A0
		// (set) Token: 0x06013C20 RID: 80928 RVA: 0x004F80C8 File Offset: 0x004F62C8
		public unsafe BasketballPhysicsState _State_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__State_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__State_k__BackingField)) = value;
			}
		}

		// Token: 0x17007018 RID: 28696
		// (get) Token: 0x06013C21 RID: 80929 RVA: 0x004F80EC File Offset: 0x004F62EC
		// (set) Token: 0x06013C22 RID: 80930 RVA: 0x004F8114 File Offset: 0x004F6314
		public unsafe bool _ManagedFixedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__ManagedFixedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballPhysics.NativeFieldInfoPtr__ManagedFixedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x0400C9CA RID: 51658
		private static readonly IntPtr NativeFieldInfoPtr_BallsInMotion;

		// Token: 0x0400C9CB RID: 51659
		private static readonly IntPtr NativeFieldInfoPtr_Pickup;

		// Token: 0x0400C9CC RID: 51660
		private static readonly IntPtr NativeFieldInfoPtr_Rigidbody;

		// Token: 0x0400C9CD RID: 51661
		private static readonly IntPtr NativeFieldInfoPtr_Collider;

		// Token: 0x0400C9CE RID: 51662
		private static readonly IntPtr NativeFieldInfoPtr_DribbleMaterial;

		// Token: 0x0400C9CF RID: 51663
		private static readonly IntPtr NativeFieldInfoPtr_NonDribbleMaterial;

		// Token: 0x0400C9D0 RID: 51664
		private static readonly IntPtr NativeFieldInfoPtr_AirDrag;

		// Token: 0x0400C9D1 RID: 51665
		private static readonly IntPtr NativeFieldInfoPtr_AirAngularDrag;

		// Token: 0x0400C9D2 RID: 51666
		private static readonly IntPtr NativeFieldInfoPtr_GroundDetectionAngle;

		// Token: 0x0400C9D3 RID: 51667
		private static readonly IntPtr NativeFieldInfoPtr_GroundDragIncreaseFactor;

		// Token: 0x0400C9D4 RID: 51668
		private static readonly IntPtr NativeFieldInfoPtr_GroundAngularDragIncreaseFactor;

		// Token: 0x0400C9D5 RID: 51669
		private static readonly IntPtr NativeFieldInfoPtr__t;

		// Token: 0x0400C9D6 RID: 51670
		private static readonly IntPtr NativeFieldInfoPtr__bounces;

		// Token: 0x0400C9D7 RID: 51671
		private static readonly IntPtr NativeFieldInfoPtr__hasTravelledUpwards;

		// Token: 0x0400C9D8 RID: 51672
		private static readonly IntPtr NativeFieldInfoPtr__active;

		// Token: 0x0400C9D9 RID: 51673
		private static readonly IntPtr NativeFieldInfoPtr__collisionColliders;

		// Token: 0x0400C9DA RID: 51674
		private static readonly IntPtr NativeFieldInfoPtr__collisionNormals;

		// Token: 0x0400C9DB RID: 51675
		private static readonly IntPtr NativeFieldInfoPtr__DeadBall_k__BackingField;

		// Token: 0x0400C9DC RID: 51676
		private static readonly IntPtr NativeFieldInfoPtr__LastPosition_k__BackingField;

		// Token: 0x0400C9DD RID: 51677
		private static readonly IntPtr NativeFieldInfoPtr__CurrentPosition_k__BackingField;

		// Token: 0x0400C9DE RID: 51678
		private static readonly IntPtr NativeFieldInfoPtr__ThrowPosition_k__BackingField;

		// Token: 0x0400C9DF RID: 51679
		private static readonly IntPtr NativeFieldInfoPtr__State_k__BackingField;

		// Token: 0x0400C9E0 RID: 51680
		private static readonly IntPtr NativeFieldInfoPtr__ManagedFixedUpdateRemoval_k__BackingField;

		// Token: 0x0400C9E1 RID: 51681
		private static readonly IntPtr NativeMethodInfoPtr_get_DeadBall_Public_get_Boolean_0;

		// Token: 0x0400C9E2 RID: 51682
		private static readonly IntPtr NativeMethodInfoPtr_set_DeadBall_Public_set_Void_Boolean_0;

		// Token: 0x0400C9E3 RID: 51683
		private static readonly IntPtr NativeMethodInfoPtr_get_LastPosition_Public_get_Vector3_0;

		// Token: 0x0400C9E4 RID: 51684
		private static readonly IntPtr NativeMethodInfoPtr_set_LastPosition_Private_set_Void_Vector3_0;

		// Token: 0x0400C9E5 RID: 51685
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentPosition_Public_get_Vector3_0;

		// Token: 0x0400C9E6 RID: 51686
		private static readonly IntPtr NativeMethodInfoPtr_set_CurrentPosition_Private_set_Void_Vector3_0;

		// Token: 0x0400C9E7 RID: 51687
		private static readonly IntPtr NativeMethodInfoPtr_get_ThrowPosition_Public_get_Vector3_0;

		// Token: 0x0400C9E8 RID: 51688
		private static readonly IntPtr NativeMethodInfoPtr_set_ThrowPosition_Private_set_Void_Vector3_0;

		// Token: 0x0400C9E9 RID: 51689
		private static readonly IntPtr NativeMethodInfoPtr_get_State_Public_get_BasketballPhysicsState_0;

		// Token: 0x0400C9EA RID: 51690
		private static readonly IntPtr NativeMethodInfoPtr_set_State_Private_set_Void_BasketballPhysicsState_0;

		// Token: 0x0400C9EB RID: 51691
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400C9EC RID: 51692
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedFixedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400C9ED RID: 51693
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x0400C9EE RID: 51694
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x0400C9EF RID: 51695
		private static readonly IntPtr NativeMethodInfoPtr_RegisterEvents_Private_Void_Boolean_0;

		// Token: 0x0400C9F0 RID: 51696
		private static readonly IntPtr NativeMethodInfoPtr_SetDefaults_Private_Void_0;

		// Token: 0x0400C9F1 RID: 51697
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedFixedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400C9F2 RID: 51698
		private static readonly IntPtr NativeMethodInfoPtr_OnPickupGrabbed_Private_Void_Pickup_0;

		// Token: 0x0400C9F3 RID: 51699
		private static readonly IntPtr NativeMethodInfoPtr_OnPickupReleased_Private_Void_0;

		// Token: 0x0400C9F4 RID: 51700
		private static readonly IntPtr NativeMethodInfoPtr_EquipReset_Private_Void_0;

		// Token: 0x0400C9F5 RID: 51701
		private static readonly IntPtr NativeMethodInfoPtr_SetState_Private_Void_BasketballPhysicsState_Boolean_0;

		// Token: 0x0400C9F6 RID: 51702
		private static readonly IntPtr NativeMethodInfoPtr_GetActiveState_Private_BasketballPhysicsState_0;

		// Token: 0x0400C9F7 RID: 51703
		private static readonly IntPtr NativeMethodInfoPtr_IsOnGround_Private_Boolean_0;

		// Token: 0x0400C9F8 RID: 51704
		private static readonly IntPtr NativeMethodInfoPtr_SetInMotion_Private_Void_Boolean_0;

		// Token: 0x0400C9F9 RID: 51705
		private static readonly IntPtr NativeMethodInfoPtr_OnCollisionEnter_Private_Void_Collision_0;

		// Token: 0x0400C9FA RID: 51706
		private static readonly IntPtr NativeMethodInfoPtr_OnCollisionStay_Private_Void_Collision_0;

		// Token: 0x0400C9FB RID: 51707
		private static readonly IntPtr NativeMethodInfoPtr_OnCollisionExit_Private_Void_Collision_0;

		// Token: 0x0400C9FC RID: 51708
		private static readonly IntPtr NativeMethodInfoPtr_OnExitAllCollisions_Private_Void_0;

		// Token: 0x0400C9FD RID: 51709
		private static readonly IntPtr NativeMethodInfoPtr_ClearAllCollisions_Private_Void_0;

		// Token: 0x0400C9FE RID: 51710
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
