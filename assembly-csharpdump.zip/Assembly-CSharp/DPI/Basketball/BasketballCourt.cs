﻿using System;
using AK.Wwise;
using DPI.Networking;
using Il2CppSystem;
using Onward.GameVariants;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Basketball
{
	// Token: 0x0200101E RID: 4126
	public class BasketballCourt : MonoBehaviour
	{
		// Token: 0x17006FEC RID: 28652
		// (get) Token: 0x06013B7B RID: 80763 RVA: 0x004F5508 File Offset: 0x004F3708
		public unsafe bool Interlude
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_get_Interlude_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17006FED RID: 28653
		// (get) Token: 0x06013B7C RID: 80764 RVA: 0x004F5558 File Offset: 0x004F3758
		public unsafe float InterludeTimeRemaining
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_get_InterludeTimeRemaining_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17006FEE RID: 28654
		// (get) Token: 0x06013B7D RID: 80765 RVA: 0x004F55A8 File Offset: 0x004F37A8
		// (set) Token: 0x06013B7E RID: 80766 RVA: 0x004F55F8 File Offset: 0x004F37F8
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013B7F RID: 80767 RVA: 0x004F564C File Offset: 0x004F384C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B80 RID: 80768 RVA: 0x004F5690 File Offset: 0x004F3890
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B81 RID: 80769 RVA: 0x004F56D4 File Offset: 0x004F38D4
		[CallerCount(0)]
		public unsafe void OnGameVariantSelected(GameVariantTypes variant)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref variant;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B82 RID: 80770 RVA: 0x004F5728 File Offset: 0x004F3928
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_Initialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B83 RID: 80771 RVA: 0x004F576C File Offset: 0x004F396C
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_Uninitialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B84 RID: 80772 RVA: 0x004F57B0 File Offset: 0x004F39B0
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B85 RID: 80773 RVA: 0x004F57F4 File Offset: 0x004F39F4
		[CallerCount(0)]
		public unsafe void OnScoreChange(int newScore)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newScore;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnScoreChange_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B86 RID: 80774 RVA: 0x004F5848 File Offset: 0x004F3A48
		[CallerCount(0)]
		public unsafe void OnRequestCourtEvent(BasketballCourtRequestEvent msg, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref msg;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnRequestCourtEvent_Private_Void_BasketballCourtRequestEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B87 RID: 80775 RVA: 0x004F58BC File Offset: 0x004F3ABC
		[CallerCount(0)]
		public unsafe void OnSendCourtEvent(BasketballCourtSendEvent msg, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref msg;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr_OnSendCourtEvent_Private_Void_BasketballCourtSendEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B88 RID: 80776 RVA: 0x004F5930 File Offset: 0x004F3B30
		[CallerCount(0)]
		public unsafe BasketballCourt() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballCourt.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013B89 RID: 80777 RVA: 0x004F597C File Offset: 0x004F3B7C
		// Note: this type is marked as 'beforefieldinit'.
		static BasketballCourt()
		{
			Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Basketball", "BasketballCourt");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr);
			BasketballCourt.NativeFieldInfoPtr_KlaxonSoundEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "KlaxonSoundEvent");
			BasketballCourt.NativeFieldInfoPtr_CourtIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "CourtIndex");
			BasketballCourt.NativeFieldInfoPtr_InterludeDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "InterludeDuration");
			BasketballCourt.NativeFieldInfoPtr_WinningScore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "WinningScore");
			BasketballCourt.NativeFieldInfoPtr__initialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "_initialized");
			BasketballCourt.NativeFieldInfoPtr__interludeExpiration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "_interludeExpiration");
			BasketballCourt.NativeFieldInfoPtr__interlude = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "_interlude");
			BasketballCourt.NativeFieldInfoPtr__interludeTimeRemaining = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "_interludeTimeRemaining");
			BasketballCourt.NativeFieldInfoPtr_OnInterludeChange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "OnInterludeChange");
			BasketballCourt.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			BasketballCourt.NativeMethodInfoPtr_get_Interlude_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688426);
			BasketballCourt.NativeMethodInfoPtr_get_InterludeTimeRemaining_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688427);
			BasketballCourt.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688428);
			BasketballCourt.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688429);
			BasketballCourt.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688430);
			BasketballCourt.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688431);
			BasketballCourt.NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688432);
			BasketballCourt.NativeMethodInfoPtr_Initialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688433);
			BasketballCourt.NativeMethodInfoPtr_Uninitialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688434);
			BasketballCourt.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688435);
			BasketballCourt.NativeMethodInfoPtr_OnScoreChange_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688436);
			BasketballCourt.NativeMethodInfoPtr_OnRequestCourtEvent_Private_Void_BasketballCourtRequestEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688437);
			BasketballCourt.NativeMethodInfoPtr_OnSendCourtEvent_Private_Void_BasketballCourtSendEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688438);
			BasketballCourt.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr, 100688439);
		}

		// Token: 0x06013B8A RID: 80778 RVA: 0x0000210C File Offset: 0x0000030C
		public BasketballCourt(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006FE1 RID: 28641
		// (get) Token: 0x06013B8B RID: 80779 RVA: 0x004F5B8C File Offset: 0x004F3D8C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BasketballCourt>.NativeClassPtr));
			}
		}

		// Token: 0x17006FE2 RID: 28642
		// (get) Token: 0x06013B8C RID: 80780 RVA: 0x004F5BA0 File Offset: 0x004F3DA0
		// (set) Token: 0x06013B8D RID: 80781 RVA: 0x004F5BD4 File Offset: 0x004F3DD4
		public unsafe AK.Wwise.Event KlaxonSoundEvent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_KlaxonSoundEvent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_KlaxonSoundEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FE3 RID: 28643
		// (get) Token: 0x06013B8E RID: 80782 RVA: 0x004F5BFC File Offset: 0x004F3DFC
		// (set) Token: 0x06013B8F RID: 80783 RVA: 0x004F5C24 File Offset: 0x004F3E24
		public unsafe int CourtIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_CourtIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_CourtIndex)) = value;
			}
		}

		// Token: 0x17006FE4 RID: 28644
		// (get) Token: 0x06013B90 RID: 80784 RVA: 0x004F5C48 File Offset: 0x004F3E48
		// (set) Token: 0x06013B91 RID: 80785 RVA: 0x004F5C70 File Offset: 0x004F3E70
		public unsafe float InterludeDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_InterludeDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_InterludeDuration)) = value;
			}
		}

		// Token: 0x17006FE5 RID: 28645
		// (get) Token: 0x06013B92 RID: 80786 RVA: 0x004F5C94 File Offset: 0x004F3E94
		// (set) Token: 0x06013B93 RID: 80787 RVA: 0x004F5CBC File Offset: 0x004F3EBC
		public unsafe int WinningScore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_WinningScore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_WinningScore)) = value;
			}
		}

		// Token: 0x17006FE6 RID: 28646
		// (get) Token: 0x06013B94 RID: 80788 RVA: 0x004F5CE0 File Offset: 0x004F3EE0
		// (set) Token: 0x06013B95 RID: 80789 RVA: 0x004F5D08 File Offset: 0x004F3F08
		public unsafe bool _initialized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__initialized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__initialized)) = value;
			}
		}

		// Token: 0x17006FE7 RID: 28647
		// (get) Token: 0x06013B96 RID: 80790 RVA: 0x004F5D2C File Offset: 0x004F3F2C
		// (set) Token: 0x06013B97 RID: 80791 RVA: 0x004F5D54 File Offset: 0x004F3F54
		public unsafe double _interludeExpiration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interludeExpiration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interludeExpiration)) = value;
			}
		}

		// Token: 0x17006FE8 RID: 28648
		// (get) Token: 0x06013B98 RID: 80792 RVA: 0x004F5D78 File Offset: 0x004F3F78
		// (set) Token: 0x06013B99 RID: 80793 RVA: 0x004F5DA0 File Offset: 0x004F3FA0
		public unsafe bool _interlude
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interlude);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interlude)) = value;
			}
		}

		// Token: 0x17006FE9 RID: 28649
		// (get) Token: 0x06013B9A RID: 80794 RVA: 0x004F5DC4 File Offset: 0x004F3FC4
		// (set) Token: 0x06013B9B RID: 80795 RVA: 0x004F5DEC File Offset: 0x004F3FEC
		public unsafe float _interludeTimeRemaining
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interludeTimeRemaining);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__interludeTimeRemaining)) = value;
			}
		}

		// Token: 0x17006FEA RID: 28650
		// (get) Token: 0x06013B9C RID: 80796 RVA: 0x004F5E10 File Offset: 0x004F4010
		// (set) Token: 0x06013B9D RID: 80797 RVA: 0x004F5E44 File Offset: 0x004F4044
		public unsafe Action<bool> OnInterludeChange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_OnInterludeChange);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<bool>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr_OnInterludeChange), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FEB RID: 28651
		// (get) Token: 0x06013B9E RID: 80798 RVA: 0x004F5E6C File Offset: 0x004F406C
		// (set) Token: 0x06013B9F RID: 80799 RVA: 0x004F5E94 File Offset: 0x004F4094
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballCourt.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x0400C98E RID: 51598
		private static readonly IntPtr NativeFieldInfoPtr_KlaxonSoundEvent;

		// Token: 0x0400C98F RID: 51599
		private static readonly IntPtr NativeFieldInfoPtr_CourtIndex;

		// Token: 0x0400C990 RID: 51600
		private static readonly IntPtr NativeFieldInfoPtr_InterludeDuration;

		// Token: 0x0400C991 RID: 51601
		private static readonly IntPtr NativeFieldInfoPtr_WinningScore;

		// Token: 0x0400C992 RID: 51602
		private static readonly IntPtr NativeFieldInfoPtr__initialized;

		// Token: 0x0400C993 RID: 51603
		private static readonly IntPtr NativeFieldInfoPtr__interludeExpiration;

		// Token: 0x0400C994 RID: 51604
		private static readonly IntPtr NativeFieldInfoPtr__interlude;

		// Token: 0x0400C995 RID: 51605
		private static readonly IntPtr NativeFieldInfoPtr__interludeTimeRemaining;

		// Token: 0x0400C996 RID: 51606
		private static readonly IntPtr NativeFieldInfoPtr_OnInterludeChange;

		// Token: 0x0400C997 RID: 51607
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x0400C998 RID: 51608
		private static readonly IntPtr NativeMethodInfoPtr_get_Interlude_Public_get_Boolean_0;

		// Token: 0x0400C999 RID: 51609
		private static readonly IntPtr NativeMethodInfoPtr_get_InterludeTimeRemaining_Public_get_Single_0;

		// Token: 0x0400C99A RID: 51610
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400C99B RID: 51611
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400C99C RID: 51612
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x0400C99D RID: 51613
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x0400C99E RID: 51614
		private static readonly IntPtr NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0;

		// Token: 0x0400C99F RID: 51615
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Private_Void_0;

		// Token: 0x0400C9A0 RID: 51616
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Private_Void_0;

		// Token: 0x0400C9A1 RID: 51617
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400C9A2 RID: 51618
		private static readonly IntPtr NativeMethodInfoPtr_OnScoreChange_Public_Void_Int32_0;

		// Token: 0x0400C9A3 RID: 51619
		private static readonly IntPtr NativeMethodInfoPtr_OnRequestCourtEvent_Private_Void_BasketballCourtRequestEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400C9A4 RID: 51620
		private static readonly IntPtr NativeMethodInfoPtr_OnSendCourtEvent_Private_Void_BasketballCourtSendEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400C9A5 RID: 51621
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
