﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.GameVariants;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace DPI.Basketball
{
	// Token: 0x0200101F RID: 4127
	public class BasketballGoal : MonoBehaviour
	{
		// Token: 0x17006FFF RID: 28671
		// (get) Token: 0x06013BA0 RID: 80800 RVA: 0x004F5EB8 File Offset: 0x004F40B8
		// (set) Token: 0x06013BA1 RID: 80801 RVA: 0x004F5F08 File Offset: 0x004F4108
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06013BA2 RID: 80802 RVA: 0x004F5F5C File Offset: 0x004F415C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA3 RID: 80803 RVA: 0x004F5FA0 File Offset: 0x004F41A0
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA4 RID: 80804 RVA: 0x004F5FE4 File Offset: 0x004F41E4
		[CallerCount(0)]
		public unsafe void OnGameVariantSelected(GameVariantTypes variant)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref variant;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA5 RID: 80805 RVA: 0x004F6038 File Offset: 0x004F4238
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_Initialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA6 RID: 80806 RVA: 0x004F607C File Offset: 0x004F427C
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_Uninitialize_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA7 RID: 80807 RVA: 0x004F60C0 File Offset: 0x004F42C0
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BA8 RID: 80808 RVA: 0x004F6104 File Offset: 0x004F4304
		[CallerCount(0)]
		public unsafe BasketballGoal.GoalType CheckPathOnPlane(Plane plane, Vector3 start, Vector3 end)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref plane;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref start;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref end;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_CheckPathOnPlane_Private_GoalType_Plane_Vector3_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013BA9 RID: 80809 RVA: 0x004F618C File Offset: 0x004F438C
		[CallerCount(0)]
		public unsafe bool PointIsAbovePlane(Plane plane, Vector3 point)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref plane;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref point;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_PointIsAbovePlane_Private_Boolean_Plane_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06013BAA RID: 80810 RVA: 0x004F6204 File Offset: 0x004F4404
		[CallerCount(0)]
		public unsafe void PlayScoreEffects()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_PlayScoreEffects_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BAB RID: 80811 RVA: 0x004F6248 File Offset: 0x004F4448
		[CallerCount(0)]
		public unsafe void RefreshScoreElements()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_RefreshScoreElements_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BAC RID: 80812 RVA: 0x004F628C File Offset: 0x004F448C
		[CallerCount(0)]
		public unsafe void OnInterludeChange(bool interlude)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref interlude;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnInterludeChange_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BAD RID: 80813 RVA: 0x004F62E0 File Offset: 0x004F44E0
		[CallerCount(0)]
		public unsafe void OnPerformScoreEvent(BasketballGoalScoreEvent msg, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref msg;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnPerformScoreEvent_Private_Void_BasketballGoalScoreEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BAE RID: 80814 RVA: 0x004F6354 File Offset: 0x004F4554
		[CallerCount(0)]
		public unsafe void OnRequestScoreEvent(BasketballGoalRequestEvent msg, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref msg;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnRequestScoreEvent_Private_Void_BasketballGoalRequestEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BAF RID: 80815 RVA: 0x004F63C8 File Offset: 0x004F45C8
		[CallerCount(0)]
		public unsafe void OnSendScoreEvent(BasketballGoalSendEvent msg, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref msg;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr_OnSendScoreEvent_Private_Void_BasketballGoalSendEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BB0 RID: 80816 RVA: 0x004F643C File Offset: 0x004F463C
		[CallerCount(0)]
		public unsafe BasketballGoal() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasketballGoal.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06013BB1 RID: 80817 RVA: 0x004F6488 File Offset: 0x004F4688
		// Note: this type is marked as 'beforefieldinit'.
		static BasketballGoal()
		{
			Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "DPI.Basketball", "BasketballGoal");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr);
			BasketballGoal.NativeFieldInfoPtr_Court = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "Court");
			BasketballGoal.NativeFieldInfoPtr_ScoreIndicator = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "ScoreIndicator");
			BasketballGoal.NativeFieldInfoPtr_GoalIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "GoalIndex");
			BasketballGoal.NativeFieldInfoPtr_ScoringDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "ScoringDistance");
			BasketballGoal.NativeFieldInfoPtr_ScoringDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "ScoringDelay");
			BasketballGoal.NativeFieldInfoPtr_ThreePointDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "ThreePointDistance");
			BasketballGoal.NativeFieldInfoPtr_Debugging = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "Debugging");
			BasketballGoal.NativeFieldInfoPtr_DebugStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "DebugStart");
			BasketballGoal.NativeFieldInfoPtr_DebugEnd = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "DebugEnd");
			BasketballGoal.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			BasketballGoal.NativeFieldInfoPtr__initialized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "_initialized");
			BasketballGoal.NativeFieldInfoPtr__scoringPlane = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "_scoringPlane");
			BasketballGoal.NativeFieldInfoPtr__lastScoreTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "_lastScoreTime");
			BasketballGoal.NativeFieldInfoPtr__currentScore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "_currentScore");
			BasketballGoal.NativeFieldInfoPtr__positionCache = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, "_positionCache");
			BasketballGoal.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688440);
			BasketballGoal.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688441);
			BasketballGoal.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688442);
			BasketballGoal.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688443);
			BasketballGoal.NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688444);
			BasketballGoal.NativeMethodInfoPtr_Initialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688445);
			BasketballGoal.NativeMethodInfoPtr_Uninitialize_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688446);
			BasketballGoal.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688447);
			BasketballGoal.NativeMethodInfoPtr_CheckPathOnPlane_Private_GoalType_Plane_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688448);
			BasketballGoal.NativeMethodInfoPtr_PointIsAbovePlane_Private_Boolean_Plane_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688449);
			BasketballGoal.NativeMethodInfoPtr_PlayScoreEffects_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688450);
			BasketballGoal.NativeMethodInfoPtr_RefreshScoreElements_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688451);
			BasketballGoal.NativeMethodInfoPtr_OnInterludeChange_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688452);
			BasketballGoal.NativeMethodInfoPtr_OnPerformScoreEvent_Private_Void_BasketballGoalScoreEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688453);
			BasketballGoal.NativeMethodInfoPtr_OnRequestScoreEvent_Private_Void_BasketballGoalRequestEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688454);
			BasketballGoal.NativeMethodInfoPtr_OnSendScoreEvent_Private_Void_BasketballGoalSendEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688455);
			BasketballGoal.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr, 100688456);
		}

		// Token: 0x06013BB2 RID: 80818 RVA: 0x0000210C File Offset: 0x0000030C
		public BasketballGoal(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17006FEF RID: 28655
		// (get) Token: 0x06013BB3 RID: 80819 RVA: 0x004F6738 File Offset: 0x004F4938
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BasketballGoal>.NativeClassPtr));
			}
		}

		// Token: 0x17006FF0 RID: 28656
		// (get) Token: 0x06013BB4 RID: 80820 RVA: 0x004F674C File Offset: 0x004F494C
		// (set) Token: 0x06013BB5 RID: 80821 RVA: 0x004F6780 File Offset: 0x004F4980
		public unsafe BasketballCourt Court
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_Court);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BasketballCourt(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_Court), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FF1 RID: 28657
		// (get) Token: 0x06013BB6 RID: 80822 RVA: 0x004F67A8 File Offset: 0x004F49A8
		// (set) Token: 0x06013BB7 RID: 80823 RVA: 0x004F67DC File Offset: 0x004F49DC
		public unsafe BasketballGoalIndicatorLight ScoreIndicator
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoreIndicator);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BasketballGoalIndicatorLight(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoreIndicator), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FF2 RID: 28658
		// (get) Token: 0x06013BB8 RID: 80824 RVA: 0x004F6804 File Offset: 0x004F4A04
		// (set) Token: 0x06013BB9 RID: 80825 RVA: 0x004F682C File Offset: 0x004F4A2C
		public unsafe int GoalIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_GoalIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_GoalIndex)) = value;
			}
		}

		// Token: 0x17006FF3 RID: 28659
		// (get) Token: 0x06013BBA RID: 80826 RVA: 0x004F6850 File Offset: 0x004F4A50
		// (set) Token: 0x06013BBB RID: 80827 RVA: 0x004F6878 File Offset: 0x004F4A78
		public unsafe float ScoringDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoringDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoringDistance)) = value;
			}
		}

		// Token: 0x17006FF4 RID: 28660
		// (get) Token: 0x06013BBC RID: 80828 RVA: 0x004F689C File Offset: 0x004F4A9C
		// (set) Token: 0x06013BBD RID: 80829 RVA: 0x004F68C4 File Offset: 0x004F4AC4
		public unsafe float ScoringDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoringDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ScoringDelay)) = value;
			}
		}

		// Token: 0x17006FF5 RID: 28661
		// (get) Token: 0x06013BBE RID: 80830 RVA: 0x004F68E8 File Offset: 0x004F4AE8
		// (set) Token: 0x06013BBF RID: 80831 RVA: 0x004F6910 File Offset: 0x004F4B10
		public unsafe float ThreePointDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ThreePointDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_ThreePointDistance)) = value;
			}
		}

		// Token: 0x17006FF6 RID: 28662
		// (get) Token: 0x06013BC0 RID: 80832 RVA: 0x004F6934 File Offset: 0x004F4B34
		// (set) Token: 0x06013BC1 RID: 80833 RVA: 0x004F695C File Offset: 0x004F4B5C
		public unsafe bool Debugging
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_Debugging);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_Debugging)) = value;
			}
		}

		// Token: 0x17006FF7 RID: 28663
		// (get) Token: 0x06013BC2 RID: 80834 RVA: 0x004F6980 File Offset: 0x004F4B80
		// (set) Token: 0x06013BC3 RID: 80835 RVA: 0x004F69B4 File Offset: 0x004F4BB4
		public unsafe Transform DebugStart
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_DebugStart);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_DebugStart), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FF8 RID: 28664
		// (get) Token: 0x06013BC4 RID: 80836 RVA: 0x004F69DC File Offset: 0x004F4BDC
		// (set) Token: 0x06013BC5 RID: 80837 RVA: 0x004F6A10 File Offset: 0x004F4C10
		public unsafe Transform DebugEnd
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_DebugEnd);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr_DebugEnd), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17006FF9 RID: 28665
		// (get) Token: 0x06013BC6 RID: 80838 RVA: 0x004F6A38 File Offset: 0x004F4C38
		// (set) Token: 0x06013BC7 RID: 80839 RVA: 0x004F6A60 File Offset: 0x004F4C60
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x17006FFA RID: 28666
		// (get) Token: 0x06013BC8 RID: 80840 RVA: 0x004F6A84 File Offset: 0x004F4C84
		// (set) Token: 0x06013BC9 RID: 80841 RVA: 0x004F6AAC File Offset: 0x004F4CAC
		public unsafe bool _initialized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__initialized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__initialized)) = value;
			}
		}

		// Token: 0x17006FFB RID: 28667
		// (get) Token: 0x06013BCA RID: 80842 RVA: 0x004F6AD0 File Offset: 0x004F4CD0
		// (set) Token: 0x06013BCB RID: 80843 RVA: 0x004F6AF8 File Offset: 0x004F4CF8
		public unsafe Plane _scoringPlane
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__scoringPlane);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__scoringPlane)) = value;
			}
		}

		// Token: 0x17006FFC RID: 28668
		// (get) Token: 0x06013BCC RID: 80844 RVA: 0x004F6B1C File Offset: 0x004F4D1C
		// (set) Token: 0x06013BCD RID: 80845 RVA: 0x004F6B44 File Offset: 0x004F4D44
		public unsafe double _lastScoreTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__lastScoreTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__lastScoreTime)) = value;
			}
		}

		// Token: 0x17006FFD RID: 28669
		// (get) Token: 0x06013BCE RID: 80846 RVA: 0x004F6B68 File Offset: 0x004F4D68
		// (set) Token: 0x06013BCF RID: 80847 RVA: 0x004F6B90 File Offset: 0x004F4D90
		public unsafe int _currentScore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__currentScore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__currentScore)) = value;
			}
		}

		// Token: 0x17006FFE RID: 28670
		// (get) Token: 0x06013BD0 RID: 80848 RVA: 0x004F6BB4 File Offset: 0x004F4DB4
		// (set) Token: 0x06013BD1 RID: 80849 RVA: 0x004F6BDC File Offset: 0x004F4DDC
		public unsafe Vector3 _positionCache
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__positionCache);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasketballGoal.NativeFieldInfoPtr__positionCache)) = value;
			}
		}

		// Token: 0x0400C9A6 RID: 51622
		private static readonly IntPtr NativeFieldInfoPtr_Court;

		// Token: 0x0400C9A7 RID: 51623
		private static readonly IntPtr NativeFieldInfoPtr_ScoreIndicator;

		// Token: 0x0400C9A8 RID: 51624
		private static readonly IntPtr NativeFieldInfoPtr_GoalIndex;

		// Token: 0x0400C9A9 RID: 51625
		private static readonly IntPtr NativeFieldInfoPtr_ScoringDistance;

		// Token: 0x0400C9AA RID: 51626
		private static readonly IntPtr NativeFieldInfoPtr_ScoringDelay;

		// Token: 0x0400C9AB RID: 51627
		private static readonly IntPtr NativeFieldInfoPtr_ThreePointDistance;

		// Token: 0x0400C9AC RID: 51628
		private static readonly IntPtr NativeFieldInfoPtr_Debugging;

		// Token: 0x0400C9AD RID: 51629
		private static readonly IntPtr NativeFieldInfoPtr_DebugStart;

		// Token: 0x0400C9AE RID: 51630
		private static readonly IntPtr NativeFieldInfoPtr_DebugEnd;

		// Token: 0x0400C9AF RID: 51631
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x0400C9B0 RID: 51632
		private static readonly IntPtr NativeFieldInfoPtr__initialized;

		// Token: 0x0400C9B1 RID: 51633
		private static readonly IntPtr NativeFieldInfoPtr__scoringPlane;

		// Token: 0x0400C9B2 RID: 51634
		private static readonly IntPtr NativeFieldInfoPtr__lastScoreTime;

		// Token: 0x0400C9B3 RID: 51635
		private static readonly IntPtr NativeFieldInfoPtr__currentScore;

		// Token: 0x0400C9B4 RID: 51636
		private static readonly IntPtr NativeFieldInfoPtr__positionCache;

		// Token: 0x0400C9B5 RID: 51637
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x0400C9B6 RID: 51638
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x0400C9B7 RID: 51639
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x0400C9B8 RID: 51640
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x0400C9B9 RID: 51641
		private static readonly IntPtr NativeMethodInfoPtr_OnGameVariantSelected_Private_Void_GameVariantTypes_0;

		// Token: 0x0400C9BA RID: 51642
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Private_Void_0;

		// Token: 0x0400C9BB RID: 51643
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Private_Void_0;

		// Token: 0x0400C9BC RID: 51644
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x0400C9BD RID: 51645
		private static readonly IntPtr NativeMethodInfoPtr_CheckPathOnPlane_Private_GoalType_Plane_Vector3_Vector3_0;

		// Token: 0x0400C9BE RID: 51646
		private static readonly IntPtr NativeMethodInfoPtr_PointIsAbovePlane_Private_Boolean_Plane_Vector3_0;

		// Token: 0x0400C9BF RID: 51647
		private static readonly IntPtr NativeMethodInfoPtr_PlayScoreEffects_Private_Void_0;

		// Token: 0x0400C9C0 RID: 51648
		private static readonly IntPtr NativeMethodInfoPtr_RefreshScoreElements_Private_Void_0;

		// Token: 0x0400C9C1 RID: 51649
		private static readonly IntPtr NativeMethodInfoPtr_OnInterludeChange_Private_Void_Boolean_0;

		// Token: 0x0400C9C2 RID: 51650
		private static readonly IntPtr NativeMethodInfoPtr_OnPerformScoreEvent_Private_Void_BasketballGoalScoreEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400C9C3 RID: 51651
		private static readonly IntPtr NativeMethodInfoPtr_OnRequestScoreEvent_Private_Void_BasketballGoalRequestEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400C9C4 RID: 51652
		private static readonly IntPtr NativeMethodInfoPtr_OnSendScoreEvent_Private_Void_BasketballGoalSendEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400C9C5 RID: 51653
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02001020 RID: 4128
		public enum GoalType
		{
			// Token: 0x0400C9C7 RID: 51655
			None,
			// Token: 0x0400C9C8 RID: 51656
			FromAbove,
			// Token: 0x0400C9C9 RID: 51657
			FromBelow
		}
	}
}
