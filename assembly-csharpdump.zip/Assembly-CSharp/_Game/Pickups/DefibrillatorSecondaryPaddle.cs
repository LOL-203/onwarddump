﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.Pickups
{
	// Token: 0x02000950 RID: 2384
	public class DefibrillatorSecondaryPaddle : Pickup
	{
		// Token: 0x0600CAA5 RID: 51877 RVA: 0x003263B4 File Offset: 0x003245B4
		[CallerCount(0)]
		public new unsafe bool CanGrab(InputCommand command, HandController hand)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref command;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(hand);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), DefibrillatorSecondaryPaddle.NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CAA6 RID: 51878 RVA: 0x0032643C File Offset: 0x0032463C
		[CallerCount(0)]
		public unsafe DefibrillatorSecondaryPaddle() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DefibrillatorSecondaryPaddle.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAA7 RID: 51879 RVA: 0x00326488 File Offset: 0x00324688
		// Note: this type is marked as 'beforefieldinit'.
		static DefibrillatorSecondaryPaddle()
		{
			Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Pickups", "DefibrillatorSecondaryPaddle");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr);
			DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_StartPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, "StartPos");
			DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_Indicators = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, "Indicators");
			DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_PaddleCenter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, "PaddleCenter");
			DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_ChargingParticle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, "ChargingParticle");
			DefibrillatorSecondaryPaddle.NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, 100678906);
			DefibrillatorSecondaryPaddle.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr, 100678907);
		}

		// Token: 0x0600CAA8 RID: 51880 RVA: 0x00047D20 File Offset: 0x00045F20
		public DefibrillatorSecondaryPaddle(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049CE RID: 18894
		// (get) Token: 0x0600CAA9 RID: 51881 RVA: 0x00326530 File Offset: 0x00324730
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DefibrillatorSecondaryPaddle>.NativeClassPtr));
			}
		}

		// Token: 0x170049CF RID: 18895
		// (get) Token: 0x0600CAAA RID: 51882 RVA: 0x00326544 File Offset: 0x00324744
		// (set) Token: 0x0600CAAB RID: 51883 RVA: 0x00326578 File Offset: 0x00324778
		public unsafe Transform StartPos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_StartPos);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_StartPos), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049D0 RID: 18896
		// (get) Token: 0x0600CAAC RID: 51884 RVA: 0x003265A0 File Offset: 0x003247A0
		// (set) Token: 0x0600CAAD RID: 51885 RVA: 0x003265D4 File Offset: 0x003247D4
		public unsafe Il2CppReferenceArray<Renderer> Indicators
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_Indicators);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Renderer>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_Indicators), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049D1 RID: 18897
		// (get) Token: 0x0600CAAE RID: 51886 RVA: 0x003265FC File Offset: 0x003247FC
		// (set) Token: 0x0600CAAF RID: 51887 RVA: 0x00326630 File Offset: 0x00324830
		public unsafe Transform PaddleCenter
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_PaddleCenter);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_PaddleCenter), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049D2 RID: 18898
		// (get) Token: 0x0600CAB0 RID: 51888 RVA: 0x00326658 File Offset: 0x00324858
		// (set) Token: 0x0600CAB1 RID: 51889 RVA: 0x0032668C File Offset: 0x0032488C
		public unsafe ParticleSystem ChargingParticle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_ChargingParticle);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ParticleSystem(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DefibrillatorSecondaryPaddle.NativeFieldInfoPtr_ChargingParticle), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008011 RID: 32785
		private static readonly IntPtr NativeFieldInfoPtr_StartPos;

		// Token: 0x04008012 RID: 32786
		private static readonly IntPtr NativeFieldInfoPtr_Indicators;

		// Token: 0x04008013 RID: 32787
		private static readonly IntPtr NativeFieldInfoPtr_PaddleCenter;

		// Token: 0x04008014 RID: 32788
		private static readonly IntPtr NativeFieldInfoPtr_ChargingParticle;

		// Token: 0x04008015 RID: 32789
		private static readonly IntPtr NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0;

		// Token: 0x04008016 RID: 32790
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
