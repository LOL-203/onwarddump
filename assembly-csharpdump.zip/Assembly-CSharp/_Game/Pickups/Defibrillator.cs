﻿using System;
using System.Runtime.InteropServices;
using AK.Wwise;
using DPI.Networking;
using DPI.Networking.IO;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.Pickups
{
	// Token: 0x0200094E RID: 2382
	public class Defibrillator : Pickup
	{
		// Token: 0x0600CA32 RID: 51762 RVA: 0x00324678 File Offset: 0x00322878
		[CallerCount(0)]
		public new unsafe void OnStart()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnStart_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA33 RID: 51763 RVA: 0x003246C8 File Offset: 0x003228C8
		[CallerCount(0)]
		public new unsafe void OnDestroyInherited()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnDestroyInherited_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA34 RID: 51764 RVA: 0x00324718 File Offset: 0x00322918
		[CallerCount(0)]
		public new unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA35 RID: 51765 RVA: 0x00324768 File Offset: 0x00322968
		[CallerCount(0)]
		public new unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnDisable_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA36 RID: 51766 RVA: 0x003247B8 File Offset: 0x003229B8
		[CallerCount(0)]
		public new unsafe void OnUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnUpdate_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA37 RID: 51767 RVA: 0x00324808 File Offset: 0x00322A08
		[CallerCount(0)]
		public new unsafe void OnUpdateInHand()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnUpdateInHand_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA38 RID: 51768 RVA: 0x00324858 File Offset: 0x00322A58
		[CallerCount(0)]
		public unsafe void UpdateActiveCharging()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_UpdateActiveCharging_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA39 RID: 51769 RVA: 0x0032489C File Offset: 0x00322A9C
		[CallerCount(0)]
		public unsafe void Rubbing()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_Rubbing_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA3A RID: 51770 RVA: 0x003248E0 File Offset: 0x00322AE0
		[CallerCount(0)]
		public unsafe bool IsActivelyCharging()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_IsActivelyCharging_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA3B RID: 51771 RVA: 0x00324930 File Offset: 0x00322B30
		[CallerCount(0)]
		public new unsafe bool CanGrab(InputCommand command, HandController hand)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref command;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(hand);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA3C RID: 51772 RVA: 0x003249B8 File Offset: 0x00322BB8
		[CallerCount(0)]
		public unsafe void CheckForHeal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_CheckForHeal_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA3D RID: 51773 RVA: 0x003249FC File Offset: 0x00322BFC
		[CallerCount(0)]
		public unsafe void UpdateAudioOrigin()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_UpdateAudioOrigin_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA3E RID: 51774 RVA: 0x00324A40 File Offset: 0x00322C40
		[CallerCount(0)]
		public unsafe void UpdateIndicators()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_UpdateIndicators_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA3F RID: 51775 RVA: 0x00324A84 File Offset: 0x00322C84
		[CallerCount(0)]
		public unsafe DamageController GetDamageController(Transform startPoint)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(startPoint);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_GetDamageController_Private_DamageController_Transform_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
		}

		// Token: 0x0600CA40 RID: 51776 RVA: 0x00324AF4 File Offset: 0x00322CF4
		[CallerCount(0)]
		public unsafe void SetDamageControllerColliders(bool active)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref active;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_SetDamageControllerColliders_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA41 RID: 51777 RVA: 0x00324B48 File Offset: 0x00322D48
		[CallerCount(0)]
		public unsafe void KillChargeLevel()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_KillChargeLevel_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA42 RID: 51778 RVA: 0x00324B8C File Offset: 0x00322D8C
		[CallerCount(0)]
		public unsafe void SetChargeLevel(float value, bool sync)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref sync;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_SetChargeLevel_Private_Void_Single_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA43 RID: 51779 RVA: 0x00324BF4 File Offset: 0x00322DF4
		[CallerCount(0)]
		public unsafe void SyncChargeLevel()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_SyncChargeLevel_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA44 RID: 51780 RVA: 0x00324C38 File Offset: 0x00322E38
		[CallerCount(0)]
		public unsafe void RPC_SetChargeLevel(float newChargeLevel, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newChargeLevel;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Private_Void_Single_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA45 RID: 51781 RVA: 0x00324CAC File Offset: 0x00322EAC
		[CallerCount(0)]
		public unsafe void PlayDefibrillateEffects()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_PlayDefibrillateEffects_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA46 RID: 51782 RVA: 0x00324CF0 File Offset: 0x00322EF0
		[CallerCount(0)]
		public unsafe void PlayChargeEffects()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_PlayChargeEffects_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA47 RID: 51783 RVA: 0x00324D34 File Offset: 0x00322F34
		[CallerCount(0)]
		public unsafe bool GetHasHealInputs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_GetHasHealInputs_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA48 RID: 51784 RVA: 0x00324D84 File Offset: 0x00322F84
		[CallerCount(0)]
		public unsafe bool GetHasHarmInputs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_GetHasHarmInputs_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA49 RID: 51785 RVA: 0x00324DD4 File Offset: 0x00322FD4
		[CallerCount(0)]
		public unsafe bool GetAreTriggersDown()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_GetAreTriggersDown_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA4A RID: 51786 RVA: 0x00324E24 File Offset: 0x00323024
		[CallerCount(0)]
		public unsafe void SetParticles(bool playing, bool force = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref playing;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref force;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_SetParticles_Private_Void_Boolean_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA4B RID: 51787 RVA: 0x00324E8C File Offset: 0x0032308C
		[CallerCount(0)]
		public unsafe void Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiUnique_DPINetworkMessageInfo_0(Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique tmp, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref tmp;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiUnique_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA4C RID: 51788 RVA: 0x00324F00 File Offset: 0x00323100
		[CallerCount(0)]
		public unsafe void RPC_SetChargeLevel(Il2CppReferenceArray<DPIPlayer> invokeRpcPlayerTargets, float newChargeLevel)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTargets);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newChargeLevel;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_ArrayOf_DPIPlayer_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA4D RID: 51789 RVA: 0x00324F6C File Offset: 0x0032316C
		[CallerCount(0)]
		public unsafe void RPC_SetChargeLevel(DPIPlayer invokeRpcPlayerTarget, float newChargeLevel)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTarget);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newChargeLevel;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_DPIPlayer_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA4E RID: 51790 RVA: 0x00324FD8 File Offset: 0x003231D8
		[CallerCount(0)]
		public unsafe void RPC_SetChargeLevel(RpcTarget invokeRpcTarget, float newChargeLevel)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref invokeRpcTarget;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref newChargeLevel;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_RpcTarget_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA4F RID: 51791 RVA: 0x00325040 File Offset: 0x00323240
		[CallerCount(0)]
		public new unsafe void OnCodeGenInitializeHook()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Defibrillator.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA50 RID: 51792 RVA: 0x00325090 File Offset: 0x00323290
		[CallerCount(0)]
		public unsafe Defibrillator() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA51 RID: 51793 RVA: 0x003250DC File Offset: 0x003232DC
		// Note: this type is marked as 'beforefieldinit'.
		static Defibrillator()
		{
			Il2CppClassPointerStore<Defibrillator>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Pickups", "Defibrillator");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr);
			Defibrillator.NativeFieldInfoPtr_AllDefibrillators = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "AllDefibrillators");
			Defibrillator.NativeFieldInfoPtr_OtherPaddle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "OtherPaddle");
			Defibrillator.NativeFieldInfoPtr_AudioOrigin = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "AudioOrigin");
			Defibrillator.NativeFieldInfoPtr_HealSoundEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "HealSoundEvent");
			Defibrillator.NativeFieldInfoPtr_ChargeSoundEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "ChargeSoundEvent");
			Defibrillator.NativeFieldInfoPtr_Indicators = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "Indicators");
			Defibrillator.NativeFieldInfoPtr_ChargeLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "ChargeLevel");
			Defibrillator.NativeFieldInfoPtr_MaxChargeLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MaxChargeLevel");
			Defibrillator.NativeFieldInfoPtr_StartingChargeLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "StartingChargeLevel");
			Defibrillator.NativeFieldInfoPtr_PassiveChargeSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "PassiveChargeSpeed");
			Defibrillator.NativeFieldInfoPtr_ActiveChargeSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "ActiveChargeSpeed");
			Defibrillator.NativeFieldInfoPtr_MinMaterialLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MinMaterialLevel");
			Defibrillator.NativeFieldInfoPtr_MaxMaterialLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MaxMaterialLevel");
			Defibrillator.NativeFieldInfoPtr_SyncRate = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "SyncRate");
			Defibrillator.NativeFieldInfoPtr_MaxPaddleDistance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MaxPaddleDistance");
			Defibrillator.NativeFieldInfoPtr_MaxRubbingAngle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MaxRubbingAngle");
			Defibrillator.NativeFieldInfoPtr_MinMovementSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "MinMovementSpeed");
			Defibrillator.NativeFieldInfoPtr_ChargeFalloff = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "ChargeFalloff");
			Defibrillator.NativeFieldInfoPtr_PaddleCenter = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "PaddleCenter");
			Defibrillator.NativeFieldInfoPtr_ChargingParticle = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "ChargingParticle");
			Defibrillator.NativeFieldInfoPtr_SphereCastBuffer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "SphereCastBuffer");
			Defibrillator.NativeFieldInfoPtr_damageControllers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "damageControllers");
			Defibrillator.NativeFieldInfoPtr_StartPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "StartPos");
			Defibrillator.NativeFieldInfoPtr_Radius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "Radius");
			Defibrillator.NativeFieldInfoPtr__hitMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_hitMask");
			Defibrillator.NativeFieldInfoPtr__chargeLevelProperty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_chargeLevelProperty");
			Defibrillator.NativeFieldInfoPtr__hasPlayedChargeEffects = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_hasPlayedChargeEffects");
			Defibrillator.NativeFieldInfoPtr__playingIds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_playingIds");
			Defibrillator.NativeFieldInfoPtr__isAudioPlaying = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_isAudioPlaying");
			Defibrillator.NativeFieldInfoPtr__hasStarted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_hasStarted");
			Defibrillator.NativeFieldInfoPtr__paddleMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_paddleMaterial");
			Defibrillator.NativeFieldInfoPtr__lastPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_lastPosition");
			Defibrillator.NativeFieldInfoPtr__currentChargeTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_currentChargeTime");
			Defibrillator.NativeFieldInfoPtr__isActiveCharging = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_isActiveCharging");
			Defibrillator.NativeFieldInfoPtr__particlesPlaying = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_particlesPlaying");
			Defibrillator.NativeFieldInfoPtr__lastSyncTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_lastSyncTime");
			Defibrillator.NativeFieldInfoPtr__lastSyncValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "_lastSyncValue");
			Defibrillator.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiUnique_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "Δδδ_H_RPC_SetChargeLevel");
			Defibrillator.NativeMethodInfoPtr_OnStart_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678872);
			Defibrillator.NativeMethodInfoPtr_OnDestroyInherited_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678873);
			Defibrillator.NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678874);
			Defibrillator.NativeMethodInfoPtr_OnDisable_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678875);
			Defibrillator.NativeMethodInfoPtr_OnUpdate_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678876);
			Defibrillator.NativeMethodInfoPtr_OnUpdateInHand_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678877);
			Defibrillator.NativeMethodInfoPtr_UpdateActiveCharging_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678878);
			Defibrillator.NativeMethodInfoPtr_Rubbing_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678879);
			Defibrillator.NativeMethodInfoPtr_IsActivelyCharging_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678880);
			Defibrillator.NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678881);
			Defibrillator.NativeMethodInfoPtr_CheckForHeal_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678882);
			Defibrillator.NativeMethodInfoPtr_UpdateAudioOrigin_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678883);
			Defibrillator.NativeMethodInfoPtr_UpdateIndicators_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678884);
			Defibrillator.NativeMethodInfoPtr_GetDamageController_Private_DamageController_Transform_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678885);
			Defibrillator.NativeMethodInfoPtr_SetDamageControllerColliders_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678886);
			Defibrillator.NativeMethodInfoPtr_KillChargeLevel_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678887);
			Defibrillator.NativeMethodInfoPtr_SetChargeLevel_Private_Void_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678888);
			Defibrillator.NativeMethodInfoPtr_SyncChargeLevel_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678889);
			Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Private_Void_Single_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678890);
			Defibrillator.NativeMethodInfoPtr_PlayDefibrillateEffects_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678891);
			Defibrillator.NativeMethodInfoPtr_PlayChargeEffects_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678892);
			Defibrillator.NativeMethodInfoPtr_GetHasHealInputs_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678893);
			Defibrillator.NativeMethodInfoPtr_GetHasHarmInputs_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678894);
			Defibrillator.NativeMethodInfoPtr_GetAreTriggersDown_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678895);
			Defibrillator.NativeMethodInfoPtr_SetParticles_Private_Void_Boolean_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678896);
			Defibrillator.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiUnique_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678897);
			Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_ArrayOf_DPIPlayer_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678898);
			Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_DPIPlayer_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678899);
			Defibrillator.NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_RpcTarget_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678900);
			Defibrillator.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678901);
			Defibrillator.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, 100678902);
		}

		// Token: 0x0600CA52 RID: 51794 RVA: 0x00047D20 File Offset: 0x00045F20
		public Defibrillator(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049A6 RID: 18854
		// (get) Token: 0x0600CA53 RID: 51795 RVA: 0x00325670 File Offset: 0x00323870
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr));
			}
		}

		// Token: 0x170049A7 RID: 18855
		// (get) Token: 0x0600CA54 RID: 51796 RVA: 0x00325684 File Offset: 0x00323884
		// (set) Token: 0x0600CA55 RID: 51797 RVA: 0x003256AF File Offset: 0x003238AF
		public unsafe static List<Defibrillator> AllDefibrillators
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(Defibrillator.NativeFieldInfoPtr_AllDefibrillators, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<Defibrillator>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Defibrillator.NativeFieldInfoPtr_AllDefibrillators, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049A8 RID: 18856
		// (get) Token: 0x0600CA56 RID: 51798 RVA: 0x003256C4 File Offset: 0x003238C4
		// (set) Token: 0x0600CA57 RID: 51799 RVA: 0x003256F8 File Offset: 0x003238F8
		public unsafe DefibrillatorSecondaryPaddle OtherPaddle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_OtherPaddle);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DefibrillatorSecondaryPaddle(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_OtherPaddle), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049A9 RID: 18857
		// (get) Token: 0x0600CA58 RID: 51800 RVA: 0x00325720 File Offset: 0x00323920
		// (set) Token: 0x0600CA59 RID: 51801 RVA: 0x00325754 File Offset: 0x00323954
		public unsafe GameObject AudioOrigin
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_AudioOrigin);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_AudioOrigin), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049AA RID: 18858
		// (get) Token: 0x0600CA5A RID: 51802 RVA: 0x0032577C File Offset: 0x0032397C
		// (set) Token: 0x0600CA5B RID: 51803 RVA: 0x003257B0 File Offset: 0x003239B0
		public unsafe AK.Wwise.Event HealSoundEvent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_HealSoundEvent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_HealSoundEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049AB RID: 18859
		// (get) Token: 0x0600CA5C RID: 51804 RVA: 0x003257D8 File Offset: 0x003239D8
		// (set) Token: 0x0600CA5D RID: 51805 RVA: 0x0032580C File Offset: 0x00323A0C
		public unsafe AK.Wwise.Event ChargeSoundEvent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeSoundEvent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AK.Wwise.Event(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeSoundEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049AC RID: 18860
		// (get) Token: 0x0600CA5E RID: 51806 RVA: 0x00325834 File Offset: 0x00323A34
		// (set) Token: 0x0600CA5F RID: 51807 RVA: 0x00325868 File Offset: 0x00323A68
		public unsafe Il2CppReferenceArray<Renderer> Indicators
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_Indicators);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Renderer>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_Indicators), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049AD RID: 18861
		// (get) Token: 0x0600CA60 RID: 51808 RVA: 0x00325890 File Offset: 0x00323A90
		// (set) Token: 0x0600CA61 RID: 51809 RVA: 0x003258B8 File Offset: 0x00323AB8
		public unsafe float ChargeLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeLevel)) = value;
			}
		}

		// Token: 0x170049AE RID: 18862
		// (get) Token: 0x0600CA62 RID: 51810 RVA: 0x003258DC File Offset: 0x00323ADC
		// (set) Token: 0x0600CA63 RID: 51811 RVA: 0x00325904 File Offset: 0x00323B04
		public unsafe float MaxChargeLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxChargeLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxChargeLevel)) = value;
			}
		}

		// Token: 0x170049AF RID: 18863
		// (get) Token: 0x0600CA64 RID: 51812 RVA: 0x00325928 File Offset: 0x00323B28
		// (set) Token: 0x0600CA65 RID: 51813 RVA: 0x00325950 File Offset: 0x00323B50
		public unsafe float StartingChargeLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_StartingChargeLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_StartingChargeLevel)) = value;
			}
		}

		// Token: 0x170049B0 RID: 18864
		// (get) Token: 0x0600CA66 RID: 51814 RVA: 0x00325974 File Offset: 0x00323B74
		// (set) Token: 0x0600CA67 RID: 51815 RVA: 0x0032599C File Offset: 0x00323B9C
		public unsafe float PassiveChargeSpeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_PassiveChargeSpeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_PassiveChargeSpeed)) = value;
			}
		}

		// Token: 0x170049B1 RID: 18865
		// (get) Token: 0x0600CA68 RID: 51816 RVA: 0x003259C0 File Offset: 0x00323BC0
		// (set) Token: 0x0600CA69 RID: 51817 RVA: 0x003259E8 File Offset: 0x00323BE8
		public unsafe float ActiveChargeSpeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ActiveChargeSpeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ActiveChargeSpeed)) = value;
			}
		}

		// Token: 0x170049B2 RID: 18866
		// (get) Token: 0x0600CA6A RID: 51818 RVA: 0x00325A0C File Offset: 0x00323C0C
		// (set) Token: 0x0600CA6B RID: 51819 RVA: 0x00325A34 File Offset: 0x00323C34
		public unsafe float MinMaterialLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MinMaterialLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MinMaterialLevel)) = value;
			}
		}

		// Token: 0x170049B3 RID: 18867
		// (get) Token: 0x0600CA6C RID: 51820 RVA: 0x00325A58 File Offset: 0x00323C58
		// (set) Token: 0x0600CA6D RID: 51821 RVA: 0x00325A80 File Offset: 0x00323C80
		public unsafe float MaxMaterialLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxMaterialLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxMaterialLevel)) = value;
			}
		}

		// Token: 0x170049B4 RID: 18868
		// (get) Token: 0x0600CA6E RID: 51822 RVA: 0x00325AA4 File Offset: 0x00323CA4
		// (set) Token: 0x0600CA6F RID: 51823 RVA: 0x00325ACC File Offset: 0x00323CCC
		public unsafe float SyncRate
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_SyncRate);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_SyncRate)) = value;
			}
		}

		// Token: 0x170049B5 RID: 18869
		// (get) Token: 0x0600CA70 RID: 51824 RVA: 0x00325AF0 File Offset: 0x00323CF0
		// (set) Token: 0x0600CA71 RID: 51825 RVA: 0x00325B18 File Offset: 0x00323D18
		public unsafe float MaxPaddleDistance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxPaddleDistance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxPaddleDistance)) = value;
			}
		}

		// Token: 0x170049B6 RID: 18870
		// (get) Token: 0x0600CA72 RID: 51826 RVA: 0x00325B3C File Offset: 0x00323D3C
		// (set) Token: 0x0600CA73 RID: 51827 RVA: 0x00325B64 File Offset: 0x00323D64
		public unsafe float MaxRubbingAngle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxRubbingAngle);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MaxRubbingAngle)) = value;
			}
		}

		// Token: 0x170049B7 RID: 18871
		// (get) Token: 0x0600CA74 RID: 51828 RVA: 0x00325B88 File Offset: 0x00323D88
		// (set) Token: 0x0600CA75 RID: 51829 RVA: 0x00325BB0 File Offset: 0x00323DB0
		public unsafe float MinMovementSpeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MinMovementSpeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_MinMovementSpeed)) = value;
			}
		}

		// Token: 0x170049B8 RID: 18872
		// (get) Token: 0x0600CA76 RID: 51830 RVA: 0x00325BD4 File Offset: 0x00323DD4
		// (set) Token: 0x0600CA77 RID: 51831 RVA: 0x00325BFC File Offset: 0x00323DFC
		public unsafe float ChargeFalloff
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeFalloff);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargeFalloff)) = value;
			}
		}

		// Token: 0x170049B9 RID: 18873
		// (get) Token: 0x0600CA78 RID: 51832 RVA: 0x00325C20 File Offset: 0x00323E20
		// (set) Token: 0x0600CA79 RID: 51833 RVA: 0x00325C54 File Offset: 0x00323E54
		public unsafe Transform PaddleCenter
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_PaddleCenter);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_PaddleCenter), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049BA RID: 18874
		// (get) Token: 0x0600CA7A RID: 51834 RVA: 0x00325C7C File Offset: 0x00323E7C
		// (set) Token: 0x0600CA7B RID: 51835 RVA: 0x00325CB0 File Offset: 0x00323EB0
		public unsafe ParticleSystem ChargingParticle
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargingParticle);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ParticleSystem(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_ChargingParticle), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049BB RID: 18875
		// (get) Token: 0x0600CA7C RID: 51836 RVA: 0x00325CD8 File Offset: 0x00323ED8
		// (set) Token: 0x0600CA7D RID: 51837 RVA: 0x00325D0C File Offset: 0x00323F0C
		public unsafe Il2CppReferenceArray<Collider> SphereCastBuffer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_SphereCastBuffer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<Collider>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_SphereCastBuffer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049BC RID: 18876
		// (get) Token: 0x0600CA7E RID: 51838 RVA: 0x00325D34 File Offset: 0x00323F34
		// (set) Token: 0x0600CA7F RID: 51839 RVA: 0x00325D68 File Offset: 0x00323F68
		public unsafe List<DamageController> damageControllers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_damageControllers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<DamageController>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_damageControllers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049BD RID: 18877
		// (get) Token: 0x0600CA80 RID: 51840 RVA: 0x00325D90 File Offset: 0x00323F90
		// (set) Token: 0x0600CA81 RID: 51841 RVA: 0x00325DC4 File Offset: 0x00323FC4
		public unsafe Transform StartPos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_StartPos);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_StartPos), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049BE RID: 18878
		// (get) Token: 0x0600CA82 RID: 51842 RVA: 0x00325DEC File Offset: 0x00323FEC
		// (set) Token: 0x0600CA83 RID: 51843 RVA: 0x00325E14 File Offset: 0x00324014
		public unsafe float Radius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_Radius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_Radius)) = value;
			}
		}

		// Token: 0x170049BF RID: 18879
		// (get) Token: 0x0600CA84 RID: 51844 RVA: 0x00325E38 File Offset: 0x00324038
		// (set) Token: 0x0600CA85 RID: 51845 RVA: 0x00325E60 File Offset: 0x00324060
		public unsafe LayerMask _hitMask
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hitMask);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hitMask)) = value;
			}
		}

		// Token: 0x170049C0 RID: 18880
		// (get) Token: 0x0600CA86 RID: 51846 RVA: 0x00325E84 File Offset: 0x00324084
		// (set) Token: 0x0600CA87 RID: 51847 RVA: 0x00325EAC File Offset: 0x003240AC
		public unsafe int _chargeLevelProperty
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__chargeLevelProperty);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__chargeLevelProperty)) = value;
			}
		}

		// Token: 0x170049C1 RID: 18881
		// (get) Token: 0x0600CA88 RID: 51848 RVA: 0x00325ED0 File Offset: 0x003240D0
		// (set) Token: 0x0600CA89 RID: 51849 RVA: 0x00325EF8 File Offset: 0x003240F8
		public unsafe bool _hasPlayedChargeEffects
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hasPlayedChargeEffects);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hasPlayedChargeEffects)) = value;
			}
		}

		// Token: 0x170049C2 RID: 18882
		// (get) Token: 0x0600CA8A RID: 51850 RVA: 0x00325F1C File Offset: 0x0032411C
		// (set) Token: 0x0600CA8B RID: 51851 RVA: 0x00325F50 File Offset: 0x00324150
		public unsafe Il2CppStructArray<uint> _playingIds
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__playingIds);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<uint>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__playingIds), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049C3 RID: 18883
		// (get) Token: 0x0600CA8C RID: 51852 RVA: 0x00325F78 File Offset: 0x00324178
		// (set) Token: 0x0600CA8D RID: 51853 RVA: 0x00325FA0 File Offset: 0x003241A0
		public unsafe bool _isAudioPlaying
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__isAudioPlaying);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__isAudioPlaying)) = value;
			}
		}

		// Token: 0x170049C4 RID: 18884
		// (get) Token: 0x0600CA8E RID: 51854 RVA: 0x00325FC4 File Offset: 0x003241C4
		// (set) Token: 0x0600CA8F RID: 51855 RVA: 0x00325FEC File Offset: 0x003241EC
		public unsafe bool _hasStarted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hasStarted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__hasStarted)) = value;
			}
		}

		// Token: 0x170049C5 RID: 18885
		// (get) Token: 0x0600CA90 RID: 51856 RVA: 0x00326010 File Offset: 0x00324210
		// (set) Token: 0x0600CA91 RID: 51857 RVA: 0x00326044 File Offset: 0x00324244
		public unsafe Material _paddleMaterial
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__paddleMaterial);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Material(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__paddleMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049C6 RID: 18886
		// (get) Token: 0x0600CA92 RID: 51858 RVA: 0x0032606C File Offset: 0x0032426C
		// (set) Token: 0x0600CA93 RID: 51859 RVA: 0x00326094 File Offset: 0x00324294
		public unsafe Vector3 _lastPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastPosition)) = value;
			}
		}

		// Token: 0x170049C7 RID: 18887
		// (get) Token: 0x0600CA94 RID: 51860 RVA: 0x003260B8 File Offset: 0x003242B8
		// (set) Token: 0x0600CA95 RID: 51861 RVA: 0x003260E0 File Offset: 0x003242E0
		public unsafe float _currentChargeTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__currentChargeTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__currentChargeTime)) = value;
			}
		}

		// Token: 0x170049C8 RID: 18888
		// (get) Token: 0x0600CA96 RID: 51862 RVA: 0x00326104 File Offset: 0x00324304
		// (set) Token: 0x0600CA97 RID: 51863 RVA: 0x0032612C File Offset: 0x0032432C
		public unsafe bool _isActiveCharging
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__isActiveCharging);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__isActiveCharging)) = value;
			}
		}

		// Token: 0x170049C9 RID: 18889
		// (get) Token: 0x0600CA98 RID: 51864 RVA: 0x00326150 File Offset: 0x00324350
		// (set) Token: 0x0600CA99 RID: 51865 RVA: 0x00326178 File Offset: 0x00324378
		public unsafe bool _particlesPlaying
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__particlesPlaying);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__particlesPlaying)) = value;
			}
		}

		// Token: 0x170049CA RID: 18890
		// (get) Token: 0x0600CA9A RID: 51866 RVA: 0x0032619C File Offset: 0x0032439C
		// (set) Token: 0x0600CA9B RID: 51867 RVA: 0x003261C4 File Offset: 0x003243C4
		public unsafe double _lastSyncTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastSyncTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastSyncTime)) = value;
			}
		}

		// Token: 0x170049CB RID: 18891
		// (get) Token: 0x0600CA9C RID: 51868 RVA: 0x003261E8 File Offset: 0x003243E8
		// (set) Token: 0x0600CA9D RID: 51869 RVA: 0x00326210 File Offset: 0x00324410
		public unsafe float _lastSyncValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastSyncValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr__lastSyncValue)) = value;
			}
		}

		// Token: 0x170049CC RID: 18892
		// (get) Token: 0x0600CA9E RID: 51870 RVA: 0x00326234 File Offset: 0x00324434
		// (set) Token: 0x0600CA9F RID: 51871 RVA: 0x00326268 File Offset: 0x00324468
		public new unsafe EntityClientRpcHandle<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique> field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiUnique_0
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiUnique_0);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new EntityClientRpcHandle<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Defibrillator.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiUnique_0), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007FC8 RID: 32712
		private static readonly IntPtr NativeFieldInfoPtr_AllDefibrillators;

		// Token: 0x04007FC9 RID: 32713
		private static readonly IntPtr NativeFieldInfoPtr_OtherPaddle;

		// Token: 0x04007FCA RID: 32714
		private static readonly IntPtr NativeFieldInfoPtr_AudioOrigin;

		// Token: 0x04007FCB RID: 32715
		private static readonly IntPtr NativeFieldInfoPtr_HealSoundEvent;

		// Token: 0x04007FCC RID: 32716
		private static readonly IntPtr NativeFieldInfoPtr_ChargeSoundEvent;

		// Token: 0x04007FCD RID: 32717
		private static readonly IntPtr NativeFieldInfoPtr_Indicators;

		// Token: 0x04007FCE RID: 32718
		private static readonly IntPtr NativeFieldInfoPtr_ChargeLevel;

		// Token: 0x04007FCF RID: 32719
		private static readonly IntPtr NativeFieldInfoPtr_MaxChargeLevel;

		// Token: 0x04007FD0 RID: 32720
		private static readonly IntPtr NativeFieldInfoPtr_StartingChargeLevel;

		// Token: 0x04007FD1 RID: 32721
		private static readonly IntPtr NativeFieldInfoPtr_PassiveChargeSpeed;

		// Token: 0x04007FD2 RID: 32722
		private static readonly IntPtr NativeFieldInfoPtr_ActiveChargeSpeed;

		// Token: 0x04007FD3 RID: 32723
		private static readonly IntPtr NativeFieldInfoPtr_MinMaterialLevel;

		// Token: 0x04007FD4 RID: 32724
		private static readonly IntPtr NativeFieldInfoPtr_MaxMaterialLevel;

		// Token: 0x04007FD5 RID: 32725
		private static readonly IntPtr NativeFieldInfoPtr_SyncRate;

		// Token: 0x04007FD6 RID: 32726
		private static readonly IntPtr NativeFieldInfoPtr_MaxPaddleDistance;

		// Token: 0x04007FD7 RID: 32727
		private static readonly IntPtr NativeFieldInfoPtr_MaxRubbingAngle;

		// Token: 0x04007FD8 RID: 32728
		private static readonly IntPtr NativeFieldInfoPtr_MinMovementSpeed;

		// Token: 0x04007FD9 RID: 32729
		private static readonly IntPtr NativeFieldInfoPtr_ChargeFalloff;

		// Token: 0x04007FDA RID: 32730
		private static readonly IntPtr NativeFieldInfoPtr_PaddleCenter;

		// Token: 0x04007FDB RID: 32731
		private static readonly IntPtr NativeFieldInfoPtr_ChargingParticle;

		// Token: 0x04007FDC RID: 32732
		private static readonly IntPtr NativeFieldInfoPtr_SphereCastBuffer;

		// Token: 0x04007FDD RID: 32733
		private static readonly IntPtr NativeFieldInfoPtr_damageControllers;

		// Token: 0x04007FDE RID: 32734
		private static readonly IntPtr NativeFieldInfoPtr_StartPos;

		// Token: 0x04007FDF RID: 32735
		private static readonly IntPtr NativeFieldInfoPtr_Radius;

		// Token: 0x04007FE0 RID: 32736
		private static readonly IntPtr NativeFieldInfoPtr__hitMask;

		// Token: 0x04007FE1 RID: 32737
		private static readonly IntPtr NativeFieldInfoPtr__chargeLevelProperty;

		// Token: 0x04007FE2 RID: 32738
		private static readonly IntPtr NativeFieldInfoPtr__hasPlayedChargeEffects;

		// Token: 0x04007FE3 RID: 32739
		private static readonly IntPtr NativeFieldInfoPtr__playingIds;

		// Token: 0x04007FE4 RID: 32740
		private static readonly IntPtr NativeFieldInfoPtr__isAudioPlaying;

		// Token: 0x04007FE5 RID: 32741
		private static readonly IntPtr NativeFieldInfoPtr__hasStarted;

		// Token: 0x04007FE6 RID: 32742
		private static readonly IntPtr NativeFieldInfoPtr__paddleMaterial;

		// Token: 0x04007FE7 RID: 32743
		private static readonly IntPtr NativeFieldInfoPtr__lastPosition;

		// Token: 0x04007FE8 RID: 32744
		private static readonly IntPtr NativeFieldInfoPtr__currentChargeTime;

		// Token: 0x04007FE9 RID: 32745
		private static readonly IntPtr NativeFieldInfoPtr__isActiveCharging;

		// Token: 0x04007FEA RID: 32746
		private static readonly IntPtr NativeFieldInfoPtr__particlesPlaying;

		// Token: 0x04007FEB RID: 32747
		private static readonly IntPtr NativeFieldInfoPtr__lastSyncTime;

		// Token: 0x04007FEC RID: 32748
		private static readonly IntPtr NativeFieldInfoPtr__lastSyncValue;

		// Token: 0x04007FED RID: 32749
		private static readonly IntPtr NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableSiUnique_0;

		// Token: 0x04007FEE RID: 32750
		private static readonly IntPtr NativeMethodInfoPtr_OnStart_Public_Virtual_Void_0;

		// Token: 0x04007FEF RID: 32751
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroyInherited_Public_Virtual_Void_0;

		// Token: 0x04007FF0 RID: 32752
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Protected_Virtual_Void_0;

		// Token: 0x04007FF1 RID: 32753
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Protected_Virtual_Void_0;

		// Token: 0x04007FF2 RID: 32754
		private static readonly IntPtr NativeMethodInfoPtr_OnUpdate_Protected_Virtual_Void_0;

		// Token: 0x04007FF3 RID: 32755
		private static readonly IntPtr NativeMethodInfoPtr_OnUpdateInHand_Protected_Virtual_Void_0;

		// Token: 0x04007FF4 RID: 32756
		private static readonly IntPtr NativeMethodInfoPtr_UpdateActiveCharging_Private_Void_0;

		// Token: 0x04007FF5 RID: 32757
		private static readonly IntPtr NativeMethodInfoPtr_Rubbing_Public_Void_0;

		// Token: 0x04007FF6 RID: 32758
		private static readonly IntPtr NativeMethodInfoPtr_IsActivelyCharging_Private_Boolean_0;

		// Token: 0x04007FF7 RID: 32759
		private static readonly IntPtr NativeMethodInfoPtr_CanGrab_Public_Virtual_Boolean_InputCommand_HandController_0;

		// Token: 0x04007FF8 RID: 32760
		private static readonly IntPtr NativeMethodInfoPtr_CheckForHeal_Private_Void_0;

		// Token: 0x04007FF9 RID: 32761
		private static readonly IntPtr NativeMethodInfoPtr_UpdateAudioOrigin_Private_Void_0;

		// Token: 0x04007FFA RID: 32762
		private static readonly IntPtr NativeMethodInfoPtr_UpdateIndicators_Private_Void_0;

		// Token: 0x04007FFB RID: 32763
		private static readonly IntPtr NativeMethodInfoPtr_GetDamageController_Private_DamageController_Transform_0;

		// Token: 0x04007FFC RID: 32764
		private static readonly IntPtr NativeMethodInfoPtr_SetDamageControllerColliders_Private_Void_Boolean_0;

		// Token: 0x04007FFD RID: 32765
		private static readonly IntPtr NativeMethodInfoPtr_KillChargeLevel_Private_Void_0;

		// Token: 0x04007FFE RID: 32766
		private static readonly IntPtr NativeMethodInfoPtr_SetChargeLevel_Private_Void_Single_Boolean_0;

		// Token: 0x04007FFF RID: 32767
		private static readonly IntPtr NativeMethodInfoPtr_SyncChargeLevel_Private_Void_0;

		// Token: 0x04008000 RID: 32768
		private static readonly IntPtr NativeMethodInfoPtr_RPC_SetChargeLevel_Private_Void_Single_DPINetworkMessageInfo_0;

		// Token: 0x04008001 RID: 32769
		private static readonly IntPtr NativeMethodInfoPtr_PlayDefibrillateEffects_Public_Void_0;

		// Token: 0x04008002 RID: 32770
		private static readonly IntPtr NativeMethodInfoPtr_PlayChargeEffects_Private_Void_0;

		// Token: 0x04008003 RID: 32771
		private static readonly IntPtr NativeMethodInfoPtr_GetHasHealInputs_Private_Boolean_0;

		// Token: 0x04008004 RID: 32772
		private static readonly IntPtr NativeMethodInfoPtr_GetHasHarmInputs_Private_Boolean_0;

		// Token: 0x04008005 RID: 32773
		private static readonly IntPtr NativeMethodInfoPtr_GetAreTriggersDown_Private_Boolean_0;

		// Token: 0x04008006 RID: 32774
		private static readonly IntPtr NativeMethodInfoPtr_SetParticles_Private_Void_Boolean_Boolean_0;

		// Token: 0x04008007 RID: 32775
		private static readonly IntPtr NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableSiUnique_DPINetworkMessageInfo_0;

		// Token: 0x04008008 RID: 32776
		private static readonly IntPtr NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_ArrayOf_DPIPlayer_Single_0;

		// Token: 0x04008009 RID: 32777
		private static readonly IntPtr NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_DPIPlayer_Single_0;

		// Token: 0x0400800A RID: 32778
		private static readonly IntPtr NativeMethodInfoPtr_RPC_SetChargeLevel_Public_Void_RpcTarget_Single_0;

		// Token: 0x0400800B RID: 32779
		private static readonly IntPtr NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0;

		// Token: 0x0400800C RID: 32780
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200094F RID: 2383
		[ObfuscatedName("_Game.Pickups.Defibrillator/Δδδ_S_RPC_SetChargeLevel")]
		[StructLayout(2)]
		public new struct ValueTypeNPrivateSealedINetworkStreamableSiUnique
		{
			// Token: 0x0600CAA0 RID: 51872 RVA: 0x00326290 File Offset: 0x00324490
			[CallerCount(0)]
			public unsafe void Read(DPINetworkStream networkStream)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CAA1 RID: 51873 RVA: 0x003262DC File Offset: 0x003244DC
			[CallerCount(0)]
			public unsafe void Write(DPINetworkStream networkStream)
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CAA2 RID: 51874 RVA: 0x00326328 File Offset: 0x00324528
			// Note: this type is marked as 'beforefieldinit'.
			static ValueTypeNPrivateSealedINetworkStreamableSiUnique()
			{
				Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<Defibrillator>.NativeClassPtr, "Δδδ_S_RPC_SetChargeLevel");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr);
				Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique.NativeFieldInfoPtr_field_Public_Single_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr, "Δδδ_I_newChargeLevel");
				Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr, 100678904);
				Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr, 100678905);
			}

			// Token: 0x0600CAA3 RID: 51875 RVA: 0x0032638F File Offset: 0x0032458F
			public Il2CppSystem.Object BoxIl2CppObject()
			{
				return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr, ref this));
			}

			// Token: 0x170049CD RID: 18893
			// (get) Token: 0x0600CAA4 RID: 51876 RVA: 0x003263A1 File Offset: 0x003245A1
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Defibrillator.ValueTypeNPrivateSealedINetworkStreamableSiUnique>.NativeClassPtr));
				}
			}

			// Token: 0x0400800D RID: 32781
			private static readonly IntPtr NativeFieldInfoPtr_field_Public_Single_0;

			// Token: 0x0400800E RID: 32782
			private static readonly IntPtr NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0;

			// Token: 0x0400800F RID: 32783
			private static readonly IntPtr NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0;

			// Token: 0x04008010 RID: 32784
			[FieldOffset(0)]
			public float field_Public_Single_0;
		}
	}
}
