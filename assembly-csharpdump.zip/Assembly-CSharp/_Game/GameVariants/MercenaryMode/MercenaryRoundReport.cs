﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000977 RID: 2423
	[Serializable]
	[StructLayout(0)]
	public sealed class MercenaryRoundReport : ValueType
	{
		// Token: 0x0600CCE6 RID: 52454 RVA: 0x0032F39C File Offset: 0x0032D59C
		[CallerCount(0)]
		public unsafe string FormatForAnalytics()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundReport.NativeMethodInfoPtr_FormatForAnalytics_Public_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCE7 RID: 52455 RVA: 0x0032F3E8 File Offset: 0x0032D5E8
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryRoundReport()
		{
			Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryRoundReport");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr);
			MercenaryRoundReport.NativeFieldInfoPtr_Mode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Mode");
			MercenaryRoundReport.NativeFieldInfoPtr_Challenge = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Challenge");
			MercenaryRoundReport.NativeFieldInfoPtr_Scale = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Scale");
			MercenaryRoundReport.NativeFieldInfoPtr_Difficulty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Difficulty");
			MercenaryRoundReport.NativeFieldInfoPtr_Map = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Map");
			MercenaryRoundReport.NativeFieldInfoPtr_IsEndless = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "IsEndless");
			MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveCompleted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "ObjectiveCompleted");
			MercenaryRoundReport.NativeFieldInfoPtr_IsMultiplayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "IsMultiplayer");
			MercenaryRoundReport.NativeFieldInfoPtr_Tier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "Tier");
			MercenaryRoundReport.NativeFieldInfoPtr_PlayerCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "PlayerCount");
			MercenaryRoundReport.NativeFieldInfoPtr_EnemyCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "EnemyCount");
			MercenaryRoundReport.NativeFieldInfoPtr_KillCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "KillCount");
			MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveScore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "ObjectiveScore");
			MercenaryRoundReport.NativeFieldInfoPtr_KillScore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "KillScore");
			MercenaryRoundReport.NativeFieldInfoPtr_TotalScore = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "TotalScore");
			MercenaryRoundReport.NativeFieldInfoPtr_SceneComplexity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "SceneComplexity");
			MercenaryRoundReport.NativeFieldInfoPtr_RawTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "RawTime");
			MercenaryRoundReport.NativeFieldInfoPtr_FastTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "FastTime");
			MercenaryRoundReport.NativeFieldInfoPtr_SlowTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "SlowTime");
			MercenaryRoundReport.NativeFieldInfoPtr_WindowTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "WindowTime");
			MercenaryRoundReport.NativeFieldInfoPtr_SurvivalNormalized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "SurvivalNormalized");
			MercenaryRoundReport.NativeFieldInfoPtr_TimeNormalized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "TimeNormalized");
			MercenaryRoundReport.NativeFieldInfoPtr_ChallengeMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "ChallengeMultiplier");
			MercenaryRoundReport.NativeFieldInfoPtr_SurvivalMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "SurvivalMultiplier");
			MercenaryRoundReport.NativeFieldInfoPtr_TimeMultiplier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "TimeMultiplier");
			MercenaryRoundReport.NativeFieldInfoPtr_KillVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "KillVelocity");
			MercenaryRoundReport.NativeFieldInfoPtr_KillCoverage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "KillCoverage");
			MercenaryRoundReport.NativeFieldInfoPtr_EnemyDensity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, "EnemyDensity");
			MercenaryRoundReport.NativeMethodInfoPtr_FormatForAnalytics_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, 100679092);
		}

		// Token: 0x0600CCE8 RID: 52456 RVA: 0x0002717B File Offset: 0x0002537B
		public MercenaryRoundReport(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A9E RID: 19102
		// (get) Token: 0x0600CCE9 RID: 52457 RVA: 0x0032F65C File Offset: 0x0032D85C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr));
			}
		}

		// Token: 0x0600CCEA RID: 52458 RVA: 0x0032F670 File Offset: 0x0032D870
		public unsafe MercenaryRoundReport()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<MercenaryRoundReport>.NativeClassPtr, data));
		}

		// Token: 0x17004A9F RID: 19103
		// (get) Token: 0x0600CCEB RID: 52459 RVA: 0x0032F6A0 File Offset: 0x0032D8A0
		// (set) Token: 0x0600CCEC RID: 52460 RVA: 0x0032F6C9 File Offset: 0x0032D8C9
		public unsafe string Mode
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Mode);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Mode), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AA0 RID: 19104
		// (get) Token: 0x0600CCED RID: 52461 RVA: 0x0032F6F0 File Offset: 0x0032D8F0
		// (set) Token: 0x0600CCEE RID: 52462 RVA: 0x0032F719 File Offset: 0x0032D919
		public unsafe string Challenge
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Challenge);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Challenge), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AA1 RID: 19105
		// (get) Token: 0x0600CCEF RID: 52463 RVA: 0x0032F740 File Offset: 0x0032D940
		// (set) Token: 0x0600CCF0 RID: 52464 RVA: 0x0032F769 File Offset: 0x0032D969
		public unsafe string Scale
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Scale);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Scale), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AA2 RID: 19106
		// (get) Token: 0x0600CCF1 RID: 52465 RVA: 0x0032F790 File Offset: 0x0032D990
		// (set) Token: 0x0600CCF2 RID: 52466 RVA: 0x0032F7B9 File Offset: 0x0032D9B9
		public unsafe string Difficulty
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Difficulty);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Difficulty), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AA3 RID: 19107
		// (get) Token: 0x0600CCF3 RID: 52467 RVA: 0x0032F7E0 File Offset: 0x0032D9E0
		// (set) Token: 0x0600CCF4 RID: 52468 RVA: 0x0032F809 File Offset: 0x0032DA09
		public unsafe string Map
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Map);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Map), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AA4 RID: 19108
		// (get) Token: 0x0600CCF5 RID: 52469 RVA: 0x0032F830 File Offset: 0x0032DA30
		// (set) Token: 0x0600CCF6 RID: 52470 RVA: 0x0032F858 File Offset: 0x0032DA58
		public unsafe bool IsEndless
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_IsEndless);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_IsEndless)) = value;
			}
		}

		// Token: 0x17004AA5 RID: 19109
		// (get) Token: 0x0600CCF7 RID: 52471 RVA: 0x0032F87C File Offset: 0x0032DA7C
		// (set) Token: 0x0600CCF8 RID: 52472 RVA: 0x0032F8A4 File Offset: 0x0032DAA4
		public unsafe bool ObjectiveCompleted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveCompleted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveCompleted)) = value;
			}
		}

		// Token: 0x17004AA6 RID: 19110
		// (get) Token: 0x0600CCF9 RID: 52473 RVA: 0x0032F8C8 File Offset: 0x0032DAC8
		// (set) Token: 0x0600CCFA RID: 52474 RVA: 0x0032F8F0 File Offset: 0x0032DAF0
		public unsafe bool IsMultiplayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_IsMultiplayer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_IsMultiplayer)) = value;
			}
		}

		// Token: 0x17004AA7 RID: 19111
		// (get) Token: 0x0600CCFB RID: 52475 RVA: 0x0032F914 File Offset: 0x0032DB14
		// (set) Token: 0x0600CCFC RID: 52476 RVA: 0x0032F93C File Offset: 0x0032DB3C
		public unsafe int Tier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Tier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_Tier)) = value;
			}
		}

		// Token: 0x17004AA8 RID: 19112
		// (get) Token: 0x0600CCFD RID: 52477 RVA: 0x0032F960 File Offset: 0x0032DB60
		// (set) Token: 0x0600CCFE RID: 52478 RVA: 0x0032F988 File Offset: 0x0032DB88
		public unsafe int PlayerCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_PlayerCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_PlayerCount)) = value;
			}
		}

		// Token: 0x17004AA9 RID: 19113
		// (get) Token: 0x0600CCFF RID: 52479 RVA: 0x0032F9AC File Offset: 0x0032DBAC
		// (set) Token: 0x0600CD00 RID: 52480 RVA: 0x0032F9D4 File Offset: 0x0032DBD4
		public unsafe int EnemyCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_EnemyCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_EnemyCount)) = value;
			}
		}

		// Token: 0x17004AAA RID: 19114
		// (get) Token: 0x0600CD01 RID: 52481 RVA: 0x0032F9F8 File Offset: 0x0032DBF8
		// (set) Token: 0x0600CD02 RID: 52482 RVA: 0x0032FA20 File Offset: 0x0032DC20
		public unsafe int KillCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillCount)) = value;
			}
		}

		// Token: 0x17004AAB RID: 19115
		// (get) Token: 0x0600CD03 RID: 52483 RVA: 0x0032FA44 File Offset: 0x0032DC44
		// (set) Token: 0x0600CD04 RID: 52484 RVA: 0x0032FA6C File Offset: 0x0032DC6C
		public unsafe int ObjectiveScore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveScore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ObjectiveScore)) = value;
			}
		}

		// Token: 0x17004AAC RID: 19116
		// (get) Token: 0x0600CD05 RID: 52485 RVA: 0x0032FA90 File Offset: 0x0032DC90
		// (set) Token: 0x0600CD06 RID: 52486 RVA: 0x0032FAB8 File Offset: 0x0032DCB8
		public unsafe int KillScore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillScore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillScore)) = value;
			}
		}

		// Token: 0x17004AAD RID: 19117
		// (get) Token: 0x0600CD07 RID: 52487 RVA: 0x0032FADC File Offset: 0x0032DCDC
		// (set) Token: 0x0600CD08 RID: 52488 RVA: 0x0032FB04 File Offset: 0x0032DD04
		public unsafe int TotalScore
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TotalScore);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TotalScore)) = value;
			}
		}

		// Token: 0x17004AAE RID: 19118
		// (get) Token: 0x0600CD09 RID: 52489 RVA: 0x0032FB28 File Offset: 0x0032DD28
		// (set) Token: 0x0600CD0A RID: 52490 RVA: 0x0032FB50 File Offset: 0x0032DD50
		public unsafe int SceneComplexity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SceneComplexity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SceneComplexity)) = value;
			}
		}

		// Token: 0x17004AAF RID: 19119
		// (get) Token: 0x0600CD0B RID: 52491 RVA: 0x0032FB74 File Offset: 0x0032DD74
		// (set) Token: 0x0600CD0C RID: 52492 RVA: 0x0032FB9C File Offset: 0x0032DD9C
		public unsafe float RawTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_RawTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_RawTime)) = value;
			}
		}

		// Token: 0x17004AB0 RID: 19120
		// (get) Token: 0x0600CD0D RID: 52493 RVA: 0x0032FBC0 File Offset: 0x0032DDC0
		// (set) Token: 0x0600CD0E RID: 52494 RVA: 0x0032FBE8 File Offset: 0x0032DDE8
		public unsafe float FastTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_FastTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_FastTime)) = value;
			}
		}

		// Token: 0x17004AB1 RID: 19121
		// (get) Token: 0x0600CD0F RID: 52495 RVA: 0x0032FC0C File Offset: 0x0032DE0C
		// (set) Token: 0x0600CD10 RID: 52496 RVA: 0x0032FC34 File Offset: 0x0032DE34
		public unsafe float SlowTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SlowTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SlowTime)) = value;
			}
		}

		// Token: 0x17004AB2 RID: 19122
		// (get) Token: 0x0600CD11 RID: 52497 RVA: 0x0032FC58 File Offset: 0x0032DE58
		// (set) Token: 0x0600CD12 RID: 52498 RVA: 0x0032FC80 File Offset: 0x0032DE80
		public unsafe float WindowTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_WindowTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_WindowTime)) = value;
			}
		}

		// Token: 0x17004AB3 RID: 19123
		// (get) Token: 0x0600CD13 RID: 52499 RVA: 0x0032FCA4 File Offset: 0x0032DEA4
		// (set) Token: 0x0600CD14 RID: 52500 RVA: 0x0032FCCC File Offset: 0x0032DECC
		public unsafe float SurvivalNormalized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SurvivalNormalized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SurvivalNormalized)) = value;
			}
		}

		// Token: 0x17004AB4 RID: 19124
		// (get) Token: 0x0600CD15 RID: 52501 RVA: 0x0032FCF0 File Offset: 0x0032DEF0
		// (set) Token: 0x0600CD16 RID: 52502 RVA: 0x0032FD18 File Offset: 0x0032DF18
		public unsafe float TimeNormalized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TimeNormalized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TimeNormalized)) = value;
			}
		}

		// Token: 0x17004AB5 RID: 19125
		// (get) Token: 0x0600CD17 RID: 52503 RVA: 0x0032FD3C File Offset: 0x0032DF3C
		// (set) Token: 0x0600CD18 RID: 52504 RVA: 0x0032FD64 File Offset: 0x0032DF64
		public unsafe float ChallengeMultiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ChallengeMultiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_ChallengeMultiplier)) = value;
			}
		}

		// Token: 0x17004AB6 RID: 19126
		// (get) Token: 0x0600CD19 RID: 52505 RVA: 0x0032FD88 File Offset: 0x0032DF88
		// (set) Token: 0x0600CD1A RID: 52506 RVA: 0x0032FDB0 File Offset: 0x0032DFB0
		public unsafe float SurvivalMultiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SurvivalMultiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_SurvivalMultiplier)) = value;
			}
		}

		// Token: 0x17004AB7 RID: 19127
		// (get) Token: 0x0600CD1B RID: 52507 RVA: 0x0032FDD4 File Offset: 0x0032DFD4
		// (set) Token: 0x0600CD1C RID: 52508 RVA: 0x0032FDFC File Offset: 0x0032DFFC
		public unsafe float TimeMultiplier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TimeMultiplier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_TimeMultiplier)) = value;
			}
		}

		// Token: 0x17004AB8 RID: 19128
		// (get) Token: 0x0600CD1D RID: 52509 RVA: 0x0032FE20 File Offset: 0x0032E020
		// (set) Token: 0x0600CD1E RID: 52510 RVA: 0x0032FE48 File Offset: 0x0032E048
		public unsafe float KillVelocity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillVelocity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillVelocity)) = value;
			}
		}

		// Token: 0x17004AB9 RID: 19129
		// (get) Token: 0x0600CD1F RID: 52511 RVA: 0x0032FE6C File Offset: 0x0032E06C
		// (set) Token: 0x0600CD20 RID: 52512 RVA: 0x0032FE94 File Offset: 0x0032E094
		public unsafe float KillCoverage
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillCoverage);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_KillCoverage)) = value;
			}
		}

		// Token: 0x17004ABA RID: 19130
		// (get) Token: 0x0600CD21 RID: 52513 RVA: 0x0032FEB8 File Offset: 0x0032E0B8
		// (set) Token: 0x0600CD22 RID: 52514 RVA: 0x0032FEE0 File Offset: 0x0032E0E0
		public unsafe float EnemyDensity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_EnemyDensity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundReport.NativeFieldInfoPtr_EnemyDensity)) = value;
			}
		}

		// Token: 0x04008198 RID: 33176
		private static readonly IntPtr NativeFieldInfoPtr_Mode;

		// Token: 0x04008199 RID: 33177
		private static readonly IntPtr NativeFieldInfoPtr_Challenge;

		// Token: 0x0400819A RID: 33178
		private static readonly IntPtr NativeFieldInfoPtr_Scale;

		// Token: 0x0400819B RID: 33179
		private static readonly IntPtr NativeFieldInfoPtr_Difficulty;

		// Token: 0x0400819C RID: 33180
		private static readonly IntPtr NativeFieldInfoPtr_Map;

		// Token: 0x0400819D RID: 33181
		private static readonly IntPtr NativeFieldInfoPtr_IsEndless;

		// Token: 0x0400819E RID: 33182
		private static readonly IntPtr NativeFieldInfoPtr_ObjectiveCompleted;

		// Token: 0x0400819F RID: 33183
		private static readonly IntPtr NativeFieldInfoPtr_IsMultiplayer;

		// Token: 0x040081A0 RID: 33184
		private static readonly IntPtr NativeFieldInfoPtr_Tier;

		// Token: 0x040081A1 RID: 33185
		private static readonly IntPtr NativeFieldInfoPtr_PlayerCount;

		// Token: 0x040081A2 RID: 33186
		private static readonly IntPtr NativeFieldInfoPtr_EnemyCount;

		// Token: 0x040081A3 RID: 33187
		private static readonly IntPtr NativeFieldInfoPtr_KillCount;

		// Token: 0x040081A4 RID: 33188
		private static readonly IntPtr NativeFieldInfoPtr_ObjectiveScore;

		// Token: 0x040081A5 RID: 33189
		private static readonly IntPtr NativeFieldInfoPtr_KillScore;

		// Token: 0x040081A6 RID: 33190
		private static readonly IntPtr NativeFieldInfoPtr_TotalScore;

		// Token: 0x040081A7 RID: 33191
		private static readonly IntPtr NativeFieldInfoPtr_SceneComplexity;

		// Token: 0x040081A8 RID: 33192
		private static readonly IntPtr NativeFieldInfoPtr_RawTime;

		// Token: 0x040081A9 RID: 33193
		private static readonly IntPtr NativeFieldInfoPtr_FastTime;

		// Token: 0x040081AA RID: 33194
		private static readonly IntPtr NativeFieldInfoPtr_SlowTime;

		// Token: 0x040081AB RID: 33195
		private static readonly IntPtr NativeFieldInfoPtr_WindowTime;

		// Token: 0x040081AC RID: 33196
		private static readonly IntPtr NativeFieldInfoPtr_SurvivalNormalized;

		// Token: 0x040081AD RID: 33197
		private static readonly IntPtr NativeFieldInfoPtr_TimeNormalized;

		// Token: 0x040081AE RID: 33198
		private static readonly IntPtr NativeFieldInfoPtr_ChallengeMultiplier;

		// Token: 0x040081AF RID: 33199
		private static readonly IntPtr NativeFieldInfoPtr_SurvivalMultiplier;

		// Token: 0x040081B0 RID: 33200
		private static readonly IntPtr NativeFieldInfoPtr_TimeMultiplier;

		// Token: 0x040081B1 RID: 33201
		private static readonly IntPtr NativeFieldInfoPtr_KillVelocity;

		// Token: 0x040081B2 RID: 33202
		private static readonly IntPtr NativeFieldInfoPtr_KillCoverage;

		// Token: 0x040081B3 RID: 33203
		private static readonly IntPtr NativeFieldInfoPtr_EnemyDensity;

		// Token: 0x040081B4 RID: 33204
		private static readonly IntPtr NativeMethodInfoPtr_FormatForAnalytics_Public_String_0;
	}
}
