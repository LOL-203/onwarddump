﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000978 RID: 2424
	[StructLayout(2)]
	public struct MercenaryRoundSnapshot
	{
		// Token: 0x0600CD23 RID: 52515 RVA: 0x0032FF04 File Offset: 0x0032E104
		[CallerCount(0)]
		public unsafe Il2CppStructArray<byte> ToByteArray()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshot.NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x0600CD24 RID: 52516 RVA: 0x0032FF4C File Offset: 0x0032E14C
		[CallerCount(0)]
		public unsafe static MercenaryRoundSnapshot FromByteArray(ArraySegment<byte> data)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(data));
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshot.NativeMethodInfoPtr_FromByteArray_Public_Static_MercenaryRoundSnapshot_ArraySegment_1_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD25 RID: 52517 RVA: 0x0032FFAC File Offset: 0x0032E1AC
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryRoundSnapshot()
		{
			Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryRoundSnapshot");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr);
			MercenaryRoundSnapshot.NativeFieldInfoPtr_RoundSeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, "RoundSeed");
			MercenaryRoundSnapshot.NativeFieldInfoPtr_RoundIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, "RoundIndex");
			MercenaryRoundSnapshot.NativeFieldInfoPtr_MapChosen = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, "MapChosen");
			MercenaryRoundSnapshot.NativeFieldInfoPtr_buffer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, "buffer");
			MercenaryRoundSnapshot.NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, 100679093);
			MercenaryRoundSnapshot.NativeMethodInfoPtr_FromByteArray_Public_Static_MercenaryRoundSnapshot_ArraySegment_1_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, 100679094);
		}

		// Token: 0x0600CD26 RID: 52518 RVA: 0x00330054 File Offset: 0x0032E254
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr, ref this));
		}

		// Token: 0x17004ABB RID: 19131
		// (get) Token: 0x0600CD27 RID: 52519 RVA: 0x00330066 File Offset: 0x0032E266
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryRoundSnapshot>.NativeClassPtr));
			}
		}

		// Token: 0x17004ABC RID: 19132
		// (get) Token: 0x0600CD28 RID: 52520 RVA: 0x00330078 File Offset: 0x0032E278
		// (set) Token: 0x0600CD29 RID: 52521 RVA: 0x003300A3 File Offset: 0x0032E2A3
		public unsafe static Il2CppStructArray<byte> buffer
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(MercenaryRoundSnapshot.NativeFieldInfoPtr_buffer, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryRoundSnapshot.NativeFieldInfoPtr_buffer, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040081B5 RID: 33205
		private static readonly IntPtr NativeFieldInfoPtr_RoundSeed;

		// Token: 0x040081B6 RID: 33206
		private static readonly IntPtr NativeFieldInfoPtr_RoundIndex;

		// Token: 0x040081B7 RID: 33207
		private static readonly IntPtr NativeFieldInfoPtr_MapChosen;

		// Token: 0x040081B8 RID: 33208
		private static readonly IntPtr NativeFieldInfoPtr_buffer;

		// Token: 0x040081B9 RID: 33209
		private static readonly IntPtr NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0;

		// Token: 0x040081BA RID: 33210
		private static readonly IntPtr NativeMethodInfoPtr_FromByteArray_Public_Static_MercenaryRoundSnapshot_ArraySegment_1_Byte_0;

		// Token: 0x040081BB RID: 33211
		[FieldOffset(0)]
		public int RoundSeed;

		// Token: 0x040081BC RID: 33212
		[FieldOffset(4)]
		public int RoundIndex;

		// Token: 0x040081BD RID: 33213
		[FieldOffset(8)]
		public byte MapChosen;
	}
}
