﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000972 RID: 2418
	public enum MercenaryOperationScale
	{
		// Token: 0x0400815A RID: 33114
		Auto,
		// Token: 0x0400815B RID: 33115
		Solo,
		// Token: 0x0400815C RID: 33116
		Duo,
		// Token: 0x0400815D RID: 33117
		Trio,
		// Token: 0x0400815E RID: 33118
		Quad
	}
}
