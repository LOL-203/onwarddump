﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000971 RID: 2417
	public enum MercenaryObjectives
	{
		// Token: 0x04008154 RID: 33108
		Eliminate,
		// Token: 0x04008155 RID: 33109
		Transmit,
		// Token: 0x04008156 RID: 33110
		Escape,
		// Token: 0x04008157 RID: 33111
		Extract,
		// Token: 0x04008158 RID: 33112
		Sabotage
	}
}
