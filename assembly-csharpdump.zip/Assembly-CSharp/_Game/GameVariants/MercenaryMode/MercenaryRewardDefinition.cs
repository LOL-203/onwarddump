﻿using System;
using DPI;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000974 RID: 2420
	[Serializable]
	public class MercenaryRewardDefinition : Object
	{
		// Token: 0x0600CCAF RID: 52399 RVA: 0x0032E858 File Offset: 0x0032CA58
		[CallerCount(0)]
		public unsafe void AddToReward(RandomWrapper random, ref MercenaryReward reward)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &reward;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRewardDefinition.NativeMethodInfoPtr_AddToReward_Public_Void_RandomWrapper_byref_MercenaryReward_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CCB0 RID: 52400 RVA: 0x0032E8C8 File Offset: 0x0032CAC8
		[CallerCount(0)]
		public unsafe MercenaryRewardDefinition() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRewardDefinition.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CCB1 RID: 52401 RVA: 0x0032E914 File Offset: 0x0032CB14
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryRewardDefinition()
		{
			Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryRewardDefinition");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr);
			MercenaryRewardDefinition.NativeFieldInfoPtr_Flags = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Flags");
			MercenaryRewardDefinition.NativeFieldInfoPtr_Weapons = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Weapons");
			MercenaryRewardDefinition.NativeFieldInfoPtr_Attachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Attachments");
			MercenaryRewardDefinition.NativeFieldInfoPtr_Equipments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Equipments");
			MercenaryRewardDefinition.NativeFieldInfoPtr_Category = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Category");
			MercenaryRewardDefinition.NativeFieldInfoPtr_Identifier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, "Identifier");
			MercenaryRewardDefinition.NativeMethodInfoPtr_AddToReward_Public_Void_RandomWrapper_byref_MercenaryReward_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, 100679086);
			MercenaryRewardDefinition.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr, 100679087);
		}

		// Token: 0x0600CCB2 RID: 52402 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryRewardDefinition(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A85 RID: 19077
		// (get) Token: 0x0600CCB3 RID: 52403 RVA: 0x0032E9E4 File Offset: 0x0032CBE4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryRewardDefinition>.NativeClassPtr));
			}
		}

		// Token: 0x17004A86 RID: 19078
		// (get) Token: 0x0600CCB4 RID: 52404 RVA: 0x0032E9F8 File Offset: 0x0032CBF8
		// (set) Token: 0x0600CCB5 RID: 52405 RVA: 0x0032EA20 File Offset: 0x0032CC20
		public unsafe MercenaryRewardFlags Flags
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Flags);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Flags)) = value;
			}
		}

		// Token: 0x17004A87 RID: 19079
		// (get) Token: 0x0600CCB6 RID: 52406 RVA: 0x0032EA44 File Offset: 0x0032CC44
		// (set) Token: 0x0600CCB7 RID: 52407 RVA: 0x0032EA78 File Offset: 0x0032CC78
		public unsafe Il2CppStructArray<WeaponName> Weapons
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Weapons);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<WeaponName>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Weapons), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A88 RID: 19080
		// (get) Token: 0x0600CCB8 RID: 52408 RVA: 0x0032EAA0 File Offset: 0x0032CCA0
		// (set) Token: 0x0600CCB9 RID: 52409 RVA: 0x0032EAD4 File Offset: 0x0032CCD4
		public unsafe Il2CppStructArray<WeaponAttachment.AttachmentType> Attachments
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Attachments);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<WeaponAttachment.AttachmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Attachments), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A89 RID: 19081
		// (get) Token: 0x0600CCBA RID: 52410 RVA: 0x0032EAFC File Offset: 0x0032CCFC
		// (set) Token: 0x0600CCBB RID: 52411 RVA: 0x0032EB30 File Offset: 0x0032CD30
		public unsafe Il2CppStructArray<ClassLoadout.EquipmentType> Equipments
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Equipments);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<ClassLoadout.EquipmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Equipments), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A8A RID: 19082
		// (get) Token: 0x0600CCBC RID: 52412 RVA: 0x0032EB58 File Offset: 0x0032CD58
		// (set) Token: 0x0600CCBD RID: 52413 RVA: 0x0032EB80 File Offset: 0x0032CD80
		public unsafe MercenaryRewardFlags Category
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Category);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Category)) = value;
			}
		}

		// Token: 0x17004A8B RID: 19083
		// (get) Token: 0x0600CCBE RID: 52414 RVA: 0x0032EBA4 File Offset: 0x0032CDA4
		// (set) Token: 0x0600CCBF RID: 52415 RVA: 0x0032EBCC File Offset: 0x0032CDCC
		public unsafe int Identifier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Identifier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRewardDefinition.NativeFieldInfoPtr_Identifier)) = value;
			}
		}

		// Token: 0x0400816F RID: 33135
		private static readonly IntPtr NativeFieldInfoPtr_Flags;

		// Token: 0x04008170 RID: 33136
		private static readonly IntPtr NativeFieldInfoPtr_Weapons;

		// Token: 0x04008171 RID: 33137
		private static readonly IntPtr NativeFieldInfoPtr_Attachments;

		// Token: 0x04008172 RID: 33138
		private static readonly IntPtr NativeFieldInfoPtr_Equipments;

		// Token: 0x04008173 RID: 33139
		private static readonly IntPtr NativeFieldInfoPtr_Category;

		// Token: 0x04008174 RID: 33140
		private static readonly IntPtr NativeFieldInfoPtr_Identifier;

		// Token: 0x04008175 RID: 33141
		private static readonly IntPtr NativeMethodInfoPtr_AddToReward_Public_Void_RandomWrapper_byref_MercenaryReward_0;

		// Token: 0x04008176 RID: 33142
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
