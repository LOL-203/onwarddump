﻿using System;
using Il2CppSystem;
using Onward.AI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200097E RID: 2430
	[Serializable]
	public class DifficultySettingsRef : Object
	{
		// Token: 0x0600CD74 RID: 52596 RVA: 0x00331068 File Offset: 0x0032F268
		[CallerCount(0)]
		public unsafe DifficultySettingsRef() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DifficultySettingsRef.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD75 RID: 52597 RVA: 0x003310B4 File Offset: 0x0032F2B4
		// Note: this type is marked as 'beforefieldinit'.
		static DifficultySettingsRef()
		{
			Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "DifficultySettingsRef");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr);
			DifficultySettingsRef.NativeFieldInfoPtr_Settings = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr, "Settings");
			DifficultySettingsRef.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr, 100679106);
		}

		// Token: 0x0600CD76 RID: 52598 RVA: 0x00002988 File Offset: 0x00000B88
		public DifficultySettingsRef(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004ADB RID: 19163
		// (get) Token: 0x0600CD77 RID: 52599 RVA: 0x0033110C File Offset: 0x0032F30C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DifficultySettingsRef>.NativeClassPtr));
			}
		}

		// Token: 0x17004ADC RID: 19164
		// (get) Token: 0x0600CD78 RID: 52600 RVA: 0x00331120 File Offset: 0x0032F320
		// (set) Token: 0x0600CD79 RID: 52601 RVA: 0x00331154 File Offset: 0x0032F354
		public unsafe DifficultySettings Settings
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DifficultySettingsRef.NativeFieldInfoPtr_Settings);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DifficultySettings(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DifficultySettingsRef.NativeFieldInfoPtr_Settings), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040081E7 RID: 33255
		private static readonly IntPtr NativeFieldInfoPtr_Settings;

		// Token: 0x040081E8 RID: 33256
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
