﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000965 RID: 2405
	[Serializable]
	public class MercenaryAttachmentList : Object
	{
		// Token: 0x0600CC35 RID: 52277 RVA: 0x0032CCD8 File Offset: 0x0032AED8
		[CallerCount(0)]
		public unsafe WeaponAttachment.AttachmentType GetRandomInList(Random random)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryAttachmentList.NativeMethodInfoPtr_GetRandomInList_Public_AttachmentType_Random_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CC36 RID: 52278 RVA: 0x0032CD40 File Offset: 0x0032AF40
		[CallerCount(0)]
		public unsafe MercenaryAttachmentList() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryAttachmentList.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC37 RID: 52279 RVA: 0x0032CD8C File Offset: 0x0032AF8C
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryAttachmentList()
		{
			Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryAttachmentList");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr);
			MercenaryAttachmentList.NativeFieldInfoPtr_Attachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr, "Attachments");
			MercenaryAttachmentList.NativeMethodInfoPtr_GetRandomInList_Public_AttachmentType_Random_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr, 100679053);
			MercenaryAttachmentList.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr, 100679054);
		}

		// Token: 0x0600CC38 RID: 52280 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryAttachmentList(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A5D RID: 19037
		// (get) Token: 0x0600CC39 RID: 52281 RVA: 0x0032CDF8 File Offset: 0x0032AFF8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryAttachmentList>.NativeClassPtr));
			}
		}

		// Token: 0x17004A5E RID: 19038
		// (get) Token: 0x0600CC3A RID: 52282 RVA: 0x0032CE0C File Offset: 0x0032B00C
		// (set) Token: 0x0600CC3B RID: 52283 RVA: 0x0032CE40 File Offset: 0x0032B040
		public unsafe List<WeaponAttachment.AttachmentType> Attachments
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryAttachmentList.NativeFieldInfoPtr_Attachments);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryAttachmentList.NativeFieldInfoPtr_Attachments), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008115 RID: 33045
		private static readonly IntPtr NativeFieldInfoPtr_Attachments;

		// Token: 0x04008116 RID: 33046
		private static readonly IntPtr NativeMethodInfoPtr_GetRandomInList_Public_AttachmentType_Random_0;

		// Token: 0x04008117 RID: 33047
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
