﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200097D RID: 2429
	public class MercenaryTier : ScriptableObject
	{
		// Token: 0x0600CD5E RID: 52574 RVA: 0x00330C34 File Offset: 0x0032EE34
		[CallerCount(0)]
		public unsafe MercenaryTier() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryTier.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD5F RID: 52575 RVA: 0x00330C80 File Offset: 0x0032EE80
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryTier()
		{
			Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryTier");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr);
			MercenaryTier.NativeFieldInfoPtr_TierIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "TierIndex");
			MercenaryTier.NativeFieldInfoPtr_MinRoundForTier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "MinRoundForTier");
			MercenaryTier.NativeFieldInfoPtr_MaxRoundForTier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "MaxRoundForTier");
			MercenaryTier.NativeFieldInfoPtr_StandardOnly = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "StandardOnly");
			MercenaryTier.NativeFieldInfoPtr_EndlessOnly = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "EndlessOnly");
			MercenaryTier.NativeFieldInfoPtr_Difficulties = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "Difficulties");
			MercenaryTier.NativeFieldInfoPtr_Objectives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "Objectives");
			MercenaryTier.NativeFieldInfoPtr_UsesAnyMap = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "UsesAnyMap");
			MercenaryTier.NativeFieldInfoPtr_Rewards = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, "Rewards");
			MercenaryTier.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr, 100679105);
		}

		// Token: 0x0600CD60 RID: 52576 RVA: 0x0002DD3C File Offset: 0x0002BF3C
		public MercenaryTier(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004AD1 RID: 19153
		// (get) Token: 0x0600CD61 RID: 52577 RVA: 0x00330D78 File Offset: 0x0032EF78
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryTier>.NativeClassPtr));
			}
		}

		// Token: 0x17004AD2 RID: 19154
		// (get) Token: 0x0600CD62 RID: 52578 RVA: 0x00330D8C File Offset: 0x0032EF8C
		// (set) Token: 0x0600CD63 RID: 52579 RVA: 0x00330DB4 File Offset: 0x0032EFB4
		public unsafe int TierIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_TierIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_TierIndex)) = value;
			}
		}

		// Token: 0x17004AD3 RID: 19155
		// (get) Token: 0x0600CD64 RID: 52580 RVA: 0x00330DD8 File Offset: 0x0032EFD8
		// (set) Token: 0x0600CD65 RID: 52581 RVA: 0x00330E00 File Offset: 0x0032F000
		public unsafe int MinRoundForTier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_MinRoundForTier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_MinRoundForTier)) = value;
			}
		}

		// Token: 0x17004AD4 RID: 19156
		// (get) Token: 0x0600CD66 RID: 52582 RVA: 0x00330E24 File Offset: 0x0032F024
		// (set) Token: 0x0600CD67 RID: 52583 RVA: 0x00330E4C File Offset: 0x0032F04C
		public unsafe int MaxRoundForTier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_MaxRoundForTier);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_MaxRoundForTier)) = value;
			}
		}

		// Token: 0x17004AD5 RID: 19157
		// (get) Token: 0x0600CD68 RID: 52584 RVA: 0x00330E70 File Offset: 0x0032F070
		// (set) Token: 0x0600CD69 RID: 52585 RVA: 0x00330E98 File Offset: 0x0032F098
		public unsafe bool StandardOnly
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_StandardOnly);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_StandardOnly)) = value;
			}
		}

		// Token: 0x17004AD6 RID: 19158
		// (get) Token: 0x0600CD6A RID: 52586 RVA: 0x00330EBC File Offset: 0x0032F0BC
		// (set) Token: 0x0600CD6B RID: 52587 RVA: 0x00330EE4 File Offset: 0x0032F0E4
		public unsafe bool EndlessOnly
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_EndlessOnly);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_EndlessOnly)) = value;
			}
		}

		// Token: 0x17004AD7 RID: 19159
		// (get) Token: 0x0600CD6C RID: 52588 RVA: 0x00330F08 File Offset: 0x0032F108
		// (set) Token: 0x0600CD6D RID: 52589 RVA: 0x00330F3C File Offset: 0x0032F13C
		public unsafe List<DifficultySettingsRef> Difficulties
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Difficulties);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<DifficultySettingsRef>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Difficulties), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AD8 RID: 19160
		// (get) Token: 0x0600CD6E RID: 52590 RVA: 0x00330F64 File Offset: 0x0032F164
		// (set) Token: 0x0600CD6F RID: 52591 RVA: 0x00330F98 File Offset: 0x0032F198
		public unsafe List<MercenaryObjectives> Objectives
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Objectives);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<MercenaryObjectives>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Objectives), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AD9 RID: 19161
		// (get) Token: 0x0600CD70 RID: 52592 RVA: 0x00330FC0 File Offset: 0x0032F1C0
		// (set) Token: 0x0600CD71 RID: 52593 RVA: 0x00330FE8 File Offset: 0x0032F1E8
		public unsafe bool UsesAnyMap
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_UsesAnyMap);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_UsesAnyMap)) = value;
			}
		}

		// Token: 0x17004ADA RID: 19162
		// (get) Token: 0x0600CD72 RID: 52594 RVA: 0x0033100C File Offset: 0x0032F20C
		// (set) Token: 0x0600CD73 RID: 52595 RVA: 0x00331040 File Offset: 0x0032F240
		public unsafe MercenaryTierRewards Rewards
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Rewards);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryTierRewards(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryTier.NativeFieldInfoPtr_Rewards), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040081DD RID: 33245
		private static readonly IntPtr NativeFieldInfoPtr_TierIndex;

		// Token: 0x040081DE RID: 33246
		private static readonly IntPtr NativeFieldInfoPtr_MinRoundForTier;

		// Token: 0x040081DF RID: 33247
		private static readonly IntPtr NativeFieldInfoPtr_MaxRoundForTier;

		// Token: 0x040081E0 RID: 33248
		private static readonly IntPtr NativeFieldInfoPtr_StandardOnly;

		// Token: 0x040081E1 RID: 33249
		private static readonly IntPtr NativeFieldInfoPtr_EndlessOnly;

		// Token: 0x040081E2 RID: 33250
		private static readonly IntPtr NativeFieldInfoPtr_Difficulties;

		// Token: 0x040081E3 RID: 33251
		private static readonly IntPtr NativeFieldInfoPtr_Objectives;

		// Token: 0x040081E4 RID: 33252
		private static readonly IntPtr NativeFieldInfoPtr_UsesAnyMap;

		// Token: 0x040081E5 RID: 33253
		private static readonly IntPtr NativeFieldInfoPtr_Rewards;

		// Token: 0x040081E6 RID: 33254
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
