﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000967 RID: 2407
	public enum MercenaryChallengeLevel
	{
		// Token: 0x0400811E RID: 33054
		Easiest,
		// Token: 0x0400811F RID: 33055
		Easier,
		// Token: 0x04008120 RID: 33056
		Easy,
		// Token: 0x04008121 RID: 33057
		Normal,
		// Token: 0x04008122 RID: 33058
		Hard,
		// Token: 0x04008123 RID: 33059
		Harder,
		// Token: 0x04008124 RID: 33060
		Hardest
	}
}
