﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200097A RID: 2426
	public enum MercenaryRoundType
	{
		// Token: 0x040081C9 RID: 33225
		Unknown,
		// Token: 0x040081CA RID: 33226
		Hideout,
		// Token: 0x040081CB RID: 33227
		MidRun,
		// Token: 0x040081CC RID: 33228
		FinalRound,
		// Token: 0x040081CD RID: 33229
		EndlessRound
	}
}
