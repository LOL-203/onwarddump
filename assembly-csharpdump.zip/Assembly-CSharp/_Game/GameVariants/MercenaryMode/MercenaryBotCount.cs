﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000966 RID: 2406
	[Serializable]
	public class MercenaryBotCount : Il2CppSystem.Object
	{
		// Token: 0x0600CC3C RID: 52284 RVA: 0x0032CE68 File Offset: 0x0032B068
		[CallerCount(0)]
		public unsafe MercenaryBotCount() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryBotCount.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC3D RID: 52285 RVA: 0x0032CEB4 File Offset: 0x0032B0B4
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryBotCount()
		{
			Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryBotCount");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr);
			MercenaryBotCount.NativeFieldInfoPtr_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr, "Type");
			MercenaryBotCount.NativeFieldInfoPtr_StartingBotCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr, "StartingBotCount");
			MercenaryBotCount.NativeFieldInfoPtr_EndingBotCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr, "EndingBotCount");
			MercenaryBotCount.NativeFieldInfoPtr_VarianceCurve = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr, "VarianceCurve");
			MercenaryBotCount.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr, 100679055);
		}

		// Token: 0x0600CC3E RID: 52286 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryBotCount(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A5F RID: 19039
		// (get) Token: 0x0600CC3F RID: 52287 RVA: 0x0032CF48 File Offset: 0x0032B148
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryBotCount>.NativeClassPtr));
			}
		}

		// Token: 0x17004A60 RID: 19040
		// (get) Token: 0x0600CC40 RID: 52288 RVA: 0x0032CF5C File Offset: 0x0032B15C
		// (set) Token: 0x0600CC41 RID: 52289 RVA: 0x0032CF84 File Offset: 0x0032B184
		public unsafe MercenaryOperationScale Type
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_Type);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_Type)) = value;
			}
		}

		// Token: 0x17004A61 RID: 19041
		// (get) Token: 0x0600CC42 RID: 52290 RVA: 0x0032CFA8 File Offset: 0x0032B1A8
		// (set) Token: 0x0600CC43 RID: 52291 RVA: 0x0032CFD0 File Offset: 0x0032B1D0
		public unsafe int StartingBotCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_StartingBotCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_StartingBotCount)) = value;
			}
		}

		// Token: 0x17004A62 RID: 19042
		// (get) Token: 0x0600CC44 RID: 52292 RVA: 0x0032CFF4 File Offset: 0x0032B1F4
		// (set) Token: 0x0600CC45 RID: 52293 RVA: 0x0032D01C File Offset: 0x0032B21C
		public unsafe int EndingBotCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_EndingBotCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_EndingBotCount)) = value;
			}
		}

		// Token: 0x17004A63 RID: 19043
		// (get) Token: 0x0600CC46 RID: 52294 RVA: 0x0032D040 File Offset: 0x0032B240
		// (set) Token: 0x0600CC47 RID: 52295 RVA: 0x0032D074 File Offset: 0x0032B274
		public unsafe AnimationCurve VarianceCurve
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_VarianceCurve);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AnimationCurve(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryBotCount.NativeFieldInfoPtr_VarianceCurve), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008118 RID: 33048
		private static readonly IntPtr NativeFieldInfoPtr_Type;

		// Token: 0x04008119 RID: 33049
		private static readonly IntPtr NativeFieldInfoPtr_StartingBotCount;

		// Token: 0x0400811A RID: 33050
		private static readonly IntPtr NativeFieldInfoPtr_EndingBotCount;

		// Token: 0x0400811B RID: 33051
		private static readonly IntPtr NativeFieldInfoPtr_VarianceCurve;

		// Token: 0x0400811C RID: 33052
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
