﻿using System;
using System.Runtime.InteropServices;
using DPI;
using Il2CppSystem;
using Onward.AI;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000976 RID: 2422
	[StructLayout(0)]
	public sealed class MercenaryRound : ValueType
	{
		// Token: 0x17004A9C RID: 19100
		// (get) Token: 0x0600CCC2 RID: 52418 RVA: 0x0032EC1C File Offset: 0x0032CE1C
		public unsafe int DifficultyScore
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryRound.NativeMethodInfoPtr_get_DifficultyScore_Public_get_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A9D RID: 19101
		// (get) Token: 0x0600CCC3 RID: 52419 RVA: 0x0032EC6C File Offset: 0x0032CE6C
		// (set) Token: 0x0600CCC4 RID: 52420 RVA: 0x0032ECBC File Offset: 0x0032CEBC
		public unsafe int EnemyCount
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryRound.NativeMethodInfoPtr_get_EnemyCount_Public_get_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRound.NativeMethodInfoPtr_set_EnemyCount_Private_set_Void_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600CCC5 RID: 52421 RVA: 0x0032ED10 File Offset: 0x0032CF10
		[CallerCount(0)]
		public unsafe void InitializeInRoundSeed(MercenaryVariant variant)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(variant);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRound.NativeMethodInfoPtr_InitializeInRoundSeed_Public_Void_MercenaryVariant_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CCC6 RID: 52422 RVA: 0x0032ED68 File Offset: 0x0032CF68
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryRound()
		{
			Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryRound");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr);
			MercenaryRound.NativeFieldInfoPtr_Tier = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "Tier");
			MercenaryRound.NativeFieldInfoPtr_Difficulty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "Difficulty");
			MercenaryRound.NativeFieldInfoPtr_ObjectiveType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "ObjectiveType");
			MercenaryRound.NativeFieldInfoPtr_Map = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "Map");
			MercenaryRound.NativeFieldInfoPtr_WeaponRewardShared = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "WeaponRewardShared");
			MercenaryRound.NativeFieldInfoPtr_UtilityRewardShared = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "UtilityRewardShared");
			MercenaryRound.NativeFieldInfoPtr_MissionState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "MissionState");
			MercenaryRound.NativeFieldInfoPtr_RewardCollected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "RewardCollected");
			MercenaryRound.NativeFieldInfoPtr_GenerationSeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "GenerationSeed");
			MercenaryRound.NativeFieldInfoPtr_GenerationIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "GenerationIndex");
			MercenaryRound.NativeFieldInfoPtr_InRoundSeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "InRoundSeed");
			MercenaryRound.NativeFieldInfoPtr_TierNormalized = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "TierNormalized");
			MercenaryRound.NativeFieldInfoPtr__random = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "_random");
			MercenaryRound.NativeFieldInfoPtr__EnemyCount_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, "<EnemyCount>k__BackingField");
			MercenaryRound.NativeMethodInfoPtr_get_DifficultyScore_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, 100679088);
			MercenaryRound.NativeMethodInfoPtr_get_EnemyCount_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, 100679089);
			MercenaryRound.NativeMethodInfoPtr_set_EnemyCount_Private_set_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, 100679090);
			MercenaryRound.NativeMethodInfoPtr_InitializeInRoundSeed_Public_Void_MercenaryVariant_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, 100679091);
		}

		// Token: 0x0600CCC7 RID: 52423 RVA: 0x0002717B File Offset: 0x0002537B
		public MercenaryRound(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A8D RID: 19085
		// (get) Token: 0x0600CCC8 RID: 52424 RVA: 0x0032EF00 File Offset: 0x0032D100
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr));
			}
		}

		// Token: 0x0600CCC9 RID: 52425 RVA: 0x0032EF14 File Offset: 0x0032D114
		public unsafe MercenaryRound()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, data));
		}

		// Token: 0x17004A8E RID: 19086
		// (get) Token: 0x0600CCCA RID: 52426 RVA: 0x0032EF44 File Offset: 0x0032D144
		// (set) Token: 0x0600CCCB RID: 52427 RVA: 0x0032EF78 File Offset: 0x0032D178
		public unsafe MercenaryTier Tier
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Tier);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryTier(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Tier), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A8F RID: 19087
		// (get) Token: 0x0600CCCC RID: 52428 RVA: 0x0032EFA0 File Offset: 0x0032D1A0
		// (set) Token: 0x0600CCCD RID: 52429 RVA: 0x0032EFD4 File Offset: 0x0032D1D4
		public unsafe DifficultySettings Difficulty
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Difficulty);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DifficultySettings(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Difficulty), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A90 RID: 19088
		// (get) Token: 0x0600CCCE RID: 52430 RVA: 0x0032EFFC File Offset: 0x0032D1FC
		// (set) Token: 0x0600CCCF RID: 52431 RVA: 0x0032F024 File Offset: 0x0032D224
		public unsafe MercenaryObjectives ObjectiveType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_ObjectiveType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_ObjectiveType)) = value;
			}
		}

		// Token: 0x17004A91 RID: 19089
		// (get) Token: 0x0600CCD0 RID: 52432 RVA: 0x0032F048 File Offset: 0x0032D248
		// (set) Token: 0x0600CCD1 RID: 52433 RVA: 0x0032F070 File Offset: 0x0032D270
		public unsafe OnwardMap Map
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Map);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_Map)) = value;
			}
		}

		// Token: 0x17004A92 RID: 19090
		// (get) Token: 0x0600CCD2 RID: 52434 RVA: 0x0032F094 File Offset: 0x0032D294
		// (set) Token: 0x0600CCD3 RID: 52435 RVA: 0x0032F0BC File Offset: 0x0032D2BC
		public unsafe MercenaryReward WeaponRewardShared
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_WeaponRewardShared);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_WeaponRewardShared)) = value;
			}
		}

		// Token: 0x17004A93 RID: 19091
		// (get) Token: 0x0600CCD4 RID: 52436 RVA: 0x0032F0E0 File Offset: 0x0032D2E0
		// (set) Token: 0x0600CCD5 RID: 52437 RVA: 0x0032F108 File Offset: 0x0032D308
		public unsafe MercenaryReward UtilityRewardShared
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_UtilityRewardShared);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_UtilityRewardShared)) = value;
			}
		}

		// Token: 0x17004A94 RID: 19092
		// (get) Token: 0x0600CCD6 RID: 52438 RVA: 0x0032F12C File Offset: 0x0032D32C
		// (set) Token: 0x0600CCD7 RID: 52439 RVA: 0x0032F154 File Offset: 0x0032D354
		public unsafe MercenaryMissionState MissionState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_MissionState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_MissionState)) = value;
			}
		}

		// Token: 0x17004A95 RID: 19093
		// (get) Token: 0x0600CCD8 RID: 52440 RVA: 0x0032F178 File Offset: 0x0032D378
		// (set) Token: 0x0600CCD9 RID: 52441 RVA: 0x0032F1A0 File Offset: 0x0032D3A0
		public unsafe bool RewardCollected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_RewardCollected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_RewardCollected)) = value;
			}
		}

		// Token: 0x17004A96 RID: 19094
		// (get) Token: 0x0600CCDA RID: 52442 RVA: 0x0032F1C4 File Offset: 0x0032D3C4
		// (set) Token: 0x0600CCDB RID: 52443 RVA: 0x0032F1EC File Offset: 0x0032D3EC
		public unsafe int GenerationSeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_GenerationSeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_GenerationSeed)) = value;
			}
		}

		// Token: 0x17004A97 RID: 19095
		// (get) Token: 0x0600CCDC RID: 52444 RVA: 0x0032F210 File Offset: 0x0032D410
		// (set) Token: 0x0600CCDD RID: 52445 RVA: 0x0032F238 File Offset: 0x0032D438
		public unsafe int GenerationIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_GenerationIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_GenerationIndex)) = value;
			}
		}

		// Token: 0x17004A98 RID: 19096
		// (get) Token: 0x0600CCDE RID: 52446 RVA: 0x0032F25C File Offset: 0x0032D45C
		// (set) Token: 0x0600CCDF RID: 52447 RVA: 0x0032F284 File Offset: 0x0032D484
		public unsafe int InRoundSeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_InRoundSeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_InRoundSeed)) = value;
			}
		}

		// Token: 0x17004A99 RID: 19097
		// (get) Token: 0x0600CCE0 RID: 52448 RVA: 0x0032F2A8 File Offset: 0x0032D4A8
		// (set) Token: 0x0600CCE1 RID: 52449 RVA: 0x0032F2D0 File Offset: 0x0032D4D0
		public unsafe float TierNormalized
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_TierNormalized);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr_TierNormalized)) = value;
			}
		}

		// Token: 0x17004A9A RID: 19098
		// (get) Token: 0x0600CCE2 RID: 52450 RVA: 0x0032F2F4 File Offset: 0x0032D4F4
		// (set) Token: 0x0600CCE3 RID: 52451 RVA: 0x0032F328 File Offset: 0x0032D528
		public unsafe RandomWrapper _random
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr__random);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new RandomWrapper(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr__random), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A9B RID: 19099
		// (get) Token: 0x0600CCE4 RID: 52452 RVA: 0x0032F350 File Offset: 0x0032D550
		// (set) Token: 0x0600CCE5 RID: 52453 RVA: 0x0032F378 File Offset: 0x0032D578
		public unsafe int _EnemyCount_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr__EnemyCount_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRound.NativeFieldInfoPtr__EnemyCount_k__BackingField)) = value;
			}
		}

		// Token: 0x04008186 RID: 33158
		private static readonly IntPtr NativeFieldInfoPtr_Tier;

		// Token: 0x04008187 RID: 33159
		private static readonly IntPtr NativeFieldInfoPtr_Difficulty;

		// Token: 0x04008188 RID: 33160
		private static readonly IntPtr NativeFieldInfoPtr_ObjectiveType;

		// Token: 0x04008189 RID: 33161
		private static readonly IntPtr NativeFieldInfoPtr_Map;

		// Token: 0x0400818A RID: 33162
		private static readonly IntPtr NativeFieldInfoPtr_WeaponRewardShared;

		// Token: 0x0400818B RID: 33163
		private static readonly IntPtr NativeFieldInfoPtr_UtilityRewardShared;

		// Token: 0x0400818C RID: 33164
		private static readonly IntPtr NativeFieldInfoPtr_MissionState;

		// Token: 0x0400818D RID: 33165
		private static readonly IntPtr NativeFieldInfoPtr_RewardCollected;

		// Token: 0x0400818E RID: 33166
		private static readonly IntPtr NativeFieldInfoPtr_GenerationSeed;

		// Token: 0x0400818F RID: 33167
		private static readonly IntPtr NativeFieldInfoPtr_GenerationIndex;

		// Token: 0x04008190 RID: 33168
		private static readonly IntPtr NativeFieldInfoPtr_InRoundSeed;

		// Token: 0x04008191 RID: 33169
		private static readonly IntPtr NativeFieldInfoPtr_TierNormalized;

		// Token: 0x04008192 RID: 33170
		private static readonly IntPtr NativeFieldInfoPtr__random;

		// Token: 0x04008193 RID: 33171
		private static readonly IntPtr NativeFieldInfoPtr__EnemyCount_k__BackingField;

		// Token: 0x04008194 RID: 33172
		private static readonly IntPtr NativeMethodInfoPtr_get_DifficultyScore_Public_get_Int32_0;

		// Token: 0x04008195 RID: 33173
		private static readonly IntPtr NativeMethodInfoPtr_get_EnemyCount_Public_get_Int32_0;

		// Token: 0x04008196 RID: 33174
		private static readonly IntPtr NativeMethodInfoPtr_set_EnemyCount_Private_set_Void_Int32_0;

		// Token: 0x04008197 RID: 33175
		private static readonly IntPtr NativeMethodInfoPtr_InitializeInRoundSeed_Public_Void_MercenaryVariant_0;
	}
}
