﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000973 RID: 2419
	[StructLayout(2)]
	public struct MercenaryReward
	{
		// Token: 0x0600CCA2 RID: 52386 RVA: 0x0032E4DC File Offset: 0x0032C6DC
		[CallerCount(0)]
		public unsafe string GetWeaponNameAndType()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetWeaponNameAndType_Public_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCA3 RID: 52387 RVA: 0x0032E518 File Offset: 0x0032C718
		[CallerCount(0)]
		public unsafe string GetWeaponRewardText()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetWeaponRewardText_Public_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCA4 RID: 52388 RVA: 0x0032E554 File Offset: 0x0032C754
		[CallerCount(0)]
		public unsafe string GetUtilityRewardText()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetUtilityRewardText_Public_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCA5 RID: 52389 RVA: 0x0032E590 File Offset: 0x0032C790
		[CallerCount(0)]
		public unsafe string GetSurplusRewardText()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetSurplusRewardText_Public_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCA6 RID: 52390 RVA: 0x0032E5CC File Offset: 0x0032C7CC
		[CallerCount(0)]
		public unsafe string GetCompatibilityTooltip(MercenaryVariant variant)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(variant);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetCompatibilityTooltip_Public_String_MercenaryVariant_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CCA7 RID: 52391 RVA: 0x0032E620 File Offset: 0x0032C820
		[CallerCount(0)]
		public unsafe ClassLoadout.WeaponPointObject GetWeaponDefinition(MercenaryVariant variant, WeaponName weapon, bool isPrimary)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(variant);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref weapon;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isPrimary;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryReward.NativeMethodInfoPtr_GetWeaponDefinition_Private_WeaponPointObject_MercenaryVariant_WeaponName_Boolean_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new ClassLoadout.WeaponPointObject(intPtr2) : null;
		}

		// Token: 0x0600CCA8 RID: 52392 RVA: 0x0032E6A4 File Offset: 0x0032C8A4
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryReward()
		{
			Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryReward");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr);
			MercenaryReward.NativeFieldInfoPtr_Flags = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "Flags");
			MercenaryReward.NativeFieldInfoPtr_PrimaryString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "PrimaryString");
			MercenaryReward.NativeFieldInfoPtr_SecondaryString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "SecondaryString");
			MercenaryReward.NativeFieldInfoPtr_Weapon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "Weapon");
			MercenaryReward.NativeFieldInfoPtr_Attachment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "Attachment");
			MercenaryReward.NativeFieldInfoPtr_Equipment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, "Equipment");
			MercenaryReward.NativeMethodInfoPtr_GetWeaponNameAndType_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679080);
			MercenaryReward.NativeMethodInfoPtr_GetWeaponRewardText_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679081);
			MercenaryReward.NativeMethodInfoPtr_GetUtilityRewardText_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679082);
			MercenaryReward.NativeMethodInfoPtr_GetSurplusRewardText_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679083);
			MercenaryReward.NativeMethodInfoPtr_GetCompatibilityTooltip_Public_String_MercenaryVariant_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679084);
			MercenaryReward.NativeMethodInfoPtr_GetWeaponDefinition_Private_WeaponPointObject_MercenaryVariant_WeaponName_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, 100679085);
		}

		// Token: 0x0600CCA9 RID: 52393 RVA: 0x0032E7C4 File Offset: 0x0032C9C4
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr, ref this));
		}

		// Token: 0x17004A82 RID: 19074
		// (get) Token: 0x0600CCAA RID: 52394 RVA: 0x0032E7D6 File Offset: 0x0032C9D6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryReward>.NativeClassPtr));
			}
		}

		// Token: 0x17004A83 RID: 19075
		// (get) Token: 0x0600CCAB RID: 52395 RVA: 0x0032E7E8 File Offset: 0x0032C9E8
		// (set) Token: 0x0600CCAC RID: 52396 RVA: 0x0032E808 File Offset: 0x0032CA08
		public unsafe static string PrimaryString
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(MercenaryReward.NativeFieldInfoPtr_PrimaryString, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryReward.NativeFieldInfoPtr_PrimaryString, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004A84 RID: 19076
		// (get) Token: 0x0600CCAD RID: 52397 RVA: 0x0032E820 File Offset: 0x0032CA20
		// (set) Token: 0x0600CCAE RID: 52398 RVA: 0x0032E840 File Offset: 0x0032CA40
		public unsafe static string SecondaryString
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(MercenaryReward.NativeFieldInfoPtr_SecondaryString, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryReward.NativeFieldInfoPtr_SecondaryString, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400815F RID: 33119
		private static readonly IntPtr NativeFieldInfoPtr_Flags;

		// Token: 0x04008160 RID: 33120
		private static readonly IntPtr NativeFieldInfoPtr_PrimaryString;

		// Token: 0x04008161 RID: 33121
		private static readonly IntPtr NativeFieldInfoPtr_SecondaryString;

		// Token: 0x04008162 RID: 33122
		private static readonly IntPtr NativeFieldInfoPtr_Weapon;

		// Token: 0x04008163 RID: 33123
		private static readonly IntPtr NativeFieldInfoPtr_Attachment;

		// Token: 0x04008164 RID: 33124
		private static readonly IntPtr NativeFieldInfoPtr_Equipment;

		// Token: 0x04008165 RID: 33125
		private static readonly IntPtr NativeMethodInfoPtr_GetWeaponNameAndType_Public_String_0;

		// Token: 0x04008166 RID: 33126
		private static readonly IntPtr NativeMethodInfoPtr_GetWeaponRewardText_Public_String_0;

		// Token: 0x04008167 RID: 33127
		private static readonly IntPtr NativeMethodInfoPtr_GetUtilityRewardText_Public_String_0;

		// Token: 0x04008168 RID: 33128
		private static readonly IntPtr NativeMethodInfoPtr_GetSurplusRewardText_Public_String_0;

		// Token: 0x04008169 RID: 33129
		private static readonly IntPtr NativeMethodInfoPtr_GetCompatibilityTooltip_Public_String_MercenaryVariant_0;

		// Token: 0x0400816A RID: 33130
		private static readonly IntPtr NativeMethodInfoPtr_GetWeaponDefinition_Private_WeaponPointObject_MercenaryVariant_WeaponName_Boolean_0;

		// Token: 0x0400816B RID: 33131
		[FieldOffset(0)]
		public MercenaryRewardFlags Flags;

		// Token: 0x0400816C RID: 33132
		[FieldOffset(4)]
		public WeaponName Weapon;

		// Token: 0x0400816D RID: 33133
		[FieldOffset(8)]
		public WeaponAttachment.AttachmentType Attachment;

		// Token: 0x0400816E RID: 33134
		[FieldOffset(12)]
		public ClassLoadout.EquipmentType Equipment;
	}
}
