﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200096E RID: 2414
	[Serializable]
	public class MercenaryMapWeight : Object
	{
		// Token: 0x0600CC8E RID: 52366 RVA: 0x0032E1E0 File Offset: 0x0032C3E0
		[CallerCount(0)]
		public unsafe MercenaryMapWeight() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryMapWeight.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC8F RID: 52367 RVA: 0x0032E22C File Offset: 0x0032C42C
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryMapWeight()
		{
			Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryMapWeight");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr);
			MercenaryMapWeight.NativeFieldInfoPtr_TierDelta = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr, "TierDelta");
			MercenaryMapWeight.NativeFieldInfoPtr_Weight = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr, "Weight");
			MercenaryMapWeight.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr, 100679078);
		}

		// Token: 0x0600CC90 RID: 52368 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryMapWeight(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A7A RID: 19066
		// (get) Token: 0x0600CC91 RID: 52369 RVA: 0x0032E298 File Offset: 0x0032C498
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryMapWeight>.NativeClassPtr));
			}
		}

		// Token: 0x17004A7B RID: 19067
		// (get) Token: 0x0600CC92 RID: 52370 RVA: 0x0032E2AC File Offset: 0x0032C4AC
		// (set) Token: 0x0600CC93 RID: 52371 RVA: 0x0032E2D4 File Offset: 0x0032C4D4
		public unsafe int TierDelta
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMapWeight.NativeFieldInfoPtr_TierDelta);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMapWeight.NativeFieldInfoPtr_TierDelta)) = value;
			}
		}

		// Token: 0x17004A7C RID: 19068
		// (get) Token: 0x0600CC94 RID: 52372 RVA: 0x0032E2F8 File Offset: 0x0032C4F8
		// (set) Token: 0x0600CC95 RID: 52373 RVA: 0x0032E320 File Offset: 0x0032C520
		public unsafe float Weight
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMapWeight.NativeFieldInfoPtr_Weight);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMapWeight.NativeFieldInfoPtr_Weight)) = value;
			}
		}

		// Token: 0x0400814A RID: 33098
		private static readonly IntPtr NativeFieldInfoPtr_TierDelta;

		// Token: 0x0400814B RID: 33099
		private static readonly IntPtr NativeFieldInfoPtr_Weight;

		// Token: 0x0400814C RID: 33100
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
