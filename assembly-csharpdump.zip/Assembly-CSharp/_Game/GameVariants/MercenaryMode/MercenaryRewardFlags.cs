﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000975 RID: 2421
	[Flags]
	public enum MercenaryRewardFlags
	{
		// Token: 0x04008178 RID: 33144
		None = 0,
		// Token: 0x04008179 RID: 33145
		Primary = 1,
		// Token: 0x0400817A RID: 33146
		Secondary = 2,
		// Token: 0x0400817B RID: 33147
		Weapon = 4,
		// Token: 0x0400817C RID: 33148
		Magazine = 8,
		// Token: 0x0400817D RID: 33149
		Attachment = 16,
		// Token: 0x0400817E RID: 33150
		Equipment = 32,
		// Token: 0x0400817F RID: 33151
		Ammo = 64,
		// Token: 0x04008180 RID: 33152
		CategoryWeapon = 128,
		// Token: 0x04008181 RID: 33153
		CategoryUtilitySecondary = 256,
		// Token: 0x04008182 RID: 33154
		CategoryUtilityEquipment = 512,
		// Token: 0x04008183 RID: 33155
		CategoryUtilityAttachment = 1024,
		// Token: 0x04008184 RID: 33156
		CategoryUtilityAmmo = 2048,
		// Token: 0x04008185 RID: 33157
		BigUtility = 4096
	}
}
