﻿using System;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000970 RID: 2416
	public enum MercenaryMissionState
	{
		// Token: 0x04008150 RID: 33104
		IN_PROGRESS,
		// Token: 0x04008151 RID: 33105
		SUCCESS,
		// Token: 0x04008152 RID: 33106
		FAILED
	}
}
