﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000979 RID: 2425
	public class MercenaryRoundSnapshotList : Object
	{
		// Token: 0x0600CD2A RID: 52522 RVA: 0x003300B8 File Offset: 0x0032E2B8
		[CallerCount(0)]
		public unsafe MercenaryRoundSnapshotList(int rotatingLength) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref rotatingLength;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD2B RID: 52523 RVA: 0x00330118 File Offset: 0x0032E318
		[CallerCount(0)]
		public unsafe Il2CppStructArray<byte> ToByteArray()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x0600CD2C RID: 52524 RVA: 0x00330170 File Offset: 0x0032E370
		[CallerCount(0)]
		public unsafe void FromByteArray(Il2CppStructArray<byte> data)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(data);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_FromByteArray_Public_Void_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD2D RID: 52525 RVA: 0x003301CC File Offset: 0x0032E3CC
		[CallerCount(0)]
		public unsafe void AddSnapshot(MercenaryRoundSnapshot snapshot)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref snapshot;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_AddSnapshot_Public_Void_MercenaryRoundSnapshot_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD2E RID: 52526 RVA: 0x00330220 File Offset: 0x0032E420
		[CallerCount(0)]
		public unsafe bool TryGetSnapshot(int index, out MercenaryRoundSnapshot snapshot)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref index;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &snapshot;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_TryGetSnapshot_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD2F RID: 52527 RVA: 0x00330298 File Offset: 0x0032E498
		[CallerCount(0)]
		public unsafe bool TryGetSnapshotDelta(int delta, out MercenaryRoundSnapshot snapshot)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref delta;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = &snapshot;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_TryGetSnapshotDelta_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD30 RID: 52528 RVA: 0x00330310 File Offset: 0x0032E510
		[CallerCount(0)]
		public unsafe void Clear()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryRoundSnapshotList.NativeMethodInfoPtr_Clear_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD31 RID: 52529 RVA: 0x00330354 File Offset: 0x0032E554
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryRoundSnapshotList()
		{
			Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryRoundSnapshotList");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr);
			MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshots = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, "_snapshots");
			MercenaryRoundSnapshotList.NativeFieldInfoPtr__rotatingLength = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, "_rotatingLength");
			MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshotCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, "_snapshotCount");
			MercenaryRoundSnapshotList.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679096);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679097);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_FromByteArray_Public_Void_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679098);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_AddSnapshot_Public_Void_MercenaryRoundSnapshot_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679099);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_TryGetSnapshot_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679100);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_TryGetSnapshotDelta_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679101);
			MercenaryRoundSnapshotList.NativeMethodInfoPtr_Clear_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr, 100679102);
		}

		// Token: 0x0600CD32 RID: 52530 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryRoundSnapshotList(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004ABD RID: 19133
		// (get) Token: 0x0600CD33 RID: 52531 RVA: 0x0033044C File Offset: 0x0032E64C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryRoundSnapshotList>.NativeClassPtr));
			}
		}

		// Token: 0x17004ABE RID: 19134
		// (get) Token: 0x0600CD34 RID: 52532 RVA: 0x00330460 File Offset: 0x0032E660
		// (set) Token: 0x0600CD35 RID: 52533 RVA: 0x00330494 File Offset: 0x0032E694
		public unsafe Il2CppStructArray<MercenaryRoundSnapshot> _snapshots
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshots);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<MercenaryRoundSnapshot>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshots), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004ABF RID: 19135
		// (get) Token: 0x0600CD36 RID: 52534 RVA: 0x003304BC File Offset: 0x0032E6BC
		// (set) Token: 0x0600CD37 RID: 52535 RVA: 0x003304E4 File Offset: 0x0032E6E4
		public unsafe int _rotatingLength
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__rotatingLength);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__rotatingLength)) = value;
			}
		}

		// Token: 0x17004AC0 RID: 19136
		// (get) Token: 0x0600CD38 RID: 52536 RVA: 0x00330508 File Offset: 0x0032E708
		// (set) Token: 0x0600CD39 RID: 52537 RVA: 0x00330530 File Offset: 0x0032E730
		public unsafe byte _snapshotCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshotCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryRoundSnapshotList.NativeFieldInfoPtr__snapshotCount)) = value;
			}
		}

		// Token: 0x040081BE RID: 33214
		private static readonly IntPtr NativeFieldInfoPtr__snapshots;

		// Token: 0x040081BF RID: 33215
		private static readonly IntPtr NativeFieldInfoPtr__rotatingLength;

		// Token: 0x040081C0 RID: 33216
		private static readonly IntPtr NativeFieldInfoPtr__snapshotCount;

		// Token: 0x040081C1 RID: 33217
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

		// Token: 0x040081C2 RID: 33218
		private static readonly IntPtr NativeMethodInfoPtr_ToByteArray_Public_ArrayOf_Byte_0;

		// Token: 0x040081C3 RID: 33219
		private static readonly IntPtr NativeMethodInfoPtr_FromByteArray_Public_Void_ArrayOf_Byte_0;

		// Token: 0x040081C4 RID: 33220
		private static readonly IntPtr NativeMethodInfoPtr_AddSnapshot_Public_Void_MercenaryRoundSnapshot_0;

		// Token: 0x040081C5 RID: 33221
		private static readonly IntPtr NativeMethodInfoPtr_TryGetSnapshot_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0;

		// Token: 0x040081C6 RID: 33222
		private static readonly IntPtr NativeMethodInfoPtr_TryGetSnapshotDelta_Public_Boolean_Int32_byref_MercenaryRoundSnapshot_0;

		// Token: 0x040081C7 RID: 33223
		private static readonly IntPtr NativeMethodInfoPtr_Clear_Public_Void_0;
	}
}
