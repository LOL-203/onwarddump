﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000968 RID: 2408
	[Serializable]
	public class MercenaryEquipmentList : Object
	{
		// Token: 0x0600CC4A RID: 52298 RVA: 0x0032D0C8 File Offset: 0x0032B2C8
		[CallerCount(0)]
		public unsafe ClassLoadout.EquipmentType GetRandomInList(Random random)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryEquipmentList.NativeMethodInfoPtr_GetRandomInList_Public_EquipmentType_Random_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CC4B RID: 52299 RVA: 0x0032D130 File Offset: 0x0032B330
		[CallerCount(0)]
		public unsafe MercenaryEquipmentList() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryEquipmentList.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC4C RID: 52300 RVA: 0x0032D17C File Offset: 0x0032B37C
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryEquipmentList()
		{
			Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryEquipmentList");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr);
			MercenaryEquipmentList.NativeFieldInfoPtr_Equipment = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr, "Equipment");
			MercenaryEquipmentList.NativeMethodInfoPtr_GetRandomInList_Public_EquipmentType_Random_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr, 100679056);
			MercenaryEquipmentList.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr, 100679057);
		}

		// Token: 0x0600CC4D RID: 52301 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryEquipmentList(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A65 RID: 19045
		// (get) Token: 0x0600CC4E RID: 52302 RVA: 0x0032D1E8 File Offset: 0x0032B3E8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryEquipmentList>.NativeClassPtr));
			}
		}

		// Token: 0x17004A66 RID: 19046
		// (get) Token: 0x0600CC4F RID: 52303 RVA: 0x0032D1FC File Offset: 0x0032B3FC
		// (set) Token: 0x0600CC50 RID: 52304 RVA: 0x0032D230 File Offset: 0x0032B430
		public unsafe List<ClassLoadout.EquipmentType> Equipment
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryEquipmentList.NativeFieldInfoPtr_Equipment);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<ClassLoadout.EquipmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryEquipmentList.NativeFieldInfoPtr_Equipment), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008125 RID: 33061
		private static readonly IntPtr NativeFieldInfoPtr_Equipment;

		// Token: 0x04008126 RID: 33062
		private static readonly IntPtr NativeMethodInfoPtr_GetRandomInList_Public_EquipmentType_Random_0;

		// Token: 0x04008127 RID: 33063
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
