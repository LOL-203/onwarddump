﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000969 RID: 2409
	public class MercenaryGameData : ScriptableObject
	{
		// Token: 0x0600CC51 RID: 52305 RVA: 0x0032D258 File Offset: 0x0032B458
		[CallerCount(0)]
		public unsafe MercenaryGameData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryGameData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC52 RID: 52306 RVA: 0x0032D2A4 File Offset: 0x0032B4A4
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryGameData()
		{
			Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryGameData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr);
			MercenaryGameData.NativeFieldInfoPtr_MaxTierIndex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "MaxTierIndex");
			MercenaryGameData.NativeFieldInfoPtr_RoundsBeforeFinalMission = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "RoundsBeforeFinalMission");
			MercenaryGameData.NativeFieldInfoPtr_DefaultLoadout = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "DefaultLoadout");
			MercenaryGameData.NativeFieldInfoPtr_DefaultPrimaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "DefaultPrimaryAttachments");
			MercenaryGameData.NativeFieldInfoPtr_DefaultSecondaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "DefaultSecondaryAttachments");
			MercenaryGameData.NativeFieldInfoPtr_DefaultAmmoTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "DefaultAmmoTypes");
			MercenaryGameData.NativeFieldInfoPtr_Tiers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, "Tiers");
			MercenaryGameData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr, 100679058);
		}

		// Token: 0x0600CC53 RID: 52307 RVA: 0x0002DD3C File Offset: 0x0002BF3C
		public MercenaryGameData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A67 RID: 19047
		// (get) Token: 0x0600CC54 RID: 52308 RVA: 0x0032D374 File Offset: 0x0032B574
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryGameData>.NativeClassPtr));
			}
		}

		// Token: 0x17004A68 RID: 19048
		// (get) Token: 0x0600CC55 RID: 52309 RVA: 0x0032D388 File Offset: 0x0032B588
		// (set) Token: 0x0600CC56 RID: 52310 RVA: 0x0032D3B0 File Offset: 0x0032B5B0
		public unsafe int MaxTierIndex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_MaxTierIndex);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_MaxTierIndex)) = value;
			}
		}

		// Token: 0x17004A69 RID: 19049
		// (get) Token: 0x0600CC57 RID: 52311 RVA: 0x0032D3D4 File Offset: 0x0032B5D4
		// (set) Token: 0x0600CC58 RID: 52312 RVA: 0x0032D3FC File Offset: 0x0032B5FC
		public unsafe int RoundsBeforeFinalMission
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_RoundsBeforeFinalMission);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_RoundsBeforeFinalMission)) = value;
			}
		}

		// Token: 0x17004A6A RID: 19050
		// (get) Token: 0x0600CC59 RID: 52313 RVA: 0x0032D420 File Offset: 0x0032B620
		// (set) Token: 0x0600CC5A RID: 52314 RVA: 0x0032D454 File Offset: 0x0032B654
		public unsafe Loadout DefaultLoadout
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultLoadout);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Loadout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultLoadout), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A6B RID: 19051
		// (get) Token: 0x0600CC5B RID: 52315 RVA: 0x0032D47C File Offset: 0x0032B67C
		// (set) Token: 0x0600CC5C RID: 52316 RVA: 0x0032D4B0 File Offset: 0x0032B6B0
		public unsafe List<WeaponAttachment.AttachmentType> DefaultPrimaryAttachments
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultPrimaryAttachments);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultPrimaryAttachments), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A6C RID: 19052
		// (get) Token: 0x0600CC5D RID: 52317 RVA: 0x0032D4D8 File Offset: 0x0032B6D8
		// (set) Token: 0x0600CC5E RID: 52318 RVA: 0x0032D50C File Offset: 0x0032B70C
		public unsafe List<WeaponAttachment.AttachmentType> DefaultSecondaryAttachments
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultSecondaryAttachments);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultSecondaryAttachments), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A6D RID: 19053
		// (get) Token: 0x0600CC5F RID: 52319 RVA: 0x0032D534 File Offset: 0x0032B734
		// (set) Token: 0x0600CC60 RID: 52320 RVA: 0x0032D568 File Offset: 0x0032B768
		public unsafe List<ClassLoadout.AmmoType> DefaultAmmoTypes
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultAmmoTypes);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<ClassLoadout.AmmoType>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_DefaultAmmoTypes), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A6E RID: 19054
		// (get) Token: 0x0600CC61 RID: 52321 RVA: 0x0032D590 File Offset: 0x0032B790
		// (set) Token: 0x0600CC62 RID: 52322 RVA: 0x0032D5C4 File Offset: 0x0032B7C4
		public unsafe List<MercenaryTier> Tiers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_Tiers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<MercenaryTier>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryGameData.NativeFieldInfoPtr_Tiers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008128 RID: 33064
		private static readonly IntPtr NativeFieldInfoPtr_MaxTierIndex;

		// Token: 0x04008129 RID: 33065
		private static readonly IntPtr NativeFieldInfoPtr_RoundsBeforeFinalMission;

		// Token: 0x0400812A RID: 33066
		private static readonly IntPtr NativeFieldInfoPtr_DefaultLoadout;

		// Token: 0x0400812B RID: 33067
		private static readonly IntPtr NativeFieldInfoPtr_DefaultPrimaryAttachments;

		// Token: 0x0400812C RID: 33068
		private static readonly IntPtr NativeFieldInfoPtr_DefaultSecondaryAttachments;

		// Token: 0x0400812D RID: 33069
		private static readonly IntPtr NativeFieldInfoPtr_DefaultAmmoTypes;

		// Token: 0x0400812E RID: 33070
		private static readonly IntPtr NativeFieldInfoPtr_Tiers;

		// Token: 0x0400812F RID: 33071
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
