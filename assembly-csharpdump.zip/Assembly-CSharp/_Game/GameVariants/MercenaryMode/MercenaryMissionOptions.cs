﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200096F RID: 2415
	public class MercenaryMissionOptions : Object
	{
		// Token: 0x0600CC96 RID: 52374 RVA: 0x0032E344 File Offset: 0x0032C544
		[CallerCount(0)]
		public unsafe MercenaryMissionOptions() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryMissionOptions.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC97 RID: 52375 RVA: 0x0032E390 File Offset: 0x0032C590
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryMissionOptions()
		{
			Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryMissionOptions");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr);
			MercenaryMissionOptions.NativeFieldInfoPtr_Options = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr, "Options");
			MercenaryMissionOptions.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr, 100679079);
		}

		// Token: 0x0600CC98 RID: 52376 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryMissionOptions(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A7D RID: 19069
		// (get) Token: 0x0600CC99 RID: 52377 RVA: 0x0032E3E8 File Offset: 0x0032C5E8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryMissionOptions>.NativeClassPtr));
			}
		}

		// Token: 0x17004A7E RID: 19070
		// (get) Token: 0x0600CC9A RID: 52378 RVA: 0x0032E3FC File Offset: 0x0032C5FC
		// (set) Token: 0x0600CC9B RID: 52379 RVA: 0x0032E430 File Offset: 0x0032C630
		public unsafe List<MercenaryRound> Options
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMissionOptions.NativeFieldInfoPtr_Options);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<MercenaryRound>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryMissionOptions.NativeFieldInfoPtr_Options), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400814D RID: 33101
		private static readonly IntPtr NativeFieldInfoPtr_Options;

		// Token: 0x0400814E RID: 33102
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
