﻿using System;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200096A RID: 2410
	public class MercenaryLoadoutUtils : Object
	{
		// Token: 0x0600CC63 RID: 52323 RVA: 0x0032D5EC File Offset: 0x0032B7EC
		[CallerCount(0)]
		public unsafe static bool TryGetMercenaryLoadout(out Loadout cachedLoadout)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(cachedLoadout);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.NativeMethodInfoPtr_TryGetMercenaryLoadout_Public_Static_Boolean_byref_Loadout_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			cachedLoadout = ((intPtr2 == 0) ? null : new Loadout(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CC64 RID: 52324 RVA: 0x0032D664 File Offset: 0x0032B864
		[CallerCount(0)]
		public unsafe static bool TryGetCachedItem<T>(string filePath, string fileName, out T item)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(filePath);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(fileName);
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(item);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.MethodInfoStoreGeneric_TryGetCachedItem_Private_Static_Boolean_String_String_byref_T_0<T>.Pointer, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			item = ((intPtr2 == 0) ? null : new T(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CC65 RID: 52325 RVA: 0x0032D70C File Offset: 0x0032B90C
		[CallerCount(0)]
		public unsafe static void CacheMercenaryLoadout(Loadout loadout)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(loadout);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.NativeMethodInfoPtr_CacheMercenaryLoadout_Public_Static_Void_Loadout_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC66 RID: 52326 RVA: 0x0032D758 File Offset: 0x0032B958
		[CallerCount(0)]
		public unsafe static void CacheItem(string json, string filePath, string fileName)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(json);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(filePath);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(fileName);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.NativeMethodInfoPtr_CacheItem_Private_Static_Void_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC67 RID: 52327 RVA: 0x0032D7D4 File Offset: 0x0032B9D4
		[CallerCount(0)]
		public unsafe static void ApplyRewardToClassLoadout(MercenaryReward reward, ref MercenarySessionData.StockpileDescriptor stockpile, ClassLoadout allEquipmentData)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref reward;
			ref IntPtr ptr2 = ref ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)];
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(stockpile);
			ptr2 = &intPtr;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(allEquipmentData);
			IntPtr returnedException;
			IntPtr intPtr2 = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.NativeMethodInfoPtr_ApplyRewardToClassLoadout_Public_Static_Void_MercenaryReward_byref_StockpileDescriptor_ClassLoadout_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr3 = intPtr;
			stockpile = ((intPtr3 == 0) ? null : new MercenarySessionData.StockpileDescriptor(intPtr3));
		}

		// Token: 0x0600CC68 RID: 52328 RVA: 0x0032D86C File Offset: 0x0032BA6C
		[CallerCount(0)]
		public unsafe MercenaryLoadoutUtils() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC69 RID: 52329 RVA: 0x0032D8B8 File Offset: 0x0032BAB8
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryLoadoutUtils()
		{
			Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryLoadoutUtils");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr);
			MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutDataPath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, "_mercenaryLoadoutDataPath");
			MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutFilename = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, "_mercenaryLoadoutFilename");
			MercenaryLoadoutUtils.NativeMethodInfoPtr_TryGetMercenaryLoadout_Public_Static_Boolean_byref_Loadout_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679059);
			MercenaryLoadoutUtils.NativeMethodInfoPtr_TryGetCachedItem_Private_Static_Boolean_String_String_byref_T_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679060);
			MercenaryLoadoutUtils.NativeMethodInfoPtr_CacheMercenaryLoadout_Public_Static_Void_Loadout_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679061);
			MercenaryLoadoutUtils.NativeMethodInfoPtr_CacheItem_Private_Static_Void_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679062);
			MercenaryLoadoutUtils.NativeMethodInfoPtr_ApplyRewardToClassLoadout_Public_Static_Void_MercenaryReward_byref_StockpileDescriptor_ClassLoadout_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679063);
			MercenaryLoadoutUtils.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, 100679064);
		}

		// Token: 0x0600CC6A RID: 52330 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenaryLoadoutUtils(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A6F RID: 19055
		// (get) Token: 0x0600CC6B RID: 52331 RVA: 0x0032D988 File Offset: 0x0032BB88
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr));
			}
		}

		// Token: 0x17004A70 RID: 19056
		// (get) Token: 0x0600CC6C RID: 52332 RVA: 0x0032D99C File Offset: 0x0032BB9C
		// (set) Token: 0x0600CC6D RID: 52333 RVA: 0x0032D9BC File Offset: 0x0032BBBC
		public unsafe static string _mercenaryLoadoutDataPath
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutDataPath, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutDataPath, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004A71 RID: 19057
		// (get) Token: 0x0600CC6E RID: 52334 RVA: 0x0032D9D4 File Offset: 0x0032BBD4
		// (set) Token: 0x0600CC6F RID: 52335 RVA: 0x0032D9F4 File Offset: 0x0032BBF4
		public unsafe static string _mercenaryLoadoutFilename
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutFilename, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.NativeFieldInfoPtr__mercenaryLoadoutFilename, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x04008130 RID: 33072
		private static readonly IntPtr NativeFieldInfoPtr__mercenaryLoadoutDataPath;

		// Token: 0x04008131 RID: 33073
		private static readonly IntPtr NativeFieldInfoPtr__mercenaryLoadoutFilename;

		// Token: 0x04008132 RID: 33074
		private static readonly IntPtr NativeMethodInfoPtr_TryGetMercenaryLoadout_Public_Static_Boolean_byref_Loadout_0;

		// Token: 0x04008133 RID: 33075
		private static readonly IntPtr NativeMethodInfoPtr_TryGetCachedItem_Private_Static_Boolean_String_String_byref_T_0;

		// Token: 0x04008134 RID: 33076
		private static readonly IntPtr NativeMethodInfoPtr_CacheMercenaryLoadout_Public_Static_Void_Loadout_0;

		// Token: 0x04008135 RID: 33077
		private static readonly IntPtr NativeMethodInfoPtr_CacheItem_Private_Static_Void_String_String_String_0;

		// Token: 0x04008136 RID: 33078
		private static readonly IntPtr NativeMethodInfoPtr_ApplyRewardToClassLoadout_Public_Static_Void_MercenaryReward_byref_StockpileDescriptor_ClassLoadout_0;

		// Token: 0x04008137 RID: 33079
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200096B RID: 2411
		[ObfuscatedName("_Game.GameVariants.MercenaryMode.MercenaryLoadoutUtils/<>c__DisplayClass6_0")]
		public sealed class __c__DisplayClass6_0 : Object
		{
			// Token: 0x0600CC70 RID: 52336 RVA: 0x0032DA0C File Offset: 0x0032BC0C
			[CallerCount(0)]
			public unsafe __c__DisplayClass6_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CC71 RID: 52337 RVA: 0x0032DA58 File Offset: 0x0032BC58
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__0(ClassLoadout.WeaponPointObject existingWeapon)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(existingWeapon);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__0_Internal_Boolean_WeaponPointObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC72 RID: 52338 RVA: 0x0032DAC0 File Offset: 0x0032BCC0
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__1(ClassLoadout.WeaponPointObject existingWeapon)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(existingWeapon);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__1_Internal_Boolean_WeaponPointObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC73 RID: 52339 RVA: 0x0032DB28 File Offset: 0x0032BD28
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__6(WeaponAttachment.AttachmentType existingAtt)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAtt;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_Internal_Boolean_AttachmentType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC74 RID: 52340 RVA: 0x0032DB8C File Offset: 0x0032BD8C
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__7(WeaponAttachment.AttachmentType existingAtt)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAtt;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__7_Internal_Boolean_AttachmentType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC75 RID: 52341 RVA: 0x0032DBF0 File Offset: 0x0032BDF0
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__8(ClassLoadout.EquipmentObject existingStuff)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(existingStuff);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__8_Internal_Boolean_EquipmentObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC76 RID: 52342 RVA: 0x0032DC58 File Offset: 0x0032BE58
			// Note: this type is marked as 'beforefieldinit'.
			static __c__DisplayClass6_0()
			{
				Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, "<>c__DisplayClass6_0");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeFieldInfoPtr_reward = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, "reward");
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679066);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__0_Internal_Boolean_WeaponPointObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679067);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__1_Internal_Boolean_WeaponPointObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679068);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_Internal_Boolean_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679069);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__7_Internal_Boolean_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679070);
				MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__8_Internal_Boolean_EquipmentObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr, 100679071);
			}

			// Token: 0x0600CC77 RID: 52343 RVA: 0x00002988 File Offset: 0x00000B88
			public __c__DisplayClass6_0(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004A72 RID: 19058
			// (get) Token: 0x0600CC78 RID: 52344 RVA: 0x0032DD0F File Offset: 0x0032BF0F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c__DisplayClass6_0>.NativeClassPtr));
				}
			}

			// Token: 0x17004A73 RID: 19059
			// (get) Token: 0x0600CC79 RID: 52345 RVA: 0x0032DD20 File Offset: 0x0032BF20
			// (set) Token: 0x0600CC7A RID: 52346 RVA: 0x0032DD48 File Offset: 0x0032BF48
			public unsafe MercenaryReward reward
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeFieldInfoPtr_reward);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryLoadoutUtils.__c__DisplayClass6_0.NativeFieldInfoPtr_reward)) = value;
				}
			}

			// Token: 0x04008138 RID: 33080
			private static readonly IntPtr NativeFieldInfoPtr_reward;

			// Token: 0x04008139 RID: 33081
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x0400813A RID: 33082
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__0_Internal_Boolean_WeaponPointObject_0;

			// Token: 0x0400813B RID: 33083
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__1_Internal_Boolean_WeaponPointObject_0;

			// Token: 0x0400813C RID: 33084
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_Internal_Boolean_AttachmentType_0;

			// Token: 0x0400813D RID: 33085
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__7_Internal_Boolean_AttachmentType_0;

			// Token: 0x0400813E RID: 33086
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__8_Internal_Boolean_EquipmentObject_0;
		}

		// Token: 0x0200096C RID: 2412
		[ObfuscatedName("_Game.GameVariants.MercenaryMode.MercenaryLoadoutUtils/<>c")]
		[Serializable]
		public sealed class __c : Object
		{
			// Token: 0x0600CC7B RID: 52347 RVA: 0x0032DD6C File Offset: 0x0032BF6C
			[CallerCount(0)]
			public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CC7C RID: 52348 RVA: 0x0032DDB8 File Offset: 0x0032BFB8
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__6_2(ClassLoadout.AmmoType existingAmmo)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAmmo;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_2_Internal_Boolean_AmmoType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC7D RID: 52349 RVA: 0x0032DE1C File Offset: 0x0032C01C
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__6_3(ClassLoadout.AmmoType existingAmmo)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAmmo;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_3_Internal_Boolean_AmmoType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC7E RID: 52350 RVA: 0x0032DE80 File Offset: 0x0032C080
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__6_4(WeaponAttachment.AttachmentType existingAtt)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAtt;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_4_Internal_Boolean_AttachmentType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC7F RID: 52351 RVA: 0x0032DEE4 File Offset: 0x0032C0E4
			[CallerCount(0)]
			public unsafe bool _ApplyRewardToClassLoadout_b__6_5(WeaponAttachment.AttachmentType existingAtt)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref existingAtt;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_5_Internal_Boolean_AttachmentType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x0600CC80 RID: 52352 RVA: 0x0032DF48 File Offset: 0x0032C148
			// Note: this type is marked as 'beforefieldinit'.
			static __c()
			{
				Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr, "<>c");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr);
				MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, "<>9");
				MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, "<>9__6_2");
				MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, "<>9__6_3");
				MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, "<>9__6_4");
				MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, "<>9__6_5");
				MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, 100679073);
				MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_2_Internal_Boolean_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, 100679074);
				MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_3_Internal_Boolean_AmmoType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, 100679075);
				MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_4_Internal_Boolean_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, 100679076);
				MercenaryLoadoutUtils.__c.NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_5_Internal_Boolean_AttachmentType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr, 100679077);
			}

			// Token: 0x0600CC81 RID: 52353 RVA: 0x00002988 File Offset: 0x00000B88
			public __c(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004A74 RID: 19060
			// (get) Token: 0x0600CC82 RID: 52354 RVA: 0x0032E03B File Offset: 0x0032C23B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryLoadoutUtils.__c>.NativeClassPtr));
				}
			}

			// Token: 0x17004A75 RID: 19061
			// (get) Token: 0x0600CC83 RID: 52355 RVA: 0x0032E04C File Offset: 0x0032C24C
			// (set) Token: 0x0600CC84 RID: 52356 RVA: 0x0032E077 File Offset: 0x0032C277
			public unsafe static MercenaryLoadoutUtils.__c __9
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new MercenaryLoadoutUtils.__c(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004A76 RID: 19062
			// (get) Token: 0x0600CC85 RID: 52357 RVA: 0x0032E08C File Offset: 0x0032C28C
			// (set) Token: 0x0600CC86 RID: 52358 RVA: 0x0032E0B7 File Offset: 0x0032C2B7
			public unsafe static Func<ClassLoadout.AmmoType, bool> __9__6_2
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_2, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<ClassLoadout.AmmoType, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_2, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004A77 RID: 19063
			// (get) Token: 0x0600CC87 RID: 52359 RVA: 0x0032E0CC File Offset: 0x0032C2CC
			// (set) Token: 0x0600CC88 RID: 52360 RVA: 0x0032E0F7 File Offset: 0x0032C2F7
			public unsafe static Func<ClassLoadout.AmmoType, bool> __9__6_3
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_3, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<ClassLoadout.AmmoType, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_3, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004A78 RID: 19064
			// (get) Token: 0x0600CC89 RID: 52361 RVA: 0x0032E10C File Offset: 0x0032C30C
			// (set) Token: 0x0600CC8A RID: 52362 RVA: 0x0032E137 File Offset: 0x0032C337
			public unsafe static Func<WeaponAttachment.AttachmentType, bool> __9__6_4
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_4, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<WeaponAttachment.AttachmentType, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_4, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004A79 RID: 19065
			// (get) Token: 0x0600CC8B RID: 52363 RVA: 0x0032E14C File Offset: 0x0032C34C
			// (set) Token: 0x0600CC8C RID: 52364 RVA: 0x0032E177 File Offset: 0x0032C377
			public unsafe static Func<WeaponAttachment.AttachmentType, bool> __9__6_5
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_5, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<WeaponAttachment.AttachmentType, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(MercenaryLoadoutUtils.__c.NativeFieldInfoPtr___9__6_5, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400813F RID: 33087
			private static readonly IntPtr NativeFieldInfoPtr___9;

			// Token: 0x04008140 RID: 33088
			private static readonly IntPtr NativeFieldInfoPtr___9__6_2;

			// Token: 0x04008141 RID: 33089
			private static readonly IntPtr NativeFieldInfoPtr___9__6_3;

			// Token: 0x04008142 RID: 33090
			private static readonly IntPtr NativeFieldInfoPtr___9__6_4;

			// Token: 0x04008143 RID: 33091
			private static readonly IntPtr NativeFieldInfoPtr___9__6_5;

			// Token: 0x04008144 RID: 33092
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x04008145 RID: 33093
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_2_Internal_Boolean_AmmoType_0;

			// Token: 0x04008146 RID: 33094
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_3_Internal_Boolean_AmmoType_0;

			// Token: 0x04008147 RID: 33095
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_4_Internal_Boolean_AttachmentType_0;

			// Token: 0x04008148 RID: 33096
			private static readonly IntPtr NativeMethodInfoPtr__ApplyRewardToClassLoadout_b__6_5_Internal_Boolean_AttachmentType_0;
		}

		// Token: 0x0200096D RID: 2413
		private sealed class MethodInfoStoreGeneric_TryGetCachedItem_Private_Static_Boolean_String_String_byref_T_0<T>
		{
			// Token: 0x04008149 RID: 33097
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(MercenaryLoadoutUtils.NativeMethodInfoPtr_TryGetCachedItem_Private_Static_Boolean_String_String_byref_T_0, Il2CppClassPointerStore<MercenaryLoadoutUtils>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
