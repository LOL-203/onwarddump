﻿using System;
using System.Runtime.InteropServices;
using DPI;
using DPI.AISystems.Spawners;
using DPI.Networking;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Il2CppSystem.Reflection;
using Onward.Data;
using Onward.GameVariants;
using Onward.GameVariants.Mercenary;
using Onward.Networking;
using Onward.Scenes;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using _Game.GameVariants.Objectives;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x02000980 RID: 2432
	public class MercenaryVariant : DeterminedRoundLengthGameMode
	{
		// Token: 0x17004AF6 RID: 19190
		// (get) Token: 0x0600CD83 RID: 52611 RVA: 0x00331368 File Offset: 0x0032F568
		public unsafe static int CurrentRoundIndex
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_get_CurrentRoundIndex_Public_Static_get_Int32_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004AF7 RID: 19191
		// (get) Token: 0x0600CD84 RID: 52612 RVA: 0x003313AC File Offset: 0x0032F5AC
		public unsafe static bool IsInHideout
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_get_IsInHideout_Public_Static_get_Boolean_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004AF8 RID: 19192
		// (get) Token: 0x0600CD85 RID: 52613 RVA: 0x003313F0 File Offset: 0x0032F5F0
		public unsafe static MercenaryRoundType CurrentRoundType
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_get_CurrentRoundType_Public_Static_get_MercenaryRoundType_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004AF9 RID: 19193
		// (get) Token: 0x0600CD86 RID: 52614 RVA: 0x00331434 File Offset: 0x0032F634
		public unsafe static MercenaryRoundType NextRoundType
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_get_NextRoundType_Public_Static_get_MercenaryRoundType_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CD87 RID: 52615 RVA: 0x00331478 File Offset: 0x0032F678
		[CallerCount(0)]
		public unsafe static MercenaryRoundType GetRoundType(int roundIndex)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref roundIndex;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetRoundType_Private_Static_MercenaryRoundType_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD88 RID: 52616 RVA: 0x003314CC File Offset: 0x0032F6CC
		[CallerCount(0)]
		public new unsafe void InitializeGameVariant(bool resetTaskIndex = true)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref resetTaskIndex;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_InitializeGameVariant_Public_Virtual_Void_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD89 RID: 52617 RVA: 0x0033152C File Offset: 0x0032F72C
		[CallerCount(0)]
		public new unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD8A RID: 52618 RVA: 0x0033157C File Offset: 0x0032F77C
		[CallerCount(0)]
		public new unsafe string GetIntroTextForCurrentFaction()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_GetIntroTextForCurrentFaction_Public_Virtual_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CD8B RID: 52619 RVA: 0x003315D4 File Offset: 0x0032F7D4
		[CallerCount(0)]
		public unsafe string GetIntroTextForVariant<T>() where T : GameVariant
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.MethodInfoStoreGeneric_GetIntroTextForVariant_Private_String_0<T>.Pointer, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CD8C RID: 52620 RVA: 0x00331620 File Offset: 0x0032F820
		[CallerCount(0)]
		public new unsafe void BroadcastMissionData([Optional] DPIPlayer target)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(target);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_BroadcastMissionData_Protected_Virtual_Void_DPIPlayer_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD8D RID: 52621 RVA: 0x00331684 File Offset: 0x0032F884
		[CallerCount(0)]
		public unsafe void ReceivedRoundData(MissionDataEvent<MercenaryGameData> missionData, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(missionData));
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_ReceivedRoundData_Private_Void_MissionDataEvent_1_MercenaryGameData_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD8E RID: 52622 RVA: 0x00331700 File Offset: 0x0032F900
		[CallerCount(0)]
		public new unsafe void SpawnObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_SpawnObjective_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD8F RID: 52623 RVA: 0x00331750 File Offset: 0x0032F950
		[CallerCount(0)]
		public new unsafe void AdvanceMission()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_AdvanceMission_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD90 RID: 52624 RVA: 0x003317A0 File Offset: 0x0032F9A0
		[CallerCount(0)]
		public unsafe void ActivateObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_ActivateObjective_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD91 RID: 52625 RVA: 0x003317E4 File Offset: 0x0032F9E4
		[CallerCount(0)]
		public unsafe ObjectiveTypes GetEvacType(MercenaryMissionData missionData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(missionData);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetEvacType_Private_ObjectiveTypes_MercenaryMissionData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD92 RID: 52626 RVA: 0x0033184C File Offset: 0x0032FA4C
		[CallerCount(0)]
		public unsafe void CleanUpObjectives()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_CleanUpObjectives_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD93 RID: 52627 RVA: 0x00331890 File Offset: 0x0032FA90
		[CallerCount(0)]
		public unsafe static bool IsEndless()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_IsEndless_Public_Static_Boolean_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD94 RID: 52628 RVA: 0x003318D4 File Offset: 0x0032FAD4
		[CallerCount(0)]
		public unsafe MercenaryRound GenerateRound(RandomWrapper random, int generationSeed, int tierIndex, HashSet<OnwardMap> usedMaps, HashSet<int> usedRewards)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref generationSeed;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref tierIndex;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedMaps);
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedRewards);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GenerateRound_Private_MercenaryRound_RandomWrapper_Int32_Int32_HashSet_1_OnwardMap_HashSet_1_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new MercenaryRound(intPtr);
		}

		// Token: 0x0600CD95 RID: 52629 RVA: 0x0033198C File Offset: 0x0032FB8C
		[CallerCount(0)]
		public unsafe OnwardMap PickWeightedMap(MercenaryTier tier, RandomWrapper random, HashSet<OnwardMap> usedMaps)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(tier);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedMaps);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_PickWeightedMap_Private_OnwardMap_MercenaryTier_RandomWrapper_HashSet_1_OnwardMap_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD96 RID: 52630 RVA: 0x00331A24 File Offset: 0x0032FC24
		[CallerCount(0)]
		public unsafe float GetWeightForMap(MercenaryTier tier, SceneData map)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(tier);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(map);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetWeightForMap_Private_Single_MercenaryTier_SceneData_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD97 RID: 52631 RVA: 0x00331AA4 File Offset: 0x0032FCA4
		[CallerCount(0)]
		public unsafe void SetupInitialSessionData(string roomName, bool isInHideout)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(roomName);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isInHideout;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_SetupInitialSessionData_Private_Void_String_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD98 RID: 52632 RVA: 0x00331B10 File Offset: 0x0032FD10
		[CallerCount(0)]
		public unsafe void SetupPerRoundSessionData(bool initial)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref initial;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_SetupPerRoundSessionData_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD99 RID: 52633 RVA: 0x00331B64 File Offset: 0x0032FD64
		[CallerCount(0)]
		public unsafe MercenaryMissionOptions GetThreeMissionOptions(int roundSeed, int roundIndex)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref roundSeed;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref roundIndex;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetThreeMissionOptions_Private_MercenaryMissionOptions_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new MercenaryMissionOptions(intPtr2) : null;
		}

		// Token: 0x0600CD9A RID: 52634 RVA: 0x00331BE0 File Offset: 0x0032FDE0
		[CallerCount(0)]
		public unsafe static void ResetRoomProperties(bool isContinuing)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isContinuing;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_ResetRoomProperties_Public_Static_Void_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD9B RID: 52635 RVA: 0x00331C28 File Offset: 0x0032FE28
		[CallerCount(0)]
		public unsafe void SetupDefaultStockpile()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_SetupDefaultStockpile_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD9C RID: 52636 RVA: 0x00331C6C File Offset: 0x0032FE6C
		[CallerCount(0)]
		public unsafe static MercenaryReward GenerateWeaponPackage(RandomWrapper random, MercenaryTierRewards tierRewards, HashSet<int> usedRewards)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(tierRewards);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedRewards);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GenerateWeaponPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD9D RID: 52637 RVA: 0x00331CF4 File Offset: 0x0032FEF4
		[CallerCount(0)]
		public unsafe static MercenaryReward GenerateUtilityPackage(RandomWrapper random, MercenaryTierRewards tierRewards, HashSet<int> usedRewards)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(tierRewards);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedRewards);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GenerateUtilityPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CD9E RID: 52638 RVA: 0x00331D7C File Offset: 0x0032FF7C
		[CallerCount(0)]
		public new unsafe string GetGameVariantDataName(GameVariantNameType nameType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref nameType;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_GetGameVariantDataName_Public_Virtual_String_GameVariantNameType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CD9F RID: 52639 RVA: 0x00331DE4 File Offset: 0x0032FFE4
		[CallerCount(0)]
		public unsafe static MercenaryRewardDefinition GetUniqueRewardDefinition(RandomWrapper random, List<MercenaryRewardDefinition> allEntries, HashSet<int> usedEntries)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(allEntries);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(usedEntries);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetUniqueRewardDefinition_Private_Static_MercenaryRewardDefinition_RandomWrapper_List_1_MercenaryRewardDefinition_HashSet_1_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new MercenaryRewardDefinition(intPtr2) : null;
		}

		// Token: 0x0600CDA0 RID: 52640 RVA: 0x00331E74 File Offset: 0x00330074
		[CallerCount(0)]
		public unsafe static MercenaryTier GetTierForRound(int round, RandomWrapper random, List<MercenaryTier> tiers)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref round;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(tiers);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetTierForRound_Private_Static_MercenaryTier_Int32_RandomWrapper_List_1_MercenaryTier_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new MercenaryTier(intPtr2) : null;
		}

		// Token: 0x0600CDA1 RID: 52641 RVA: 0x00331F00 File Offset: 0x00330100
		[CallerCount(0)]
		public new unsafe int GetRoundLength()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), MercenaryVariant.NativeMethodInfoPtr_GetRoundLength_Public_Virtual_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA2 RID: 52642 RVA: 0x00331F5C File Offset: 0x0033015C
		[CallerCount(0)]
		public unsafe void CreateAISpawner()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_CreateAISpawner_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDA3 RID: 52643 RVA: 0x00331FA0 File Offset: 0x003301A0
		[CallerCount(0)]
		public unsafe void DestroyAISpawner()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_DestroyAISpawner_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDA4 RID: 52644 RVA: 0x00331FE4 File Offset: 0x003301E4
		[CallerCount(0)]
		public unsafe static int GetPlayerCount()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetPlayerCount_Public_Static_Int32_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA5 RID: 52645 RVA: 0x00332028 File Offset: 0x00330228
		[CallerCount(0)]
		public unsafe static MercenaryOperationScale GetIntendedOperationScale(int players)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref players;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetIntendedOperationScale_Public_Static_MercenaryOperationScale_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA6 RID: 52646 RVA: 0x0033207C File Offset: 0x0033027C
		[CallerCount(0)]
		public unsafe static MercenaryOperationScale GetCurrentRawOperationScale()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetCurrentRawOperationScale_Public_Static_MercenaryOperationScale_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA7 RID: 52647 RVA: 0x003320C0 File Offset: 0x003302C0
		[CallerCount(0)]
		public unsafe static MercenaryOperationScale GetCurrentEffectiveOperationScale()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetCurrentEffectiveOperationScale_Public_Static_MercenaryOperationScale_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA8 RID: 52648 RVA: 0x00332104 File Offset: 0x00330304
		[CallerCount(0)]
		public unsafe static MercenaryChallengeLevel GetChallengeLevel(int players, MercenaryOperationScale currentScale)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref players;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref currentScale;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetChallengeLevel_Public_Static_MercenaryChallengeLevel_Int32_MercenaryOperationScale_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDA9 RID: 52649 RVA: 0x0033216C File Offset: 0x0033036C
		[CallerCount(0)]
		public unsafe static string GetChallengeLevelCaption(int players, MercenaryOperationScale scale, bool colored)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref players;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref scale;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref colored;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetChallengeLevelCaption_Public_Static_String_Int32_MercenaryOperationScale_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600CDAA RID: 52650 RVA: 0x003321E0 File Offset: 0x003303E0
		[CallerCount(0)]
		public unsafe static bool OverrideToCountUpFromStart(MercenaryObjectives objectiveType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref objectiveType;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_OverrideToCountUpFromStart_Public_Static_Boolean_MercenaryObjectives_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDAB RID: 52651 RVA: 0x00332234 File Offset: 0x00330434
		[CallerCount(0)]
		public unsafe int GetEnemyCountForTier(RandomWrapper random, MercenaryOperationScale scale, float normalizedTierProgress)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(random);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref scale;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref normalizedTierProgress;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_GetEnemyCountForTier_Public_Int32_RandomWrapper_MercenaryOperationScale_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDAC RID: 52652 RVA: 0x003322C4 File Offset: 0x003304C4
		[CallerCount(0)]
		public unsafe bool TryGetRoundDelta(int delta, out MercenaryRound round)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref delta;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtrNotNull(round);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_TryGetRoundDelta_Public_Boolean_Int32_byref_MercenaryRound_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CDAD RID: 52653 RVA: 0x00332340 File Offset: 0x00330540
		[CallerCount(0)]
		public unsafe void ProcessRoundSnapshots(bool initial)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref initial;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_ProcessRoundSnapshots_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDAE RID: 52654 RVA: 0x00332394 File Offset: 0x00330594
		[CallerCount(0)]
		public unsafe void OnJoinInProgressContinue()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_OnJoinInProgressContinue_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDAF RID: 52655 RVA: 0x003323D8 File Offset: 0x003305D8
		[CallerCount(0)]
		public unsafe void OnJoinInProgressLeft()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr_OnJoinInProgressLeft_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDB0 RID: 52656 RVA: 0x0033241C File Offset: 0x0033061C
		[CallerCount(0)]
		public unsafe MercenaryVariant() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDB1 RID: 52657 RVA: 0x00332468 File Offset: 0x00330668
		// Note: this type is marked as 'beforefieldinit'.
		static MercenaryVariant()
		{
			Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenaryVariant");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr);
			MercenaryVariant.NativeFieldInfoPtr_MercenaryGameModeData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "MercenaryGameModeData");
			MercenaryVariant.NativeFieldInfoPtr_AllEquipmentData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "AllEquipmentData");
			MercenaryVariant.NativeFieldInfoPtr_DefaultStockpile = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "DefaultStockpile");
			MercenaryVariant.NativeFieldInfoPtr_UplinkObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "UplinkObjective");
			MercenaryVariant.NativeFieldInfoPtr_EvacObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "EvacObjective");
			MercenaryVariant.NativeFieldInfoPtr_ExtractObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "ExtractObjective");
			MercenaryVariant.NativeFieldInfoPtr_HuntObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "HuntObjective");
			MercenaryVariant.NativeFieldInfoPtr_SabotageObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "SabotageObjective");
			MercenaryVariant.NativeFieldInfoPtr_ExtractPickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "ExtractPickup");
			MercenaryVariant.NativeFieldInfoPtr_SessionData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "SessionData");
			MercenaryVariant.NativeFieldInfoPtr_BotCounts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "BotCounts");
			MercenaryVariant.NativeFieldInfoPtr_MapWeights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "MapWeights");
			MercenaryVariant.NativeFieldInfoPtr__assetDatabaseObjectiveReference = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_assetDatabaseObjectiveReference");
			MercenaryVariant.NativeFieldInfoPtr__botCounts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_botCounts");
			MercenaryVariant.NativeFieldInfoPtr__mapWeights = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_mapWeights");
			MercenaryVariant.NativeFieldInfoPtr_CurrentObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "CurrentObjective");
			MercenaryVariant.NativeFieldInfoPtr_CurrentAISpawner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "CurrentAISpawner");
			MercenaryVariant.NativeFieldInfoPtr_MercenarySpawnData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "MercenarySpawnData");
			MercenaryVariant.NativeFieldInfoPtr__validMaps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_validMaps");
			MercenaryVariant.NativeFieldInfoPtr__allMaps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_allMaps");
			MercenaryVariant.NativeFieldInfoPtr__weightedMaps = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "_weightedMaps");
			MercenaryVariant.NativeMethodInfoPtr_get_CurrentRoundIndex_Public_Static_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679109);
			MercenaryVariant.NativeMethodInfoPtr_get_IsInHideout_Public_Static_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679110);
			MercenaryVariant.NativeMethodInfoPtr_get_CurrentRoundType_Public_Static_get_MercenaryRoundType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679111);
			MercenaryVariant.NativeMethodInfoPtr_get_NextRoundType_Public_Static_get_MercenaryRoundType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679112);
			MercenaryVariant.NativeMethodInfoPtr_GetRoundType_Private_Static_MercenaryRoundType_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679113);
			MercenaryVariant.NativeMethodInfoPtr_InitializeGameVariant_Public_Virtual_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679114);
			MercenaryVariant.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679115);
			MercenaryVariant.NativeMethodInfoPtr_GetIntroTextForCurrentFaction_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679116);
			MercenaryVariant.NativeMethodInfoPtr_GetIntroTextForVariant_Private_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679117);
			MercenaryVariant.NativeMethodInfoPtr_BroadcastMissionData_Protected_Virtual_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679118);
			MercenaryVariant.NativeMethodInfoPtr_ReceivedRoundData_Private_Void_MissionDataEvent_1_MercenaryGameData_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679119);
			MercenaryVariant.NativeMethodInfoPtr_SpawnObjective_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679120);
			MercenaryVariant.NativeMethodInfoPtr_AdvanceMission_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679121);
			MercenaryVariant.NativeMethodInfoPtr_ActivateObjective_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679122);
			MercenaryVariant.NativeMethodInfoPtr_GetEvacType_Private_ObjectiveTypes_MercenaryMissionData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679123);
			MercenaryVariant.NativeMethodInfoPtr_CleanUpObjectives_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679124);
			MercenaryVariant.NativeMethodInfoPtr_IsEndless_Public_Static_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679125);
			MercenaryVariant.NativeMethodInfoPtr_GenerateRound_Private_MercenaryRound_RandomWrapper_Int32_Int32_HashSet_1_OnwardMap_HashSet_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679126);
			MercenaryVariant.NativeMethodInfoPtr_PickWeightedMap_Private_OnwardMap_MercenaryTier_RandomWrapper_HashSet_1_OnwardMap_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679127);
			MercenaryVariant.NativeMethodInfoPtr_GetWeightForMap_Private_Single_MercenaryTier_SceneData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679128);
			MercenaryVariant.NativeMethodInfoPtr_SetupInitialSessionData_Private_Void_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679129);
			MercenaryVariant.NativeMethodInfoPtr_SetupPerRoundSessionData_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679130);
			MercenaryVariant.NativeMethodInfoPtr_GetThreeMissionOptions_Private_MercenaryMissionOptions_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679131);
			MercenaryVariant.NativeMethodInfoPtr_ResetRoomProperties_Public_Static_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679132);
			MercenaryVariant.NativeMethodInfoPtr_SetupDefaultStockpile_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679133);
			MercenaryVariant.NativeMethodInfoPtr_GenerateWeaponPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679134);
			MercenaryVariant.NativeMethodInfoPtr_GenerateUtilityPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679135);
			MercenaryVariant.NativeMethodInfoPtr_GetGameVariantDataName_Public_Virtual_String_GameVariantNameType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679136);
			MercenaryVariant.NativeMethodInfoPtr_GetUniqueRewardDefinition_Private_Static_MercenaryRewardDefinition_RandomWrapper_List_1_MercenaryRewardDefinition_HashSet_1_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679137);
			MercenaryVariant.NativeMethodInfoPtr_GetTierForRound_Private_Static_MercenaryTier_Int32_RandomWrapper_List_1_MercenaryTier_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679138);
			MercenaryVariant.NativeMethodInfoPtr_GetRoundLength_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679139);
			MercenaryVariant.NativeMethodInfoPtr_CreateAISpawner_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679140);
			MercenaryVariant.NativeMethodInfoPtr_DestroyAISpawner_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679141);
			MercenaryVariant.NativeMethodInfoPtr_GetPlayerCount_Public_Static_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679142);
			MercenaryVariant.NativeMethodInfoPtr_GetIntendedOperationScale_Public_Static_MercenaryOperationScale_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679143);
			MercenaryVariant.NativeMethodInfoPtr_GetCurrentRawOperationScale_Public_Static_MercenaryOperationScale_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679144);
			MercenaryVariant.NativeMethodInfoPtr_GetCurrentEffectiveOperationScale_Public_Static_MercenaryOperationScale_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679145);
			MercenaryVariant.NativeMethodInfoPtr_GetChallengeLevel_Public_Static_MercenaryChallengeLevel_Int32_MercenaryOperationScale_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679146);
			MercenaryVariant.NativeMethodInfoPtr_GetChallengeLevelCaption_Public_Static_String_Int32_MercenaryOperationScale_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679147);
			MercenaryVariant.NativeMethodInfoPtr_OverrideToCountUpFromStart_Public_Static_Boolean_MercenaryObjectives_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679148);
			MercenaryVariant.NativeMethodInfoPtr_GetEnemyCountForTier_Public_Int32_RandomWrapper_MercenaryOperationScale_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679149);
			MercenaryVariant.NativeMethodInfoPtr_TryGetRoundDelta_Public_Boolean_Int32_byref_MercenaryRound_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679150);
			MercenaryVariant.NativeMethodInfoPtr_ProcessRoundSnapshots_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679151);
			MercenaryVariant.NativeMethodInfoPtr_OnJoinInProgressContinue_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679152);
			MercenaryVariant.NativeMethodInfoPtr_OnJoinInProgressLeft_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679153);
			MercenaryVariant.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, 100679154);
		}

		// Token: 0x0600CDB2 RID: 52658 RVA: 0x003329D4 File Offset: 0x00330BD4
		public MercenaryVariant(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004AE0 RID: 19168
		// (get) Token: 0x0600CDB3 RID: 52659 RVA: 0x003329DD File Offset: 0x00330BDD
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr));
			}
		}

		// Token: 0x17004AE1 RID: 19169
		// (get) Token: 0x0600CDB4 RID: 52660 RVA: 0x003329F0 File Offset: 0x00330BF0
		// (set) Token: 0x0600CDB5 RID: 52661 RVA: 0x00332A24 File Offset: 0x00330C24
		public unsafe MercenaryGameData MercenaryGameModeData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MercenaryGameModeData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryGameData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MercenaryGameModeData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE2 RID: 19170
		// (get) Token: 0x0600CDB6 RID: 52662 RVA: 0x00332A4C File Offset: 0x00330C4C
		// (set) Token: 0x0600CDB7 RID: 52663 RVA: 0x00332A80 File Offset: 0x00330C80
		public unsafe ClassLoadout AllEquipmentData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_AllEquipmentData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ClassLoadout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_AllEquipmentData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE3 RID: 19171
		// (get) Token: 0x0600CDB8 RID: 52664 RVA: 0x00332AA8 File Offset: 0x00330CA8
		// (set) Token: 0x0600CDB9 RID: 52665 RVA: 0x00332ADC File Offset: 0x00330CDC
		public unsafe ClassLoadout DefaultStockpile
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_DefaultStockpile);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ClassLoadout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_DefaultStockpile), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE4 RID: 19172
		// (get) Token: 0x0600CDBA RID: 52666 RVA: 0x00332B04 File Offset: 0x00330D04
		// (set) Token: 0x0600CDBB RID: 52667 RVA: 0x00332B38 File Offset: 0x00330D38
		public unsafe AssetReference UplinkObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_UplinkObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReference(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_UplinkObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE5 RID: 19173
		// (get) Token: 0x0600CDBC RID: 52668 RVA: 0x00332B60 File Offset: 0x00330D60
		// (set) Token: 0x0600CDBD RID: 52669 RVA: 0x00332B94 File Offset: 0x00330D94
		public unsafe AssetReference EvacObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_EvacObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReference(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_EvacObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE6 RID: 19174
		// (get) Token: 0x0600CDBE RID: 52670 RVA: 0x00332BBC File Offset: 0x00330DBC
		// (set) Token: 0x0600CDBF RID: 52671 RVA: 0x00332BF0 File Offset: 0x00330DF0
		public unsafe AssetReference ExtractObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_ExtractObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReference(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_ExtractObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE7 RID: 19175
		// (get) Token: 0x0600CDC0 RID: 52672 RVA: 0x00332C18 File Offset: 0x00330E18
		// (set) Token: 0x0600CDC1 RID: 52673 RVA: 0x00332C4C File Offset: 0x00330E4C
		public unsafe AssetReference HuntObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_HuntObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReference(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_HuntObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE8 RID: 19176
		// (get) Token: 0x0600CDC2 RID: 52674 RVA: 0x00332C74 File Offset: 0x00330E74
		// (set) Token: 0x0600CDC3 RID: 52675 RVA: 0x00332CA8 File Offset: 0x00330EA8
		public unsafe AssetReference SabotageObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_SabotageObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReference(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_SabotageObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AE9 RID: 19177
		// (get) Token: 0x0600CDC4 RID: 52676 RVA: 0x00332CD0 File Offset: 0x00330ED0
		// (set) Token: 0x0600CDC5 RID: 52677 RVA: 0x00332D04 File Offset: 0x00330F04
		public unsafe PickupData ExtractPickup
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_ExtractPickup);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PickupData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_ExtractPickup), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AEA RID: 19178
		// (get) Token: 0x0600CDC6 RID: 52678 RVA: 0x00332D2C File Offset: 0x00330F2C
		// (set) Token: 0x0600CDC7 RID: 52679 RVA: 0x00332D57 File Offset: 0x00330F57
		public unsafe static MercenarySessionData SessionData
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(MercenaryVariant.NativeFieldInfoPtr_SessionData, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new MercenarySessionData(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryVariant.NativeFieldInfoPtr_SessionData, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AEB RID: 19179
		// (get) Token: 0x0600CDC8 RID: 52680 RVA: 0x00332D6C File Offset: 0x00330F6C
		// (set) Token: 0x0600CDC9 RID: 52681 RVA: 0x00332DA0 File Offset: 0x00330FA0
		public unsafe Il2CppReferenceArray<MercenaryBotCount> BotCounts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_BotCounts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<MercenaryBotCount>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_BotCounts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AEC RID: 19180
		// (get) Token: 0x0600CDCA RID: 52682 RVA: 0x00332DC8 File Offset: 0x00330FC8
		// (set) Token: 0x0600CDCB RID: 52683 RVA: 0x00332DFC File Offset: 0x00330FFC
		public unsafe Il2CppReferenceArray<MercenaryMapWeight> MapWeights
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MapWeights);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<MercenaryMapWeight>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MapWeights), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AED RID: 19181
		// (get) Token: 0x0600CDCC RID: 52684 RVA: 0x00332E24 File Offset: 0x00331024
		// (set) Token: 0x0600CDCD RID: 52685 RVA: 0x00332E58 File Offset: 0x00331058
		public unsafe GameObject _assetDatabaseObjectiveReference
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__assetDatabaseObjectiveReference);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__assetDatabaseObjectiveReference), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AEE RID: 19182
		// (get) Token: 0x0600CDCE RID: 52686 RVA: 0x00332E80 File Offset: 0x00331080
		// (set) Token: 0x0600CDCF RID: 52687 RVA: 0x00332EB4 File Offset: 0x003310B4
		public unsafe Dictionary<MercenaryOperationScale, MercenaryBotCount> _botCounts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__botCounts);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<MercenaryOperationScale, MercenaryBotCount>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__botCounts), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AEF RID: 19183
		// (get) Token: 0x0600CDD0 RID: 52688 RVA: 0x00332EDC File Offset: 0x003310DC
		// (set) Token: 0x0600CDD1 RID: 52689 RVA: 0x00332F10 File Offset: 0x00331110
		public unsafe Dictionary<int, MercenaryMapWeight> _mapWeights
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__mapWeights);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<int, MercenaryMapWeight>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr__mapWeights), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF0 RID: 19184
		// (get) Token: 0x0600CDD2 RID: 52690 RVA: 0x00332F38 File Offset: 0x00331138
		// (set) Token: 0x0600CDD3 RID: 52691 RVA: 0x00332F6C File Offset: 0x0033116C
		public unsafe BaseObjective CurrentObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_CurrentObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new BaseObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_CurrentObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF1 RID: 19185
		// (get) Token: 0x0600CDD4 RID: 52692 RVA: 0x00332F94 File Offset: 0x00331194
		// (set) Token: 0x0600CDD5 RID: 52693 RVA: 0x00332FC8 File Offset: 0x003311C8
		public unsafe AISpawner CurrentAISpawner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_CurrentAISpawner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AISpawner(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_CurrentAISpawner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF2 RID: 19186
		// (get) Token: 0x0600CDD6 RID: 52694 RVA: 0x00332FF0 File Offset: 0x003311F0
		// (set) Token: 0x0600CDD7 RID: 52695 RVA: 0x00333024 File Offset: 0x00331224
		public unsafe MercenarySpawnData MercenarySpawnData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MercenarySpawnData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenarySpawnData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.NativeFieldInfoPtr_MercenarySpawnData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF3 RID: 19187
		// (get) Token: 0x0600CDD8 RID: 52696 RVA: 0x0033304C File Offset: 0x0033124C
		// (set) Token: 0x0600CDD9 RID: 52697 RVA: 0x00333077 File Offset: 0x00331277
		public unsafe static List<SceneData> _validMaps
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(MercenaryVariant.NativeFieldInfoPtr__validMaps, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<SceneData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryVariant.NativeFieldInfoPtr__validMaps, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF4 RID: 19188
		// (get) Token: 0x0600CDDA RID: 52698 RVA: 0x0033308C File Offset: 0x0033128C
		// (set) Token: 0x0600CDDB RID: 52699 RVA: 0x003330B7 File Offset: 0x003312B7
		public unsafe static List<SceneData> _allMaps
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(MercenaryVariant.NativeFieldInfoPtr__allMaps, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<SceneData>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryVariant.NativeFieldInfoPtr__allMaps, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AF5 RID: 19189
		// (get) Token: 0x0600CDDC RID: 52700 RVA: 0x003330CC File Offset: 0x003312CC
		// (set) Token: 0x0600CDDD RID: 52701 RVA: 0x003330F7 File Offset: 0x003312F7
		public unsafe static List<ValueTuple<OnwardMap, float>> _weightedMaps
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(MercenaryVariant.NativeFieldInfoPtr__weightedMaps, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<ValueTuple<OnwardMap, float>>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenaryVariant.NativeFieldInfoPtr__weightedMaps, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040081ED RID: 33261
		private static readonly IntPtr NativeFieldInfoPtr_MercenaryGameModeData;

		// Token: 0x040081EE RID: 33262
		private static readonly IntPtr NativeFieldInfoPtr_AllEquipmentData;

		// Token: 0x040081EF RID: 33263
		private static readonly IntPtr NativeFieldInfoPtr_DefaultStockpile;

		// Token: 0x040081F0 RID: 33264
		private static readonly IntPtr NativeFieldInfoPtr_UplinkObjective;

		// Token: 0x040081F1 RID: 33265
		private static readonly IntPtr NativeFieldInfoPtr_EvacObjective;

		// Token: 0x040081F2 RID: 33266
		private static readonly IntPtr NativeFieldInfoPtr_ExtractObjective;

		// Token: 0x040081F3 RID: 33267
		private static readonly IntPtr NativeFieldInfoPtr_HuntObjective;

		// Token: 0x040081F4 RID: 33268
		private static readonly IntPtr NativeFieldInfoPtr_SabotageObjective;

		// Token: 0x040081F5 RID: 33269
		private static readonly IntPtr NativeFieldInfoPtr_ExtractPickup;

		// Token: 0x040081F6 RID: 33270
		private static readonly IntPtr NativeFieldInfoPtr_SessionData;

		// Token: 0x040081F7 RID: 33271
		private static readonly IntPtr NativeFieldInfoPtr_BotCounts;

		// Token: 0x040081F8 RID: 33272
		private static readonly IntPtr NativeFieldInfoPtr_MapWeights;

		// Token: 0x040081F9 RID: 33273
		private static readonly IntPtr NativeFieldInfoPtr__assetDatabaseObjectiveReference;

		// Token: 0x040081FA RID: 33274
		private static readonly IntPtr NativeFieldInfoPtr__botCounts;

		// Token: 0x040081FB RID: 33275
		private static readonly IntPtr NativeFieldInfoPtr__mapWeights;

		// Token: 0x040081FC RID: 33276
		private static readonly IntPtr NativeFieldInfoPtr_CurrentObjective;

		// Token: 0x040081FD RID: 33277
		private static readonly IntPtr NativeFieldInfoPtr_CurrentAISpawner;

		// Token: 0x040081FE RID: 33278
		private static readonly IntPtr NativeFieldInfoPtr_MercenarySpawnData;

		// Token: 0x040081FF RID: 33279
		private static readonly IntPtr NativeFieldInfoPtr__validMaps;

		// Token: 0x04008200 RID: 33280
		private static readonly IntPtr NativeFieldInfoPtr__allMaps;

		// Token: 0x04008201 RID: 33281
		private static readonly IntPtr NativeFieldInfoPtr__weightedMaps;

		// Token: 0x04008202 RID: 33282
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentRoundIndex_Public_Static_get_Int32_0;

		// Token: 0x04008203 RID: 33283
		private static readonly IntPtr NativeMethodInfoPtr_get_IsInHideout_Public_Static_get_Boolean_0;

		// Token: 0x04008204 RID: 33284
		private static readonly IntPtr NativeMethodInfoPtr_get_CurrentRoundType_Public_Static_get_MercenaryRoundType_0;

		// Token: 0x04008205 RID: 33285
		private static readonly IntPtr NativeMethodInfoPtr_get_NextRoundType_Public_Static_get_MercenaryRoundType_0;

		// Token: 0x04008206 RID: 33286
		private static readonly IntPtr NativeMethodInfoPtr_GetRoundType_Private_Static_MercenaryRoundType_Int32_0;

		// Token: 0x04008207 RID: 33287
		private static readonly IntPtr NativeMethodInfoPtr_InitializeGameVariant_Public_Virtual_Void_Boolean_0;

		// Token: 0x04008208 RID: 33288
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0;

		// Token: 0x04008209 RID: 33289
		private static readonly IntPtr NativeMethodInfoPtr_GetIntroTextForCurrentFaction_Public_Virtual_String_0;

		// Token: 0x0400820A RID: 33290
		private static readonly IntPtr NativeMethodInfoPtr_GetIntroTextForVariant_Private_String_0;

		// Token: 0x0400820B RID: 33291
		private static readonly IntPtr NativeMethodInfoPtr_BroadcastMissionData_Protected_Virtual_Void_DPIPlayer_0;

		// Token: 0x0400820C RID: 33292
		private static readonly IntPtr NativeMethodInfoPtr_ReceivedRoundData_Private_Void_MissionDataEvent_1_MercenaryGameData_DPINetworkMessageInfo_0;

		// Token: 0x0400820D RID: 33293
		private static readonly IntPtr NativeMethodInfoPtr_SpawnObjective_Public_Virtual_Void_0;

		// Token: 0x0400820E RID: 33294
		private static readonly IntPtr NativeMethodInfoPtr_AdvanceMission_Protected_Virtual_Void_0;

		// Token: 0x0400820F RID: 33295
		private static readonly IntPtr NativeMethodInfoPtr_ActivateObjective_Private_Void_0;

		// Token: 0x04008210 RID: 33296
		private static readonly IntPtr NativeMethodInfoPtr_GetEvacType_Private_ObjectiveTypes_MercenaryMissionData_0;

		// Token: 0x04008211 RID: 33297
		private static readonly IntPtr NativeMethodInfoPtr_CleanUpObjectives_Public_Void_0;

		// Token: 0x04008212 RID: 33298
		private static readonly IntPtr NativeMethodInfoPtr_IsEndless_Public_Static_Boolean_0;

		// Token: 0x04008213 RID: 33299
		private static readonly IntPtr NativeMethodInfoPtr_GenerateRound_Private_MercenaryRound_RandomWrapper_Int32_Int32_HashSet_1_OnwardMap_HashSet_1_Int32_0;

		// Token: 0x04008214 RID: 33300
		private static readonly IntPtr NativeMethodInfoPtr_PickWeightedMap_Private_OnwardMap_MercenaryTier_RandomWrapper_HashSet_1_OnwardMap_0;

		// Token: 0x04008215 RID: 33301
		private static readonly IntPtr NativeMethodInfoPtr_GetWeightForMap_Private_Single_MercenaryTier_SceneData_0;

		// Token: 0x04008216 RID: 33302
		private static readonly IntPtr NativeMethodInfoPtr_SetupInitialSessionData_Private_Void_String_Boolean_0;

		// Token: 0x04008217 RID: 33303
		private static readonly IntPtr NativeMethodInfoPtr_SetupPerRoundSessionData_Private_Void_Boolean_0;

		// Token: 0x04008218 RID: 33304
		private static readonly IntPtr NativeMethodInfoPtr_GetThreeMissionOptions_Private_MercenaryMissionOptions_Int32_Int32_0;

		// Token: 0x04008219 RID: 33305
		private static readonly IntPtr NativeMethodInfoPtr_ResetRoomProperties_Public_Static_Void_Boolean_0;

		// Token: 0x0400821A RID: 33306
		private static readonly IntPtr NativeMethodInfoPtr_SetupDefaultStockpile_Private_Void_0;

		// Token: 0x0400821B RID: 33307
		private static readonly IntPtr NativeMethodInfoPtr_GenerateWeaponPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0;

		// Token: 0x0400821C RID: 33308
		private static readonly IntPtr NativeMethodInfoPtr_GenerateUtilityPackage_Public_Static_MercenaryReward_RandomWrapper_MercenaryTierRewards_HashSet_1_Int32_0;

		// Token: 0x0400821D RID: 33309
		private static readonly IntPtr NativeMethodInfoPtr_GetGameVariantDataName_Public_Virtual_String_GameVariantNameType_0;

		// Token: 0x0400821E RID: 33310
		private static readonly IntPtr NativeMethodInfoPtr_GetUniqueRewardDefinition_Private_Static_MercenaryRewardDefinition_RandomWrapper_List_1_MercenaryRewardDefinition_HashSet_1_Int32_0;

		// Token: 0x0400821F RID: 33311
		private static readonly IntPtr NativeMethodInfoPtr_GetTierForRound_Private_Static_MercenaryTier_Int32_RandomWrapper_List_1_MercenaryTier_0;

		// Token: 0x04008220 RID: 33312
		private static readonly IntPtr NativeMethodInfoPtr_GetRoundLength_Public_Virtual_Int32_0;

		// Token: 0x04008221 RID: 33313
		private static readonly IntPtr NativeMethodInfoPtr_CreateAISpawner_Public_Void_0;

		// Token: 0x04008222 RID: 33314
		private static readonly IntPtr NativeMethodInfoPtr_DestroyAISpawner_Public_Void_0;

		// Token: 0x04008223 RID: 33315
		private static readonly IntPtr NativeMethodInfoPtr_GetPlayerCount_Public_Static_Int32_0;

		// Token: 0x04008224 RID: 33316
		private static readonly IntPtr NativeMethodInfoPtr_GetIntendedOperationScale_Public_Static_MercenaryOperationScale_Int32_0;

		// Token: 0x04008225 RID: 33317
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentRawOperationScale_Public_Static_MercenaryOperationScale_0;

		// Token: 0x04008226 RID: 33318
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentEffectiveOperationScale_Public_Static_MercenaryOperationScale_0;

		// Token: 0x04008227 RID: 33319
		private static readonly IntPtr NativeMethodInfoPtr_GetChallengeLevel_Public_Static_MercenaryChallengeLevel_Int32_MercenaryOperationScale_0;

		// Token: 0x04008228 RID: 33320
		private static readonly IntPtr NativeMethodInfoPtr_GetChallengeLevelCaption_Public_Static_String_Int32_MercenaryOperationScale_Boolean_0;

		// Token: 0x04008229 RID: 33321
		private static readonly IntPtr NativeMethodInfoPtr_OverrideToCountUpFromStart_Public_Static_Boolean_MercenaryObjectives_0;

		// Token: 0x0400822A RID: 33322
		private static readonly IntPtr NativeMethodInfoPtr_GetEnemyCountForTier_Public_Int32_RandomWrapper_MercenaryOperationScale_Single_0;

		// Token: 0x0400822B RID: 33323
		private static readonly IntPtr NativeMethodInfoPtr_TryGetRoundDelta_Public_Boolean_Int32_byref_MercenaryRound_0;

		// Token: 0x0400822C RID: 33324
		private static readonly IntPtr NativeMethodInfoPtr_ProcessRoundSnapshots_Private_Void_Boolean_0;

		// Token: 0x0400822D RID: 33325
		private static readonly IntPtr NativeMethodInfoPtr_OnJoinInProgressContinue_Private_Void_0;

		// Token: 0x0400822E RID: 33326
		private static readonly IntPtr NativeMethodInfoPtr_OnJoinInProgressLeft_Private_Void_0;

		// Token: 0x0400822F RID: 33327
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000981 RID: 2433
		[ObfuscatedName("_Game.GameVariants.MercenaryMode.MercenaryVariant/<>c__DisplayClass36_0")]
		public sealed class __c__DisplayClass36_0 : Il2CppSystem.Object
		{
			// Token: 0x0600CDDE RID: 52702 RVA: 0x0033310C File Offset: 0x0033130C
			[CallerCount(0)]
			public unsafe __c__DisplayClass36_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.__c__DisplayClass36_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CDDF RID: 52703 RVA: 0x00333158 File Offset: 0x00331358
			[CallerCount(0)]
			public unsafe void _SpawnObjective_b__0(AsyncOperationHandle<GameObject> complete)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(complete));
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenaryVariant.__c__DisplayClass36_0.NativeMethodInfoPtr__SpawnObjective_b__0_Internal_Void_AsyncOperationHandle_1_GameObject_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CDE0 RID: 52704 RVA: 0x003331B8 File Offset: 0x003313B8
			// Note: this type is marked as 'beforefieldinit'.
			static __c__DisplayClass36_0()
			{
				Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr, "<>c__DisplayClass36_0");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr);
				MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr, "<>4__this");
				MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr_asyncOp = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr, "asyncOp");
				MercenaryVariant.__c__DisplayClass36_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr, 100679156);
				MercenaryVariant.__c__DisplayClass36_0.NativeMethodInfoPtr__SpawnObjective_b__0_Internal_Void_AsyncOperationHandle_1_GameObject_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr, 100679157);
			}

			// Token: 0x0600CDE1 RID: 52705 RVA: 0x00002988 File Offset: 0x00000B88
			public __c__DisplayClass36_0(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004AFA RID: 19194
			// (get) Token: 0x0600CDE2 RID: 52706 RVA: 0x00333233 File Offset: 0x00331433
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenaryVariant.__c__DisplayClass36_0>.NativeClassPtr));
				}
			}

			// Token: 0x17004AFB RID: 19195
			// (get) Token: 0x0600CDE3 RID: 52707 RVA: 0x00333244 File Offset: 0x00331444
			// (set) Token: 0x0600CDE4 RID: 52708 RVA: 0x00333278 File Offset: 0x00331478
			public unsafe MercenaryVariant __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new MercenaryVariant(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004AFC RID: 19196
			// (get) Token: 0x0600CDE5 RID: 52709 RVA: 0x003332A0 File Offset: 0x003314A0
			// (set) Token: 0x0600CDE6 RID: 52710 RVA: 0x003332D2 File Offset: 0x003314D2
			public AsyncOperationHandle<GameObject> asyncOp
			{
				get
				{
					IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr_asyncOp);
					return new AsyncOperationHandle<GameObject>(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AsyncOperationHandle<GameObject>>.NativeClassPtr, data));
				}
				set
				{
					cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenaryVariant.__c__DisplayClass36_0.NativeFieldInfoPtr_asyncOp), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<AsyncOperationHandle<GameObject>>.NativeClassPtr, (UIntPtr)0));
				}
			}

			// Token: 0x04008230 RID: 33328
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04008231 RID: 33329
			private static readonly IntPtr NativeFieldInfoPtr_asyncOp;

			// Token: 0x04008232 RID: 33330
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x04008233 RID: 33331
			private static readonly IntPtr NativeMethodInfoPtr__SpawnObjective_b__0_Internal_Void_AsyncOperationHandle_1_GameObject_0;
		}

		// Token: 0x02000982 RID: 2434
		private sealed class MethodInfoStoreGeneric_GetIntroTextForVariant_Private_String_0<T>
		{
			// Token: 0x04008234 RID: 33332
			internal static IntPtr Pointer = IL2CPP.il2cpp_method_get_from_reflection(IL2CPP.Il2CppObjectBaseToPtrNotNull(new MethodInfo(IL2CPP.il2cpp_method_get_object(MercenaryVariant.NativeMethodInfoPtr_GetIntroTextForVariant_Private_String_0, Il2CppClassPointerStore<MercenaryVariant>.NativeClassPtr)).MakeGenericMethod(new Il2CppReferenceArray<Type>(new Type[]
			{
				Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<T>.NativeClassPtr))
			}))));
		}
	}
}
