﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.MercenaryMode
{
	// Token: 0x0200097B RID: 2427
	public class MercenarySessionData : Object
	{
		// Token: 0x0600CD3C RID: 52540 RVA: 0x00330580 File Offset: 0x0032E780
		[CallerCount(0)]
		public unsafe MercenarySessionData(string roomName) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(roomName);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenarySessionData.NativeMethodInfoPtr__ctor_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CD3D RID: 52541 RVA: 0x003305E4 File Offset: 0x0032E7E4
		// Note: this type is marked as 'beforefieldinit'.
		static MercenarySessionData()
		{
			Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.MercenaryMode", "MercenarySessionData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr);
			MercenarySessionData.NativeFieldInfoPtr_UNINITIALIZED_ROOM_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "UNINITIALIZED_ROOM_NAME");
			MercenarySessionData.NativeFieldInfoPtr_CurrentStockpile = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "CurrentStockpile");
			MercenarySessionData.NativeFieldInfoPtr_RoomName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "RoomName");
			MercenarySessionData.NativeFieldInfoPtr_NextMissionOption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "NextMissionOption");
			MercenarySessionData.NativeFieldInfoPtr_CurrentRound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "CurrentRound");
			MercenarySessionData.NativeFieldInfoPtr_RoundSnapshots = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "RoundSnapshots");
			MercenarySessionData.NativeFieldInfoPtr_StartingRound = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "StartingRound");
			MercenarySessionData.NativeMethodInfoPtr__ctor_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, 100679103);
		}

		// Token: 0x0600CD3E RID: 52542 RVA: 0x00002988 File Offset: 0x00000B88
		public MercenarySessionData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004AC2 RID: 19138
		// (get) Token: 0x0600CD3F RID: 52543 RVA: 0x003306B4 File Offset: 0x0032E8B4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr));
			}
		}

		// Token: 0x17004AC3 RID: 19139
		// (get) Token: 0x0600CD40 RID: 52544 RVA: 0x003306C8 File Offset: 0x0032E8C8
		// (set) Token: 0x0600CD41 RID: 52545 RVA: 0x003306E8 File Offset: 0x0032E8E8
		public unsafe static string UNINITIALIZED_ROOM_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(MercenarySessionData.NativeFieldInfoPtr_UNINITIALIZED_ROOM_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(MercenarySessionData.NativeFieldInfoPtr_UNINITIALIZED_ROOM_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AC4 RID: 19140
		// (get) Token: 0x0600CD42 RID: 52546 RVA: 0x00330700 File Offset: 0x0032E900
		// (set) Token: 0x0600CD43 RID: 52547 RVA: 0x00330734 File Offset: 0x0032E934
		public unsafe MercenarySessionData.StockpileDescriptor CurrentStockpile
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_CurrentStockpile);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenarySessionData.StockpileDescriptor(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_CurrentStockpile), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AC5 RID: 19141
		// (get) Token: 0x0600CD44 RID: 52548 RVA: 0x0033075C File Offset: 0x0032E95C
		// (set) Token: 0x0600CD45 RID: 52549 RVA: 0x00330785 File Offset: 0x0032E985
		public unsafe string RoomName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_RoomName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_RoomName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004AC6 RID: 19142
		// (get) Token: 0x0600CD46 RID: 52550 RVA: 0x003307AC File Offset: 0x0032E9AC
		// (set) Token: 0x0600CD47 RID: 52551 RVA: 0x003307E0 File Offset: 0x0032E9E0
		public unsafe MercenaryMissionOptions NextMissionOption
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_NextMissionOption);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryMissionOptions(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_NextMissionOption), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AC7 RID: 19143
		// (get) Token: 0x0600CD48 RID: 52552 RVA: 0x00330808 File Offset: 0x0032EA08
		// (set) Token: 0x0600CD49 RID: 52553 RVA: 0x0033083A File Offset: 0x0032EA3A
		public MercenaryRound CurrentRound
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_CurrentRound);
				return new MercenaryRound(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_CurrentRound), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<MercenaryRound>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17004AC8 RID: 19144
		// (get) Token: 0x0600CD4A RID: 52554 RVA: 0x00330870 File Offset: 0x0032EA70
		// (set) Token: 0x0600CD4B RID: 52555 RVA: 0x003308A4 File Offset: 0x0032EAA4
		public unsafe MercenaryRoundSnapshotList RoundSnapshots
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_RoundSnapshots);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryRoundSnapshotList(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_RoundSnapshots), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AC9 RID: 19145
		// (get) Token: 0x0600CD4C RID: 52556 RVA: 0x003308CC File Offset: 0x0032EACC
		// (set) Token: 0x0600CD4D RID: 52557 RVA: 0x003308F4 File Offset: 0x0032EAF4
		public unsafe int StartingRound
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_StartingRound);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.NativeFieldInfoPtr_StartingRound)) = value;
			}
		}

		// Token: 0x040081CE RID: 33230
		private static readonly IntPtr NativeFieldInfoPtr_UNINITIALIZED_ROOM_NAME;

		// Token: 0x040081CF RID: 33231
		private static readonly IntPtr NativeFieldInfoPtr_CurrentStockpile;

		// Token: 0x040081D0 RID: 33232
		private static readonly IntPtr NativeFieldInfoPtr_RoomName;

		// Token: 0x040081D1 RID: 33233
		private static readonly IntPtr NativeFieldInfoPtr_NextMissionOption;

		// Token: 0x040081D2 RID: 33234
		private static readonly IntPtr NativeFieldInfoPtr_CurrentRound;

		// Token: 0x040081D3 RID: 33235
		private static readonly IntPtr NativeFieldInfoPtr_RoundSnapshots;

		// Token: 0x040081D4 RID: 33236
		private static readonly IntPtr NativeFieldInfoPtr_StartingRound;

		// Token: 0x040081D5 RID: 33237
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_0;

		// Token: 0x0200097C RID: 2428
		public class StockpileDescriptor : Object
		{
			// Token: 0x0600CD4E RID: 52558 RVA: 0x00330918 File Offset: 0x0032EB18
			[CallerCount(0)]
			public unsafe StockpileDescriptor() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(MercenarySessionData.StockpileDescriptor.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CD4F RID: 52559 RVA: 0x00330964 File Offset: 0x0032EB64
			// Note: this type is marked as 'beforefieldinit'.
			static StockpileDescriptor()
			{
				Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<MercenarySessionData>.NativeClassPtr, "StockpileDescriptor");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr);
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_ClassLoadout = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "ClassLoadout");
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "PrimaryAttachments");
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryAttachments = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "SecondaryAttachments");
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_AmmoTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "AmmoTypes");
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryMagazines = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "PrimaryMagazines");
				MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryMagazines = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, "SecondaryMagazines");
				MercenarySessionData.StockpileDescriptor.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr, 100679104);
			}

			// Token: 0x0600CD50 RID: 52560 RVA: 0x00002988 File Offset: 0x00000B88
			public StockpileDescriptor(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004ACA RID: 19146
			// (get) Token: 0x0600CD51 RID: 52561 RVA: 0x00330A1B File Offset: 0x0032EC1B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<MercenarySessionData.StockpileDescriptor>.NativeClassPtr));
				}
			}

			// Token: 0x17004ACB RID: 19147
			// (get) Token: 0x0600CD52 RID: 52562 RVA: 0x00330A2C File Offset: 0x0032EC2C
			// (set) Token: 0x0600CD53 RID: 52563 RVA: 0x00330A60 File Offset: 0x0032EC60
			public unsafe ClassLoadout ClassLoadout
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_ClassLoadout);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new ClassLoadout(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_ClassLoadout), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004ACC RID: 19148
			// (get) Token: 0x0600CD54 RID: 52564 RVA: 0x00330A88 File Offset: 0x0032EC88
			// (set) Token: 0x0600CD55 RID: 52565 RVA: 0x00330ABC File Offset: 0x0032ECBC
			public unsafe List<WeaponAttachment.AttachmentType> PrimaryAttachments
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryAttachments);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryAttachments), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004ACD RID: 19149
			// (get) Token: 0x0600CD56 RID: 52566 RVA: 0x00330AE4 File Offset: 0x0032ECE4
			// (set) Token: 0x0600CD57 RID: 52567 RVA: 0x00330B18 File Offset: 0x0032ED18
			public unsafe List<WeaponAttachment.AttachmentType> SecondaryAttachments
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryAttachments);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new List<WeaponAttachment.AttachmentType>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryAttachments), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004ACE RID: 19150
			// (get) Token: 0x0600CD58 RID: 52568 RVA: 0x00330B40 File Offset: 0x0032ED40
			// (set) Token: 0x0600CD59 RID: 52569 RVA: 0x00330B74 File Offset: 0x0032ED74
			public unsafe List<ClassLoadout.AmmoType> AmmoTypes
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_AmmoTypes);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new List<ClassLoadout.AmmoType>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_AmmoTypes), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004ACF RID: 19151
			// (get) Token: 0x0600CD5A RID: 52570 RVA: 0x00330B9C File Offset: 0x0032ED9C
			// (set) Token: 0x0600CD5B RID: 52571 RVA: 0x00330BC4 File Offset: 0x0032EDC4
			public unsafe int PrimaryMagazines
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryMagazines);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_PrimaryMagazines)) = value;
				}
			}

			// Token: 0x17004AD0 RID: 19152
			// (get) Token: 0x0600CD5C RID: 52572 RVA: 0x00330BE8 File Offset: 0x0032EDE8
			// (set) Token: 0x0600CD5D RID: 52573 RVA: 0x00330C10 File Offset: 0x0032EE10
			public unsafe int SecondaryMagazines
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryMagazines);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(MercenarySessionData.StockpileDescriptor.NativeFieldInfoPtr_SecondaryMagazines)) = value;
				}
			}

			// Token: 0x040081D6 RID: 33238
			private static readonly IntPtr NativeFieldInfoPtr_ClassLoadout;

			// Token: 0x040081D7 RID: 33239
			private static readonly IntPtr NativeFieldInfoPtr_PrimaryAttachments;

			// Token: 0x040081D8 RID: 33240
			private static readonly IntPtr NativeFieldInfoPtr_SecondaryAttachments;

			// Token: 0x040081D9 RID: 33241
			private static readonly IntPtr NativeFieldInfoPtr_AmmoTypes;

			// Token: 0x040081DA RID: 33242
			private static readonly IntPtr NativeFieldInfoPtr_PrimaryMagazines;

			// Token: 0x040081DB RID: 33243
			private static readonly IntPtr NativeFieldInfoPtr_SecondaryMagazines;

			// Token: 0x040081DC RID: 33244
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}
	}
}
