﻿using System;
using Il2CppSystem;
using Onward.GameManagement;
using Onward.GameVariants;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000958 RID: 2392
	public class UplinkObjective : BaseObjective
	{
		// Token: 0x170049F6 RID: 18934
		// (get) Token: 0x0600CB13 RID: 51987 RVA: 0x003282EC File Offset: 0x003264EC
		public new unsafe ObjectiveTypes ObjectiveType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049F7 RID: 18935
		// (get) Token: 0x0600CB14 RID: 51988 RVA: 0x00328348 File Offset: 0x00326548
		public unsafe UplinkState UplinkState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_get_UplinkState_Public_get_UplinkState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049F8 RID: 18936
		// (get) Token: 0x0600CB15 RID: 51989 RVA: 0x00328398 File Offset: 0x00326598
		// (set) Token: 0x0600CB16 RID: 51990 RVA: 0x003283E8 File Offset: 0x003265E8
		public unsafe UplinkMode UplinkMode
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_get_UplinkMode_Public_get_UplinkMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_set_UplinkMode_Private_set_Void_UplinkMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170049F9 RID: 18937
		// (get) Token: 0x0600CB17 RID: 51991 RVA: 0x0032843C File Offset: 0x0032663C
		public new unsafe RoundEndTypes ObjectiveCompleteEndType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CB18 RID: 51992 RVA: 0x00328498 File Offset: 0x00326698
		[CallerCount(0)]
		public unsafe void AddUplinkStateChangedListener(Action<UplinkState, double, double> action)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(action);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_AddUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB19 RID: 51993 RVA: 0x003284F4 File Offset: 0x003266F4
		[CallerCount(0)]
		public unsafe void RemoveUplinkStateChangedListener(Action<UplinkState, double, double> action)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(action);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_RemoveUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170049FA RID: 18938
		// (get) Token: 0x0600CB1A RID: 51994 RVA: 0x00328550 File Offset: 0x00326750
		public unsafe OnwardPhotonPlayer SendingPlayer
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_get_SendingPlayer_Public_get_OnwardPhotonPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new OnwardPhotonPlayer(intPtr2) : null;
			}
		}

		// Token: 0x0600CB1B RID: 51995 RVA: 0x003285A8 File Offset: 0x003267A8
		[CallerCount(0)]
		public new unsafe void Initialize(GameVariant owner, BaseObjectiveData objectiveData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(objectiveData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB1C RID: 51996 RVA: 0x00328624 File Offset: 0x00326824
		[CallerCount(0)]
		public unsafe void AddStateChangeEvent(Action<UplinkState, double, double> newEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(newEvent);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_AddStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB1D RID: 51997 RVA: 0x00328680 File Offset: 0x00326880
		[CallerCount(0)]
		public unsafe void RemoveStateChangeEvent(Action<UplinkState, double, double> removedEvent)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(removedEvent);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_RemoveStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB1E RID: 51998 RVA: 0x003286DC File Offset: 0x003268DC
		[CallerCount(0)]
		public new unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB1F RID: 51999 RVA: 0x0032872C File Offset: 0x0032692C
		[CallerCount(0)]
		public new unsafe void TickShared()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB20 RID: 52000 RVA: 0x0032877C File Offset: 0x0032697C
		[CallerCount(0)]
		public unsafe void UplinkSendingComplete()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_UplinkSendingComplete_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB21 RID: 52001 RVA: 0x003287C0 File Offset: 0x003269C0
		[CallerCount(0)]
		public new unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB22 RID: 52002 RVA: 0x00328810 File Offset: 0x00326A10
		[CallerCount(0)]
		public unsafe void SetCode()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_SetCode_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB23 RID: 52003 RVA: 0x00328860 File Offset: 0x00326A60
		[CallerCount(0)]
		public unsafe float GetTimeRemaining(bool isCancelTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isCancelTime;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkObjective.NativeMethodInfoPtr_GetTimeRemaining_Public_Virtual_New_Single_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CB24 RID: 52004 RVA: 0x003288D0 File Offset: 0x00326AD0
		[CallerCount(0)]
		public unsafe void OnUplinkStateChanged(UplinkState state, double startTime, double endTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref state;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref startTime;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref endTime;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr_OnUplinkStateChanged_Private_Void_UplinkState_Double_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB25 RID: 52005 RVA: 0x0032894C File Offset: 0x00326B4C
		[CallerCount(0)]
		public unsafe UplinkObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB26 RID: 52006 RVA: 0x00328998 File Offset: 0x00326B98
		// Note: this type is marked as 'beforefieldinit'.
		static UplinkObjective()
		{
			Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "UplinkObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr);
			UplinkObjective.NativeFieldInfoPtr_OnUpdateStateChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "OnUpdateStateChanged");
			UplinkObjective.NativeFieldInfoPtr_USE_DEBUG_CODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "USE_DEBUG_CODE");
			UplinkObjective.NativeFieldInfoPtr_LengthOfUplinkCode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "LengthOfUplinkCode");
			UplinkObjective.NativeFieldInfoPtr__UplinkMode_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "<UplinkMode>k__BackingField");
			UplinkObjective.NativeFieldInfoPtr__uplinkSubtype = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "_uplinkSubtype");
			UplinkObjective.NativeFieldInfoPtr_Code = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, "Code");
			UplinkObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678956);
			UplinkObjective.NativeMethodInfoPtr_get_UplinkState_Public_get_UplinkState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678957);
			UplinkObjective.NativeMethodInfoPtr_get_UplinkMode_Public_get_UplinkMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678958);
			UplinkObjective.NativeMethodInfoPtr_set_UplinkMode_Private_set_Void_UplinkMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678959);
			UplinkObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678960);
			UplinkObjective.NativeMethodInfoPtr_AddUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678961);
			UplinkObjective.NativeMethodInfoPtr_RemoveUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678962);
			UplinkObjective.NativeMethodInfoPtr_get_SendingPlayer_Public_get_OnwardPhotonPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678963);
			UplinkObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678964);
			UplinkObjective.NativeMethodInfoPtr_AddStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678965);
			UplinkObjective.NativeMethodInfoPtr_RemoveStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678966);
			UplinkObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678967);
			UplinkObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678968);
			UplinkObjective.NativeMethodInfoPtr_UplinkSendingComplete_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678969);
			UplinkObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678970);
			UplinkObjective.NativeMethodInfoPtr_SetCode_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678971);
			UplinkObjective.NativeMethodInfoPtr_GetTimeRemaining_Public_Virtual_New_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678972);
			UplinkObjective.NativeMethodInfoPtr_OnUplinkStateChanged_Private_Void_UplinkState_Double_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678973);
			UplinkObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr, 100678974);
		}

		// Token: 0x0600CB27 RID: 52007 RVA: 0x00328BBC File Offset: 0x00326DBC
		public UplinkObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049EF RID: 18927
		// (get) Token: 0x0600CB28 RID: 52008 RVA: 0x00328BC5 File Offset: 0x00326DC5
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UplinkObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170049F0 RID: 18928
		// (get) Token: 0x0600CB29 RID: 52009 RVA: 0x00328BD8 File Offset: 0x00326DD8
		// (set) Token: 0x0600CB2A RID: 52010 RVA: 0x00328C03 File Offset: 0x00326E03
		public unsafe static Action<UplinkState> OnUpdateStateChanged
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(UplinkObjective.NativeFieldInfoPtr_OnUpdateStateChanged, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action<UplinkState>(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(UplinkObjective.NativeFieldInfoPtr_OnUpdateStateChanged, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049F1 RID: 18929
		// (get) Token: 0x0600CB2B RID: 52011 RVA: 0x00328C18 File Offset: 0x00326E18
		// (set) Token: 0x0600CB2C RID: 52012 RVA: 0x00328C36 File Offset: 0x00326E36
		public unsafe static bool USE_DEBUG_CODE
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(UplinkObjective.NativeFieldInfoPtr_USE_DEBUG_CODE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(UplinkObjective.NativeFieldInfoPtr_USE_DEBUG_CODE, (void*)(&value));
			}
		}

		// Token: 0x170049F2 RID: 18930
		// (get) Token: 0x0600CB2D RID: 52013 RVA: 0x00328C48 File Offset: 0x00326E48
		// (set) Token: 0x0600CB2E RID: 52014 RVA: 0x00328C70 File Offset: 0x00326E70
		public unsafe int LengthOfUplinkCode
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr_LengthOfUplinkCode);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr_LengthOfUplinkCode)) = value;
			}
		}

		// Token: 0x170049F3 RID: 18931
		// (get) Token: 0x0600CB2F RID: 52015 RVA: 0x00328C94 File Offset: 0x00326E94
		// (set) Token: 0x0600CB30 RID: 52016 RVA: 0x00328CBC File Offset: 0x00326EBC
		public unsafe UplinkMode _UplinkMode_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr__UplinkMode_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr__UplinkMode_k__BackingField)) = value;
			}
		}

		// Token: 0x170049F4 RID: 18932
		// (get) Token: 0x0600CB31 RID: 52017 RVA: 0x00328CE0 File Offset: 0x00326EE0
		// (set) Token: 0x0600CB32 RID: 52018 RVA: 0x00328D14 File Offset: 0x00326F14
		public unsafe UplinkSubtype _uplinkSubtype
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr__uplinkSubtype);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UplinkSubtype(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr__uplinkSubtype), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049F5 RID: 18933
		// (get) Token: 0x0600CB33 RID: 52019 RVA: 0x00328D3C File Offset: 0x00326F3C
		// (set) Token: 0x0600CB34 RID: 52020 RVA: 0x00328D70 File Offset: 0x00326F70
		public unsafe Il2CppStructArray<int> Code
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr_Code);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjective.NativeFieldInfoPtr_Code), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400805F RID: 32863
		private static readonly IntPtr NativeFieldInfoPtr_OnUpdateStateChanged;

		// Token: 0x04008060 RID: 32864
		private static readonly IntPtr NativeFieldInfoPtr_USE_DEBUG_CODE;

		// Token: 0x04008061 RID: 32865
		private static readonly IntPtr NativeFieldInfoPtr_LengthOfUplinkCode;

		// Token: 0x04008062 RID: 32866
		private static readonly IntPtr NativeFieldInfoPtr__UplinkMode_k__BackingField;

		// Token: 0x04008063 RID: 32867
		private static readonly IntPtr NativeFieldInfoPtr__uplinkSubtype;

		// Token: 0x04008064 RID: 32868
		private static readonly IntPtr NativeFieldInfoPtr_Code;

		// Token: 0x04008065 RID: 32869
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0;

		// Token: 0x04008066 RID: 32870
		private static readonly IntPtr NativeMethodInfoPtr_get_UplinkState_Public_get_UplinkState_0;

		// Token: 0x04008067 RID: 32871
		private static readonly IntPtr NativeMethodInfoPtr_get_UplinkMode_Public_get_UplinkMode_0;

		// Token: 0x04008068 RID: 32872
		private static readonly IntPtr NativeMethodInfoPtr_set_UplinkMode_Private_set_Void_UplinkMode_0;

		// Token: 0x04008069 RID: 32873
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0;

		// Token: 0x0400806A RID: 32874
		private static readonly IntPtr NativeMethodInfoPtr_AddUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0;

		// Token: 0x0400806B RID: 32875
		private static readonly IntPtr NativeMethodInfoPtr_RemoveUplinkStateChangedListener_Public_Void_Action_3_UplinkState_Double_Double_0;

		// Token: 0x0400806C RID: 32876
		private static readonly IntPtr NativeMethodInfoPtr_get_SendingPlayer_Public_get_OnwardPhotonPlayer_0;

		// Token: 0x0400806D RID: 32877
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0;

		// Token: 0x0400806E RID: 32878
		private static readonly IntPtr NativeMethodInfoPtr_AddStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0;

		// Token: 0x0400806F RID: 32879
		private static readonly IntPtr NativeMethodInfoPtr_RemoveStateChangeEvent_Public_Void_Action_3_UplinkState_Double_Double_0;

		// Token: 0x04008070 RID: 32880
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0;

		// Token: 0x04008071 RID: 32881
		private static readonly IntPtr NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0;

		// Token: 0x04008072 RID: 32882
		private static readonly IntPtr NativeMethodInfoPtr_UplinkSendingComplete_Public_Void_0;

		// Token: 0x04008073 RID: 32883
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0;

		// Token: 0x04008074 RID: 32884
		private static readonly IntPtr NativeMethodInfoPtr_SetCode_Protected_Virtual_New_Void_0;

		// Token: 0x04008075 RID: 32885
		private static readonly IntPtr NativeMethodInfoPtr_GetTimeRemaining_Public_Virtual_New_Single_Boolean_0;

		// Token: 0x04008076 RID: 32886
		private static readonly IntPtr NativeMethodInfoPtr_OnUplinkStateChanged_Private_Void_UplinkState_Double_Double_0;

		// Token: 0x04008077 RID: 32887
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
