﻿using System;
using Il2CppSystem;
using Onward.AI.Objectives;
using Onward.GameManagement;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Hunt
{
	// Token: 0x0200095E RID: 2398
	public class HuntObjective : BaseObjective
	{
		// Token: 0x17004A1C RID: 18972
		// (get) Token: 0x0600CB92 RID: 52114 RVA: 0x0032A608 File Offset: 0x00328808
		public new unsafe Onward.GameVariants.ObjectiveTypes ObjectiveType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), HuntObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A1D RID: 18973
		// (get) Token: 0x0600CB93 RID: 52115 RVA: 0x0032A664 File Offset: 0x00328864
		public new unsafe RoundEndTypes ObjectiveCompleteEndType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), HuntObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A1E RID: 18974
		// (get) Token: 0x0600CB94 RID: 52116 RVA: 0x0032A6C0 File Offset: 0x003288C0
		public new unsafe ActivateObjectiveState ActivateObjectiveState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), HuntObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CB95 RID: 52117 RVA: 0x0032A71C File Offset: 0x0032891C
		[CallerCount(0)]
		public new unsafe void ActivateObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), HuntObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB96 RID: 52118 RVA: 0x0032A76C File Offset: 0x0032896C
		[CallerCount(0)]
		public unsafe void OnAIDied()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntObjective.NativeMethodInfoPtr_OnAIDied_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB97 RID: 52119 RVA: 0x0032A7B0 File Offset: 0x003289B0
		[CallerCount(0)]
		public unsafe HuntObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB98 RID: 52120 RVA: 0x0032A7FC File Offset: 0x003289FC
		// Note: this type is marked as 'beforefieldinit'.
		static HuntObjective()
		{
			Il2CppClassPointerStore<HuntObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Hunt", "HuntObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr);
			HuntObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679009);
			HuntObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679010);
			HuntObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679011);
			HuntObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679012);
			HuntObjective.NativeMethodInfoPtr_OnAIDied_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679013);
			HuntObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr, 100679014);
		}

		// Token: 0x0600CB99 RID: 52121 RVA: 0x00328BBC File Offset: 0x00326DBC
		public HuntObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A1B RID: 18971
		// (get) Token: 0x0600CB9A RID: 52122 RVA: 0x0032A8A4 File Offset: 0x00328AA4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HuntObjective>.NativeClassPtr));
			}
		}

		// Token: 0x040080B0 RID: 32944
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0;

		// Token: 0x040080B1 RID: 32945
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0;

		// Token: 0x040080B2 RID: 32946
		private static readonly IntPtr NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0;

		// Token: 0x040080B3 RID: 32947
		private static readonly IntPtr NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0;

		// Token: 0x040080B4 RID: 32948
		private static readonly IntPtr NativeMethodInfoPtr_OnAIDied_Private_Void_0;

		// Token: 0x040080B5 RID: 32949
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
