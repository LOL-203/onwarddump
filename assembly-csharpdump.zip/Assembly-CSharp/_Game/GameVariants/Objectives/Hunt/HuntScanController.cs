﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.Objectives.Hunt
{
	// Token: 0x02000960 RID: 2400
	public class HuntScanController : MonoBehaviour
	{
		// Token: 0x17004A31 RID: 18993
		// (get) Token: 0x0600CB9F RID: 52127 RVA: 0x0032A950 File Offset: 0x00328B50
		public unsafe HuntScanProperties ScanProperties
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_get_ScanProperties_Public_get_HuntScanProperties_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return new HuntScanProperties(intPtr);
			}
		}

		// Token: 0x17004A32 RID: 18994
		// (get) Token: 0x0600CBA0 RID: 52128 RVA: 0x0032A99C File Offset: 0x00328B9C
		public unsafe float Progress
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_get_Progress_Public_get_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A33 RID: 18995
		// (get) Token: 0x0600CBA1 RID: 52129 RVA: 0x0032A9EC File Offset: 0x00328BEC
		// (set) Token: 0x0600CBA2 RID: 52130 RVA: 0x0032AA3C File Offset: 0x00328C3C
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600CBA3 RID: 52131 RVA: 0x0032AA90 File Offset: 0x00328C90
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA4 RID: 52132 RVA: 0x0032AAD4 File Offset: 0x00328CD4
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA5 RID: 52133 RVA: 0x0032AB18 File Offset: 0x00328D18
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA6 RID: 52134 RVA: 0x0032AB5C File Offset: 0x00328D5C
		[CallerCount(0)]
		public unsafe void UpdateAICounts()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_UpdateAICounts_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA7 RID: 52135 RVA: 0x0032ABA0 File Offset: 0x00328DA0
		[CallerCount(0)]
		public unsafe void UpdateStandby()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_UpdateStandby_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA8 RID: 52136 RVA: 0x0032ABE4 File Offset: 0x00328DE4
		[CallerCount(0)]
		public unsafe void UpdateOther()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_UpdateOther_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBA9 RID: 52137 RVA: 0x0032AC28 File Offset: 0x00328E28
		[CallerCount(0)]
		public unsafe void MarkRandomAI()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_MarkRandomAI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBAA RID: 52138 RVA: 0x0032AC6C File Offset: 0x00328E6C
		[CallerCount(0)]
		public unsafe HuntScanState GetCurrentScanState()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_GetCurrentScanState_Private_HuntScanState_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBAB RID: 52139 RVA: 0x0032ACBC File Offset: 0x00328EBC
		[CallerCount(0)]
		public unsafe void SetState(HuntScanState newState, bool force = false)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newState;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref force;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_SetState_Private_Void_HuntScanState_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBAC RID: 52140 RVA: 0x0032AD24 File Offset: 0x00328F24
		[CallerCount(0)]
		public unsafe void ResetTimer()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr_ResetTimer_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBAD RID: 52141 RVA: 0x0032AD68 File Offset: 0x00328F68
		[CallerCount(0)]
		public unsafe HuntScanController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntScanController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBAE RID: 52142 RVA: 0x0032ADB4 File Offset: 0x00328FB4
		// Note: this type is marked as 'beforefieldinit'.
		static HuntScanController()
		{
			Il2CppClassPointerStore<HuntScanController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Hunt", "HuntScanController");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr);
			HuntScanController.NativeFieldInfoPtr_Singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "Singleton");
			HuntScanController.NativeFieldInfoPtr_OnControllerStateChange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "OnControllerStateChange");
			HuntScanController.NativeFieldInfoPtr_MarkedAIMaximum = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "MarkedAIMaximum");
			HuntScanController.NativeFieldInfoPtr_StandbyMinutesSlope = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "StandbyMinutesSlope");
			HuntScanController.NativeFieldInfoPtr_StandbyMinutesIntercept = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "StandbyMinutesIntercept");
			HuntScanController.NativeFieldInfoPtr_DebugPrintStandbyBotCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "DebugPrintStandbyBotCount");
			HuntScanController.NativeFieldInfoPtr_Properties = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "Properties");
			HuntScanController.NativeFieldInfoPtr__properties = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_properties");
			HuntScanController.NativeFieldInfoPtr__random = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_random");
			HuntScanController.NativeFieldInfoPtr__timer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_timer");
			HuntScanController.NativeFieldInfoPtr__markedAI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_markedAI");
			HuntScanController.NativeFieldInfoPtr__livingAI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_livingAI");
			HuntScanController.NativeFieldInfoPtr__totalAI = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_totalAI");
			HuntScanController.NativeFieldInfoPtr__scanState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_scanState");
			HuntScanController.NativeFieldInfoPtr__scanProperties = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "_scanProperties");
			HuntScanController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			HuntScanController.NativeMethodInfoPtr_get_ScanProperties_Public_get_HuntScanProperties_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679016);
			HuntScanController.NativeMethodInfoPtr_get_Progress_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679017);
			HuntScanController.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679018);
			HuntScanController.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679019);
			HuntScanController.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679020);
			HuntScanController.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679021);
			HuntScanController.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679022);
			HuntScanController.NativeMethodInfoPtr_UpdateAICounts_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679023);
			HuntScanController.NativeMethodInfoPtr_UpdateStandby_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679024);
			HuntScanController.NativeMethodInfoPtr_UpdateOther_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679025);
			HuntScanController.NativeMethodInfoPtr_MarkRandomAI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679026);
			HuntScanController.NativeMethodInfoPtr_GetCurrentScanState_Private_HuntScanState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679027);
			HuntScanController.NativeMethodInfoPtr_SetState_Private_Void_HuntScanState_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679028);
			HuntScanController.NativeMethodInfoPtr_ResetTimer_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679029);
			HuntScanController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr, 100679030);
		}

		// Token: 0x0600CBAF RID: 52143 RVA: 0x0000210C File Offset: 0x0000030C
		public HuntScanController(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A20 RID: 18976
		// (get) Token: 0x0600CBB0 RID: 52144 RVA: 0x0032B050 File Offset: 0x00329250
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HuntScanController>.NativeClassPtr));
			}
		}

		// Token: 0x17004A21 RID: 18977
		// (get) Token: 0x0600CBB1 RID: 52145 RVA: 0x0032B064 File Offset: 0x00329264
		// (set) Token: 0x0600CBB2 RID: 52146 RVA: 0x0032B08F File Offset: 0x0032928F
		public unsafe static HuntScanController Singleton
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(HuntScanController.NativeFieldInfoPtr_Singleton, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new HuntScanController(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(HuntScanController.NativeFieldInfoPtr_Singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A22 RID: 18978
		// (get) Token: 0x0600CBB3 RID: 52147 RVA: 0x0032B0A4 File Offset: 0x003292A4
		// (set) Token: 0x0600CBB4 RID: 52148 RVA: 0x0032B0CF File Offset: 0x003292CF
		public unsafe static Action OnControllerStateChange
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(HuntScanController.NativeFieldInfoPtr_OnControllerStateChange, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(HuntScanController.NativeFieldInfoPtr_OnControllerStateChange, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A23 RID: 18979
		// (get) Token: 0x0600CBB5 RID: 52149 RVA: 0x0032B0E4 File Offset: 0x003292E4
		// (set) Token: 0x0600CBB6 RID: 52150 RVA: 0x0032B10C File Offset: 0x0032930C
		public unsafe int MarkedAIMaximum
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_MarkedAIMaximum);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_MarkedAIMaximum)) = value;
			}
		}

		// Token: 0x17004A24 RID: 18980
		// (get) Token: 0x0600CBB7 RID: 52151 RVA: 0x0032B130 File Offset: 0x00329330
		// (set) Token: 0x0600CBB8 RID: 52152 RVA: 0x0032B158 File Offset: 0x00329358
		public unsafe float StandbyMinutesSlope
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_StandbyMinutesSlope);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_StandbyMinutesSlope)) = value;
			}
		}

		// Token: 0x17004A25 RID: 18981
		// (get) Token: 0x0600CBB9 RID: 52153 RVA: 0x0032B17C File Offset: 0x0032937C
		// (set) Token: 0x0600CBBA RID: 52154 RVA: 0x0032B1A4 File Offset: 0x003293A4
		public unsafe float StandbyMinutesIntercept
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_StandbyMinutesIntercept);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_StandbyMinutesIntercept)) = value;
			}
		}

		// Token: 0x17004A26 RID: 18982
		// (get) Token: 0x0600CBBB RID: 52155 RVA: 0x0032B1C8 File Offset: 0x003293C8
		// (set) Token: 0x0600CBBC RID: 52156 RVA: 0x0032B1F0 File Offset: 0x003293F0
		public unsafe int DebugPrintStandbyBotCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_DebugPrintStandbyBotCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_DebugPrintStandbyBotCount)) = value;
			}
		}

		// Token: 0x17004A27 RID: 18983
		// (get) Token: 0x0600CBBD RID: 52157 RVA: 0x0032B214 File Offset: 0x00329414
		// (set) Token: 0x0600CBBE RID: 52158 RVA: 0x0032B248 File Offset: 0x00329448
		public unsafe Il2CppReferenceArray<HuntScanProperties> Properties
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_Properties);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<HuntScanProperties>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr_Properties), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A28 RID: 18984
		// (get) Token: 0x0600CBBF RID: 52159 RVA: 0x0032B270 File Offset: 0x00329470
		// (set) Token: 0x0600CBC0 RID: 52160 RVA: 0x0032B2A4 File Offset: 0x003294A4
		public unsafe Dictionary<HuntScanState, HuntScanProperties> _properties
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__properties);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Dictionary<HuntScanState, HuntScanProperties>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__properties), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A29 RID: 18985
		// (get) Token: 0x0600CBC1 RID: 52161 RVA: 0x0032B2CC File Offset: 0x003294CC
		// (set) Token: 0x0600CBC2 RID: 52162 RVA: 0x0032B300 File Offset: 0x00329500
		public unsafe Il2CppSystem.Random _random
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__random);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppSystem.Random(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__random), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A2A RID: 18986
		// (get) Token: 0x0600CBC3 RID: 52163 RVA: 0x0032B328 File Offset: 0x00329528
		// (set) Token: 0x0600CBC4 RID: 52164 RVA: 0x0032B350 File Offset: 0x00329550
		public unsafe float _timer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__timer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__timer)) = value;
			}
		}

		// Token: 0x17004A2B RID: 18987
		// (get) Token: 0x0600CBC5 RID: 52165 RVA: 0x0032B374 File Offset: 0x00329574
		// (set) Token: 0x0600CBC6 RID: 52166 RVA: 0x0032B39C File Offset: 0x0032959C
		public unsafe int _markedAI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__markedAI);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__markedAI)) = value;
			}
		}

		// Token: 0x17004A2C RID: 18988
		// (get) Token: 0x0600CBC7 RID: 52167 RVA: 0x0032B3C0 File Offset: 0x003295C0
		// (set) Token: 0x0600CBC8 RID: 52168 RVA: 0x0032B3E8 File Offset: 0x003295E8
		public unsafe int _livingAI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__livingAI);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__livingAI)) = value;
			}
		}

		// Token: 0x17004A2D RID: 18989
		// (get) Token: 0x0600CBC9 RID: 52169 RVA: 0x0032B40C File Offset: 0x0032960C
		// (set) Token: 0x0600CBCA RID: 52170 RVA: 0x0032B434 File Offset: 0x00329634
		public unsafe int _totalAI
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__totalAI);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__totalAI)) = value;
			}
		}

		// Token: 0x17004A2E RID: 18990
		// (get) Token: 0x0600CBCB RID: 52171 RVA: 0x0032B458 File Offset: 0x00329658
		// (set) Token: 0x0600CBCC RID: 52172 RVA: 0x0032B480 File Offset: 0x00329680
		public unsafe HuntScanState _scanState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__scanState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__scanState)) = value;
			}
		}

		// Token: 0x17004A2F RID: 18991
		// (get) Token: 0x0600CBCD RID: 52173 RVA: 0x0032B4A4 File Offset: 0x003296A4
		// (set) Token: 0x0600CBCE RID: 52174 RVA: 0x0032B4D6 File Offset: 0x003296D6
		public HuntScanProperties _scanProperties
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__scanProperties);
				return new HuntScanProperties(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__scanProperties), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17004A30 RID: 18992
		// (get) Token: 0x0600CBCF RID: 52175 RVA: 0x0032B50C File Offset: 0x0032970C
		// (set) Token: 0x0600CBD0 RID: 52176 RVA: 0x0032B534 File Offset: 0x00329734
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanController.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x040080B7 RID: 32951
		private static readonly IntPtr NativeFieldInfoPtr_Singleton;

		// Token: 0x040080B8 RID: 32952
		private static readonly IntPtr NativeFieldInfoPtr_OnControllerStateChange;

		// Token: 0x040080B9 RID: 32953
		private static readonly IntPtr NativeFieldInfoPtr_MarkedAIMaximum;

		// Token: 0x040080BA RID: 32954
		private static readonly IntPtr NativeFieldInfoPtr_StandbyMinutesSlope;

		// Token: 0x040080BB RID: 32955
		private static readonly IntPtr NativeFieldInfoPtr_StandbyMinutesIntercept;

		// Token: 0x040080BC RID: 32956
		private static readonly IntPtr NativeFieldInfoPtr_DebugPrintStandbyBotCount;

		// Token: 0x040080BD RID: 32957
		private static readonly IntPtr NativeFieldInfoPtr_Properties;

		// Token: 0x040080BE RID: 32958
		private static readonly IntPtr NativeFieldInfoPtr__properties;

		// Token: 0x040080BF RID: 32959
		private static readonly IntPtr NativeFieldInfoPtr__random;

		// Token: 0x040080C0 RID: 32960
		private static readonly IntPtr NativeFieldInfoPtr__timer;

		// Token: 0x040080C1 RID: 32961
		private static readonly IntPtr NativeFieldInfoPtr__markedAI;

		// Token: 0x040080C2 RID: 32962
		private static readonly IntPtr NativeFieldInfoPtr__livingAI;

		// Token: 0x040080C3 RID: 32963
		private static readonly IntPtr NativeFieldInfoPtr__totalAI;

		// Token: 0x040080C4 RID: 32964
		private static readonly IntPtr NativeFieldInfoPtr__scanState;

		// Token: 0x040080C5 RID: 32965
		private static readonly IntPtr NativeFieldInfoPtr__scanProperties;

		// Token: 0x040080C6 RID: 32966
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x040080C7 RID: 32967
		private static readonly IntPtr NativeMethodInfoPtr_get_ScanProperties_Public_get_HuntScanProperties_0;

		// Token: 0x040080C8 RID: 32968
		private static readonly IntPtr NativeMethodInfoPtr_get_Progress_Public_get_Single_0;

		// Token: 0x040080C9 RID: 32969
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x040080CA RID: 32970
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x040080CB RID: 32971
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x040080CC RID: 32972
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x040080CD RID: 32973
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x040080CE RID: 32974
		private static readonly IntPtr NativeMethodInfoPtr_UpdateAICounts_Private_Void_0;

		// Token: 0x040080CF RID: 32975
		private static readonly IntPtr NativeMethodInfoPtr_UpdateStandby_Private_Void_0;

		// Token: 0x040080D0 RID: 32976
		private static readonly IntPtr NativeMethodInfoPtr_UpdateOther_Private_Void_0;

		// Token: 0x040080D1 RID: 32977
		private static readonly IntPtr NativeMethodInfoPtr_MarkRandomAI_Private_Void_0;

		// Token: 0x040080D2 RID: 32978
		private static readonly IntPtr NativeMethodInfoPtr_GetCurrentScanState_Private_HuntScanState_0;

		// Token: 0x040080D3 RID: 32979
		private static readonly IntPtr NativeMethodInfoPtr_SetState_Private_Void_HuntScanState_Boolean_0;

		// Token: 0x040080D4 RID: 32980
		private static readonly IntPtr NativeMethodInfoPtr_ResetTimer_Private_Void_0;

		// Token: 0x040080D5 RID: 32981
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
