﻿using System;

namespace _Game.GameVariants.Objectives.Hunt
{
	// Token: 0x02000962 RID: 2402
	public enum HuntScanState
	{
		// Token: 0x040080E0 RID: 32992
		Uninitialized,
		// Token: 0x040080E1 RID: 32993
		Standby,
		// Token: 0x040080E2 RID: 32994
		Revealed,
		// Token: 0x040080E3 RID: 32995
		Jammed,
		// Token: 0x040080E4 RID: 32996
		ScanningFast,
		// Token: 0x040080E5 RID: 32997
		ScanningSlow,
		// Token: 0x040080E6 RID: 32998
		ScanningMedium
	}
}
