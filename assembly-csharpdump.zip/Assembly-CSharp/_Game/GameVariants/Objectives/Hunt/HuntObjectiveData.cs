﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Hunt
{
	// Token: 0x0200095F RID: 2399
	public class HuntObjectiveData : BaseObjectiveData
	{
		// Token: 0x0600CB9B RID: 52123 RVA: 0x0032A8B8 File Offset: 0x00328AB8
		[CallerCount(0)]
		public unsafe HuntObjectiveData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HuntObjectiveData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HuntObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB9C RID: 52124 RVA: 0x0032A903 File Offset: 0x00328B03
		// Note: this type is marked as 'beforefieldinit'.
		static HuntObjectiveData()
		{
			Il2CppClassPointerStore<HuntObjectiveData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Hunt", "HuntObjectiveData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HuntObjectiveData>.NativeClassPtr);
			HuntObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntObjectiveData>.NativeClassPtr, 100679015);
		}

		// Token: 0x0600CB9D RID: 52125 RVA: 0x00328E3C File Offset: 0x0032703C
		public HuntObjectiveData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A1F RID: 18975
		// (get) Token: 0x0600CB9E RID: 52126 RVA: 0x0032A93C File Offset: 0x00328B3C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HuntObjectiveData>.NativeClassPtr));
			}
		}

		// Token: 0x040080B6 RID: 32950
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
