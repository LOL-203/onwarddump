﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.Objectives.Hunt
{
	// Token: 0x02000961 RID: 2401
	[Serializable]
	[StructLayout(0)]
	public sealed class HuntScanProperties : ValueType
	{
		// Token: 0x0600CBD1 RID: 52177 RVA: 0x0032B558 File Offset: 0x00329758
		[CallerCount(0)]
		public unsafe float GetMaxTime(float timeSlope, float timeIntercept, int aiCount)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref timeSlope;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref timeIntercept;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiCount;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HuntScanProperties.NativeMethodInfoPtr_GetMaxTime_Public_Single_Single_Single_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBD2 RID: 52178 RVA: 0x0032B5E0 File Offset: 0x003297E0
		[CallerCount(0)]
		public unsafe float GetProgress(float timer, float timeSlope, float timeIntercept, int aiCount)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref timer;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref timeSlope;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref timeIntercept;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref aiCount;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(HuntScanProperties.NativeMethodInfoPtr_GetProgress_Public_Single_Single_Single_Single_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBD3 RID: 52179 RVA: 0x0032B67C File Offset: 0x0032987C
		// Note: this type is marked as 'beforefieldinit'.
		static HuntScanProperties()
		{
			Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Hunt", "HuntScanProperties");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr);
			HuntScanProperties.NativeFieldInfoPtr_State = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "State");
			HuntScanProperties.NativeFieldInfoPtr_Caption = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "Caption");
			HuntScanProperties.NativeFieldInfoPtr_MaxTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "MaxTime");
			HuntScanProperties.NativeFieldInfoPtr_UseAICountForTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "UseAICountForTime");
			HuntScanProperties.NativeFieldInfoPtr_Scanning = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "Scanning");
			HuntScanProperties.NativeFieldInfoPtr_MessageOnly = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "MessageOnly");
			HuntScanProperties.NativeFieldInfoPtr_Color = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, "Color");
			HuntScanProperties.NativeMethodInfoPtr_GetMaxTime_Public_Single_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, 100679031);
			HuntScanProperties.NativeMethodInfoPtr_GetProgress_Public_Single_Single_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, 100679032);
		}

		// Token: 0x0600CBD4 RID: 52180 RVA: 0x0002717B File Offset: 0x0002537B
		public HuntScanProperties(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A34 RID: 18996
		// (get) Token: 0x0600CBD5 RID: 52181 RVA: 0x0032B760 File Offset: 0x00329960
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr));
			}
		}

		// Token: 0x0600CBD6 RID: 52182 RVA: 0x0032B774 File Offset: 0x00329974
		public unsafe HuntScanProperties()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<HuntScanProperties>.NativeClassPtr, data));
		}

		// Token: 0x17004A35 RID: 18997
		// (get) Token: 0x0600CBD7 RID: 52183 RVA: 0x0032B7A4 File Offset: 0x003299A4
		// (set) Token: 0x0600CBD8 RID: 52184 RVA: 0x0032B7CC File Offset: 0x003299CC
		public unsafe HuntScanState State
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_State);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_State)) = value;
			}
		}

		// Token: 0x17004A36 RID: 18998
		// (get) Token: 0x0600CBD9 RID: 52185 RVA: 0x0032B7F0 File Offset: 0x003299F0
		// (set) Token: 0x0600CBDA RID: 52186 RVA: 0x0032B819 File Offset: 0x00329A19
		public unsafe string Caption
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Caption);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Caption), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004A37 RID: 18999
		// (get) Token: 0x0600CBDB RID: 52187 RVA: 0x0032B840 File Offset: 0x00329A40
		// (set) Token: 0x0600CBDC RID: 52188 RVA: 0x0032B868 File Offset: 0x00329A68
		public unsafe float MaxTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_MaxTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_MaxTime)) = value;
			}
		}

		// Token: 0x17004A38 RID: 19000
		// (get) Token: 0x0600CBDD RID: 52189 RVA: 0x0032B88C File Offset: 0x00329A8C
		// (set) Token: 0x0600CBDE RID: 52190 RVA: 0x0032B8B4 File Offset: 0x00329AB4
		public unsafe bool UseAICountForTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_UseAICountForTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_UseAICountForTime)) = value;
			}
		}

		// Token: 0x17004A39 RID: 19001
		// (get) Token: 0x0600CBDF RID: 52191 RVA: 0x0032B8D8 File Offset: 0x00329AD8
		// (set) Token: 0x0600CBE0 RID: 52192 RVA: 0x0032B900 File Offset: 0x00329B00
		public unsafe bool Scanning
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Scanning);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Scanning)) = value;
			}
		}

		// Token: 0x17004A3A RID: 19002
		// (get) Token: 0x0600CBE1 RID: 52193 RVA: 0x0032B924 File Offset: 0x00329B24
		// (set) Token: 0x0600CBE2 RID: 52194 RVA: 0x0032B94C File Offset: 0x00329B4C
		public unsafe bool MessageOnly
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_MessageOnly);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_MessageOnly)) = value;
			}
		}

		// Token: 0x17004A3B RID: 19003
		// (get) Token: 0x0600CBE3 RID: 52195 RVA: 0x0032B970 File Offset: 0x00329B70
		// (set) Token: 0x0600CBE4 RID: 52196 RVA: 0x0032B998 File Offset: 0x00329B98
		public unsafe Color Color
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Color);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(HuntScanProperties.NativeFieldInfoPtr_Color)) = value;
			}
		}

		// Token: 0x040080D6 RID: 32982
		private static readonly IntPtr NativeFieldInfoPtr_State;

		// Token: 0x040080D7 RID: 32983
		private static readonly IntPtr NativeFieldInfoPtr_Caption;

		// Token: 0x040080D8 RID: 32984
		private static readonly IntPtr NativeFieldInfoPtr_MaxTime;

		// Token: 0x040080D9 RID: 32985
		private static readonly IntPtr NativeFieldInfoPtr_UseAICountForTime;

		// Token: 0x040080DA RID: 32986
		private static readonly IntPtr NativeFieldInfoPtr_Scanning;

		// Token: 0x040080DB RID: 32987
		private static readonly IntPtr NativeFieldInfoPtr_MessageOnly;

		// Token: 0x040080DC RID: 32988
		private static readonly IntPtr NativeFieldInfoPtr_Color;

		// Token: 0x040080DD RID: 32989
		private static readonly IntPtr NativeMethodInfoPtr_GetMaxTime_Public_Single_Single_Single_Int32_0;

		// Token: 0x040080DE RID: 32990
		private static readonly IntPtr NativeMethodInfoPtr_GetProgress_Public_Single_Single_Single_Single_Int32_0;
	}
}
