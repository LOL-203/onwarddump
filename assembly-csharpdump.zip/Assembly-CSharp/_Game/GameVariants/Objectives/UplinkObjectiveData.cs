﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000959 RID: 2393
	public class UplinkObjectiveData : BaseObjectiveData
	{
		// Token: 0x0600CB35 RID: 52021 RVA: 0x00328D98 File Offset: 0x00326F98
		[CallerCount(0)]
		public unsafe UplinkObjectiveData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB36 RID: 52022 RVA: 0x00328DE4 File Offset: 0x00326FE4
		// Note: this type is marked as 'beforefieldinit'.
		static UplinkObjectiveData()
		{
			Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "UplinkObjectiveData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr);
			UplinkObjectiveData.NativeFieldInfoPtr_Mode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr, "Mode");
			UplinkObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr, 100678975);
		}

		// Token: 0x0600CB37 RID: 52023 RVA: 0x00328E3C File Offset: 0x0032703C
		public UplinkObjectiveData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049FB RID: 18939
		// (get) Token: 0x0600CB38 RID: 52024 RVA: 0x00328E45 File Offset: 0x00327045
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UplinkObjectiveData>.NativeClassPtr));
			}
		}

		// Token: 0x170049FC RID: 18940
		// (get) Token: 0x0600CB39 RID: 52025 RVA: 0x00328E58 File Offset: 0x00327058
		// (set) Token: 0x0600CB3A RID: 52026 RVA: 0x00328E80 File Offset: 0x00327080
		public unsafe UplinkMode Mode
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjectiveData.NativeFieldInfoPtr_Mode);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkObjectiveData.NativeFieldInfoPtr_Mode)) = value;
			}
		}

		// Token: 0x04008078 RID: 32888
		private static readonly IntPtr NativeFieldInfoPtr_Mode;

		// Token: 0x04008079 RID: 32889
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
