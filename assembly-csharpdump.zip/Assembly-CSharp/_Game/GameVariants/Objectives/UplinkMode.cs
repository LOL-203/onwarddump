﻿using System;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000956 RID: 2390
	public enum UplinkMode
	{
		// Token: 0x04008057 RID: 32855
		InstantSend,
		// Token: 0x04008058 RID: 32856
		SendAndDefend
	}
}
