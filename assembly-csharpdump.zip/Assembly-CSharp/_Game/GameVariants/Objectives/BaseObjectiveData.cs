﻿using System;
using Il2CppSystem;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000953 RID: 2387
	public class BaseObjectiveData : Object
	{
		// Token: 0x0600CAE9 RID: 51945 RVA: 0x00327814 File Offset: 0x00325A14
		[CallerCount(0)]
		public unsafe BaseObjectiveData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseObjectiveData.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAEA RID: 51946 RVA: 0x00327860 File Offset: 0x00325A60
		// Note: this type is marked as 'beforefieldinit'.
		static BaseObjectiveData()
		{
			Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "BaseObjectiveData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr);
			BaseObjectiveData.NativeFieldInfoPtr_PositionData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr, "PositionData");
			BaseObjectiveData.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr, 100678941);
		}

		// Token: 0x0600CAEB RID: 51947 RVA: 0x00002988 File Offset: 0x00000B88
		public BaseObjectiveData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049E3 RID: 18915
		// (get) Token: 0x0600CAEC RID: 51948 RVA: 0x003278B8 File Offset: 0x00325AB8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BaseObjectiveData>.NativeClassPtr));
			}
		}

		// Token: 0x170049E4 RID: 18916
		// (get) Token: 0x0600CAED RID: 51949 RVA: 0x003278CC File Offset: 0x00325ACC
		// (set) Token: 0x0600CAEE RID: 51950 RVA: 0x00327900 File Offset: 0x00325B00
		public unsafe ObjectiveData PositionData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjectiveData.NativeFieldInfoPtr_PositionData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ObjectiveData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjectiveData.NativeFieldInfoPtr_PositionData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008040 RID: 32832
		private static readonly IntPtr NativeFieldInfoPtr_PositionData;

		// Token: 0x04008041 RID: 32833
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
