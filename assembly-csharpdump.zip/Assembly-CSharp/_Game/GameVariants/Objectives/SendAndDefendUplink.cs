﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000955 RID: 2389
	public class SendAndDefendUplink : UplinkSubtype
	{
		// Token: 0x0600CAF5 RID: 51957 RVA: 0x00327AE8 File Offset: 0x00325CE8
		[CallerCount(0)]
		public new unsafe void Initialize(UplinkObjective owner)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_UplinkObjective_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF6 RID: 51958 RVA: 0x00327B4C File Offset: 0x00325D4C
		[CallerCount(0)]
		public new unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF7 RID: 51959 RVA: 0x00327B9C File Offset: 0x00325D9C
		[CallerCount(0)]
		public new unsafe void OnCodeSent(UplinkCodeSentEvent unused, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref unused;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF8 RID: 51960 RVA: 0x00327C18 File Offset: 0x00325E18
		[CallerCount(0)]
		public new unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF9 RID: 51961 RVA: 0x00327C68 File Offset: 0x00325E68
		[CallerCount(0)]
		public new unsafe void TickShared()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAFA RID: 51962 RVA: 0x00327CB8 File Offset: 0x00325EB8
		[CallerCount(0)]
		public new unsafe void OnUplinkStateChange(UplinkStateChangedEvent uplinkEvent, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref uplinkEvent;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAFB RID: 51963 RVA: 0x00327D34 File Offset: 0x00325F34
		[CallerCount(0)]
		public new unsafe float GetRemainingSendTime(bool isCancelTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isCancelTime;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SendAndDefendUplink.NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CAFC RID: 51964 RVA: 0x00327DA4 File Offset: 0x00325FA4
		[CallerCount(0)]
		public unsafe void OnUplinkDetectorLeftRange(UplinkDetectorOutOfRangeEvent outOfRangeEvent, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref outOfRangeEvent;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SendAndDefendUplink.NativeMethodInfoPtr_OnUplinkDetectorLeftRange_Private_Void_UplinkDetectorOutOfRangeEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAFD RID: 51965 RVA: 0x00327E18 File Offset: 0x00326018
		[CallerCount(0)]
		public unsafe void UplinkDetectorOwnerKilled(UplinkDetectorOwnerKilledEvent unused, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref unused;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SendAndDefendUplink.NativeMethodInfoPtr_UplinkDetectorOwnerKilled_Private_Void_UplinkDetectorOwnerKilledEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAFE RID: 51966 RVA: 0x00327E8C File Offset: 0x0032608C
		[CallerCount(0)]
		public unsafe void OnLocalTabletLeftRange(SendUplinkDetector uplinkDetector)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(uplinkDetector);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SendAndDefendUplink.NativeMethodInfoPtr_OnLocalTabletLeftRange_Private_Void_SendUplinkDetector_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAFF RID: 51967 RVA: 0x00327EE8 File Offset: 0x003260E8
		[CallerCount(0)]
		public unsafe SendAndDefendUplink() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SendAndDefendUplink.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB00 RID: 51968 RVA: 0x00327F34 File Offset: 0x00326134
		// Note: this type is marked as 'beforefieldinit'.
		static SendAndDefendUplink()
		{
			Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "SendAndDefendUplink");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr);
			SendAndDefendUplink.NativeFieldInfoPtr_StartCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "StartCaptureTime");
			SendAndDefendUplink.NativeFieldInfoPtr_EndCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "EndCaptureTime");
			SendAndDefendUplink.NativeFieldInfoPtr_CurrentCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "CurrentCaptureTime");
			SendAndDefendUplink.NativeFieldInfoPtr_CancelCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "CancelCaptureTime");
			SendAndDefendUplink.NativeFieldInfoPtr_EndCancelCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "EndCancelCaptureTime");
			SendAndDefendUplink.NativeFieldInfoPtr_CurrentCancelCaptureTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, "CurrentCancelCaptureTime");
			SendAndDefendUplink.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_UplinkObjective_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678945);
			SendAndDefendUplink.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678946);
			SendAndDefendUplink.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678947);
			SendAndDefendUplink.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678948);
			SendAndDefendUplink.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678949);
			SendAndDefendUplink.NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678950);
			SendAndDefendUplink.NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678951);
			SendAndDefendUplink.NativeMethodInfoPtr_OnUplinkDetectorLeftRange_Private_Void_UplinkDetectorOutOfRangeEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678952);
			SendAndDefendUplink.NativeMethodInfoPtr_UplinkDetectorOwnerKilled_Private_Void_UplinkDetectorOwnerKilledEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678953);
			SendAndDefendUplink.NativeMethodInfoPtr_OnLocalTabletLeftRange_Private_Void_SendUplinkDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678954);
			SendAndDefendUplink.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr, 100678955);
		}

		// Token: 0x0600CB01 RID: 51969 RVA: 0x00327ACC File Offset: 0x00325CCC
		public SendAndDefendUplink(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049E6 RID: 18918
		// (get) Token: 0x0600CB02 RID: 51970 RVA: 0x003280B8 File Offset: 0x003262B8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SendAndDefendUplink>.NativeClassPtr));
			}
		}

		// Token: 0x170049E7 RID: 18919
		// (get) Token: 0x0600CB03 RID: 51971 RVA: 0x003280CC File Offset: 0x003262CC
		// (set) Token: 0x0600CB04 RID: 51972 RVA: 0x003280F4 File Offset: 0x003262F4
		public unsafe double StartCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_StartCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_StartCaptureTime)) = value;
			}
		}

		// Token: 0x170049E8 RID: 18920
		// (get) Token: 0x0600CB05 RID: 51973 RVA: 0x00328118 File Offset: 0x00326318
		// (set) Token: 0x0600CB06 RID: 51974 RVA: 0x00328140 File Offset: 0x00326340
		public unsafe double EndCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_EndCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_EndCaptureTime)) = value;
			}
		}

		// Token: 0x170049E9 RID: 18921
		// (get) Token: 0x0600CB07 RID: 51975 RVA: 0x00328164 File Offset: 0x00326364
		// (set) Token: 0x0600CB08 RID: 51976 RVA: 0x0032818C File Offset: 0x0032638C
		public unsafe double CurrentCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CurrentCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CurrentCaptureTime)) = value;
			}
		}

		// Token: 0x170049EA RID: 18922
		// (get) Token: 0x0600CB09 RID: 51977 RVA: 0x003281B0 File Offset: 0x003263B0
		// (set) Token: 0x0600CB0A RID: 51978 RVA: 0x003281D8 File Offset: 0x003263D8
		public unsafe double CancelCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CancelCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CancelCaptureTime)) = value;
			}
		}

		// Token: 0x170049EB RID: 18923
		// (get) Token: 0x0600CB0B RID: 51979 RVA: 0x003281FC File Offset: 0x003263FC
		// (set) Token: 0x0600CB0C RID: 51980 RVA: 0x00328224 File Offset: 0x00326424
		public unsafe double EndCancelCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_EndCancelCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_EndCancelCaptureTime)) = value;
			}
		}

		// Token: 0x170049EC RID: 18924
		// (get) Token: 0x0600CB0D RID: 51981 RVA: 0x00328248 File Offset: 0x00326448
		// (set) Token: 0x0600CB0E RID: 51982 RVA: 0x00328270 File Offset: 0x00326470
		public unsafe double CurrentCancelCaptureTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CurrentCancelCaptureTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SendAndDefendUplink.NativeFieldInfoPtr_CurrentCancelCaptureTime)) = value;
			}
		}

		// Token: 0x04008045 RID: 32837
		private static readonly IntPtr NativeFieldInfoPtr_StartCaptureTime;

		// Token: 0x04008046 RID: 32838
		private static readonly IntPtr NativeFieldInfoPtr_EndCaptureTime;

		// Token: 0x04008047 RID: 32839
		private static readonly IntPtr NativeFieldInfoPtr_CurrentCaptureTime;

		// Token: 0x04008048 RID: 32840
		private static readonly IntPtr NativeFieldInfoPtr_CancelCaptureTime;

		// Token: 0x04008049 RID: 32841
		private static readonly IntPtr NativeFieldInfoPtr_EndCancelCaptureTime;

		// Token: 0x0400804A RID: 32842
		private static readonly IntPtr NativeFieldInfoPtr_CurrentCancelCaptureTime;

		// Token: 0x0400804B RID: 32843
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_Void_UplinkObjective_0;

		// Token: 0x0400804C RID: 32844
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0;

		// Token: 0x0400804D RID: 32845
		private static readonly IntPtr NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400804E RID: 32846
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0;

		// Token: 0x0400804F RID: 32847
		private static readonly IntPtr NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0;

		// Token: 0x04008050 RID: 32848
		private static readonly IntPtr NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008051 RID: 32849
		private static readonly IntPtr NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0;

		// Token: 0x04008052 RID: 32850
		private static readonly IntPtr NativeMethodInfoPtr_OnUplinkDetectorLeftRange_Private_Void_UplinkDetectorOutOfRangeEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008053 RID: 32851
		private static readonly IntPtr NativeMethodInfoPtr_UplinkDetectorOwnerKilled_Private_Void_UplinkDetectorOwnerKilledEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008054 RID: 32852
		private static readonly IntPtr NativeMethodInfoPtr_OnLocalTabletLeftRange_Private_Void_SendUplinkDetector_0;

		// Token: 0x04008055 RID: 32853
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
