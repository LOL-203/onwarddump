﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000954 RID: 2388
	public class InstantUplink : UplinkSubtype
	{
		// Token: 0x0600CAEF RID: 51951 RVA: 0x00327928 File Offset: 0x00325B28
		[CallerCount(0)]
		public new unsafe float GetRemainingSendTime(bool isCancelTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isCancelTime;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InstantUplink.NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CAF0 RID: 51952 RVA: 0x00327998 File Offset: 0x00325B98
		[CallerCount(0)]
		public new unsafe void OnCodeSent(UplinkCodeSentEvent unused, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref unused;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InstantUplink.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF1 RID: 51953 RVA: 0x00327A14 File Offset: 0x00325C14
		[CallerCount(0)]
		public unsafe InstantUplink() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InstantUplink.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAF2 RID: 51954 RVA: 0x00327A60 File Offset: 0x00325C60
		// Note: this type is marked as 'beforefieldinit'.
		static InstantUplink()
		{
			Il2CppClassPointerStore<InstantUplink>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "InstantUplink");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr);
			InstantUplink.NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr, 100678942);
			InstantUplink.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr, 100678943);
			InstantUplink.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr, 100678944);
		}

		// Token: 0x0600CAF3 RID: 51955 RVA: 0x00327ACC File Offset: 0x00325CCC
		public InstantUplink(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049E5 RID: 18917
		// (get) Token: 0x0600CAF4 RID: 51956 RVA: 0x00327AD5 File Offset: 0x00325CD5
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<InstantUplink>.NativeClassPtr));
			}
		}

		// Token: 0x04008042 RID: 32834
		private static readonly IntPtr NativeMethodInfoPtr_GetRemainingSendTime_Public_Virtual_Single_Boolean_0;

		// Token: 0x04008043 RID: 32835
		private static readonly IntPtr NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008044 RID: 32836
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
