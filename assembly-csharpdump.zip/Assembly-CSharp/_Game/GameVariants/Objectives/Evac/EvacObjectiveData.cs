﻿using System;
using Il2CppSystem;
using Onward.Data;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Evac
{
	// Token: 0x02000964 RID: 2404
	public class EvacObjectiveData : BaseObjectiveData
	{
		// Token: 0x0600CC29 RID: 52265 RVA: 0x0032CA94 File Offset: 0x0032AC94
		[CallerCount(0)]
		public unsafe EvacObjectiveData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CC2A RID: 52266 RVA: 0x0032CAE0 File Offset: 0x0032ACE0
		// Note: this type is marked as 'beforefieldinit'.
		static EvacObjectiveData()
		{
			Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Evac", "EvacObjectiveData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr);
			EvacObjectiveData.NativeFieldInfoPtr_EvacType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr, "EvacType");
			EvacObjectiveData.NativeFieldInfoPtr_PickupToSpawn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr, "PickupToSpawn");
			EvacObjectiveData.NativeFieldInfoPtr_WhereToSpawnPickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr, "WhereToSpawnPickup");
			EvacObjectiveData.NativeFieldInfoPtr_PickupSpawnDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr, "PickupSpawnDelay");
			EvacObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr, 100679052);
		}

		// Token: 0x0600CC2B RID: 52267 RVA: 0x00328E3C File Offset: 0x0032703C
		public EvacObjectiveData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A58 RID: 19032
		// (get) Token: 0x0600CC2C RID: 52268 RVA: 0x0032CB74 File Offset: 0x0032AD74
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<EvacObjectiveData>.NativeClassPtr));
			}
		}

		// Token: 0x17004A59 RID: 19033
		// (get) Token: 0x0600CC2D RID: 52269 RVA: 0x0032CB88 File Offset: 0x0032AD88
		// (set) Token: 0x0600CC2E RID: 52270 RVA: 0x0032CBB0 File Offset: 0x0032ADB0
		public unsafe ObjectiveTypes EvacType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_EvacType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_EvacType)) = value;
			}
		}

		// Token: 0x17004A5A RID: 19034
		// (get) Token: 0x0600CC2F RID: 52271 RVA: 0x0032CBD4 File Offset: 0x0032ADD4
		// (set) Token: 0x0600CC30 RID: 52272 RVA: 0x0032CC08 File Offset: 0x0032AE08
		public unsafe PickupData PickupToSpawn
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_PickupToSpawn);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PickupData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_PickupToSpawn), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A5B RID: 19035
		// (get) Token: 0x0600CC31 RID: 52273 RVA: 0x0032CC30 File Offset: 0x0032AE30
		// (set) Token: 0x0600CC32 RID: 52274 RVA: 0x0032CC64 File Offset: 0x0032AE64
		public unsafe Onward.GameVariants.SpawnPoint WhereToSpawnPickup
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_WhereToSpawnPickup);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Onward.GameVariants.SpawnPoint(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_WhereToSpawnPickup), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A5C RID: 19036
		// (get) Token: 0x0600CC33 RID: 52275 RVA: 0x0032CC8C File Offset: 0x0032AE8C
		// (set) Token: 0x0600CC34 RID: 52276 RVA: 0x0032CCB4 File Offset: 0x0032AEB4
		public unsafe float PickupSpawnDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_PickupSpawnDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjectiveData.NativeFieldInfoPtr_PickupSpawnDelay)) = value;
			}
		}

		// Token: 0x04008110 RID: 33040
		private static readonly IntPtr NativeFieldInfoPtr_EvacType;

		// Token: 0x04008111 RID: 33041
		private static readonly IntPtr NativeFieldInfoPtr_PickupToSpawn;

		// Token: 0x04008112 RID: 33042
		private static readonly IntPtr NativeFieldInfoPtr_WhereToSpawnPickup;

		// Token: 0x04008113 RID: 33043
		private static readonly IntPtr NativeFieldInfoPtr_PickupSpawnDelay;

		// Token: 0x04008114 RID: 33044
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
