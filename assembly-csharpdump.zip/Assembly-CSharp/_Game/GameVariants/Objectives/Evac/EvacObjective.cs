﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.AI.Objectives;
using Onward.Data;
using Onward.GameManagement;
using Onward.GameVariants;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Evac
{
	// Token: 0x02000963 RID: 2403
	public class EvacObjective : BaseObjective
	{
		// Token: 0x17004A54 RID: 19028
		// (get) Token: 0x0600CBE7 RID: 52199 RVA: 0x0032B9E8 File Offset: 0x00329BE8
		public new unsafe ActivateObjectiveState ActivateObjectiveState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A55 RID: 19029
		// (get) Token: 0x0600CBE8 RID: 52200 RVA: 0x0032BA44 File Offset: 0x00329C44
		// (set) Token: 0x0600CBE9 RID: 52201 RVA: 0x0032BA94 File Offset: 0x00329C94
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17004A56 RID: 19030
		// (get) Token: 0x0600CBEA RID: 52202 RVA: 0x0032BAE8 File Offset: 0x00329CE8
		public new unsafe Onward.GameVariants.ObjectiveTypes ObjectiveType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A57 RID: 19031
		// (get) Token: 0x0600CBEB RID: 52203 RVA: 0x0032BB44 File Offset: 0x00329D44
		public new unsafe RoundEndTypes ObjectiveCompleteEndType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CBEC RID: 52204 RVA: 0x0032BBA0 File Offset: 0x00329DA0
		[CallerCount(0)]
		public new unsafe void Initialize(GameVariant owner, BaseObjectiveData objectiveData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(objectiveData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBED RID: 52205 RVA: 0x0032BC1C File Offset: 0x00329E1C
		[CallerCount(0)]
		public new unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBEE RID: 52206 RVA: 0x0032BC6C File Offset: 0x00329E6C
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBEF RID: 52207 RVA: 0x0032BCB0 File Offset: 0x00329EB0
		[CallerCount(0)]
		public new unsafe void ActivateObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF0 RID: 52208 RVA: 0x0032BD00 File Offset: 0x00329F00
		[CallerCount(0)]
		public new unsafe void HostSetObjectiveSyncData(DPIPlayer host)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(host);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_Void_DPIPlayer_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF1 RID: 52209 RVA: 0x0032BD64 File Offset: 0x00329F64
		[CallerCount(0)]
		public new unsafe bool ClientSetObjectiveSyncData()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBF2 RID: 52210 RVA: 0x0032BDC0 File Offset: 0x00329FC0
		[CallerCount(0)]
		public new unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF3 RID: 52211 RVA: 0x0032BE10 File Offset: 0x0032A010
		[CallerCount(0)]
		public new unsafe void TickShared()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), EvacObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF4 RID: 52212 RVA: 0x0032BE60 File Offset: 0x0032A060
		[CallerCount(0)]
		public unsafe void EvacPlayerSafeAction(PlayerEvacuationEvent evacuatedEvent, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref evacuatedEvent;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_EvacPlayerSafeAction_Private_Void_PlayerEvacuationEvent_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF5 RID: 52213 RVA: 0x0032BED4 File Offset: 0x0032A0D4
		[CallerCount(0)]
		public unsafe void OnVictoryTriggered(EvacVictoryTrigger trigger)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(trigger);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_OnVictoryTriggered_Private_Void_EvacVictoryTrigger_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF6 RID: 52214 RVA: 0x0032BF30 File Offset: 0x0032A130
		[CallerCount(0)]
		public unsafe double GetRemainingTime()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_GetRemainingTime_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBF7 RID: 52215 RVA: 0x0032BF80 File Offset: 0x0032A180
		[CallerCount(0)]
		public unsafe double GetTimeToLand()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_GetTimeToLand_Public_Double_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CBF8 RID: 52216 RVA: 0x0032BFD0 File Offset: 0x0032A1D0
		[CallerCount(0)]
		public unsafe void TickPickupSpawn()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr_TickPickupSpawn_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBF9 RID: 52217 RVA: 0x0032C014 File Offset: 0x0032A214
		[CallerCount(0)]
		public unsafe EvacObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(EvacObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CBFA RID: 52218 RVA: 0x0032C060 File Offset: 0x0032A260
		// Note: this type is marked as 'beforefieldinit'.
		static EvacObjective()
		{
			Il2CppClassPointerStore<EvacObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Evac", "EvacObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr);
			EvacObjective.NativeFieldInfoPtr_Singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "Singleton");
			EvacObjective.NativeFieldInfoPtr_HelicopterObjective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "HelicopterObjective");
			EvacObjective.NativeFieldInfoPtr_UseMusic = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "UseMusic");
			EvacObjective.NativeFieldInfoPtr__evacChopperArrivalTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_evacChopperArrivalTime");
			EvacObjective.NativeFieldInfoPtr__musicStartTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_musicStartTime");
			EvacObjective.NativeFieldInfoPtr__evacChopperLandTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_evacChopperLandTime");
			EvacObjective.NativeFieldInfoPtr__evacChopperDepartTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_evacChopperDepartTime");
			EvacObjective.NativeFieldInfoPtr__musicStarted = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_musicStarted");
			EvacObjective.NativeFieldInfoPtr__evacSmokeOut = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_evacSmokeOut");
			EvacObjective.NativeFieldInfoPtr__beepPlayed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_beepPlayed");
			EvacObjective.NativeFieldInfoPtr__evacVictoryTriggered = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_evacVictoryTriggered");
			EvacObjective.NativeFieldInfoPtr_MusicStartTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "MusicStartTime");
			EvacObjective.NativeFieldInfoPtr_EvacChopperArrives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "EvacChopperArrives");
			EvacObjective.NativeFieldInfoPtr_EvacChopperLandTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "EvacChopperLandTime");
			EvacObjective.NativeFieldInfoPtr_EvacChopperDepartTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "EvacChopperDepartTime");
			EvacObjective.NativeFieldInfoPtr__safePlayers = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_safePlayers");
			EvacObjective.NativeFieldInfoPtr__initializedType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_initializedType");
			EvacObjective.NativeFieldInfoPtr__hasSpawnablePickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_hasSpawnablePickup");
			EvacObjective.NativeFieldInfoPtr__spawnablePickup = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_spawnablePickup");
			EvacObjective.NativeFieldInfoPtr__spawnablePickupLocation = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_spawnablePickupLocation");
			EvacObjective.NativeFieldInfoPtr__spawnablePickupDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "_spawnablePickupDelay");
			EvacObjective.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			EvacObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679033);
			EvacObjective.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679034);
			EvacObjective.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679035);
			EvacObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679036);
			EvacObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679037);
			EvacObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679038);
			EvacObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679039);
			EvacObjective.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679040);
			EvacObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679041);
			EvacObjective.NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679042);
			EvacObjective.NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679043);
			EvacObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679044);
			EvacObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679045);
			EvacObjective.NativeMethodInfoPtr_EvacPlayerSafeAction_Private_Void_PlayerEvacuationEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679046);
			EvacObjective.NativeMethodInfoPtr_OnVictoryTriggered_Private_Void_EvacVictoryTrigger_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679047);
			EvacObjective.NativeMethodInfoPtr_GetRemainingTime_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679048);
			EvacObjective.NativeMethodInfoPtr_GetTimeToLand_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679049);
			EvacObjective.NativeMethodInfoPtr_TickPickupSpawn_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679050);
			EvacObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr, 100679051);
		}

		// Token: 0x0600CBFB RID: 52219 RVA: 0x00328BBC File Offset: 0x00326DBC
		public EvacObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A3D RID: 19005
		// (get) Token: 0x0600CBFC RID: 52220 RVA: 0x0032C3C4 File Offset: 0x0032A5C4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<EvacObjective>.NativeClassPtr));
			}
		}

		// Token: 0x17004A3E RID: 19006
		// (get) Token: 0x0600CBFD RID: 52221 RVA: 0x0032C3D8 File Offset: 0x0032A5D8
		// (set) Token: 0x0600CBFE RID: 52222 RVA: 0x0032C403 File Offset: 0x0032A603
		public unsafe static EvacObjective Singleton
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(EvacObjective.NativeFieldInfoPtr_Singleton, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new EvacObjective(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(EvacObjective.NativeFieldInfoPtr_Singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A3F RID: 19007
		// (get) Token: 0x0600CBFF RID: 52223 RVA: 0x0032C418 File Offset: 0x0032A618
		// (set) Token: 0x0600CC00 RID: 52224 RVA: 0x0032C44C File Offset: 0x0032A64C
		public unsafe AIDefendObjective HelicopterObjective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_HelicopterObjective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AIDefendObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_HelicopterObjective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A40 RID: 19008
		// (get) Token: 0x0600CC01 RID: 52225 RVA: 0x0032C474 File Offset: 0x0032A674
		// (set) Token: 0x0600CC02 RID: 52226 RVA: 0x0032C49C File Offset: 0x0032A69C
		public unsafe bool UseMusic
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_UseMusic);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_UseMusic)) = value;
			}
		}

		// Token: 0x17004A41 RID: 19009
		// (get) Token: 0x0600CC03 RID: 52227 RVA: 0x0032C4C0 File Offset: 0x0032A6C0
		// (set) Token: 0x0600CC04 RID: 52228 RVA: 0x0032C4E8 File Offset: 0x0032A6E8
		public unsafe double _evacChopperArrivalTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperArrivalTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperArrivalTime)) = value;
			}
		}

		// Token: 0x17004A42 RID: 19010
		// (get) Token: 0x0600CC05 RID: 52229 RVA: 0x0032C50C File Offset: 0x0032A70C
		// (set) Token: 0x0600CC06 RID: 52230 RVA: 0x0032C534 File Offset: 0x0032A734
		public unsafe double _musicStartTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__musicStartTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__musicStartTime)) = value;
			}
		}

		// Token: 0x17004A43 RID: 19011
		// (get) Token: 0x0600CC07 RID: 52231 RVA: 0x0032C558 File Offset: 0x0032A758
		// (set) Token: 0x0600CC08 RID: 52232 RVA: 0x0032C580 File Offset: 0x0032A780
		public unsafe double _evacChopperLandTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperLandTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperLandTime)) = value;
			}
		}

		// Token: 0x17004A44 RID: 19012
		// (get) Token: 0x0600CC09 RID: 52233 RVA: 0x0032C5A4 File Offset: 0x0032A7A4
		// (set) Token: 0x0600CC0A RID: 52234 RVA: 0x0032C5CC File Offset: 0x0032A7CC
		public unsafe double _evacChopperDepartTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperDepartTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacChopperDepartTime)) = value;
			}
		}

		// Token: 0x17004A45 RID: 19013
		// (get) Token: 0x0600CC0B RID: 52235 RVA: 0x0032C5F0 File Offset: 0x0032A7F0
		// (set) Token: 0x0600CC0C RID: 52236 RVA: 0x0032C618 File Offset: 0x0032A818
		public unsafe bool _musicStarted
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__musicStarted);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__musicStarted)) = value;
			}
		}

		// Token: 0x17004A46 RID: 19014
		// (get) Token: 0x0600CC0D RID: 52237 RVA: 0x0032C63C File Offset: 0x0032A83C
		// (set) Token: 0x0600CC0E RID: 52238 RVA: 0x0032C664 File Offset: 0x0032A864
		public unsafe bool _evacSmokeOut
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacSmokeOut);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacSmokeOut)) = value;
			}
		}

		// Token: 0x17004A47 RID: 19015
		// (get) Token: 0x0600CC0F RID: 52239 RVA: 0x0032C688 File Offset: 0x0032A888
		// (set) Token: 0x0600CC10 RID: 52240 RVA: 0x0032C6B0 File Offset: 0x0032A8B0
		public unsafe bool _beepPlayed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__beepPlayed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__beepPlayed)) = value;
			}
		}

		// Token: 0x17004A48 RID: 19016
		// (get) Token: 0x0600CC11 RID: 52241 RVA: 0x0032C6D4 File Offset: 0x0032A8D4
		// (set) Token: 0x0600CC12 RID: 52242 RVA: 0x0032C6FC File Offset: 0x0032A8FC
		public unsafe bool _evacVictoryTriggered
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacVictoryTriggered);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__evacVictoryTriggered)) = value;
			}
		}

		// Token: 0x17004A49 RID: 19017
		// (get) Token: 0x0600CC13 RID: 52243 RVA: 0x0032C720 File Offset: 0x0032A920
		// (set) Token: 0x0600CC14 RID: 52244 RVA: 0x0032C748 File Offset: 0x0032A948
		public unsafe double MusicStartTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_MusicStartTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_MusicStartTime)) = value;
			}
		}

		// Token: 0x17004A4A RID: 19018
		// (get) Token: 0x0600CC15 RID: 52245 RVA: 0x0032C76C File Offset: 0x0032A96C
		// (set) Token: 0x0600CC16 RID: 52246 RVA: 0x0032C794 File Offset: 0x0032A994
		public unsafe double EvacChopperArrives
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperArrives);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperArrives)) = value;
			}
		}

		// Token: 0x17004A4B RID: 19019
		// (get) Token: 0x0600CC17 RID: 52247 RVA: 0x0032C7B8 File Offset: 0x0032A9B8
		// (set) Token: 0x0600CC18 RID: 52248 RVA: 0x0032C7E0 File Offset: 0x0032A9E0
		public unsafe double EvacChopperLandTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperLandTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperLandTime)) = value;
			}
		}

		// Token: 0x17004A4C RID: 19020
		// (get) Token: 0x0600CC19 RID: 52249 RVA: 0x0032C804 File Offset: 0x0032AA04
		// (set) Token: 0x0600CC1A RID: 52250 RVA: 0x0032C82C File Offset: 0x0032AA2C
		public unsafe double EvacChopperDepartTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperDepartTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr_EvacChopperDepartTime)) = value;
			}
		}

		// Token: 0x17004A4D RID: 19021
		// (get) Token: 0x0600CC1B RID: 52251 RVA: 0x0032C850 File Offset: 0x0032AA50
		// (set) Token: 0x0600CC1C RID: 52252 RVA: 0x0032C884 File Offset: 0x0032AA84
		public unsafe Il2CppReferenceArray<OnwardPhotonPlayer> _safePlayers
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__safePlayers);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<OnwardPhotonPlayer>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__safePlayers), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A4E RID: 19022
		// (get) Token: 0x0600CC1D RID: 52253 RVA: 0x0032C8AC File Offset: 0x0032AAAC
		// (set) Token: 0x0600CC1E RID: 52254 RVA: 0x0032C8D4 File Offset: 0x0032AAD4
		public unsafe Onward.GameVariants.ObjectiveTypes _initializedType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__initializedType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__initializedType)) = value;
			}
		}

		// Token: 0x17004A4F RID: 19023
		// (get) Token: 0x0600CC1F RID: 52255 RVA: 0x0032C8F8 File Offset: 0x0032AAF8
		// (set) Token: 0x0600CC20 RID: 52256 RVA: 0x0032C920 File Offset: 0x0032AB20
		public unsafe bool _hasSpawnablePickup
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__hasSpawnablePickup);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__hasSpawnablePickup)) = value;
			}
		}

		// Token: 0x17004A50 RID: 19024
		// (get) Token: 0x0600CC21 RID: 52257 RVA: 0x0032C944 File Offset: 0x0032AB44
		// (set) Token: 0x0600CC22 RID: 52258 RVA: 0x0032C978 File Offset: 0x0032AB78
		public unsafe PickupData _spawnablePickup
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickup);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new PickupData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickup), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A51 RID: 19025
		// (get) Token: 0x0600CC23 RID: 52259 RVA: 0x0032C9A0 File Offset: 0x0032ABA0
		// (set) Token: 0x0600CC24 RID: 52260 RVA: 0x0032C9D4 File Offset: 0x0032ABD4
		public unsafe Onward.GameVariants.SpawnPoint _spawnablePickupLocation
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickupLocation);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Onward.GameVariants.SpawnPoint(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickupLocation), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A52 RID: 19026
		// (get) Token: 0x0600CC25 RID: 52261 RVA: 0x0032C9FC File Offset: 0x0032ABFC
		// (set) Token: 0x0600CC26 RID: 52262 RVA: 0x0032CA24 File Offset: 0x0032AC24
		public unsafe float _spawnablePickupDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickupDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__spawnablePickupDelay)) = value;
			}
		}

		// Token: 0x17004A53 RID: 19027
		// (get) Token: 0x0600CC27 RID: 52263 RVA: 0x0032CA48 File Offset: 0x0032AC48
		// (set) Token: 0x0600CC28 RID: 52264 RVA: 0x0032CA70 File Offset: 0x0032AC70
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(EvacObjective.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x040080E7 RID: 32999
		private static readonly IntPtr NativeFieldInfoPtr_Singleton;

		// Token: 0x040080E8 RID: 33000
		private static readonly IntPtr NativeFieldInfoPtr_HelicopterObjective;

		// Token: 0x040080E9 RID: 33001
		private static readonly IntPtr NativeFieldInfoPtr_UseMusic;

		// Token: 0x040080EA RID: 33002
		private static readonly IntPtr NativeFieldInfoPtr__evacChopperArrivalTime;

		// Token: 0x040080EB RID: 33003
		private static readonly IntPtr NativeFieldInfoPtr__musicStartTime;

		// Token: 0x040080EC RID: 33004
		private static readonly IntPtr NativeFieldInfoPtr__evacChopperLandTime;

		// Token: 0x040080ED RID: 33005
		private static readonly IntPtr NativeFieldInfoPtr__evacChopperDepartTime;

		// Token: 0x040080EE RID: 33006
		private static readonly IntPtr NativeFieldInfoPtr__musicStarted;

		// Token: 0x040080EF RID: 33007
		private static readonly IntPtr NativeFieldInfoPtr__evacSmokeOut;

		// Token: 0x040080F0 RID: 33008
		private static readonly IntPtr NativeFieldInfoPtr__beepPlayed;

		// Token: 0x040080F1 RID: 33009
		private static readonly IntPtr NativeFieldInfoPtr__evacVictoryTriggered;

		// Token: 0x040080F2 RID: 33010
		private static readonly IntPtr NativeFieldInfoPtr_MusicStartTime;

		// Token: 0x040080F3 RID: 33011
		private static readonly IntPtr NativeFieldInfoPtr_EvacChopperArrives;

		// Token: 0x040080F4 RID: 33012
		private static readonly IntPtr NativeFieldInfoPtr_EvacChopperLandTime;

		// Token: 0x040080F5 RID: 33013
		private static readonly IntPtr NativeFieldInfoPtr_EvacChopperDepartTime;

		// Token: 0x040080F6 RID: 33014
		private static readonly IntPtr NativeFieldInfoPtr__safePlayers;

		// Token: 0x040080F7 RID: 33015
		private static readonly IntPtr NativeFieldInfoPtr__initializedType;

		// Token: 0x040080F8 RID: 33016
		private static readonly IntPtr NativeFieldInfoPtr__hasSpawnablePickup;

		// Token: 0x040080F9 RID: 33017
		private static readonly IntPtr NativeFieldInfoPtr__spawnablePickup;

		// Token: 0x040080FA RID: 33018
		private static readonly IntPtr NativeFieldInfoPtr__spawnablePickupLocation;

		// Token: 0x040080FB RID: 33019
		private static readonly IntPtr NativeFieldInfoPtr__spawnablePickupDelay;

		// Token: 0x040080FC RID: 33020
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x040080FD RID: 33021
		private static readonly IntPtr NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0;

		// Token: 0x040080FE RID: 33022
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x040080FF RID: 33023
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x04008100 RID: 33024
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0;

		// Token: 0x04008101 RID: 33025
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0;

		// Token: 0x04008102 RID: 33026
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0;

		// Token: 0x04008103 RID: 33027
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0;

		// Token: 0x04008104 RID: 33028
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x04008105 RID: 33029
		private static readonly IntPtr NativeMethodInfoPtr_ActivateObjective_Public_Virtual_Void_0;

		// Token: 0x04008106 RID: 33030
		private static readonly IntPtr NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_Void_DPIPlayer_0;

		// Token: 0x04008107 RID: 33031
		private static readonly IntPtr NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_Boolean_0;

		// Token: 0x04008108 RID: 33032
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0;

		// Token: 0x04008109 RID: 33033
		private static readonly IntPtr NativeMethodInfoPtr_TickShared_Public_Virtual_Void_0;

		// Token: 0x0400810A RID: 33034
		private static readonly IntPtr NativeMethodInfoPtr_EvacPlayerSafeAction_Private_Void_PlayerEvacuationEvent_DPINetworkMessageInfo_0;

		// Token: 0x0400810B RID: 33035
		private static readonly IntPtr NativeMethodInfoPtr_OnVictoryTriggered_Private_Void_EvacVictoryTrigger_0;

		// Token: 0x0400810C RID: 33036
		private static readonly IntPtr NativeMethodInfoPtr_GetRemainingTime_Public_Double_0;

		// Token: 0x0400810D RID: 33037
		private static readonly IntPtr NativeMethodInfoPtr_GetTimeToLand_Public_Double_0;

		// Token: 0x0400810E RID: 33038
		private static readonly IntPtr NativeMethodInfoPtr_TickPickupSpawn_Private_Void_0;

		// Token: 0x0400810F RID: 33039
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
