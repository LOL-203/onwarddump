﻿using System;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000957 RID: 2391
	public enum UplinkState
	{
		// Token: 0x0400805A RID: 32858
		Idle,
		// Token: 0x0400805B RID: 32859
		Sending,
		// Token: 0x0400805C RID: 32860
		Canceling,
		// Token: 0x0400805D RID: 32861
		Sent,
		// Token: 0x0400805E RID: 32862
		Canceled
	}
}
