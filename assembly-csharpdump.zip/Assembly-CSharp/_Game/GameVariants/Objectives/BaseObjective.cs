﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.AI.Objectives;
using Onward.GameManagement;
using Onward.GameVariants;
using Onward.Mutators;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x02000952 RID: 2386
	public class BaseObjective : MonoBehaviour
	{
		// Token: 0x170049DE RID: 18910
		// (get) Token: 0x0600CACC RID: 51916 RVA: 0x00326F0C File Offset: 0x0032510C
		// (set) Token: 0x0600CACD RID: 51917 RVA: 0x00326F5C File Offset: 0x0032515C
		public unsafe bool IsObjectiveComplete
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BaseObjective.NativeMethodInfoPtr_get_IsObjectiveComplete_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseObjective.NativeMethodInfoPtr_set_IsObjectiveComplete_Protected_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170049DF RID: 18911
		// (get) Token: 0x0600CACE RID: 51918 RVA: 0x00326FB0 File Offset: 0x003251B0
		// (set) Token: 0x0600CACF RID: 51919 RVA: 0x00327000 File Offset: 0x00325200
		public unsafe bool IsObjectiveActive
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BaseObjective.NativeMethodInfoPtr_get_IsObjectiveActive_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseObjective.NativeMethodInfoPtr_set_IsObjectiveActive_Protected_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170049E0 RID: 18912
		// (get) Token: 0x0600CAD0 RID: 51920 RVA: 0x00327054 File Offset: 0x00325254
		public unsafe ActivateObjectiveState ActivateObjectiveState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_New_get_ActivateObjectiveState_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049E1 RID: 18913
		// (get) Token: 0x0600CAD1 RID: 51921 RVA: 0x003270B0 File Offset: 0x003252B0
		public unsafe Onward.GameVariants.ObjectiveTypes ObjectiveType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Abstract_Virtual_New_get_ObjectiveTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049E2 RID: 18914
		// (get) Token: 0x0600CAD2 RID: 51922 RVA: 0x0032710C File Offset: 0x0032530C
		public unsafe RoundEndTypes ObjectiveCompleteEndType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Abstract_Virtual_New_get_RoundEndTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CAD3 RID: 51923 RVA: 0x00327168 File Offset: 0x00325368
		[CallerCount(0)]
		public unsafe void Initialize(GameVariant activeVariant, BaseObjectiveData objectiveData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(activeVariant);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(objectiveData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_GameVariant_BaseObjectiveData_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD4 RID: 51924 RVA: 0x003271E4 File Offset: 0x003253E4
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD5 RID: 51925 RVA: 0x00327234 File Offset: 0x00325434
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_OnDestroy_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD6 RID: 51926 RVA: 0x00327284 File Offset: 0x00325484
		[CallerCount(0)]
		public unsafe void ActivateObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD7 RID: 51927 RVA: 0x003272D4 File Offset: 0x003254D4
		[CallerCount(0)]
		public unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD8 RID: 51928 RVA: 0x00327324 File Offset: 0x00325524
		[CallerCount(0)]
		public unsafe void TickShared()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAD9 RID: 51929 RVA: 0x00327374 File Offset: 0x00325574
		[CallerCount(0)]
		public unsafe void HostSetObjectiveSyncData(DPIPlayer host)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(host);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_New_Void_DPIPlayer_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CADA RID: 51930 RVA: 0x003273D8 File Offset: 0x003255D8
		[CallerCount(0)]
		public unsafe bool ClientSetObjectiveSyncData()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), BaseObjective.NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_New_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CADB RID: 51931 RVA: 0x00327434 File Offset: 0x00325634
		[CallerCount(0)]
		public unsafe BaseObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BaseObjective.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CADC RID: 51932 RVA: 0x00327480 File Offset: 0x00325680
		// Note: this type is marked as 'beforefieldinit'.
		static BaseObjective()
		{
			Il2CppClassPointerStore<BaseObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "BaseObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr);
			BaseObjective.NativeFieldInfoPtr_VariantOwner = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, "VariantOwner");
			BaseObjective.NativeFieldInfoPtr_Mutators = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, "Mutators");
			BaseObjective.NativeFieldInfoPtr_OnObjectiveComplete = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, "OnObjectiveComplete");
			BaseObjective.NativeFieldInfoPtr__IsObjectiveComplete_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, "<IsObjectiveComplete>k__BackingField");
			BaseObjective.NativeFieldInfoPtr__IsObjectiveActive_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, "<IsObjectiveActive>k__BackingField");
			BaseObjective.NativeMethodInfoPtr_get_IsObjectiveComplete_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678925);
			BaseObjective.NativeMethodInfoPtr_set_IsObjectiveComplete_Protected_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678926);
			BaseObjective.NativeMethodInfoPtr_get_IsObjectiveActive_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678927);
			BaseObjective.NativeMethodInfoPtr_set_IsObjectiveActive_Protected_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678928);
			BaseObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_New_get_ActivateObjectiveState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678929);
			BaseObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Abstract_Virtual_New_get_ObjectiveTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678930);
			BaseObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Abstract_Virtual_New_get_RoundEndTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678931);
			BaseObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_GameVariant_BaseObjectiveData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678932);
			BaseObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678933);
			BaseObjective.NativeMethodInfoPtr_OnDestroy_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678934);
			BaseObjective.NativeMethodInfoPtr_ActivateObjective_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678935);
			BaseObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678936);
			BaseObjective.NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678937);
			BaseObjective.NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_New_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678938);
			BaseObjective.NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678939);
			BaseObjective.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr, 100678940);
		}

		// Token: 0x0600CADD RID: 51933 RVA: 0x0000210C File Offset: 0x0000030C
		public BaseObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049D8 RID: 18904
		// (get) Token: 0x0600CADE RID: 51934 RVA: 0x00327654 File Offset: 0x00325854
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BaseObjective>.NativeClassPtr));
			}
		}

		// Token: 0x170049D9 RID: 18905
		// (get) Token: 0x0600CADF RID: 51935 RVA: 0x00327668 File Offset: 0x00325868
		// (set) Token: 0x0600CAE0 RID: 51936 RVA: 0x0032769C File Offset: 0x0032589C
		public unsafe GameVariant VariantOwner
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_VariantOwner);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameVariant(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_VariantOwner), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049DA RID: 18906
		// (get) Token: 0x0600CAE1 RID: 51937 RVA: 0x003276C4 File Offset: 0x003258C4
		// (set) Token: 0x0600CAE2 RID: 51938 RVA: 0x003276F8 File Offset: 0x003258F8
		public unsafe List<Mutator> Mutators
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_Mutators);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Mutator>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_Mutators), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049DB RID: 18907
		// (get) Token: 0x0600CAE3 RID: 51939 RVA: 0x00327720 File Offset: 0x00325920
		// (set) Token: 0x0600CAE4 RID: 51940 RVA: 0x00327754 File Offset: 0x00325954
		public unsafe Action OnObjectiveComplete
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_OnObjectiveComplete);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr_OnObjectiveComplete), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049DC RID: 18908
		// (get) Token: 0x0600CAE5 RID: 51941 RVA: 0x0032777C File Offset: 0x0032597C
		// (set) Token: 0x0600CAE6 RID: 51942 RVA: 0x003277A4 File Offset: 0x003259A4
		public unsafe bool _IsObjectiveComplete_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr__IsObjectiveComplete_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr__IsObjectiveComplete_k__BackingField)) = value;
			}
		}

		// Token: 0x170049DD RID: 18909
		// (get) Token: 0x0600CAE7 RID: 51943 RVA: 0x003277C8 File Offset: 0x003259C8
		// (set) Token: 0x0600CAE8 RID: 51944 RVA: 0x003277F0 File Offset: 0x003259F0
		public unsafe bool _IsObjectiveActive_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr__IsObjectiveActive_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BaseObjective.NativeFieldInfoPtr__IsObjectiveActive_k__BackingField)) = value;
			}
		}

		// Token: 0x0400802B RID: 32811
		private static readonly IntPtr NativeFieldInfoPtr_VariantOwner;

		// Token: 0x0400802C RID: 32812
		private static readonly IntPtr NativeFieldInfoPtr_Mutators;

		// Token: 0x0400802D RID: 32813
		private static readonly IntPtr NativeFieldInfoPtr_OnObjectiveComplete;

		// Token: 0x0400802E RID: 32814
		private static readonly IntPtr NativeFieldInfoPtr__IsObjectiveComplete_k__BackingField;

		// Token: 0x0400802F RID: 32815
		private static readonly IntPtr NativeFieldInfoPtr__IsObjectiveActive_k__BackingField;

		// Token: 0x04008030 RID: 32816
		private static readonly IntPtr NativeMethodInfoPtr_get_IsObjectiveComplete_Public_get_Boolean_0;

		// Token: 0x04008031 RID: 32817
		private static readonly IntPtr NativeMethodInfoPtr_set_IsObjectiveComplete_Protected_set_Void_Boolean_0;

		// Token: 0x04008032 RID: 32818
		private static readonly IntPtr NativeMethodInfoPtr_get_IsObjectiveActive_Public_get_Boolean_0;

		// Token: 0x04008033 RID: 32819
		private static readonly IntPtr NativeMethodInfoPtr_set_IsObjectiveActive_Protected_set_Void_Boolean_0;

		// Token: 0x04008034 RID: 32820
		private static readonly IntPtr NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_New_get_ActivateObjectiveState_0;

		// Token: 0x04008035 RID: 32821
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveType_Public_Abstract_Virtual_New_get_ObjectiveTypes_0;

		// Token: 0x04008036 RID: 32822
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Abstract_Virtual_New_get_RoundEndTypes_0;

		// Token: 0x04008037 RID: 32823
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_GameVariant_BaseObjectiveData_0;

		// Token: 0x04008038 RID: 32824
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0;

		// Token: 0x04008039 RID: 32825
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Public_Virtual_New_Void_0;

		// Token: 0x0400803A RID: 32826
		private static readonly IntPtr NativeMethodInfoPtr_ActivateObjective_Public_Virtual_New_Void_0;

		// Token: 0x0400803B RID: 32827
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0;

		// Token: 0x0400803C RID: 32828
		private static readonly IntPtr NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0;

		// Token: 0x0400803D RID: 32829
		private static readonly IntPtr NativeMethodInfoPtr_HostSetObjectiveSyncData_Protected_Virtual_New_Void_DPIPlayer_0;

		// Token: 0x0400803E RID: 32830
		private static readonly IntPtr NativeMethodInfoPtr_ClientSetObjectiveSyncData_Protected_Virtual_New_Boolean_0;

		// Token: 0x0400803F RID: 32831
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
