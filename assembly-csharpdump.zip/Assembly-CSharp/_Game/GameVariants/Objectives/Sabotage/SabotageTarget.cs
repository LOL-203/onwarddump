﻿using System;
using DPI.Networking;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using _Game.GameVariants.MercenaryMode;

namespace _Game.GameVariants.Objectives.Sabotage
{
	// Token: 0x0200095D RID: 2397
	public class SabotageTarget : MonoBehaviourDPINetworking
	{
		// Token: 0x17004A19 RID: 18969
		// (get) Token: 0x0600CB60 RID: 52064 RVA: 0x00329904 File Offset: 0x00327B04
		// (set) Token: 0x0600CB61 RID: 52065 RVA: 0x00329954 File Offset: 0x00327B54
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17004A1A RID: 18970
		// (get) Token: 0x0600CB62 RID: 52066 RVA: 0x003299A8 File Offset: 0x00327BA8
		public unsafe bool IsDestroyed
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_get_IsDestroyed_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CB63 RID: 52067 RVA: 0x003299F8 File Offset: 0x00327BF8
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB64 RID: 52068 RVA: 0x00329A3C File Offset: 0x00327C3C
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB65 RID: 52069 RVA: 0x00329A80 File Offset: 0x00327C80
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB66 RID: 52070 RVA: 0x00329AC4 File Offset: 0x00327CC4
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB67 RID: 52071 RVA: 0x00329B08 File Offset: 0x00327D08
		[CallerCount(0)]
		public unsafe void SetDamageObjects(bool damage)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref damage;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_SetDamageObjects_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB68 RID: 52072 RVA: 0x00329B5C File Offset: 0x00327D5C
		[CallerCount(0)]
		public unsafe void OnBodyDestruction(DPIPlayer source)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnBodyDestruction_Private_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB69 RID: 52073 RVA: 0x00329BB8 File Offset: 0x00327DB8
		[CallerCount(0)]
		public unsafe void OnCircuitDestruction(DPIPlayer source)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(source);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnCircuitDestruction_Private_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB6A RID: 52074 RVA: 0x00329C14 File Offset: 0x00327E14
		[CallerCount(0)]
		public unsafe void TakeOwnershipIfMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_TakeOwnershipIfMaster_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB6B RID: 52075 RVA: 0x00329C58 File Offset: 0x00327E58
		[CallerCount(0)]
		public unsafe void Cleanup()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_Cleanup_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB6C RID: 52076 RVA: 0x00329C9C File Offset: 0x00327E9C
		[CallerCount(0)]
		public unsafe void OnMasterClientSwitched(DPIPlayer player)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(player);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_OnMasterClientSwitched_Private_Void_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB6D RID: 52077 RVA: 0x00329CF8 File Offset: 0x00327EF8
		[CallerCount(0)]
		public unsafe bool LinkToObjective()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_LinkToObjective_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CB6E RID: 52078 RVA: 0x00329D48 File Offset: 0x00327F48
		[CallerCount(0)]
		public unsafe void SetJamPosition(Vector3 position)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref position;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_SetJamPosition_Private_Void_Vector3_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB6F RID: 52079 RVA: 0x00329D9C File Offset: 0x00327F9C
		[CallerCount(0)]
		public unsafe void CheckAudio()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr_CheckAudio_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB70 RID: 52080 RVA: 0x00329DE0 File Offset: 0x00327FE0
		[CallerCount(0)]
		public unsafe SabotageTarget() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageTarget.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB71 RID: 52081 RVA: 0x00329E2C File Offset: 0x0032802C
		// Note: this type is marked as 'beforefieldinit'.
		static SabotageTarget()
		{
			Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Sabotage", "SabotageTarget");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr);
			SabotageTarget.NativeFieldInfoPtr_DESTROY_WAIT_TIME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "DESTROY_WAIT_TIME");
			SabotageTarget.NativeFieldInfoPtr__bodyDamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_bodyDamageController");
			SabotageTarget.NativeFieldInfoPtr__circuitsDamageController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_circuitsDamageController");
			SabotageTarget.NativeFieldInfoPtr__circuitsObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_circuitsObject");
			SabotageTarget.NativeFieldInfoPtr__bodyDestructionFX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_bodyDestructionFX");
			SabotageTarget.NativeFieldInfoPtr__circuitsDestructionFX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_circuitsDestructionFX");
			SabotageTarget.NativeFieldInfoPtr__view = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_view");
			SabotageTarget.NativeFieldInfoPtr__openable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_openable");
			SabotageTarget.NativeFieldInfoPtr__audio = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_audio");
			SabotageTarget.NativeFieldInfoPtr__damagedObjects = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_damagedObjects");
			SabotageTarget.NativeFieldInfoPtr__undamagedObjects = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_undamagedObjects");
			SabotageTarget.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			SabotageTarget.NativeFieldInfoPtr__destroyedTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_destroyedTime");
			SabotageTarget.NativeFieldInfoPtr__variant = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_variant");
			SabotageTarget.NativeFieldInfoPtr__objective = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, "_objective");
			SabotageTarget.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678992);
			SabotageTarget.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678993);
			SabotageTarget.NativeMethodInfoPtr_get_IsDestroyed_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678994);
			SabotageTarget.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678995);
			SabotageTarget.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678996);
			SabotageTarget.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678997);
			SabotageTarget.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678998);
			SabotageTarget.NativeMethodInfoPtr_SetDamageObjects_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100678999);
			SabotageTarget.NativeMethodInfoPtr_OnBodyDestruction_Private_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679000);
			SabotageTarget.NativeMethodInfoPtr_OnCircuitDestruction_Private_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679001);
			SabotageTarget.NativeMethodInfoPtr_TakeOwnershipIfMaster_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679002);
			SabotageTarget.NativeMethodInfoPtr_Cleanup_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679003);
			SabotageTarget.NativeMethodInfoPtr_OnMasterClientSwitched_Private_Void_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679004);
			SabotageTarget.NativeMethodInfoPtr_LinkToObjective_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679005);
			SabotageTarget.NativeMethodInfoPtr_SetJamPosition_Private_Void_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679006);
			SabotageTarget.NativeMethodInfoPtr_CheckAudio_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679007);
			SabotageTarget.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr, 100679008);
		}

		// Token: 0x0600CB72 RID: 52082 RVA: 0x00047530 File Offset: 0x00045730
		public SabotageTarget(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A09 RID: 18953
		// (get) Token: 0x0600CB73 RID: 52083 RVA: 0x0032A0DC File Offset: 0x003282DC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SabotageTarget>.NativeClassPtr));
			}
		}

		// Token: 0x17004A0A RID: 18954
		// (get) Token: 0x0600CB74 RID: 52084 RVA: 0x0032A0F0 File Offset: 0x003282F0
		// (set) Token: 0x0600CB75 RID: 52085 RVA: 0x0032A10E File Offset: 0x0032830E
		public unsafe static float DESTROY_WAIT_TIME
		{
			get
			{
				float result;
				IL2CPP.il2cpp_field_static_get_value(SabotageTarget.NativeFieldInfoPtr_DESTROY_WAIT_TIME, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SabotageTarget.NativeFieldInfoPtr_DESTROY_WAIT_TIME, (void*)(&value));
			}
		}

		// Token: 0x17004A0B RID: 18955
		// (get) Token: 0x0600CB76 RID: 52086 RVA: 0x0032A120 File Offset: 0x00328320
		// (set) Token: 0x0600CB77 RID: 52087 RVA: 0x0032A154 File Offset: 0x00328354
		public unsafe DamageController _bodyDamageController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__bodyDamageController);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__bodyDamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A0C RID: 18956
		// (get) Token: 0x0600CB78 RID: 52088 RVA: 0x0032A17C File Offset: 0x0032837C
		// (set) Token: 0x0600CB79 RID: 52089 RVA: 0x0032A1B0 File Offset: 0x003283B0
		public unsafe DamageController _circuitsDamageController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsDamageController);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DamageController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsDamageController), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A0D RID: 18957
		// (get) Token: 0x0600CB7A RID: 52090 RVA: 0x0032A1D8 File Offset: 0x003283D8
		// (set) Token: 0x0600CB7B RID: 52091 RVA: 0x0032A20C File Offset: 0x0032840C
		public unsafe GameObject _circuitsObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A0E RID: 18958
		// (get) Token: 0x0600CB7C RID: 52092 RVA: 0x0032A234 File Offset: 0x00328434
		// (set) Token: 0x0600CB7D RID: 52093 RVA: 0x0032A268 File Offset: 0x00328468
		public unsafe GameObject _bodyDestructionFX
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__bodyDestructionFX);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__bodyDestructionFX), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A0F RID: 18959
		// (get) Token: 0x0600CB7E RID: 52094 RVA: 0x0032A290 File Offset: 0x00328490
		// (set) Token: 0x0600CB7F RID: 52095 RVA: 0x0032A2C4 File Offset: 0x003284C4
		public unsafe GameObject _circuitsDestructionFX
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsDestructionFX);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__circuitsDestructionFX), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A10 RID: 18960
		// (get) Token: 0x0600CB80 RID: 52096 RVA: 0x0032A2EC File Offset: 0x003284EC
		// (set) Token: 0x0600CB81 RID: 52097 RVA: 0x0032A320 File Offset: 0x00328520
		public unsafe DPIView _view
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__view);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DPIView(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__view), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A11 RID: 18961
		// (get) Token: 0x0600CB82 RID: 52098 RVA: 0x0032A348 File Offset: 0x00328548
		// (set) Token: 0x0600CB83 RID: 52099 RVA: 0x0032A37C File Offset: 0x0032857C
		public unsafe Interactable_Openable _openable
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__openable);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Interactable_Openable(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__openable), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A12 RID: 18962
		// (get) Token: 0x0600CB84 RID: 52100 RVA: 0x0032A3A4 File Offset: 0x003285A4
		// (set) Token: 0x0600CB85 RID: 52101 RVA: 0x0032A3D8 File Offset: 0x003285D8
		public unsafe AmbientAudioEmitter _audio
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__audio);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AmbientAudioEmitter(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__audio), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A13 RID: 18963
		// (get) Token: 0x0600CB86 RID: 52102 RVA: 0x0032A400 File Offset: 0x00328600
		// (set) Token: 0x0600CB87 RID: 52103 RVA: 0x0032A434 File Offset: 0x00328634
		public unsafe Il2CppReferenceArray<GameObject> _damagedObjects
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__damagedObjects);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__damagedObjects), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A14 RID: 18964
		// (get) Token: 0x0600CB88 RID: 52104 RVA: 0x0032A45C File Offset: 0x0032865C
		// (set) Token: 0x0600CB89 RID: 52105 RVA: 0x0032A490 File Offset: 0x00328690
		public unsafe Il2CppReferenceArray<GameObject> _undamagedObjects
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__undamagedObjects);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<GameObject>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__undamagedObjects), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A15 RID: 18965
		// (get) Token: 0x0600CB8A RID: 52106 RVA: 0x0032A4B8 File Offset: 0x003286B8
		// (set) Token: 0x0600CB8B RID: 52107 RVA: 0x0032A4E0 File Offset: 0x003286E0
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x17004A16 RID: 18966
		// (get) Token: 0x0600CB8C RID: 52108 RVA: 0x0032A504 File Offset: 0x00328704
		// (set) Token: 0x0600CB8D RID: 52109 RVA: 0x0032A52C File Offset: 0x0032872C
		public unsafe float _destroyedTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__destroyedTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__destroyedTime)) = value;
			}
		}

		// Token: 0x17004A17 RID: 18967
		// (get) Token: 0x0600CB8E RID: 52110 RVA: 0x0032A550 File Offset: 0x00328750
		// (set) Token: 0x0600CB8F RID: 52111 RVA: 0x0032A584 File Offset: 0x00328784
		public unsafe MercenaryVariant _variant
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__variant);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MercenaryVariant(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__variant), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A18 RID: 18968
		// (get) Token: 0x0600CB90 RID: 52112 RVA: 0x0032A5AC File Offset: 0x003287AC
		// (set) Token: 0x0600CB91 RID: 52113 RVA: 0x0032A5E0 File Offset: 0x003287E0
		public unsafe SabotageObjective _objective
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__objective);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new SabotageObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageTarget.NativeFieldInfoPtr__objective), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008090 RID: 32912
		private static readonly IntPtr NativeFieldInfoPtr_DESTROY_WAIT_TIME;

		// Token: 0x04008091 RID: 32913
		private static readonly IntPtr NativeFieldInfoPtr__bodyDamageController;

		// Token: 0x04008092 RID: 32914
		private static readonly IntPtr NativeFieldInfoPtr__circuitsDamageController;

		// Token: 0x04008093 RID: 32915
		private static readonly IntPtr NativeFieldInfoPtr__circuitsObject;

		// Token: 0x04008094 RID: 32916
		private static readonly IntPtr NativeFieldInfoPtr__bodyDestructionFX;

		// Token: 0x04008095 RID: 32917
		private static readonly IntPtr NativeFieldInfoPtr__circuitsDestructionFX;

		// Token: 0x04008096 RID: 32918
		private static readonly IntPtr NativeFieldInfoPtr__view;

		// Token: 0x04008097 RID: 32919
		private static readonly IntPtr NativeFieldInfoPtr__openable;

		// Token: 0x04008098 RID: 32920
		private static readonly IntPtr NativeFieldInfoPtr__audio;

		// Token: 0x04008099 RID: 32921
		private static readonly IntPtr NativeFieldInfoPtr__damagedObjects;

		// Token: 0x0400809A RID: 32922
		private static readonly IntPtr NativeFieldInfoPtr__undamagedObjects;

		// Token: 0x0400809B RID: 32923
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x0400809C RID: 32924
		private static readonly IntPtr NativeFieldInfoPtr__destroyedTime;

		// Token: 0x0400809D RID: 32925
		private static readonly IntPtr NativeFieldInfoPtr__variant;

		// Token: 0x0400809E RID: 32926
		private static readonly IntPtr NativeFieldInfoPtr__objective;

		// Token: 0x0400809F RID: 32927
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x040080A0 RID: 32928
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x040080A1 RID: 32929
		private static readonly IntPtr NativeMethodInfoPtr_get_IsDestroyed_Public_get_Boolean_0;

		// Token: 0x040080A2 RID: 32930
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x040080A3 RID: 32931
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x040080A4 RID: 32932
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x040080A5 RID: 32933
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x040080A6 RID: 32934
		private static readonly IntPtr NativeMethodInfoPtr_SetDamageObjects_Private_Void_Boolean_0;

		// Token: 0x040080A7 RID: 32935
		private static readonly IntPtr NativeMethodInfoPtr_OnBodyDestruction_Private_Void_DPIPlayer_0;

		// Token: 0x040080A8 RID: 32936
		private static readonly IntPtr NativeMethodInfoPtr_OnCircuitDestruction_Private_Void_DPIPlayer_0;

		// Token: 0x040080A9 RID: 32937
		private static readonly IntPtr NativeMethodInfoPtr_TakeOwnershipIfMaster_Private_Void_0;

		// Token: 0x040080AA RID: 32938
		private static readonly IntPtr NativeMethodInfoPtr_Cleanup_Public_Void_0;

		// Token: 0x040080AB RID: 32939
		private static readonly IntPtr NativeMethodInfoPtr_OnMasterClientSwitched_Private_Void_DPIPlayer_0;

		// Token: 0x040080AC RID: 32940
		private static readonly IntPtr NativeMethodInfoPtr_LinkToObjective_Private_Boolean_0;

		// Token: 0x040080AD RID: 32941
		private static readonly IntPtr NativeMethodInfoPtr_SetJamPosition_Private_Void_Vector3_0;

		// Token: 0x040080AE RID: 32942
		private static readonly IntPtr NativeMethodInfoPtr_CheckAudio_Private_Void_0;

		// Token: 0x040080AF RID: 32943
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
