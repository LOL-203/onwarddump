﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Sabotage
{
	// Token: 0x0200095C RID: 2396
	public class SabotageObjectiveData : BaseObjectiveData
	{
		// Token: 0x0600CB5C RID: 52060 RVA: 0x0032986C File Offset: 0x00327A6C
		[CallerCount(0)]
		public unsafe SabotageObjectiveData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SabotageObjectiveData>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB5D RID: 52061 RVA: 0x003298B7 File Offset: 0x00327AB7
		// Note: this type is marked as 'beforefieldinit'.
		static SabotageObjectiveData()
		{
			Il2CppClassPointerStore<SabotageObjectiveData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Sabotage", "SabotageObjectiveData");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SabotageObjectiveData>.NativeClassPtr);
			SabotageObjectiveData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjectiveData>.NativeClassPtr, 100678991);
		}

		// Token: 0x0600CB5E RID: 52062 RVA: 0x00328E3C File Offset: 0x0032703C
		public SabotageObjectiveData(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A08 RID: 18952
		// (get) Token: 0x0600CB5F RID: 52063 RVA: 0x003298F0 File Offset: 0x00327AF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SabotageObjectiveData>.NativeClassPtr));
			}
		}

		// Token: 0x0400808F RID: 32911
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
