﻿using System;
using Il2CppSystem;
using Onward.AI.Objectives;
using Onward.Data;
using Onward.GameManagement;
using Onward.GameVariants;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives.Sabotage
{
	// Token: 0x0200095B RID: 2395
	public class SabotageObjective : BaseObjective
	{
		// Token: 0x17004A05 RID: 18949
		// (get) Token: 0x0600CB4E RID: 52046 RVA: 0x00329440 File Offset: 0x00327640
		public new unsafe Onward.GameVariants.ObjectiveTypes ObjectiveType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A06 RID: 18950
		// (get) Token: 0x0600CB4F RID: 52047 RVA: 0x0032949C File Offset: 0x0032769C
		public new unsafe RoundEndTypes ObjectiveCompleteEndType
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x17004A07 RID: 18951
		// (get) Token: 0x0600CB50 RID: 52048 RVA: 0x003294F8 File Offset: 0x003276F8
		public new unsafe ActivateObjectiveState ActivateObjectiveState
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CB51 RID: 52049 RVA: 0x00329554 File Offset: 0x00327754
		[CallerCount(0)]
		public new unsafe void Initialize(GameVariant activeVariant, BaseObjectiveData objectiveData)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(activeVariant);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(objectiveData);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB52 RID: 52050 RVA: 0x003295D0 File Offset: 0x003277D0
		[CallerCount(0)]
		public new unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB53 RID: 52051 RVA: 0x00329620 File Offset: 0x00327820
		[CallerCount(0)]
		public new unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SabotageObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB54 RID: 52052 RVA: 0x00329670 File Offset: 0x00327870
		[CallerCount(0)]
		public unsafe SabotageObjective() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SabotageObjective.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB55 RID: 52053 RVA: 0x003296BC File Offset: 0x003278BC
		// Note: this type is marked as 'beforefieldinit'.
		static SabotageObjective()
		{
			Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives.Sabotage", "SabotageObjective");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr);
			SabotageObjective.NativeFieldInfoPtr__targetData = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, "_targetData");
			SabotageObjective.NativeFieldInfoPtr_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, "Target");
			SabotageObjective.NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678984);
			SabotageObjective.NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678985);
			SabotageObjective.NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678986);
			SabotageObjective.NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678987);
			SabotageObjective.NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678988);
			SabotageObjective.NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678989);
			SabotageObjective.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr, 100678990);
		}

		// Token: 0x0600CB56 RID: 52054 RVA: 0x00328BBC File Offset: 0x00326DBC
		public SabotageObjective(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004A02 RID: 18946
		// (get) Token: 0x0600CB57 RID: 52055 RVA: 0x003297A0 File Offset: 0x003279A0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SabotageObjective>.NativeClassPtr));
			}
		}

		// Token: 0x17004A03 RID: 18947
		// (get) Token: 0x0600CB58 RID: 52056 RVA: 0x003297B4 File Offset: 0x003279B4
		// (set) Token: 0x0600CB59 RID: 52057 RVA: 0x003297E8 File Offset: 0x003279E8
		public unsafe AssetReferenceData _targetData
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageObjective.NativeFieldInfoPtr__targetData);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AssetReferenceData(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageObjective.NativeFieldInfoPtr__targetData), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A04 RID: 18948
		// (get) Token: 0x0600CB5A RID: 52058 RVA: 0x00329810 File Offset: 0x00327A10
		// (set) Token: 0x0600CB5B RID: 52059 RVA: 0x00329844 File Offset: 0x00327A44
		public unsafe SabotageTarget Target
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageObjective.NativeFieldInfoPtr_Target);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new SabotageTarget(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SabotageObjective.NativeFieldInfoPtr_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008086 RID: 32902
		private static readonly IntPtr NativeFieldInfoPtr__targetData;

		// Token: 0x04008087 RID: 32903
		private static readonly IntPtr NativeFieldInfoPtr_Target;

		// Token: 0x04008088 RID: 32904
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveType_Public_Virtual_get_ObjectiveTypes_0;

		// Token: 0x04008089 RID: 32905
		private static readonly IntPtr NativeMethodInfoPtr_get_ObjectiveCompleteEndType_Public_Virtual_get_RoundEndTypes_0;

		// Token: 0x0400808A RID: 32906
		private static readonly IntPtr NativeMethodInfoPtr_get_ActivateObjectiveState_Public_Virtual_get_ActivateObjectiveState_0;

		// Token: 0x0400808B RID: 32907
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_Void_GameVariant_BaseObjectiveData_0;

		// Token: 0x0400808C RID: 32908
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_Void_0;

		// Token: 0x0400808D RID: 32909
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_Void_0;

		// Token: 0x0400808E RID: 32910
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
