﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.GameVariants.Objectives
{
	// Token: 0x0200095A RID: 2394
	[Serializable]
	public class UplinkSubtype : Object
	{
		// Token: 0x0600CB3B RID: 52027 RVA: 0x00328EA4 File Offset: 0x003270A4
		[CallerCount(0)]
		public unsafe void Initialize(UplinkObjective owner)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(owner);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_UplinkObjective_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB3C RID: 52028 RVA: 0x00328F08 File Offset: 0x00327108
		[CallerCount(0)]
		public unsafe void OnCodeSent(UplinkCodeSentEvent unused, DPINetworkMessageInfo info)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref unused;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_New_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB3D RID: 52029 RVA: 0x00328F84 File Offset: 0x00327184
		[CallerCount(0)]
		public unsafe void Uninitialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB3E RID: 52030 RVA: 0x00328FD4 File Offset: 0x003271D4
		[CallerCount(0)]
		public unsafe float GetRemainingSendTime(bool isCancelTime)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref isCancelTime;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_GetRemainingSendTime_Public_Abstract_Virtual_New_Single_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CB3F RID: 52031 RVA: 0x00329044 File Offset: 0x00327244
		[CallerCount(0)]
		public unsafe void TickMaster()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB40 RID: 52032 RVA: 0x00329094 File Offset: 0x00327294
		[CallerCount(0)]
		public unsafe void TickShared()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB41 RID: 52033 RVA: 0x003290E4 File Offset: 0x003272E4
		[CallerCount(0)]
		public unsafe void OnUplinkStateChange(UplinkStateChangedEvent uplinkEvent, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref uplinkEvent;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), UplinkSubtype.NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_New_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB42 RID: 52034 RVA: 0x00329160 File Offset: 0x00327360
		[CallerCount(0)]
		public unsafe UplinkSubtype() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(UplinkSubtype.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CB43 RID: 52035 RVA: 0x003291AC File Offset: 0x003273AC
		// Note: this type is marked as 'beforefieldinit'.
		static UplinkSubtype()
		{
			Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.GameVariants.Objectives", "UplinkSubtype");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr);
			UplinkSubtype.NativeFieldInfoPtr__parent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, "_parent");
			UplinkSubtype.NativeFieldInfoPtr_SendingPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, "SendingPlayer");
			UplinkSubtype.NativeFieldInfoPtr_UplinkState = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, "UplinkState");
			UplinkSubtype.NativeFieldInfoPtr_OnUplinkStateChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, "OnUplinkStateChanged");
			UplinkSubtype.NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_UplinkObjective_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678976);
			UplinkSubtype.NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_New_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678977);
			UplinkSubtype.NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678978);
			UplinkSubtype.NativeMethodInfoPtr_GetRemainingSendTime_Public_Abstract_Virtual_New_Single_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678979);
			UplinkSubtype.NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678980);
			UplinkSubtype.NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678981);
			UplinkSubtype.NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_New_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678982);
			UplinkSubtype.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr, 100678983);
		}

		// Token: 0x0600CB44 RID: 52036 RVA: 0x00002988 File Offset: 0x00000B88
		public UplinkSubtype(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049FD RID: 18941
		// (get) Token: 0x0600CB45 RID: 52037 RVA: 0x003292CC File Offset: 0x003274CC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<UplinkSubtype>.NativeClassPtr));
			}
		}

		// Token: 0x170049FE RID: 18942
		// (get) Token: 0x0600CB46 RID: 52038 RVA: 0x003292E0 File Offset: 0x003274E0
		// (set) Token: 0x0600CB47 RID: 52039 RVA: 0x00329314 File Offset: 0x00327514
		public unsafe UplinkObjective _parent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr__parent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UplinkObjective(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr__parent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049FF RID: 18943
		// (get) Token: 0x0600CB48 RID: 52040 RVA: 0x0032933C File Offset: 0x0032753C
		// (set) Token: 0x0600CB49 RID: 52041 RVA: 0x00329370 File Offset: 0x00327570
		public unsafe OnwardPhotonPlayer SendingPlayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_SendingPlayer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new OnwardPhotonPlayer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_SendingPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004A00 RID: 18944
		// (get) Token: 0x0600CB4A RID: 52042 RVA: 0x00329398 File Offset: 0x00327598
		// (set) Token: 0x0600CB4B RID: 52043 RVA: 0x003293C0 File Offset: 0x003275C0
		public unsafe UplinkState UplinkState
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_UplinkState);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_UplinkState)) = value;
			}
		}

		// Token: 0x17004A01 RID: 18945
		// (get) Token: 0x0600CB4C RID: 52044 RVA: 0x003293E4 File Offset: 0x003275E4
		// (set) Token: 0x0600CB4D RID: 52045 RVA: 0x00329418 File Offset: 0x00327618
		public unsafe Action<UplinkState, double, double> OnUplinkStateChanged
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_OnUplinkStateChanged);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action<UplinkState, double, double>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(UplinkSubtype.NativeFieldInfoPtr_OnUplinkStateChanged), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x0400807A RID: 32890
		private static readonly IntPtr NativeFieldInfoPtr__parent;

		// Token: 0x0400807B RID: 32891
		private static readonly IntPtr NativeFieldInfoPtr_SendingPlayer;

		// Token: 0x0400807C RID: 32892
		private static readonly IntPtr NativeFieldInfoPtr_UplinkState;

		// Token: 0x0400807D RID: 32893
		private static readonly IntPtr NativeFieldInfoPtr_OnUplinkStateChanged;

		// Token: 0x0400807E RID: 32894
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Virtual_New_Void_UplinkObjective_0;

		// Token: 0x0400807F RID: 32895
		private static readonly IntPtr NativeMethodInfoPtr_OnCodeSent_Protected_Virtual_New_Void_UplinkCodeSentEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008080 RID: 32896
		private static readonly IntPtr NativeMethodInfoPtr_Uninitialize_Public_Virtual_New_Void_0;

		// Token: 0x04008081 RID: 32897
		private static readonly IntPtr NativeMethodInfoPtr_GetRemainingSendTime_Public_Abstract_Virtual_New_Single_Boolean_0;

		// Token: 0x04008082 RID: 32898
		private static readonly IntPtr NativeMethodInfoPtr_TickMaster_Public_Virtual_New_Void_0;

		// Token: 0x04008083 RID: 32899
		private static readonly IntPtr NativeMethodInfoPtr_TickShared_Public_Virtual_New_Void_0;

		// Token: 0x04008084 RID: 32900
		private static readonly IntPtr NativeMethodInfoPtr_OnUplinkStateChange_Protected_Virtual_New_Void_UplinkStateChangedEvent_DPINetworkMessageInfo_0;

		// Token: 0x04008085 RID: 32901
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
