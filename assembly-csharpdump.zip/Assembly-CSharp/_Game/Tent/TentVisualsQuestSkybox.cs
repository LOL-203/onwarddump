﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.Tent
{
	// Token: 0x0200094A RID: 2378
	public class TentVisualsQuestSkybox : MonoBehaviour
	{
		// Token: 0x0600C9FC RID: 51708 RVA: 0x00323710 File Offset: 0x00321910
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TentVisualsQuestSkybox.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9FD RID: 51709 RVA: 0x00323754 File Offset: 0x00321954
		[CallerCount(0)]
		public unsafe void TurnOffSkyBox()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TentVisualsQuestSkybox.NativeMethodInfoPtr_TurnOffSkyBox_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9FE RID: 51710 RVA: 0x00323798 File Offset: 0x00321998
		[CallerCount(0)]
		public unsafe TentVisualsQuestSkybox() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(TentVisualsQuestSkybox.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9FF RID: 51711 RVA: 0x003237E4 File Offset: 0x003219E4
		// Note: this type is marked as 'beforefieldinit'.
		static TentVisualsQuestSkybox()
		{
			Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Tent", "TentVisualsQuestSkybox");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr);
			TentVisualsQuestSkybox.NativeFieldInfoPtr_SkyboxMesh = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr, "SkyboxMesh");
			TentVisualsQuestSkybox.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr, 100678847);
			TentVisualsQuestSkybox.NativeMethodInfoPtr_TurnOffSkyBox_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr, 100678848);
			TentVisualsQuestSkybox.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr, 100678849);
		}

		// Token: 0x0600CA00 RID: 51712 RVA: 0x0000210C File Offset: 0x0000030C
		public TentVisualsQuestSkybox(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004993 RID: 18835
		// (get) Token: 0x0600CA01 RID: 51713 RVA: 0x00323864 File Offset: 0x00321A64
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TentVisualsQuestSkybox>.NativeClassPtr));
			}
		}

		// Token: 0x17004994 RID: 18836
		// (get) Token: 0x0600CA02 RID: 51714 RVA: 0x00323878 File Offset: 0x00321A78
		// (set) Token: 0x0600CA03 RID: 51715 RVA: 0x003238AC File Offset: 0x00321AAC
		public unsafe GameObject SkyboxMesh
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(TentVisualsQuestSkybox.NativeFieldInfoPtr_SkyboxMesh);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(TentVisualsQuestSkybox.NativeFieldInfoPtr_SkyboxMesh), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F96 RID: 32662
		private static readonly IntPtr NativeFieldInfoPtr_SkyboxMesh;

		// Token: 0x04007F97 RID: 32663
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04007F98 RID: 32664
		private static readonly IntPtr NativeMethodInfoPtr_TurnOffSkyBox_Public_Void_0;

		// Token: 0x04007F99 RID: 32665
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
