﻿using System;
using DPI.Agreements;
using DPI.Services;
using DPI.Web;
using Il2CppSystem;
using Il2CppSystem.Collections.Concurrent;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.Services.Common
{
	// Token: 0x0200094B RID: 2379
	public class LicenseAgreementService : OnwardService
	{
		// Token: 0x1700499F RID: 18847
		// (get) Token: 0x0600CA04 RID: 51716 RVA: 0x003238D4 File Offset: 0x00321AD4
		public new unsafe OnwardServiceType Type
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_get_Type_Public_Virtual_get_OnwardServiceType_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049A0 RID: 18848
		// (get) Token: 0x0600CA05 RID: 51717 RVA: 0x00323930 File Offset: 0x00321B30
		public new unsafe bool ServiceCanTrigger
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_get_ServiceCanTrigger_Protected_Virtual_get_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CA06 RID: 51718 RVA: 0x0032398C File Offset: 0x00321B8C
		[CallerCount(0)]
		public unsafe bool IsWaitTimeUp()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_IsWaitTimeUp_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x170049A1 RID: 18849
		// (get) Token: 0x0600CA07 RID: 51719 RVA: 0x003239DC File Offset: 0x00321BDC
		public new unsafe int RetryTimeMsWhenSucceeded
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_get_RetryTimeMsWhenSucceeded_Protected_Virtual_get_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x170049A2 RID: 18850
		// (get) Token: 0x0600CA08 RID: 51720 RVA: 0x00323A38 File Offset: 0x00321C38
		public new unsafe int RetryTimeMsWhenNotSucceeded
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_get_RetryTimeMsWhenNotSucceeded_Protected_Virtual_get_Int32_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CA09 RID: 51721 RVA: 0x00323A94 File Offset: 0x00321C94
		[CallerCount(0)]
		public unsafe LicenseAgreementService(OnwardServiceManager manager, ConcurrentQueue<Action> actionQueue) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(manager);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(actionQueue);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr__ctor_Public_Void_OnwardServiceManager_ConcurrentQueue_1_Action_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170049A3 RID: 18851
		// (get) Token: 0x0600CA0A RID: 51722 RVA: 0x00323B10 File Offset: 0x00321D10
		public unsafe DownpourAgreements AllAgreements
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_get_AllAgreements_Public_get_DownpourAgreements_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new DownpourAgreements(intPtr2) : null;
			}
		}

		// Token: 0x0600CA0B RID: 51723 RVA: 0x00323B68 File Offset: 0x00321D68
		[CallerCount(0)]
		public new unsafe void PerformService()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_PerformService_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA0C RID: 51724 RVA: 0x00323BB8 File Offset: 0x00321DB8
		[CallerCount(0)]
		public new unsafe void UpdateServiceTrigger()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseAgreementService.NativeMethodInfoPtr_UpdateServiceTrigger_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA0D RID: 51725 RVA: 0x00323C08 File Offset: 0x00321E08
		[CallerCount(0)]
		public unsafe void OnAgreementsReceivedFromWeb(string json)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(json);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_OnAgreementsReceivedFromWeb_Private_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA0E RID: 51726 RVA: 0x00323C64 File Offset: 0x00321E64
		[CallerCount(0)]
		public unsafe bool TryGetNextLicenseAgreementToShow(out LicenseAgreement licenseAgreement)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(licenseAgreement);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_TryGetNextLicenseAgreementToShow_Public_Boolean_byref_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			licenseAgreement = ((intPtr2 == 0) ? null : new LicenseAgreement(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA0F RID: 51727 RVA: 0x00323CEC File Offset: 0x00321EEC
		[CallerCount(0)]
		public unsafe void OnFailedToGetAgreementsFromWeb(Exception exception, FailedGetRequest failedGetRequest)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(exception);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(failedGetRequest));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_OnFailedToGetAgreementsFromWeb_Private_Void_Exception_FailedGetRequest_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA10 RID: 51728 RVA: 0x00323D64 File Offset: 0x00321F64
		[CallerCount(0)]
		public unsafe void InitializeAgreements()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_InitializeAgreements_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA11 RID: 51729 RVA: 0x00323DA8 File Offset: 0x00321FA8
		[CallerCount(0)]
		public unsafe void CompareAndCacheLocalUserAgreements()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_CompareAndCacheLocalUserAgreements_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA12 RID: 51730 RVA: 0x00323DEC File Offset: 0x00321FEC
		[CallerCount(0)]
		public unsafe void CollectAgreementsToShow()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_CollectAgreementsToShow_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA13 RID: 51731 RVA: 0x00323E30 File Offset: 0x00322030
		[CallerCount(0)]
		public unsafe bool TryGetLocallyCachedAgreements(out List<LicenseAgreement> cachedLicenseAgreements)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(cachedLicenseAgreements);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_TryGetLocallyCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			cachedLicenseAgreements = ((intPtr2 == 0) ? null : new List(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA14 RID: 51732 RVA: 0x00323EB8 File Offset: 0x003220B8
		[CallerCount(0)]
		public unsafe bool TryGetBuildCachedAgreements(out List<LicenseAgreement> buildCachedAgreements)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtr(buildCachedAgreements);
			ptr2 = &intPtr;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_TryGetBuildCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			buildCachedAgreements = ((intPtr2 == 0) ? null : new List(intPtr2));
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA15 RID: 51733 RVA: 0x00323F40 File Offset: 0x00322140
		[CallerCount(0)]
		public unsafe void CacheAgreement(LicenseAgreement agreement)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(agreement);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_CacheAgreement_Public_Void_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA16 RID: 51734 RVA: 0x00323F9C File Offset: 0x0032219C
		[CallerCount(0)]
		public unsafe bool HasUserAgreedToLicenseAgreement(LicenseAgreementType typeToCheck)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref typeToCheck;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_HasUserAgreedToLicenseAgreement_Public_Boolean_LicenseAgreementType_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA17 RID: 51735 RVA: 0x00324000 File Offset: 0x00322200
		[CallerCount(0)]
		public unsafe void CacheUserAgreements(DownpourAgreements agreementsToCache)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(agreementsToCache);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_CacheUserAgreements_Private_Void_DownpourAgreements_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CA18 RID: 51736 RVA: 0x0032405C File Offset: 0x0032225C
		[CallerCount(0)]
		public unsafe bool IsCachedAgreementVersionValid(LicenseAgreement latestLicenseAgreement, LicenseAgreement cachedLicenseAgreement)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(latestLicenseAgreement);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(cachedLicenseAgreement);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(LicenseAgreementService.NativeMethodInfoPtr_IsCachedAgreementVersionValid_Private_Boolean_LicenseAgreement_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CA19 RID: 51737 RVA: 0x003240DC File Offset: 0x003222DC
		// Note: this type is marked as 'beforefieldinit'.
		static LicenseAgreementService()
		{
			Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Services.Common", "LicenseAgreementService");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr);
			LicenseAgreementService.NativeFieldInfoPtr__localAgreementDir = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "_localAgreementDir");
			LicenseAgreementService.NativeFieldInfoPtr_TIME_TO_WAIT_FOR_INTERNET = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "TIME_TO_WAIT_FOR_INTERNET");
			LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "OnLicenseAgreementsChanged");
			LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsValidated = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "OnLicenseAgreementsValidated");
			LicenseAgreementService.NativeFieldInfoPtr__startTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "_startTime");
			LicenseAgreementService.NativeFieldInfoPtr__allAgreements = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "_allAgreements");
			LicenseAgreementService.NativeFieldInfoPtr__agreementsToShow = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "_agreementsToShow");
			LicenseAgreementService.NativeFieldInfoPtr__performCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "_performCount");
			LicenseAgreementService.NativeFieldInfoPtr_PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, "PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE");
			LicenseAgreementService.NativeMethodInfoPtr_get_Type_Public_Virtual_get_OnwardServiceType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678850);
			LicenseAgreementService.NativeMethodInfoPtr_get_ServiceCanTrigger_Protected_Virtual_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678851);
			LicenseAgreementService.NativeMethodInfoPtr_IsWaitTimeUp_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678852);
			LicenseAgreementService.NativeMethodInfoPtr_get_RetryTimeMsWhenSucceeded_Protected_Virtual_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678853);
			LicenseAgreementService.NativeMethodInfoPtr_get_RetryTimeMsWhenNotSucceeded_Protected_Virtual_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678854);
			LicenseAgreementService.NativeMethodInfoPtr__ctor_Public_Void_OnwardServiceManager_ConcurrentQueue_1_Action_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678855);
			LicenseAgreementService.NativeMethodInfoPtr_get_AllAgreements_Public_get_DownpourAgreements_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678856);
			LicenseAgreementService.NativeMethodInfoPtr_PerformService_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678857);
			LicenseAgreementService.NativeMethodInfoPtr_UpdateServiceTrigger_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678858);
			LicenseAgreementService.NativeMethodInfoPtr_OnAgreementsReceivedFromWeb_Private_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678859);
			LicenseAgreementService.NativeMethodInfoPtr_TryGetNextLicenseAgreementToShow_Public_Boolean_byref_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678860);
			LicenseAgreementService.NativeMethodInfoPtr_OnFailedToGetAgreementsFromWeb_Private_Void_Exception_FailedGetRequest_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678861);
			LicenseAgreementService.NativeMethodInfoPtr_InitializeAgreements_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678862);
			LicenseAgreementService.NativeMethodInfoPtr_CompareAndCacheLocalUserAgreements_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678863);
			LicenseAgreementService.NativeMethodInfoPtr_CollectAgreementsToShow_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678864);
			LicenseAgreementService.NativeMethodInfoPtr_TryGetLocallyCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678865);
			LicenseAgreementService.NativeMethodInfoPtr_TryGetBuildCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678866);
			LicenseAgreementService.NativeMethodInfoPtr_CacheAgreement_Public_Void_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678867);
			LicenseAgreementService.NativeMethodInfoPtr_HasUserAgreedToLicenseAgreement_Public_Boolean_LicenseAgreementType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678868);
			LicenseAgreementService.NativeMethodInfoPtr_CacheUserAgreements_Private_Void_DownpourAgreements_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678869);
			LicenseAgreementService.NativeMethodInfoPtr_IsCachedAgreementVersionValid_Private_Boolean_LicenseAgreement_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr, 100678870);
		}

		// Token: 0x0600CA1A RID: 51738 RVA: 0x00324364 File Offset: 0x00322564
		public LicenseAgreementService(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004995 RID: 18837
		// (get) Token: 0x0600CA1B RID: 51739 RVA: 0x0032436D File Offset: 0x0032256D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Il2CppSystem.Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<LicenseAgreementService>.NativeClassPtr));
			}
		}

		// Token: 0x17004996 RID: 18838
		// (get) Token: 0x0600CA1C RID: 51740 RVA: 0x00324380 File Offset: 0x00322580
		// (set) Token: 0x0600CA1D RID: 51741 RVA: 0x003243A0 File Offset: 0x003225A0
		public unsafe static string _localAgreementDir
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(LicenseAgreementService.NativeFieldInfoPtr__localAgreementDir, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(LicenseAgreementService.NativeFieldInfoPtr__localAgreementDir, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17004997 RID: 18839
		// (get) Token: 0x0600CA1E RID: 51742 RVA: 0x003243B8 File Offset: 0x003225B8
		// (set) Token: 0x0600CA1F RID: 51743 RVA: 0x003243D6 File Offset: 0x003225D6
		public unsafe static int TIME_TO_WAIT_FOR_INTERNET
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(LicenseAgreementService.NativeFieldInfoPtr_TIME_TO_WAIT_FOR_INTERNET, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(LicenseAgreementService.NativeFieldInfoPtr_TIME_TO_WAIT_FOR_INTERNET, (void*)(&value));
			}
		}

		// Token: 0x17004998 RID: 18840
		// (get) Token: 0x0600CA20 RID: 51744 RVA: 0x003243E8 File Offset: 0x003225E8
		// (set) Token: 0x0600CA21 RID: 51745 RVA: 0x0032441C File Offset: 0x0032261C
		public unsafe Action OnLicenseAgreementsChanged
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsChanged);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsChanged), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004999 RID: 18841
		// (get) Token: 0x0600CA22 RID: 51746 RVA: 0x00324444 File Offset: 0x00322644
		// (set) Token: 0x0600CA23 RID: 51747 RVA: 0x00324478 File Offset: 0x00322678
		public unsafe Action OnLicenseAgreementsValidated
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsValidated);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr_OnLicenseAgreementsValidated), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700499A RID: 18842
		// (get) Token: 0x0600CA24 RID: 51748 RVA: 0x003244A0 File Offset: 0x003226A0
		// (set) Token: 0x0600CA25 RID: 51749 RVA: 0x003244C8 File Offset: 0x003226C8
		public unsafe int _startTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__startTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__startTime)) = value;
			}
		}

		// Token: 0x1700499B RID: 18843
		// (get) Token: 0x0600CA26 RID: 51750 RVA: 0x003244EC File Offset: 0x003226EC
		// (set) Token: 0x0600CA27 RID: 51751 RVA: 0x00324520 File Offset: 0x00322720
		public unsafe DownpourAgreements _allAgreements
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__allAgreements);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DownpourAgreements(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__allAgreements), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700499C RID: 18844
		// (get) Token: 0x0600CA28 RID: 51752 RVA: 0x00324548 File Offset: 0x00322748
		// (set) Token: 0x0600CA29 RID: 51753 RVA: 0x0032457C File Offset: 0x0032277C
		public unsafe Queue<LicenseAgreement> _agreementsToShow
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__agreementsToShow);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Queue<LicenseAgreement>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__agreementsToShow), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700499D RID: 18845
		// (get) Token: 0x0600CA2A RID: 51754 RVA: 0x003245A4 File Offset: 0x003227A4
		// (set) Token: 0x0600CA2B RID: 51755 RVA: 0x003245CC File Offset: 0x003227CC
		public unsafe int _performCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__performCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseAgreementService.NativeFieldInfoPtr__performCount)) = value;
			}
		}

		// Token: 0x1700499E RID: 18846
		// (get) Token: 0x0600CA2C RID: 51756 RVA: 0x003245F0 File Offset: 0x003227F0
		// (set) Token: 0x0600CA2D RID: 51757 RVA: 0x0032460E File Offset: 0x0032280E
		public unsafe static int PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(LicenseAgreementService.NativeFieldInfoPtr_PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(LicenseAgreementService.NativeFieldInfoPtr_PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE, (void*)(&value));
			}
		}

		// Token: 0x04007F9A RID: 32666
		private static readonly IntPtr NativeFieldInfoPtr__localAgreementDir;

		// Token: 0x04007F9B RID: 32667
		private static readonly IntPtr NativeFieldInfoPtr_TIME_TO_WAIT_FOR_INTERNET;

		// Token: 0x04007F9C RID: 32668
		private static readonly IntPtr NativeFieldInfoPtr_OnLicenseAgreementsChanged;

		// Token: 0x04007F9D RID: 32669
		private static readonly IntPtr NativeFieldInfoPtr_OnLicenseAgreementsValidated;

		// Token: 0x04007F9E RID: 32670
		private static readonly IntPtr NativeFieldInfoPtr__startTime;

		// Token: 0x04007F9F RID: 32671
		private static readonly IntPtr NativeFieldInfoPtr__allAgreements;

		// Token: 0x04007FA0 RID: 32672
		private static readonly IntPtr NativeFieldInfoPtr__agreementsToShow;

		// Token: 0x04007FA1 RID: 32673
		private static readonly IntPtr NativeFieldInfoPtr__performCount;

		// Token: 0x04007FA2 RID: 32674
		private static readonly IntPtr NativeFieldInfoPtr_PERFORM_ATTEMPTS_BEFORE_GRAB_LOCAL_CACHE;

		// Token: 0x04007FA3 RID: 32675
		private static readonly IntPtr NativeMethodInfoPtr_get_Type_Public_Virtual_get_OnwardServiceType_0;

		// Token: 0x04007FA4 RID: 32676
		private static readonly IntPtr NativeMethodInfoPtr_get_ServiceCanTrigger_Protected_Virtual_get_Boolean_0;

		// Token: 0x04007FA5 RID: 32677
		private static readonly IntPtr NativeMethodInfoPtr_IsWaitTimeUp_Private_Boolean_0;

		// Token: 0x04007FA6 RID: 32678
		private static readonly IntPtr NativeMethodInfoPtr_get_RetryTimeMsWhenSucceeded_Protected_Virtual_get_Int32_0;

		// Token: 0x04007FA7 RID: 32679
		private static readonly IntPtr NativeMethodInfoPtr_get_RetryTimeMsWhenNotSucceeded_Protected_Virtual_get_Int32_0;

		// Token: 0x04007FA8 RID: 32680
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_OnwardServiceManager_ConcurrentQueue_1_Action_0;

		// Token: 0x04007FA9 RID: 32681
		private static readonly IntPtr NativeMethodInfoPtr_get_AllAgreements_Public_get_DownpourAgreements_0;

		// Token: 0x04007FAA RID: 32682
		private static readonly IntPtr NativeMethodInfoPtr_PerformService_Protected_Virtual_Void_0;

		// Token: 0x04007FAB RID: 32683
		private static readonly IntPtr NativeMethodInfoPtr_UpdateServiceTrigger_Protected_Virtual_Void_0;

		// Token: 0x04007FAC RID: 32684
		private static readonly IntPtr NativeMethodInfoPtr_OnAgreementsReceivedFromWeb_Private_Void_String_0;

		// Token: 0x04007FAD RID: 32685
		private static readonly IntPtr NativeMethodInfoPtr_TryGetNextLicenseAgreementToShow_Public_Boolean_byref_LicenseAgreement_0;

		// Token: 0x04007FAE RID: 32686
		private static readonly IntPtr NativeMethodInfoPtr_OnFailedToGetAgreementsFromWeb_Private_Void_Exception_FailedGetRequest_0;

		// Token: 0x04007FAF RID: 32687
		private static readonly IntPtr NativeMethodInfoPtr_InitializeAgreements_Private_Void_0;

		// Token: 0x04007FB0 RID: 32688
		private static readonly IntPtr NativeMethodInfoPtr_CompareAndCacheLocalUserAgreements_Private_Void_0;

		// Token: 0x04007FB1 RID: 32689
		private static readonly IntPtr NativeMethodInfoPtr_CollectAgreementsToShow_Private_Void_0;

		// Token: 0x04007FB2 RID: 32690
		private static readonly IntPtr NativeMethodInfoPtr_TryGetLocallyCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0;

		// Token: 0x04007FB3 RID: 32691
		private static readonly IntPtr NativeMethodInfoPtr_TryGetBuildCachedAgreements_Private_Boolean_byref_List_1_LicenseAgreement_0;

		// Token: 0x04007FB4 RID: 32692
		private static readonly IntPtr NativeMethodInfoPtr_CacheAgreement_Public_Void_LicenseAgreement_0;

		// Token: 0x04007FB5 RID: 32693
		private static readonly IntPtr NativeMethodInfoPtr_HasUserAgreedToLicenseAgreement_Public_Boolean_LicenseAgreementType_0;

		// Token: 0x04007FB6 RID: 32694
		private static readonly IntPtr NativeMethodInfoPtr_CacheUserAgreements_Private_Void_DownpourAgreements_0;

		// Token: 0x04007FB7 RID: 32695
		private static readonly IntPtr NativeMethodInfoPtr_IsCachedAgreementVersionValid_Private_Boolean_LicenseAgreement_LicenseAgreement_0;
	}
}
