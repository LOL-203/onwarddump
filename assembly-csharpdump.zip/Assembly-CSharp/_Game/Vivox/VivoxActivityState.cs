﻿using System;

namespace _Game.Vivox
{
	// Token: 0x02000939 RID: 2361
	public enum VivoxActivityState
	{
		// Token: 0x04007EFB RID: 32507
		NotChecking,
		// Token: 0x04007EFC RID: 32508
		Active,
		// Token: 0x04007EFD RID: 32509
		DroppedMessagesDetected,
		// Token: 0x04007EFE RID: 32510
		Inactive,
		// Token: 0x04007EFF RID: 32511
		Reinitializing
	}
}
