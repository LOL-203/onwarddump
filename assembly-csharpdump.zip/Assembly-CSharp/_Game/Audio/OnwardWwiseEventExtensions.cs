﻿using System;
using AK.Wwise;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.Audio
{
	// Token: 0x02000986 RID: 2438
	public static class OnwardWwiseEventExtensions : Object
	{
		// Token: 0x0600CE32 RID: 52786 RVA: 0x003344B8 File Offset: 0x003326B8
		[CallerCount(0)]
		public unsafe static bool IsValidAndAppInitialized(this Event ev)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ev);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(OnwardWwiseEventExtensions.NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_Event_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CE33 RID: 52787 RVA: 0x00334510 File Offset: 0x00332710
		[CallerCount(0)]
		public unsafe static bool IsValidAndAppInitialized(this uint wwiseEventId)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref wwiseEventId;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(OnwardWwiseEventExtensions.NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600CE34 RID: 52788 RVA: 0x00334564 File Offset: 0x00332764
		// Note: this type is marked as 'beforefieldinit'.
		static OnwardWwiseEventExtensions()
		{
			Il2CppClassPointerStore<OnwardWwiseEventExtensions>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Audio", "OnwardWwiseEventExtensions");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<OnwardWwiseEventExtensions>.NativeClassPtr);
			OnwardWwiseEventExtensions.NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_Event_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<OnwardWwiseEventExtensions>.NativeClassPtr, 100679179);
			OnwardWwiseEventExtensions.NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<OnwardWwiseEventExtensions>.NativeClassPtr, 100679180);
		}

		// Token: 0x0600CE35 RID: 52789 RVA: 0x00002988 File Offset: 0x00000B88
		public OnwardWwiseEventExtensions(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B19 RID: 19225
		// (get) Token: 0x0600CE36 RID: 52790 RVA: 0x003345BC File Offset: 0x003327BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<OnwardWwiseEventExtensions>.NativeClassPtr));
			}
		}

		// Token: 0x04008260 RID: 33376
		private static readonly IntPtr NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_Event_0;

		// Token: 0x04008261 RID: 33377
		private static readonly IntPtr NativeMethodInfoPtr_IsValidAndAppInitialized_Public_Static_Boolean_UInt32_0;
	}
}
