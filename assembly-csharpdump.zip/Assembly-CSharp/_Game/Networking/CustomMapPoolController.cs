﻿using System;
using System.Runtime.InteropServices;
using DPI.Networking;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.CustomMaps;
using Onward.Networking;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.Networking
{
	// Token: 0x02000951 RID: 2385
	public class CustomMapPoolController : MonoBehaviour
	{
		// Token: 0x170049D7 RID: 18903
		// (get) Token: 0x0600CAB2 RID: 51890 RVA: 0x003266B4 File Offset: 0x003248B4
		public unsafe bool AllowGameModeChange
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_get_AllowGameModeChange_Private_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x0600CAB3 RID: 51891 RVA: 0x00326704 File Offset: 0x00324904
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAB4 RID: 51892 RVA: 0x00326748 File Offset: 0x00324948
		[CallerCount(0)]
		public unsafe void Initialize()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_Initialize_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAB5 RID: 51893 RVA: 0x0032678C File Offset: 0x0032498C
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAB6 RID: 51894 RVA: 0x003267D0 File Offset: 0x003249D0
		[CallerCount(0)]
		public unsafe Il2CppStringArray GetCustomMapIdsFromPlayers(Il2CppReferenceArray<DPIPlayer> dpiPlayers)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(dpiPlayers);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_GetCustomMapIdsFromPlayers_Private_ArrayOf_ArrayOf_DPIPlayer_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
		}

		// Token: 0x0600CAB7 RID: 51895 RVA: 0x00326840 File Offset: 0x00324A40
		[CallerCount(0)]
		public unsafe List<WorkshopItem> ConsumeCustomMapPoolWorkshopItemsAndRefresh()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_ConsumeCustomMapPoolWorkshopItemsAndRefresh_Public_List_1_WorkshopItem_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<WorkshopItem>(intPtr2) : null;
		}

		// Token: 0x0600CAB8 RID: 51896 RVA: 0x00326898 File Offset: 0x00324A98
		[CallerCount(0)]
		public unsafe void RefreshPool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_RefreshPool_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAB9 RID: 51897 RVA: 0x003268DC File Offset: 0x00324ADC
		[CallerCount(0)]
		public unsafe void OnPlayerPropertiesUpdate(DPIPlayer arg1, DPIHashtable arg2)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(arg1);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(arg2);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_OnPlayerPropertiesUpdate_Private_Void_DPIPlayer_DPIHashtable_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CABA RID: 51898 RVA: 0x00326950 File Offset: 0x00324B50
		[CallerCount(0)]
		public unsafe void CheckIfAllPlayersSubmittedMaps()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_CheckIfAllPlayersSubmittedMaps_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CABB RID: 51899 RVA: 0x00326994 File Offset: 0x00324B94
		[CallerCount(0)]
		public unsafe Il2CppStringArray ConsumeCustomMapPoolMapIdsAndRefresh()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_ConsumeCustomMapPoolMapIdsAndRefresh_Private_ArrayOf_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
		}

		// Token: 0x0600CABC RID: 51900 RVA: 0x003269EC File Offset: 0x00324BEC
		[CallerCount(0)]
		public unsafe Il2CppStringArray GetCachedWorkshopMaps()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_GetCachedWorkshopMaps_Private_ArrayOf_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
		}

		// Token: 0x0600CABD RID: 51901 RVA: 0x00326A44 File Offset: 0x00324C44
		[CallerCount(0)]
		public unsafe void GetAndCacheRandomWorkshopMapsFromMetaEndpoint()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_GetAndCacheRandomWorkshopMapsFromMetaEndpoint_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CABE RID: 51902 RVA: 0x00326A88 File Offset: 0x00324C88
		[CallerCount(0)]
		public unsafe void OnReceivedNewItems(List<WorkshopItem> workshopItems)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(workshopItems);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_OnReceivedNewItems_Private_Void_List_1_WorkshopItem_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CABF RID: 51903 RVA: 0x00326AE4 File Offset: 0x00324CE4
		[CallerCount(0)]
		public unsafe void RefreshPlayerMaps(RefreshCustomMapPlayerProperty refreshCustomMapPlayerProperty, DPINetworkMessageInfo messageInfo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref refreshCustomMapPlayerProperty;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(messageInfo));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_RefreshPlayerMaps_Public_Void_RefreshCustomMapPlayerProperty_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAC0 RID: 51904 RVA: 0x00326B58 File Offset: 0x00324D58
		[CallerCount(0)]
		public unsafe Il2CppStringArray GetHostMaps()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_GetHostMaps_Private_ArrayOf_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
		}

		// Token: 0x0600CAC1 RID: 51905 RVA: 0x00326BB0 File Offset: 0x00324DB0
		[CallerCount(0)]
		public unsafe void RegisterSomeCustomMapsToPlayerProperties([Optional] int numberOfMaps)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref numberOfMaps;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr_RegisterSomeCustomMapsToPlayerProperties_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAC2 RID: 51906 RVA: 0x00326C04 File Offset: 0x00324E04
		[CallerCount(0)]
		public unsafe CustomMapPoolController() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CustomMapPoolController.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CAC3 RID: 51907 RVA: 0x00326C50 File Offset: 0x00324E50
		// Note: this type is marked as 'beforefieldinit'.
		static CustomMapPoolController()
		{
			Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Networking", "CustomMapPoolController");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr);
			CustomMapPoolController.NativeFieldInfoPtr_Instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, "Instance");
			CustomMapPoolController.NativeFieldInfoPtr_OnPoolRefreshed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, "OnPoolRefreshed");
			CustomMapPoolController.NativeFieldInfoPtr__playerSetMapsCount = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, "_playerSetMapsCount");
			CustomMapPoolController.NativeMethodInfoPtr_get_AllowGameModeChange_Private_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678908);
			CustomMapPoolController.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678909);
			CustomMapPoolController.NativeMethodInfoPtr_Initialize_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678910);
			CustomMapPoolController.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678911);
			CustomMapPoolController.NativeMethodInfoPtr_GetCustomMapIdsFromPlayers_Private_ArrayOf_ArrayOf_DPIPlayer_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678912);
			CustomMapPoolController.NativeMethodInfoPtr_ConsumeCustomMapPoolWorkshopItemsAndRefresh_Public_List_1_WorkshopItem_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678913);
			CustomMapPoolController.NativeMethodInfoPtr_RefreshPool_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678914);
			CustomMapPoolController.NativeMethodInfoPtr_OnPlayerPropertiesUpdate_Private_Void_DPIPlayer_DPIHashtable_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678915);
			CustomMapPoolController.NativeMethodInfoPtr_CheckIfAllPlayersSubmittedMaps_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678916);
			CustomMapPoolController.NativeMethodInfoPtr_ConsumeCustomMapPoolMapIdsAndRefresh_Private_ArrayOf_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678917);
			CustomMapPoolController.NativeMethodInfoPtr_GetCachedWorkshopMaps_Private_ArrayOf_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678918);
			CustomMapPoolController.NativeMethodInfoPtr_GetAndCacheRandomWorkshopMapsFromMetaEndpoint_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678919);
			CustomMapPoolController.NativeMethodInfoPtr_OnReceivedNewItems_Private_Void_List_1_WorkshopItem_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678920);
			CustomMapPoolController.NativeMethodInfoPtr_RefreshPlayerMaps_Public_Void_RefreshCustomMapPlayerProperty_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678921);
			CustomMapPoolController.NativeMethodInfoPtr_GetHostMaps_Private_ArrayOf_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678922);
			CustomMapPoolController.NativeMethodInfoPtr_RegisterSomeCustomMapsToPlayerProperties_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678923);
			CustomMapPoolController.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr, 100678924);
		}

		// Token: 0x0600CAC4 RID: 51908 RVA: 0x0000210C File Offset: 0x0000030C
		public CustomMapPoolController(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170049D3 RID: 18899
		// (get) Token: 0x0600CAC5 RID: 51909 RVA: 0x00326E10 File Offset: 0x00325010
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CustomMapPoolController>.NativeClassPtr));
			}
		}

		// Token: 0x170049D4 RID: 18900
		// (get) Token: 0x0600CAC6 RID: 51910 RVA: 0x00326E24 File Offset: 0x00325024
		// (set) Token: 0x0600CAC7 RID: 51911 RVA: 0x00326E4F File Offset: 0x0032504F
		public unsafe static CustomMapPoolController Instance
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(CustomMapPoolController.NativeFieldInfoPtr_Instance, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new CustomMapPoolController(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(CustomMapPoolController.NativeFieldInfoPtr_Instance, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049D5 RID: 18901
		// (get) Token: 0x0600CAC8 RID: 51912 RVA: 0x00326E64 File Offset: 0x00325064
		// (set) Token: 0x0600CAC9 RID: 51913 RVA: 0x00326E98 File Offset: 0x00325098
		public unsafe Action OnPoolRefreshed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapPoolController.NativeFieldInfoPtr_OnPoolRefreshed);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapPoolController.NativeFieldInfoPtr_OnPoolRefreshed), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170049D6 RID: 18902
		// (get) Token: 0x0600CACA RID: 51914 RVA: 0x00326EC0 File Offset: 0x003250C0
		// (set) Token: 0x0600CACB RID: 51915 RVA: 0x00326EE8 File Offset: 0x003250E8
		public unsafe int _playerSetMapsCount
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapPoolController.NativeFieldInfoPtr__playerSetMapsCount);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CustomMapPoolController.NativeFieldInfoPtr__playerSetMapsCount)) = value;
			}
		}

		// Token: 0x04008017 RID: 32791
		private static readonly IntPtr NativeFieldInfoPtr_Instance;

		// Token: 0x04008018 RID: 32792
		private static readonly IntPtr NativeFieldInfoPtr_OnPoolRefreshed;

		// Token: 0x04008019 RID: 32793
		private static readonly IntPtr NativeFieldInfoPtr__playerSetMapsCount;

		// Token: 0x0400801A RID: 32794
		private static readonly IntPtr NativeMethodInfoPtr_get_AllowGameModeChange_Private_get_Boolean_0;

		// Token: 0x0400801B RID: 32795
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x0400801C RID: 32796
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_0;

		// Token: 0x0400801D RID: 32797
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x0400801E RID: 32798
		private static readonly IntPtr NativeMethodInfoPtr_GetCustomMapIdsFromPlayers_Private_ArrayOf_ArrayOf_DPIPlayer_0;

		// Token: 0x0400801F RID: 32799
		private static readonly IntPtr NativeMethodInfoPtr_ConsumeCustomMapPoolWorkshopItemsAndRefresh_Public_List_1_WorkshopItem_0;

		// Token: 0x04008020 RID: 32800
		private static readonly IntPtr NativeMethodInfoPtr_RefreshPool_Public_Void_0;

		// Token: 0x04008021 RID: 32801
		private static readonly IntPtr NativeMethodInfoPtr_OnPlayerPropertiesUpdate_Private_Void_DPIPlayer_DPIHashtable_0;

		// Token: 0x04008022 RID: 32802
		private static readonly IntPtr NativeMethodInfoPtr_CheckIfAllPlayersSubmittedMaps_Private_Void_0;

		// Token: 0x04008023 RID: 32803
		private static readonly IntPtr NativeMethodInfoPtr_ConsumeCustomMapPoolMapIdsAndRefresh_Private_ArrayOf_0;

		// Token: 0x04008024 RID: 32804
		private static readonly IntPtr NativeMethodInfoPtr_GetCachedWorkshopMaps_Private_ArrayOf_0;

		// Token: 0x04008025 RID: 32805
		private static readonly IntPtr NativeMethodInfoPtr_GetAndCacheRandomWorkshopMapsFromMetaEndpoint_Private_Void_0;

		// Token: 0x04008026 RID: 32806
		private static readonly IntPtr NativeMethodInfoPtr_OnReceivedNewItems_Private_Void_List_1_WorkshopItem_0;

		// Token: 0x04008027 RID: 32807
		private static readonly IntPtr NativeMethodInfoPtr_RefreshPlayerMaps_Public_Void_RefreshCustomMapPlayerProperty_DPINetworkMessageInfo_0;

		// Token: 0x04008028 RID: 32808
		private static readonly IntPtr NativeMethodInfoPtr_GetHostMaps_Private_ArrayOf_0;

		// Token: 0x04008029 RID: 32809
		private static readonly IntPtr NativeMethodInfoPtr_RegisterSomeCustomMapsToPlayerProperties_Public_Void_Int32_0;

		// Token: 0x0400802A RID: 32810
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
