﻿using System;
using DPI.Networking;
using Il2CppSystem;
using Onward.Rendering;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.FX
{
	// Token: 0x02000983 RID: 2435
	public class ComfortVignetteHandler : MonoBehaviour
	{
		// Token: 0x0600CDE8 RID: 52712 RVA: 0x0033335C File Offset: 0x0033155C
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDE9 RID: 52713 RVA: 0x003333A0 File Offset: 0x003315A0
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDEA RID: 52714 RVA: 0x003333E4 File Offset: 0x003315E4
		[CallerCount(0)]
		public unsafe void OnManagedLateUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17004B0A RID: 19210
		// (get) Token: 0x0600CDEB RID: 52715 RVA: 0x00333428 File Offset: 0x00331628
		// (set) Token: 0x0600CDEC RID: 52716 RVA: 0x00333478 File Offset: 0x00331678
		public unsafe bool ManagedLateUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600CDED RID: 52717 RVA: 0x003334CC File Offset: 0x003316CC
		[CallerCount(0)]
		public unsafe void HandleComfortVignette()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr_HandleComfortVignette_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDEE RID: 52718 RVA: 0x00333510 File Offset: 0x00331710
		[CallerCount(0)]
		public unsafe ComfortVignetteHandler() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteHandler.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CDEF RID: 52719 RVA: 0x0033355C File Offset: 0x0033175C
		// Note: this type is marked as 'beforefieldinit'.
		static ComfortVignetteHandler()
		{
			Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.FX", "ComfortVignetteHandler");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr);
			ComfortVignetteHandler.NativeFieldInfoPtr_VRCharacterController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "VRCharacterController");
			ComfortVignetteHandler.NativeFieldInfoPtr_TurnOnMagnitudeThreshold = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "TurnOnMagnitudeThreshold");
			ComfortVignetteHandler.NativeFieldInfoPtr_TurnOffMagnitudeThreshold = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "TurnOffMagnitudeThreshold");
			ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementStarts = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "TimeToStayOnAfterMovementStarts");
			ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementEnds = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "TimeToStayOnAfterMovementEnds");
			ComfortVignetteHandler.NativeFieldInfoPtr__dpiView = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_dpiView");
			ComfortVignetteHandler.NativeFieldInfoPtr__isComfortVignetteOn = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_isComfortVignetteOn");
			ComfortVignetteHandler.NativeFieldInfoPtr__movementStartedTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_movementStartedTime");
			ComfortVignetteHandler.NativeFieldInfoPtr__movementStoppedTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_movementStoppedTime");
			ComfortVignetteHandler.NativeFieldInfoPtr__comfortVignetteLevel = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_comfortVignetteLevel");
			ComfortVignetteHandler.NativeFieldInfoPtr__cachedScreenEffectStateType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "_cachedScreenEffectStateType");
			ComfortVignetteHandler.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, "<ManagedLateUpdateRemoval>k__BackingField");
			ComfortVignetteHandler.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679158);
			ComfortVignetteHandler.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679159);
			ComfortVignetteHandler.NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679160);
			ComfortVignetteHandler.NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679161);
			ComfortVignetteHandler.NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679162);
			ComfortVignetteHandler.NativeMethodInfoPtr_HandleComfortVignette_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679163);
			ComfortVignetteHandler.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr, 100679164);
		}

		// Token: 0x0600CDF0 RID: 52720 RVA: 0x0000210C File Offset: 0x0000030C
		public ComfortVignetteHandler(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004AFD RID: 19197
		// (get) Token: 0x0600CDF1 RID: 52721 RVA: 0x00333708 File Offset: 0x00331908
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ComfortVignetteHandler>.NativeClassPtr));
			}
		}

		// Token: 0x17004AFE RID: 19198
		// (get) Token: 0x0600CDF2 RID: 52722 RVA: 0x0033371C File Offset: 0x0033191C
		// (set) Token: 0x0600CDF3 RID: 52723 RVA: 0x00333750 File Offset: 0x00331950
		public unsafe VRCharacterController VRCharacterController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_VRCharacterController);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new VRCharacterController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_VRCharacterController), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004AFF RID: 19199
		// (get) Token: 0x0600CDF4 RID: 52724 RVA: 0x00333778 File Offset: 0x00331978
		// (set) Token: 0x0600CDF5 RID: 52725 RVA: 0x003337A0 File Offset: 0x003319A0
		public unsafe float TurnOnMagnitudeThreshold
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TurnOnMagnitudeThreshold);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TurnOnMagnitudeThreshold)) = value;
			}
		}

		// Token: 0x17004B00 RID: 19200
		// (get) Token: 0x0600CDF6 RID: 52726 RVA: 0x003337C4 File Offset: 0x003319C4
		// (set) Token: 0x0600CDF7 RID: 52727 RVA: 0x003337EC File Offset: 0x003319EC
		public unsafe float TurnOffMagnitudeThreshold
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TurnOffMagnitudeThreshold);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TurnOffMagnitudeThreshold)) = value;
			}
		}

		// Token: 0x17004B01 RID: 19201
		// (get) Token: 0x0600CDF8 RID: 52728 RVA: 0x00333810 File Offset: 0x00331A10
		// (set) Token: 0x0600CDF9 RID: 52729 RVA: 0x00333838 File Offset: 0x00331A38
		public unsafe float TimeToStayOnAfterMovementStarts
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementStarts);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementStarts)) = value;
			}
		}

		// Token: 0x17004B02 RID: 19202
		// (get) Token: 0x0600CDFA RID: 52730 RVA: 0x0033385C File Offset: 0x00331A5C
		// (set) Token: 0x0600CDFB RID: 52731 RVA: 0x00333884 File Offset: 0x00331A84
		public unsafe float TimeToStayOnAfterMovementEnds
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementEnds);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr_TimeToStayOnAfterMovementEnds)) = value;
			}
		}

		// Token: 0x17004B03 RID: 19203
		// (get) Token: 0x0600CDFC RID: 52732 RVA: 0x003338A8 File Offset: 0x00331AA8
		// (set) Token: 0x0600CDFD RID: 52733 RVA: 0x003338DC File Offset: 0x00331ADC
		public unsafe DPIView _dpiView
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__dpiView);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DPIView(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__dpiView), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B04 RID: 19204
		// (get) Token: 0x0600CDFE RID: 52734 RVA: 0x00333904 File Offset: 0x00331B04
		// (set) Token: 0x0600CDFF RID: 52735 RVA: 0x0033392C File Offset: 0x00331B2C
		public unsafe bool _isComfortVignetteOn
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__isComfortVignetteOn);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__isComfortVignetteOn)) = value;
			}
		}

		// Token: 0x17004B05 RID: 19205
		// (get) Token: 0x0600CE00 RID: 52736 RVA: 0x00333950 File Offset: 0x00331B50
		// (set) Token: 0x0600CE01 RID: 52737 RVA: 0x00333978 File Offset: 0x00331B78
		public unsafe float _movementStartedTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__movementStartedTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__movementStartedTime)) = value;
			}
		}

		// Token: 0x17004B06 RID: 19206
		// (get) Token: 0x0600CE02 RID: 52738 RVA: 0x0033399C File Offset: 0x00331B9C
		// (set) Token: 0x0600CE03 RID: 52739 RVA: 0x003339C4 File Offset: 0x00331BC4
		public unsafe float _movementStoppedTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__movementStoppedTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__movementStoppedTime)) = value;
			}
		}

		// Token: 0x17004B07 RID: 19207
		// (get) Token: 0x0600CE04 RID: 52740 RVA: 0x003339E8 File Offset: 0x00331BE8
		// (set) Token: 0x0600CE05 RID: 52741 RVA: 0x00333A10 File Offset: 0x00331C10
		public unsafe ComfortVignetteLevel _comfortVignetteLevel
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__comfortVignetteLevel);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__comfortVignetteLevel)) = value;
			}
		}

		// Token: 0x17004B08 RID: 19208
		// (get) Token: 0x0600CE06 RID: 52742 RVA: 0x00333A34 File Offset: 0x00331C34
		// (set) Token: 0x0600CE07 RID: 52743 RVA: 0x00333A5C File Offset: 0x00331C5C
		public unsafe ScreenEffectStateTypes _cachedScreenEffectStateType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__cachedScreenEffectStateType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__cachedScreenEffectStateType)) = value;
			}
		}

		// Token: 0x17004B09 RID: 19209
		// (get) Token: 0x0600CE08 RID: 52744 RVA: 0x00333A80 File Offset: 0x00331C80
		// (set) Token: 0x0600CE09 RID: 52745 RVA: 0x00333AA8 File Offset: 0x00331CA8
		public unsafe bool _ManagedLateUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteHandler.NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x04008235 RID: 33333
		private static readonly IntPtr NativeFieldInfoPtr_VRCharacterController;

		// Token: 0x04008236 RID: 33334
		private static readonly IntPtr NativeFieldInfoPtr_TurnOnMagnitudeThreshold;

		// Token: 0x04008237 RID: 33335
		private static readonly IntPtr NativeFieldInfoPtr_TurnOffMagnitudeThreshold;

		// Token: 0x04008238 RID: 33336
		private static readonly IntPtr NativeFieldInfoPtr_TimeToStayOnAfterMovementStarts;

		// Token: 0x04008239 RID: 33337
		private static readonly IntPtr NativeFieldInfoPtr_TimeToStayOnAfterMovementEnds;

		// Token: 0x0400823A RID: 33338
		private static readonly IntPtr NativeFieldInfoPtr__dpiView;

		// Token: 0x0400823B RID: 33339
		private static readonly IntPtr NativeFieldInfoPtr__isComfortVignetteOn;

		// Token: 0x0400823C RID: 33340
		private static readonly IntPtr NativeFieldInfoPtr__movementStartedTime;

		// Token: 0x0400823D RID: 33341
		private static readonly IntPtr NativeFieldInfoPtr__movementStoppedTime;

		// Token: 0x0400823E RID: 33342
		private static readonly IntPtr NativeFieldInfoPtr__comfortVignetteLevel;

		// Token: 0x0400823F RID: 33343
		private static readonly IntPtr NativeFieldInfoPtr__cachedScreenEffectStateType;

		// Token: 0x04008240 RID: 33344
		private static readonly IntPtr NativeFieldInfoPtr__ManagedLateUpdateRemoval_k__BackingField;

		// Token: 0x04008241 RID: 33345
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04008242 RID: 33346
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04008243 RID: 33347
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedLateUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x04008244 RID: 33348
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedLateUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x04008245 RID: 33349
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedLateUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x04008246 RID: 33350
		private static readonly IntPtr NativeMethodInfoPtr_HandleComfortVignette_Private_Void_0;

		// Token: 0x04008247 RID: 33351
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
