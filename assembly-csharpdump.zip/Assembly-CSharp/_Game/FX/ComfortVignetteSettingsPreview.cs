﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using Onward.Rendering;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.FX
{
	// Token: 0x02000984 RID: 2436
	public class ComfortVignetteSettingsPreview : MonoBehaviour
	{
		// Token: 0x0600CE0A RID: 52746 RVA: 0x00333ACC File Offset: 0x00331CCC
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE0B RID: 52747 RVA: 0x00333B10 File Offset: 0x00331D10
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE0C RID: 52748 RVA: 0x00333B54 File Offset: 0x00331D54
		[CallerCount(0)]
		public unsafe void IncrementButtonOnOnClick()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_IncrementButtonOnOnClick_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE0D RID: 52749 RVA: 0x00333B98 File Offset: 0x00331D98
		[CallerCount(0)]
		public unsafe void DecrementButtonOnOnClick()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_DecrementButtonOnOnClick_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE0E RID: 52750 RVA: 0x00333BDC File Offset: 0x00331DDC
		[CallerCount(0)]
		public unsafe void FlashVignette()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_FlashVignette_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE0F RID: 52751 RVA: 0x00333C20 File Offset: 0x00331E20
		[CallerCount(0)]
		public unsafe void ResetVignetteFlash()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_ResetVignetteFlash_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE10 RID: 52752 RVA: 0x00333C64 File Offset: 0x00331E64
		[CallerCount(0)]
		public unsafe IEnumerator FlashVignetteCR()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr_FlashVignetteCR_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600CE11 RID: 52753 RVA: 0x00333CBC File Offset: 0x00331EBC
		[CallerCount(0)]
		public unsafe ComfortVignetteSettingsPreview() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600CE12 RID: 52754 RVA: 0x00333D08 File Offset: 0x00331F08
		// Note: this type is marked as 'beforefieldinit'.
		static ComfortVignetteSettingsPreview()
		{
			Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.FX", "ComfortVignetteSettingsPreview");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr);
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr_DecrementButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "DecrementButton");
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr_IncrementButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "IncrementButton");
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr_VignettePrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "VignettePrefab");
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr__currentTempVignetteAperture = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "_currentTempVignetteAperture");
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr__cachedScreenEffectStateType = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "_cachedScreenEffectStateType");
			ComfortVignetteSettingsPreview.NativeFieldInfoPtr__flashVignetteCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "_flashVignetteCoroutine");
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679165);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679166);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_IncrementButtonOnOnClick_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679167);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_DecrementButtonOnOnClick_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679168);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_FlashVignette_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679169);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_ResetVignetteFlash_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679170);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr_FlashVignetteCR_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679171);
			ComfortVignetteSettingsPreview.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, 100679172);
		}

		// Token: 0x0600CE13 RID: 52755 RVA: 0x0000210C File Offset: 0x0000030C
		public ComfortVignetteSettingsPreview(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004B0B RID: 19211
		// (get) Token: 0x0600CE14 RID: 52756 RVA: 0x00333E50 File Offset: 0x00332050
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr));
			}
		}

		// Token: 0x17004B0C RID: 19212
		// (get) Token: 0x0600CE15 RID: 52757 RVA: 0x00333E64 File Offset: 0x00332064
		// (set) Token: 0x0600CE16 RID: 52758 RVA: 0x00333E98 File Offset: 0x00332098
		public unsafe MenuItemPopout DecrementButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_DecrementButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_DecrementButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B0D RID: 19213
		// (get) Token: 0x0600CE17 RID: 52759 RVA: 0x00333EC0 File Offset: 0x003320C0
		// (set) Token: 0x0600CE18 RID: 52760 RVA: 0x00333EF4 File Offset: 0x003320F4
		public unsafe MenuItemPopout IncrementButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_IncrementButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_IncrementButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B0E RID: 19214
		// (get) Token: 0x0600CE19 RID: 52761 RVA: 0x00333F1C File Offset: 0x0033211C
		// (set) Token: 0x0600CE1A RID: 52762 RVA: 0x00333F50 File Offset: 0x00332150
		public unsafe GameObject VignettePrefab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_VignettePrefab);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr_VignettePrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B0F RID: 19215
		// (get) Token: 0x0600CE1B RID: 52763 RVA: 0x00333F78 File Offset: 0x00332178
		// (set) Token: 0x0600CE1C RID: 52764 RVA: 0x00333FAC File Offset: 0x003321AC
		public unsafe GameObject _currentTempVignetteAperture
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__currentTempVignetteAperture);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__currentTempVignetteAperture), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004B10 RID: 19216
		// (get) Token: 0x0600CE1D RID: 52765 RVA: 0x00333FD4 File Offset: 0x003321D4
		// (set) Token: 0x0600CE1E RID: 52766 RVA: 0x00333FFC File Offset: 0x003321FC
		public unsafe ScreenEffectStateTypes _cachedScreenEffectStateType
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__cachedScreenEffectStateType);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__cachedScreenEffectStateType)) = value;
			}
		}

		// Token: 0x17004B11 RID: 19217
		// (get) Token: 0x0600CE1F RID: 52767 RVA: 0x00334020 File Offset: 0x00332220
		// (set) Token: 0x0600CE20 RID: 52768 RVA: 0x00334054 File Offset: 0x00332254
		public unsafe Coroutine _flashVignetteCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__flashVignetteCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview.NativeFieldInfoPtr__flashVignetteCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04008248 RID: 33352
		private static readonly IntPtr NativeFieldInfoPtr_DecrementButton;

		// Token: 0x04008249 RID: 33353
		private static readonly IntPtr NativeFieldInfoPtr_IncrementButton;

		// Token: 0x0400824A RID: 33354
		private static readonly IntPtr NativeFieldInfoPtr_VignettePrefab;

		// Token: 0x0400824B RID: 33355
		private static readonly IntPtr NativeFieldInfoPtr__currentTempVignetteAperture;

		// Token: 0x0400824C RID: 33356
		private static readonly IntPtr NativeFieldInfoPtr__cachedScreenEffectStateType;

		// Token: 0x0400824D RID: 33357
		private static readonly IntPtr NativeFieldInfoPtr__flashVignetteCoroutine;

		// Token: 0x0400824E RID: 33358
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x0400824F RID: 33359
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04008250 RID: 33360
		private static readonly IntPtr NativeMethodInfoPtr_IncrementButtonOnOnClick_Private_Void_0;

		// Token: 0x04008251 RID: 33361
		private static readonly IntPtr NativeMethodInfoPtr_DecrementButtonOnOnClick_Private_Void_0;

		// Token: 0x04008252 RID: 33362
		private static readonly IntPtr NativeMethodInfoPtr_FlashVignette_Private_Void_0;

		// Token: 0x04008253 RID: 33363
		private static readonly IntPtr NativeMethodInfoPtr_ResetVignetteFlash_Private_Void_0;

		// Token: 0x04008254 RID: 33364
		private static readonly IntPtr NativeMethodInfoPtr_FlashVignetteCR_Private_IEnumerator_0;

		// Token: 0x04008255 RID: 33365
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000985 RID: 2437
		[ObfuscatedName("_Game.FX.ComfortVignetteSettingsPreview/<FlashVignetteCR>d__12")]
		public sealed class _FlashVignetteCR_d__12 : Il2CppSystem.Object
		{
			// Token: 0x0600CE21 RID: 52769 RVA: 0x0033407C File Offset: 0x0033227C
			[CallerCount(0)]
			public unsafe _FlashVignetteCR_d__12(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CE22 RID: 52770 RVA: 0x003340DC File Offset: 0x003322DC
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600CE23 RID: 52771 RVA: 0x00334120 File Offset: 0x00332320
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17004B17 RID: 19223
			// (get) Token: 0x0600CE24 RID: 52772 RVA: 0x00334170 File Offset: 0x00332370
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600CE25 RID: 52773 RVA: 0x003341C8 File Offset: 0x003323C8
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17004B18 RID: 19224
			// (get) Token: 0x0600CE26 RID: 52774 RVA: 0x0033420C File Offset: 0x0033240C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600CE27 RID: 52775 RVA: 0x00334264 File Offset: 0x00332464
			// Note: this type is marked as 'beforefieldinit'.
			static _FlashVignetteCR_d__12()
			{
				Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ComfortVignetteSettingsPreview>.NativeClassPtr, "<FlashVignetteCR>d__12");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, "<>1__state");
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, "<>2__current");
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, "<>4__this");
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr__i_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, "<i>5__2");
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679173);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679174);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679175);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679176);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679177);
				ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr, 100679178);
			}

			// Token: 0x0600CE28 RID: 52776 RVA: 0x00002988 File Offset: 0x00000B88
			public _FlashVignetteCR_d__12(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004B12 RID: 19218
			// (get) Token: 0x0600CE29 RID: 52777 RVA: 0x00334357 File Offset: 0x00332557
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ComfortVignetteSettingsPreview._FlashVignetteCR_d__12>.NativeClassPtr));
				}
			}

			// Token: 0x17004B13 RID: 19219
			// (get) Token: 0x0600CE2A RID: 52778 RVA: 0x00334368 File Offset: 0x00332568
			// (set) Token: 0x0600CE2B RID: 52779 RVA: 0x00334390 File Offset: 0x00332590
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17004B14 RID: 19220
			// (get) Token: 0x0600CE2C RID: 52780 RVA: 0x003343B4 File Offset: 0x003325B4
			// (set) Token: 0x0600CE2D RID: 52781 RVA: 0x003343E8 File Offset: 0x003325E8
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004B15 RID: 19221
			// (get) Token: 0x0600CE2E RID: 52782 RVA: 0x00334410 File Offset: 0x00332610
			// (set) Token: 0x0600CE2F RID: 52783 RVA: 0x00334444 File Offset: 0x00332644
			public unsafe ComfortVignetteSettingsPreview __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new ComfortVignetteSettingsPreview(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004B16 RID: 19222
			// (get) Token: 0x0600CE30 RID: 52784 RVA: 0x0033446C File Offset: 0x0033266C
			// (set) Token: 0x0600CE31 RID: 52785 RVA: 0x00334494 File Offset: 0x00332694
			public unsafe int _i_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr__i_5__2);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ComfortVignetteSettingsPreview._FlashVignetteCR_d__12.NativeFieldInfoPtr__i_5__2)) = value;
				}
			}

			// Token: 0x04008256 RID: 33366
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x04008257 RID: 33367
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x04008258 RID: 33368
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04008259 RID: 33369
			private static readonly IntPtr NativeFieldInfoPtr__i_5__2;

			// Token: 0x0400825A RID: 33370
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x0400825B RID: 33371
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400825C RID: 33372
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x0400825D RID: 33373
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x0400825E RID: 33374
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400825F RID: 33375
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
