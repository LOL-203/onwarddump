﻿using System;

namespace _Game.PlatformSDK_Helpers
{
	// Token: 0x0200094C RID: 2380
	public enum DeeplinkEventType
	{
		// Token: 0x04007FB9 RID: 32697
		STARTED,
		// Token: 0x04007FBA RID: 32698
		SUCCESS,
		// Token: 0x04007FBB RID: 32699
		FAILED
	}
}
