﻿using System;

namespace _Game.PlatformSDK_Helpers
{
	// Token: 0x0200094D RID: 2381
	public enum DeeplinkFailedReason
	{
		// Token: 0x04007FBD RID: 32701
		None,
		// Token: 0x04007FBE RID: 32702
		PlatformFailure,
		// Token: 0x04007FBF RID: 32703
		Cancelled,
		// Token: 0x04007FC0 RID: 32704
		JoinedDifferentRoom,
		// Token: 0x04007FC1 RID: 32705
		InvalidPassword,
		// Token: 0x04007FC2 RID: 32706
		NoRoomIdReceived,
		// Token: 0x04007FC3 RID: 32707
		RoomUnavailable,
		// Token: 0x04007FC4 RID: 32708
		RoomFull,
		// Token: 0x04007FC5 RID: 32709
		GameliftError,
		// Token: 0x04007FC6 RID: 32710
		OutdatedMap,
		// Token: 0x04007FC7 RID: 32711
		GameNotFound
	}
}
