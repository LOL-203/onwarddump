﻿using System;
using Il2CppSystem;
using Il2CppSystem.Text;
using Onward.CustomMaps;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine.Networking;

namespace _Game.UI.MainMenu.Workshop.GetUGCBundleRequest
{
	// Token: 0x02000944 RID: 2372
	public static class DPIMapBundleWebRequest : Object
	{
		// Token: 0x0600C98E RID: 51598 RVA: 0x00321C54 File Offset: 0x0031FE54
		[CallerCount(0)]
		public unsafe static UnityWebRequest GetMapBundleFromMeta(string outputPath, string versionedMapId, WorkshopPlatformEnum platform)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(outputPath);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(versionedMapId);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref platform;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DPIMapBundleWebRequest.NativeMethodInfoPtr_GetMapBundleFromMeta_Public_Static_UnityWebRequest_String_String_WorkshopPlatformEnum_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new UnityWebRequest(intPtr2) : null;
		}

		// Token: 0x0600C98F RID: 51599 RVA: 0x00321CE0 File Offset: 0x0031FEE0
		// Note: this type is marked as 'beforefieldinit'.
		static DPIMapBundleWebRequest()
		{
			Il2CppClassPointerStore<DPIMapBundleWebRequest>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.MainMenu.Workshop.GetUGCBundleRequest", "DPIMapBundleWebRequest");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DPIMapBundleWebRequest>.NativeClassPtr);
			DPIMapBundleWebRequest.NativeFieldInfoPtr__encoder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DPIMapBundleWebRequest>.NativeClassPtr, "_encoder");
			DPIMapBundleWebRequest.NativeMethodInfoPtr_GetMapBundleFromMeta_Public_Static_UnityWebRequest_String_String_WorkshopPlatformEnum_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DPIMapBundleWebRequest>.NativeClassPtr, 100678815);
		}

		// Token: 0x0600C990 RID: 51600 RVA: 0x00002988 File Offset: 0x00000B88
		public DPIMapBundleWebRequest(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700496C RID: 18796
		// (get) Token: 0x0600C991 RID: 51601 RVA: 0x00321D38 File Offset: 0x0031FF38
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DPIMapBundleWebRequest>.NativeClassPtr));
			}
		}

		// Token: 0x1700496D RID: 18797
		// (get) Token: 0x0600C992 RID: 51602 RVA: 0x00321D4C File Offset: 0x0031FF4C
		// (set) Token: 0x0600C993 RID: 51603 RVA: 0x00321D77 File Offset: 0x0031FF77
		public unsafe static UTF8Encoding _encoder
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(DPIMapBundleWebRequest.NativeFieldInfoPtr__encoder, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new UTF8Encoding(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(DPIMapBundleWebRequest.NativeFieldInfoPtr__encoder, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F59 RID: 32601
		private static readonly IntPtr NativeFieldInfoPtr__encoder;

		// Token: 0x04007F5A RID: 32602
		private static readonly IntPtr NativeMethodInfoPtr_GetMapBundleFromMeta_Public_Static_UnityWebRequest_String_String_WorkshopPlatformEnum_0;
	}
}
