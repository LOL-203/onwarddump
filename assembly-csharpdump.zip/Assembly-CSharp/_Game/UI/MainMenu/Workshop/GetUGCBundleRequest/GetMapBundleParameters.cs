﻿using System;
using Il2CppSystem;
using Onward.CustomMaps;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.UI.MainMenu.Workshop.GetUGCBundleRequest
{
	// Token: 0x02000945 RID: 2373
	public class GetMapBundleParameters : Object
	{
		// Token: 0x0600C994 RID: 51604 RVA: 0x00321D8C File Offset: 0x0031FF8C
		[CallerCount(0)]
		public unsafe GetMapBundleParameters() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(GetMapBundleParameters.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C995 RID: 51605 RVA: 0x00321DD8 File Offset: 0x0031FFD8
		// Note: this type is marked as 'beforefieldinit'.
		static GetMapBundleParameters()
		{
			Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.MainMenu.Workshop.GetUGCBundleRequest", "GetMapBundleParameters");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr);
			GetMapBundleParameters.NativeFieldInfoPtr_platform = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr, "platform");
			GetMapBundleParameters.NativeFieldInfoPtr_versioned_map_id = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr, "versioned_map_id");
			GetMapBundleParameters.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr, 100678817);
		}

		// Token: 0x0600C996 RID: 51606 RVA: 0x00002988 File Offset: 0x00000B88
		public GetMapBundleParameters(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700496E RID: 18798
		// (get) Token: 0x0600C997 RID: 51607 RVA: 0x00321E44 File Offset: 0x00320044
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<GetMapBundleParameters>.NativeClassPtr));
			}
		}

		// Token: 0x1700496F RID: 18799
		// (get) Token: 0x0600C998 RID: 51608 RVA: 0x00321E58 File Offset: 0x00320058
		// (set) Token: 0x0600C999 RID: 51609 RVA: 0x00321E80 File Offset: 0x00320080
		public unsafe WorkshopPlatformEnum platform
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(GetMapBundleParameters.NativeFieldInfoPtr_platform);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(GetMapBundleParameters.NativeFieldInfoPtr_platform)) = value;
			}
		}

		// Token: 0x17004970 RID: 18800
		// (get) Token: 0x0600C99A RID: 51610 RVA: 0x00321EA4 File Offset: 0x003200A4
		// (set) Token: 0x0600C99B RID: 51611 RVA: 0x00321ECD File Offset: 0x003200CD
		public unsafe string versioned_map_id
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(GetMapBundleParameters.NativeFieldInfoPtr_versioned_map_id);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(GetMapBundleParameters.NativeFieldInfoPtr_versioned_map_id), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x04007F5B RID: 32603
		private static readonly IntPtr NativeFieldInfoPtr_platform;

		// Token: 0x04007F5C RID: 32604
		private static readonly IntPtr NativeFieldInfoPtr_versioned_map_id;

		// Token: 0x04007F5D RID: 32605
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
