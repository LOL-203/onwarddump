﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI.MainMenu.Workshop
{
	// Token: 0x02000943 RID: 2371
	public class DeleteCustomContentUIButtonClicker : MonoBehaviour
	{
		// Token: 0x0600C984 RID: 51588 RVA: 0x003219E0 File Offset: 0x0031FBE0
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C985 RID: 51589 RVA: 0x00321A24 File Offset: 0x0031FC24
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C986 RID: 51590 RVA: 0x00321A68 File Offset: 0x0031FC68
		[CallerCount(0)]
		public unsafe void OnClick()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnClick_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C987 RID: 51591 RVA: 0x00321AAC File Offset: 0x0031FCAC
		[CallerCount(0)]
		public unsafe void DeleteCustomContentCache()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_DeleteCustomContentCache_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C988 RID: 51592 RVA: 0x00321AF0 File Offset: 0x0031FCF0
		[CallerCount(0)]
		public unsafe DeleteCustomContentUIButtonClicker() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C989 RID: 51593 RVA: 0x00321B3C File Offset: 0x0031FD3C
		// Note: this type is marked as 'beforefieldinit'.
		static DeleteCustomContentUIButtonClicker()
		{
			Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.MainMenu.Workshop", "DeleteCustomContentUIButtonClicker");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr);
			DeleteCustomContentUIButtonClicker.NativeFieldInfoPtr_DeleteContentUIButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, "DeleteContentUIButton");
			DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, 100678810);
			DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, 100678811);
			DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_OnClick_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, 100678812);
			DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr_DeleteCustomContentCache_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, 100678813);
			DeleteCustomContentUIButtonClicker.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr, 100678814);
		}

		// Token: 0x0600C98A RID: 51594 RVA: 0x0000210C File Offset: 0x0000030C
		public DeleteCustomContentUIButtonClicker(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700496A RID: 18794
		// (get) Token: 0x0600C98B RID: 51595 RVA: 0x00321BE4 File Offset: 0x0031FDE4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DeleteCustomContentUIButtonClicker>.NativeClassPtr));
			}
		}

		// Token: 0x1700496B RID: 18795
		// (get) Token: 0x0600C98C RID: 51596 RVA: 0x00321BF8 File Offset: 0x0031FDF8
		// (set) Token: 0x0600C98D RID: 51597 RVA: 0x00321C2C File Offset: 0x0031FE2C
		public unsafe MenuItemPopout DeleteContentUIButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeleteCustomContentUIButtonClicker.NativeFieldInfoPtr_DeleteContentUIButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DeleteCustomContentUIButtonClicker.NativeFieldInfoPtr_DeleteContentUIButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F53 RID: 32595
		private static readonly IntPtr NativeFieldInfoPtr_DeleteContentUIButton;

		// Token: 0x04007F54 RID: 32596
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04007F55 RID: 32597
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04007F56 RID: 32598
		private static readonly IntPtr NativeMethodInfoPtr_OnClick_Private_Void_0;

		// Token: 0x04007F57 RID: 32599
		private static readonly IntPtr NativeMethodInfoPtr_DeleteCustomContentCache_Private_Void_0;

		// Token: 0x04007F58 RID: 32600
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
