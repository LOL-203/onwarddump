﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI
{
	// Token: 0x0200093E RID: 2366
	public class Onward_UI_TentToastNotification : MonoBehaviour
	{
		// Token: 0x0600C922 RID: 51490 RVA: 0x00320284 File Offset: 0x0031E484
		[CallerCount(0)]
		public unsafe static void Toast(string text, float duration)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(text);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_Toast_Public_Static_Void_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C923 RID: 51491 RVA: 0x003202E4 File Offset: 0x0031E4E4
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C924 RID: 51492 RVA: 0x00320328 File Offset: 0x0031E528
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C925 RID: 51493 RVA: 0x0032036C File Offset: 0x0031E56C
		[CallerCount(0)]
		public unsafe void ResetToast()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_ResetToast_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C926 RID: 51494 RVA: 0x003203B0 File Offset: 0x0031E5B0
		[CallerCount(0)]
		public unsafe void Setup(bool active)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref active;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_Setup_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C927 RID: 51495 RVA: 0x00320404 File Offset: 0x0031E604
		[CallerCount(0)]
		public unsafe void StopToast()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_StopToast_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C928 RID: 51496 RVA: 0x00320448 File Offset: 0x0031E648
		[CallerCount(0)]
		public unsafe void StartToast(string text, float duration)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(text);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_StartToast_Private_Void_String_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C929 RID: 51497 RVA: 0x003204B4 File Offset: 0x0031E6B4
		[CallerCount(0)]
		public unsafe IEnumerator ToastDisplayRoutine(string text, float duration)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(text);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_ToastDisplayRoutine_Private_IEnumerator_String_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600C92A RID: 51498 RVA: 0x00320534 File Offset: 0x0031E734
		[CallerCount(0)]
		public unsafe IEnumerator ToastFade(float startAlpha, float endAlpha, float duration)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref startAlpha;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref endAlpha;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref duration;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr_ToastFade_Private_IEnumerator_Single_Single_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600C92B RID: 51499 RVA: 0x003205C4 File Offset: 0x0031E7C4
		[CallerCount(0)]
		public unsafe Onward_UI_TentToastNotification() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C92C RID: 51500 RVA: 0x00320610 File Offset: 0x0031E810
		// Note: this type is marked as 'beforefieldinit'.
		static Onward_UI_TentToastNotification()
		{
			Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI", "Onward_UI_TentToastNotification");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr);
			Onward_UI_TentToastNotification.NativeFieldInfoPtr_Instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "Instance");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_toastText");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__fadeLength = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_fadeLength");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__colorHex = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_colorHex");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__alphaRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_alphaRange");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__testDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_testDuration");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__testString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_testString");
			Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastDisplayCoroutine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "_toastDisplayCoroutine");
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_Toast_Public_Static_Void_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678781);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678782);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678783);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_ResetToast_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678784);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_Setup_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678785);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_StopToast_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678786);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_StartToast_Private_Void_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678787);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_ToastDisplayRoutine_Private_IEnumerator_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678788);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr_ToastFade_Private_IEnumerator_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678789);
			Onward_UI_TentToastNotification.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, 100678790);
		}

		// Token: 0x0600C92D RID: 51501 RVA: 0x0000210C File Offset: 0x0000030C
		public Onward_UI_TentToastNotification(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004945 RID: 18757
		// (get) Token: 0x0600C92E RID: 51502 RVA: 0x003207A8 File Offset: 0x0031E9A8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr));
			}
		}

		// Token: 0x17004946 RID: 18758
		// (get) Token: 0x0600C92F RID: 51503 RVA: 0x003207BC File Offset: 0x0031E9BC
		// (set) Token: 0x0600C930 RID: 51504 RVA: 0x003207E7 File Offset: 0x0031E9E7
		public unsafe static Onward_UI_TentToastNotification Instance
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(Onward_UI_TentToastNotification.NativeFieldInfoPtr_Instance, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Onward_UI_TentToastNotification(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Onward_UI_TentToastNotification.NativeFieldInfoPtr_Instance, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004947 RID: 18759
		// (get) Token: 0x0600C931 RID: 51505 RVA: 0x003207FC File Offset: 0x0031E9FC
		// (set) Token: 0x0600C932 RID: 51506 RVA: 0x00320830 File Offset: 0x0031EA30
		public unsafe TextMeshProUGUI _toastText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004948 RID: 18760
		// (get) Token: 0x0600C933 RID: 51507 RVA: 0x00320858 File Offset: 0x0031EA58
		// (set) Token: 0x0600C934 RID: 51508 RVA: 0x00320880 File Offset: 0x0031EA80
		public unsafe float _fadeLength
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__fadeLength);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__fadeLength)) = value;
			}
		}

		// Token: 0x17004949 RID: 18761
		// (get) Token: 0x0600C935 RID: 51509 RVA: 0x003208A4 File Offset: 0x0031EAA4
		// (set) Token: 0x0600C936 RID: 51510 RVA: 0x003208CD File Offset: 0x0031EACD
		public unsafe string _colorHex
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__colorHex);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__colorHex), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700494A RID: 18762
		// (get) Token: 0x0600C937 RID: 51511 RVA: 0x003208F4 File Offset: 0x0031EAF4
		// (set) Token: 0x0600C938 RID: 51512 RVA: 0x0032091C File Offset: 0x0031EB1C
		public unsafe Vector2 _alphaRange
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__alphaRange);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__alphaRange)) = value;
			}
		}

		// Token: 0x1700494B RID: 18763
		// (get) Token: 0x0600C939 RID: 51513 RVA: 0x00320940 File Offset: 0x0031EB40
		// (set) Token: 0x0600C93A RID: 51514 RVA: 0x00320968 File Offset: 0x0031EB68
		public unsafe float _testDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__testDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__testDuration)) = value;
			}
		}

		// Token: 0x1700494C RID: 18764
		// (get) Token: 0x0600C93B RID: 51515 RVA: 0x0032098C File Offset: 0x0031EB8C
		// (set) Token: 0x0600C93C RID: 51516 RVA: 0x003209B5 File Offset: 0x0031EBB5
		public unsafe string _testString
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__testString);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__testString), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700494D RID: 18765
		// (get) Token: 0x0600C93D RID: 51517 RVA: 0x003209DC File Offset: 0x0031EBDC
		// (set) Token: 0x0600C93E RID: 51518 RVA: 0x00320A10 File Offset: 0x0031EC10
		public unsafe Coroutine _toastDisplayCoroutine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastDisplayCoroutine);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Coroutine(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification.NativeFieldInfoPtr__toastDisplayCoroutine), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F17 RID: 32535
		private static readonly IntPtr NativeFieldInfoPtr_Instance;

		// Token: 0x04007F18 RID: 32536
		private static readonly IntPtr NativeFieldInfoPtr__toastText;

		// Token: 0x04007F19 RID: 32537
		private static readonly IntPtr NativeFieldInfoPtr__fadeLength;

		// Token: 0x04007F1A RID: 32538
		private static readonly IntPtr NativeFieldInfoPtr__colorHex;

		// Token: 0x04007F1B RID: 32539
		private static readonly IntPtr NativeFieldInfoPtr__alphaRange;

		// Token: 0x04007F1C RID: 32540
		private static readonly IntPtr NativeFieldInfoPtr__testDuration;

		// Token: 0x04007F1D RID: 32541
		private static readonly IntPtr NativeFieldInfoPtr__testString;

		// Token: 0x04007F1E RID: 32542
		private static readonly IntPtr NativeFieldInfoPtr__toastDisplayCoroutine;

		// Token: 0x04007F1F RID: 32543
		private static readonly IntPtr NativeMethodInfoPtr_Toast_Public_Static_Void_String_Single_0;

		// Token: 0x04007F20 RID: 32544
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04007F21 RID: 32545
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04007F22 RID: 32546
		private static readonly IntPtr NativeMethodInfoPtr_ResetToast_Private_Void_0;

		// Token: 0x04007F23 RID: 32547
		private static readonly IntPtr NativeMethodInfoPtr_Setup_Private_Void_Boolean_0;

		// Token: 0x04007F24 RID: 32548
		private static readonly IntPtr NativeMethodInfoPtr_StopToast_Private_Void_0;

		// Token: 0x04007F25 RID: 32549
		private static readonly IntPtr NativeMethodInfoPtr_StartToast_Private_Void_String_Single_0;

		// Token: 0x04007F26 RID: 32550
		private static readonly IntPtr NativeMethodInfoPtr_ToastDisplayRoutine_Private_IEnumerator_String_Single_0;

		// Token: 0x04007F27 RID: 32551
		private static readonly IntPtr NativeMethodInfoPtr_ToastFade_Private_IEnumerator_Single_Single_Single_0;

		// Token: 0x04007F28 RID: 32552
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200093F RID: 2367
		[ObfuscatedName("_Game.UI.Onward_UI_TentToastNotification/<ToastDisplayRoutine>d__15")]
		public sealed class _ToastDisplayRoutine_d__15 : Il2CppSystem.Object
		{
			// Token: 0x0600C93F RID: 51519 RVA: 0x00320A38 File Offset: 0x0031EC38
			[CallerCount(0)]
			public unsafe _ToastDisplayRoutine_d__15(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C940 RID: 51520 RVA: 0x00320A98 File Offset: 0x0031EC98
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C941 RID: 51521 RVA: 0x00320ADC File Offset: 0x0031ECDC
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17004954 RID: 18772
			// (get) Token: 0x0600C942 RID: 51522 RVA: 0x00320B2C File Offset: 0x0031ED2C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600C943 RID: 51523 RVA: 0x00320B84 File Offset: 0x0031ED84
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17004955 RID: 18773
			// (get) Token: 0x0600C944 RID: 51524 RVA: 0x00320BC8 File Offset: 0x0031EDC8
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600C945 RID: 51525 RVA: 0x00320C20 File Offset: 0x0031EE20
			// Note: this type is marked as 'beforefieldinit'.
			static _ToastDisplayRoutine_d__15()
			{
				Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "<ToastDisplayRoutine>d__15");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, "<>1__state");
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, "<>2__current");
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, "<>4__this");
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_text = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, "text");
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_duration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, "duration");
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678791);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678792);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678793);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678794);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678795);
				Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr, 100678796);
			}

			// Token: 0x0600C946 RID: 51526 RVA: 0x00002988 File Offset: 0x00000B88
			public _ToastDisplayRoutine_d__15(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700494E RID: 18766
			// (get) Token: 0x0600C947 RID: 51527 RVA: 0x00320D27 File Offset: 0x0031EF27
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15>.NativeClassPtr));
				}
			}

			// Token: 0x1700494F RID: 18767
			// (get) Token: 0x0600C948 RID: 51528 RVA: 0x00320D38 File Offset: 0x0031EF38
			// (set) Token: 0x0600C949 RID: 51529 RVA: 0x00320D60 File Offset: 0x0031EF60
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17004950 RID: 18768
			// (get) Token: 0x0600C94A RID: 51530 RVA: 0x00320D84 File Offset: 0x0031EF84
			// (set) Token: 0x0600C94B RID: 51531 RVA: 0x00320DB8 File Offset: 0x0031EFB8
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004951 RID: 18769
			// (get) Token: 0x0600C94C RID: 51532 RVA: 0x00320DE0 File Offset: 0x0031EFE0
			// (set) Token: 0x0600C94D RID: 51533 RVA: 0x00320E14 File Offset: 0x0031F014
			public unsafe Onward_UI_TentToastNotification __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Onward_UI_TentToastNotification(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004952 RID: 18770
			// (get) Token: 0x0600C94E RID: 51534 RVA: 0x00320E3C File Offset: 0x0031F03C
			// (set) Token: 0x0600C94F RID: 51535 RVA: 0x00320E65 File Offset: 0x0031F065
			public unsafe string text
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_text);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_text), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x17004953 RID: 18771
			// (get) Token: 0x0600C950 RID: 51536 RVA: 0x00320E8C File Offset: 0x0031F08C
			// (set) Token: 0x0600C951 RID: 51537 RVA: 0x00320EB4 File Offset: 0x0031F0B4
			public unsafe float duration
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_duration);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastDisplayRoutine_d__15.NativeFieldInfoPtr_duration)) = value;
				}
			}

			// Token: 0x04007F29 RID: 32553
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x04007F2A RID: 32554
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x04007F2B RID: 32555
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04007F2C RID: 32556
			private static readonly IntPtr NativeFieldInfoPtr_text;

			// Token: 0x04007F2D RID: 32557
			private static readonly IntPtr NativeFieldInfoPtr_duration;

			// Token: 0x04007F2E RID: 32558
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x04007F2F RID: 32559
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007F30 RID: 32560
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x04007F31 RID: 32561
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x04007F32 RID: 32562
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007F33 RID: 32563
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}

		// Token: 0x02000940 RID: 2368
		[ObfuscatedName("_Game.UI.Onward_UI_TentToastNotification/<ToastFade>d__16")]
		public sealed class _ToastFade_d__16 : Il2CppSystem.Object
		{
			// Token: 0x0600C952 RID: 51538 RVA: 0x00320ED8 File Offset: 0x0031F0D8
			[CallerCount(0)]
			public unsafe _ToastFade_d__16(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C953 RID: 51539 RVA: 0x00320F38 File Offset: 0x0031F138
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600C954 RID: 51540 RVA: 0x00320F7C File Offset: 0x0031F17C
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x17004960 RID: 18784
			// (get) Token: 0x0600C955 RID: 51541 RVA: 0x00320FCC File Offset: 0x0031F1CC
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600C956 RID: 51542 RVA: 0x00321024 File Offset: 0x0031F224
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x17004961 RID: 18785
			// (get) Token: 0x0600C957 RID: 51543 RVA: 0x00321068 File Offset: 0x0031F268
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x0600C958 RID: 51544 RVA: 0x003210C0 File Offset: 0x0031F2C0
			// Note: this type is marked as 'beforefieldinit'.
			static _ToastFade_d__16()
			{
				Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<Onward_UI_TentToastNotification>.NativeClassPtr, "<ToastFade>d__16");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<>1__state");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<>2__current");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<>4__this");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_startAlpha = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "startAlpha");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_endAlpha = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "endAlpha");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_duration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "duration");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__timer_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<timer>5__2");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__startColor_5__3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<startColor>5__3");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__endColor_5__4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, "<endColor>5__4");
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678797);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678798);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678799);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678800);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678801);
				Onward_UI_TentToastNotification._ToastFade_d__16.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr, 100678802);
			}

			// Token: 0x0600C959 RID: 51545 RVA: 0x00002988 File Offset: 0x00000B88
			public _ToastFade_d__16(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17004956 RID: 18774
			// (get) Token: 0x0600C95A RID: 51546 RVA: 0x00321217 File Offset: 0x0031F417
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Onward_UI_TentToastNotification._ToastFade_d__16>.NativeClassPtr));
				}
			}

			// Token: 0x17004957 RID: 18775
			// (get) Token: 0x0600C95B RID: 51547 RVA: 0x00321228 File Offset: 0x0031F428
			// (set) Token: 0x0600C95C RID: 51548 RVA: 0x00321250 File Offset: 0x0031F450
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x17004958 RID: 18776
			// (get) Token: 0x0600C95D RID: 51549 RVA: 0x00321274 File Offset: 0x0031F474
			// (set) Token: 0x0600C95E RID: 51550 RVA: 0x003212A8 File Offset: 0x0031F4A8
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17004959 RID: 18777
			// (get) Token: 0x0600C95F RID: 51551 RVA: 0x003212D0 File Offset: 0x0031F4D0
			// (set) Token: 0x0600C960 RID: 51552 RVA: 0x00321304 File Offset: 0x0031F504
			public unsafe Onward_UI_TentToastNotification __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Onward_UI_TentToastNotification(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x1700495A RID: 18778
			// (get) Token: 0x0600C961 RID: 51553 RVA: 0x0032132C File Offset: 0x0031F52C
			// (set) Token: 0x0600C962 RID: 51554 RVA: 0x00321354 File Offset: 0x0031F554
			public unsafe float startAlpha
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_startAlpha);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_startAlpha)) = value;
				}
			}

			// Token: 0x1700495B RID: 18779
			// (get) Token: 0x0600C963 RID: 51555 RVA: 0x00321378 File Offset: 0x0031F578
			// (set) Token: 0x0600C964 RID: 51556 RVA: 0x003213A0 File Offset: 0x0031F5A0
			public unsafe float endAlpha
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_endAlpha);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_endAlpha)) = value;
				}
			}

			// Token: 0x1700495C RID: 18780
			// (get) Token: 0x0600C965 RID: 51557 RVA: 0x003213C4 File Offset: 0x0031F5C4
			// (set) Token: 0x0600C966 RID: 51558 RVA: 0x003213EC File Offset: 0x0031F5EC
			public unsafe float duration
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_duration);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr_duration)) = value;
				}
			}

			// Token: 0x1700495D RID: 18781
			// (get) Token: 0x0600C967 RID: 51559 RVA: 0x00321410 File Offset: 0x0031F610
			// (set) Token: 0x0600C968 RID: 51560 RVA: 0x00321438 File Offset: 0x0031F638
			public unsafe float _timer_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__timer_5__2);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__timer_5__2)) = value;
				}
			}

			// Token: 0x1700495E RID: 18782
			// (get) Token: 0x0600C969 RID: 51561 RVA: 0x0032145C File Offset: 0x0031F65C
			// (set) Token: 0x0600C96A RID: 51562 RVA: 0x00321484 File Offset: 0x0031F684
			public unsafe Color _startColor_5__3
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__startColor_5__3);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__startColor_5__3)) = value;
				}
			}

			// Token: 0x1700495F RID: 18783
			// (get) Token: 0x0600C96B RID: 51563 RVA: 0x003214A8 File Offset: 0x0031F6A8
			// (set) Token: 0x0600C96C RID: 51564 RVA: 0x003214D0 File Offset: 0x0031F6D0
			public unsafe Color _endColor_5__4
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__endColor_5__4);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_TentToastNotification._ToastFade_d__16.NativeFieldInfoPtr__endColor_5__4)) = value;
				}
			}

			// Token: 0x04007F34 RID: 32564
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x04007F35 RID: 32565
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x04007F36 RID: 32566
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04007F37 RID: 32567
			private static readonly IntPtr NativeFieldInfoPtr_startAlpha;

			// Token: 0x04007F38 RID: 32568
			private static readonly IntPtr NativeFieldInfoPtr_endAlpha;

			// Token: 0x04007F39 RID: 32569
			private static readonly IntPtr NativeFieldInfoPtr_duration;

			// Token: 0x04007F3A RID: 32570
			private static readonly IntPtr NativeFieldInfoPtr__timer_5__2;

			// Token: 0x04007F3B RID: 32571
			private static readonly IntPtr NativeFieldInfoPtr__startColor_5__3;

			// Token: 0x04007F3C RID: 32572
			private static readonly IntPtr NativeFieldInfoPtr__endColor_5__4;

			// Token: 0x04007F3D RID: 32573
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x04007F3E RID: 32574
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007F3F RID: 32575
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x04007F40 RID: 32576
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x04007F41 RID: 32577
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x04007F42 RID: 32578
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
