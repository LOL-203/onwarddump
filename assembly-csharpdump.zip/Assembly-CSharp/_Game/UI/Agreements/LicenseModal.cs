﻿using System;
using DPI.Agreements;
using Il2CppSystem;
using Onward.Licenses;
using Onward.UI.Dialogs;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;
using _Game.Services.Common;

namespace _Game.UI.Agreements
{
	// Token: 0x02000946 RID: 2374
	public class LicenseModal : ModalDialogBase
	{
		// Token: 0x0600C99C RID: 51612 RVA: 0x00321EF4 File Offset: 0x003200F4
		[CallerCount(0)]
		public new unsafe void SetupModalDialog(ModalDialogPropertiesBase props)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(props);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), LicenseModal.NativeMethodInfoPtr_SetupModalDialog_Public_Virtual_Void_ModalDialogPropertiesBase_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C99D RID: 51613 RVA: 0x00321F58 File Offset: 0x00320158
		[CallerCount(0)]
		public unsafe void SetupNextAgreementToShowForModalDialog()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_SetupNextAgreementToShowForModalDialog_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C99E RID: 51614 RVA: 0x00321F9C File Offset: 0x0032019C
		[CallerCount(0)]
		public unsafe void Initialize(LicenseAgreementService licenseAgreementService, LicenseAgreement data, Action onExitModal, bool isBackButtonActive)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(licenseAgreementService);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(data);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(onExitModal);
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref isBackButtonActive;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_Initialize_Public_Void_LicenseAgreementService_LicenseAgreement_Action_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C99F RID: 51615 RVA: 0x00322038 File Offset: 0x00320238
		[CallerCount(0)]
		public unsafe void OnLicenseAgreementClicked()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_OnLicenseAgreementClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A0 RID: 51616 RVA: 0x0032207C File Offset: 0x0032027C
		[CallerCount(0)]
		public unsafe void OnDeclineLicenseAgreementClicked()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_OnDeclineLicenseAgreementClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A1 RID: 51617 RVA: 0x003220C0 File Offset: 0x003202C0
		[CallerCount(0)]
		public unsafe void OnBackButtonClicked()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_OnBackButtonClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A2 RID: 51618 RVA: 0x00322104 File Offset: 0x00320304
		[CallerCount(0)]
		public unsafe string GetAcceptString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_GetAcceptString_Private_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600C9A3 RID: 51619 RVA: 0x00322150 File Offset: 0x00320350
		[CallerCount(0)]
		public unsafe void LicenseStatusChanged(bool agreed)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref agreed;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_LicenseStatusChanged_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A4 RID: 51620 RVA: 0x003221A4 File Offset: 0x003203A4
		[CallerCount(0)]
		public unsafe void ProcessButtonOverrides(LicenseAgreement agreement)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(agreement);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_ProcessButtonOverrides_Private_Void_LicenseAgreement_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A5 RID: 51621 RVA: 0x00322200 File Offset: 0x00320400
		[CallerCount(0)]
		public unsafe void ProcessButtonOverride(AgreementButtonOverride buttonOverride, string expectedRegion)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(buttonOverride));
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(expectedRegion);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_ProcessButtonOverride_Private_Void_AgreementButtonOverride_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A6 RID: 51622 RVA: 0x00322278 File Offset: 0x00320478
		[CallerCount(0)]
		public unsafe void OnInfoLicenseAgreementClicked()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr_OnInfoLicenseAgreementClicked_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A7 RID: 51623 RVA: 0x003222BC File Offset: 0x003204BC
		[CallerCount(0)]
		public unsafe LicenseModal() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LicenseModal.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9A8 RID: 51624 RVA: 0x00322308 File Offset: 0x00320508
		// Note: this type is marked as 'beforefieldinit'.
		static LicenseModal()
		{
			Il2CppClassPointerStore<LicenseModal>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.Agreements", "LicenseModal");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr);
			LicenseModal.NativeFieldInfoPtr__headerText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_headerText");
			LicenseModal.NativeFieldInfoPtr__acceptedStatus = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_acceptedStatus");
			LicenseModal.NativeFieldInfoPtr__optInObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optInObject");
			LicenseModal.NativeFieldInfoPtr__optOutObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optOutObject");
			LicenseModal.NativeFieldInfoPtr__acknowledgeObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_acknowledgeObject");
			LicenseModal.NativeFieldInfoPtr__infoObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_infoObject");
			LicenseModal.NativeFieldInfoPtr__optInButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optInButton");
			LicenseModal.NativeFieldInfoPtr__optOutButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optOutButton");
			LicenseModal.NativeFieldInfoPtr__acknowledgeButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_acknowledgeButton");
			LicenseModal.NativeFieldInfoPtr__infoButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_infoButton");
			LicenseModal.NativeFieldInfoPtr__optInText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optInText");
			LicenseModal.NativeFieldInfoPtr__optOutText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_optOutText");
			LicenseModal.NativeFieldInfoPtr__acknowledgeText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_acknowledgeText");
			LicenseModal.NativeFieldInfoPtr__infoText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_infoText");
			LicenseModal.NativeFieldInfoPtr__backText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_backText");
			LicenseModal.NativeFieldInfoPtr__backButtonGameObject = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_backButtonGameObject");
			LicenseModal.NativeFieldInfoPtr__backButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_backButton");
			LicenseModal.NativeFieldInfoPtr__licenseTextStream = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_licenseTextStream");
			LicenseModal.NativeFieldInfoPtr__licenseAgreementService = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_licenseAgreementService");
			LicenseModal.NativeFieldInfoPtr__agreement = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_agreement");
			LicenseModal.NativeFieldInfoPtr__onExitModal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, "_onExitModal");
			LicenseModal.NativeMethodInfoPtr_SetupModalDialog_Public_Virtual_Void_ModalDialogPropertiesBase_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678818);
			LicenseModal.NativeMethodInfoPtr_SetupNextAgreementToShowForModalDialog_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678819);
			LicenseModal.NativeMethodInfoPtr_Initialize_Public_Void_LicenseAgreementService_LicenseAgreement_Action_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678820);
			LicenseModal.NativeMethodInfoPtr_OnLicenseAgreementClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678821);
			LicenseModal.NativeMethodInfoPtr_OnDeclineLicenseAgreementClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678822);
			LicenseModal.NativeMethodInfoPtr_OnBackButtonClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678823);
			LicenseModal.NativeMethodInfoPtr_GetAcceptString_Private_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678824);
			LicenseModal.NativeMethodInfoPtr_LicenseStatusChanged_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678825);
			LicenseModal.NativeMethodInfoPtr_ProcessButtonOverrides_Private_Void_LicenseAgreement_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678826);
			LicenseModal.NativeMethodInfoPtr_ProcessButtonOverride_Private_Void_AgreementButtonOverride_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678827);
			LicenseModal.NativeMethodInfoPtr_OnInfoLicenseAgreementClicked_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678828);
			LicenseModal.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr, 100678829);
		}

		// Token: 0x0600C9A9 RID: 51625 RVA: 0x003225CC File Offset: 0x003207CC
		public LicenseModal(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004971 RID: 18801
		// (get) Token: 0x0600C9AA RID: 51626 RVA: 0x003225D5 File Offset: 0x003207D5
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<LicenseModal>.NativeClassPtr));
			}
		}

		// Token: 0x17004972 RID: 18802
		// (get) Token: 0x0600C9AB RID: 51627 RVA: 0x003225E8 File Offset: 0x003207E8
		// (set) Token: 0x0600C9AC RID: 51628 RVA: 0x0032261C File Offset: 0x0032081C
		public unsafe TextMeshProUGUI _headerText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__headerText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__headerText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004973 RID: 18803
		// (get) Token: 0x0600C9AD RID: 51629 RVA: 0x00322644 File Offset: 0x00320844
		// (set) Token: 0x0600C9AE RID: 51630 RVA: 0x00322678 File Offset: 0x00320878
		public unsafe TextMeshProUGUI _acceptedStatus
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acceptedStatus);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acceptedStatus), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004974 RID: 18804
		// (get) Token: 0x0600C9AF RID: 51631 RVA: 0x003226A0 File Offset: 0x003208A0
		// (set) Token: 0x0600C9B0 RID: 51632 RVA: 0x003226D4 File Offset: 0x003208D4
		public unsafe GameObject _optInObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004975 RID: 18805
		// (get) Token: 0x0600C9B1 RID: 51633 RVA: 0x003226FC File Offset: 0x003208FC
		// (set) Token: 0x0600C9B2 RID: 51634 RVA: 0x00322730 File Offset: 0x00320930
		public unsafe GameObject _optOutObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004976 RID: 18806
		// (get) Token: 0x0600C9B3 RID: 51635 RVA: 0x00322758 File Offset: 0x00320958
		// (set) Token: 0x0600C9B4 RID: 51636 RVA: 0x0032278C File Offset: 0x0032098C
		public unsafe GameObject _acknowledgeObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004977 RID: 18807
		// (get) Token: 0x0600C9B5 RID: 51637 RVA: 0x003227B4 File Offset: 0x003209B4
		// (set) Token: 0x0600C9B6 RID: 51638 RVA: 0x003227E8 File Offset: 0x003209E8
		public unsafe GameObject _infoObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004978 RID: 18808
		// (get) Token: 0x0600C9B7 RID: 51639 RVA: 0x00322810 File Offset: 0x00320A10
		// (set) Token: 0x0600C9B8 RID: 51640 RVA: 0x00322844 File Offset: 0x00320A44
		public unsafe Button _optInButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004979 RID: 18809
		// (get) Token: 0x0600C9B9 RID: 51641 RVA: 0x0032286C File Offset: 0x00320A6C
		// (set) Token: 0x0600C9BA RID: 51642 RVA: 0x003228A0 File Offset: 0x00320AA0
		public unsafe Button _optOutButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497A RID: 18810
		// (get) Token: 0x0600C9BB RID: 51643 RVA: 0x003228C8 File Offset: 0x00320AC8
		// (set) Token: 0x0600C9BC RID: 51644 RVA: 0x003228FC File Offset: 0x00320AFC
		public unsafe Button _acknowledgeButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497B RID: 18811
		// (get) Token: 0x0600C9BD RID: 51645 RVA: 0x00322924 File Offset: 0x00320B24
		// (set) Token: 0x0600C9BE RID: 51646 RVA: 0x00322958 File Offset: 0x00320B58
		public unsafe Button _infoButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497C RID: 18812
		// (get) Token: 0x0600C9BF RID: 51647 RVA: 0x00322980 File Offset: 0x00320B80
		// (set) Token: 0x0600C9C0 RID: 51648 RVA: 0x003229B4 File Offset: 0x00320BB4
		public unsafe TextMeshProUGUI _optInText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optInText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497D RID: 18813
		// (get) Token: 0x0600C9C1 RID: 51649 RVA: 0x003229DC File Offset: 0x00320BDC
		// (set) Token: 0x0600C9C2 RID: 51650 RVA: 0x00322A10 File Offset: 0x00320C10
		public unsafe TextMeshProUGUI _optOutText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__optOutText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497E RID: 18814
		// (get) Token: 0x0600C9C3 RID: 51651 RVA: 0x00322A38 File Offset: 0x00320C38
		// (set) Token: 0x0600C9C4 RID: 51652 RVA: 0x00322A6C File Offset: 0x00320C6C
		public unsafe TextMeshProUGUI _acknowledgeText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__acknowledgeText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700497F RID: 18815
		// (get) Token: 0x0600C9C5 RID: 51653 RVA: 0x00322A94 File Offset: 0x00320C94
		// (set) Token: 0x0600C9C6 RID: 51654 RVA: 0x00322AC8 File Offset: 0x00320CC8
		public unsafe TextMeshProUGUI _infoText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__infoText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004980 RID: 18816
		// (get) Token: 0x0600C9C7 RID: 51655 RVA: 0x00322AF0 File Offset: 0x00320CF0
		// (set) Token: 0x0600C9C8 RID: 51656 RVA: 0x00322B24 File Offset: 0x00320D24
		public unsafe TextMeshProUGUI _backText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004981 RID: 18817
		// (get) Token: 0x0600C9C9 RID: 51657 RVA: 0x00322B4C File Offset: 0x00320D4C
		// (set) Token: 0x0600C9CA RID: 51658 RVA: 0x00322B80 File Offset: 0x00320D80
		public unsafe GameObject _backButtonGameObject
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backButtonGameObject);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backButtonGameObject), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004982 RID: 18818
		// (get) Token: 0x0600C9CB RID: 51659 RVA: 0x00322BA8 File Offset: 0x00320DA8
		// (set) Token: 0x0600C9CC RID: 51660 RVA: 0x00322BDC File Offset: 0x00320DDC
		public unsafe Button _backButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__backButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004983 RID: 18819
		// (get) Token: 0x0600C9CD RID: 51661 RVA: 0x00322C04 File Offset: 0x00320E04
		// (set) Token: 0x0600C9CE RID: 51662 RVA: 0x00322C38 File Offset: 0x00320E38
		public unsafe LicenseTextStream _licenseTextStream
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__licenseTextStream);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LicenseTextStream(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__licenseTextStream), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004984 RID: 18820
		// (get) Token: 0x0600C9CF RID: 51663 RVA: 0x00322C60 File Offset: 0x00320E60
		// (set) Token: 0x0600C9D0 RID: 51664 RVA: 0x00322C94 File Offset: 0x00320E94
		public unsafe LicenseAgreementService _licenseAgreementService
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__licenseAgreementService);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LicenseAgreementService(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__licenseAgreementService), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004985 RID: 18821
		// (get) Token: 0x0600C9D1 RID: 51665 RVA: 0x00322CBC File Offset: 0x00320EBC
		// (set) Token: 0x0600C9D2 RID: 51666 RVA: 0x00322CF0 File Offset: 0x00320EF0
		public unsafe LicenseAgreement _agreement
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__agreement);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LicenseAgreement(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__agreement), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004986 RID: 18822
		// (get) Token: 0x0600C9D3 RID: 51667 RVA: 0x00322D18 File Offset: 0x00320F18
		// (set) Token: 0x0600C9D4 RID: 51668 RVA: 0x00322D4C File Offset: 0x00320F4C
		public unsafe Action _onExitModal
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__onExitModal);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(LicenseModal.NativeFieldInfoPtr__onExitModal), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F5E RID: 32606
		private static readonly IntPtr NativeFieldInfoPtr__headerText;

		// Token: 0x04007F5F RID: 32607
		private static readonly IntPtr NativeFieldInfoPtr__acceptedStatus;

		// Token: 0x04007F60 RID: 32608
		private static readonly IntPtr NativeFieldInfoPtr__optInObject;

		// Token: 0x04007F61 RID: 32609
		private static readonly IntPtr NativeFieldInfoPtr__optOutObject;

		// Token: 0x04007F62 RID: 32610
		private static readonly IntPtr NativeFieldInfoPtr__acknowledgeObject;

		// Token: 0x04007F63 RID: 32611
		private static readonly IntPtr NativeFieldInfoPtr__infoObject;

		// Token: 0x04007F64 RID: 32612
		private static readonly IntPtr NativeFieldInfoPtr__optInButton;

		// Token: 0x04007F65 RID: 32613
		private static readonly IntPtr NativeFieldInfoPtr__optOutButton;

		// Token: 0x04007F66 RID: 32614
		private static readonly IntPtr NativeFieldInfoPtr__acknowledgeButton;

		// Token: 0x04007F67 RID: 32615
		private static readonly IntPtr NativeFieldInfoPtr__infoButton;

		// Token: 0x04007F68 RID: 32616
		private static readonly IntPtr NativeFieldInfoPtr__optInText;

		// Token: 0x04007F69 RID: 32617
		private static readonly IntPtr NativeFieldInfoPtr__optOutText;

		// Token: 0x04007F6A RID: 32618
		private static readonly IntPtr NativeFieldInfoPtr__acknowledgeText;

		// Token: 0x04007F6B RID: 32619
		private static readonly IntPtr NativeFieldInfoPtr__infoText;

		// Token: 0x04007F6C RID: 32620
		private static readonly IntPtr NativeFieldInfoPtr__backText;

		// Token: 0x04007F6D RID: 32621
		private static readonly IntPtr NativeFieldInfoPtr__backButtonGameObject;

		// Token: 0x04007F6E RID: 32622
		private static readonly IntPtr NativeFieldInfoPtr__backButton;

		// Token: 0x04007F6F RID: 32623
		private static readonly IntPtr NativeFieldInfoPtr__licenseTextStream;

		// Token: 0x04007F70 RID: 32624
		private static readonly IntPtr NativeFieldInfoPtr__licenseAgreementService;

		// Token: 0x04007F71 RID: 32625
		private static readonly IntPtr NativeFieldInfoPtr__agreement;

		// Token: 0x04007F72 RID: 32626
		private static readonly IntPtr NativeFieldInfoPtr__onExitModal;

		// Token: 0x04007F73 RID: 32627
		private static readonly IntPtr NativeMethodInfoPtr_SetupModalDialog_Public_Virtual_Void_ModalDialogPropertiesBase_0;

		// Token: 0x04007F74 RID: 32628
		private static readonly IntPtr NativeMethodInfoPtr_SetupNextAgreementToShowForModalDialog_Private_Void_0;

		// Token: 0x04007F75 RID: 32629
		private static readonly IntPtr NativeMethodInfoPtr_Initialize_Public_Void_LicenseAgreementService_LicenseAgreement_Action_Boolean_0;

		// Token: 0x04007F76 RID: 32630
		private static readonly IntPtr NativeMethodInfoPtr_OnLicenseAgreementClicked_Private_Void_0;

		// Token: 0x04007F77 RID: 32631
		private static readonly IntPtr NativeMethodInfoPtr_OnDeclineLicenseAgreementClicked_Private_Void_0;

		// Token: 0x04007F78 RID: 32632
		private static readonly IntPtr NativeMethodInfoPtr_OnBackButtonClicked_Private_Void_0;

		// Token: 0x04007F79 RID: 32633
		private static readonly IntPtr NativeMethodInfoPtr_GetAcceptString_Private_String_0;

		// Token: 0x04007F7A RID: 32634
		private static readonly IntPtr NativeMethodInfoPtr_LicenseStatusChanged_Private_Void_Boolean_0;

		// Token: 0x04007F7B RID: 32635
		private static readonly IntPtr NativeMethodInfoPtr_ProcessButtonOverrides_Private_Void_LicenseAgreement_0;

		// Token: 0x04007F7C RID: 32636
		private static readonly IntPtr NativeMethodInfoPtr_ProcessButtonOverride_Private_Void_AgreementButtonOverride_String_0;

		// Token: 0x04007F7D RID: 32637
		private static readonly IntPtr NativeMethodInfoPtr_OnInfoLicenseAgreementClicked_Private_Void_0;

		// Token: 0x04007F7E RID: 32638
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
