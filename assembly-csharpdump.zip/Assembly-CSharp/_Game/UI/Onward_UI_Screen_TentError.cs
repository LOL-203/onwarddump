﻿using System;
using Il2CppSystem;
using Onward.UI;
using TMPro;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace _Game.UI
{
	// Token: 0x0200093D RID: 2365
	public class Onward_UI_Screen_TentError : Onward_UI_Screen
	{
		// Token: 0x0600C90D RID: 51469 RVA: 0x0031FD24 File Offset: 0x0031DF24
		[CallerCount(0)]
		public new unsafe void OpenScreen(Onward_UI_Screen comingFrom)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(comingFrom);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Onward_UI_Screen_TentError.NativeMethodInfoPtr_OpenScreen_Public_Virtual_Void_Onward_UI_Screen_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C90E RID: 51470 RVA: 0x0031FD88 File Offset: 0x0031DF88
		[CallerCount(0)]
		public new unsafe void CloseScreen(Onward_UI_Screen goingTo)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(goingTo);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Onward_UI_Screen_TentError.NativeMethodInfoPtr_CloseScreen_Public_Virtual_Void_Onward_UI_Screen_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C90F RID: 51471 RVA: 0x0031FDEC File Offset: 0x0031DFEC
		[CallerCount(0)]
		public unsafe void SetText(string text)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(text);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_Screen_TentError.NativeMethodInfoPtr_SetText_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C910 RID: 51472 RVA: 0x0031FE48 File Offset: 0x0031E048
		[CallerCount(0)]
		public unsafe void SetButton(bool enableButton, string text)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref enableButton;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(text);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_Screen_TentError.NativeMethodInfoPtr_SetButton_Public_Void_Boolean_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C911 RID: 51473 RVA: 0x0031FEB4 File Offset: 0x0031E0B4
		[CallerCount(0)]
		public unsafe void ContinueSelected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_Screen_TentError.NativeMethodInfoPtr_ContinueSelected_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C912 RID: 51474 RVA: 0x0031FEF8 File Offset: 0x0031E0F8
		[CallerCount(0)]
		public unsafe Onward_UI_Screen_TentError() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Onward_UI_Screen_TentError.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C913 RID: 51475 RVA: 0x0031FF44 File Offset: 0x0031E144
		// Note: this type is marked as 'beforefieldinit'.
		static Onward_UI_Screen_TentError()
		{
			Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI", "Onward_UI_Screen_TentError");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr);
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_OnContinue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "OnContinue");
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonContainer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "ButtonContainer");
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_ContinueButton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "ContinueButton");
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "ButtonText");
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_ErrorText = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "ErrorText");
			Onward_UI_Screen_TentError.NativeFieldInfoPtr_Instance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, "Instance");
			Onward_UI_Screen_TentError.NativeMethodInfoPtr_OpenScreen_Public_Virtual_Void_Onward_UI_Screen_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678775);
			Onward_UI_Screen_TentError.NativeMethodInfoPtr_CloseScreen_Public_Virtual_Void_Onward_UI_Screen_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678776);
			Onward_UI_Screen_TentError.NativeMethodInfoPtr_SetText_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678777);
			Onward_UI_Screen_TentError.NativeMethodInfoPtr_SetButton_Public_Void_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678778);
			Onward_UI_Screen_TentError.NativeMethodInfoPtr_ContinueSelected_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678779);
			Onward_UI_Screen_TentError.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr, 100678780);
		}

		// Token: 0x0600C914 RID: 51476 RVA: 0x00155468 File Offset: 0x00153668
		public Onward_UI_Screen_TentError(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700493E RID: 18750
		// (get) Token: 0x0600C915 RID: 51477 RVA: 0x00320064 File Offset: 0x0031E264
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Onward_UI_Screen_TentError>.NativeClassPtr));
			}
		}

		// Token: 0x1700493F RID: 18751
		// (get) Token: 0x0600C916 RID: 51478 RVA: 0x00320078 File Offset: 0x0031E278
		// (set) Token: 0x0600C917 RID: 51479 RVA: 0x003200AC File Offset: 0x0031E2AC
		public unsafe Action OnContinue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_OnContinue);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_OnContinue), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004940 RID: 18752
		// (get) Token: 0x0600C918 RID: 51480 RVA: 0x003200D4 File Offset: 0x0031E2D4
		// (set) Token: 0x0600C919 RID: 51481 RVA: 0x00320108 File Offset: 0x0031E308
		public unsafe GameObject ButtonContainer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonContainer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonContainer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004941 RID: 18753
		// (get) Token: 0x0600C91A RID: 51482 RVA: 0x00320130 File Offset: 0x0031E330
		// (set) Token: 0x0600C91B RID: 51483 RVA: 0x00320164 File Offset: 0x0031E364
		public unsafe Button ContinueButton
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ContinueButton);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Button(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ContinueButton), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004942 RID: 18754
		// (get) Token: 0x0600C91C RID: 51484 RVA: 0x0032018C File Offset: 0x0031E38C
		// (set) Token: 0x0600C91D RID: 51485 RVA: 0x003201C0 File Offset: 0x0031E3C0
		public unsafe TextMeshProUGUI ButtonText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ButtonText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004943 RID: 18755
		// (get) Token: 0x0600C91E RID: 51486 RVA: 0x003201E8 File Offset: 0x0031E3E8
		// (set) Token: 0x0600C91F RID: 51487 RVA: 0x0032021C File Offset: 0x0031E41C
		public unsafe TextMeshProUGUI ErrorText
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ErrorText);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new TextMeshProUGUI(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(Onward_UI_Screen_TentError.NativeFieldInfoPtr_ErrorText), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004944 RID: 18756
		// (get) Token: 0x0600C920 RID: 51488 RVA: 0x00320244 File Offset: 0x0031E444
		// (set) Token: 0x0600C921 RID: 51489 RVA: 0x0032026F File Offset: 0x0031E46F
		public unsafe static Onward_UI_Screen_TentError Instance
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(Onward_UI_Screen_TentError.NativeFieldInfoPtr_Instance, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Onward_UI_Screen_TentError(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Onward_UI_Screen_TentError.NativeFieldInfoPtr_Instance, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04007F0B RID: 32523
		private static readonly IntPtr NativeFieldInfoPtr_OnContinue;

		// Token: 0x04007F0C RID: 32524
		private static readonly IntPtr NativeFieldInfoPtr_ButtonContainer;

		// Token: 0x04007F0D RID: 32525
		private static readonly IntPtr NativeFieldInfoPtr_ContinueButton;

		// Token: 0x04007F0E RID: 32526
		private static readonly IntPtr NativeFieldInfoPtr_ButtonText;

		// Token: 0x04007F0F RID: 32527
		private static readonly IntPtr NativeFieldInfoPtr_ErrorText;

		// Token: 0x04007F10 RID: 32528
		private static readonly IntPtr NativeFieldInfoPtr_Instance;

		// Token: 0x04007F11 RID: 32529
		private static readonly IntPtr NativeMethodInfoPtr_OpenScreen_Public_Virtual_Void_Onward_UI_Screen_0;

		// Token: 0x04007F12 RID: 32530
		private static readonly IntPtr NativeMethodInfoPtr_CloseScreen_Public_Virtual_Void_Onward_UI_Screen_0;

		// Token: 0x04007F13 RID: 32531
		private static readonly IntPtr NativeMethodInfoPtr_SetText_Public_Void_String_0;

		// Token: 0x04007F14 RID: 32532
		private static readonly IntPtr NativeMethodInfoPtr_SetButton_Public_Void_Boolean_String_0;

		// Token: 0x04007F15 RID: 32533
		private static readonly IntPtr NativeMethodInfoPtr_ContinueSelected_Public_Void_0;

		// Token: 0x04007F16 RID: 32534
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
