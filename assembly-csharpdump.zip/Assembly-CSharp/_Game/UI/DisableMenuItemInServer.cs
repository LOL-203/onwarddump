﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI
{
	// Token: 0x0200093C RID: 2364
	public class DisableMenuItemInServer : MonoBehaviour
	{
		// Token: 0x0600C903 RID: 51459 RVA: 0x0031FB00 File Offset: 0x0031DD00
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableMenuItemInServer.NativeMethodInfoPtr_OnEnable_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C904 RID: 51460 RVA: 0x0031FB44 File Offset: 0x0031DD44
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableMenuItemInServer.NativeMethodInfoPtr_OnDisable_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C905 RID: 51461 RVA: 0x0031FB88 File Offset: 0x0031DD88
		[CallerCount(0)]
		public unsafe DisableMenuItemInServer() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DisableMenuItemInServer.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C906 RID: 51462 RVA: 0x0031FBD4 File Offset: 0x0031DDD4
		// Note: this type is marked as 'beforefieldinit'.
		static DisableMenuItemInServer()
		{
			Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI", "DisableMenuItemInServer");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr);
			DisableMenuItemInServer.NativeFieldInfoPtr__menuItemPopout = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr, "_menuItemPopout");
			DisableMenuItemInServer.NativeFieldInfoPtr__originalValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr, "_originalValue");
			DisableMenuItemInServer.NativeMethodInfoPtr_OnEnable_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr, 100678772);
			DisableMenuItemInServer.NativeMethodInfoPtr_OnDisable_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr, 100678773);
			DisableMenuItemInServer.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr, 100678774);
		}

		// Token: 0x0600C907 RID: 51463 RVA: 0x0000210C File Offset: 0x0000030C
		public DisableMenuItemInServer(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700493B RID: 18747
		// (get) Token: 0x0600C908 RID: 51464 RVA: 0x0031FC68 File Offset: 0x0031DE68
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DisableMenuItemInServer>.NativeClassPtr));
			}
		}

		// Token: 0x1700493C RID: 18748
		// (get) Token: 0x0600C909 RID: 51465 RVA: 0x0031FC7C File Offset: 0x0031DE7C
		// (set) Token: 0x0600C90A RID: 51466 RVA: 0x0031FCB0 File Offset: 0x0031DEB0
		public unsafe MenuItemPopout _menuItemPopout
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableMenuItemInServer.NativeFieldInfoPtr__menuItemPopout);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MenuItemPopout(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableMenuItemInServer.NativeFieldInfoPtr__menuItemPopout), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700493D RID: 18749
		// (get) Token: 0x0600C90B RID: 51467 RVA: 0x0031FCD8 File Offset: 0x0031DED8
		// (set) Token: 0x0600C90C RID: 51468 RVA: 0x0031FD00 File Offset: 0x0031DF00
		public unsafe bool _originalValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableMenuItemInServer.NativeFieldInfoPtr__originalValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DisableMenuItemInServer.NativeFieldInfoPtr__originalValue)) = value;
			}
		}

		// Token: 0x04007F06 RID: 32518
		private static readonly IntPtr NativeFieldInfoPtr__menuItemPopout;

		// Token: 0x04007F07 RID: 32519
		private static readonly IntPtr NativeFieldInfoPtr__originalValue;

		// Token: 0x04007F08 RID: 32520
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Public_Void_0;

		// Token: 0x04007F09 RID: 32521
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Public_Void_0;

		// Token: 0x04007F0A RID: 32522
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
