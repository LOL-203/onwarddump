﻿using System;
using Il2CppSystem;
using Onward;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.UI;

namespace _Game.UI
{
	// Token: 0x02000942 RID: 2370
	public class ShaderPreloaderUI : MonoBehaviour
	{
		// Token: 0x0600C96F RID: 51567 RVA: 0x00321520 File Offset: 0x0031F720
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C970 RID: 51568 RVA: 0x00321564 File Offset: 0x0031F764
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr_OnDestroy_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C971 RID: 51569 RVA: 0x003215A8 File Offset: 0x0031F7A8
		[CallerCount(0)]
		public unsafe void Init()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr_Init_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C972 RID: 51570 RVA: 0x003215EC File Offset: 0x0031F7EC
		[CallerCount(0)]
		public unsafe void OnProgressUpdated(float progress)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref progress;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr_OnProgressUpdated_Private_Void_Single_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C973 RID: 51571 RVA: 0x00321640 File Offset: 0x0031F840
		[CallerCount(0)]
		public unsafe ShaderPreloaderUI() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C974 RID: 51572 RVA: 0x0032168C File Offset: 0x0031F88C
		[CallerCount(0)]
		public unsafe void _Init_b__8_0()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ShaderPreloaderUI.NativeMethodInfoPtr__Init_b__8_0_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C975 RID: 51573 RVA: 0x003216D0 File Offset: 0x0031F8D0
		// Note: this type is marked as 'beforefieldinit'.
		static ShaderPreloaderUI()
		{
			Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI", "ShaderPreloaderUI");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr);
			ShaderPreloaderUI.NativeFieldInfoPtr_ShaderPreloader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "ShaderPreloader");
			ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarImage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "ProgressBarImage");
			ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarBackgroundImage = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "ProgressBarBackgroundImage");
			ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeInDuration = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "BackgroundImageFadeInDuration");
			ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeColorTarget = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "BackgroundImageFadeColorTarget");
			ShaderPreloaderUI.NativeFieldInfoPtr__color = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, "_color");
			ShaderPreloaderUI.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678803);
			ShaderPreloaderUI.NativeMethodInfoPtr_OnDestroy_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678804);
			ShaderPreloaderUI.NativeMethodInfoPtr_Init_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678805);
			ShaderPreloaderUI.NativeMethodInfoPtr_OnProgressUpdated_Private_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678806);
			ShaderPreloaderUI.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678807);
			ShaderPreloaderUI.NativeMethodInfoPtr__Init_b__8_0_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr, 100678809);
		}

		// Token: 0x0600C976 RID: 51574 RVA: 0x0000210C File Offset: 0x0000030C
		public ShaderPreloaderUI(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004963 RID: 18787
		// (get) Token: 0x0600C977 RID: 51575 RVA: 0x003217F0 File Offset: 0x0031F9F0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ShaderPreloaderUI>.NativeClassPtr));
			}
		}

		// Token: 0x17004964 RID: 18788
		// (get) Token: 0x0600C978 RID: 51576 RVA: 0x00321804 File Offset: 0x0031FA04
		// (set) Token: 0x0600C979 RID: 51577 RVA: 0x00321838 File Offset: 0x0031FA38
		public unsafe ShaderPreloader ShaderPreloader
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ShaderPreloader);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ShaderPreloader(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ShaderPreloader), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004965 RID: 18789
		// (get) Token: 0x0600C97A RID: 51578 RVA: 0x00321860 File Offset: 0x0031FA60
		// (set) Token: 0x0600C97B RID: 51579 RVA: 0x00321894 File Offset: 0x0031FA94
		public unsafe Image ProgressBarImage
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarImage);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Image(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarImage), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004966 RID: 18790
		// (get) Token: 0x0600C97C RID: 51580 RVA: 0x003218BC File Offset: 0x0031FABC
		// (set) Token: 0x0600C97D RID: 51581 RVA: 0x003218F0 File Offset: 0x0031FAF0
		public unsafe Image ProgressBarBackgroundImage
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarBackgroundImage);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Image(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_ProgressBarBackgroundImage), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004967 RID: 18791
		// (get) Token: 0x0600C97E RID: 51582 RVA: 0x00321918 File Offset: 0x0031FB18
		// (set) Token: 0x0600C97F RID: 51583 RVA: 0x00321940 File Offset: 0x0031FB40
		public unsafe float BackgroundImageFadeInDuration
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeInDuration);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeInDuration)) = value;
			}
		}

		// Token: 0x17004968 RID: 18792
		// (get) Token: 0x0600C980 RID: 51584 RVA: 0x00321964 File Offset: 0x0031FB64
		// (set) Token: 0x0600C981 RID: 51585 RVA: 0x0032198C File Offset: 0x0031FB8C
		public unsafe Color BackgroundImageFadeColorTarget
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeColorTarget);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ShaderPreloaderUI.NativeFieldInfoPtr_BackgroundImageFadeColorTarget)) = value;
			}
		}

		// Token: 0x17004969 RID: 18793
		// (get) Token: 0x0600C982 RID: 51586 RVA: 0x003219B0 File Offset: 0x0031FBB0
		// (set) Token: 0x0600C983 RID: 51587 RVA: 0x003219CE File Offset: 0x0031FBCE
		public unsafe static int _color
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ShaderPreloaderUI.NativeFieldInfoPtr__color, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ShaderPreloaderUI.NativeFieldInfoPtr__color, (void*)(&value));
			}
		}

		// Token: 0x04007F47 RID: 32583
		private static readonly IntPtr NativeFieldInfoPtr_ShaderPreloader;

		// Token: 0x04007F48 RID: 32584
		private static readonly IntPtr NativeFieldInfoPtr_ProgressBarImage;

		// Token: 0x04007F49 RID: 32585
		private static readonly IntPtr NativeFieldInfoPtr_ProgressBarBackgroundImage;

		// Token: 0x04007F4A RID: 32586
		private static readonly IntPtr NativeFieldInfoPtr_BackgroundImageFadeInDuration;

		// Token: 0x04007F4B RID: 32587
		private static readonly IntPtr NativeFieldInfoPtr_BackgroundImageFadeColorTarget;

		// Token: 0x04007F4C RID: 32588
		private static readonly IntPtr NativeFieldInfoPtr__color;

		// Token: 0x04007F4D RID: 32589
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04007F4E RID: 32590
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Private_Void_0;

		// Token: 0x04007F4F RID: 32591
		private static readonly IntPtr NativeMethodInfoPtr_Init_Public_Void_0;

		// Token: 0x04007F50 RID: 32592
		private static readonly IntPtr NativeMethodInfoPtr_OnProgressUpdated_Private_Void_Single_0;

		// Token: 0x04007F51 RID: 32593
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x04007F52 RID: 32594
		private static readonly IntPtr NativeMethodInfoPtr__Init_b__8_0_Private_Void_0;
	}
}
