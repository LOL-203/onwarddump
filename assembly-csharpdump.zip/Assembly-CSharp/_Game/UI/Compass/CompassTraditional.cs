﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI.Compass
{
	// Token: 0x02000949 RID: 2377
	public class CompassTraditional : Compass
	{
		// Token: 0x0600C9ED RID: 51693 RVA: 0x0032338C File Offset: 0x0032158C
		[CallerCount(0)]
		public new unsafe float GetDegrees()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), CompassTraditional.NativeMethodInfoPtr_GetDegrees_Public_Virtual_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C9EE RID: 51694 RVA: 0x003233E8 File Offset: 0x003215E8
		[CallerCount(0)]
		public unsafe bool IsCompassUpsideDown()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CompassTraditional.NativeMethodInfoPtr_IsCompassUpsideDown_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C9EF RID: 51695 RVA: 0x00323438 File Offset: 0x00321638
		[CallerCount(0)]
		public new unsafe void PointNorth()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), CompassTraditional.NativeMethodInfoPtr_PointNorth_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9F0 RID: 51696 RVA: 0x00323488 File Offset: 0x00321688
		[CallerCount(0)]
		public unsafe CompassTraditional() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompassTraditional.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9F1 RID: 51697 RVA: 0x003234D4 File Offset: 0x003216D4
		// Note: this type is marked as 'beforefieldinit'.
		static CompassTraditional()
		{
			Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.Compass", "CompassTraditional");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr);
			CompassTraditional.NativeFieldInfoPtr__compassFace = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, "_compassFace");
			CompassTraditional.NativeFieldInfoPtr__container = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, "_container");
			CompassTraditional.NativeFieldInfoPtr__lerpSpeed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, "_lerpSpeed");
			CompassTraditional.NativeFieldInfoPtr__originalRot = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, "_originalRot");
			CompassTraditional.NativeMethodInfoPtr_GetDegrees_Public_Virtual_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, 100678843);
			CompassTraditional.NativeMethodInfoPtr_IsCompassUpsideDown_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, 100678844);
			CompassTraditional.NativeMethodInfoPtr_PointNorth_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, 100678845);
			CompassTraditional.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr, 100678846);
		}

		// Token: 0x0600C9F2 RID: 51698 RVA: 0x003235A4 File Offset: 0x003217A4
		public CompassTraditional(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700498E RID: 18830
		// (get) Token: 0x0600C9F3 RID: 51699 RVA: 0x003235AD File Offset: 0x003217AD
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CompassTraditional>.NativeClassPtr));
			}
		}

		// Token: 0x1700498F RID: 18831
		// (get) Token: 0x0600C9F4 RID: 51700 RVA: 0x003235C0 File Offset: 0x003217C0
		// (set) Token: 0x0600C9F5 RID: 51701 RVA: 0x003235F4 File Offset: 0x003217F4
		public unsafe Transform _compassFace
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__compassFace);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__compassFace), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004990 RID: 18832
		// (get) Token: 0x0600C9F6 RID: 51702 RVA: 0x0032361C File Offset: 0x0032181C
		// (set) Token: 0x0600C9F7 RID: 51703 RVA: 0x00323650 File Offset: 0x00321850
		public unsafe Transform _container
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__container);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__container), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17004991 RID: 18833
		// (get) Token: 0x0600C9F8 RID: 51704 RVA: 0x00323678 File Offset: 0x00321878
		// (set) Token: 0x0600C9F9 RID: 51705 RVA: 0x003236A0 File Offset: 0x003218A0
		public unsafe float _lerpSpeed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__lerpSpeed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__lerpSpeed)) = value;
			}
		}

		// Token: 0x17004992 RID: 18834
		// (get) Token: 0x0600C9FA RID: 51706 RVA: 0x003236C4 File Offset: 0x003218C4
		// (set) Token: 0x0600C9FB RID: 51707 RVA: 0x003236EC File Offset: 0x003218EC
		public unsafe Quaternion _originalRot
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__originalRot);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassTraditional.NativeFieldInfoPtr__originalRot)) = value;
			}
		}

		// Token: 0x04007F8E RID: 32654
		private static readonly IntPtr NativeFieldInfoPtr__compassFace;

		// Token: 0x04007F8F RID: 32655
		private static readonly IntPtr NativeFieldInfoPtr__container;

		// Token: 0x04007F90 RID: 32656
		private static readonly IntPtr NativeFieldInfoPtr__lerpSpeed;

		// Token: 0x04007F91 RID: 32657
		private static readonly IntPtr NativeFieldInfoPtr__originalRot;

		// Token: 0x04007F92 RID: 32658
		private static readonly IntPtr NativeMethodInfoPtr_GetDegrees_Public_Virtual_Single_0;

		// Token: 0x04007F93 RID: 32659
		private static readonly IntPtr NativeMethodInfoPtr_IsCompassUpsideDown_Private_Boolean_0;

		// Token: 0x04007F94 RID: 32660
		private static readonly IntPtr NativeMethodInfoPtr_PointNorth_Protected_Virtual_Void_0;

		// Token: 0x04007F95 RID: 32661
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
