﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI.Compass
{
	// Token: 0x02000948 RID: 2376
	public class CompassDisplay : MonoBehaviour
	{
		// Token: 0x1700498D RID: 18829
		// (get) Token: 0x0600C9E4 RID: 51684 RVA: 0x00323164 File Offset: 0x00321364
		// (set) Token: 0x0600C9E5 RID: 51685 RVA: 0x003231B4 File Offset: 0x003213B4
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CompassDisplay.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompassDisplay.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600C9E6 RID: 51686 RVA: 0x00323208 File Offset: 0x00321408
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompassDisplay.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9E7 RID: 51687 RVA: 0x0032324C File Offset: 0x0032144C
		[CallerCount(0)]
		public unsafe CompassDisplay() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CompassDisplay.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9E8 RID: 51688 RVA: 0x00323298 File Offset: 0x00321498
		// Note: this type is marked as 'beforefieldinit'.
		static CompassDisplay()
		{
			Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.Compass", "CompassDisplay");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr);
			CompassDisplay.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			CompassDisplay.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr, 100678839);
			CompassDisplay.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr, 100678840);
			CompassDisplay.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr, 100678841);
			CompassDisplay.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr, 100678842);
		}

		// Token: 0x0600C9E9 RID: 51689 RVA: 0x0000210C File Offset: 0x0000030C
		public CompassDisplay(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700498B RID: 18827
		// (get) Token: 0x0600C9EA RID: 51690 RVA: 0x0032332C File Offset: 0x0032152C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CompassDisplay>.NativeClassPtr));
			}
		}

		// Token: 0x1700498C RID: 18828
		// (get) Token: 0x0600C9EB RID: 51691 RVA: 0x00323340 File Offset: 0x00321540
		// (set) Token: 0x0600C9EC RID: 51692 RVA: 0x00323368 File Offset: 0x00321568
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassDisplay.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CompassDisplay.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x04007F89 RID: 32649
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x04007F8A RID: 32650
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x04007F8B RID: 32651
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x04007F8C RID: 32652
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x04007F8D RID: 32653
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
