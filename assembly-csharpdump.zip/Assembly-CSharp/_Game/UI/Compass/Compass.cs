﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace _Game.UI.Compass
{
	// Token: 0x02000947 RID: 2375
	public class Compass : MonoBehaviour
	{
		// Token: 0x1700498A RID: 18826
		// (get) Token: 0x0600C9D5 RID: 51669 RVA: 0x00322D74 File Offset: 0x00320F74
		// (set) Token: 0x0600C9D6 RID: 51670 RVA: 0x00322DC4 File Offset: 0x00320FC4
		public unsafe bool ManagedUpdateRemoval
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x0600C9D7 RID: 51671 RVA: 0x00322E18 File Offset: 0x00321018
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9D8 RID: 51672 RVA: 0x00322E5C File Offset: 0x0032105C
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9D9 RID: 51673 RVA: 0x00322EA0 File Offset: 0x003210A0
		[CallerCount(0)]
		public unsafe void OnManagedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9DA RID: 51674 RVA: 0x00322EE4 File Offset: 0x003210E4
		[CallerCount(0)]
		public unsafe float GetDegrees()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Compass.NativeMethodInfoPtr_GetDegrees_Public_Abstract_Virtual_New_Single_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C9DB RID: 51675 RVA: 0x00322F40 File Offset: 0x00321140
		[CallerCount(0)]
		public unsafe void PointNorth()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), Compass.NativeMethodInfoPtr_PointNorth_Protected_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9DC RID: 51676 RVA: 0x00322F90 File Offset: 0x00321190
		[CallerCount(0)]
		public unsafe Compass() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Compass>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Compass.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600C9DD RID: 51677 RVA: 0x00322FDC File Offset: 0x003211DC
		// Note: this type is marked as 'beforefieldinit'.
		static Compass()
		{
			Il2CppClassPointerStore<Compass>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.UI.Compass", "Compass");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Compass>.NativeClassPtr);
			Compass.NativeFieldInfoPtr__north = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Compass>.NativeClassPtr, "_north");
			Compass.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Compass>.NativeClassPtr, "<ManagedUpdateRemoval>k__BackingField");
			Compass.NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678830);
			Compass.NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678831);
			Compass.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678832);
			Compass.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678833);
			Compass.NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678834);
			Compass.NativeMethodInfoPtr_GetDegrees_Public_Abstract_Virtual_New_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678835);
			Compass.NativeMethodInfoPtr_PointNorth_Protected_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678836);
			Compass.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Compass>.NativeClassPtr, 100678837);
		}

		// Token: 0x0600C9DE RID: 51678 RVA: 0x0000210C File Offset: 0x0000030C
		public Compass(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004987 RID: 18823
		// (get) Token: 0x0600C9DF RID: 51679 RVA: 0x003230D4 File Offset: 0x003212D4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Compass>.NativeClassPtr));
			}
		}

		// Token: 0x17004988 RID: 18824
		// (get) Token: 0x0600C9E0 RID: 51680 RVA: 0x003230E8 File Offset: 0x003212E8
		// (set) Token: 0x0600C9E1 RID: 51681 RVA: 0x00323106 File Offset: 0x00321306
		public unsafe static Vector3 _north
		{
			get
			{
				Vector3 result;
				IL2CPP.il2cpp_field_static_get_value(Compass.NativeFieldInfoPtr__north, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Compass.NativeFieldInfoPtr__north, (void*)(&value));
			}
		}

		// Token: 0x17004989 RID: 18825
		// (get) Token: 0x0600C9E2 RID: 51682 RVA: 0x00323118 File Offset: 0x00321318
		// (set) Token: 0x0600C9E3 RID: 51683 RVA: 0x00323140 File Offset: 0x00321340
		public unsafe bool _ManagedUpdateRemoval_k__BackingField
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Compass.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Compass.NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField)) = value;
			}
		}

		// Token: 0x04007F7F RID: 32639
		private static readonly IntPtr NativeFieldInfoPtr__north;

		// Token: 0x04007F80 RID: 32640
		private static readonly IntPtr NativeFieldInfoPtr__ManagedUpdateRemoval_k__BackingField;

		// Token: 0x04007F81 RID: 32641
		private static readonly IntPtr NativeMethodInfoPtr_get_ManagedUpdateRemoval_Public_Virtual_Final_New_get_Boolean_0;

		// Token: 0x04007F82 RID: 32642
		private static readonly IntPtr NativeMethodInfoPtr_set_ManagedUpdateRemoval_Public_Virtual_Final_New_set_Void_Boolean_0;

		// Token: 0x04007F83 RID: 32643
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04007F84 RID: 32644
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04007F85 RID: 32645
		private static readonly IntPtr NativeMethodInfoPtr_OnManagedUpdate_Public_Virtual_Final_New_Void_0;

		// Token: 0x04007F86 RID: 32646
		private static readonly IntPtr NativeMethodInfoPtr_GetDegrees_Public_Abstract_Virtual_New_Single_0;

		// Token: 0x04007F87 RID: 32647
		private static readonly IntPtr NativeMethodInfoPtr_PointNorth_Protected_Abstract_Virtual_New_Void_0;

		// Token: 0x04007F88 RID: 32648
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
