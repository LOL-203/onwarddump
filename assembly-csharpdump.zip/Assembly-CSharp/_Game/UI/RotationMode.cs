﻿using System;

namespace _Game.UI
{
	// Token: 0x02000941 RID: 2369
	public enum RotationMode
	{
		// Token: 0x04007F44 RID: 32580
		Disabled,
		// Token: 0x04007F45 RID: 32581
		SnapTurn,
		// Token: 0x04007F46 RID: 32582
		SmoothTurn
	}
}
