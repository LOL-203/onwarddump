﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.Utilities
{
	// Token: 0x0200093A RID: 2362
	public static class BoolUtils : Object
	{
		// Token: 0x0600C8F7 RID: 51447 RVA: 0x0031F800 File Offset: 0x0031DA00
		[CallerCount(0)]
		public unsafe static string BoolToStr(bool b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref b;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(BoolUtils.NativeMethodInfoPtr_BoolToStr_Public_Static_String_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600C8F8 RID: 51448 RVA: 0x0031F850 File Offset: 0x0031DA50
		[CallerCount(0)]
		public unsafe static int BoolToInt(bool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoolUtils.NativeMethodInfoPtr_BoolToInt_Public_Static_Int32_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C8F9 RID: 51449 RVA: 0x0031F8A4 File Offset: 0x0031DAA4
		[CallerCount(0)]
		public unsafe static bool NumberStrToBool(string s)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(s);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoolUtils.NativeMethodInfoPtr_NumberStrToBool_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C8FA RID: 51450 RVA: 0x0031F8FC File Offset: 0x0031DAFC
		[CallerCount(0)]
		public unsafe static bool NumberToBool(int num)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref num;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BoolUtils.NativeMethodInfoPtr_NumberToBool_Public_Static_Boolean_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C8FB RID: 51451 RVA: 0x0031F950 File Offset: 0x0031DB50
		// Note: this type is marked as 'beforefieldinit'.
		static BoolUtils()
		{
			Il2CppClassPointerStore<BoolUtils>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Utilities", "BoolUtils");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr);
			BoolUtils.NativeMethodInfoPtr_BoolToStr_Public_Static_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr, 100678766);
			BoolUtils.NativeMethodInfoPtr_BoolToInt_Public_Static_Int32_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr, 100678767);
			BoolUtils.NativeMethodInfoPtr_NumberStrToBool_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr, 100678768);
			BoolUtils.NativeMethodInfoPtr_NumberToBool_Public_Static_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr, 100678769);
		}

		// Token: 0x0600C8FC RID: 51452 RVA: 0x00002988 File Offset: 0x00000B88
		public BoolUtils(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17004939 RID: 18745
		// (get) Token: 0x0600C8FD RID: 51453 RVA: 0x0031F9D0 File Offset: 0x0031DBD0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BoolUtils>.NativeClassPtr));
			}
		}

		// Token: 0x04007F00 RID: 32512
		private static readonly IntPtr NativeMethodInfoPtr_BoolToStr_Public_Static_String_Boolean_0;

		// Token: 0x04007F01 RID: 32513
		private static readonly IntPtr NativeMethodInfoPtr_BoolToInt_Public_Static_Int32_Boolean_0;

		// Token: 0x04007F02 RID: 32514
		private static readonly IntPtr NativeMethodInfoPtr_NumberStrToBool_Public_Static_Boolean_String_0;

		// Token: 0x04007F03 RID: 32515
		private static readonly IntPtr NativeMethodInfoPtr_NumberToBool_Public_Static_Boolean_Int32_0;
	}
}
