﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace _Game.Utilities
{
	// Token: 0x0200093B RID: 2363
	public static class TypeUtilities : Object
	{
		// Token: 0x0600C8FE RID: 51454 RVA: 0x0031F9E4 File Offset: 0x0031DBE4
		[CallerCount(0)]
		public unsafe static int GetHashForType(Type eventType)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(eventType);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(TypeUtilities.NativeMethodInfoPtr_GetHashForType_Public_Static_Int32_Type_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C8FF RID: 51455 RVA: 0x0031FA3C File Offset: 0x0031DC3C
		[CallerCount(0)]
		public unsafe static int GetHashForString(string str)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(str);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(TypeUtilities.NativeMethodInfoPtr_GetHashForString_Public_Static_Int32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600C900 RID: 51456 RVA: 0x0031FA94 File Offset: 0x0031DC94
		// Note: this type is marked as 'beforefieldinit'.
		static TypeUtilities()
		{
			Il2CppClassPointerStore<TypeUtilities>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "_Game.Utilities", "TypeUtilities");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<TypeUtilities>.NativeClassPtr);
			TypeUtilities.NativeMethodInfoPtr_GetHashForType_Public_Static_Int32_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TypeUtilities>.NativeClassPtr, 100678770);
			TypeUtilities.NativeMethodInfoPtr_GetHashForString_Public_Static_Int32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<TypeUtilities>.NativeClassPtr, 100678771);
		}

		// Token: 0x0600C901 RID: 51457 RVA: 0x00002988 File Offset: 0x00000B88
		public TypeUtilities(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700493A RID: 18746
		// (get) Token: 0x0600C902 RID: 51458 RVA: 0x0031FAEC File Offset: 0x0031DCEC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<TypeUtilities>.NativeClassPtr));
			}
		}

		// Token: 0x04007F04 RID: 32516
		private static readonly IntPtr NativeMethodInfoPtr_GetHashForType_Public_Static_Int32_Type_0;

		// Token: 0x04007F05 RID: 32517
		private static readonly IntPtr NativeMethodInfoPtr_GetHashForString_Public_Static_Int32_String_0;
	}
}
