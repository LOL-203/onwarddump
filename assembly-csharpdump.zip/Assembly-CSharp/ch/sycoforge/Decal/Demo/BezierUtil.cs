﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x0200062A RID: 1578
	public static class BezierUtil : Il2CppSystem.Object
	{
		// Token: 0x06008024 RID: 32804 RVA: 0x00205A7C File Offset: 0x00203C7C
		[CallerCount(0)]
		public unsafe static List<Vector3> InterpolatePath(List<Vector3> path, int segments, float radius, float angleThreshold)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(path);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref segments;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref radius;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref angleThreshold;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BezierUtil.NativeMethodInfoPtr_InterpolatePath_Public_Static_List_1_Vector3_List_1_Vector3_Int32_Single_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
		}

		// Token: 0x06008025 RID: 32805 RVA: 0x00205B14 File Offset: 0x00203D14
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<Vector3> GetBezierApproximation(Il2CppStructArray<Vector3> controlPoints, int outputSegmentCount)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(controlPoints);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref outputSegmentCount;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BezierUtil.NativeMethodInfoPtr_GetBezierApproximation_Public_Static_ArrayOf_Vector3_ArrayOf_Vector3_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<Vector3>(intPtr2) : null;
		}

		// Token: 0x06008026 RID: 32806 RVA: 0x00205B88 File Offset: 0x00203D88
		[CallerCount(0)]
		public unsafe static Vector3 GetBezierPoint(float t, Il2CppStructArray<Vector3> controlPoints, int index, int count)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref t;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(controlPoints);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref index;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref count;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BezierUtil.NativeMethodInfoPtr_GetBezierPoint_Public_Static_Vector3_Single_ArrayOf_Vector3_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06008027 RID: 32807 RVA: 0x00205C1C File Offset: 0x00203E1C
		// Note: this type is marked as 'beforefieldinit'.
		static BezierUtil()
		{
			Il2CppClassPointerStore<BezierUtil>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "BezierUtil");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BezierUtil>.NativeClassPtr);
			BezierUtil.NativeMethodInfoPtr_InterpolatePath_Public_Static_List_1_Vector3_List_1_Vector3_Int32_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BezierUtil>.NativeClassPtr, 100673634);
			BezierUtil.NativeMethodInfoPtr_GetBezierApproximation_Public_Static_ArrayOf_Vector3_ArrayOf_Vector3_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BezierUtil>.NativeClassPtr, 100673635);
			BezierUtil.NativeMethodInfoPtr_GetBezierPoint_Public_Static_Vector3_Single_ArrayOf_Vector3_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BezierUtil>.NativeClassPtr, 100673636);
		}

		// Token: 0x06008028 RID: 32808 RVA: 0x00002988 File Offset: 0x00000B88
		public BezierUtil(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DCD RID: 11725
		// (get) Token: 0x06008029 RID: 32809 RVA: 0x00205C88 File Offset: 0x00203E88
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BezierUtil>.NativeClassPtr));
			}
		}

		// Token: 0x0400521F RID: 21023
		private static readonly IntPtr NativeMethodInfoPtr_InterpolatePath_Public_Static_List_1_Vector3_List_1_Vector3_Int32_Single_Single_0;

		// Token: 0x04005220 RID: 21024
		private static readonly IntPtr NativeMethodInfoPtr_GetBezierApproximation_Public_Static_ArrayOf_Vector3_ArrayOf_Vector3_Int32_0;

		// Token: 0x04005221 RID: 21025
		private static readonly IntPtr NativeMethodInfoPtr_GetBezierPoint_Public_Static_Vector3_Single_ArrayOf_Vector3_Int32_Int32_0;
	}
}
