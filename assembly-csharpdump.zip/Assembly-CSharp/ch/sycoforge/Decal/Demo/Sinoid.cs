﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x0200062E RID: 1582
	public class Sinoid : MonoBehaviour
	{
		// Token: 0x06008057 RID: 32855 RVA: 0x00206688 File Offset: 0x00204888
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Sinoid.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008058 RID: 32856 RVA: 0x002066CC File Offset: 0x002048CC
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Sinoid.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008059 RID: 32857 RVA: 0x00206710 File Offset: 0x00204910
		[CallerCount(0)]
		public unsafe Sinoid() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Sinoid>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Sinoid.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600805A RID: 32858 RVA: 0x0020675C File Offset: 0x0020495C
		// Note: this type is marked as 'beforefieldinit'.
		static Sinoid()
		{
			Il2CppClassPointerStore<Sinoid>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "Sinoid");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Sinoid>.NativeClassPtr);
			Sinoid.NativeFieldInfoPtr_AngularVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, "AngularVelocity");
			Sinoid.NativeFieldInfoPtr_SineFreq = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, "SineFreq");
			Sinoid.NativeFieldInfoPtr_Amplitude = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, "Amplitude");
			Sinoid.NativeFieldInfoPtr_accuTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, "accuTime");
			Sinoid.NativeFieldInfoPtr_startPos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, "startPos");
			Sinoid.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, 100673647);
			Sinoid.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, 100673648);
			Sinoid.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Sinoid>.NativeClassPtr, 100673649);
		}

		// Token: 0x0600805B RID: 32859 RVA: 0x0000210C File Offset: 0x0000030C
		public Sinoid(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DDE RID: 11742
		// (get) Token: 0x0600805C RID: 32860 RVA: 0x0020682C File Offset: 0x00204A2C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Sinoid>.NativeClassPtr));
			}
		}

		// Token: 0x17002DDF RID: 11743
		// (get) Token: 0x0600805D RID: 32861 RVA: 0x00206840 File Offset: 0x00204A40
		// (set) Token: 0x0600805E RID: 32862 RVA: 0x00206868 File Offset: 0x00204A68
		public unsafe float AngularVelocity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_AngularVelocity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_AngularVelocity)) = value;
			}
		}

		// Token: 0x17002DE0 RID: 11744
		// (get) Token: 0x0600805F RID: 32863 RVA: 0x0020688C File Offset: 0x00204A8C
		// (set) Token: 0x06008060 RID: 32864 RVA: 0x002068B4 File Offset: 0x00204AB4
		public unsafe float SineFreq
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_SineFreq);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_SineFreq)) = value;
			}
		}

		// Token: 0x17002DE1 RID: 11745
		// (get) Token: 0x06008061 RID: 32865 RVA: 0x002068D8 File Offset: 0x00204AD8
		// (set) Token: 0x06008062 RID: 32866 RVA: 0x00206900 File Offset: 0x00204B00
		public unsafe float Amplitude
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_Amplitude);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_Amplitude)) = value;
			}
		}

		// Token: 0x17002DE2 RID: 11746
		// (get) Token: 0x06008063 RID: 32867 RVA: 0x00206924 File Offset: 0x00204B24
		// (set) Token: 0x06008064 RID: 32868 RVA: 0x0020694C File Offset: 0x00204B4C
		public unsafe float accuTime
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_accuTime);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_accuTime)) = value;
			}
		}

		// Token: 0x17002DE3 RID: 11747
		// (get) Token: 0x06008065 RID: 32869 RVA: 0x00206970 File Offset: 0x00204B70
		// (set) Token: 0x06008066 RID: 32870 RVA: 0x00206998 File Offset: 0x00204B98
		public unsafe Vector3 startPos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_startPos);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(Sinoid.NativeFieldInfoPtr_startPos)) = value;
			}
		}

		// Token: 0x04005239 RID: 21049
		private static readonly IntPtr NativeFieldInfoPtr_AngularVelocity;

		// Token: 0x0400523A RID: 21050
		private static readonly IntPtr NativeFieldInfoPtr_SineFreq;

		// Token: 0x0400523B RID: 21051
		private static readonly IntPtr NativeFieldInfoPtr_Amplitude;

		// Token: 0x0400523C RID: 21052
		private static readonly IntPtr NativeFieldInfoPtr_accuTime;

		// Token: 0x0400523D RID: 21053
		private static readonly IntPtr NativeFieldInfoPtr_startPos;

		// Token: 0x0400523E RID: 21054
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x0400523F RID: 21055
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x04005240 RID: 21056
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
