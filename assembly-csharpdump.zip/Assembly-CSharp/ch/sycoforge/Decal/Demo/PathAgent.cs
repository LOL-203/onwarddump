﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.AI;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x0200062C RID: 1580
	public class PathAgent : MonoBehaviour
	{
		// Token: 0x0600802F RID: 32815 RVA: 0x00205DEC File Offset: 0x00203FEC
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008030 RID: 32816 RVA: 0x00205E30 File Offset: 0x00204030
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008031 RID: 32817 RVA: 0x00205E74 File Offset: 0x00204074
		[CallerCount(0)]
		public unsafe void SetTarget(Ray mouseRay)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref mouseRay;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr_SetTarget_Private_Void_Ray_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008032 RID: 32818 RVA: 0x00205EC8 File Offset: 0x002040C8
		[CallerCount(0)]
		public unsafe void CreatePath(Ray mouseRay)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref mouseRay;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr_CreatePath_Private_Void_Ray_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008033 RID: 32819 RVA: 0x00205F1C File Offset: 0x0020411C
		[CallerCount(0)]
		public unsafe void OnDrawGizmos()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr_OnDrawGizmos_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008034 RID: 32820 RVA: 0x00205F60 File Offset: 0x00204160
		[CallerCount(0)]
		public unsafe PathAgent() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<PathAgent>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(PathAgent.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008035 RID: 32821 RVA: 0x00205FAC File Offset: 0x002041AC
		// Note: this type is marked as 'beforefieldinit'.
		static PathAgent()
		{
			Il2CppClassPointerStore<PathAgent>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "PathAgent");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<PathAgent>.NativeClassPtr);
			PathAgent.NativeFieldInfoPtr_PathThickness = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "PathThickness");
			PathAgent.NativeFieldInfoPtr_NormalPathOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "NormalPathOffset");
			PathAgent.NativeFieldInfoPtr_Radius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "Radius");
			PathAgent.NativeFieldInfoPtr_AngleThreshold = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "AngleThreshold");
			PathAgent.NativeFieldInfoPtr_DrawGizmos = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "DrawGizmos");
			PathAgent.NativeFieldInfoPtr_TargetAimDecal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "TargetAimDecal");
			PathAgent.NativeFieldInfoPtr_TargetPointDecalPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "TargetPointDecalPrefab");
			PathAgent.NativeFieldInfoPtr_path = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "path");
			PathAgent.NativeFieldInfoPtr_agent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "agent");
			PathAgent.NativeFieldInfoPtr_lineRenderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "lineRenderer");
			PathAgent.NativeFieldInfoPtr_decalOffset = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "decalOffset");
			PathAgent.NativeFieldInfoPtr_MAXDISTANCE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, "MAXDISTANCE");
			PathAgent.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673639);
			PathAgent.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673640);
			PathAgent.NativeMethodInfoPtr_SetTarget_Private_Void_Ray_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673641);
			PathAgent.NativeMethodInfoPtr_CreatePath_Private_Void_Ray_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673642);
			PathAgent.NativeMethodInfoPtr_OnDrawGizmos_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673643);
			PathAgent.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<PathAgent>.NativeClassPtr, 100673644);
		}

		// Token: 0x06008036 RID: 32822 RVA: 0x0000210C File Offset: 0x0000030C
		public PathAgent(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DCF RID: 11727
		// (get) Token: 0x06008037 RID: 32823 RVA: 0x00206144 File Offset: 0x00204344
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<PathAgent>.NativeClassPtr));
			}
		}

		// Token: 0x17002DD0 RID: 11728
		// (get) Token: 0x06008038 RID: 32824 RVA: 0x00206158 File Offset: 0x00204358
		// (set) Token: 0x06008039 RID: 32825 RVA: 0x00206180 File Offset: 0x00204380
		public unsafe float PathThickness
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_PathThickness);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_PathThickness)) = value;
			}
		}

		// Token: 0x17002DD1 RID: 11729
		// (get) Token: 0x0600803A RID: 32826 RVA: 0x002061A4 File Offset: 0x002043A4
		// (set) Token: 0x0600803B RID: 32827 RVA: 0x002061CC File Offset: 0x002043CC
		public unsafe float NormalPathOffset
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_NormalPathOffset);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_NormalPathOffset)) = value;
			}
		}

		// Token: 0x17002DD2 RID: 11730
		// (get) Token: 0x0600803C RID: 32828 RVA: 0x002061F0 File Offset: 0x002043F0
		// (set) Token: 0x0600803D RID: 32829 RVA: 0x00206218 File Offset: 0x00204418
		public unsafe float Radius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_Radius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_Radius)) = value;
			}
		}

		// Token: 0x17002DD3 RID: 11731
		// (get) Token: 0x0600803E RID: 32830 RVA: 0x0020623C File Offset: 0x0020443C
		// (set) Token: 0x0600803F RID: 32831 RVA: 0x00206264 File Offset: 0x00204464
		public unsafe float AngleThreshold
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_AngleThreshold);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_AngleThreshold)) = value;
			}
		}

		// Token: 0x17002DD4 RID: 11732
		// (get) Token: 0x06008040 RID: 32832 RVA: 0x00206288 File Offset: 0x00204488
		// (set) Token: 0x06008041 RID: 32833 RVA: 0x002062B0 File Offset: 0x002044B0
		public unsafe bool DrawGizmos
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_DrawGizmos);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_DrawGizmos)) = value;
			}
		}

		// Token: 0x17002DD5 RID: 11733
		// (get) Token: 0x06008042 RID: 32834 RVA: 0x002062D4 File Offset: 0x002044D4
		// (set) Token: 0x06008043 RID: 32835 RVA: 0x00206308 File Offset: 0x00204508
		public unsafe EasyDecal TargetAimDecal
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_TargetAimDecal);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new EasyDecal(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_TargetAimDecal), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DD6 RID: 11734
		// (get) Token: 0x06008044 RID: 32836 RVA: 0x00206330 File Offset: 0x00204530
		// (set) Token: 0x06008045 RID: 32837 RVA: 0x00206364 File Offset: 0x00204564
		public unsafe GameObject TargetPointDecalPrefab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_TargetPointDecalPrefab);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_TargetPointDecalPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DD7 RID: 11735
		// (get) Token: 0x06008046 RID: 32838 RVA: 0x0020638C File Offset: 0x0020458C
		// (set) Token: 0x06008047 RID: 32839 RVA: 0x002063C0 File Offset: 0x002045C0
		public unsafe List<Vector3> path
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_path);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<Vector3>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_path), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DD8 RID: 11736
		// (get) Token: 0x06008048 RID: 32840 RVA: 0x002063E8 File Offset: 0x002045E8
		// (set) Token: 0x06008049 RID: 32841 RVA: 0x0020641C File Offset: 0x0020461C
		public unsafe NavMeshAgent agent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_agent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new NavMeshAgent(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_agent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DD9 RID: 11737
		// (get) Token: 0x0600804A RID: 32842 RVA: 0x00206444 File Offset: 0x00204644
		// (set) Token: 0x0600804B RID: 32843 RVA: 0x00206478 File Offset: 0x00204678
		public unsafe LineRenderer lineRenderer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_lineRenderer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new LineRenderer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_lineRenderer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DDA RID: 11738
		// (get) Token: 0x0600804C RID: 32844 RVA: 0x002064A0 File Offset: 0x002046A0
		// (set) Token: 0x0600804D RID: 32845 RVA: 0x002064C8 File Offset: 0x002046C8
		public unsafe Vector3 decalOffset
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_decalOffset);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(PathAgent.NativeFieldInfoPtr_decalOffset)) = value;
			}
		}

		// Token: 0x17002DDB RID: 11739
		// (get) Token: 0x0600804E RID: 32846 RVA: 0x002064EC File Offset: 0x002046EC
		// (set) Token: 0x0600804F RID: 32847 RVA: 0x0020650A File Offset: 0x0020470A
		public unsafe static int MAXDISTANCE
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(PathAgent.NativeFieldInfoPtr_MAXDISTANCE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(PathAgent.NativeFieldInfoPtr_MAXDISTANCE, (void*)(&value));
			}
		}

		// Token: 0x04005224 RID: 21028
		private static readonly IntPtr NativeFieldInfoPtr_PathThickness;

		// Token: 0x04005225 RID: 21029
		private static readonly IntPtr NativeFieldInfoPtr_NormalPathOffset;

		// Token: 0x04005226 RID: 21030
		private static readonly IntPtr NativeFieldInfoPtr_Radius;

		// Token: 0x04005227 RID: 21031
		private static readonly IntPtr NativeFieldInfoPtr_AngleThreshold;

		// Token: 0x04005228 RID: 21032
		private static readonly IntPtr NativeFieldInfoPtr_DrawGizmos;

		// Token: 0x04005229 RID: 21033
		private static readonly IntPtr NativeFieldInfoPtr_TargetAimDecal;

		// Token: 0x0400522A RID: 21034
		private static readonly IntPtr NativeFieldInfoPtr_TargetPointDecalPrefab;

		// Token: 0x0400522B RID: 21035
		private static readonly IntPtr NativeFieldInfoPtr_path;

		// Token: 0x0400522C RID: 21036
		private static readonly IntPtr NativeFieldInfoPtr_agent;

		// Token: 0x0400522D RID: 21037
		private static readonly IntPtr NativeFieldInfoPtr_lineRenderer;

		// Token: 0x0400522E RID: 21038
		private static readonly IntPtr NativeFieldInfoPtr_decalOffset;

		// Token: 0x0400522F RID: 21039
		private static readonly IntPtr NativeFieldInfoPtr_MAXDISTANCE;

		// Token: 0x04005230 RID: 21040
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04005231 RID: 21041
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x04005232 RID: 21042
		private static readonly IntPtr NativeMethodInfoPtr_SetTarget_Private_Void_Ray_0;

		// Token: 0x04005233 RID: 21043
		private static readonly IntPtr NativeMethodInfoPtr_CreatePath_Private_Void_Ray_0;

		// Token: 0x04005234 RID: 21044
		private static readonly IntPtr NativeMethodInfoPtr_OnDrawGizmos_Private_Void_0;

		// Token: 0x04005235 RID: 21045
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
