﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x0200062D RID: 1581
	public class ProxyRegister : MonoBehaviour
	{
		// Token: 0x06008050 RID: 32848 RVA: 0x0020651C File Offset: 0x0020471C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ProxyRegister.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008051 RID: 32849 RVA: 0x00206560 File Offset: 0x00204760
		[CallerCount(0)]
		public unsafe ProxyRegister() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ProxyRegister.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008052 RID: 32850 RVA: 0x002065AC File Offset: 0x002047AC
		// Note: this type is marked as 'beforefieldinit'.
		static ProxyRegister()
		{
			Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "ProxyRegister");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr);
			ProxyRegister.NativeFieldInfoPtr_ProxyCollection = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr, "ProxyCollection");
			ProxyRegister.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr, 100673645);
			ProxyRegister.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr, 100673646);
		}

		// Token: 0x06008053 RID: 32851 RVA: 0x0000210C File Offset: 0x0000030C
		public ProxyRegister(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DDC RID: 11740
		// (get) Token: 0x06008054 RID: 32852 RVA: 0x00206618 File Offset: 0x00204818
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ProxyRegister>.NativeClassPtr));
			}
		}

		// Token: 0x17002DDD RID: 11741
		// (get) Token: 0x06008055 RID: 32853 RVA: 0x0020662C File Offset: 0x0020482C
		// (set) Token: 0x06008056 RID: 32854 RVA: 0x00206660 File Offset: 0x00204860
		public unsafe StaticProxyCollection ProxyCollection
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ProxyRegister.NativeFieldInfoPtr_ProxyCollection);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new StaticProxyCollection(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ProxyRegister.NativeFieldInfoPtr_ProxyCollection), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04005236 RID: 21046
		private static readonly IntPtr NativeFieldInfoPtr_ProxyCollection;

		// Token: 0x04005237 RID: 21047
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04005238 RID: 21048
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
