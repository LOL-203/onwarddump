﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000629 RID: 1577
	public class BasicBulletHoles : MonoBehaviour
	{
		// Token: 0x0600801A RID: 32794 RVA: 0x00205858 File Offset: 0x00203A58
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasicBulletHoles.NativeMethodInfoPtr_Start_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600801B RID: 32795 RVA: 0x0020589C File Offset: 0x00203A9C
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasicBulletHoles.NativeMethodInfoPtr_Update_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600801C RID: 32796 RVA: 0x002058E0 File Offset: 0x00203AE0
		[CallerCount(0)]
		public unsafe BasicBulletHoles() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BasicBulletHoles.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600801D RID: 32797 RVA: 0x0020592C File Offset: 0x00203B2C
		// Note: this type is marked as 'beforefieldinit'.
		static BasicBulletHoles()
		{
			Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "BasicBulletHoles");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr);
			BasicBulletHoles.NativeFieldInfoPtr_DecalPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr, "DecalPrefab");
			BasicBulletHoles.NativeFieldInfoPtr_t = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr, "t");
			BasicBulletHoles.NativeMethodInfoPtr_Start_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr, 100673631);
			BasicBulletHoles.NativeMethodInfoPtr_Update_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr, 100673632);
			BasicBulletHoles.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr, 100673633);
		}

		// Token: 0x0600801E RID: 32798 RVA: 0x0000210C File Offset: 0x0000030C
		public BasicBulletHoles(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DCA RID: 11722
		// (get) Token: 0x0600801F RID: 32799 RVA: 0x002059C0 File Offset: 0x00203BC0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BasicBulletHoles>.NativeClassPtr));
			}
		}

		// Token: 0x17002DCB RID: 11723
		// (get) Token: 0x06008020 RID: 32800 RVA: 0x002059D4 File Offset: 0x00203BD4
		// (set) Token: 0x06008021 RID: 32801 RVA: 0x00205A08 File Offset: 0x00203C08
		public unsafe EasyDecal DecalPrefab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasicBulletHoles.NativeFieldInfoPtr_DecalPrefab);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new EasyDecal(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasicBulletHoles.NativeFieldInfoPtr_DecalPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DCC RID: 11724
		// (get) Token: 0x06008022 RID: 32802 RVA: 0x00205A30 File Offset: 0x00203C30
		// (set) Token: 0x06008023 RID: 32803 RVA: 0x00205A58 File Offset: 0x00203C58
		public unsafe bool t
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasicBulletHoles.NativeFieldInfoPtr_t);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(BasicBulletHoles.NativeFieldInfoPtr_t)) = value;
			}
		}

		// Token: 0x0400521A RID: 21018
		private static readonly IntPtr NativeFieldInfoPtr_DecalPrefab;

		// Token: 0x0400521B RID: 21019
		private static readonly IntPtr NativeFieldInfoPtr_t;

		// Token: 0x0400521C RID: 21020
		private static readonly IntPtr NativeMethodInfoPtr_Start_Public_Void_0;

		// Token: 0x0400521D RID: 21021
		private static readonly IntPtr NativeMethodInfoPtr_Update_Public_Void_0;

		// Token: 0x0400521E RID: 21022
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
