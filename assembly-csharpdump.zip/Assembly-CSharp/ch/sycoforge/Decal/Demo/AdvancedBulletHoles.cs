﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000628 RID: 1576
	public class AdvancedBulletHoles : MonoBehaviour
	{
		// Token: 0x0600800E RID: 32782 RVA: 0x002055C4 File Offset: 0x002037C4
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AdvancedBulletHoles.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600800F RID: 32783 RVA: 0x00205608 File Offset: 0x00203808
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AdvancedBulletHoles.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008010 RID: 32784 RVA: 0x0020564C File Offset: 0x0020384C
		[CallerCount(0)]
		public unsafe AdvancedBulletHoles() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AdvancedBulletHoles.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06008011 RID: 32785 RVA: 0x00205698 File Offset: 0x00203898
		// Note: this type is marked as 'beforefieldinit'.
		static AdvancedBulletHoles()
		{
			Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "AdvancedBulletHoles");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr);
			AdvancedBulletHoles.NativeFieldInfoPtr_DecalPrefab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, "DecalPrefab");
			AdvancedBulletHoles.NativeFieldInfoPtr_ImpactParticles = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, "ImpactParticles");
			AdvancedBulletHoles.NativeFieldInfoPtr_CastRadius = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, "CastRadius");
			AdvancedBulletHoles.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, 100673628);
			AdvancedBulletHoles.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, 100673629);
			AdvancedBulletHoles.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr, 100673630);
		}

		// Token: 0x06008012 RID: 32786 RVA: 0x0000210C File Offset: 0x0000030C
		public AdvancedBulletHoles(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DC6 RID: 11718
		// (get) Token: 0x06008013 RID: 32787 RVA: 0x00205740 File Offset: 0x00203940
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AdvancedBulletHoles>.NativeClassPtr));
			}
		}

		// Token: 0x17002DC7 RID: 11719
		// (get) Token: 0x06008014 RID: 32788 RVA: 0x00205754 File Offset: 0x00203954
		// (set) Token: 0x06008015 RID: 32789 RVA: 0x00205788 File Offset: 0x00203988
		public unsafe EasyDecal DecalPrefab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_DecalPrefab);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new EasyDecal(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_DecalPrefab), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DC8 RID: 11720
		// (get) Token: 0x06008016 RID: 32790 RVA: 0x002057B0 File Offset: 0x002039B0
		// (set) Token: 0x06008017 RID: 32791 RVA: 0x002057E4 File Offset: 0x002039E4
		public unsafe GameObject ImpactParticles
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_ImpactParticles);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_ImpactParticles), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17002DC9 RID: 11721
		// (get) Token: 0x06008018 RID: 32792 RVA: 0x0020580C File Offset: 0x00203A0C
		// (set) Token: 0x06008019 RID: 32793 RVA: 0x00205834 File Offset: 0x00203A34
		public unsafe float CastRadius
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_CastRadius);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AdvancedBulletHoles.NativeFieldInfoPtr_CastRadius)) = value;
			}
		}

		// Token: 0x04005214 RID: 21012
		private static readonly IntPtr NativeFieldInfoPtr_DecalPrefab;

		// Token: 0x04005215 RID: 21013
		private static readonly IntPtr NativeFieldInfoPtr_ImpactParticles;

		// Token: 0x04005216 RID: 21014
		private static readonly IntPtr NativeFieldInfoPtr_CastRadius;

		// Token: 0x04005217 RID: 21015
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04005218 RID: 21016
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x04005219 RID: 21017
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
