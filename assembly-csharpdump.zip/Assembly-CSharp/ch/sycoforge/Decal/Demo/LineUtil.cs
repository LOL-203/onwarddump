﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x0200062B RID: 1579
	public static class LineUtil : Il2CppSystem.Object
	{
		// Token: 0x0600802A RID: 32810 RVA: 0x00205C9C File Offset: 0x00203E9C
		[CallerCount(0)]
		public unsafe static void DrawPath(float thickness, Material material, List<Vector3> path)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref thickness;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(material);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(path);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LineUtil.NativeMethodInfoPtr_DrawPath_Public_Static_Void_Single_Material_List_1_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600802B RID: 32811 RVA: 0x00205D14 File Offset: 0x00203F14
		[CallerCount(0)]
		public unsafe static void DrawLine(float thickness, Vector3 start, Vector3 end)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref thickness;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref start;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref end;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(LineUtil.NativeMethodInfoPtr_DrawLine_Private_Static_Void_Single_Vector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600802C RID: 32812 RVA: 0x00205D80 File Offset: 0x00203F80
		// Note: this type is marked as 'beforefieldinit'.
		static LineUtil()
		{
			Il2CppClassPointerStore<LineUtil>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "ch.sycoforge.Decal.Demo", "LineUtil");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<LineUtil>.NativeClassPtr);
			LineUtil.NativeMethodInfoPtr_DrawPath_Public_Static_Void_Single_Material_List_1_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LineUtil>.NativeClassPtr, 100673637);
			LineUtil.NativeMethodInfoPtr_DrawLine_Private_Static_Void_Single_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<LineUtil>.NativeClassPtr, 100673638);
		}

		// Token: 0x0600802D RID: 32813 RVA: 0x00002988 File Offset: 0x00000B88
		public LineUtil(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17002DCE RID: 11726
		// (get) Token: 0x0600802E RID: 32814 RVA: 0x00205DD8 File Offset: 0x00203FD8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<LineUtil>.NativeClassPtr));
			}
		}

		// Token: 0x04005222 RID: 21026
		private static readonly IntPtr NativeMethodInfoPtr_DrawPath_Public_Static_Void_Single_Material_List_1_Vector3_0;

		// Token: 0x04005223 RID: 21027
		private static readonly IntPtr NativeMethodInfoPtr_DrawLine_Private_Static_Void_Single_Vector3_Vector3_0;
	}
}
