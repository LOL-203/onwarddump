﻿using System;
using Il2CppSystem;
using RealisticEyeMovements;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004C0 RID: 1216
public class DistanceOptimizer : MonoBehaviour
{
	// Token: 0x060061EC RID: 25068 RVA: 0x0018876C File Offset: 0x0018696C
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DistanceOptimizer.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060061ED RID: 25069 RVA: 0x001887B0 File Offset: 0x001869B0
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DistanceOptimizer.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060061EE RID: 25070 RVA: 0x001887F4 File Offset: 0x001869F4
	[CallerCount(0)]
	public unsafe DistanceOptimizer() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DistanceOptimizer.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060061EF RID: 25071 RVA: 0x00188840 File Offset: 0x00186A40
	// Note: this type is marked as 'beforefieldinit'.
	static DistanceOptimizer()
	{
		Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DistanceOptimizer");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr);
		DistanceOptimizer.NativeFieldInfoPtr_EyeRef = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, "EyeRef");
		DistanceOptimizer.NativeFieldInfoPtr_LookTargetRef = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, "LookTargetRef");
		DistanceOptimizer.NativeFieldInfoPtr_InRange = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, "InRange");
		DistanceOptimizer.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, 100671072);
		DistanceOptimizer.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, 100671073);
		DistanceOptimizer.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr, 100671074);
	}

	// Token: 0x060061F0 RID: 25072 RVA: 0x0000210C File Offset: 0x0000030C
	public DistanceOptimizer(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170022CD RID: 8909
	// (get) Token: 0x060061F1 RID: 25073 RVA: 0x001888E8 File Offset: 0x00186AE8
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DistanceOptimizer>.NativeClassPtr));
		}
	}

	// Token: 0x170022CE RID: 8910
	// (get) Token: 0x060061F2 RID: 25074 RVA: 0x001888FC File Offset: 0x00186AFC
	// (set) Token: 0x060061F3 RID: 25075 RVA: 0x00188930 File Offset: 0x00186B30
	public unsafe EyeAndHeadAnimator EyeRef
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_EyeRef);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EyeAndHeadAnimator(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_EyeRef), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170022CF RID: 8911
	// (get) Token: 0x060061F4 RID: 25076 RVA: 0x00188958 File Offset: 0x00186B58
	// (set) Token: 0x060061F5 RID: 25077 RVA: 0x0018898C File Offset: 0x00186B8C
	public unsafe LookTargetController LookTargetRef
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_LookTargetRef);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new LookTargetController(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_LookTargetRef), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170022D0 RID: 8912
	// (get) Token: 0x060061F6 RID: 25078 RVA: 0x001889B4 File Offset: 0x00186BB4
	// (set) Token: 0x060061F7 RID: 25079 RVA: 0x001889DC File Offset: 0x00186BDC
	public unsafe bool InRange
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_InRange);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DistanceOptimizer.NativeFieldInfoPtr_InRange)) = value;
		}
	}

	// Token: 0x04003DDE RID: 15838
	private static readonly IntPtr NativeFieldInfoPtr_EyeRef;

	// Token: 0x04003DDF RID: 15839
	private static readonly IntPtr NativeFieldInfoPtr_LookTargetRef;

	// Token: 0x04003DE0 RID: 15840
	private static readonly IntPtr NativeFieldInfoPtr_InRange;

	// Token: 0x04003DE1 RID: 15841
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x04003DE2 RID: 15842
	private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

	// Token: 0x04003DE3 RID: 15843
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
