﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x020004F5 RID: 1269
public class DamageFalloffData : ScriptableObject
{
	// Token: 0x06006745 RID: 26437 RVA: 0x0019E970 File Offset: 0x0019CB70
	[CallerCount(0)]
	public unsafe void OnValidate()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageFalloffData.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006746 RID: 26438 RVA: 0x0019E9B4 File Offset: 0x0019CBB4
	[CallerCount(0)]
	public unsafe DamageFalloffData() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageFalloffData.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006747 RID: 26439 RVA: 0x0019EA00 File Offset: 0x0019CC00
	// Note: this type is marked as 'beforefieldinit'.
	static DamageFalloffData()
	{
		Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "DamageFalloffData");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr);
		DamageFalloffData.NativeFieldInfoPtr_Curves = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr, "Curves");
		DamageFalloffData.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr, 100671499);
		DamageFalloffData.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr, 100671500);
	}

	// Token: 0x06006748 RID: 26440 RVA: 0x0002DD3C File Offset: 0x0002BF3C
	public DamageFalloffData(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170024AB RID: 9387
	// (get) Token: 0x06006749 RID: 26441 RVA: 0x0019EA6C File Offset: 0x0019CC6C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr));
		}
	}

	// Token: 0x170024AC RID: 9388
	// (get) Token: 0x0600674A RID: 26442 RVA: 0x0019EA80 File Offset: 0x0019CC80
	// (set) Token: 0x0600674B RID: 26443 RVA: 0x0019EAB4 File Offset: 0x0019CCB4
	public unsafe List<DamageFalloffData.DamageCurve> Curves
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.NativeFieldInfoPtr_Curves);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<DamageFalloffData.DamageCurve>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.NativeFieldInfoPtr_Curves), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04004130 RID: 16688
	private static readonly IntPtr NativeFieldInfoPtr_Curves;

	// Token: 0x04004131 RID: 16689
	private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

	// Token: 0x04004132 RID: 16690
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x020004F6 RID: 1270
	[Serializable]
	public class DamageCurve : Il2CppSystem.Object
	{
		// Token: 0x0600674C RID: 26444 RVA: 0x0019EADC File Offset: 0x0019CCDC
		[CallerCount(0)]
		public unsafe DamageCurve() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DamageFalloffData.DamageCurve.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600674D RID: 26445 RVA: 0x0019EB28 File Offset: 0x0019CD28
		// Note: this type is marked as 'beforefieldinit'.
		static DamageCurve()
		{
			Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DamageFalloffData>.NativeClassPtr, "DamageCurve");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr);
			DamageFalloffData.DamageCurve.NativeFieldInfoPtr_ElementName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr, "ElementName");
			DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Ammo = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr, "Ammo");
			DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Curve = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr, "Curve");
			DamageFalloffData.DamageCurve.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr, 100671501);
		}

		// Token: 0x0600674E RID: 26446 RVA: 0x00002988 File Offset: 0x00000B88
		public DamageCurve(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170024AD RID: 9389
		// (get) Token: 0x0600674F RID: 26447 RVA: 0x0019EBA3 File Offset: 0x0019CDA3
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DamageFalloffData.DamageCurve>.NativeClassPtr));
			}
		}

		// Token: 0x170024AE RID: 9390
		// (get) Token: 0x06006750 RID: 26448 RVA: 0x0019EBB4 File Offset: 0x0019CDB4
		// (set) Token: 0x06006751 RID: 26449 RVA: 0x0019EBDD File Offset: 0x0019CDDD
		public unsafe string ElementName
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_ElementName);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_ElementName), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170024AF RID: 9391
		// (get) Token: 0x06006752 RID: 26450 RVA: 0x0019EC04 File Offset: 0x0019CE04
		// (set) Token: 0x06006753 RID: 26451 RVA: 0x0019EC2C File Offset: 0x0019CE2C
		public unsafe ClassLoadout.AmmoType Ammo
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Ammo);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Ammo)) = value;
			}
		}

		// Token: 0x170024B0 RID: 9392
		// (get) Token: 0x06006754 RID: 26452 RVA: 0x0019EC50 File Offset: 0x0019CE50
		// (set) Token: 0x06006755 RID: 26453 RVA: 0x0019EC84 File Offset: 0x0019CE84
		public unsafe AnimationCurve Curve
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Curve);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new AnimationCurve(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DamageFalloffData.DamageCurve.NativeFieldInfoPtr_Curve), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04004133 RID: 16691
		private static readonly IntPtr NativeFieldInfoPtr_ElementName;

		// Token: 0x04004134 RID: 16692
		private static readonly IntPtr NativeFieldInfoPtr_Ammo;

		// Token: 0x04004135 RID: 16693
		private static readonly IntPtr NativeFieldInfoPtr_Curve;

		// Token: 0x04004136 RID: 16694
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
