﻿using System;
using System.Runtime.InteropServices;
using DPI.Networking;
using DPI.Networking.IO;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using Onward.CustomContent.Assets;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200032F RID: 815
public class AmmoBoxManager : MonoBehaviourDPINetworking
{
	// Token: 0x170016AE RID: 5806
	// (get) Token: 0x0600401D RID: 16413 RVA: 0x00102F50 File Offset: 0x00101150
	// (set) Token: 0x0600401E RID: 16414 RVA: 0x00102F98 File Offset: 0x00101198
	public unsafe static AmmoBoxManager Singleton
	{
		[CallerCount(0)]
		get
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_get_Singleton_Public_Static_get_AmmoBoxManager_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new AmmoBoxManager(intPtr2) : null;
		}
		[CallerCount(0)]
		set
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_AmmoBoxManager_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}
	}

	// Token: 0x0600401F RID: 16415 RVA: 0x00102FE4 File Offset: 0x001011E4
	[CallerCount(0)]
	public unsafe void OnEnable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004020 RID: 16416 RVA: 0x00103028 File Offset: 0x00101228
	[CallerCount(0)]
	public unsafe void OnDisable()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004021 RID: 16417 RVA: 0x0010306C File Offset: 0x0010126C
	[CallerCount(0)]
	public unsafe void HolsterPickup(Pickup pickup, PickupHolster holster)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(pickup);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(holster);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_HolsterPickup_Public_Void_Pickup_PickupHolster_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004022 RID: 16418 RVA: 0x001030E0 File Offset: 0x001012E0
	[CallerCount(0)]
	public unsafe void SpawnAmmoBoxes()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004023 RID: 16419 RVA: 0x00103124 File Offset: 0x00101324
	[CallerCount(0)]
	public unsafe void SpawnAmmoBoxes(Il2CppReferenceArray<AmmoBox> boxSpawnPoints)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(boxSpawnPoints);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_ArrayOf_AmmoBox_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004024 RID: 16420 RVA: 0x00103180 File Offset: 0x00101380
	[CallerCount(0)]
	public unsafe void RPC_HolsterPickup(int holsterIndex, int pickupViewID, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref holsterIndex;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pickupViewID;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_Int32_Int32_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004025 RID: 16421 RVA: 0x00103204 File Offset: 0x00101404
	[CallerCount(0)]
	public unsafe void ResetAllBoxes()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_ResetAllBoxes_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004026 RID: 16422 RVA: 0x00103248 File Offset: 0x00101448
	[CallerCount(0)]
	public unsafe void Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInInUnique_DPINetworkMessageInfo_0(AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique tmp, DPINetworkMessageInfo info)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref tmp;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(info));
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInInUnique_DPINetworkMessageInfo_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004027 RID: 16423 RVA: 0x001032BC File Offset: 0x001014BC
	[CallerCount(0)]
	public unsafe void RPC_HolsterPickup(Il2CppReferenceArray<DPIPlayer> invokeRpcPlayerTargets, int holsterIndex, int pickupViewID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTargets);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref holsterIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pickupViewID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_ArrayOf_DPIPlayer_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004028 RID: 16424 RVA: 0x0010333C File Offset: 0x0010153C
	[CallerCount(0)]
	public unsafe void RPC_HolsterPickup(DPIPlayer invokeRpcPlayerTarget, int holsterIndex, int pickupViewID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(invokeRpcPlayerTarget);
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref holsterIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pickupViewID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_DPIPlayer_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06004029 RID: 16425 RVA: 0x001033BC File Offset: 0x001015BC
	[CallerCount(0)]
	public unsafe void RPC_HolsterPickup(RpcTarget invokeRpcTarget, int holsterIndex, int pickupViewID)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref invokeRpcTarget;
		ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref holsterIndex;
		ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref pickupViewID;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_RpcTarget_Int32_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600402A RID: 16426 RVA: 0x00103438 File Offset: 0x00101638
	[CallerCount(0)]
	public new unsafe void OnCodeGenInitializeHook()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), AmmoBoxManager.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600402B RID: 16427 RVA: 0x00103488 File Offset: 0x00101688
	[CallerCount(0)]
	public unsafe AmmoBoxManager() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x0600402C RID: 16428 RVA: 0x001034D4 File Offset: 0x001016D4
	// Note: this type is marked as 'beforefieldinit'.
	static AmmoBoxManager()
	{
		Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "AmmoBoxManager");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr);
		AmmoBoxManager.NativeFieldInfoPtr_singleton = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, "singleton");
		AmmoBoxManager.NativeFieldInfoPtr_AmmoBoxes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, "AmmoBoxes");
		AmmoBoxManager.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInInUnique_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, "Δδδ_H_RPC_HolsterPickup");
		AmmoBoxManager.NativeMethodInfoPtr_get_Singleton_Public_Static_get_AmmoBoxManager_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668436);
		AmmoBoxManager.NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_AmmoBoxManager_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668437);
		AmmoBoxManager.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668438);
		AmmoBoxManager.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668439);
		AmmoBoxManager.NativeMethodInfoPtr_HolsterPickup_Public_Void_Pickup_PickupHolster_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668440);
		AmmoBoxManager.NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668441);
		AmmoBoxManager.NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_ArrayOf_AmmoBox_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668442);
		AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_Int32_Int32_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668443);
		AmmoBoxManager.NativeMethodInfoPtr_ResetAllBoxes_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668444);
		AmmoBoxManager.NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInInUnique_DPINetworkMessageInfo_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668445);
		AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_ArrayOf_DPIPlayer_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668446);
		AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_DPIPlayer_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668447);
		AmmoBoxManager.NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_RpcTarget_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668448);
		AmmoBoxManager.NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668449);
		AmmoBoxManager.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, 100668450);
	}

	// Token: 0x0600402D RID: 16429 RVA: 0x00047530 File Offset: 0x00045730
	public AmmoBoxManager(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x170016AA RID: 5802
	// (get) Token: 0x0600402E RID: 16430 RVA: 0x0010366C File Offset: 0x0010186C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr));
		}
	}

	// Token: 0x170016AB RID: 5803
	// (get) Token: 0x0600402F RID: 16431 RVA: 0x00103680 File Offset: 0x00101880
	// (set) Token: 0x06004030 RID: 16432 RVA: 0x001036AB File Offset: 0x001018AB
	public unsafe static AmmoBoxManager singleton
	{
		get
		{
			IntPtr intPtr;
			IL2CPP.il2cpp_field_static_get_value(AmmoBoxManager.NativeFieldInfoPtr_singleton, (void*)(&intPtr));
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new AmmoBoxManager(intPtr2) : null;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(AmmoBoxManager.NativeFieldInfoPtr_singleton, IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016AC RID: 5804
	// (get) Token: 0x06004031 RID: 16433 RVA: 0x001036C0 File Offset: 0x001018C0
	// (set) Token: 0x06004032 RID: 16434 RVA: 0x001036F4 File Offset: 0x001018F4
	public unsafe List<AmmoRefill> AmmoBoxes
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmmoBoxManager.NativeFieldInfoPtr_AmmoBoxes);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new List<AmmoRefill>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmmoBoxManager.NativeFieldInfoPtr_AmmoBoxes), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x170016AD RID: 5805
	// (get) Token: 0x06004033 RID: 16435 RVA: 0x0010371C File Offset: 0x0010191C
	// (set) Token: 0x06004034 RID: 16436 RVA: 0x00103750 File Offset: 0x00101950
	public unsafe EntityClientRpcHandle<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique> field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInInUnique_0
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmmoBoxManager.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInInUnique_0);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EntityClientRpcHandle<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(AmmoBoxManager.NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInInUnique_0), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x04002937 RID: 10551
	private static readonly IntPtr NativeFieldInfoPtr_singleton;

	// Token: 0x04002938 RID: 10552
	private static readonly IntPtr NativeFieldInfoPtr_AmmoBoxes;

	// Token: 0x04002939 RID: 10553
	private static readonly IntPtr NativeFieldInfoPtr_field_Private_EntityClientRpcHandle_1_ValueTypeNPrivateSealedINetworkStreamableInInUnique_0;

	// Token: 0x0400293A RID: 10554
	private static readonly IntPtr NativeMethodInfoPtr_get_Singleton_Public_Static_get_AmmoBoxManager_0;

	// Token: 0x0400293B RID: 10555
	private static readonly IntPtr NativeMethodInfoPtr_set_Singleton_Private_Static_set_Void_AmmoBoxManager_0;

	// Token: 0x0400293C RID: 10556
	private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

	// Token: 0x0400293D RID: 10557
	private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

	// Token: 0x0400293E RID: 10558
	private static readonly IntPtr NativeMethodInfoPtr_HolsterPickup_Public_Void_Pickup_PickupHolster_0;

	// Token: 0x0400293F RID: 10559
	private static readonly IntPtr NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_0;

	// Token: 0x04002940 RID: 10560
	private static readonly IntPtr NativeMethodInfoPtr_SpawnAmmoBoxes_Public_Void_ArrayOf_AmmoBox_0;

	// Token: 0x04002941 RID: 10561
	private static readonly IntPtr NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_Int32_Int32_DPINetworkMessageInfo_0;

	// Token: 0x04002942 RID: 10562
	private static readonly IntPtr NativeMethodInfoPtr_ResetAllBoxes_Public_Void_0;

	// Token: 0x04002943 RID: 10563
	private static readonly IntPtr NativeMethodInfoPtr_Method_Private_Void_ValueTypeNPrivateSealedINetworkStreamableInInUnique_DPINetworkMessageInfo_0;

	// Token: 0x04002944 RID: 10564
	private static readonly IntPtr NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_ArrayOf_DPIPlayer_Int32_Int32_0;

	// Token: 0x04002945 RID: 10565
	private static readonly IntPtr NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_DPIPlayer_Int32_Int32_0;

	// Token: 0x04002946 RID: 10566
	private static readonly IntPtr NativeMethodInfoPtr_RPC_HolsterPickup_Public_Void_RpcTarget_Int32_Int32_0;

	// Token: 0x04002947 RID: 10567
	private static readonly IntPtr NativeMethodInfoPtr_OnCodeGenInitializeHook_Public_Virtual_Void_0;

	// Token: 0x04002948 RID: 10568
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

	// Token: 0x02000330 RID: 816
	[ObfuscatedName("AmmoBoxManager/Δδδ_S_RPC_HolsterPickup")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealedINetworkStreamableInInUnique
	{
		// Token: 0x06004035 RID: 16437 RVA: 0x00103778 File Offset: 0x00101978
		[CallerCount(0)]
		public unsafe void Read(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004036 RID: 16438 RVA: 0x001037C4 File Offset: 0x001019C4
		[CallerCount(0)]
		public unsafe void Write(DPINetworkStream networkStream)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(networkStream);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06004037 RID: 16439 RVA: 0x00103810 File Offset: 0x00101A10
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealedINetworkStreamableInInUnique()
		{
			Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<AmmoBoxManager>.NativeClassPtr, "Δδδ_S_RPC_HolsterPickup");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr);
			AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeFieldInfoPtr_field_Public_Int32_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr, "Δδδ_I_holsterIndex");
			AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeFieldInfoPtr_field_Public_Int32_1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr, "Δδδ_I_pickupViewID");
			AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr, 100668451);
			AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique.NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr, 100668452);
		}

		// Token: 0x06004038 RID: 16440 RVA: 0x0010388B File Offset: 0x00101A8B
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr, ref this));
		}

		// Token: 0x170016AF RID: 5807
		// (get) Token: 0x06004039 RID: 16441 RVA: 0x0010389D File Offset: 0x00101A9D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<AmmoBoxManager.ValueTypeNPrivateSealedINetworkStreamableInInUnique>.NativeClassPtr));
			}
		}

		// Token: 0x04002949 RID: 10569
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Int32_0;

		// Token: 0x0400294A RID: 10570
		private static readonly IntPtr NativeFieldInfoPtr_field_Public_Int32_1;

		// Token: 0x0400294B RID: 10571
		private static readonly IntPtr NativeMethodInfoPtr_Read_Public_Virtual_Final_New_Void_DPINetworkStream_0;

		// Token: 0x0400294C RID: 10572
		private static readonly IntPtr NativeMethodInfoPtr_Write_Public_Virtual_Final_New_Void_DPINetworkStream_0;

		// Token: 0x0400294D RID: 10573
		[FieldOffset(0)]
		public int field_Public_Int32_0;

		// Token: 0x0400294E RID: 10574
		[FieldOffset(4)]
		public int field_Public_Int32_1;
	}
}
