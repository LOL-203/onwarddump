﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000176 RID: 374
public class CameraRigGuardian : MonoBehaviour
{
	// Token: 0x060018D4 RID: 6356 RVA: 0x000634D0 File Offset: 0x000616D0
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_Start_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018D5 RID: 6357 RVA: 0x00063514 File Offset: 0x00061714
	[CallerCount(0)]
	public unsafe void OnApplicationFocus(bool focus)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref focus;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_OnApplicationFocus_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018D6 RID: 6358 RVA: 0x00063568 File Offset: 0x00061768
	[CallerCount(0)]
	public unsafe void OnApplicationPause(bool pause)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = ref pause;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_OnApplicationPause_Protected_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018D7 RID: 6359 RVA: 0x000635BC File Offset: 0x000617BC
	[CallerCount(0)]
	public unsafe void Update()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_Update_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018D8 RID: 6360 RVA: 0x00063600 File Offset: 0x00061800
	[CallerCount(0)]
	public unsafe bool CanCheckCameraRig()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_CanCheckCameraRig_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060018D9 RID: 6361 RVA: 0x00063650 File Offset: 0x00061850
	[CallerCount(0)]
	public unsafe bool IsCameraRigStuck()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr obj = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_IsCameraRigStuck_Protected_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
		return *IL2CPP.il2cpp_object_unbox(obj);
	}

	// Token: 0x060018DA RID: 6362 RVA: 0x000636A0 File Offset: 0x000618A0
	[CallerCount(0)]
	public unsafe void ResetScans()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_ResetScans_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018DB RID: 6363 RVA: 0x000636E4 File Offset: 0x000618E4
	[CallerCount(0)]
	public unsafe void ResolveStuck()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_ResolveStuck_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018DC RID: 6364 RVA: 0x00063728 File Offset: 0x00061928
	[CallerCount(0)]
	public unsafe void ReturnToMenu()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr_ReturnToMenu_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018DD RID: 6365 RVA: 0x0006376C File Offset: 0x0006196C
	[CallerCount(0)]
	public unsafe CameraRigGuardian() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CameraRigGuardian.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x060018DE RID: 6366 RVA: 0x000637B8 File Offset: 0x000619B8
	// Note: this type is marked as 'beforefieldinit'.
	static CameraRigGuardian()
	{
		Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CameraRigGuardian");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr);
		CameraRigGuardian.NativeFieldInfoPtr_SlowScanTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "SlowScanTime");
		CameraRigGuardian.NativeFieldInfoPtr_FastScanFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "FastScanFrames");
		CameraRigGuardian.NativeFieldInfoPtr_ResetFrames = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "ResetFrames");
		CameraRigGuardian.NativeFieldInfoPtr_MaximumDeltaTime = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "MaximumDeltaTime");
		CameraRigGuardian.NativeFieldInfoPtr_slowScanTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "slowScanTimer");
		CameraRigGuardian.NativeFieldInfoPtr_fastScanTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "fastScanTimer");
		CameraRigGuardian.NativeFieldInfoPtr_resetTimer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "resetTimer");
		CameraRigGuardian.NativeFieldInfoPtr_paused = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "paused");
		CameraRigGuardian.NativeFieldInfoPtr_focused = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, "focused");
		CameraRigGuardian.NativeMethodInfoPtr_Start_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665288);
		CameraRigGuardian.NativeMethodInfoPtr_OnApplicationFocus_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665289);
		CameraRigGuardian.NativeMethodInfoPtr_OnApplicationPause_Protected_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665290);
		CameraRigGuardian.NativeMethodInfoPtr_Update_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665291);
		CameraRigGuardian.NativeMethodInfoPtr_CanCheckCameraRig_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665292);
		CameraRigGuardian.NativeMethodInfoPtr_IsCameraRigStuck_Protected_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665293);
		CameraRigGuardian.NativeMethodInfoPtr_ResetScans_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665294);
		CameraRigGuardian.NativeMethodInfoPtr_ResolveStuck_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665295);
		CameraRigGuardian.NativeMethodInfoPtr_ReturnToMenu_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665296);
		CameraRigGuardian.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr, 100665297);
	}

	// Token: 0x060018DF RID: 6367 RVA: 0x0000210C File Offset: 0x0000030C
	public CameraRigGuardian(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000892 RID: 2194
	// (get) Token: 0x060018E0 RID: 6368 RVA: 0x00063964 File Offset: 0x00061B64
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CameraRigGuardian>.NativeClassPtr));
		}
	}

	// Token: 0x17000893 RID: 2195
	// (get) Token: 0x060018E1 RID: 6369 RVA: 0x00063978 File Offset: 0x00061B78
	// (set) Token: 0x060018E2 RID: 6370 RVA: 0x000639A0 File Offset: 0x00061BA0
	public unsafe float SlowScanTime
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_SlowScanTime);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_SlowScanTime)) = value;
		}
	}

	// Token: 0x17000894 RID: 2196
	// (get) Token: 0x060018E3 RID: 6371 RVA: 0x000639C4 File Offset: 0x00061BC4
	// (set) Token: 0x060018E4 RID: 6372 RVA: 0x000639EC File Offset: 0x00061BEC
	public unsafe int FastScanFrames
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_FastScanFrames);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_FastScanFrames)) = value;
		}
	}

	// Token: 0x17000895 RID: 2197
	// (get) Token: 0x060018E5 RID: 6373 RVA: 0x00063A10 File Offset: 0x00061C10
	// (set) Token: 0x060018E6 RID: 6374 RVA: 0x00063A38 File Offset: 0x00061C38
	public unsafe int ResetFrames
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_ResetFrames);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_ResetFrames)) = value;
		}
	}

	// Token: 0x17000896 RID: 2198
	// (get) Token: 0x060018E7 RID: 6375 RVA: 0x00063A5C File Offset: 0x00061C5C
	// (set) Token: 0x060018E8 RID: 6376 RVA: 0x00063A84 File Offset: 0x00061C84
	public unsafe float MaximumDeltaTime
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_MaximumDeltaTime);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_MaximumDeltaTime)) = value;
		}
	}

	// Token: 0x17000897 RID: 2199
	// (get) Token: 0x060018E9 RID: 6377 RVA: 0x00063AA8 File Offset: 0x00061CA8
	// (set) Token: 0x060018EA RID: 6378 RVA: 0x00063AD0 File Offset: 0x00061CD0
	public unsafe float slowScanTimer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_slowScanTimer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_slowScanTimer)) = value;
		}
	}

	// Token: 0x17000898 RID: 2200
	// (get) Token: 0x060018EB RID: 6379 RVA: 0x00063AF4 File Offset: 0x00061CF4
	// (set) Token: 0x060018EC RID: 6380 RVA: 0x00063B1C File Offset: 0x00061D1C
	public unsafe int fastScanTimer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_fastScanTimer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_fastScanTimer)) = value;
		}
	}

	// Token: 0x17000899 RID: 2201
	// (get) Token: 0x060018ED RID: 6381 RVA: 0x00063B40 File Offset: 0x00061D40
	// (set) Token: 0x060018EE RID: 6382 RVA: 0x00063B68 File Offset: 0x00061D68
	public unsafe int resetTimer
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_resetTimer);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_resetTimer)) = value;
		}
	}

	// Token: 0x1700089A RID: 2202
	// (get) Token: 0x060018EF RID: 6383 RVA: 0x00063B8C File Offset: 0x00061D8C
	// (set) Token: 0x060018F0 RID: 6384 RVA: 0x00063BB4 File Offset: 0x00061DB4
	public unsafe bool paused
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_paused);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_paused)) = value;
		}
	}

	// Token: 0x1700089B RID: 2203
	// (get) Token: 0x060018F1 RID: 6385 RVA: 0x00063BD8 File Offset: 0x00061DD8
	// (set) Token: 0x060018F2 RID: 6386 RVA: 0x00063C00 File Offset: 0x00061E00
	public unsafe bool focused
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_focused);
			return *intPtr;
		}
		set
		{
			*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CameraRigGuardian.NativeFieldInfoPtr_focused)) = value;
		}
	}

	// Token: 0x04001002 RID: 4098
	private static readonly IntPtr NativeFieldInfoPtr_SlowScanTime;

	// Token: 0x04001003 RID: 4099
	private static readonly IntPtr NativeFieldInfoPtr_FastScanFrames;

	// Token: 0x04001004 RID: 4100
	private static readonly IntPtr NativeFieldInfoPtr_ResetFrames;

	// Token: 0x04001005 RID: 4101
	private static readonly IntPtr NativeFieldInfoPtr_MaximumDeltaTime;

	// Token: 0x04001006 RID: 4102
	private static readonly IntPtr NativeFieldInfoPtr_slowScanTimer;

	// Token: 0x04001007 RID: 4103
	private static readonly IntPtr NativeFieldInfoPtr_fastScanTimer;

	// Token: 0x04001008 RID: 4104
	private static readonly IntPtr NativeFieldInfoPtr_resetTimer;

	// Token: 0x04001009 RID: 4105
	private static readonly IntPtr NativeFieldInfoPtr_paused;

	// Token: 0x0400100A RID: 4106
	private static readonly IntPtr NativeFieldInfoPtr_focused;

	// Token: 0x0400100B RID: 4107
	private static readonly IntPtr NativeMethodInfoPtr_Start_Protected_Void_0;

	// Token: 0x0400100C RID: 4108
	private static readonly IntPtr NativeMethodInfoPtr_OnApplicationFocus_Protected_Void_Boolean_0;

	// Token: 0x0400100D RID: 4109
	private static readonly IntPtr NativeMethodInfoPtr_OnApplicationPause_Protected_Void_Boolean_0;

	// Token: 0x0400100E RID: 4110
	private static readonly IntPtr NativeMethodInfoPtr_Update_Protected_Void_0;

	// Token: 0x0400100F RID: 4111
	private static readonly IntPtr NativeMethodInfoPtr_CanCheckCameraRig_Protected_Boolean_0;

	// Token: 0x04001010 RID: 4112
	private static readonly IntPtr NativeMethodInfoPtr_IsCameraRigStuck_Protected_Boolean_0;

	// Token: 0x04001011 RID: 4113
	private static readonly IntPtr NativeMethodInfoPtr_ResetScans_Protected_Void_0;

	// Token: 0x04001012 RID: 4114
	private static readonly IntPtr NativeMethodInfoPtr_ResolveStuck_Protected_Void_0;

	// Token: 0x04001013 RID: 4115
	private static readonly IntPtr NativeMethodInfoPtr_ReturnToMenu_Private_Void_0;

	// Token: 0x04001014 RID: 4116
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
