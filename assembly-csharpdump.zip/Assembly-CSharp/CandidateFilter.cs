﻿using System;
using ch.sycoforge.Decal;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000562 RID: 1378
public class CandidateFilter : MonoBehaviour
{
	// Token: 0x06006F85 RID: 28549 RVA: 0x001C07DC File Offset: 0x001BE9DC
	[CallerCount(0)]
	public unsafe void Start()
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CandidateFilter.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006F86 RID: 28550 RVA: 0x001C0820 File Offset: 0x001BEA20
	[CallerCount(0)]
	public unsafe void bp_OnCandidatesProcessed(List<Collider> colliders)
	{
		IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
		IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
		*ptr = IL2CPP.Il2CppObjectBaseToPtr(colliders);
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CandidateFilter.NativeMethodInfoPtr_bp_OnCandidatesProcessed_Private_Void_List_1_Collider_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006F87 RID: 28551 RVA: 0x001C087C File Offset: 0x001BEA7C
	[CallerCount(0)]
	public unsafe CandidateFilter() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(CandidateFilter.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06006F88 RID: 28552 RVA: 0x001C08C8 File Offset: 0x001BEAC8
	// Note: this type is marked as 'beforefieldinit'.
	static CandidateFilter()
	{
		Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "CandidateFilter");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr);
		CandidateFilter.NativeFieldInfoPtr_ExclusiveReceiver = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr, "ExclusiveReceiver");
		CandidateFilter.NativeFieldInfoPtr_decal = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr, "decal");
		CandidateFilter.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr, 100672150);
		CandidateFilter.NativeMethodInfoPtr_bp_OnCandidatesProcessed_Private_Void_List_1_Collider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr, 100672151);
		CandidateFilter.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr, 100672152);
	}

	// Token: 0x06006F89 RID: 28553 RVA: 0x0000210C File Offset: 0x0000030C
	public CandidateFilter(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17002797 RID: 10135
	// (get) Token: 0x06006F8A RID: 28554 RVA: 0x001C095C File Offset: 0x001BEB5C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<CandidateFilter>.NativeClassPtr));
		}
	}

	// Token: 0x17002798 RID: 10136
	// (get) Token: 0x06006F8B RID: 28555 RVA: 0x001C0970 File Offset: 0x001BEB70
	// (set) Token: 0x06006F8C RID: 28556 RVA: 0x001C09A4 File Offset: 0x001BEBA4
	public unsafe GameObject ExclusiveReceiver
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CandidateFilter.NativeFieldInfoPtr_ExclusiveReceiver);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CandidateFilter.NativeFieldInfoPtr_ExclusiveReceiver), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x17002799 RID: 10137
	// (get) Token: 0x06006F8D RID: 28557 RVA: 0x001C09CC File Offset: 0x001BEBCC
	// (set) Token: 0x06006F8E RID: 28558 RVA: 0x001C0A00 File Offset: 0x001BEC00
	public unsafe EasyDecal decal
	{
		get
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(CandidateFilter.NativeFieldInfoPtr_decal);
			IntPtr intPtr2 = *intPtr;
			return (intPtr2 != 0) ? new EasyDecal(intPtr2) : null;
		}
		set
		{
			IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(CandidateFilter.NativeFieldInfoPtr_decal), IL2CPP.Il2CppObjectBaseToPtr(value));
		}
	}

	// Token: 0x0400473C RID: 18236
	private static readonly IntPtr NativeFieldInfoPtr_ExclusiveReceiver;

	// Token: 0x0400473D RID: 18237
	private static readonly IntPtr NativeFieldInfoPtr_decal;

	// Token: 0x0400473E RID: 18238
	private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

	// Token: 0x0400473F RID: 18239
	private static readonly IntPtr NativeMethodInfoPtr_bp_OnCandidatesProcessed_Private_Void_List_1_Collider_0;

	// Token: 0x04004740 RID: 18240
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
