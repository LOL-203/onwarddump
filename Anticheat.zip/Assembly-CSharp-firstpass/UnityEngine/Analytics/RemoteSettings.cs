﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace UnityEngine.Analytics
{
	// Token: 0x0200000B RID: 11
	public class RemoteSettings : MonoBehaviour
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600005F RID: 95 RVA: 0x000038C8 File Offset: 0x00001AC8
		// (set) Token: 0x06000060 RID: 96 RVA: 0x00003920 File Offset: 0x00001B20
		public unsafe DriveableProperty DP
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RemoteSettings.NativeMethodInfoPtr_get_DP_Internal_get_DriveableProperty_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new DriveableProperty(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RemoteSettings.NativeMethodInfoPtr_set_DP_Internal_set_Void_DriveableProperty_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000397C File Offset: 0x00001B7C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RemoteSettings.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000062 RID: 98 RVA: 0x000039C0 File Offset: 0x00001BC0
		[CallerCount(0)]
		public unsafe void RemoteSettingsUpdated()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RemoteSettings.NativeMethodInfoPtr_RemoteSettingsUpdated_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00003A04 File Offset: 0x00001C04
		[CallerCount(0)]
		public unsafe RemoteSettings() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(RemoteSettings.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00003A50 File Offset: 0x00001C50
		// Note: this type is marked as 'beforefieldinit'.
		static RemoteSettings()
		{
			Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "UnityEngine.Analytics", "RemoteSettings");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr);
			RemoteSettings.NativeFieldInfoPtr_m_DriveableProperty = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, "m_DriveableProperty");
			RemoteSettings.NativeMethodInfoPtr_get_DP_Internal_get_DriveableProperty_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, 100663339);
			RemoteSettings.NativeMethodInfoPtr_set_DP_Internal_set_Void_DriveableProperty_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, 100663340);
			RemoteSettings.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, 100663341);
			RemoteSettings.NativeMethodInfoPtr_RemoteSettingsUpdated_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, 100663342);
			RemoteSettings.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr, 100663343);
		}

		// Token: 0x06000065 RID: 101 RVA: 0x000022CC File Offset: 0x000004CC
		public RemoteSettings(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000066 RID: 102 RVA: 0x00003AF8 File Offset: 0x00001CF8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<RemoteSettings>.NativeClassPtr));
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000067 RID: 103 RVA: 0x00003B0C File Offset: 0x00001D0C
		// (set) Token: 0x06000068 RID: 104 RVA: 0x00003B40 File Offset: 0x00001D40
		public unsafe DriveableProperty m_DriveableProperty
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(RemoteSettings.NativeFieldInfoPtr_m_DriveableProperty);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new DriveableProperty(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(RemoteSettings.NativeFieldInfoPtr_m_DriveableProperty), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000045 RID: 69
		private static readonly IntPtr NativeFieldInfoPtr_m_DriveableProperty;

		// Token: 0x04000046 RID: 70
		private static readonly IntPtr NativeMethodInfoPtr_get_DP_Internal_get_DriveableProperty_0;

		// Token: 0x04000047 RID: 71
		private static readonly IntPtr NativeMethodInfoPtr_set_DP_Internal_set_Void_DriveableProperty_0;

		// Token: 0x04000048 RID: 72
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04000049 RID: 73
		private static readonly IntPtr NativeMethodInfoPtr_RemoteSettingsUpdated_Private_Void_0;

		// Token: 0x0400004A RID: 74
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
