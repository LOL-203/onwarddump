﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections.Generic;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace UnityEngine.Analytics
{
	// Token: 0x02000009 RID: 9
	[Serializable]
	public class DriveableProperty : Object
	{
		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00003078 File Offset: 0x00001278
		// (set) Token: 0x06000042 RID: 66 RVA: 0x000030D0 File Offset: 0x000012D0
		public unsafe List<DriveableProperty.FieldWithRemoteSettingsKey> fields
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.NativeMethodInfoPtr_get_fields_Public_get_List_1_FieldWithRemoteSettingsKey_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new List<DriveableProperty.FieldWithRemoteSettingsKey>(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.NativeMethodInfoPtr_set_fields_Public_set_Void_List_1_FieldWithRemoteSettingsKey_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06000043 RID: 67 RVA: 0x0000312C File Offset: 0x0000132C
		[CallerCount(0)]
		public unsafe DriveableProperty() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00003178 File Offset: 0x00001378
		// Note: this type is marked as 'beforefieldinit'.
		static DriveableProperty()
		{
			Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "UnityEngine.Analytics", "DriveableProperty");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr);
			DriveableProperty.NativeFieldInfoPtr_m_Fields = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr, "m_Fields");
			DriveableProperty.NativeMethodInfoPtr_get_fields_Public_get_List_1_FieldWithRemoteSettingsKey_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr, 100663325);
			DriveableProperty.NativeMethodInfoPtr_set_fields_Public_set_Void_List_1_FieldWithRemoteSettingsKey_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr, 100663326);
			DriveableProperty.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr, 100663327);
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00002580 File Offset: 0x00000780
		public DriveableProperty(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000046 RID: 70 RVA: 0x000031F8 File Offset: 0x000013F8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr));
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000047 RID: 71 RVA: 0x0000320C File Offset: 0x0000140C
		// (set) Token: 0x06000048 RID: 72 RVA: 0x00003240 File Offset: 0x00001440
		public unsafe List<DriveableProperty.FieldWithRemoteSettingsKey> m_Fields
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.NativeFieldInfoPtr_m_Fields);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new List<DriveableProperty.FieldWithRemoteSettingsKey>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.NativeFieldInfoPtr_m_Fields), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000032 RID: 50
		private static readonly IntPtr NativeFieldInfoPtr_m_Fields;

		// Token: 0x04000033 RID: 51
		private static readonly IntPtr NativeMethodInfoPtr_get_fields_Public_get_List_1_FieldWithRemoteSettingsKey_0;

		// Token: 0x04000034 RID: 52
		private static readonly IntPtr NativeMethodInfoPtr_set_fields_Public_set_Void_List_1_FieldWithRemoteSettingsKey_0;

		// Token: 0x04000035 RID: 53
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x0200000A RID: 10
		[Serializable]
		public class FieldWithRemoteSettingsKey : Object
		{
			// Token: 0x1700001C RID: 28
			// (get) Token: 0x06000049 RID: 73 RVA: 0x00003268 File Offset: 0x00001468
			// (set) Token: 0x0600004A RID: 74 RVA: 0x000032C0 File Offset: 0x000014C0
			public unsafe Object target
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_target_Public_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Object(intPtr2) : null;
				}
				[CallerCount(0)]
				set
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
					*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_target_Public_set_Void_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}
			}

			// Token: 0x1700001D RID: 29
			// (get) Token: 0x0600004B RID: 75 RVA: 0x0000331C File Offset: 0x0000151C
			// (set) Token: 0x0600004C RID: 76 RVA: 0x00003368 File Offset: 0x00001568
			public unsafe string fieldPath
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_fieldPath_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return IL2CPP.Il2CppStringToManaged(il2CppString);
				}
				[CallerCount(0)]
				set
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
					*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_fieldPath_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}
			}

			// Token: 0x1700001E RID: 30
			// (get) Token: 0x0600004D RID: 77 RVA: 0x000033C4 File Offset: 0x000015C4
			// (set) Token: 0x0600004E RID: 78 RVA: 0x00003410 File Offset: 0x00001610
			public unsafe string rsKeyName
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_rsKeyName_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return IL2CPP.Il2CppStringToManaged(il2CppString);
				}
				[CallerCount(0)]
				set
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
					*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_rsKeyName_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}
			}

			// Token: 0x1700001F RID: 31
			// (get) Token: 0x0600004F RID: 79 RVA: 0x0000346C File Offset: 0x0000166C
			// (set) Token: 0x06000050 RID: 80 RVA: 0x000034B8 File Offset: 0x000016B8
			public unsafe string type
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_type_Public_get_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					return IL2CPP.Il2CppStringToManaged(il2CppString);
				}
				[CallerCount(0)]
				set
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
					*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_type_Public_set_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
				}
			}

			// Token: 0x06000051 RID: 81 RVA: 0x00003514 File Offset: 0x00001714
			[CallerCount(0)]
			public unsafe void SetValue(Object val)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(val);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_SetValue_Public_Void_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000052 RID: 82 RVA: 0x00003570 File Offset: 0x00001770
			[CallerCount(0)]
			public unsafe Type GetTypeOfField()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_GetTypeOfField_Public_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Type(intPtr2) : null;
			}

			// Token: 0x06000053 RID: 83 RVA: 0x000035C8 File Offset: 0x000017C8
			[CallerCount(0)]
			public unsafe FieldWithRemoteSettingsKey() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000054 RID: 84 RVA: 0x00003614 File Offset: 0x00001814
			// Note: this type is marked as 'beforefieldinit'.
			static FieldWithRemoteSettingsKey()
			{
				Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<DriveableProperty>.NativeClassPtr, "FieldWithRemoteSettingsKey");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, "m_Target");
				DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_FieldPath = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, "m_FieldPath");
				DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_RSKeyName = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, "m_RSKeyName");
				DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Type = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, "m_Type");
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_target_Public_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663328);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_target_Public_set_Void_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663329);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_fieldPath_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663330);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_fieldPath_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663331);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_rsKeyName_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663332);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_rsKeyName_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663333);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_get_type_Public_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663334);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_set_type_Public_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663335);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_SetValue_Public_Void_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663336);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr_GetTypeOfField_Public_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663337);
				DriveableProperty.FieldWithRemoteSettingsKey.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr, 100663338);
			}

			// Token: 0x06000055 RID: 85 RVA: 0x00002580 File Offset: 0x00000780
			public FieldWithRemoteSettingsKey(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17000017 RID: 23
			// (get) Token: 0x06000056 RID: 86 RVA: 0x0000376B File Offset: 0x0000196B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<DriveableProperty.FieldWithRemoteSettingsKey>.NativeClassPtr));
				}
			}

			// Token: 0x17000018 RID: 24
			// (get) Token: 0x06000057 RID: 87 RVA: 0x0000377C File Offset: 0x0000197C
			// (set) Token: 0x06000058 RID: 88 RVA: 0x000037B0 File Offset: 0x000019B0
			public unsafe Object m_Target
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Target);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Target), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17000019 RID: 25
			// (get) Token: 0x06000059 RID: 89 RVA: 0x000037D8 File Offset: 0x000019D8
			// (set) Token: 0x0600005A RID: 90 RVA: 0x00003801 File Offset: 0x00001A01
			public unsafe string m_FieldPath
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_FieldPath);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_FieldPath), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x1700001A RID: 26
			// (get) Token: 0x0600005B RID: 91 RVA: 0x00003828 File Offset: 0x00001A28
			// (set) Token: 0x0600005C RID: 92 RVA: 0x00003851 File Offset: 0x00001A51
			public unsafe string m_RSKeyName
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_RSKeyName);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_RSKeyName), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x1700001B RID: 27
			// (get) Token: 0x0600005D RID: 93 RVA: 0x00003878 File Offset: 0x00001A78
			// (set) Token: 0x0600005E RID: 94 RVA: 0x000038A1 File Offset: 0x00001AA1
			public unsafe string m_Type
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Type);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(DriveableProperty.FieldWithRemoteSettingsKey.NativeFieldInfoPtr_m_Type), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x04000036 RID: 54
			private static readonly IntPtr NativeFieldInfoPtr_m_Target;

			// Token: 0x04000037 RID: 55
			private static readonly IntPtr NativeFieldInfoPtr_m_FieldPath;

			// Token: 0x04000038 RID: 56
			private static readonly IntPtr NativeFieldInfoPtr_m_RSKeyName;

			// Token: 0x04000039 RID: 57
			private static readonly IntPtr NativeFieldInfoPtr_m_Type;

			// Token: 0x0400003A RID: 58
			private static readonly IntPtr NativeMethodInfoPtr_get_target_Public_get_Object_0;

			// Token: 0x0400003B RID: 59
			private static readonly IntPtr NativeMethodInfoPtr_set_target_Public_set_Void_Object_0;

			// Token: 0x0400003C RID: 60
			private static readonly IntPtr NativeMethodInfoPtr_get_fieldPath_Public_get_String_0;

			// Token: 0x0400003D RID: 61
			private static readonly IntPtr NativeMethodInfoPtr_set_fieldPath_Public_set_Void_String_0;

			// Token: 0x0400003E RID: 62
			private static readonly IntPtr NativeMethodInfoPtr_get_rsKeyName_Public_get_String_0;

			// Token: 0x0400003F RID: 63
			private static readonly IntPtr NativeMethodInfoPtr_set_rsKeyName_Public_set_Void_String_0;

			// Token: 0x04000040 RID: 64
			private static readonly IntPtr NativeMethodInfoPtr_get_type_Public_get_String_0;

			// Token: 0x04000041 RID: 65
			private static readonly IntPtr NativeMethodInfoPtr_set_type_Public_set_Void_String_0;

			// Token: 0x04000042 RID: 66
			private static readonly IntPtr NativeMethodInfoPtr_SetValue_Public_Void_Object_0;

			// Token: 0x04000043 RID: 67
			private static readonly IntPtr NativeMethodInfoPtr_GetTypeOfField_Public_Type_0;

			// Token: 0x04000044 RID: 68
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
		}
	}
}
