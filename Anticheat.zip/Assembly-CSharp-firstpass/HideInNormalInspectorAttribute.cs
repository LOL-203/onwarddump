﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class HideInNormalInspectorAttribute : PropertyAttribute
{
	// Token: 0x06000004 RID: 4 RVA: 0x00002088 File Offset: 0x00000288
	[CallerCount(0)]
	public unsafe HideInNormalInspectorAttribute() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HideInNormalInspectorAttribute>.NativeClassPtr))
	{
		IntPtr* param = null;
		IntPtr returnedException;
		IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HideInNormalInspectorAttribute.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
		Il2CppException.RaiseExceptionIfNecessary(returnedException);
	}

	// Token: 0x06000005 RID: 5 RVA: 0x000020D3 File Offset: 0x000002D3
	// Note: this type is marked as 'beforefieldinit'.
	static HideInNormalInspectorAttribute()
	{
		Il2CppClassPointerStore<HideInNormalInspectorAttribute>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "", "HideInNormalInspectorAttribute");
		IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HideInNormalInspectorAttribute>.NativeClassPtr);
		HideInNormalInspectorAttribute.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HideInNormalInspectorAttribute>.NativeClassPtr, 100663297);
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0000210C File Offset: 0x0000030C
	public HideInNormalInspectorAttribute(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000007 RID: 7 RVA: 0x00002115 File Offset: 0x00000315
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HideInNormalInspectorAttribute>.NativeClassPtr));
		}
	}

	// Token: 0x04000001 RID: 1
	private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
}
