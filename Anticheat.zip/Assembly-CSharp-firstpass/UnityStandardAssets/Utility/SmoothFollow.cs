﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace UnityStandardAssets.Utility
{
	// Token: 0x02000004 RID: 4
	public class SmoothFollow : MonoBehaviour
	{
		// Token: 0x06000008 RID: 8 RVA: 0x00002128 File Offset: 0x00000328
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SmoothFollow.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000009 RID: 9 RVA: 0x0000216C File Offset: 0x0000036C
		[CallerCount(0)]
		public unsafe void LateUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SmoothFollow.NativeMethodInfoPtr_LateUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000021B0 File Offset: 0x000003B0
		[CallerCount(0)]
		public unsafe SmoothFollow() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SmoothFollow.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000021FC File Offset: 0x000003FC
		// Note: this type is marked as 'beforefieldinit'.
		static SmoothFollow()
		{
			Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "UnityStandardAssets.Utility", "SmoothFollow");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr);
			SmoothFollow.NativeFieldInfoPtr_target = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, "target");
			SmoothFollow.NativeFieldInfoPtr_distance = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, "distance");
			SmoothFollow.NativeFieldInfoPtr_height = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, "height");
			SmoothFollow.NativeFieldInfoPtr_rotationDamping = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, "rotationDamping");
			SmoothFollow.NativeFieldInfoPtr_heightDamping = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, "heightDamping");
			SmoothFollow.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, 100663298);
			SmoothFollow.NativeMethodInfoPtr_LateUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, 100663299);
			SmoothFollow.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr, 100663300);
		}

		// Token: 0x0600000C RID: 12 RVA: 0x000022CC File Offset: 0x000004CC
		public SmoothFollow(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000D RID: 13 RVA: 0x000022D5 File Offset: 0x000004D5
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SmoothFollow>.NativeClassPtr));
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600000E RID: 14 RVA: 0x000022E8 File Offset: 0x000004E8
		// (set) Token: 0x0600000F RID: 15 RVA: 0x0000231C File Offset: 0x0000051C
		public unsafe Transform target
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_target);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Transform(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_target), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000010 RID: 16 RVA: 0x00002344 File Offset: 0x00000544
		// (set) Token: 0x06000011 RID: 17 RVA: 0x0000236C File Offset: 0x0000056C
		public unsafe float distance
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_distance);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_distance)) = value;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000012 RID: 18 RVA: 0x00002390 File Offset: 0x00000590
		// (set) Token: 0x06000013 RID: 19 RVA: 0x000023B8 File Offset: 0x000005B8
		public unsafe float height
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_height);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_height)) = value;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000014 RID: 20 RVA: 0x000023DC File Offset: 0x000005DC
		// (set) Token: 0x06000015 RID: 21 RVA: 0x00002404 File Offset: 0x00000604
		public unsafe float rotationDamping
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_rotationDamping);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_rotationDamping)) = value;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000016 RID: 22 RVA: 0x00002428 File Offset: 0x00000628
		// (set) Token: 0x06000017 RID: 23 RVA: 0x00002450 File Offset: 0x00000650
		public unsafe float heightDamping
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_heightDamping);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SmoothFollow.NativeFieldInfoPtr_heightDamping)) = value;
			}
		}

		// Token: 0x04000002 RID: 2
		private static readonly IntPtr NativeFieldInfoPtr_target;

		// Token: 0x04000003 RID: 3
		private static readonly IntPtr NativeFieldInfoPtr_distance;

		// Token: 0x04000004 RID: 4
		private static readonly IntPtr NativeFieldInfoPtr_height;

		// Token: 0x04000005 RID: 5
		private static readonly IntPtr NativeFieldInfoPtr_rotationDamping;

		// Token: 0x04000006 RID: 6
		private static readonly IntPtr NativeFieldInfoPtr_heightDamping;

		// Token: 0x04000007 RID: 7
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04000008 RID: 8
		private static readonly IntPtr NativeMethodInfoPtr_LateUpdate_Private_Void_0;

		// Token: 0x04000009 RID: 9
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
