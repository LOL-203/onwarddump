﻿using System;
using System.Reflection;

[assembly: AssemblyAlgorithmId(0)]
[assembly: AssemblyVersion("0.0.0.0")]
