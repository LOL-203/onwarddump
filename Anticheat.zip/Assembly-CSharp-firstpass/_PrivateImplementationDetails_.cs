﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

// Token: 0x0200003B RID: 59
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x06000599 RID: 1433 RVA: 0x0001C71D File Offset: 0x0001A91D
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C");
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x00002580 File Offset: 0x00000780
	public _PrivateImplementationDetails_(IntPtr A_1) : base(A_1)
	{
	}

	// Token: 0x17000156 RID: 342
	// (get) Token: 0x0600059B RID: 1435 RVA: 0x0001C74C File Offset: 0x0001A94C
	[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
	public new static Type Il2CppType
	{
		get
		{
			return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr));
		}
	}

	// Token: 0x17000157 RID: 343
	// (get) Token: 0x0600059C RID: 1436 RVA: 0x0001C760 File Offset: 0x0001A960
	// (set) Token: 0x0600059D RID: 1437 RVA: 0x0001C77E File Offset: 0x0001A97E
	public unsafe static int C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C
	{
		get
		{
			int result;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C, (void*)(&result));
			return result;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C, (void*)(&value));
		}
	}

	// Token: 0x040004E4 RID: 1252
	private static readonly IntPtr NativeFieldInfoPtr_C9513413361171C289BA71B26C2E428164D74AC7979C32D27C62C530C7DD1E4C;
}
