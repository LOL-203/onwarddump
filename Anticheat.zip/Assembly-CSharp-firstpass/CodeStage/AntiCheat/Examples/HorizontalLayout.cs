﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.Examples
{
	// Token: 0x02000038 RID: 56
	public class HorizontalLayout : Il2CppSystem.Object
	{
		// Token: 0x0600054A RID: 1354 RVA: 0x0001B59C File Offset: 0x0001979C
		[CallerCount(0)]
		public unsafe HorizontalLayout(Il2CppReferenceArray<GUILayoutOption> options) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(options);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HorizontalLayout.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x0001B600 File Offset: 0x00019800
		[CallerCount(0)]
		public unsafe void Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(HorizontalLayout.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0001B644 File Offset: 0x00019844
		// Note: this type is marked as 'beforefieldinit'.
		static HorizontalLayout()
		{
			Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Examples", "HorizontalLayout");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr);
			HorizontalLayout.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr, 100664069);
			HorizontalLayout.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr, 100664070);
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00002580 File Offset: 0x00000780
		public HorizontalLayout(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x0600054E RID: 1358 RVA: 0x0001B69C File Offset: 0x0001989C
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<HorizontalLayout>.NativeClassPtr));
			}
		}

		// Token: 0x040004B7 RID: 1207
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0;

		// Token: 0x040004B8 RID: 1208
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0;
	}
}
