﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.Examples
{
	// Token: 0x02000039 RID: 57
	public class VerticalLayout : Il2CppSystem.Object
	{
		// Token: 0x0600054F RID: 1359 RVA: 0x0001B6B0 File Offset: 0x000198B0
		[CallerCount(0)]
		public unsafe VerticalLayout(Il2CppReferenceArray<GUILayoutOption> options) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(options);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VerticalLayout.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x0001B714 File Offset: 0x00019914
		[CallerCount(0)]
		public unsafe VerticalLayout(GUIStyle style) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(style);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VerticalLayout.NativeMethodInfoPtr__ctor_Public_Void_GUIStyle_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x0001B778 File Offset: 0x00019978
		[CallerCount(0)]
		public unsafe void Dispose()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(VerticalLayout.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0001B7BC File Offset: 0x000199BC
		// Note: this type is marked as 'beforefieldinit'.
		static VerticalLayout()
		{
			Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Examples", "VerticalLayout");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr);
			VerticalLayout.NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr, 100664071);
			VerticalLayout.NativeMethodInfoPtr__ctor_Public_Void_GUIStyle_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr, 100664072);
			VerticalLayout.NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr, 100664073);
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x00002580 File Offset: 0x00000780
		public VerticalLayout(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000554 RID: 1364 RVA: 0x0001B828 File Offset: 0x00019A28
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<VerticalLayout>.NativeClassPtr));
			}
		}

		// Token: 0x040004B9 RID: 1209
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_ArrayOf_GUILayoutOption_0;

		// Token: 0x040004BA RID: 1210
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_GUIStyle_0;

		// Token: 0x040004BB RID: 1211
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Virtual_Final_New_Void_0;
	}
}
