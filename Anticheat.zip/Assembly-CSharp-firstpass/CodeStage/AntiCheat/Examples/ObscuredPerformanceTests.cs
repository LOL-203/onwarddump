﻿using System;
using Il2CppSystem;
using Il2CppSystem.Text;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.Examples
{
	// Token: 0x0200003A RID: 58
	public class ObscuredPerformanceTests : MonoBehaviour
	{
		// Token: 0x06000555 RID: 1365 RVA: 0x0001B83C File Offset: 0x00019A3C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x0001B880 File Offset: 0x00019A80
		[CallerCount(0)]
		public unsafe void StartTests()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_StartTests_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x0001B8C4 File Offset: 0x00019AC4
		[CallerCount(0)]
		public unsafe void TestBool()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestBool_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x0001B908 File Offset: 0x00019B08
		[CallerCount(0)]
		public unsafe void TestByte()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestByte_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x0001B94C File Offset: 0x00019B4C
		[CallerCount(0)]
		public unsafe void TestShort()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestShort_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x0001B990 File Offset: 0x00019B90
		[CallerCount(0)]
		public unsafe void TestUShort()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestUShort_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x0001B9D4 File Offset: 0x00019BD4
		[CallerCount(0)]
		public unsafe void TestDouble()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestDouble_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x0001BA18 File Offset: 0x00019C18
		[CallerCount(0)]
		public unsafe void TestFloat()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestFloat_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x0001BA5C File Offset: 0x00019C5C
		[CallerCount(0)]
		public unsafe void TestInt()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestInt_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x0001BAA0 File Offset: 0x00019CA0
		[CallerCount(0)]
		public unsafe void TestLong()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestLong_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x0001BAE4 File Offset: 0x00019CE4
		[CallerCount(0)]
		public unsafe void TestString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestString_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x0001BB28 File Offset: 0x00019D28
		[CallerCount(0)]
		public unsafe void TestUInt()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestUInt_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x0001BB6C File Offset: 0x00019D6C
		[CallerCount(0)]
		public unsafe void TestVector3()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestVector3_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0001BBB0 File Offset: 0x00019DB0
		[CallerCount(0)]
		public unsafe void TestPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr_TestPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x0001BBF4 File Offset: 0x00019DF4
		[CallerCount(0)]
		public unsafe ObscuredPerformanceTests() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPerformanceTests.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x0001BC40 File Offset: 0x00019E40
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredPerformanceTests()
		{
			Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Examples", "ObscuredPerformanceTests");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr);
			ObscuredPerformanceTests.NativeFieldInfoPtr_boolTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "boolTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_boolIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "boolIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_byteTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "byteTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_byteIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "byteIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_shortTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "shortTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_shortIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "shortIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_ushortTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "ushortTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_ushortIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "ushortIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_intTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "intTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_intIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "intIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_uintTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "uintTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_uintIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "uintIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_longTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "longTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_longIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "longIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_floatTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "floatTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_floatIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "floatIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_doubleTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "doubleTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_doubleIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "doubleIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_stringTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "stringTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_stringIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "stringIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Test = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "vector3Test");
			ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Iterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "vector3Iterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_prefsTest = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "prefsTest");
			ObscuredPerformanceTests.NativeFieldInfoPtr_prefsIterations = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "prefsIterations");
			ObscuredPerformanceTests.NativeFieldInfoPtr_logBuilder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, "logBuilder");
			ObscuredPerformanceTests.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664074);
			ObscuredPerformanceTests.NativeMethodInfoPtr_StartTests_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664075);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestBool_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664076);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestByte_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664077);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestShort_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664078);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestUShort_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664079);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestDouble_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664080);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestFloat_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664081);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestInt_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664082);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestLong_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664083);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestString_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664084);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestUInt_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664085);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestVector3_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664086);
			ObscuredPerformanceTests.NativeMethodInfoPtr_TestPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664087);
			ObscuredPerformanceTests.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr, 100664088);
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x000022CC File Offset: 0x000004CC
		public ObscuredPerformanceTests(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000566 RID: 1382 RVA: 0x0001BF90 File Offset: 0x0001A190
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredPerformanceTests>.NativeClassPtr));
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000567 RID: 1383 RVA: 0x0001BFA4 File Offset: 0x0001A1A4
		// (set) Token: 0x06000568 RID: 1384 RVA: 0x0001BFCC File Offset: 0x0001A1CC
		public unsafe bool boolTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_boolTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_boolTest)) = value;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000569 RID: 1385 RVA: 0x0001BFF0 File Offset: 0x0001A1F0
		// (set) Token: 0x0600056A RID: 1386 RVA: 0x0001C018 File Offset: 0x0001A218
		public unsafe int boolIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_boolIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_boolIterations)) = value;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600056B RID: 1387 RVA: 0x0001C03C File Offset: 0x0001A23C
		// (set) Token: 0x0600056C RID: 1388 RVA: 0x0001C064 File Offset: 0x0001A264
		public unsafe bool byteTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_byteTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_byteTest)) = value;
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x0600056D RID: 1389 RVA: 0x0001C088 File Offset: 0x0001A288
		// (set) Token: 0x0600056E RID: 1390 RVA: 0x0001C0B0 File Offset: 0x0001A2B0
		public unsafe int byteIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_byteIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_byteIterations)) = value;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x0600056F RID: 1391 RVA: 0x0001C0D4 File Offset: 0x0001A2D4
		// (set) Token: 0x06000570 RID: 1392 RVA: 0x0001C0FC File Offset: 0x0001A2FC
		public unsafe bool shortTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_shortTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_shortTest)) = value;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x06000571 RID: 1393 RVA: 0x0001C120 File Offset: 0x0001A320
		// (set) Token: 0x06000572 RID: 1394 RVA: 0x0001C148 File Offset: 0x0001A348
		public unsafe int shortIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_shortIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_shortIterations)) = value;
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x06000573 RID: 1395 RVA: 0x0001C16C File Offset: 0x0001A36C
		// (set) Token: 0x06000574 RID: 1396 RVA: 0x0001C194 File Offset: 0x0001A394
		public unsafe bool ushortTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_ushortTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_ushortTest)) = value;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x06000575 RID: 1397 RVA: 0x0001C1B8 File Offset: 0x0001A3B8
		// (set) Token: 0x06000576 RID: 1398 RVA: 0x0001C1E0 File Offset: 0x0001A3E0
		public unsafe int ushortIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_ushortIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_ushortIterations)) = value;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x06000577 RID: 1399 RVA: 0x0001C204 File Offset: 0x0001A404
		// (set) Token: 0x06000578 RID: 1400 RVA: 0x0001C22C File Offset: 0x0001A42C
		public unsafe bool intTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_intTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_intTest)) = value;
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x06000579 RID: 1401 RVA: 0x0001C250 File Offset: 0x0001A450
		// (set) Token: 0x0600057A RID: 1402 RVA: 0x0001C278 File Offset: 0x0001A478
		public unsafe int intIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_intIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_intIterations)) = value;
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x0600057B RID: 1403 RVA: 0x0001C29C File Offset: 0x0001A49C
		// (set) Token: 0x0600057C RID: 1404 RVA: 0x0001C2C4 File Offset: 0x0001A4C4
		public unsafe bool uintTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_uintTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_uintTest)) = value;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x0600057D RID: 1405 RVA: 0x0001C2E8 File Offset: 0x0001A4E8
		// (set) Token: 0x0600057E RID: 1406 RVA: 0x0001C310 File Offset: 0x0001A510
		public unsafe int uintIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_uintIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_uintIterations)) = value;
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x0600057F RID: 1407 RVA: 0x0001C334 File Offset: 0x0001A534
		// (set) Token: 0x06000580 RID: 1408 RVA: 0x0001C35C File Offset: 0x0001A55C
		public unsafe bool longTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_longTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_longTest)) = value;
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000581 RID: 1409 RVA: 0x0001C380 File Offset: 0x0001A580
		// (set) Token: 0x06000582 RID: 1410 RVA: 0x0001C3A8 File Offset: 0x0001A5A8
		public unsafe int longIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_longIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_longIterations)) = value;
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000583 RID: 1411 RVA: 0x0001C3CC File Offset: 0x0001A5CC
		// (set) Token: 0x06000584 RID: 1412 RVA: 0x0001C3F4 File Offset: 0x0001A5F4
		public unsafe bool floatTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_floatTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_floatTest)) = value;
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x0001C418 File Offset: 0x0001A618
		// (set) Token: 0x06000586 RID: 1414 RVA: 0x0001C440 File Offset: 0x0001A640
		public unsafe int floatIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_floatIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_floatIterations)) = value;
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x06000587 RID: 1415 RVA: 0x0001C464 File Offset: 0x0001A664
		// (set) Token: 0x06000588 RID: 1416 RVA: 0x0001C48C File Offset: 0x0001A68C
		public unsafe bool doubleTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_doubleTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_doubleTest)) = value;
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x0001C4B0 File Offset: 0x0001A6B0
		// (set) Token: 0x0600058A RID: 1418 RVA: 0x0001C4D8 File Offset: 0x0001A6D8
		public unsafe int doubleIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_doubleIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_doubleIterations)) = value;
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600058B RID: 1419 RVA: 0x0001C4FC File Offset: 0x0001A6FC
		// (set) Token: 0x0600058C RID: 1420 RVA: 0x0001C524 File Offset: 0x0001A724
		public unsafe bool stringTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_stringTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_stringTest)) = value;
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x0600058D RID: 1421 RVA: 0x0001C548 File Offset: 0x0001A748
		// (set) Token: 0x0600058E RID: 1422 RVA: 0x0001C570 File Offset: 0x0001A770
		public unsafe int stringIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_stringIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_stringIterations)) = value;
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x0600058F RID: 1423 RVA: 0x0001C594 File Offset: 0x0001A794
		// (set) Token: 0x06000590 RID: 1424 RVA: 0x0001C5BC File Offset: 0x0001A7BC
		public unsafe bool vector3Test
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Test);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Test)) = value;
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000591 RID: 1425 RVA: 0x0001C5E0 File Offset: 0x0001A7E0
		// (set) Token: 0x06000592 RID: 1426 RVA: 0x0001C608 File Offset: 0x0001A808
		public unsafe int vector3Iterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Iterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_vector3Iterations)) = value;
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000593 RID: 1427 RVA: 0x0001C62C File Offset: 0x0001A82C
		// (set) Token: 0x06000594 RID: 1428 RVA: 0x0001C654 File Offset: 0x0001A854
		public unsafe bool prefsTest
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_prefsTest);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_prefsTest)) = value;
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000595 RID: 1429 RVA: 0x0001C678 File Offset: 0x0001A878
		// (set) Token: 0x06000596 RID: 1430 RVA: 0x0001C6A0 File Offset: 0x0001A8A0
		public unsafe int prefsIterations
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_prefsIterations);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_prefsIterations)) = value;
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000597 RID: 1431 RVA: 0x0001C6C4 File Offset: 0x0001A8C4
		// (set) Token: 0x06000598 RID: 1432 RVA: 0x0001C6F8 File Offset: 0x0001A8F8
		public unsafe StringBuilder logBuilder
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_logBuilder);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new StringBuilder(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredPerformanceTests.NativeFieldInfoPtr_logBuilder), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040004BC RID: 1212
		private static readonly IntPtr NativeFieldInfoPtr_boolTest;

		// Token: 0x040004BD RID: 1213
		private static readonly IntPtr NativeFieldInfoPtr_boolIterations;

		// Token: 0x040004BE RID: 1214
		private static readonly IntPtr NativeFieldInfoPtr_byteTest;

		// Token: 0x040004BF RID: 1215
		private static readonly IntPtr NativeFieldInfoPtr_byteIterations;

		// Token: 0x040004C0 RID: 1216
		private static readonly IntPtr NativeFieldInfoPtr_shortTest;

		// Token: 0x040004C1 RID: 1217
		private static readonly IntPtr NativeFieldInfoPtr_shortIterations;

		// Token: 0x040004C2 RID: 1218
		private static readonly IntPtr NativeFieldInfoPtr_ushortTest;

		// Token: 0x040004C3 RID: 1219
		private static readonly IntPtr NativeFieldInfoPtr_ushortIterations;

		// Token: 0x040004C4 RID: 1220
		private static readonly IntPtr NativeFieldInfoPtr_intTest;

		// Token: 0x040004C5 RID: 1221
		private static readonly IntPtr NativeFieldInfoPtr_intIterations;

		// Token: 0x040004C6 RID: 1222
		private static readonly IntPtr NativeFieldInfoPtr_uintTest;

		// Token: 0x040004C7 RID: 1223
		private static readonly IntPtr NativeFieldInfoPtr_uintIterations;

		// Token: 0x040004C8 RID: 1224
		private static readonly IntPtr NativeFieldInfoPtr_longTest;

		// Token: 0x040004C9 RID: 1225
		private static readonly IntPtr NativeFieldInfoPtr_longIterations;

		// Token: 0x040004CA RID: 1226
		private static readonly IntPtr NativeFieldInfoPtr_floatTest;

		// Token: 0x040004CB RID: 1227
		private static readonly IntPtr NativeFieldInfoPtr_floatIterations;

		// Token: 0x040004CC RID: 1228
		private static readonly IntPtr NativeFieldInfoPtr_doubleTest;

		// Token: 0x040004CD RID: 1229
		private static readonly IntPtr NativeFieldInfoPtr_doubleIterations;

		// Token: 0x040004CE RID: 1230
		private static readonly IntPtr NativeFieldInfoPtr_stringTest;

		// Token: 0x040004CF RID: 1231
		private static readonly IntPtr NativeFieldInfoPtr_stringIterations;

		// Token: 0x040004D0 RID: 1232
		private static readonly IntPtr NativeFieldInfoPtr_vector3Test;

		// Token: 0x040004D1 RID: 1233
		private static readonly IntPtr NativeFieldInfoPtr_vector3Iterations;

		// Token: 0x040004D2 RID: 1234
		private static readonly IntPtr NativeFieldInfoPtr_prefsTest;

		// Token: 0x040004D3 RID: 1235
		private static readonly IntPtr NativeFieldInfoPtr_prefsIterations;

		// Token: 0x040004D4 RID: 1236
		private static readonly IntPtr NativeFieldInfoPtr_logBuilder;

		// Token: 0x040004D5 RID: 1237
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x040004D6 RID: 1238
		private static readonly IntPtr NativeMethodInfoPtr_StartTests_Private_Void_0;

		// Token: 0x040004D7 RID: 1239
		private static readonly IntPtr NativeMethodInfoPtr_TestBool_Private_Void_0;

		// Token: 0x040004D8 RID: 1240
		private static readonly IntPtr NativeMethodInfoPtr_TestByte_Private_Void_0;

		// Token: 0x040004D9 RID: 1241
		private static readonly IntPtr NativeMethodInfoPtr_TestShort_Private_Void_0;

		// Token: 0x040004DA RID: 1242
		private static readonly IntPtr NativeMethodInfoPtr_TestUShort_Private_Void_0;

		// Token: 0x040004DB RID: 1243
		private static readonly IntPtr NativeMethodInfoPtr_TestDouble_Private_Void_0;

		// Token: 0x040004DC RID: 1244
		private static readonly IntPtr NativeMethodInfoPtr_TestFloat_Private_Void_0;

		// Token: 0x040004DD RID: 1245
		private static readonly IntPtr NativeMethodInfoPtr_TestInt_Private_Void_0;

		// Token: 0x040004DE RID: 1246
		private static readonly IntPtr NativeMethodInfoPtr_TestLong_Private_Void_0;

		// Token: 0x040004DF RID: 1247
		private static readonly IntPtr NativeMethodInfoPtr_TestString_Private_Void_0;

		// Token: 0x040004E0 RID: 1248
		private static readonly IntPtr NativeMethodInfoPtr_TestUInt_Private_Void_0;

		// Token: 0x040004E1 RID: 1249
		private static readonly IntPtr NativeMethodInfoPtr_TestVector3_Private_Void_0;

		// Token: 0x040004E2 RID: 1250
		private static readonly IntPtr NativeMethodInfoPtr_TestPrefs_Private_Void_0;

		// Token: 0x040004E3 RID: 1251
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
