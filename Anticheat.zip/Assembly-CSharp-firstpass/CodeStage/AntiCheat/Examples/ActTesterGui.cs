﻿using System;
using CodeStage.AntiCheat.ObscuredTypes;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using Il2CppSystem.Text;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.Examples
{
	// Token: 0x02000035 RID: 53
	public class ActTesterGui : MonoBehaviour
	{
		// Token: 0x060004B9 RID: 1209 RVA: 0x00019638 File Offset: 0x00017838
		[CallerCount(0)]
		public unsafe void OnSpeedHackDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnSpeedHackDetected_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0001967C File Offset: 0x0001787C
		[CallerCount(0)]
		public unsafe void OnInjectionDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnInjectionDetected_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x000196C0 File Offset: 0x000178C0
		[CallerCount(0)]
		public unsafe void OnInjectionDetectedWithCause(string cause)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(cause);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnInjectionDetectedWithCause_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x0001971C File Offset: 0x0001791C
		[CallerCount(0)]
		public unsafe void OnObscuredTypeCheatingDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnObscuredTypeCheatingDetected_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00019760 File Offset: 0x00017960
		[CallerCount(0)]
		public unsafe void OnWallHackDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnWallHackDetected_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x000197A4 File Offset: 0x000179A4
		[CallerCount(0)]
		public unsafe void OnValidate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnValidate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x000197E8 File Offset: 0x000179E8
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0001982C File Offset: 0x00017A2C
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x00019870 File Offset: 0x00017A70
		[CallerCount(0)]
		public unsafe void RandomizeObscuredVars()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_RandomizeObscuredVars_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x000198B4 File Offset: 0x00017AB4
		[CallerCount(0)]
		public unsafe void ObscuredStringExample()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_ObscuredStringExample_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x000198F8 File Offset: 0x00017AF8
		[CallerCount(0)]
		public unsafe void ObscuredIntExample()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_ObscuredIntExample_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0001993C File Offset: 0x00017B3C
		[CallerCount(0)]
		public unsafe void ObscuredFloatExample()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_ObscuredFloatExample_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x00019980 File Offset: 0x00017B80
		[CallerCount(0)]
		public unsafe void ObscuredVector3Example()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_ObscuredVector3Example_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x000199C4 File Offset: 0x00017BC4
		[CallerCount(0)]
		public unsafe void SavesAlterationDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_SavesAlterationDetected_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x00019A08 File Offset: 0x00017C08
		[CallerCount(0)]
		public unsafe void ForeignSavesDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_ForeignSavesDetected_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x00019A4C File Offset: 0x00017C4C
		[CallerCount(0)]
		public unsafe void OnGUI()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnGUI_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x00019A90 File Offset: 0x00017C90
		[CallerCount(0)]
		public unsafe string GetAllSimpleObscuredTypes()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_GetAllSimpleObscuredTypes_Private_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x00019ADC File Offset: 0x00017CDC
		[CallerCount(0)]
		public unsafe string GetAllObscuredPrefsDataTypes()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_GetAllObscuredPrefsDataTypes_Private_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x00019B28 File Offset: 0x00017D28
		[CallerCount(0)]
		public unsafe void LoadRegularPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_LoadRegularPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x00019B6C File Offset: 0x00017D6C
		[CallerCount(0)]
		public unsafe void SaveRegularPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_SaveRegularPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x00019BB0 File Offset: 0x00017DB0
		[CallerCount(0)]
		public unsafe void DeleteRegularPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_DeleteRegularPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x00019BF4 File Offset: 0x00017DF4
		[CallerCount(0)]
		public unsafe void LoadObscuredPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_LoadObscuredPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x00019C38 File Offset: 0x00017E38
		[CallerCount(0)]
		public unsafe void SaveObscuredPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_SaveObscuredPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x00019C7C File Offset: 0x00017E7C
		[CallerCount(0)]
		public unsafe void DeleteObscuredPrefs()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_DeleteObscuredPrefs_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x00019CC0 File Offset: 0x00017EC0
		[CallerCount(0)]
		public unsafe void PlaceUrlButton(string url)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(url);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x00019D1C File Offset: 0x00017F1C
		[CallerCount(0)]
		public unsafe void PlaceUrlButton(string url, int width)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(url);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref width;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x00019D88 File Offset: 0x00017F88
		[CallerCount(0)]
		public unsafe void PlaceUrlButton(string url, string buttonName, int width)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(url);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(buttonName);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref width;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_String_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x00019E0C File Offset: 0x0001800C
		[CallerCount(0)]
		public unsafe void OnApplicationQuit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x00019E50 File Offset: 0x00018050
		[CallerCount(0)]
		public unsafe ActTesterGui() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x00019E9C File Offset: 0x0001809C
		// Note: this type is marked as 'beforefieldinit'.
		static ActTesterGui()
		{
			Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Examples", "ActTesterGui");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr);
			ActTesterGui.NativeFieldInfoPtr_RED_COLOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "RED_COLOR");
			ActTesterGui.NativeFieldInfoPtr_GREEN_COLOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "GREEN_COLOR");
			ActTesterGui.NativeFieldInfoPtr_PREFS_STRING = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_STRING");
			ActTesterGui.NativeFieldInfoPtr_PREFS_INT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_INT");
			ActTesterGui.NativeFieldInfoPtr_PREFS_FLOAT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_FLOAT");
			ActTesterGui.NativeFieldInfoPtr_PREFS_BOOL = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_BOOL");
			ActTesterGui.NativeFieldInfoPtr_PREFS_UINT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_UINT");
			ActTesterGui.NativeFieldInfoPtr_PREFS_LONG = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_LONG");
			ActTesterGui.NativeFieldInfoPtr_PREFS_DOUBLE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_DOUBLE");
			ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_VECTOR2");
			ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_VECTOR3");
			ActTesterGui.NativeFieldInfoPtr_PREFS_QUATERNION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_QUATERNION");
			ActTesterGui.NativeFieldInfoPtr_PREFS_RECT = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_RECT");
			ActTesterGui.NativeFieldInfoPtr_PREFS_COLOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_COLOR");
			ActTesterGui.NativeFieldInfoPtr_PREFS_BYTE_ARRAY = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "PREFS_BYTE_ARRAY");
			ActTesterGui.NativeFieldInfoPtr_API_URL_LOCK_TO_DEVICE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_LOCK_TO_DEVICE");
			ActTesterGui.NativeFieldInfoPtr_API_URL_PRESERVE_PREFS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_PRESERVE_PREFS");
			ActTesterGui.NativeFieldInfoPtr_API_URL_EMERGENCY_MODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_EMERGENCY_MODE");
			ActTesterGui.NativeFieldInfoPtr_API_URL_READ_FOREIGN = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_READ_FOREIGN");
			ActTesterGui.NativeFieldInfoPtr_API_URL_UNOBSCURED_MODE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_UNOBSCURED_MODE");
			ActTesterGui.NativeFieldInfoPtr_API_URL_PLAYER_PREFS = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "API_URL_PLAYER_PREFS");
			ActTesterGui.NativeFieldInfoPtr_regularString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "regularString");
			ActTesterGui.NativeFieldInfoPtr_regularInt = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "regularInt");
			ActTesterGui.NativeFieldInfoPtr_regularFloat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "regularFloat");
			ActTesterGui.NativeFieldInfoPtr_regularVector3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "regularVector3");
			ActTesterGui.NativeFieldInfoPtr_obscuredString = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredString");
			ActTesterGui.NativeFieldInfoPtr_obscuredInt = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredInt");
			ActTesterGui.NativeFieldInfoPtr_obscuredFloat = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredFloat");
			ActTesterGui.NativeFieldInfoPtr_obscuredVector3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredVector3");
			ActTesterGui.NativeFieldInfoPtr_obscuredBool = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredBool");
			ActTesterGui.NativeFieldInfoPtr_obscuredLong = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredLong");
			ActTesterGui.NativeFieldInfoPtr_obscuredDouble = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredDouble");
			ActTesterGui.NativeFieldInfoPtr_obscuredVector2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredVector2");
			ActTesterGui.NativeFieldInfoPtr_prefsEncryptionKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "prefsEncryptionKey");
			ActTesterGui.NativeFieldInfoPtr_tabs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "tabs");
			ActTesterGui.NativeFieldInfoPtr_currentTab = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "currentTab");
			ActTesterGui.NativeFieldInfoPtr_allSimpleObscuredTypes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "allSimpleObscuredTypes");
			ActTesterGui.NativeFieldInfoPtr_regularPrefs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "regularPrefs");
			ActTesterGui.NativeFieldInfoPtr_obscuredPrefs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredPrefs");
			ActTesterGui.NativeFieldInfoPtr_savesLock = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "savesLock");
			ActTesterGui.NativeFieldInfoPtr_savesAlterationDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "savesAlterationDetected");
			ActTesterGui.NativeFieldInfoPtr_foreignSavesDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "foreignSavesDetected");
			ActTesterGui.NativeFieldInfoPtr_injectionDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "injectionDetected");
			ActTesterGui.NativeFieldInfoPtr_speedHackDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "speedHackDetected");
			ActTesterGui.NativeFieldInfoPtr_obscuredTypeCheatDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "obscuredTypeCheatDetected");
			ActTesterGui.NativeFieldInfoPtr_wallHackCheatDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "wallHackCheatDetected");
			ActTesterGui.NativeFieldInfoPtr_logBuilder = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "logBuilder");
			ActTesterGui.NativeMethodInfoPtr_OnSpeedHackDetected_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664034);
			ActTesterGui.NativeMethodInfoPtr_OnInjectionDetected_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664035);
			ActTesterGui.NativeMethodInfoPtr_OnInjectionDetectedWithCause_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664036);
			ActTesterGui.NativeMethodInfoPtr_OnObscuredTypeCheatingDetected_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664037);
			ActTesterGui.NativeMethodInfoPtr_OnWallHackDetected_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664038);
			ActTesterGui.NativeMethodInfoPtr_OnValidate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664039);
			ActTesterGui.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664040);
			ActTesterGui.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664041);
			ActTesterGui.NativeMethodInfoPtr_RandomizeObscuredVars_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664042);
			ActTesterGui.NativeMethodInfoPtr_ObscuredStringExample_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664043);
			ActTesterGui.NativeMethodInfoPtr_ObscuredIntExample_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664044);
			ActTesterGui.NativeMethodInfoPtr_ObscuredFloatExample_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664045);
			ActTesterGui.NativeMethodInfoPtr_ObscuredVector3Example_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664046);
			ActTesterGui.NativeMethodInfoPtr_SavesAlterationDetected_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664047);
			ActTesterGui.NativeMethodInfoPtr_ForeignSavesDetected_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664048);
			ActTesterGui.NativeMethodInfoPtr_OnGUI_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664049);
			ActTesterGui.NativeMethodInfoPtr_GetAllSimpleObscuredTypes_Private_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664050);
			ActTesterGui.NativeMethodInfoPtr_GetAllObscuredPrefsDataTypes_Private_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664051);
			ActTesterGui.NativeMethodInfoPtr_LoadRegularPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664052);
			ActTesterGui.NativeMethodInfoPtr_SaveRegularPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664053);
			ActTesterGui.NativeMethodInfoPtr_DeleteRegularPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664054);
			ActTesterGui.NativeMethodInfoPtr_LoadObscuredPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664055);
			ActTesterGui.NativeMethodInfoPtr_SaveObscuredPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664056);
			ActTesterGui.NativeMethodInfoPtr_DeleteObscuredPrefs_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664057);
			ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664058);
			ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664059);
			ActTesterGui.NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664060);
			ActTesterGui.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664061);
			ActTesterGui.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, 100664062);
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x000022CC File Offset: 0x000004CC
		public ActTesterGui(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x0001A4BC File Offset: 0x000186BC
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr));
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060004D9 RID: 1241 RVA: 0x0001A4D0 File Offset: 0x000186D0
		// (set) Token: 0x060004DA RID: 1242 RVA: 0x0001A4F0 File Offset: 0x000186F0
		public unsafe static string RED_COLOR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_RED_COLOR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_RED_COLOR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060004DB RID: 1243 RVA: 0x0001A508 File Offset: 0x00018708
		// (set) Token: 0x060004DC RID: 1244 RVA: 0x0001A528 File Offset: 0x00018728
		public unsafe static string GREEN_COLOR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_GREEN_COLOR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_GREEN_COLOR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x060004DD RID: 1245 RVA: 0x0001A540 File Offset: 0x00018740
		// (set) Token: 0x060004DE RID: 1246 RVA: 0x0001A560 File Offset: 0x00018760
		public unsafe static string PREFS_STRING
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_STRING, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_STRING, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060004DF RID: 1247 RVA: 0x0001A578 File Offset: 0x00018778
		// (set) Token: 0x060004E0 RID: 1248 RVA: 0x0001A598 File Offset: 0x00018798
		public unsafe static string PREFS_INT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_INT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_INT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x060004E1 RID: 1249 RVA: 0x0001A5B0 File Offset: 0x000187B0
		// (set) Token: 0x060004E2 RID: 1250 RVA: 0x0001A5D0 File Offset: 0x000187D0
		public unsafe static string PREFS_FLOAT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_FLOAT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_FLOAT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x060004E3 RID: 1251 RVA: 0x0001A5E8 File Offset: 0x000187E8
		// (set) Token: 0x060004E4 RID: 1252 RVA: 0x0001A608 File Offset: 0x00018808
		public unsafe static string PREFS_BOOL
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_BOOL, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_BOOL, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x060004E5 RID: 1253 RVA: 0x0001A620 File Offset: 0x00018820
		// (set) Token: 0x060004E6 RID: 1254 RVA: 0x0001A640 File Offset: 0x00018840
		public unsafe static string PREFS_UINT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_UINT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_UINT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x060004E7 RID: 1255 RVA: 0x0001A658 File Offset: 0x00018858
		// (set) Token: 0x060004E8 RID: 1256 RVA: 0x0001A678 File Offset: 0x00018878
		public unsafe static string PREFS_LONG
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_LONG, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_LONG, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x060004E9 RID: 1257 RVA: 0x0001A690 File Offset: 0x00018890
		// (set) Token: 0x060004EA RID: 1258 RVA: 0x0001A6B0 File Offset: 0x000188B0
		public unsafe static string PREFS_DOUBLE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_DOUBLE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_DOUBLE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x060004EB RID: 1259 RVA: 0x0001A6C8 File Offset: 0x000188C8
		// (set) Token: 0x060004EC RID: 1260 RVA: 0x0001A6E8 File Offset: 0x000188E8
		public unsafe static string PREFS_VECTOR2
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR2, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR2, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x060004ED RID: 1261 RVA: 0x0001A700 File Offset: 0x00018900
		// (set) Token: 0x060004EE RID: 1262 RVA: 0x0001A720 File Offset: 0x00018920
		public unsafe static string PREFS_VECTOR3
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR3, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_VECTOR3, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0001A738 File Offset: 0x00018938
		// (set) Token: 0x060004F0 RID: 1264 RVA: 0x0001A758 File Offset: 0x00018958
		public unsafe static string PREFS_QUATERNION
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_QUATERNION, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_QUATERNION, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x060004F1 RID: 1265 RVA: 0x0001A770 File Offset: 0x00018970
		// (set) Token: 0x060004F2 RID: 1266 RVA: 0x0001A790 File Offset: 0x00018990
		public unsafe static string PREFS_RECT
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_RECT, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_RECT, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x060004F3 RID: 1267 RVA: 0x0001A7A8 File Offset: 0x000189A8
		// (set) Token: 0x060004F4 RID: 1268 RVA: 0x0001A7C8 File Offset: 0x000189C8
		public unsafe static string PREFS_COLOR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_COLOR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_COLOR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060004F5 RID: 1269 RVA: 0x0001A7E0 File Offset: 0x000189E0
		// (set) Token: 0x060004F6 RID: 1270 RVA: 0x0001A800 File Offset: 0x00018A00
		public unsafe static string PREFS_BYTE_ARRAY
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_PREFS_BYTE_ARRAY, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_PREFS_BYTE_ARRAY, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x0001A818 File Offset: 0x00018A18
		// (set) Token: 0x060004F8 RID: 1272 RVA: 0x0001A838 File Offset: 0x00018A38
		public unsafe static string API_URL_LOCK_TO_DEVICE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_LOCK_TO_DEVICE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_LOCK_TO_DEVICE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x0001A850 File Offset: 0x00018A50
		// (set) Token: 0x060004FA RID: 1274 RVA: 0x0001A870 File Offset: 0x00018A70
		public unsafe static string API_URL_PRESERVE_PREFS
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_PRESERVE_PREFS, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_PRESERVE_PREFS, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x060004FB RID: 1275 RVA: 0x0001A888 File Offset: 0x00018A88
		// (set) Token: 0x060004FC RID: 1276 RVA: 0x0001A8A8 File Offset: 0x00018AA8
		public unsafe static string API_URL_EMERGENCY_MODE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_EMERGENCY_MODE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_EMERGENCY_MODE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x0001A8C0 File Offset: 0x00018AC0
		// (set) Token: 0x060004FE RID: 1278 RVA: 0x0001A8E0 File Offset: 0x00018AE0
		public unsafe static string API_URL_READ_FOREIGN
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_READ_FOREIGN, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_READ_FOREIGN, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x060004FF RID: 1279 RVA: 0x0001A8F8 File Offset: 0x00018AF8
		// (set) Token: 0x06000500 RID: 1280 RVA: 0x0001A918 File Offset: 0x00018B18
		public unsafe static string API_URL_UNOBSCURED_MODE
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_UNOBSCURED_MODE, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_UNOBSCURED_MODE, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000501 RID: 1281 RVA: 0x0001A930 File Offset: 0x00018B30
		// (set) Token: 0x06000502 RID: 1282 RVA: 0x0001A950 File Offset: 0x00018B50
		public unsafe static string API_URL_PLAYER_PREFS
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActTesterGui.NativeFieldInfoPtr_API_URL_PLAYER_PREFS, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActTesterGui.NativeFieldInfoPtr_API_URL_PLAYER_PREFS, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000503 RID: 1283 RVA: 0x0001A968 File Offset: 0x00018B68
		// (set) Token: 0x06000504 RID: 1284 RVA: 0x0001A991 File Offset: 0x00018B91
		public unsafe string regularString
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularString);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularString), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000505 RID: 1285 RVA: 0x0001A9B8 File Offset: 0x00018BB8
		// (set) Token: 0x06000506 RID: 1286 RVA: 0x0001A9E0 File Offset: 0x00018BE0
		public unsafe int regularInt
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularInt);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularInt)) = value;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000507 RID: 1287 RVA: 0x0001AA04 File Offset: 0x00018C04
		// (set) Token: 0x06000508 RID: 1288 RVA: 0x0001AA2C File Offset: 0x00018C2C
		public unsafe float regularFloat
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularFloat);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularFloat)) = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000509 RID: 1289 RVA: 0x0001AA50 File Offset: 0x00018C50
		// (set) Token: 0x0600050A RID: 1290 RVA: 0x0001AA78 File Offset: 0x00018C78
		public unsafe Vector3 regularVector3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularVector3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularVector3)) = value;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600050B RID: 1291 RVA: 0x0001AA9C File Offset: 0x00018C9C
		// (set) Token: 0x0600050C RID: 1292 RVA: 0x0001AAD0 File Offset: 0x00018CD0
		public unsafe ObscuredString obscuredString
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredString);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new ObscuredString(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredString), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600050D RID: 1293 RVA: 0x0001AAF8 File Offset: 0x00018CF8
		// (set) Token: 0x0600050E RID: 1294 RVA: 0x0001AB20 File Offset: 0x00018D20
		public unsafe ObscuredInt obscuredInt
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredInt);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredInt)) = value;
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x0600050F RID: 1295 RVA: 0x0001AB44 File Offset: 0x00018D44
		// (set) Token: 0x06000510 RID: 1296 RVA: 0x0001AB76 File Offset: 0x00018D76
		public ObscuredFloat obscuredFloat
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredFloat);
				return new ObscuredFloat(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredFloat), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000511 RID: 1297 RVA: 0x0001ABAC File Offset: 0x00018DAC
		// (set) Token: 0x06000512 RID: 1298 RVA: 0x0001ABD4 File Offset: 0x00018DD4
		public unsafe ObscuredVector3 obscuredVector3
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredVector3);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredVector3)) = value;
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x06000513 RID: 1299 RVA: 0x0001ABF8 File Offset: 0x00018DF8
		// (set) Token: 0x06000514 RID: 1300 RVA: 0x0001AC20 File Offset: 0x00018E20
		public unsafe ObscuredBool obscuredBool
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredBool);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredBool)) = value;
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x06000515 RID: 1301 RVA: 0x0001AC44 File Offset: 0x00018E44
		// (set) Token: 0x06000516 RID: 1302 RVA: 0x0001AC6C File Offset: 0x00018E6C
		public unsafe ObscuredLong obscuredLong
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredLong);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredLong)) = value;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x06000517 RID: 1303 RVA: 0x0001AC90 File Offset: 0x00018E90
		// (set) Token: 0x06000518 RID: 1304 RVA: 0x0001ACC2 File Offset: 0x00018EC2
		public ObscuredDouble obscuredDouble
		{
			get
			{
				IntPtr data = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredDouble);
				return new ObscuredDouble(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, data));
			}
			set
			{
				cpblk(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredDouble), IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtr(value)), IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, (UIntPtr)0));
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000519 RID: 1305 RVA: 0x0001ACF8 File Offset: 0x00018EF8
		// (set) Token: 0x0600051A RID: 1306 RVA: 0x0001AD20 File Offset: 0x00018F20
		public unsafe ObscuredVector2 obscuredVector2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredVector2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredVector2)) = value;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x0600051B RID: 1307 RVA: 0x0001AD44 File Offset: 0x00018F44
		// (set) Token: 0x0600051C RID: 1308 RVA: 0x0001AD6D File Offset: 0x00018F6D
		public unsafe string prefsEncryptionKey
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_prefsEncryptionKey);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_prefsEncryptionKey), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x0600051D RID: 1309 RVA: 0x0001AD94 File Offset: 0x00018F94
		// (set) Token: 0x0600051E RID: 1310 RVA: 0x0001ADC8 File Offset: 0x00018FC8
		public unsafe Il2CppStringArray tabs
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_tabs);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_tabs), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x0600051F RID: 1311 RVA: 0x0001ADF0 File Offset: 0x00018FF0
		// (set) Token: 0x06000520 RID: 1312 RVA: 0x0001AE18 File Offset: 0x00019018
		public unsafe int currentTab
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_currentTab);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_currentTab)) = value;
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x06000521 RID: 1313 RVA: 0x0001AE3C File Offset: 0x0001903C
		// (set) Token: 0x06000522 RID: 1314 RVA: 0x0001AE65 File Offset: 0x00019065
		public unsafe string allSimpleObscuredTypes
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_allSimpleObscuredTypes);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_allSimpleObscuredTypes), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x06000523 RID: 1315 RVA: 0x0001AE8C File Offset: 0x0001908C
		// (set) Token: 0x06000524 RID: 1316 RVA: 0x0001AEB5 File Offset: 0x000190B5
		public unsafe string regularPrefs
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularPrefs);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_regularPrefs), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000525 RID: 1317 RVA: 0x0001AEDC File Offset: 0x000190DC
		// (set) Token: 0x06000526 RID: 1318 RVA: 0x0001AF05 File Offset: 0x00019105
		public unsafe string obscuredPrefs
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredPrefs);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredPrefs), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000527 RID: 1319 RVA: 0x0001AF2C File Offset: 0x0001912C
		// (set) Token: 0x06000528 RID: 1320 RVA: 0x0001AF54 File Offset: 0x00019154
		public unsafe int savesLock
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_savesLock);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_savesLock)) = value;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000529 RID: 1321 RVA: 0x0001AF78 File Offset: 0x00019178
		// (set) Token: 0x0600052A RID: 1322 RVA: 0x0001AFA0 File Offset: 0x000191A0
		public unsafe bool savesAlterationDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_savesAlterationDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_savesAlterationDetected)) = value;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x0600052B RID: 1323 RVA: 0x0001AFC4 File Offset: 0x000191C4
		// (set) Token: 0x0600052C RID: 1324 RVA: 0x0001AFEC File Offset: 0x000191EC
		public unsafe bool foreignSavesDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_foreignSavesDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_foreignSavesDetected)) = value;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x0600052D RID: 1325 RVA: 0x0001B010 File Offset: 0x00019210
		// (set) Token: 0x0600052E RID: 1326 RVA: 0x0001B038 File Offset: 0x00019238
		public unsafe bool injectionDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_injectionDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_injectionDetected)) = value;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600052F RID: 1327 RVA: 0x0001B05C File Offset: 0x0001925C
		// (set) Token: 0x06000530 RID: 1328 RVA: 0x0001B084 File Offset: 0x00019284
		public unsafe bool speedHackDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_speedHackDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_speedHackDetected)) = value;
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x06000531 RID: 1329 RVA: 0x0001B0A8 File Offset: 0x000192A8
		// (set) Token: 0x06000532 RID: 1330 RVA: 0x0001B0D0 File Offset: 0x000192D0
		public unsafe bool obscuredTypeCheatDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredTypeCheatDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_obscuredTypeCheatDetected)) = value;
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000533 RID: 1331 RVA: 0x0001B0F4 File Offset: 0x000192F4
		// (set) Token: 0x06000534 RID: 1332 RVA: 0x0001B11C File Offset: 0x0001931C
		public unsafe bool wallHackCheatDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_wallHackCheatDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_wallHackCheatDetected)) = value;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000535 RID: 1333 RVA: 0x0001B140 File Offset: 0x00019340
		// (set) Token: 0x06000536 RID: 1334 RVA: 0x0001B174 File Offset: 0x00019374
		public unsafe StringBuilder logBuilder
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_logBuilder);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new StringBuilder(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.NativeFieldInfoPtr_logBuilder), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000462 RID: 1122
		private static readonly IntPtr NativeFieldInfoPtr_RED_COLOR;

		// Token: 0x04000463 RID: 1123
		private static readonly IntPtr NativeFieldInfoPtr_GREEN_COLOR;

		// Token: 0x04000464 RID: 1124
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_STRING;

		// Token: 0x04000465 RID: 1125
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_INT;

		// Token: 0x04000466 RID: 1126
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_FLOAT;

		// Token: 0x04000467 RID: 1127
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_BOOL;

		// Token: 0x04000468 RID: 1128
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_UINT;

		// Token: 0x04000469 RID: 1129
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_LONG;

		// Token: 0x0400046A RID: 1130
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_DOUBLE;

		// Token: 0x0400046B RID: 1131
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_VECTOR2;

		// Token: 0x0400046C RID: 1132
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_VECTOR3;

		// Token: 0x0400046D RID: 1133
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_QUATERNION;

		// Token: 0x0400046E RID: 1134
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_RECT;

		// Token: 0x0400046F RID: 1135
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_COLOR;

		// Token: 0x04000470 RID: 1136
		private static readonly IntPtr NativeFieldInfoPtr_PREFS_BYTE_ARRAY;

		// Token: 0x04000471 RID: 1137
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_LOCK_TO_DEVICE;

		// Token: 0x04000472 RID: 1138
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_PRESERVE_PREFS;

		// Token: 0x04000473 RID: 1139
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_EMERGENCY_MODE;

		// Token: 0x04000474 RID: 1140
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_READ_FOREIGN;

		// Token: 0x04000475 RID: 1141
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_UNOBSCURED_MODE;

		// Token: 0x04000476 RID: 1142
		private static readonly IntPtr NativeFieldInfoPtr_API_URL_PLAYER_PREFS;

		// Token: 0x04000477 RID: 1143
		private static readonly IntPtr NativeFieldInfoPtr_regularString;

		// Token: 0x04000478 RID: 1144
		private static readonly IntPtr NativeFieldInfoPtr_regularInt;

		// Token: 0x04000479 RID: 1145
		private static readonly IntPtr NativeFieldInfoPtr_regularFloat;

		// Token: 0x0400047A RID: 1146
		private static readonly IntPtr NativeFieldInfoPtr_regularVector3;

		// Token: 0x0400047B RID: 1147
		private static readonly IntPtr NativeFieldInfoPtr_obscuredString;

		// Token: 0x0400047C RID: 1148
		private static readonly IntPtr NativeFieldInfoPtr_obscuredInt;

		// Token: 0x0400047D RID: 1149
		private static readonly IntPtr NativeFieldInfoPtr_obscuredFloat;

		// Token: 0x0400047E RID: 1150
		private static readonly IntPtr NativeFieldInfoPtr_obscuredVector3;

		// Token: 0x0400047F RID: 1151
		private static readonly IntPtr NativeFieldInfoPtr_obscuredBool;

		// Token: 0x04000480 RID: 1152
		private static readonly IntPtr NativeFieldInfoPtr_obscuredLong;

		// Token: 0x04000481 RID: 1153
		private static readonly IntPtr NativeFieldInfoPtr_obscuredDouble;

		// Token: 0x04000482 RID: 1154
		private static readonly IntPtr NativeFieldInfoPtr_obscuredVector2;

		// Token: 0x04000483 RID: 1155
		private static readonly IntPtr NativeFieldInfoPtr_prefsEncryptionKey;

		// Token: 0x04000484 RID: 1156
		private static readonly IntPtr NativeFieldInfoPtr_tabs;

		// Token: 0x04000485 RID: 1157
		private static readonly IntPtr NativeFieldInfoPtr_currentTab;

		// Token: 0x04000486 RID: 1158
		private static readonly IntPtr NativeFieldInfoPtr_allSimpleObscuredTypes;

		// Token: 0x04000487 RID: 1159
		private static readonly IntPtr NativeFieldInfoPtr_regularPrefs;

		// Token: 0x04000488 RID: 1160
		private static readonly IntPtr NativeFieldInfoPtr_obscuredPrefs;

		// Token: 0x04000489 RID: 1161
		private static readonly IntPtr NativeFieldInfoPtr_savesLock;

		// Token: 0x0400048A RID: 1162
		private static readonly IntPtr NativeFieldInfoPtr_savesAlterationDetected;

		// Token: 0x0400048B RID: 1163
		private static readonly IntPtr NativeFieldInfoPtr_foreignSavesDetected;

		// Token: 0x0400048C RID: 1164
		private static readonly IntPtr NativeFieldInfoPtr_injectionDetected;

		// Token: 0x0400048D RID: 1165
		private static readonly IntPtr NativeFieldInfoPtr_speedHackDetected;

		// Token: 0x0400048E RID: 1166
		private static readonly IntPtr NativeFieldInfoPtr_obscuredTypeCheatDetected;

		// Token: 0x0400048F RID: 1167
		private static readonly IntPtr NativeFieldInfoPtr_wallHackCheatDetected;

		// Token: 0x04000490 RID: 1168
		private static readonly IntPtr NativeFieldInfoPtr_logBuilder;

		// Token: 0x04000491 RID: 1169
		private static readonly IntPtr NativeMethodInfoPtr_OnSpeedHackDetected_Public_Void_0;

		// Token: 0x04000492 RID: 1170
		private static readonly IntPtr NativeMethodInfoPtr_OnInjectionDetected_Public_Void_0;

		// Token: 0x04000493 RID: 1171
		private static readonly IntPtr NativeMethodInfoPtr_OnInjectionDetectedWithCause_Public_Void_String_0;

		// Token: 0x04000494 RID: 1172
		private static readonly IntPtr NativeMethodInfoPtr_OnObscuredTypeCheatingDetected_Public_Void_0;

		// Token: 0x04000495 RID: 1173
		private static readonly IntPtr NativeMethodInfoPtr_OnWallHackDetected_Public_Void_0;

		// Token: 0x04000496 RID: 1174
		private static readonly IntPtr NativeMethodInfoPtr_OnValidate_Private_Void_0;

		// Token: 0x04000497 RID: 1175
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x04000498 RID: 1176
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04000499 RID: 1177
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeObscuredVars_Private_Void_0;

		// Token: 0x0400049A RID: 1178
		private static readonly IntPtr NativeMethodInfoPtr_ObscuredStringExample_Private_Void_0;

		// Token: 0x0400049B RID: 1179
		private static readonly IntPtr NativeMethodInfoPtr_ObscuredIntExample_Private_Void_0;

		// Token: 0x0400049C RID: 1180
		private static readonly IntPtr NativeMethodInfoPtr_ObscuredFloatExample_Private_Void_0;

		// Token: 0x0400049D RID: 1181
		private static readonly IntPtr NativeMethodInfoPtr_ObscuredVector3Example_Private_Void_0;

		// Token: 0x0400049E RID: 1182
		private static readonly IntPtr NativeMethodInfoPtr_SavesAlterationDetected_Private_Void_0;

		// Token: 0x0400049F RID: 1183
		private static readonly IntPtr NativeMethodInfoPtr_ForeignSavesDetected_Private_Void_0;

		// Token: 0x040004A0 RID: 1184
		private static readonly IntPtr NativeMethodInfoPtr_OnGUI_Private_Void_0;

		// Token: 0x040004A1 RID: 1185
		private static readonly IntPtr NativeMethodInfoPtr_GetAllSimpleObscuredTypes_Private_String_0;

		// Token: 0x040004A2 RID: 1186
		private static readonly IntPtr NativeMethodInfoPtr_GetAllObscuredPrefsDataTypes_Private_String_0;

		// Token: 0x040004A3 RID: 1187
		private static readonly IntPtr NativeMethodInfoPtr_LoadRegularPrefs_Private_Void_0;

		// Token: 0x040004A4 RID: 1188
		private static readonly IntPtr NativeMethodInfoPtr_SaveRegularPrefs_Private_Void_0;

		// Token: 0x040004A5 RID: 1189
		private static readonly IntPtr NativeMethodInfoPtr_DeleteRegularPrefs_Private_Void_0;

		// Token: 0x040004A6 RID: 1190
		private static readonly IntPtr NativeMethodInfoPtr_LoadObscuredPrefs_Private_Void_0;

		// Token: 0x040004A7 RID: 1191
		private static readonly IntPtr NativeMethodInfoPtr_SaveObscuredPrefs_Private_Void_0;

		// Token: 0x040004A8 RID: 1192
		private static readonly IntPtr NativeMethodInfoPtr_DeleteObscuredPrefs_Private_Void_0;

		// Token: 0x040004A9 RID: 1193
		private static readonly IntPtr NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_0;

		// Token: 0x040004AA RID: 1194
		private static readonly IntPtr NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_Int32_0;

		// Token: 0x040004AB RID: 1195
		private static readonly IntPtr NativeMethodInfoPtr_PlaceUrlButton_Private_Void_String_String_Int32_0;

		// Token: 0x040004AC RID: 1196
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0;

		// Token: 0x040004AD RID: 1197
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

		// Token: 0x02000036 RID: 54
		[ObfuscatedName("CodeStage.AntiCheat.Examples.ActTesterGui/<>c__DisplayClass63_0")]
		public sealed class __c__DisplayClass63_0 : Il2CppSystem.Object
		{
			// Token: 0x06000537 RID: 1335 RVA: 0x0001B19C File Offset: 0x0001939C
			[CallerCount(0)]
			public unsafe __c__DisplayClass63_0() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.__c__DisplayClass63_0.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000538 RID: 1336 RVA: 0x0001B1E8 File Offset: 0x000193E8
			[CallerCount(0)]
			public unsafe void _GetAllSimpleObscuredTypes_b__2(Type t)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.__c__DisplayClass63_0.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__2_Internal_Void_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000539 RID: 1337 RVA: 0x0001B244 File Offset: 0x00019444
			// Note: this type is marked as 'beforefieldinit'.
			static __c__DisplayClass63_0()
			{
				Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "<>c__DisplayClass63_0");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr);
				ActTesterGui.__c__DisplayClass63_0.NativeFieldInfoPtr_types = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr, "types");
				ActTesterGui.__c__DisplayClass63_0.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr, 100664063);
				ActTesterGui.__c__DisplayClass63_0.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__2_Internal_Void_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr, 100664064);
			}

			// Token: 0x0600053A RID: 1338 RVA: 0x00002580 File Offset: 0x00000780
			public __c__DisplayClass63_0(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17000134 RID: 308
			// (get) Token: 0x0600053B RID: 1339 RVA: 0x0001B2AB File Offset: 0x000194AB
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ActTesterGui.__c__DisplayClass63_0>.NativeClassPtr));
				}
			}

			// Token: 0x17000135 RID: 309
			// (get) Token: 0x0600053C RID: 1340 RVA: 0x0001B2BC File Offset: 0x000194BC
			// (set) Token: 0x0600053D RID: 1341 RVA: 0x0001B2E5 File Offset: 0x000194E5
			public unsafe string types
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.__c__DisplayClass63_0.NativeFieldInfoPtr_types);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActTesterGui.__c__DisplayClass63_0.NativeFieldInfoPtr_types), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x040004AE RID: 1198
			private static readonly IntPtr NativeFieldInfoPtr_types;

			// Token: 0x040004AF RID: 1199
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x040004B0 RID: 1200
			private static readonly IntPtr NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__2_Internal_Void_Type_0;
		}

		// Token: 0x02000037 RID: 55
		[ObfuscatedName("CodeStage.AntiCheat.Examples.ActTesterGui/<>c")]
		[Serializable]
		public sealed class __c : Il2CppSystem.Object
		{
			// Token: 0x0600053E RID: 1342 RVA: 0x0001B30C File Offset: 0x0001950C
			[CallerCount(0)]
			public unsafe __c() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr))
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.__c.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x0600053F RID: 1343 RVA: 0x0001B358 File Offset: 0x00019558
			[CallerCount(0)]
			public unsafe bool _GetAllSimpleObscuredTypes_b__63_0(Assembly assembly)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(assembly);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.__c.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_0_Internal_Boolean_Assembly_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06000540 RID: 1344 RVA: 0x0001B3C0 File Offset: 0x000195C0
			[CallerCount(0)]
			public unsafe bool _GetAllSimpleObscuredTypes_b__63_1(Type t)
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(t);
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ActTesterGui.__c.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_1_Internal_Boolean_Type_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x06000541 RID: 1345 RVA: 0x0001B428 File Offset: 0x00019628
			// Note: this type is marked as 'beforefieldinit'.
			static __c()
			{
				Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ActTesterGui>.NativeClassPtr, "<>c");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr);
				ActTesterGui.__c.NativeFieldInfoPtr___9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, "<>9");
				ActTesterGui.__c.NativeFieldInfoPtr___9__63_0 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, "<>9__63_0");
				ActTesterGui.__c.NativeFieldInfoPtr___9__63_1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, "<>9__63_1");
				ActTesterGui.__c.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, 100664066);
				ActTesterGui.__c.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_0_Internal_Boolean_Assembly_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, 100664067);
				ActTesterGui.__c.NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_1_Internal_Boolean_Type_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr, 100664068);
			}

			// Token: 0x06000542 RID: 1346 RVA: 0x00002580 File Offset: 0x00000780
			public __c(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x17000136 RID: 310
			// (get) Token: 0x06000543 RID: 1347 RVA: 0x0001B4CB File Offset: 0x000196CB
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ActTesterGui.__c>.NativeClassPtr));
				}
			}

			// Token: 0x17000137 RID: 311
			// (get) Token: 0x06000544 RID: 1348 RVA: 0x0001B4DC File Offset: 0x000196DC
			// (set) Token: 0x06000545 RID: 1349 RVA: 0x0001B507 File Offset: 0x00019707
			public unsafe static ActTesterGui.__c __9
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(ActTesterGui.__c.NativeFieldInfoPtr___9, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new ActTesterGui.__c(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(ActTesterGui.__c.NativeFieldInfoPtr___9, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17000138 RID: 312
			// (get) Token: 0x06000546 RID: 1350 RVA: 0x0001B51C File Offset: 0x0001971C
			// (set) Token: 0x06000547 RID: 1351 RVA: 0x0001B547 File Offset: 0x00019747
			public unsafe static Func<Assembly, bool> __9__63_0
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(ActTesterGui.__c.NativeFieldInfoPtr___9__63_0, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<Assembly, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(ActTesterGui.__c.NativeFieldInfoPtr___9__63_0, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x17000139 RID: 313
			// (get) Token: 0x06000548 RID: 1352 RVA: 0x0001B55C File Offset: 0x0001975C
			// (set) Token: 0x06000549 RID: 1353 RVA: 0x0001B587 File Offset: 0x00019787
			public unsafe static Func<Type, bool> __9__63_1
			{
				get
				{
					IntPtr intPtr;
					IL2CPP.il2cpp_field_static_get_value(ActTesterGui.__c.NativeFieldInfoPtr___9__63_1, (void*)(&intPtr));
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Func<Type, bool>(intPtr2) : null;
				}
				set
				{
					IL2CPP.il2cpp_field_static_set_value(ActTesterGui.__c.NativeFieldInfoPtr___9__63_1, IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x040004B1 RID: 1201
			private static readonly IntPtr NativeFieldInfoPtr___9;

			// Token: 0x040004B2 RID: 1202
			private static readonly IntPtr NativeFieldInfoPtr___9__63_0;

			// Token: 0x040004B3 RID: 1203
			private static readonly IntPtr NativeFieldInfoPtr___9__63_1;

			// Token: 0x040004B4 RID: 1204
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;

			// Token: 0x040004B5 RID: 1205
			private static readonly IntPtr NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_0_Internal_Boolean_Assembly_0;

			// Token: 0x040004B6 RID: 1206
			private static readonly IntPtr NativeMethodInfoPtr__GetAllSimpleObscuredTypes_b__63_1_Internal_Boolean_Type_0;
		}
	}
}
