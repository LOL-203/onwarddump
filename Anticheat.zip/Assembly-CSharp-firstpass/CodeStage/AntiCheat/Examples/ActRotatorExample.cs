﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.Examples
{
	// Token: 0x02000034 RID: 52
	public class ActRotatorExample : MonoBehaviour
	{
		// Token: 0x060004B2 RID: 1202 RVA: 0x000194DC File Offset: 0x000176DC
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActRotatorExample.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x00019520 File Offset: 0x00017720
		[CallerCount(0)]
		public unsafe ActRotatorExample() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActRotatorExample.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0001956C File Offset: 0x0001776C
		// Note: this type is marked as 'beforefieldinit'.
		static ActRotatorExample()
		{
			Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Examples", "ActRotatorExample");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr);
			ActRotatorExample.NativeFieldInfoPtr_speed = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr, "speed");
			ActRotatorExample.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr, 100664032);
			ActRotatorExample.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr, 100664033);
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x000022CC File Offset: 0x000004CC
		public ActRotatorExample(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x060004B6 RID: 1206 RVA: 0x000195D8 File Offset: 0x000177D8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ActRotatorExample>.NativeClassPtr));
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060004B7 RID: 1207 RVA: 0x000195EC File Offset: 0x000177EC
		// (set) Token: 0x060004B8 RID: 1208 RVA: 0x00019614 File Offset: 0x00017814
		public unsafe float speed
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActRotatorExample.NativeFieldInfoPtr_speed);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActRotatorExample.NativeFieldInfoPtr_speed)) = value;
			}
		}

		// Token: 0x0400045F RID: 1119
		private static readonly IntPtr NativeFieldInfoPtr_speed;

		// Token: 0x04000460 RID: 1120
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x04000461 RID: 1121
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
