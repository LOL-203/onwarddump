﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.Events;

namespace CodeStage.AntiCheat.Detectors
{
	// Token: 0x02000028 RID: 40
	public class ActDetectorBase : MonoBehaviour
	{
		// Token: 0x0600033F RID: 831 RVA: 0x000133A4 File Offset: 0x000115A4
		[CallerCount(0)]
		public unsafe void Start()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActDetectorBase.NativeMethodInfoPtr_Start_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000340 RID: 832 RVA: 0x000133E8 File Offset: 0x000115E8
		[CallerCount(0)]
		public unsafe void OnEnable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActDetectorBase.NativeMethodInfoPtr_OnEnable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0001342C File Offset: 0x0001162C
		[CallerCount(0)]
		public unsafe void OnDisable()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActDetectorBase.NativeMethodInfoPtr_OnDisable_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000342 RID: 834 RVA: 0x00013470 File Offset: 0x00011670
		[CallerCount(0)]
		public unsafe void OnApplicationQuit()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActDetectorBase.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000343 RID: 835 RVA: 0x000134B4 File Offset: 0x000116B4
		[CallerCount(0)]
		public unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000344 RID: 836 RVA: 0x00013504 File Offset: 0x00011704
		[CallerCount(0)]
		public unsafe bool Init(ActDetectorBase instance, string detectorName)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(instance);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(detectorName);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_Init_Protected_Virtual_New_Boolean_ActDetectorBase_String_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00013590 File Offset: 0x00011790
		[CallerCount(0)]
		public unsafe void DisposeInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x000135E0 File Offset: 0x000117E0
		[CallerCount(0)]
		public unsafe bool DetectorHasAdditionalCallbacks()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_DetectorHasAdditionalCallbacks_Protected_Virtual_New_Boolean_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0001363C File Offset: 0x0001183C
		[CallerCount(0)]
		public unsafe void OnCheatingDetected()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_OnCheatingDetected_Internal_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0001368C File Offset: 0x0001188C
		[CallerCount(0)]
		public unsafe void StartDetectionAutomatically()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000349 RID: 841 RVA: 0x000136DC File Offset: 0x000118DC
		[CallerCount(0)]
		public unsafe void StopDetectionInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_StopDetectionInternal_Protected_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0001372C File Offset: 0x0001192C
		[CallerCount(0)]
		public unsafe void PauseDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_PauseDetector_Protected_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0001377C File Offset: 0x0001197C
		[CallerCount(0)]
		public unsafe void ResumeDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ActDetectorBase.NativeMethodInfoPtr_ResumeDetector_Protected_Abstract_Virtual_New_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600034C RID: 844 RVA: 0x000137CC File Offset: 0x000119CC
		[CallerCount(0)]
		public unsafe ActDetectorBase() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ActDetectorBase.NativeMethodInfoPtr__ctor_Protected_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x00013818 File Offset: 0x00011A18
		// Note: this type is marked as 'beforefieldinit'.
		static ActDetectorBase()
		{
			Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Detectors", "ActDetectorBase");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr);
			ActDetectorBase.NativeFieldInfoPtr_CONTAINER_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "CONTAINER_NAME");
			ActDetectorBase.NativeFieldInfoPtr_MENU_PATH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "MENU_PATH");
			ActDetectorBase.NativeFieldInfoPtr_GAME_OBJECT_MENU_PATH = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "GAME_OBJECT_MENU_PATH");
			ActDetectorBase.NativeFieldInfoPtr_detectorsContainer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "detectorsContainer");
			ActDetectorBase.NativeFieldInfoPtr_autoStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "autoStart");
			ActDetectorBase.NativeFieldInfoPtr_keepAlive = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "keepAlive");
			ActDetectorBase.NativeFieldInfoPtr_autoDispose = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "autoDispose");
			ActDetectorBase.NativeFieldInfoPtr_detectionEvent = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "detectionEvent");
			ActDetectorBase.NativeFieldInfoPtr_detectionAction = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "detectionAction");
			ActDetectorBase.NativeFieldInfoPtr_detectionEventHasListener = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "detectionEventHasListener");
			ActDetectorBase.NativeFieldInfoPtr_isRunning = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "isRunning");
			ActDetectorBase.NativeFieldInfoPtr_started = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, "started");
			ActDetectorBase.NativeMethodInfoPtr_Start_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663885);
			ActDetectorBase.NativeMethodInfoPtr_OnEnable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663886);
			ActDetectorBase.NativeMethodInfoPtr_OnDisable_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663887);
			ActDetectorBase.NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663888);
			ActDetectorBase.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663889);
			ActDetectorBase.NativeMethodInfoPtr_Init_Protected_Virtual_New_Boolean_ActDetectorBase_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663890);
			ActDetectorBase.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663891);
			ActDetectorBase.NativeMethodInfoPtr_DetectorHasAdditionalCallbacks_Protected_Virtual_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663892);
			ActDetectorBase.NativeMethodInfoPtr_OnCheatingDetected_Internal_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663893);
			ActDetectorBase.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663894);
			ActDetectorBase.NativeMethodInfoPtr_StopDetectionInternal_Protected_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663895);
			ActDetectorBase.NativeMethodInfoPtr_PauseDetector_Protected_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663896);
			ActDetectorBase.NativeMethodInfoPtr_ResumeDetector_Protected_Abstract_Virtual_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663897);
			ActDetectorBase.NativeMethodInfoPtr__ctor_Protected_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr, 100663898);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x000022CC File Offset: 0x000004CC
		public ActDetectorBase(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600034F RID: 847 RVA: 0x00013A50 File Offset: 0x00011C50
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ActDetectorBase>.NativeClassPtr));
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000350 RID: 848 RVA: 0x00013A64 File Offset: 0x00011C64
		// (set) Token: 0x06000351 RID: 849 RVA: 0x00013A84 File Offset: 0x00011C84
		public unsafe static string CONTAINER_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActDetectorBase.NativeFieldInfoPtr_CONTAINER_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActDetectorBase.NativeFieldInfoPtr_CONTAINER_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000352 RID: 850 RVA: 0x00013A9C File Offset: 0x00011C9C
		// (set) Token: 0x06000353 RID: 851 RVA: 0x00013ABC File Offset: 0x00011CBC
		public unsafe static string MENU_PATH
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActDetectorBase.NativeFieldInfoPtr_MENU_PATH, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActDetectorBase.NativeFieldInfoPtr_MENU_PATH, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000354 RID: 852 RVA: 0x00013AD4 File Offset: 0x00011CD4
		// (set) Token: 0x06000355 RID: 853 RVA: 0x00013AF4 File Offset: 0x00011CF4
		public unsafe static string GAME_OBJECT_MENU_PATH
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ActDetectorBase.NativeFieldInfoPtr_GAME_OBJECT_MENU_PATH, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActDetectorBase.NativeFieldInfoPtr_GAME_OBJECT_MENU_PATH, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000356 RID: 854 RVA: 0x00013B0C File Offset: 0x00011D0C
		// (set) Token: 0x06000357 RID: 855 RVA: 0x00013B37 File Offset: 0x00011D37
		public unsafe static GameObject detectorsContainer
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ActDetectorBase.NativeFieldInfoPtr_detectorsContainer, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ActDetectorBase.NativeFieldInfoPtr_detectorsContainer, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000358 RID: 856 RVA: 0x00013B4C File Offset: 0x00011D4C
		// (set) Token: 0x06000359 RID: 857 RVA: 0x00013B74 File Offset: 0x00011D74
		public unsafe bool autoStart
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_autoStart);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_autoStart)) = value;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600035A RID: 858 RVA: 0x00013B98 File Offset: 0x00011D98
		// (set) Token: 0x0600035B RID: 859 RVA: 0x00013BC0 File Offset: 0x00011DC0
		public unsafe bool keepAlive
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_keepAlive);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_keepAlive)) = value;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600035C RID: 860 RVA: 0x00013BE4 File Offset: 0x00011DE4
		// (set) Token: 0x0600035D RID: 861 RVA: 0x00013C0C File Offset: 0x00011E0C
		public unsafe bool autoDispose
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_autoDispose);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_autoDispose)) = value;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600035E RID: 862 RVA: 0x00013C30 File Offset: 0x00011E30
		// (set) Token: 0x0600035F RID: 863 RVA: 0x00013C64 File Offset: 0x00011E64
		public unsafe UnityEvent detectionEvent
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionEvent);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UnityEvent(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionEvent), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000360 RID: 864 RVA: 0x00013C8C File Offset: 0x00011E8C
		// (set) Token: 0x06000361 RID: 865 RVA: 0x00013CC0 File Offset: 0x00011EC0
		public unsafe UnityAction detectionAction
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionAction);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UnityAction(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionAction), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000362 RID: 866 RVA: 0x00013CE8 File Offset: 0x00011EE8
		// (set) Token: 0x06000363 RID: 867 RVA: 0x00013D10 File Offset: 0x00011F10
		public unsafe bool detectionEventHasListener
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionEventHasListener);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_detectionEventHasListener)) = value;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000364 RID: 868 RVA: 0x00013D34 File Offset: 0x00011F34
		// (set) Token: 0x06000365 RID: 869 RVA: 0x00013D5C File Offset: 0x00011F5C
		public unsafe bool isRunning
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_isRunning);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_isRunning)) = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000366 RID: 870 RVA: 0x00013D80 File Offset: 0x00011F80
		// (set) Token: 0x06000367 RID: 871 RVA: 0x00013DA8 File Offset: 0x00011FA8
		public unsafe bool started
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_started);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ActDetectorBase.NativeFieldInfoPtr_started)) = value;
			}
		}

		// Token: 0x04000336 RID: 822
		private static readonly IntPtr NativeFieldInfoPtr_CONTAINER_NAME;

		// Token: 0x04000337 RID: 823
		private static readonly IntPtr NativeFieldInfoPtr_MENU_PATH;

		// Token: 0x04000338 RID: 824
		private static readonly IntPtr NativeFieldInfoPtr_GAME_OBJECT_MENU_PATH;

		// Token: 0x04000339 RID: 825
		private static readonly IntPtr NativeFieldInfoPtr_detectorsContainer;

		// Token: 0x0400033A RID: 826
		private static readonly IntPtr NativeFieldInfoPtr_autoStart;

		// Token: 0x0400033B RID: 827
		private static readonly IntPtr NativeFieldInfoPtr_keepAlive;

		// Token: 0x0400033C RID: 828
		private static readonly IntPtr NativeFieldInfoPtr_autoDispose;

		// Token: 0x0400033D RID: 829
		private static readonly IntPtr NativeFieldInfoPtr_detectionEvent;

		// Token: 0x0400033E RID: 830
		private static readonly IntPtr NativeFieldInfoPtr_detectionAction;

		// Token: 0x0400033F RID: 831
		private static readonly IntPtr NativeFieldInfoPtr_detectionEventHasListener;

		// Token: 0x04000340 RID: 832
		private static readonly IntPtr NativeFieldInfoPtr_isRunning;

		// Token: 0x04000341 RID: 833
		private static readonly IntPtr NativeFieldInfoPtr_started;

		// Token: 0x04000342 RID: 834
		private static readonly IntPtr NativeMethodInfoPtr_Start_Private_Void_0;

		// Token: 0x04000343 RID: 835
		private static readonly IntPtr NativeMethodInfoPtr_OnEnable_Private_Void_0;

		// Token: 0x04000344 RID: 836
		private static readonly IntPtr NativeMethodInfoPtr_OnDisable_Private_Void_0;

		// Token: 0x04000345 RID: 837
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationQuit_Private_Void_0;

		// Token: 0x04000346 RID: 838
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Virtual_New_Void_0;

		// Token: 0x04000347 RID: 839
		private static readonly IntPtr NativeMethodInfoPtr_Init_Protected_Virtual_New_Boolean_ActDetectorBase_String_0;

		// Token: 0x04000348 RID: 840
		private static readonly IntPtr NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_New_Void_0;

		// Token: 0x04000349 RID: 841
		private static readonly IntPtr NativeMethodInfoPtr_DetectorHasAdditionalCallbacks_Protected_Virtual_New_Boolean_0;

		// Token: 0x0400034A RID: 842
		private static readonly IntPtr NativeMethodInfoPtr_OnCheatingDetected_Internal_Virtual_New_Void_0;

		// Token: 0x0400034B RID: 843
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Abstract_Virtual_New_Void_0;

		// Token: 0x0400034C RID: 844
		private static readonly IntPtr NativeMethodInfoPtr_StopDetectionInternal_Protected_Abstract_Virtual_New_Void_0;

		// Token: 0x0400034D RID: 845
		private static readonly IntPtr NativeMethodInfoPtr_PauseDetector_Protected_Abstract_Virtual_New_Void_0;

		// Token: 0x0400034E RID: 846
		private static readonly IntPtr NativeMethodInfoPtr_ResumeDetector_Protected_Abstract_Virtual_New_Void_0;

		// Token: 0x0400034F RID: 847
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Protected_Void_0;
	}
}
