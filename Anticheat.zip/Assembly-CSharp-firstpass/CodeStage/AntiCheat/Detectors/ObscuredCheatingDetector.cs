﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace CodeStage.AntiCheat.Detectors
{
	// Token: 0x0200002B RID: 43
	public class ObscuredCheatingDetector : ActDetectorBase
	{
		// Token: 0x0600039D RID: 925 RVA: 0x00014D08 File Offset: 0x00012F08
		[CallerCount(0)]
		public unsafe static void StartDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00014D3C File Offset: 0x00012F3C
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600039F RID: 927 RVA: 0x00014D88 File Offset: 0x00012F88
		[CallerCount(0)]
		public unsafe static void StopDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x00014DBC File Offset: 0x00012FBC
		[CallerCount(0)]
		public unsafe static void Dispose()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060003A1 RID: 929 RVA: 0x00014DF0 File Offset: 0x00012FF0
		// (set) Token: 0x060003A2 RID: 930 RVA: 0x00014E38 File Offset: 0x00013038
		public unsafe static ObscuredCheatingDetector Instance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_ObscuredCheatingDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ObscuredCheatingDetector(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_ObscuredCheatingDetector_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060003A3 RID: 931 RVA: 0x00014E84 File Offset: 0x00013084
		public unsafe static ObscuredCheatingDetector GetOrCreateInstance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_ObscuredCheatingDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ObscuredCheatingDetector(intPtr2) : null;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x00014ECC File Offset: 0x000130CC
		public unsafe static bool IsRunning
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_get_IsRunning_Internal_Static_get_Boolean_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x00014F10 File Offset: 0x00013110
		[CallerCount(0)]
		public unsafe ObscuredCheatingDetector() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x00014F5C File Offset: 0x0001315C
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x00014FA0 File Offset: 0x000131A0
		[CallerCount(0)]
		public new unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x00014FF0 File Offset: 0x000131F0
		[CallerCount(0)]
		public unsafe void OnLevelWasLoadedNew(Scene scene, LoadSceneMode mode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref scene;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref mode;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x00015058 File Offset: 0x00013258
		[CallerCount(0)]
		public unsafe void OnLevelLoadedCallback()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x0001509C File Offset: 0x0001329C
		[CallerCount(0)]
		public unsafe void StartDetectionInternal(UnityAction callback)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x000150F8 File Offset: 0x000132F8
		[CallerCount(0)]
		public new unsafe void StartDetectionAutomatically()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00015148 File Offset: 0x00013348
		[CallerCount(0)]
		public new unsafe void PauseDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x00015198 File Offset: 0x00013398
		[CallerCount(0)]
		public new unsafe void ResumeDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AE RID: 942 RVA: 0x000151E8 File Offset: 0x000133E8
		[CallerCount(0)]
		public new unsafe void StopDetectionInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00015238 File Offset: 0x00013438
		[CallerCount(0)]
		public new unsafe void DisposeInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), ObscuredCheatingDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00015288 File Offset: 0x00013488
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredCheatingDetector()
		{
			Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Detectors", "ObscuredCheatingDetector");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr);
			ObscuredCheatingDetector.NativeFieldInfoPtr_COMPONENT_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "COMPONENT_NAME");
			ObscuredCheatingDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "FINAL_LOG_PREFIX");
			ObscuredCheatingDetector.NativeFieldInfoPtr_instancesInScene = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "instancesInScene");
			ObscuredCheatingDetector.NativeFieldInfoPtr_floatEpsilon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "floatEpsilon");
			ObscuredCheatingDetector.NativeFieldInfoPtr_vector2Epsilon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "vector2Epsilon");
			ObscuredCheatingDetector.NativeFieldInfoPtr_vector3Epsilon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "vector3Epsilon");
			ObscuredCheatingDetector.NativeFieldInfoPtr_quaternionEpsilon = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "quaternionEpsilon");
			ObscuredCheatingDetector.NativeFieldInfoPtr__Instance_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, "<Instance>k__BackingField");
			ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663926);
			ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663927);
			ObscuredCheatingDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663928);
			ObscuredCheatingDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663929);
			ObscuredCheatingDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_ObscuredCheatingDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663930);
			ObscuredCheatingDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_ObscuredCheatingDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663931);
			ObscuredCheatingDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_ObscuredCheatingDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663932);
			ObscuredCheatingDetector.NativeMethodInfoPtr_get_IsRunning_Internal_Static_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663933);
			ObscuredCheatingDetector.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663934);
			ObscuredCheatingDetector.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663935);
			ObscuredCheatingDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663936);
			ObscuredCheatingDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663937);
			ObscuredCheatingDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663938);
			ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663939);
			ObscuredCheatingDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663940);
			ObscuredCheatingDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663941);
			ObscuredCheatingDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663942);
			ObscuredCheatingDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663943);
			ObscuredCheatingDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr, 100663944);
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0001490C File Offset: 0x00012B0C
		public ObscuredCheatingDetector(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060003B2 RID: 946 RVA: 0x000154D4 File Offset: 0x000136D4
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredCheatingDetector>.NativeClassPtr));
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060003B3 RID: 947 RVA: 0x000154E8 File Offset: 0x000136E8
		// (set) Token: 0x060003B4 RID: 948 RVA: 0x00015508 File Offset: 0x00013708
		public unsafe static string COMPONENT_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredCheatingDetector.NativeFieldInfoPtr_COMPONENT_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredCheatingDetector.NativeFieldInfoPtr_COMPONENT_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060003B5 RID: 949 RVA: 0x00015520 File Offset: 0x00013720
		// (set) Token: 0x060003B6 RID: 950 RVA: 0x00015540 File Offset: 0x00013740
		public unsafe static string FINAL_LOG_PREFIX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredCheatingDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredCheatingDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060003B7 RID: 951 RVA: 0x00015558 File Offset: 0x00013758
		// (set) Token: 0x060003B8 RID: 952 RVA: 0x00015576 File Offset: 0x00013776
		public unsafe static int instancesInScene
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredCheatingDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredCheatingDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&value));
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060003B9 RID: 953 RVA: 0x00015588 File Offset: 0x00013788
		// (set) Token: 0x060003BA RID: 954 RVA: 0x000155B0 File Offset: 0x000137B0
		public unsafe float floatEpsilon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_floatEpsilon);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_floatEpsilon)) = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060003BB RID: 955 RVA: 0x000155D4 File Offset: 0x000137D4
		// (set) Token: 0x060003BC RID: 956 RVA: 0x000155FC File Offset: 0x000137FC
		public unsafe float vector2Epsilon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_vector2Epsilon);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_vector2Epsilon)) = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060003BD RID: 957 RVA: 0x00015620 File Offset: 0x00013820
		// (set) Token: 0x060003BE RID: 958 RVA: 0x00015648 File Offset: 0x00013848
		public unsafe float vector3Epsilon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_vector3Epsilon);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_vector3Epsilon)) = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060003BF RID: 959 RVA: 0x0001566C File Offset: 0x0001386C
		// (set) Token: 0x060003C0 RID: 960 RVA: 0x00015694 File Offset: 0x00013894
		public unsafe float quaternionEpsilon
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_quaternionEpsilon);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredCheatingDetector.NativeFieldInfoPtr_quaternionEpsilon)) = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060003C1 RID: 961 RVA: 0x000156B8 File Offset: 0x000138B8
		// (set) Token: 0x060003C2 RID: 962 RVA: 0x000156E3 File Offset: 0x000138E3
		public unsafe static ObscuredCheatingDetector _Instance_k__BackingField
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ObscuredCheatingDetector.NativeFieldInfoPtr__Instance_k__BackingField, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new ObscuredCheatingDetector(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredCheatingDetector.NativeFieldInfoPtr__Instance_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000375 RID: 885
		private static readonly IntPtr NativeFieldInfoPtr_COMPONENT_NAME;

		// Token: 0x04000376 RID: 886
		private static readonly IntPtr NativeFieldInfoPtr_FINAL_LOG_PREFIX;

		// Token: 0x04000377 RID: 887
		private static readonly IntPtr NativeFieldInfoPtr_instancesInScene;

		// Token: 0x04000378 RID: 888
		private static readonly IntPtr NativeFieldInfoPtr_floatEpsilon;

		// Token: 0x04000379 RID: 889
		private static readonly IntPtr NativeFieldInfoPtr_vector2Epsilon;

		// Token: 0x0400037A RID: 890
		private static readonly IntPtr NativeFieldInfoPtr_vector3Epsilon;

		// Token: 0x0400037B RID: 891
		private static readonly IntPtr NativeFieldInfoPtr_quaternionEpsilon;

		// Token: 0x0400037C RID: 892
		private static readonly IntPtr NativeFieldInfoPtr__Instance_k__BackingField;

		// Token: 0x0400037D RID: 893
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_0;

		// Token: 0x0400037E RID: 894
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0;

		// Token: 0x0400037F RID: 895
		private static readonly IntPtr NativeMethodInfoPtr_StopDetection_Public_Static_Void_0;

		// Token: 0x04000380 RID: 896
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Static_Void_0;

		// Token: 0x04000381 RID: 897
		private static readonly IntPtr NativeMethodInfoPtr_get_Instance_Public_Static_get_ObscuredCheatingDetector_0;

		// Token: 0x04000382 RID: 898
		private static readonly IntPtr NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_ObscuredCheatingDetector_0;

		// Token: 0x04000383 RID: 899
		private static readonly IntPtr NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_ObscuredCheatingDetector_0;

		// Token: 0x04000384 RID: 900
		private static readonly IntPtr NativeMethodInfoPtr_get_IsRunning_Internal_Static_get_Boolean_0;

		// Token: 0x04000385 RID: 901
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

		// Token: 0x04000386 RID: 902
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x04000387 RID: 903
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0;

		// Token: 0x04000388 RID: 904
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0;

		// Token: 0x04000389 RID: 905
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0;

		// Token: 0x0400038A RID: 906
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_0;

		// Token: 0x0400038B RID: 907
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0;

		// Token: 0x0400038C RID: 908
		private static readonly IntPtr NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0;

		// Token: 0x0400038D RID: 909
		private static readonly IntPtr NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0;

		// Token: 0x0400038E RID: 910
		private static readonly IntPtr NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0;

		// Token: 0x0400038F RID: 911
		private static readonly IntPtr NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0;
	}
}
