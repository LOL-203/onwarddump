﻿using System;
using Il2CppSystem;
using Il2CppSystem.Collections;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace CodeStage.AntiCheat.Detectors
{
	// Token: 0x0200002D RID: 45
	public class WallHackDetector : ActDetectorBase
	{
		// Token: 0x170000EA RID: 234
		// (get) Token: 0x060003FC RID: 1020 RVA: 0x000165D8 File Offset: 0x000147D8
		// (set) Token: 0x060003FD RID: 1021 RVA: 0x00016628 File Offset: 0x00014828
		public unsafe bool CheckRigidbody
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_CheckRigidbody_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_set_CheckRigidbody_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x060003FE RID: 1022 RVA: 0x0001667C File Offset: 0x0001487C
		// (set) Token: 0x060003FF RID: 1023 RVA: 0x000166CC File Offset: 0x000148CC
		public unsafe bool CheckController
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_CheckController_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_set_CheckController_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000400 RID: 1024 RVA: 0x00016720 File Offset: 0x00014920
		// (set) Token: 0x06000401 RID: 1025 RVA: 0x00016770 File Offset: 0x00014970
		public unsafe bool CheckWireframe
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_CheckWireframe_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_set_CheckWireframe_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000402 RID: 1026 RVA: 0x000167C4 File Offset: 0x000149C4
		// (set) Token: 0x06000403 RID: 1027 RVA: 0x00016814 File Offset: 0x00014A14
		public unsafe bool CheckRaycast
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_CheckRaycast_Public_get_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_set_CheckRaycast_Public_set_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x00016868 File Offset: 0x00014A68
		[CallerCount(0)]
		public unsafe static void StartDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0001689C File Offset: 0x00014A9C
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x000168E8 File Offset: 0x00014AE8
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback, Vector3 spawnPosition)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnPosition;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00016948 File Offset: 0x00014B48
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback, Vector3 spawnPosition, byte maxFalsePositives)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref spawnPosition;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxFalsePositives;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x000169B8 File Offset: 0x00014BB8
		[CallerCount(0)]
		public unsafe static void StopDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x000169EC File Offset: 0x00014BEC
		[CallerCount(0)]
		public unsafe static void Dispose()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600040A RID: 1034 RVA: 0x00016A20 File Offset: 0x00014C20
		// (set) Token: 0x0600040B RID: 1035 RVA: 0x00016A68 File Offset: 0x00014C68
		public unsafe static WallHackDetector Instance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_WallHackDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new WallHackDetector(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_WallHackDetector_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600040C RID: 1036 RVA: 0x00016AB4 File Offset: 0x00014CB4
		public unsafe static WallHackDetector GetOrCreateInstance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_WallHackDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new WallHackDetector(intPtr2) : null;
			}
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00016AFC File Offset: 0x00014CFC
		[CallerCount(0)]
		public unsafe WallHackDetector() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00016B48 File Offset: 0x00014D48
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00016B8C File Offset: 0x00014D8C
		[CallerCount(0)]
		public new unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00016BDC File Offset: 0x00014DDC
		[CallerCount(0)]
		public unsafe void OnLevelWasLoadedNew(Scene scene, LoadSceneMode mode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref scene;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref mode;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00016C44 File Offset: 0x00014E44
		[CallerCount(0)]
		public unsafe void OnLevelLoadedCallback()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00016C88 File Offset: 0x00014E88
		[CallerCount(0)]
		public unsafe void FixedUpdate()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_FixedUpdate_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00016CCC File Offset: 0x00014ECC
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00016D10 File Offset: 0x00014F10
		[CallerCount(0)]
		public unsafe void StartDetectionInternal(UnityAction callback, Vector3 servicePosition, byte falsePositivesInRow)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref servicePosition;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref falsePositivesInRow;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Vector3_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00016D90 File Offset: 0x00014F90
		[CallerCount(0)]
		public new unsafe void StartDetectionAutomatically()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x00016DE0 File Offset: 0x00014FE0
		[CallerCount(0)]
		public new unsafe void PauseDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00016E30 File Offset: 0x00015030
		[CallerCount(0)]
		public new unsafe void ResumeDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00016E80 File Offset: 0x00015080
		[CallerCount(0)]
		public new unsafe void StopDetectionInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x00016ED0 File Offset: 0x000150D0
		[CallerCount(0)]
		public new unsafe void DisposeInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), WallHackDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00016F20 File Offset: 0x00015120
		[CallerCount(0)]
		public unsafe void UpdateServiceContainer()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_UpdateServiceContainer_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00016F64 File Offset: 0x00015164
		[CallerCount(0)]
		public unsafe IEnumerator InitDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_InitDetector_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00016FBC File Offset: 0x000151BC
		[CallerCount(0)]
		public unsafe void StartRigidModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartRigidModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00017000 File Offset: 0x00015200
		[CallerCount(0)]
		public unsafe void StartControllerModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartControllerModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00017044 File Offset: 0x00015244
		[CallerCount(0)]
		public unsafe void StartWireframeModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartWireframeModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x00017088 File Offset: 0x00015288
		[CallerCount(0)]
		public unsafe void ShootWireframeModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_ShootWireframeModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x000170CC File Offset: 0x000152CC
		[CallerCount(0)]
		public unsafe IEnumerator CaptureFrame()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_CaptureFrame_Private_IEnumerator_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new IEnumerator(intPtr2) : null;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x00017124 File Offset: 0x00015324
		[CallerCount(0)]
		public unsafe void StartRaycastModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StartRaycastModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00017168 File Offset: 0x00015368
		[CallerCount(0)]
		public unsafe void ShootRaycastModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_ShootRaycastModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x000171AC File Offset: 0x000153AC
		[CallerCount(0)]
		public unsafe void StopRigidModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StopRigidModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x000171F0 File Offset: 0x000153F0
		[CallerCount(0)]
		public unsafe void StopControllerModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StopControllerModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00017234 File Offset: 0x00015434
		[CallerCount(0)]
		public unsafe void StopWireframeModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StopWireframeModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x00017278 File Offset: 0x00015478
		[CallerCount(0)]
		public unsafe void StopRaycastModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_StopRaycastModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x000172BC File Offset: 0x000154BC
		[CallerCount(0)]
		public unsafe void InitRigidModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_InitRigidModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x00017300 File Offset: 0x00015500
		[CallerCount(0)]
		public unsafe void InitControllerModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_InitControllerModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x00017344 File Offset: 0x00015544
		[CallerCount(0)]
		public unsafe void UninitRigidModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_UninitRigidModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x00017388 File Offset: 0x00015588
		[CallerCount(0)]
		public unsafe void UninitControllerModule()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_UninitControllerModule_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x000173CC File Offset: 0x000155CC
		[CallerCount(0)]
		public unsafe bool Detect()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_Detect_Private_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600042C RID: 1068 RVA: 0x0001741C File Offset: 0x0001561C
		[CallerCount(0)]
		public unsafe static Color32 GenerateColor()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_GenerateColor_Private_Static_Color32_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600042D RID: 1069 RVA: 0x00017460 File Offset: 0x00015660
		[CallerCount(0)]
		public unsafe static bool ColorsSimilar(Color32 c1, Color32 c2, int tolerance)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref c1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref c2;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref tolerance;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector.NativeMethodInfoPtr_ColorsSimilar_Private_Static_Boolean_Color32_Color32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600042E RID: 1070 RVA: 0x000174DC File Offset: 0x000156DC
		// Note: this type is marked as 'beforefieldinit'.
		static WallHackDetector()
		{
			Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Detectors", "WallHackDetector");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr);
			WallHackDetector.NativeFieldInfoPtr_COMPONENT_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "COMPONENT_NAME");
			WallHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "FINAL_LOG_PREFIX");
			WallHackDetector.NativeFieldInfoPtr_SERVICE_CONTAINER_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "SERVICE_CONTAINER_NAME");
			WallHackDetector.NativeFieldInfoPtr_WIREFRAME_SHADER_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "WIREFRAME_SHADER_NAME");
			WallHackDetector.NativeFieldInfoPtr_SHADER_TEXTURE_SIZE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "SHADER_TEXTURE_SIZE");
			WallHackDetector.NativeFieldInfoPtr_RENDER_TEXTURE_SIZE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "RENDER_TEXTURE_SIZE");
			WallHackDetector.NativeFieldInfoPtr_rigidPlayerVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "rigidPlayerVelocity");
			WallHackDetector.NativeFieldInfoPtr_instancesInScene = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "instancesInScene");
			WallHackDetector.NativeFieldInfoPtr_waitForEndOfFrame = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "waitForEndOfFrame");
			WallHackDetector.NativeFieldInfoPtr_checkRigidbody = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "checkRigidbody");
			WallHackDetector.NativeFieldInfoPtr_checkController = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "checkController");
			WallHackDetector.NativeFieldInfoPtr_checkWireframe = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "checkWireframe");
			WallHackDetector.NativeFieldInfoPtr_checkRaycast = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "checkRaycast");
			WallHackDetector.NativeFieldInfoPtr_wireframeDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wireframeDelay");
			WallHackDetector.NativeFieldInfoPtr_raycastDelay = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "raycastDelay");
			WallHackDetector.NativeFieldInfoPtr_spawnPosition = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "spawnPosition");
			WallHackDetector.NativeFieldInfoPtr_maxFalsePositives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "maxFalsePositives");
			WallHackDetector.NativeFieldInfoPtr_serviceContainer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "serviceContainer");
			WallHackDetector.NativeFieldInfoPtr_solidWall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "solidWall");
			WallHackDetector.NativeFieldInfoPtr_thinWall = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "thinWall");
			WallHackDetector.NativeFieldInfoPtr_wfCamera = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wfCamera");
			WallHackDetector.NativeFieldInfoPtr_foregroundRenderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "foregroundRenderer");
			WallHackDetector.NativeFieldInfoPtr_backgroundRenderer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "backgroundRenderer");
			WallHackDetector.NativeFieldInfoPtr_wfColor1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wfColor1");
			WallHackDetector.NativeFieldInfoPtr_wfColor2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wfColor2");
			WallHackDetector.NativeFieldInfoPtr_wfShader = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wfShader");
			WallHackDetector.NativeFieldInfoPtr_wfMaterial = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wfMaterial");
			WallHackDetector.NativeFieldInfoPtr_shaderTexture = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "shaderTexture");
			WallHackDetector.NativeFieldInfoPtr_targetTexture = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "targetTexture");
			WallHackDetector.NativeFieldInfoPtr_renderTexture = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "renderTexture");
			WallHackDetector.NativeFieldInfoPtr_whLayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "whLayer");
			WallHackDetector.NativeFieldInfoPtr_raycastMask = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "raycastMask");
			WallHackDetector.NativeFieldInfoPtr_rigidPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "rigidPlayer");
			WallHackDetector.NativeFieldInfoPtr_charControllerPlayer = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "charControllerPlayer");
			WallHackDetector.NativeFieldInfoPtr_charControllerVelocity = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "charControllerVelocity");
			WallHackDetector.NativeFieldInfoPtr_rigidbodyDetections = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "rigidbodyDetections");
			WallHackDetector.NativeFieldInfoPtr_controllerDetections = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "controllerDetections");
			WallHackDetector.NativeFieldInfoPtr_wireframeDetections = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wireframeDetections");
			WallHackDetector.NativeFieldInfoPtr_raycastDetections = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "raycastDetections");
			WallHackDetector.NativeFieldInfoPtr_wireframeDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "wireframeDetected");
			WallHackDetector.NativeFieldInfoPtr__Instance_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "<Instance>k__BackingField");
			WallHackDetector.NativeMethodInfoPtr_get_CheckRigidbody_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663969);
			WallHackDetector.NativeMethodInfoPtr_set_CheckRigidbody_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663970);
			WallHackDetector.NativeMethodInfoPtr_get_CheckController_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663971);
			WallHackDetector.NativeMethodInfoPtr_set_CheckController_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663972);
			WallHackDetector.NativeMethodInfoPtr_get_CheckWireframe_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663973);
			WallHackDetector.NativeMethodInfoPtr_set_CheckWireframe_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663974);
			WallHackDetector.NativeMethodInfoPtr_get_CheckRaycast_Public_get_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663975);
			WallHackDetector.NativeMethodInfoPtr_set_CheckRaycast_Public_set_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663976);
			WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663977);
			WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663978);
			WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663979);
			WallHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663980);
			WallHackDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663981);
			WallHackDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663982);
			WallHackDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_WallHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663983);
			WallHackDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_WallHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663984);
			WallHackDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_WallHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663985);
			WallHackDetector.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663986);
			WallHackDetector.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663987);
			WallHackDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663988);
			WallHackDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663989);
			WallHackDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663990);
			WallHackDetector.NativeMethodInfoPtr_FixedUpdate_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663991);
			WallHackDetector.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663992);
			WallHackDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Vector3_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663993);
			WallHackDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663994);
			WallHackDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663995);
			WallHackDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663996);
			WallHackDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663997);
			WallHackDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663998);
			WallHackDetector.NativeMethodInfoPtr_UpdateServiceContainer_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100663999);
			WallHackDetector.NativeMethodInfoPtr_InitDetector_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664000);
			WallHackDetector.NativeMethodInfoPtr_StartRigidModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664001);
			WallHackDetector.NativeMethodInfoPtr_StartControllerModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664002);
			WallHackDetector.NativeMethodInfoPtr_StartWireframeModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664003);
			WallHackDetector.NativeMethodInfoPtr_ShootWireframeModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664004);
			WallHackDetector.NativeMethodInfoPtr_CaptureFrame_Private_IEnumerator_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664005);
			WallHackDetector.NativeMethodInfoPtr_StartRaycastModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664006);
			WallHackDetector.NativeMethodInfoPtr_ShootRaycastModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664007);
			WallHackDetector.NativeMethodInfoPtr_StopRigidModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664008);
			WallHackDetector.NativeMethodInfoPtr_StopControllerModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664009);
			WallHackDetector.NativeMethodInfoPtr_StopWireframeModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664010);
			WallHackDetector.NativeMethodInfoPtr_StopRaycastModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664011);
			WallHackDetector.NativeMethodInfoPtr_InitRigidModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664012);
			WallHackDetector.NativeMethodInfoPtr_InitControllerModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664013);
			WallHackDetector.NativeMethodInfoPtr_UninitRigidModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664014);
			WallHackDetector.NativeMethodInfoPtr_UninitControllerModule_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664015);
			WallHackDetector.NativeMethodInfoPtr_Detect_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664016);
			WallHackDetector.NativeMethodInfoPtr_GenerateColor_Private_Static_Color32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664017);
			WallHackDetector.NativeMethodInfoPtr_ColorsSimilar_Private_Static_Boolean_Color32_Color32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, 100664018);
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0001490C File Offset: 0x00012B0C
		public WallHackDetector(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000430 RID: 1072 RVA: 0x00017C28 File Offset: 0x00015E28
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr));
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000431 RID: 1073 RVA: 0x00017C3C File Offset: 0x00015E3C
		// (set) Token: 0x06000432 RID: 1074 RVA: 0x00017C5C File Offset: 0x00015E5C
		public unsafe static string COMPONENT_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_COMPONENT_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_COMPONENT_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000433 RID: 1075 RVA: 0x00017C74 File Offset: 0x00015E74
		// (set) Token: 0x06000434 RID: 1076 RVA: 0x00017C94 File Offset: 0x00015E94
		public unsafe static string FINAL_LOG_PREFIX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06000435 RID: 1077 RVA: 0x00017CAC File Offset: 0x00015EAC
		// (set) Token: 0x06000436 RID: 1078 RVA: 0x00017CCC File Offset: 0x00015ECC
		public unsafe static string SERVICE_CONTAINER_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_SERVICE_CONTAINER_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_SERVICE_CONTAINER_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000437 RID: 1079 RVA: 0x00017CE4 File Offset: 0x00015EE4
		// (set) Token: 0x06000438 RID: 1080 RVA: 0x00017D04 File Offset: 0x00015F04
		public unsafe static string WIREFRAME_SHADER_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_WIREFRAME_SHADER_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_WIREFRAME_SHADER_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000439 RID: 1081 RVA: 0x00017D1C File Offset: 0x00015F1C
		// (set) Token: 0x0600043A RID: 1082 RVA: 0x00017D3A File Offset: 0x00015F3A
		public unsafe static int SHADER_TEXTURE_SIZE
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_SHADER_TEXTURE_SIZE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_SHADER_TEXTURE_SIZE, (void*)(&value));
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x00017D4C File Offset: 0x00015F4C
		// (set) Token: 0x0600043C RID: 1084 RVA: 0x00017D6A File Offset: 0x00015F6A
		public unsafe static int RENDER_TEXTURE_SIZE
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_RENDER_TEXTURE_SIZE, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_RENDER_TEXTURE_SIZE, (void*)(&value));
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x00017D7C File Offset: 0x00015F7C
		// (set) Token: 0x0600043E RID: 1086 RVA: 0x00017DA4 File Offset: 0x00015FA4
		public unsafe Vector3 rigidPlayerVelocity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidPlayerVelocity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidPlayerVelocity)) = value;
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x00017DC8 File Offset: 0x00015FC8
		// (set) Token: 0x06000440 RID: 1088 RVA: 0x00017DE6 File Offset: 0x00015FE6
		public unsafe static int instancesInScene
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&value));
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x00017DF8 File Offset: 0x00015FF8
		// (set) Token: 0x06000442 RID: 1090 RVA: 0x00017E2C File Offset: 0x0001602C
		public unsafe WaitForEndOfFrame waitForEndOfFrame
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_waitForEndOfFrame);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new WaitForEndOfFrame(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_waitForEndOfFrame), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x00017E54 File Offset: 0x00016054
		// (set) Token: 0x06000444 RID: 1092 RVA: 0x00017E7C File Offset: 0x0001607C
		public unsafe bool checkRigidbody
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkRigidbody);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkRigidbody)) = value;
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000445 RID: 1093 RVA: 0x00017EA0 File Offset: 0x000160A0
		// (set) Token: 0x06000446 RID: 1094 RVA: 0x00017EC8 File Offset: 0x000160C8
		public unsafe bool checkController
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkController);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkController)) = value;
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x06000447 RID: 1095 RVA: 0x00017EEC File Offset: 0x000160EC
		// (set) Token: 0x06000448 RID: 1096 RVA: 0x00017F14 File Offset: 0x00016114
		public unsafe bool checkWireframe
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkWireframe);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkWireframe)) = value;
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x06000449 RID: 1097 RVA: 0x00017F38 File Offset: 0x00016138
		// (set) Token: 0x0600044A RID: 1098 RVA: 0x00017F60 File Offset: 0x00016160
		public unsafe bool checkRaycast
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkRaycast);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_checkRaycast)) = value;
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x0600044B RID: 1099 RVA: 0x00017F84 File Offset: 0x00016184
		// (set) Token: 0x0600044C RID: 1100 RVA: 0x00017FAC File Offset: 0x000161AC
		public unsafe int wireframeDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDelay)) = value;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x0600044D RID: 1101 RVA: 0x00017FD0 File Offset: 0x000161D0
		// (set) Token: 0x0600044E RID: 1102 RVA: 0x00017FF8 File Offset: 0x000161F8
		public unsafe int raycastDelay
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastDelay);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastDelay)) = value;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x0600044F RID: 1103 RVA: 0x0001801C File Offset: 0x0001621C
		// (set) Token: 0x06000450 RID: 1104 RVA: 0x00018044 File Offset: 0x00016244
		public unsafe Vector3 spawnPosition
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_spawnPosition);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_spawnPosition)) = value;
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000451 RID: 1105 RVA: 0x00018068 File Offset: 0x00016268
		// (set) Token: 0x06000452 RID: 1106 RVA: 0x00018090 File Offset: 0x00016290
		public unsafe byte maxFalsePositives
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_maxFalsePositives);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_maxFalsePositives)) = value;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x06000453 RID: 1107 RVA: 0x000180B4 File Offset: 0x000162B4
		// (set) Token: 0x06000454 RID: 1108 RVA: 0x000180E8 File Offset: 0x000162E8
		public unsafe GameObject serviceContainer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_serviceContainer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_serviceContainer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x06000455 RID: 1109 RVA: 0x00018110 File Offset: 0x00016310
		// (set) Token: 0x06000456 RID: 1110 RVA: 0x00018144 File Offset: 0x00016344
		public unsafe GameObject solidWall
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_solidWall);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_solidWall), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x06000457 RID: 1111 RVA: 0x0001816C File Offset: 0x0001636C
		// (set) Token: 0x06000458 RID: 1112 RVA: 0x000181A0 File Offset: 0x000163A0
		public unsafe GameObject thinWall
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_thinWall);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new GameObject(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_thinWall), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x06000459 RID: 1113 RVA: 0x000181C8 File Offset: 0x000163C8
		// (set) Token: 0x0600045A RID: 1114 RVA: 0x000181FC File Offset: 0x000163FC
		public unsafe Camera wfCamera
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfCamera);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Camera(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfCamera), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x0600045B RID: 1115 RVA: 0x00018224 File Offset: 0x00016424
		// (set) Token: 0x0600045C RID: 1116 RVA: 0x00018258 File Offset: 0x00016458
		public unsafe MeshRenderer foregroundRenderer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_foregroundRenderer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_foregroundRenderer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x0600045D RID: 1117 RVA: 0x00018280 File Offset: 0x00016480
		// (set) Token: 0x0600045E RID: 1118 RVA: 0x000182B4 File Offset: 0x000164B4
		public unsafe MeshRenderer backgroundRenderer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_backgroundRenderer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new MeshRenderer(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_backgroundRenderer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x0600045F RID: 1119 RVA: 0x000182DC File Offset: 0x000164DC
		// (set) Token: 0x06000460 RID: 1120 RVA: 0x00018304 File Offset: 0x00016504
		public unsafe Color wfColor1
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfColor1);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfColor1)) = value;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000461 RID: 1121 RVA: 0x00018328 File Offset: 0x00016528
		// (set) Token: 0x06000462 RID: 1122 RVA: 0x00018350 File Offset: 0x00016550
		public unsafe Color wfColor2
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfColor2);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfColor2)) = value;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x06000463 RID: 1123 RVA: 0x00018374 File Offset: 0x00016574
		// (set) Token: 0x06000464 RID: 1124 RVA: 0x000183A8 File Offset: 0x000165A8
		public unsafe Shader wfShader
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfShader);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Shader(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfShader), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x000183D0 File Offset: 0x000165D0
		// (set) Token: 0x06000466 RID: 1126 RVA: 0x00018404 File Offset: 0x00016604
		public unsafe Material wfMaterial
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfMaterial);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Material(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wfMaterial), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x06000467 RID: 1127 RVA: 0x0001842C File Offset: 0x0001662C
		// (set) Token: 0x06000468 RID: 1128 RVA: 0x00018460 File Offset: 0x00016660
		public unsafe Texture2D shaderTexture
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_shaderTexture);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Texture2D(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_shaderTexture), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000469 RID: 1129 RVA: 0x00018488 File Offset: 0x00016688
		// (set) Token: 0x0600046A RID: 1130 RVA: 0x000184BC File Offset: 0x000166BC
		public unsafe Texture2D targetTexture
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_targetTexture);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Texture2D(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_targetTexture), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x0600046B RID: 1131 RVA: 0x000184E4 File Offset: 0x000166E4
		// (set) Token: 0x0600046C RID: 1132 RVA: 0x00018518 File Offset: 0x00016718
		public unsafe RenderTexture renderTexture
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_renderTexture);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new RenderTexture(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_renderTexture), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x0600046D RID: 1133 RVA: 0x00018540 File Offset: 0x00016740
		// (set) Token: 0x0600046E RID: 1134 RVA: 0x00018568 File Offset: 0x00016768
		public unsafe int whLayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_whLayer);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_whLayer)) = value;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600046F RID: 1135 RVA: 0x0001858C File Offset: 0x0001678C
		// (set) Token: 0x06000470 RID: 1136 RVA: 0x000185B4 File Offset: 0x000167B4
		public unsafe int raycastMask
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastMask);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastMask)) = value;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000471 RID: 1137 RVA: 0x000185D8 File Offset: 0x000167D8
		// (set) Token: 0x06000472 RID: 1138 RVA: 0x0001860C File Offset: 0x0001680C
		public unsafe Rigidbody rigidPlayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidPlayer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Rigidbody(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000473 RID: 1139 RVA: 0x00018634 File Offset: 0x00016834
		// (set) Token: 0x06000474 RID: 1140 RVA: 0x00018668 File Offset: 0x00016868
		public unsafe CharacterController charControllerPlayer
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_charControllerPlayer);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new CharacterController(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_charControllerPlayer), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000475 RID: 1141 RVA: 0x00018690 File Offset: 0x00016890
		// (set) Token: 0x06000476 RID: 1142 RVA: 0x000186B8 File Offset: 0x000168B8
		public unsafe float charControllerVelocity
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_charControllerVelocity);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_charControllerVelocity)) = value;
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000477 RID: 1143 RVA: 0x000186DC File Offset: 0x000168DC
		// (set) Token: 0x06000478 RID: 1144 RVA: 0x00018704 File Offset: 0x00016904
		public unsafe byte rigidbodyDetections
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidbodyDetections);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_rigidbodyDetections)) = value;
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000479 RID: 1145 RVA: 0x00018728 File Offset: 0x00016928
		// (set) Token: 0x0600047A RID: 1146 RVA: 0x00018750 File Offset: 0x00016950
		public unsafe byte controllerDetections
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_controllerDetections);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_controllerDetections)) = value;
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x0600047B RID: 1147 RVA: 0x00018774 File Offset: 0x00016974
		// (set) Token: 0x0600047C RID: 1148 RVA: 0x0001879C File Offset: 0x0001699C
		public unsafe byte wireframeDetections
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDetections);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDetections)) = value;
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600047D RID: 1149 RVA: 0x000187C0 File Offset: 0x000169C0
		// (set) Token: 0x0600047E RID: 1150 RVA: 0x000187E8 File Offset: 0x000169E8
		public unsafe byte raycastDetections
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastDetections);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_raycastDetections)) = value;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600047F RID: 1151 RVA: 0x0001880C File Offset: 0x00016A0C
		// (set) Token: 0x06000480 RID: 1152 RVA: 0x00018834 File Offset: 0x00016A34
		public unsafe bool wireframeDetected
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDetected);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector.NativeFieldInfoPtr_wireframeDetected)) = value;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000481 RID: 1153 RVA: 0x00018858 File Offset: 0x00016A58
		// (set) Token: 0x06000482 RID: 1154 RVA: 0x00018883 File Offset: 0x00016A83
		public unsafe static WallHackDetector _Instance_k__BackingField
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(WallHackDetector.NativeFieldInfoPtr__Instance_k__BackingField, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new WallHackDetector(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(WallHackDetector.NativeFieldInfoPtr__Instance_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x040003B7 RID: 951
		private static readonly IntPtr NativeFieldInfoPtr_COMPONENT_NAME;

		// Token: 0x040003B8 RID: 952
		private static readonly IntPtr NativeFieldInfoPtr_FINAL_LOG_PREFIX;

		// Token: 0x040003B9 RID: 953
		private static readonly IntPtr NativeFieldInfoPtr_SERVICE_CONTAINER_NAME;

		// Token: 0x040003BA RID: 954
		private static readonly IntPtr NativeFieldInfoPtr_WIREFRAME_SHADER_NAME;

		// Token: 0x040003BB RID: 955
		private static readonly IntPtr NativeFieldInfoPtr_SHADER_TEXTURE_SIZE;

		// Token: 0x040003BC RID: 956
		private static readonly IntPtr NativeFieldInfoPtr_RENDER_TEXTURE_SIZE;

		// Token: 0x040003BD RID: 957
		private static readonly IntPtr NativeFieldInfoPtr_rigidPlayerVelocity;

		// Token: 0x040003BE RID: 958
		private static readonly IntPtr NativeFieldInfoPtr_instancesInScene;

		// Token: 0x040003BF RID: 959
		private static readonly IntPtr NativeFieldInfoPtr_waitForEndOfFrame;

		// Token: 0x040003C0 RID: 960
		private static readonly IntPtr NativeFieldInfoPtr_checkRigidbody;

		// Token: 0x040003C1 RID: 961
		private static readonly IntPtr NativeFieldInfoPtr_checkController;

		// Token: 0x040003C2 RID: 962
		private static readonly IntPtr NativeFieldInfoPtr_checkWireframe;

		// Token: 0x040003C3 RID: 963
		private static readonly IntPtr NativeFieldInfoPtr_checkRaycast;

		// Token: 0x040003C4 RID: 964
		private static readonly IntPtr NativeFieldInfoPtr_wireframeDelay;

		// Token: 0x040003C5 RID: 965
		private static readonly IntPtr NativeFieldInfoPtr_raycastDelay;

		// Token: 0x040003C6 RID: 966
		private static readonly IntPtr NativeFieldInfoPtr_spawnPosition;

		// Token: 0x040003C7 RID: 967
		private static readonly IntPtr NativeFieldInfoPtr_maxFalsePositives;

		// Token: 0x040003C8 RID: 968
		private static readonly IntPtr NativeFieldInfoPtr_serviceContainer;

		// Token: 0x040003C9 RID: 969
		private static readonly IntPtr NativeFieldInfoPtr_solidWall;

		// Token: 0x040003CA RID: 970
		private static readonly IntPtr NativeFieldInfoPtr_thinWall;

		// Token: 0x040003CB RID: 971
		private static readonly IntPtr NativeFieldInfoPtr_wfCamera;

		// Token: 0x040003CC RID: 972
		private static readonly IntPtr NativeFieldInfoPtr_foregroundRenderer;

		// Token: 0x040003CD RID: 973
		private static readonly IntPtr NativeFieldInfoPtr_backgroundRenderer;

		// Token: 0x040003CE RID: 974
		private static readonly IntPtr NativeFieldInfoPtr_wfColor1;

		// Token: 0x040003CF RID: 975
		private static readonly IntPtr NativeFieldInfoPtr_wfColor2;

		// Token: 0x040003D0 RID: 976
		private static readonly IntPtr NativeFieldInfoPtr_wfShader;

		// Token: 0x040003D1 RID: 977
		private static readonly IntPtr NativeFieldInfoPtr_wfMaterial;

		// Token: 0x040003D2 RID: 978
		private static readonly IntPtr NativeFieldInfoPtr_shaderTexture;

		// Token: 0x040003D3 RID: 979
		private static readonly IntPtr NativeFieldInfoPtr_targetTexture;

		// Token: 0x040003D4 RID: 980
		private static readonly IntPtr NativeFieldInfoPtr_renderTexture;

		// Token: 0x040003D5 RID: 981
		private static readonly IntPtr NativeFieldInfoPtr_whLayer;

		// Token: 0x040003D6 RID: 982
		private static readonly IntPtr NativeFieldInfoPtr_raycastMask;

		// Token: 0x040003D7 RID: 983
		private static readonly IntPtr NativeFieldInfoPtr_rigidPlayer;

		// Token: 0x040003D8 RID: 984
		private static readonly IntPtr NativeFieldInfoPtr_charControllerPlayer;

		// Token: 0x040003D9 RID: 985
		private static readonly IntPtr NativeFieldInfoPtr_charControllerVelocity;

		// Token: 0x040003DA RID: 986
		private static readonly IntPtr NativeFieldInfoPtr_rigidbodyDetections;

		// Token: 0x040003DB RID: 987
		private static readonly IntPtr NativeFieldInfoPtr_controllerDetections;

		// Token: 0x040003DC RID: 988
		private static readonly IntPtr NativeFieldInfoPtr_wireframeDetections;

		// Token: 0x040003DD RID: 989
		private static readonly IntPtr NativeFieldInfoPtr_raycastDetections;

		// Token: 0x040003DE RID: 990
		private static readonly IntPtr NativeFieldInfoPtr_wireframeDetected;

		// Token: 0x040003DF RID: 991
		private static readonly IntPtr NativeFieldInfoPtr__Instance_k__BackingField;

		// Token: 0x040003E0 RID: 992
		private static readonly IntPtr NativeMethodInfoPtr_get_CheckRigidbody_Public_get_Boolean_0;

		// Token: 0x040003E1 RID: 993
		private static readonly IntPtr NativeMethodInfoPtr_set_CheckRigidbody_Public_set_Void_Boolean_0;

		// Token: 0x040003E2 RID: 994
		private static readonly IntPtr NativeMethodInfoPtr_get_CheckController_Public_get_Boolean_0;

		// Token: 0x040003E3 RID: 995
		private static readonly IntPtr NativeMethodInfoPtr_set_CheckController_Public_set_Void_Boolean_0;

		// Token: 0x040003E4 RID: 996
		private static readonly IntPtr NativeMethodInfoPtr_get_CheckWireframe_Public_get_Boolean_0;

		// Token: 0x040003E5 RID: 997
		private static readonly IntPtr NativeMethodInfoPtr_set_CheckWireframe_Public_set_Void_Boolean_0;

		// Token: 0x040003E6 RID: 998
		private static readonly IntPtr NativeMethodInfoPtr_get_CheckRaycast_Public_get_Boolean_0;

		// Token: 0x040003E7 RID: 999
		private static readonly IntPtr NativeMethodInfoPtr_set_CheckRaycast_Public_set_Void_Boolean_0;

		// Token: 0x040003E8 RID: 1000
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_0;

		// Token: 0x040003E9 RID: 1001
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0;

		// Token: 0x040003EA RID: 1002
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_0;

		// Token: 0x040003EB RID: 1003
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Vector3_Byte_0;

		// Token: 0x040003EC RID: 1004
		private static readonly IntPtr NativeMethodInfoPtr_StopDetection_Public_Static_Void_0;

		// Token: 0x040003ED RID: 1005
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Static_Void_0;

		// Token: 0x040003EE RID: 1006
		private static readonly IntPtr NativeMethodInfoPtr_get_Instance_Public_Static_get_WallHackDetector_0;

		// Token: 0x040003EF RID: 1007
		private static readonly IntPtr NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_WallHackDetector_0;

		// Token: 0x040003F0 RID: 1008
		private static readonly IntPtr NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_WallHackDetector_0;

		// Token: 0x040003F1 RID: 1009
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

		// Token: 0x040003F2 RID: 1010
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x040003F3 RID: 1011
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0;

		// Token: 0x040003F4 RID: 1012
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0;

		// Token: 0x040003F5 RID: 1013
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0;

		// Token: 0x040003F6 RID: 1014
		private static readonly IntPtr NativeMethodInfoPtr_FixedUpdate_Private_Void_0;

		// Token: 0x040003F7 RID: 1015
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x040003F8 RID: 1016
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Vector3_Byte_0;

		// Token: 0x040003F9 RID: 1017
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0;

		// Token: 0x040003FA RID: 1018
		private static readonly IntPtr NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0;

		// Token: 0x040003FB RID: 1019
		private static readonly IntPtr NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0;

		// Token: 0x040003FC RID: 1020
		private static readonly IntPtr NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0;

		// Token: 0x040003FD RID: 1021
		private static readonly IntPtr NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0;

		// Token: 0x040003FE RID: 1022
		private static readonly IntPtr NativeMethodInfoPtr_UpdateServiceContainer_Private_Void_0;

		// Token: 0x040003FF RID: 1023
		private static readonly IntPtr NativeMethodInfoPtr_InitDetector_Private_IEnumerator_0;

		// Token: 0x04000400 RID: 1024
		private static readonly IntPtr NativeMethodInfoPtr_StartRigidModule_Private_Void_0;

		// Token: 0x04000401 RID: 1025
		private static readonly IntPtr NativeMethodInfoPtr_StartControllerModule_Private_Void_0;

		// Token: 0x04000402 RID: 1026
		private static readonly IntPtr NativeMethodInfoPtr_StartWireframeModule_Private_Void_0;

		// Token: 0x04000403 RID: 1027
		private static readonly IntPtr NativeMethodInfoPtr_ShootWireframeModule_Private_Void_0;

		// Token: 0x04000404 RID: 1028
		private static readonly IntPtr NativeMethodInfoPtr_CaptureFrame_Private_IEnumerator_0;

		// Token: 0x04000405 RID: 1029
		private static readonly IntPtr NativeMethodInfoPtr_StartRaycastModule_Private_Void_0;

		// Token: 0x04000406 RID: 1030
		private static readonly IntPtr NativeMethodInfoPtr_ShootRaycastModule_Private_Void_0;

		// Token: 0x04000407 RID: 1031
		private static readonly IntPtr NativeMethodInfoPtr_StopRigidModule_Private_Void_0;

		// Token: 0x04000408 RID: 1032
		private static readonly IntPtr NativeMethodInfoPtr_StopControllerModule_Private_Void_0;

		// Token: 0x04000409 RID: 1033
		private static readonly IntPtr NativeMethodInfoPtr_StopWireframeModule_Private_Void_0;

		// Token: 0x0400040A RID: 1034
		private static readonly IntPtr NativeMethodInfoPtr_StopRaycastModule_Private_Void_0;

		// Token: 0x0400040B RID: 1035
		private static readonly IntPtr NativeMethodInfoPtr_InitRigidModule_Private_Void_0;

		// Token: 0x0400040C RID: 1036
		private static readonly IntPtr NativeMethodInfoPtr_InitControllerModule_Private_Void_0;

		// Token: 0x0400040D RID: 1037
		private static readonly IntPtr NativeMethodInfoPtr_UninitRigidModule_Private_Void_0;

		// Token: 0x0400040E RID: 1038
		private static readonly IntPtr NativeMethodInfoPtr_UninitControllerModule_Private_Void_0;

		// Token: 0x0400040F RID: 1039
		private static readonly IntPtr NativeMethodInfoPtr_Detect_Private_Boolean_0;

		// Token: 0x04000410 RID: 1040
		private static readonly IntPtr NativeMethodInfoPtr_GenerateColor_Private_Static_Color32_0;

		// Token: 0x04000411 RID: 1041
		private static readonly IntPtr NativeMethodInfoPtr_ColorsSimilar_Private_Static_Boolean_Color32_Color32_Int32_0;

		// Token: 0x0200002E RID: 46
		[ObfuscatedName("CodeStage.AntiCheat.Detectors.WallHackDetector/<InitDetector>d__78")]
		public sealed class _InitDetector_d__78 : Il2CppSystem.Object
		{
			// Token: 0x06000483 RID: 1155 RVA: 0x00018898 File Offset: 0x00016A98
			[CallerCount(0)]
			public unsafe _InitDetector_d__78(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000484 RID: 1156 RVA: 0x000188F8 File Offset: 0x00016AF8
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000485 RID: 1157 RVA: 0x0001893C File Offset: 0x00016B3C
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x170000F4 RID: 244
			// (get) Token: 0x06000486 RID: 1158 RVA: 0x0001898C File Offset: 0x00016B8C
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06000487 RID: 1159 RVA: 0x000189E4 File Offset: 0x00016BE4
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x170000F5 RID: 245
			// (get) Token: 0x06000488 RID: 1160 RVA: 0x00018A28 File Offset: 0x00016C28
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06000489 RID: 1161 RVA: 0x00018A80 File Offset: 0x00016C80
			// Note: this type is marked as 'beforefieldinit'.
			static _InitDetector_d__78()
			{
				Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "<InitDetector>d__78");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr);
				WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, "<>1__state");
				WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, "<>2__current");
				WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, "<>4__this");
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664019);
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664020);
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664021);
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664022);
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664023);
				WallHackDetector._InitDetector_d__78.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr, 100664024);
			}

			// Token: 0x0600048A RID: 1162 RVA: 0x00002580 File Offset: 0x00000780
			public _InitDetector_d__78(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170000F0 RID: 240
			// (get) Token: 0x0600048B RID: 1163 RVA: 0x00018B5F File Offset: 0x00016D5F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<WallHackDetector._InitDetector_d__78>.NativeClassPtr));
				}
			}

			// Token: 0x170000F1 RID: 241
			// (get) Token: 0x0600048C RID: 1164 RVA: 0x00018B70 File Offset: 0x00016D70
			// (set) Token: 0x0600048D RID: 1165 RVA: 0x00018B98 File Offset: 0x00016D98
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x170000F2 RID: 242
			// (get) Token: 0x0600048E RID: 1166 RVA: 0x00018BBC File Offset: 0x00016DBC
			// (set) Token: 0x0600048F RID: 1167 RVA: 0x00018BF0 File Offset: 0x00016DF0
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170000F3 RID: 243
			// (get) Token: 0x06000490 RID: 1168 RVA: 0x00018C18 File Offset: 0x00016E18
			// (set) Token: 0x06000491 RID: 1169 RVA: 0x00018C4C File Offset: 0x00016E4C
			public unsafe WallHackDetector __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new WallHackDetector(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._InitDetector_d__78.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x04000412 RID: 1042
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x04000413 RID: 1043
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x04000414 RID: 1044
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x04000415 RID: 1045
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x04000416 RID: 1046
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x04000417 RID: 1047
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x04000418 RID: 1048
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x04000419 RID: 1049
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x0400041A RID: 1050
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}

		// Token: 0x0200002F RID: 47
		[ObfuscatedName("CodeStage.AntiCheat.Detectors.WallHackDetector/<CaptureFrame>d__83")]
		public sealed class _CaptureFrame_d__83 : Il2CppSystem.Object
		{
			// Token: 0x06000492 RID: 1170 RVA: 0x00018C74 File Offset: 0x00016E74
			[CallerCount(0)]
			public unsafe _CaptureFrame_d__83(int <>1__state) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref <>1__state;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr__ctor_Public_Void_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000493 RID: 1171 RVA: 0x00018CD4 File Offset: 0x00016ED4
			[CallerCount(0)]
			public unsafe void System_IDisposable_Dispose()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000494 RID: 1172 RVA: 0x00018D18 File Offset: 0x00016F18
			[CallerCount(0)]
			public unsafe bool MoveNext()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}

			// Token: 0x170000FB RID: 251
			// (get) Token: 0x06000495 RID: 1173 RVA: 0x00018D68 File Offset: 0x00016F68
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06000496 RID: 1174 RVA: 0x00018DC0 File Offset: 0x00016FC0
			[CallerCount(0)]
			public unsafe void System_Collections_IEnumerator_Reset()
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x170000FC RID: 252
			// (get) Token: 0x06000497 RID: 1175 RVA: 0x00018E04 File Offset: 0x00017004
			public unsafe Il2CppSystem.Object Current
			{
				[CallerCount(0)]
				get
				{
					IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IntPtr* param = null;
					IntPtr returnedException;
					IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
					Il2CppException.RaiseExceptionIfNecessary(returnedException);
					IntPtr intPtr2 = intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
			}

			// Token: 0x06000498 RID: 1176 RVA: 0x00018E5C File Offset: 0x0001705C
			// Note: this type is marked as 'beforefieldinit'.
			static _CaptureFrame_d__83()
			{
				Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<WallHackDetector>.NativeClassPtr, "<CaptureFrame>d__83");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr);
				WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___1__state = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, "<>1__state");
				WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___2__current = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, "<>2__current");
				WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___4__this = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, "<>4__this");
				WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr__previousActive_5__2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, "<previousActive>5__2");
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr__ctor_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664025);
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664026);
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664027);
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664028);
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664029);
				WallHackDetector._CaptureFrame_d__83.NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr, 100664030);
			}

			// Token: 0x06000499 RID: 1177 RVA: 0x00002580 File Offset: 0x00000780
			public _CaptureFrame_d__83(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x170000F6 RID: 246
			// (get) Token: 0x0600049A RID: 1178 RVA: 0x00018F4F File Offset: 0x0001714F
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<WallHackDetector._CaptureFrame_d__83>.NativeClassPtr));
				}
			}

			// Token: 0x170000F7 RID: 247
			// (get) Token: 0x0600049B RID: 1179 RVA: 0x00018F60 File Offset: 0x00017160
			// (set) Token: 0x0600049C RID: 1180 RVA: 0x00018F88 File Offset: 0x00017188
			public unsafe int __1__state
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___1__state);
					return *intPtr;
				}
				set
				{
					*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___1__state)) = value;
				}
			}

			// Token: 0x170000F8 RID: 248
			// (get) Token: 0x0600049D RID: 1181 RVA: 0x00018FAC File Offset: 0x000171AC
			// (set) Token: 0x0600049E RID: 1182 RVA: 0x00018FE0 File Offset: 0x000171E0
			public unsafe Il2CppSystem.Object __2__current
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___2__current);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppSystem.Object(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___2__current), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170000F9 RID: 249
			// (get) Token: 0x0600049F RID: 1183 RVA: 0x00019008 File Offset: 0x00017208
			// (set) Token: 0x060004A0 RID: 1184 RVA: 0x0001903C File Offset: 0x0001723C
			public unsafe WallHackDetector __4__this
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___4__this);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new WallHackDetector(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr___4__this), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x170000FA RID: 250
			// (get) Token: 0x060004A1 RID: 1185 RVA: 0x00019064 File Offset: 0x00017264
			// (set) Token: 0x060004A2 RID: 1186 RVA: 0x00019098 File Offset: 0x00017298
			public unsafe RenderTexture _previousActive_5__2
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr__previousActive_5__2);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new RenderTexture(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(WallHackDetector._CaptureFrame_d__83.NativeFieldInfoPtr__previousActive_5__2), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x0400041B RID: 1051
			private static readonly IntPtr NativeFieldInfoPtr___1__state;

			// Token: 0x0400041C RID: 1052
			private static readonly IntPtr NativeFieldInfoPtr___2__current;

			// Token: 0x0400041D RID: 1053
			private static readonly IntPtr NativeFieldInfoPtr___4__this;

			// Token: 0x0400041E RID: 1054
			private static readonly IntPtr NativeFieldInfoPtr__previousActive_5__2;

			// Token: 0x0400041F RID: 1055
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Int32_0;

			// Token: 0x04000420 RID: 1056
			private static readonly IntPtr NativeMethodInfoPtr_System_IDisposable_Dispose_Private_Virtual_Final_New_Void_0;

			// Token: 0x04000421 RID: 1057
			private static readonly IntPtr NativeMethodInfoPtr_MoveNext_Private_Virtual_Final_New_Boolean_0;

			// Token: 0x04000422 RID: 1058
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_Generic_IEnumerator_System_Object__get_Current_Private_Virtual_Final_New_get_Object_0;

			// Token: 0x04000423 RID: 1059
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_Reset_Private_Virtual_Final_New_Void_0;

			// Token: 0x04000424 RID: 1060
			private static readonly IntPtr NativeMethodInfoPtr_System_Collections_IEnumerator_get_Current_Private_Virtual_Final_New_get_Object_0;
		}
	}
}
