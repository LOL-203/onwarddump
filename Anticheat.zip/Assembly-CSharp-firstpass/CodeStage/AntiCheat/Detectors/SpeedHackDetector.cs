﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace CodeStage.AntiCheat.Detectors
{
	// Token: 0x0200002C RID: 44
	public class SpeedHackDetector : ActDetectorBase
	{
		// Token: 0x060003C3 RID: 963 RVA: 0x000156F8 File Offset: 0x000138F8
		[CallerCount(0)]
		public unsafe static void StartDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0001572C File Offset: 0x0001392C
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00015778 File Offset: 0x00013978
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback, float interval)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref interval;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x000157D8 File Offset: 0x000139D8
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback, float interval, byte maxFalsePositives)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref interval;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxFalsePositives;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x00015848 File Offset: 0x00013A48
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback, float interval, byte maxFalsePositives, int coolDown)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref interval;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref maxFalsePositives;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref coolDown;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x000158CC File Offset: 0x00013ACC
		[CallerCount(0)]
		public unsafe static void StopDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00015900 File Offset: 0x00013B00
		[CallerCount(0)]
		public unsafe static void Dispose()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060003CA RID: 970 RVA: 0x00015934 File Offset: 0x00013B34
		// (set) Token: 0x060003CB RID: 971 RVA: 0x0001597C File Offset: 0x00013B7C
		public unsafe static SpeedHackDetector Instance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_SpeedHackDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new SpeedHackDetector(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_SpeedHackDetector_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060003CC RID: 972 RVA: 0x000159C8 File Offset: 0x00013BC8
		public unsafe static SpeedHackDetector GetOrCreateInstance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_SpeedHackDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new SpeedHackDetector(intPtr2) : null;
			}
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00015A10 File Offset: 0x00013C10
		[CallerCount(0)]
		public unsafe SpeedHackDetector() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00015A5C File Offset: 0x00013C5C
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x00015AA0 File Offset: 0x00013CA0
		[CallerCount(0)]
		public new unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x00015AF0 File Offset: 0x00013CF0
		[CallerCount(0)]
		public unsafe void OnLevelWasLoadedNew(Scene scene, LoadSceneMode mode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref scene;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref mode;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x00015B58 File Offset: 0x00013D58
		[CallerCount(0)]
		public unsafe void OnLevelLoadedCallback()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00015B9C File Offset: 0x00013D9C
		[CallerCount(0)]
		public unsafe void OnApplicationPause(bool pause)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref pause;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x00015BF0 File Offset: 0x00013DF0
		[CallerCount(0)]
		public unsafe void Update()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_Update_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x00015C34 File Offset: 0x00013E34
		[CallerCount(0)]
		public unsafe void StartDetectionInternal(UnityAction callback, float checkInterval, byte falsePositives, int shotsTillCooldown)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref checkInterval;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref falsePositives;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref shotsTillCooldown;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Single_Byte_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00015CC8 File Offset: 0x00013EC8
		[CallerCount(0)]
		public new unsafe void StartDetectionAutomatically()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00015D18 File Offset: 0x00013F18
		[CallerCount(0)]
		public new unsafe void PauseDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00015D68 File Offset: 0x00013F68
		[CallerCount(0)]
		public new unsafe void ResumeDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00015DB8 File Offset: 0x00013FB8
		[CallerCount(0)]
		public new unsafe void StopDetectionInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00015E08 File Offset: 0x00014008
		[CallerCount(0)]
		public new unsafe void DisposeInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), SpeedHackDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00015E58 File Offset: 0x00014058
		[CallerCount(0)]
		public unsafe void ResetStartTicks()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(SpeedHackDetector.NativeMethodInfoPtr_ResetStartTicks_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00015E9C File Offset: 0x0001409C
		// Note: this type is marked as 'beforefieldinit'.
		static SpeedHackDetector()
		{
			Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Detectors", "SpeedHackDetector");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr);
			SpeedHackDetector.NativeFieldInfoPtr_COMPONENT_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "COMPONENT_NAME");
			SpeedHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "FINAL_LOG_PREFIX");
			SpeedHackDetector.NativeFieldInfoPtr_TICKS_PER_SECOND = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "TICKS_PER_SECOND");
			SpeedHackDetector.NativeFieldInfoPtr_THRESHOLD = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "THRESHOLD");
			SpeedHackDetector.NativeFieldInfoPtr_instancesInScene = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "instancesInScene");
			SpeedHackDetector.NativeFieldInfoPtr_interval = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "interval");
			SpeedHackDetector.NativeFieldInfoPtr_maxFalsePositives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "maxFalsePositives");
			SpeedHackDetector.NativeFieldInfoPtr_coolDown = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "coolDown");
			SpeedHackDetector.NativeFieldInfoPtr_currentFalsePositives = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "currentFalsePositives");
			SpeedHackDetector.NativeFieldInfoPtr_currentCooldownShots = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "currentCooldownShots");
			SpeedHackDetector.NativeFieldInfoPtr_ticksOnStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "ticksOnStart");
			SpeedHackDetector.NativeFieldInfoPtr_vulnerableTicksOnStart = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "vulnerableTicksOnStart");
			SpeedHackDetector.NativeFieldInfoPtr_prevTicks = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "prevTicks");
			SpeedHackDetector.NativeFieldInfoPtr_prevIntervalTicks = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "prevIntervalTicks");
			SpeedHackDetector.NativeFieldInfoPtr__Instance_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, "<Instance>k__BackingField");
			SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663945);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663946);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663947);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663948);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663949);
			SpeedHackDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663950);
			SpeedHackDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663951);
			SpeedHackDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_SpeedHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663952);
			SpeedHackDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_SpeedHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663953);
			SpeedHackDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_SpeedHackDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663954);
			SpeedHackDetector.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663955);
			SpeedHackDetector.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663956);
			SpeedHackDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663957);
			SpeedHackDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663958);
			SpeedHackDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663959);
			SpeedHackDetector.NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663960);
			SpeedHackDetector.NativeMethodInfoPtr_Update_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663961);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Single_Byte_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663962);
			SpeedHackDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663963);
			SpeedHackDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663964);
			SpeedHackDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663965);
			SpeedHackDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663966);
			SpeedHackDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663967);
			SpeedHackDetector.NativeMethodInfoPtr_ResetStartTicks_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr, 100663968);
		}

		// Token: 0x060003DC RID: 988 RVA: 0x0001490C File Offset: 0x00012B0C
		public SpeedHackDetector(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060003DD RID: 989 RVA: 0x000161D8 File Offset: 0x000143D8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<SpeedHackDetector>.NativeClassPtr));
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060003DE RID: 990 RVA: 0x000161EC File Offset: 0x000143EC
		// (set) Token: 0x060003DF RID: 991 RVA: 0x0001620C File Offset: 0x0001440C
		public unsafe static string COMPONENT_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr_COMPONENT_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr_COMPONENT_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x060003E0 RID: 992 RVA: 0x00016224 File Offset: 0x00014424
		// (set) Token: 0x060003E1 RID: 993 RVA: 0x00016244 File Offset: 0x00014444
		public unsafe static string FINAL_LOG_PREFIX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060003E2 RID: 994 RVA: 0x0001625C File Offset: 0x0001445C
		// (set) Token: 0x060003E3 RID: 995 RVA: 0x0001627A File Offset: 0x0001447A
		public unsafe static long TICKS_PER_SECOND
		{
			get
			{
				long result;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr_TICKS_PER_SECOND, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr_TICKS_PER_SECOND, (void*)(&value));
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060003E4 RID: 996 RVA: 0x0001628C File Offset: 0x0001448C
		// (set) Token: 0x060003E5 RID: 997 RVA: 0x000162AA File Offset: 0x000144AA
		public unsafe static int THRESHOLD
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr_THRESHOLD, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr_THRESHOLD, (void*)(&value));
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060003E6 RID: 998 RVA: 0x000162BC File Offset: 0x000144BC
		// (set) Token: 0x060003E7 RID: 999 RVA: 0x000162DA File Offset: 0x000144DA
		public unsafe static int instancesInScene
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&value));
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060003E8 RID: 1000 RVA: 0x000162EC File Offset: 0x000144EC
		// (set) Token: 0x060003E9 RID: 1001 RVA: 0x00016314 File Offset: 0x00014514
		public unsafe float interval
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_interval);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_interval)) = value;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060003EA RID: 1002 RVA: 0x00016338 File Offset: 0x00014538
		// (set) Token: 0x060003EB RID: 1003 RVA: 0x00016360 File Offset: 0x00014560
		public unsafe byte maxFalsePositives
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_maxFalsePositives);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_maxFalsePositives)) = value;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060003EC RID: 1004 RVA: 0x00016384 File Offset: 0x00014584
		// (set) Token: 0x060003ED RID: 1005 RVA: 0x000163AC File Offset: 0x000145AC
		public unsafe int coolDown
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_coolDown);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_coolDown)) = value;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x000163D0 File Offset: 0x000145D0
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x000163F8 File Offset: 0x000145F8
		public unsafe byte currentFalsePositives
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_currentFalsePositives);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_currentFalsePositives)) = value;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x0001641C File Offset: 0x0001461C
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x00016444 File Offset: 0x00014644
		public unsafe int currentCooldownShots
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_currentCooldownShots);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_currentCooldownShots)) = value;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x00016468 File Offset: 0x00014668
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x00016490 File Offset: 0x00014690
		public unsafe long ticksOnStart
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_ticksOnStart);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_ticksOnStart)) = value;
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x000164B4 File Offset: 0x000146B4
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x000164DC File Offset: 0x000146DC
		public unsafe long vulnerableTicksOnStart
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_vulnerableTicksOnStart);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_vulnerableTicksOnStart)) = value;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x00016500 File Offset: 0x00014700
		// (set) Token: 0x060003F7 RID: 1015 RVA: 0x00016528 File Offset: 0x00014728
		public unsafe long prevTicks
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_prevTicks);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_prevTicks)) = value;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x0001654C File Offset: 0x0001474C
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x00016574 File Offset: 0x00014774
		public unsafe long prevIntervalTicks
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_prevIntervalTicks);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(SpeedHackDetector.NativeFieldInfoPtr_prevIntervalTicks)) = value;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x00016598 File Offset: 0x00014798
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x000165C3 File Offset: 0x000147C3
		public unsafe static SpeedHackDetector _Instance_k__BackingField
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(SpeedHackDetector.NativeFieldInfoPtr__Instance_k__BackingField, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new SpeedHackDetector(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(SpeedHackDetector.NativeFieldInfoPtr__Instance_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000390 RID: 912
		private static readonly IntPtr NativeFieldInfoPtr_COMPONENT_NAME;

		// Token: 0x04000391 RID: 913
		private static readonly IntPtr NativeFieldInfoPtr_FINAL_LOG_PREFIX;

		// Token: 0x04000392 RID: 914
		private static readonly IntPtr NativeFieldInfoPtr_TICKS_PER_SECOND;

		// Token: 0x04000393 RID: 915
		private static readonly IntPtr NativeFieldInfoPtr_THRESHOLD;

		// Token: 0x04000394 RID: 916
		private static readonly IntPtr NativeFieldInfoPtr_instancesInScene;

		// Token: 0x04000395 RID: 917
		private static readonly IntPtr NativeFieldInfoPtr_interval;

		// Token: 0x04000396 RID: 918
		private static readonly IntPtr NativeFieldInfoPtr_maxFalsePositives;

		// Token: 0x04000397 RID: 919
		private static readonly IntPtr NativeFieldInfoPtr_coolDown;

		// Token: 0x04000398 RID: 920
		private static readonly IntPtr NativeFieldInfoPtr_currentFalsePositives;

		// Token: 0x04000399 RID: 921
		private static readonly IntPtr NativeFieldInfoPtr_currentCooldownShots;

		// Token: 0x0400039A RID: 922
		private static readonly IntPtr NativeFieldInfoPtr_ticksOnStart;

		// Token: 0x0400039B RID: 923
		private static readonly IntPtr NativeFieldInfoPtr_vulnerableTicksOnStart;

		// Token: 0x0400039C RID: 924
		private static readonly IntPtr NativeFieldInfoPtr_prevTicks;

		// Token: 0x0400039D RID: 925
		private static readonly IntPtr NativeFieldInfoPtr_prevIntervalTicks;

		// Token: 0x0400039E RID: 926
		private static readonly IntPtr NativeFieldInfoPtr__Instance_k__BackingField;

		// Token: 0x0400039F RID: 927
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_0;

		// Token: 0x040003A0 RID: 928
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0;

		// Token: 0x040003A1 RID: 929
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_0;

		// Token: 0x040003A2 RID: 930
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_0;

		// Token: 0x040003A3 RID: 931
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_Single_Byte_Int32_0;

		// Token: 0x040003A4 RID: 932
		private static readonly IntPtr NativeMethodInfoPtr_StopDetection_Public_Static_Void_0;

		// Token: 0x040003A5 RID: 933
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Static_Void_0;

		// Token: 0x040003A6 RID: 934
		private static readonly IntPtr NativeMethodInfoPtr_get_Instance_Public_Static_get_SpeedHackDetector_0;

		// Token: 0x040003A7 RID: 935
		private static readonly IntPtr NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_SpeedHackDetector_0;

		// Token: 0x040003A8 RID: 936
		private static readonly IntPtr NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_SpeedHackDetector_0;

		// Token: 0x040003A9 RID: 937
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

		// Token: 0x040003AA RID: 938
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x040003AB RID: 939
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0;

		// Token: 0x040003AC RID: 940
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0;

		// Token: 0x040003AD RID: 941
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0;

		// Token: 0x040003AE RID: 942
		private static readonly IntPtr NativeMethodInfoPtr_OnApplicationPause_Private_Void_Boolean_0;

		// Token: 0x040003AF RID: 943
		private static readonly IntPtr NativeMethodInfoPtr_Update_Private_Void_0;

		// Token: 0x040003B0 RID: 944
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_Single_Byte_Int32_0;

		// Token: 0x040003B1 RID: 945
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0;

		// Token: 0x040003B2 RID: 946
		private static readonly IntPtr NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0;

		// Token: 0x040003B3 RID: 947
		private static readonly IntPtr NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0;

		// Token: 0x040003B4 RID: 948
		private static readonly IntPtr NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0;

		// Token: 0x040003B5 RID: 949
		private static readonly IntPtr NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0;

		// Token: 0x040003B6 RID: 950
		private static readonly IntPtr NativeMethodInfoPtr_ResetStartTicks_Private_Void_0;
	}
}
