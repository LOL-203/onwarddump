﻿using System;
using Il2CppSystem;
using Il2CppSystem.Reflection;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace CodeStage.AntiCheat.Detectors
{
	// Token: 0x02000029 RID: 41
	public class InjectionDetector : ActDetectorBase
	{
		// Token: 0x06000368 RID: 872 RVA: 0x00013DCC File Offset: 0x00011FCC
		[CallerCount(0)]
		public unsafe static void StartDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000369 RID: 873 RVA: 0x00013E00 File Offset: 0x00012000
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction callback)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00013E4C File Offset: 0x0001204C
		[CallerCount(0)]
		public unsafe static void StartDetection(UnityAction<string> callback)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_1_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00013E98 File Offset: 0x00012098
		[CallerCount(0)]
		public unsafe static void StopDetection()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600036C RID: 876 RVA: 0x00013ECC File Offset: 0x000120CC
		[CallerCount(0)]
		public unsafe static void Dispose()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x0600036D RID: 877 RVA: 0x00013F00 File Offset: 0x00012100
		// (set) Token: 0x0600036E RID: 878 RVA: 0x00013F48 File Offset: 0x00012148
		public unsafe static InjectionDetector Instance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_InjectionDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new InjectionDetector(intPtr2) : null;
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_InjectionDetector_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x0600036F RID: 879 RVA: 0x00013F94 File Offset: 0x00012194
		public unsafe static InjectionDetector GetOrCreateInstance
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_InjectionDetector_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new InjectionDetector(intPtr2) : null;
			}
		}

		// Token: 0x06000370 RID: 880 RVA: 0x00013FDC File Offset: 0x000121DC
		[CallerCount(0)]
		public unsafe InjectionDetector() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00014028 File Offset: 0x00012228
		[CallerCount(0)]
		public unsafe void Awake()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_Awake_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000372 RID: 882 RVA: 0x0001406C File Offset: 0x0001226C
		[CallerCount(0)]
		public new unsafe void OnDestroy()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000373 RID: 883 RVA: 0x000140BC File Offset: 0x000122BC
		[CallerCount(0)]
		public unsafe void OnLevelWasLoadedNew(Scene scene, LoadSceneMode mode)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref scene;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref mode;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000374 RID: 884 RVA: 0x00014124 File Offset: 0x00012324
		[CallerCount(0)]
		public unsafe void OnLevelLoadedCallback()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00014168 File Offset: 0x00012368
		[CallerCount(0)]
		public unsafe void StartDetectionInternal(UnityAction callback, UnityAction<string> callbackWithArgument)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(callback);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(callbackWithArgument);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_UnityAction_1_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000376 RID: 886 RVA: 0x000141DC File Offset: 0x000123DC
		[CallerCount(0)]
		public new unsafe void StartDetectionAutomatically()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000377 RID: 887 RVA: 0x0001422C File Offset: 0x0001242C
		[CallerCount(0)]
		public new unsafe void PauseDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000378 RID: 888 RVA: 0x0001427C File Offset: 0x0001247C
		[CallerCount(0)]
		public new unsafe void ResumeDetector()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000379 RID: 889 RVA: 0x000142CC File Offset: 0x000124CC
		[CallerCount(0)]
		public new unsafe void StopDetectionInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600037A RID: 890 RVA: 0x0001431C File Offset: 0x0001251C
		[CallerCount(0)]
		public new unsafe void DisposeInternal()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(IL2CPP.il2cpp_object_get_virtual_method(IL2CPP.Il2CppObjectBaseToPtr(this), InjectionDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0), IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600037B RID: 891 RVA: 0x0001436C File Offset: 0x0001256C
		[CallerCount(0)]
		public unsafe void OnCheatingDetected(string cause)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(cause);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_OnCheatingDetected_Private_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600037C RID: 892 RVA: 0x000143C8 File Offset: 0x000125C8
		[CallerCount(0)]
		public unsafe void OnNewAssemblyLoaded(Object sender, AssemblyLoadEventArgs args)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(sender);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(args);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_OnNewAssemblyLoaded_Private_Void_Object_AssemblyLoadEventArgs_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0001443C File Offset: 0x0001263C
		[CallerCount(0)]
		public unsafe bool FindInjectionInCurrentAssemblies(out string cause)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			ref IntPtr ptr2 = ref *ptr;
			IntPtr il2CppString = IL2CPP.ManagedStringToIl2Cpp(cause);
			ptr2 = &il2CppString;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_FindInjectionInCurrentAssemblies_Private_Boolean_byref_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			cause = IL2CPP.Il2CppStringToManaged(il2CppString);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600037E RID: 894 RVA: 0x000144BC File Offset: 0x000126BC
		[CallerCount(0)]
		public unsafe bool AssemblyAllowed(Assembly ass)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ass);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_AssemblyAllowed_Private_Boolean_Assembly_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600037F RID: 895 RVA: 0x00014524 File Offset: 0x00012724
		[CallerCount(0)]
		public unsafe void LoadAndParseAllowedAssemblies()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_LoadAndParseAllowedAssemblies_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000380 RID: 896 RVA: 0x00014568 File Offset: 0x00012768
		[CallerCount(0)]
		public unsafe int GetAssemblyHash(Assembly ass)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(ass);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_GetAssemblyHash_Private_Int32_Assembly_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000381 RID: 897 RVA: 0x000145D0 File Offset: 0x000127D0
		[CallerCount(0)]
		public unsafe string PublicKeyTokenToString(Il2CppStructArray<byte> bytes)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bytes);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.NativeMethodInfoPtr_PublicKeyTokenToString_Private_String_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000382 RID: 898 RVA: 0x00014634 File Offset: 0x00012834
		// Note: this type is marked as 'beforefieldinit'.
		static InjectionDetector()
		{
			Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Detectors", "InjectionDetector");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr);
			InjectionDetector.NativeFieldInfoPtr_COMPONENT_NAME = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "COMPONENT_NAME");
			InjectionDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "FINAL_LOG_PREFIX");
			InjectionDetector.NativeFieldInfoPtr_detectionActionWithArgument = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "detectionActionWithArgument");
			InjectionDetector.NativeFieldInfoPtr_instancesInScene = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "instancesInScene");
			InjectionDetector.NativeFieldInfoPtr_signaturesAreNotGenuine = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "signaturesAreNotGenuine");
			InjectionDetector.NativeFieldInfoPtr_allowedAssemblies = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "allowedAssemblies");
			InjectionDetector.NativeFieldInfoPtr_hexTable = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "hexTable");
			InjectionDetector.NativeFieldInfoPtr__Instance_k__BackingField = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "<Instance>k__BackingField");
			InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663899);
			InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663900);
			InjectionDetector.NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_1_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663901);
			InjectionDetector.NativeMethodInfoPtr_StopDetection_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663902);
			InjectionDetector.NativeMethodInfoPtr_Dispose_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663903);
			InjectionDetector.NativeMethodInfoPtr_get_Instance_Public_Static_get_InjectionDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663904);
			InjectionDetector.NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_InjectionDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663905);
			InjectionDetector.NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_InjectionDetector_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663906);
			InjectionDetector.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663907);
			InjectionDetector.NativeMethodInfoPtr_Awake_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663908);
			InjectionDetector.NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663909);
			InjectionDetector.NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663910);
			InjectionDetector.NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663911);
			InjectionDetector.NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_UnityAction_1_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663912);
			InjectionDetector.NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663913);
			InjectionDetector.NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663914);
			InjectionDetector.NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663915);
			InjectionDetector.NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663916);
			InjectionDetector.NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663917);
			InjectionDetector.NativeMethodInfoPtr_OnCheatingDetected_Private_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663918);
			InjectionDetector.NativeMethodInfoPtr_OnNewAssemblyLoaded_Private_Void_Object_AssemblyLoadEventArgs_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663919);
			InjectionDetector.NativeMethodInfoPtr_FindInjectionInCurrentAssemblies_Private_Boolean_byref_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663920);
			InjectionDetector.NativeMethodInfoPtr_AssemblyAllowed_Private_Boolean_Assembly_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663921);
			InjectionDetector.NativeMethodInfoPtr_LoadAndParseAllowedAssemblies_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663922);
			InjectionDetector.NativeMethodInfoPtr_GetAssemblyHash_Private_Int32_Assembly_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663923);
			InjectionDetector.NativeMethodInfoPtr_PublicKeyTokenToString_Private_String_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, 100663924);
		}

		// Token: 0x06000383 RID: 899 RVA: 0x0001490C File Offset: 0x00012B0C
		public InjectionDetector(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000384 RID: 900 RVA: 0x00014915 File Offset: 0x00012B15
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr));
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000385 RID: 901 RVA: 0x00014928 File Offset: 0x00012B28
		// (set) Token: 0x06000386 RID: 902 RVA: 0x00014948 File Offset: 0x00012B48
		public unsafe static string COMPONENT_NAME
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(InjectionDetector.NativeFieldInfoPtr_COMPONENT_NAME, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(InjectionDetector.NativeFieldInfoPtr_COMPONENT_NAME, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000387 RID: 903 RVA: 0x00014960 File Offset: 0x00012B60
		// (set) Token: 0x06000388 RID: 904 RVA: 0x00014980 File Offset: 0x00012B80
		public unsafe static string FINAL_LOG_PREFIX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(InjectionDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(InjectionDetector.NativeFieldInfoPtr_FINAL_LOG_PREFIX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000389 RID: 905 RVA: 0x00014998 File Offset: 0x00012B98
		// (set) Token: 0x0600038A RID: 906 RVA: 0x000149CC File Offset: 0x00012BCC
		public unsafe UnityAction<string> detectionActionWithArgument
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_detectionActionWithArgument);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new UnityAction<string>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_detectionActionWithArgument), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x0600038B RID: 907 RVA: 0x000149F4 File Offset: 0x00012BF4
		// (set) Token: 0x0600038C RID: 908 RVA: 0x00014A12 File Offset: 0x00012C12
		public unsafe static int instancesInScene
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(InjectionDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(InjectionDetector.NativeFieldInfoPtr_instancesInScene, (void*)(&value));
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x0600038D RID: 909 RVA: 0x00014A24 File Offset: 0x00012C24
		// (set) Token: 0x0600038E RID: 910 RVA: 0x00014A4C File Offset: 0x00012C4C
		public unsafe bool signaturesAreNotGenuine
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_signaturesAreNotGenuine);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_signaturesAreNotGenuine)) = value;
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x0600038F RID: 911 RVA: 0x00014A70 File Offset: 0x00012C70
		// (set) Token: 0x06000390 RID: 912 RVA: 0x00014AA4 File Offset: 0x00012CA4
		public unsafe Il2CppReferenceArray<InjectionDetector.AllowedAssembly> allowedAssemblies
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_allowedAssemblies);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppReferenceArray<InjectionDetector.AllowedAssembly>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_allowedAssemblies), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000391 RID: 913 RVA: 0x00014ACC File Offset: 0x00012CCC
		// (set) Token: 0x06000392 RID: 914 RVA: 0x00014B00 File Offset: 0x00012D00
		public unsafe Il2CppStringArray hexTable
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_hexTable);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStringArray(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.NativeFieldInfoPtr_hexTable), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000393 RID: 915 RVA: 0x00014B28 File Offset: 0x00012D28
		// (set) Token: 0x06000394 RID: 916 RVA: 0x00014B53 File Offset: 0x00012D53
		public unsafe static InjectionDetector _Instance_k__BackingField
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(InjectionDetector.NativeFieldInfoPtr__Instance_k__BackingField, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new InjectionDetector(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(InjectionDetector.NativeFieldInfoPtr__Instance_k__BackingField, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x04000350 RID: 848
		private static readonly IntPtr NativeFieldInfoPtr_COMPONENT_NAME;

		// Token: 0x04000351 RID: 849
		private static readonly IntPtr NativeFieldInfoPtr_FINAL_LOG_PREFIX;

		// Token: 0x04000352 RID: 850
		private static readonly IntPtr NativeFieldInfoPtr_detectionActionWithArgument;

		// Token: 0x04000353 RID: 851
		private static readonly IntPtr NativeFieldInfoPtr_instancesInScene;

		// Token: 0x04000354 RID: 852
		private static readonly IntPtr NativeFieldInfoPtr_signaturesAreNotGenuine;

		// Token: 0x04000355 RID: 853
		private static readonly IntPtr NativeFieldInfoPtr_allowedAssemblies;

		// Token: 0x04000356 RID: 854
		private static readonly IntPtr NativeFieldInfoPtr_hexTable;

		// Token: 0x04000357 RID: 855
		private static readonly IntPtr NativeFieldInfoPtr__Instance_k__BackingField;

		// Token: 0x04000358 RID: 856
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_0;

		// Token: 0x04000359 RID: 857
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_0;

		// Token: 0x0400035A RID: 858
		private static readonly IntPtr NativeMethodInfoPtr_StartDetection_Public_Static_Void_UnityAction_1_String_0;

		// Token: 0x0400035B RID: 859
		private static readonly IntPtr NativeMethodInfoPtr_StopDetection_Public_Static_Void_0;

		// Token: 0x0400035C RID: 860
		private static readonly IntPtr NativeMethodInfoPtr_Dispose_Public_Static_Void_0;

		// Token: 0x0400035D RID: 861
		private static readonly IntPtr NativeMethodInfoPtr_get_Instance_Public_Static_get_InjectionDetector_0;

		// Token: 0x0400035E RID: 862
		private static readonly IntPtr NativeMethodInfoPtr_set_Instance_Private_Static_set_Void_InjectionDetector_0;

		// Token: 0x0400035F RID: 863
		private static readonly IntPtr NativeMethodInfoPtr_get_GetOrCreateInstance_Private_Static_get_InjectionDetector_0;

		// Token: 0x04000360 RID: 864
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

		// Token: 0x04000361 RID: 865
		private static readonly IntPtr NativeMethodInfoPtr_Awake_Private_Void_0;

		// Token: 0x04000362 RID: 866
		private static readonly IntPtr NativeMethodInfoPtr_OnDestroy_Protected_Virtual_Void_0;

		// Token: 0x04000363 RID: 867
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelWasLoadedNew_Private_Void_Scene_LoadSceneMode_0;

		// Token: 0x04000364 RID: 868
		private static readonly IntPtr NativeMethodInfoPtr_OnLevelLoadedCallback_Private_Void_0;

		// Token: 0x04000365 RID: 869
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionInternal_Private_Void_UnityAction_UnityAction_1_String_0;

		// Token: 0x04000366 RID: 870
		private static readonly IntPtr NativeMethodInfoPtr_StartDetectionAutomatically_Protected_Virtual_Void_0;

		// Token: 0x04000367 RID: 871
		private static readonly IntPtr NativeMethodInfoPtr_PauseDetector_Protected_Virtual_Void_0;

		// Token: 0x04000368 RID: 872
		private static readonly IntPtr NativeMethodInfoPtr_ResumeDetector_Protected_Virtual_Void_0;

		// Token: 0x04000369 RID: 873
		private static readonly IntPtr NativeMethodInfoPtr_StopDetectionInternal_Protected_Virtual_Void_0;

		// Token: 0x0400036A RID: 874
		private static readonly IntPtr NativeMethodInfoPtr_DisposeInternal_Protected_Virtual_Void_0;

		// Token: 0x0400036B RID: 875
		private static readonly IntPtr NativeMethodInfoPtr_OnCheatingDetected_Private_Void_String_0;

		// Token: 0x0400036C RID: 876
		private static readonly IntPtr NativeMethodInfoPtr_OnNewAssemblyLoaded_Private_Void_Object_AssemblyLoadEventArgs_0;

		// Token: 0x0400036D RID: 877
		private static readonly IntPtr NativeMethodInfoPtr_FindInjectionInCurrentAssemblies_Private_Boolean_byref_String_0;

		// Token: 0x0400036E RID: 878
		private static readonly IntPtr NativeMethodInfoPtr_AssemblyAllowed_Private_Boolean_Assembly_0;

		// Token: 0x0400036F RID: 879
		private static readonly IntPtr NativeMethodInfoPtr_LoadAndParseAllowedAssemblies_Private_Void_0;

		// Token: 0x04000370 RID: 880
		private static readonly IntPtr NativeMethodInfoPtr_GetAssemblyHash_Private_Int32_Assembly_0;

		// Token: 0x04000371 RID: 881
		private static readonly IntPtr NativeMethodInfoPtr_PublicKeyTokenToString_Private_String_ArrayOf_Byte_0;

		// Token: 0x0200002A RID: 42
		public class AllowedAssembly : Object
		{
			// Token: 0x06000395 RID: 917 RVA: 0x00014B68 File Offset: 0x00012D68
			[CallerCount(0)]
			public unsafe AllowedAssembly(string name, Il2CppStructArray<int> hashes) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr))
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(name);
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(hashes);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(InjectionDetector.AllowedAssembly.NativeMethodInfoPtr__ctor_Public_Void_String_ArrayOf_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}

			// Token: 0x06000396 RID: 918 RVA: 0x00014BE4 File Offset: 0x00012DE4
			// Note: this type is marked as 'beforefieldinit'.
			static AllowedAssembly()
			{
				Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<InjectionDetector>.NativeClassPtr, "AllowedAssembly");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr);
				InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_name = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr, "name");
				InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_hashes = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr, "hashes");
				InjectionDetector.AllowedAssembly.NativeMethodInfoPtr__ctor_Public_Void_String_ArrayOf_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr, 100663925);
			}

			// Token: 0x06000397 RID: 919 RVA: 0x00002580 File Offset: 0x00000780
			public AllowedAssembly(IntPtr A_1) : base(A_1)
			{
			}

			// Token: 0x1700009F RID: 159
			// (get) Token: 0x06000398 RID: 920 RVA: 0x00014C4B File Offset: 0x00012E4B
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public new static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<InjectionDetector.AllowedAssembly>.NativeClassPtr));
				}
			}

			// Token: 0x170000A0 RID: 160
			// (get) Token: 0x06000399 RID: 921 RVA: 0x00014C5C File Offset: 0x00012E5C
			// (set) Token: 0x0600039A RID: 922 RVA: 0x00014C85 File Offset: 0x00012E85
			public unsafe string name
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_name);
					return IL2CPP.Il2CppStringToManaged(*intPtr);
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_name), IL2CPP.ManagedStringToIl2Cpp(value));
				}
			}

			// Token: 0x170000A1 RID: 161
			// (get) Token: 0x0600039B RID: 923 RVA: 0x00014CAC File Offset: 0x00012EAC
			// (set) Token: 0x0600039C RID: 924 RVA: 0x00014CE0 File Offset: 0x00012EE0
			public unsafe Il2CppStructArray<int> hashes
			{
				get
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_hashes);
					IntPtr intPtr2 = *intPtr;
					return (intPtr2 != 0) ? new Il2CppStructArray<int>(intPtr2) : null;
				}
				set
				{
					IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
					IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(InjectionDetector.AllowedAssembly.NativeFieldInfoPtr_hashes), IL2CPP.Il2CppObjectBaseToPtr(value));
				}
			}

			// Token: 0x04000372 RID: 882
			private static readonly IntPtr NativeFieldInfoPtr_name;

			// Token: 0x04000373 RID: 883
			private static readonly IntPtr NativeFieldInfoPtr_hashes;

			// Token: 0x04000374 RID: 884
			private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_String_ArrayOf_Int32_0;
		}
	}
}
