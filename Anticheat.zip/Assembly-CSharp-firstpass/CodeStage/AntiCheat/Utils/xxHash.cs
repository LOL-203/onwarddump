﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.Utils
{
	// Token: 0x0200000C RID: 12
	public class xxHash : Object
	{
		// Token: 0x06000069 RID: 105 RVA: 0x00003B68 File Offset: 0x00001D68
		[CallerCount(0)]
		public unsafe static uint CalculateHash(Il2CppStructArray<byte> buf, int len, uint seed)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(buf);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref len;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref seed;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(xxHash.NativeMethodInfoPtr_CalculateHash_Public_Static_UInt32_ArrayOf_Byte_Int32_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00003BE8 File Offset: 0x00001DE8
		[CallerCount(0)]
		public unsafe xxHash() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<xxHash>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(xxHash.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00003C34 File Offset: 0x00001E34
		// Note: this type is marked as 'beforefieldinit'.
		static xxHash()
		{
			Il2CppClassPointerStore<xxHash>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Utils", "xxHash");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<xxHash>.NativeClassPtr);
			xxHash.NativeFieldInfoPtr_PRIME32_1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<xxHash>.NativeClassPtr, "PRIME32_1");
			xxHash.NativeFieldInfoPtr_PRIME32_2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<xxHash>.NativeClassPtr, "PRIME32_2");
			xxHash.NativeFieldInfoPtr_PRIME32_3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<xxHash>.NativeClassPtr, "PRIME32_3");
			xxHash.NativeFieldInfoPtr_PRIME32_4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<xxHash>.NativeClassPtr, "PRIME32_4");
			xxHash.NativeFieldInfoPtr_PRIME32_5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<xxHash>.NativeClassPtr, "PRIME32_5");
			xxHash.NativeMethodInfoPtr_CalculateHash_Public_Static_UInt32_ArrayOf_Byte_Int32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<xxHash>.NativeClassPtr, 100663344);
			xxHash.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<xxHash>.NativeClassPtr, 100663345);
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00002580 File Offset: 0x00000780
		public xxHash(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600006D RID: 109 RVA: 0x00003CF0 File Offset: 0x00001EF0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<xxHash>.NativeClassPtr));
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x0600006E RID: 110 RVA: 0x00003D04 File Offset: 0x00001F04
		// (set) Token: 0x0600006F RID: 111 RVA: 0x00003D22 File Offset: 0x00001F22
		public unsafe static uint PRIME32_1
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(xxHash.NativeFieldInfoPtr_PRIME32_1, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(xxHash.NativeFieldInfoPtr_PRIME32_1, (void*)(&value));
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000070 RID: 112 RVA: 0x00003D34 File Offset: 0x00001F34
		// (set) Token: 0x06000071 RID: 113 RVA: 0x00003D52 File Offset: 0x00001F52
		public unsafe static uint PRIME32_2
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(xxHash.NativeFieldInfoPtr_PRIME32_2, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(xxHash.NativeFieldInfoPtr_PRIME32_2, (void*)(&value));
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000072 RID: 114 RVA: 0x00003D64 File Offset: 0x00001F64
		// (set) Token: 0x06000073 RID: 115 RVA: 0x00003D82 File Offset: 0x00001F82
		public unsafe static uint PRIME32_3
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(xxHash.NativeFieldInfoPtr_PRIME32_3, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(xxHash.NativeFieldInfoPtr_PRIME32_3, (void*)(&value));
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000074 RID: 116 RVA: 0x00003D94 File Offset: 0x00001F94
		// (set) Token: 0x06000075 RID: 117 RVA: 0x00003DB2 File Offset: 0x00001FB2
		public unsafe static uint PRIME32_4
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(xxHash.NativeFieldInfoPtr_PRIME32_4, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(xxHash.NativeFieldInfoPtr_PRIME32_4, (void*)(&value));
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000076 RID: 118 RVA: 0x00003DC4 File Offset: 0x00001FC4
		// (set) Token: 0x06000077 RID: 119 RVA: 0x00003DE2 File Offset: 0x00001FE2
		public unsafe static uint PRIME32_5
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(xxHash.NativeFieldInfoPtr_PRIME32_5, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(xxHash.NativeFieldInfoPtr_PRIME32_5, (void*)(&value));
			}
		}

		// Token: 0x0400004B RID: 75
		private static readonly IntPtr NativeFieldInfoPtr_PRIME32_1;

		// Token: 0x0400004C RID: 76
		private static readonly IntPtr NativeFieldInfoPtr_PRIME32_2;

		// Token: 0x0400004D RID: 77
		private static readonly IntPtr NativeFieldInfoPtr_PRIME32_3;

		// Token: 0x0400004E RID: 78
		private static readonly IntPtr NativeFieldInfoPtr_PRIME32_4;

		// Token: 0x0400004F RID: 79
		private static readonly IntPtr NativeFieldInfoPtr_PRIME32_5;

		// Token: 0x04000050 RID: 80
		private static readonly IntPtr NativeMethodInfoPtr_CalculateHash_Public_Static_UInt32_ArrayOf_Byte_Int32_UInt32_0;

		// Token: 0x04000051 RID: 81
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
