﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.Common
{
	// Token: 0x02000033 RID: 51
	public class Constants : Object
	{
		// Token: 0x060004AC RID: 1196 RVA: 0x000193EC File Offset: 0x000175EC
		[CallerCount(0)]
		public unsafe Constants() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<Constants>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(Constants.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x00019438 File Offset: 0x00017638
		// Note: this type is marked as 'beforefieldinit'.
		static Constants()
		{
			Il2CppClassPointerStore<Constants>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Common", "Constants");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<Constants>.NativeClassPtr);
			Constants.NativeFieldInfoPtr_LOG_PREFIX = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<Constants>.NativeClassPtr, "LOG_PREFIX");
			Constants.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<Constants>.NativeClassPtr, 100664031);
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x00002580 File Offset: 0x00000780
		public Constants(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x060004AF RID: 1199 RVA: 0x00019490 File Offset: 0x00017690
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<Constants>.NativeClassPtr));
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x060004B0 RID: 1200 RVA: 0x000194A4 File Offset: 0x000176A4
		// (set) Token: 0x060004B1 RID: 1201 RVA: 0x000194C4 File Offset: 0x000176C4
		public unsafe static string LOG_PREFIX
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(Constants.NativeFieldInfoPtr_LOG_PREFIX, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(Constants.NativeFieldInfoPtr_LOG_PREFIX, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400045D RID: 1117
		private static readonly IntPtr NativeFieldInfoPtr_LOG_PREFIX;

		// Token: 0x0400045E RID: 1118
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
