﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace CodeStage.AntiCheat.Common
{
	// Token: 0x02000032 RID: 50
	[Serializable]
	[StructLayout(2)]
	public struct ACTkByte8
	{
		// Token: 0x060004A9 RID: 1193 RVA: 0x000192F8 File Offset: 0x000174F8
		// Note: this type is marked as 'beforefieldinit'.
		static ACTkByte8()
		{
			Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Common", "ACTkByte8");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr);
			ACTkByte8.NativeFieldInfoPtr_b1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b1");
			ACTkByte8.NativeFieldInfoPtr_b2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b2");
			ACTkByte8.NativeFieldInfoPtr_b3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b3");
			ACTkByte8.NativeFieldInfoPtr_b4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b4");
			ACTkByte8.NativeFieldInfoPtr_b5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b5");
			ACTkByte8.NativeFieldInfoPtr_b6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b6");
			ACTkByte8.NativeFieldInfoPtr_b7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b7");
			ACTkByte8.NativeFieldInfoPtr_b8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, "b8");
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x000193C8 File Offset: 0x000175C8
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr, ref this));
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x060004AB RID: 1195 RVA: 0x000193DA File Offset: 0x000175DA
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ACTkByte8>.NativeClassPtr));
			}
		}

		// Token: 0x0400044D RID: 1101
		private static readonly IntPtr NativeFieldInfoPtr_b1;

		// Token: 0x0400044E RID: 1102
		private static readonly IntPtr NativeFieldInfoPtr_b2;

		// Token: 0x0400044F RID: 1103
		private static readonly IntPtr NativeFieldInfoPtr_b3;

		// Token: 0x04000450 RID: 1104
		private static readonly IntPtr NativeFieldInfoPtr_b4;

		// Token: 0x04000451 RID: 1105
		private static readonly IntPtr NativeFieldInfoPtr_b5;

		// Token: 0x04000452 RID: 1106
		private static readonly IntPtr NativeFieldInfoPtr_b6;

		// Token: 0x04000453 RID: 1107
		private static readonly IntPtr NativeFieldInfoPtr_b7;

		// Token: 0x04000454 RID: 1108
		private static readonly IntPtr NativeFieldInfoPtr_b8;

		// Token: 0x04000455 RID: 1109
		[FieldOffset(0)]
		public byte b1;

		// Token: 0x04000456 RID: 1110
		[FieldOffset(1)]
		public byte b2;

		// Token: 0x04000457 RID: 1111
		[FieldOffset(2)]
		public byte b3;

		// Token: 0x04000458 RID: 1112
		[FieldOffset(3)]
		public byte b4;

		// Token: 0x04000459 RID: 1113
		[FieldOffset(4)]
		public byte b5;

		// Token: 0x0400045A RID: 1114
		[FieldOffset(5)]
		public byte b6;

		// Token: 0x0400045B RID: 1115
		[FieldOffset(6)]
		public byte b7;

		// Token: 0x0400045C RID: 1116
		[FieldOffset(7)]
		public byte b8;
	}
}
