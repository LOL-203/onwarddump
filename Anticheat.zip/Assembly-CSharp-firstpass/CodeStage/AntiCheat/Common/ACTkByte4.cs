﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace CodeStage.AntiCheat.Common
{
	// Token: 0x02000031 RID: 49
	[Serializable]
	[StructLayout(2)]
	public struct ACTkByte4
	{
		// Token: 0x060004A6 RID: 1190 RVA: 0x00019254 File Offset: 0x00017454
		// Note: this type is marked as 'beforefieldinit'.
		static ACTkByte4()
		{
			Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Common", "ACTkByte4");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr);
			ACTkByte4.NativeFieldInfoPtr_b1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr, "b1");
			ACTkByte4.NativeFieldInfoPtr_b2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr, "b2");
			ACTkByte4.NativeFieldInfoPtr_b3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr, "b3");
			ACTkByte4.NativeFieldInfoPtr_b4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr, "b4");
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x000192D4 File Offset: 0x000174D4
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr, ref this));
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x060004A8 RID: 1192 RVA: 0x000192E6 File Offset: 0x000174E6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ACTkByte4>.NativeClassPtr));
			}
		}

		// Token: 0x04000445 RID: 1093
		private static readonly IntPtr NativeFieldInfoPtr_b1;

		// Token: 0x04000446 RID: 1094
		private static readonly IntPtr NativeFieldInfoPtr_b2;

		// Token: 0x04000447 RID: 1095
		private static readonly IntPtr NativeFieldInfoPtr_b3;

		// Token: 0x04000448 RID: 1096
		private static readonly IntPtr NativeFieldInfoPtr_b4;

		// Token: 0x04000449 RID: 1097
		[FieldOffset(0)]
		public byte b1;

		// Token: 0x0400044A RID: 1098
		[FieldOffset(1)]
		public byte b2;

		// Token: 0x0400044B RID: 1099
		[FieldOffset(2)]
		public byte b3;

		// Token: 0x0400044C RID: 1100
		[FieldOffset(3)]
		public byte b4;
	}
}
