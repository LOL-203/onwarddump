﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;

namespace CodeStage.AntiCheat.Common
{
	// Token: 0x02000030 RID: 48
	[Serializable]
	[StructLayout(2)]
	public struct ACTkByte16
	{
		// Token: 0x060004A3 RID: 1187 RVA: 0x000190C0 File Offset: 0x000172C0
		// Note: this type is marked as 'beforefieldinit'.
		static ACTkByte16()
		{
			Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.Common", "ACTkByte16");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr);
			ACTkByte16.NativeFieldInfoPtr_b1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b1");
			ACTkByte16.NativeFieldInfoPtr_b2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b2");
			ACTkByte16.NativeFieldInfoPtr_b3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b3");
			ACTkByte16.NativeFieldInfoPtr_b4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b4");
			ACTkByte16.NativeFieldInfoPtr_b5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b5");
			ACTkByte16.NativeFieldInfoPtr_b6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b6");
			ACTkByte16.NativeFieldInfoPtr_b7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b7");
			ACTkByte16.NativeFieldInfoPtr_b8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b8");
			ACTkByte16.NativeFieldInfoPtr_b9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b9");
			ACTkByte16.NativeFieldInfoPtr_b10 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b10");
			ACTkByte16.NativeFieldInfoPtr_b11 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b11");
			ACTkByte16.NativeFieldInfoPtr_b12 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b12");
			ACTkByte16.NativeFieldInfoPtr_b13 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b13");
			ACTkByte16.NativeFieldInfoPtr_b14 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b14");
			ACTkByte16.NativeFieldInfoPtr_b15 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b15");
			ACTkByte16.NativeFieldInfoPtr_b16 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, "b16");
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00019230 File Offset: 0x00017430
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr, ref this));
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x060004A5 RID: 1189 RVA: 0x00019242 File Offset: 0x00017442
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ACTkByte16>.NativeClassPtr));
			}
		}

		// Token: 0x04000425 RID: 1061
		private static readonly IntPtr NativeFieldInfoPtr_b1;

		// Token: 0x04000426 RID: 1062
		private static readonly IntPtr NativeFieldInfoPtr_b2;

		// Token: 0x04000427 RID: 1063
		private static readonly IntPtr NativeFieldInfoPtr_b3;

		// Token: 0x04000428 RID: 1064
		private static readonly IntPtr NativeFieldInfoPtr_b4;

		// Token: 0x04000429 RID: 1065
		private static readonly IntPtr NativeFieldInfoPtr_b5;

		// Token: 0x0400042A RID: 1066
		private static readonly IntPtr NativeFieldInfoPtr_b6;

		// Token: 0x0400042B RID: 1067
		private static readonly IntPtr NativeFieldInfoPtr_b7;

		// Token: 0x0400042C RID: 1068
		private static readonly IntPtr NativeFieldInfoPtr_b8;

		// Token: 0x0400042D RID: 1069
		private static readonly IntPtr NativeFieldInfoPtr_b9;

		// Token: 0x0400042E RID: 1070
		private static readonly IntPtr NativeFieldInfoPtr_b10;

		// Token: 0x0400042F RID: 1071
		private static readonly IntPtr NativeFieldInfoPtr_b11;

		// Token: 0x04000430 RID: 1072
		private static readonly IntPtr NativeFieldInfoPtr_b12;

		// Token: 0x04000431 RID: 1073
		private static readonly IntPtr NativeFieldInfoPtr_b13;

		// Token: 0x04000432 RID: 1074
		private static readonly IntPtr NativeFieldInfoPtr_b14;

		// Token: 0x04000433 RID: 1075
		private static readonly IntPtr NativeFieldInfoPtr_b15;

		// Token: 0x04000434 RID: 1076
		private static readonly IntPtr NativeFieldInfoPtr_b16;

		// Token: 0x04000435 RID: 1077
		[FieldOffset(0)]
		public byte b1;

		// Token: 0x04000436 RID: 1078
		[FieldOffset(1)]
		public byte b2;

		// Token: 0x04000437 RID: 1079
		[FieldOffset(2)]
		public byte b3;

		// Token: 0x04000438 RID: 1080
		[FieldOffset(3)]
		public byte b4;

		// Token: 0x04000439 RID: 1081
		[FieldOffset(4)]
		public byte b5;

		// Token: 0x0400043A RID: 1082
		[FieldOffset(5)]
		public byte b6;

		// Token: 0x0400043B RID: 1083
		[FieldOffset(6)]
		public byte b7;

		// Token: 0x0400043C RID: 1084
		[FieldOffset(7)]
		public byte b8;

		// Token: 0x0400043D RID: 1085
		[FieldOffset(8)]
		public byte b9;

		// Token: 0x0400043E RID: 1086
		[FieldOffset(9)]
		public byte b10;

		// Token: 0x0400043F RID: 1087
		[FieldOffset(10)]
		public byte b11;

		// Token: 0x04000440 RID: 1088
		[FieldOffset(11)]
		public byte b12;

		// Token: 0x04000441 RID: 1089
		[FieldOffset(12)]
		public byte b13;

		// Token: 0x04000442 RID: 1090
		[FieldOffset(13)]
		public byte b14;

		// Token: 0x04000443 RID: 1091
		[FieldOffset(14)]
		public byte b15;

		// Token: 0x04000444 RID: 1092
		[FieldOffset(15)]
		public byte b16;
	}
}
