﻿using System;
using System.Runtime.InteropServices;
using CodeStage.AntiCheat.Common;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000014 RID: 20
	[Serializable]
	[StructLayout(0)]
	public sealed class ObscuredFloat : ValueType
	{
		// Token: 0x0600011A RID: 282 RVA: 0x000072A0 File Offset: 0x000054A0
		[CallerCount(0)]
		public unsafe ObscuredFloat(ACTkByte4 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte4_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600011B RID: 283 RVA: 0x000072F4 File Offset: 0x000054F4
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(int newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600011C RID: 284 RVA: 0x0000733C File Offset: 0x0000553C
		[CallerCount(0)]
		public unsafe static int Encrypt(float value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00007390 File Offset: 0x00005590
		[CallerCount(0)]
		public unsafe static int Encrypt(float value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600011E RID: 286 RVA: 0x000073F8 File Offset: 0x000055F8
		[CallerCount(0)]
		public unsafe static ACTkByte4 InternalEncrypt(float value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600011F RID: 287 RVA: 0x0000744C File Offset: 0x0000564C
		[CallerCount(0)]
		public unsafe static ACTkByte4 InternalEncrypt(float value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000120 RID: 288 RVA: 0x000074B4 File Offset: 0x000056B4
		[CallerCount(0)]
		public unsafe static float Decrypt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000121 RID: 289 RVA: 0x00007508 File Offset: 0x00005708
		[CallerCount(0)]
		public unsafe static float Decrypt(int value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00007570 File Offset: 0x00005770
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000123 RID: 291 RVA: 0x000075B0 File Offset: 0x000057B0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000124 RID: 292 RVA: 0x000075F0 File Offset: 0x000057F0
		[CallerCount(0)]
		public unsafe int GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00007640 File Offset: 0x00005840
		[CallerCount(0)]
		public unsafe void SetEncrypted(int encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00007694 File Offset: 0x00005894
		[CallerCount(0)]
		public unsafe float GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_GetDecrypted_Public_Single_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000127 RID: 295 RVA: 0x000076E4 File Offset: 0x000058E4
		[CallerCount(0)]
		public unsafe float InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_InternalDecrypt_Private_Single_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00007734 File Offset: 0x00005934
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredFloat(float value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredFloat(intPtr);
		}

		// Token: 0x06000129 RID: 297 RVA: 0x00007784 File Offset: 0x00005984
		[CallerCount(0)]
		public unsafe static implicit operator float(ObscuredFloat value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(value));
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_op_Implicit_Public_Static_Single_ObscuredFloat_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600012A RID: 298 RVA: 0x000077E4 File Offset: 0x000059E4
		[CallerCount(0)]
		public unsafe static ObscuredFloat operator ++(ObscuredFloat input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredFloat_ObscuredFloat_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredFloat(intPtr);
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000783C File Offset: 0x00005A3C
		[CallerCount(0)]
		public unsafe static ObscuredFloat operator --(ObscuredFloat input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredFloat_ObscuredFloat_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredFloat(intPtr);
		}

		// Token: 0x0600012C RID: 300 RVA: 0x00007894 File Offset: 0x00005A94
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600012D RID: 301 RVA: 0x000078FC File Offset: 0x00005AFC
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredFloat obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(obj));
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredFloat_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600012E RID: 302 RVA: 0x00007968 File Offset: 0x00005B68
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600012F RID: 303 RVA: 0x000079B8 File Offset: 0x00005BB8
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00007A04 File Offset: 0x00005C04
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_ToString_Public_String_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00007A64 File Offset: 0x00005C64
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000132 RID: 306 RVA: 0x00007AC4 File Offset: 0x00005CC4
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredFloat.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000133 RID: 307 RVA: 0x00007B3C File Offset: 0x00005D3C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredFloat()
		{
			Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredFloat");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr);
			ObscuredFloat.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "cryptoKey");
			ObscuredFloat.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "currentCryptoKey");
			ObscuredFloat.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "hiddenValue");
			ObscuredFloat.NativeFieldInfoPtr_hiddenValueOld = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "hiddenValueOld");
			ObscuredFloat.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "fakeValue");
			ObscuredFloat.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "inited");
			ObscuredFloat.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte4_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663460);
			ObscuredFloat.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663461);
			ObscuredFloat.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663462);
			ObscuredFloat.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663463);
			ObscuredFloat.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663464);
			ObscuredFloat.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663465);
			ObscuredFloat.NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663466);
			ObscuredFloat.NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663467);
			ObscuredFloat.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663468);
			ObscuredFloat.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663469);
			ObscuredFloat.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663470);
			ObscuredFloat.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663471);
			ObscuredFloat.NativeMethodInfoPtr_GetDecrypted_Public_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663472);
			ObscuredFloat.NativeMethodInfoPtr_InternalDecrypt_Private_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663473);
			ObscuredFloat.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663474);
			ObscuredFloat.NativeMethodInfoPtr_op_Implicit_Public_Static_Single_ObscuredFloat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663475);
			ObscuredFloat.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredFloat_ObscuredFloat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663476);
			ObscuredFloat.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredFloat_ObscuredFloat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663477);
			ObscuredFloat.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663478);
			ObscuredFloat.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredFloat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663479);
			ObscuredFloat.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663480);
			ObscuredFloat.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663481);
			ObscuredFloat.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663482);
			ObscuredFloat.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663483);
			ObscuredFloat.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, 100663484);
		}

		// Token: 0x06000134 RID: 308 RVA: 0x00006234 File Offset: 0x00004434
		public ObscuredFloat(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000135 RID: 309 RVA: 0x00007DD8 File Offset: 0x00005FD8
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr));
			}
		}

		// Token: 0x06000136 RID: 310 RVA: 0x00007DEC File Offset: 0x00005FEC
		public unsafe ObscuredFloat()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, data));
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000137 RID: 311 RVA: 0x00007E1C File Offset: 0x0000601C
		// (set) Token: 0x06000138 RID: 312 RVA: 0x00007E3A File Offset: 0x0000603A
		public unsafe static int cryptoKey
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredFloat.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredFloat.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000139 RID: 313 RVA: 0x00007E4C File Offset: 0x0000604C
		// (set) Token: 0x0600013A RID: 314 RVA: 0x00007E74 File Offset: 0x00006074
		public unsafe int currentCryptoKey
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_currentCryptoKey);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_currentCryptoKey)) = value;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600013B RID: 315 RVA: 0x00007E98 File Offset: 0x00006098
		// (set) Token: 0x0600013C RID: 316 RVA: 0x00007EC0 File Offset: 0x000060C0
		public unsafe ACTkByte4 hiddenValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_hiddenValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_hiddenValue)) = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600013D RID: 317 RVA: 0x00007EE4 File Offset: 0x000060E4
		// (set) Token: 0x0600013E RID: 318 RVA: 0x00007F18 File Offset: 0x00006118
		public unsafe Il2CppStructArray<byte> hiddenValueOld
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_hiddenValueOld);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_hiddenValueOld), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600013F RID: 319 RVA: 0x00007F40 File Offset: 0x00006140
		// (set) Token: 0x06000140 RID: 320 RVA: 0x00007F68 File Offset: 0x00006168
		public unsafe float fakeValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_fakeValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_fakeValue)) = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000141 RID: 321 RVA: 0x00007F8C File Offset: 0x0000618C
		// (set) Token: 0x06000142 RID: 322 RVA: 0x00007FB4 File Offset: 0x000061B4
		public unsafe bool inited
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_inited);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredFloat.NativeFieldInfoPtr_inited)) = value;
			}
		}

		// Token: 0x040000F6 RID: 246
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040000F7 RID: 247
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040000F8 RID: 248
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040000F9 RID: 249
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValueOld;

		// Token: 0x040000FA RID: 250
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040000FB RID: 251
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040000FC RID: 252
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_ACTkByte4_0;

		// Token: 0x040000FD RID: 253
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0;

		// Token: 0x040000FE RID: 254
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_0;

		// Token: 0x040000FF RID: 255
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Single_Int32_0;

		// Token: 0x04000100 RID: 256
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_0;

		// Token: 0x04000101 RID: 257
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte4_Single_Int32_0;

		// Token: 0x04000102 RID: 258
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_0;

		// Token: 0x04000103 RID: 259
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Single_Int32_Int32_0;

		// Token: 0x04000104 RID: 260
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000105 RID: 261
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x04000106 RID: 262
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int32_0;

		// Token: 0x04000107 RID: 263
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0;

		// Token: 0x04000108 RID: 264
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Single_0;

		// Token: 0x04000109 RID: 265
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Single_0;

		// Token: 0x0400010A RID: 266
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_Single_0;

		// Token: 0x0400010B RID: 267
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Single_ObscuredFloat_0;

		// Token: 0x0400010C RID: 268
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredFloat_ObscuredFloat_0;

		// Token: 0x0400010D RID: 269
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredFloat_ObscuredFloat_0;

		// Token: 0x0400010E RID: 270
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x0400010F RID: 271
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredFloat_0;

		// Token: 0x04000110 RID: 272
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000111 RID: 273
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000112 RID: 274
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000113 RID: 275
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000114 RID: 276
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x02000015 RID: 21
		[StructLayout(2)]
		public struct FloatIntBytesUnion
		{
			// Token: 0x06000143 RID: 323 RVA: 0x00007FD8 File Offset: 0x000061D8
			// Note: this type is marked as 'beforefieldinit'.
			static FloatIntBytesUnion()
			{
				Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredFloat>.NativeClassPtr, "FloatIntBytesUnion");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr);
				ObscuredFloat.FloatIntBytesUnion.NativeFieldInfoPtr_f = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr, "f");
				ObscuredFloat.FloatIntBytesUnion.NativeFieldInfoPtr_i = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr, "i");
				ObscuredFloat.FloatIntBytesUnion.NativeFieldInfoPtr_b4 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr, "b4");
			}

			// Token: 0x06000144 RID: 324 RVA: 0x0000803F File Offset: 0x0000623F
			public Object BoxIl2CppObject()
			{
				return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr, ref this));
			}

			// Token: 0x17000046 RID: 70
			// (get) Token: 0x06000145 RID: 325 RVA: 0x00008051 File Offset: 0x00006251
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredFloat.FloatIntBytesUnion>.NativeClassPtr));
				}
			}

			// Token: 0x04000115 RID: 277
			private static readonly IntPtr NativeFieldInfoPtr_f;

			// Token: 0x04000116 RID: 278
			private static readonly IntPtr NativeFieldInfoPtr_i;

			// Token: 0x04000117 RID: 279
			private static readonly IntPtr NativeFieldInfoPtr_b4;

			// Token: 0x04000118 RID: 280
			[FieldOffset(0)]
			public float f;

			// Token: 0x04000119 RID: 281
			[FieldOffset(0)]
			public int i;

			// Token: 0x0400011A RID: 282
			[FieldOffset(0)]
			public ACTkByte4 b4;
		}
	}
}
