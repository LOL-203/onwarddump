﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000021 RID: 33
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredUInt
	{
		// Token: 0x0600028C RID: 652 RVA: 0x0000F464 File Offset: 0x0000D664
		[CallerCount(0)]
		public unsafe ObscuredUInt(uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr__ctor_Private_Void_UInt32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600028D RID: 653 RVA: 0x0000F4AC File Offset: 0x0000D6AC
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(uint newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0000F4F4 File Offset: 0x0000D6F4
		[CallerCount(0)]
		public unsafe static uint Encrypt(uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600028F RID: 655 RVA: 0x0000F548 File Offset: 0x0000D748
		[CallerCount(0)]
		public unsafe static uint Decrypt(uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000290 RID: 656 RVA: 0x0000F59C File Offset: 0x0000D79C
		[CallerCount(0)]
		public unsafe static uint Encrypt(uint value, uint key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000291 RID: 657 RVA: 0x0000F604 File Offset: 0x0000D804
		[CallerCount(0)]
		public unsafe static uint Decrypt(uint value, uint key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000292 RID: 658 RVA: 0x0000F66C File Offset: 0x0000D86C
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000293 RID: 659 RVA: 0x0000F6A0 File Offset: 0x0000D8A0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000294 RID: 660 RVA: 0x0000F6D4 File Offset: 0x0000D8D4
		[CallerCount(0)]
		public unsafe uint GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_GetEncrypted_Public_UInt32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000295 RID: 661 RVA: 0x0000F718 File Offset: 0x0000D918
		[CallerCount(0)]
		public unsafe void SetEncrypted(uint encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000296 RID: 662 RVA: 0x0000F760 File Offset: 0x0000D960
		[CallerCount(0)]
		public unsafe uint GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_GetDecrypted_Public_UInt32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000297 RID: 663 RVA: 0x0000F7A4 File Offset: 0x0000D9A4
		[CallerCount(0)]
		public unsafe uint InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_InternalDecrypt_Private_UInt32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000298 RID: 664 RVA: 0x0000F7E8 File Offset: 0x0000D9E8
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredUInt(uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUInt_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000299 RID: 665 RVA: 0x0000F83C File Offset: 0x0000DA3C
		[CallerCount(0)]
		public unsafe static implicit operator uint(ObscuredUInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt32_ObscuredUInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0000F890 File Offset: 0x0000DA90
		[CallerCount(0)]
		public unsafe static explicit operator ObscuredInt(ObscuredUInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredInt_ObscuredUInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600029B RID: 667 RVA: 0x0000F8E4 File Offset: 0x0000DAE4
		[CallerCount(0)]
		public unsafe static ObscuredUInt operator ++(ObscuredUInt input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUInt_ObscuredUInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600029C RID: 668 RVA: 0x0000F938 File Offset: 0x0000DB38
		[CallerCount(0)]
		public unsafe static ObscuredUInt operator --(ObscuredUInt input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUInt_ObscuredUInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0000F98C File Offset: 0x0000DB8C
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600029E RID: 670 RVA: 0x0000F9E4 File Offset: 0x0000DBE4
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredUInt obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUInt_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600029F RID: 671 RVA: 0x0000FA38 File Offset: 0x0000DC38
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x0000FA74 File Offset: 0x0000DC74
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x0000FAC8 File Offset: 0x0000DCC8
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x0000FB0C File Offset: 0x0000DD0C
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x0000FB60 File Offset: 0x0000DD60
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUInt.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x0000FBCC File Offset: 0x0000DDCC
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredUInt()
		{
			Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredUInt");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr);
			ObscuredUInt.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, "cryptoKey");
			ObscuredUInt.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, "currentCryptoKey");
			ObscuredUInt.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, "hiddenValue");
			ObscuredUInt.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, "fakeValue");
			ObscuredUInt.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, "inited");
			ObscuredUInt.NativeMethodInfoPtr__ctor_Private_Void_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663736);
			ObscuredUInt.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663737);
			ObscuredUInt.NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663738);
			ObscuredUInt.NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663739);
			ObscuredUInt.NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663740);
			ObscuredUInt.NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663741);
			ObscuredUInt.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663742);
			ObscuredUInt.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663743);
			ObscuredUInt.NativeMethodInfoPtr_GetEncrypted_Public_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663744);
			ObscuredUInt.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663745);
			ObscuredUInt.NativeMethodInfoPtr_GetDecrypted_Public_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663746);
			ObscuredUInt.NativeMethodInfoPtr_InternalDecrypt_Private_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663747);
			ObscuredUInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUInt_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663748);
			ObscuredUInt.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt32_ObscuredUInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663749);
			ObscuredUInt.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredInt_ObscuredUInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663750);
			ObscuredUInt.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUInt_ObscuredUInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663751);
			ObscuredUInt.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUInt_ObscuredUInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663752);
			ObscuredUInt.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663753);
			ObscuredUInt.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663754);
			ObscuredUInt.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663755);
			ObscuredUInt.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663756);
			ObscuredUInt.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663757);
			ObscuredUInt.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663758);
			ObscuredUInt.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, 100663759);
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x0000FE40 File Offset: 0x0000E040
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr, ref this));
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060002A6 RID: 678 RVA: 0x0000FE52 File Offset: 0x0000E052
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredUInt>.NativeClassPtr));
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060002A7 RID: 679 RVA: 0x0000FE64 File Offset: 0x0000E064
		// (set) Token: 0x060002A8 RID: 680 RVA: 0x0000FE82 File Offset: 0x0000E082
		public unsafe static uint cryptoKey
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredUInt.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredUInt.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400026D RID: 621
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400026E RID: 622
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x0400026F RID: 623
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000270 RID: 624
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000271 RID: 625
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000272 RID: 626
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_UInt32_0;

		// Token: 0x04000273 RID: 627
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt32_0;

		// Token: 0x04000274 RID: 628
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_0;

		// Token: 0x04000275 RID: 629
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_0;

		// Token: 0x04000276 RID: 630
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_UInt32_UInt32_UInt32_0;

		// Token: 0x04000277 RID: 631
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_UInt32_UInt32_UInt32_0;

		// Token: 0x04000278 RID: 632
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000279 RID: 633
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400027A RID: 634
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_UInt32_0;

		// Token: 0x0400027B RID: 635
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt32_0;

		// Token: 0x0400027C RID: 636
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_UInt32_0;

		// Token: 0x0400027D RID: 637
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_UInt32_0;

		// Token: 0x0400027E RID: 638
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUInt_UInt32_0;

		// Token: 0x0400027F RID: 639
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_UInt32_ObscuredUInt_0;

		// Token: 0x04000280 RID: 640
		private static readonly IntPtr NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredInt_ObscuredUInt_0;

		// Token: 0x04000281 RID: 641
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUInt_ObscuredUInt_0;

		// Token: 0x04000282 RID: 642
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUInt_ObscuredUInt_0;

		// Token: 0x04000283 RID: 643
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000284 RID: 644
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUInt_0;

		// Token: 0x04000285 RID: 645
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000286 RID: 646
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000287 RID: 647
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000288 RID: 648
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000289 RID: 649
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x0400028A RID: 650
		[FieldOffset(0)]
		public uint currentCryptoKey;

		// Token: 0x0400028B RID: 651
		[FieldOffset(4)]
		public uint hiddenValue;

		// Token: 0x0400028C RID: 652
		[FieldOffset(8)]
		public uint fakeValue;

		// Token: 0x0400028D RID: 653
		[FieldOffset(12)]
		public bool inited;
	}
}
