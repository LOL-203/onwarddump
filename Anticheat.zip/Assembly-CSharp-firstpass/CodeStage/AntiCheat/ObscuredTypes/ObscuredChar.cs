﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200000F RID: 15
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredChar
	{
		// Token: 0x060000A9 RID: 169 RVA: 0x00004E94 File Offset: 0x00003094
		[CallerCount(0)]
		public unsafe ObscuredChar(char value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr__ctor_Private_Void_Char_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00004EDC File Offset: 0x000030DC
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(char newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Char_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00004F24 File Offset: 0x00003124
		[CallerCount(0)]
		public unsafe static char EncryptDecrypt(char value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00004F78 File Offset: 0x00003178
		[CallerCount(0)]
		public unsafe static char EncryptDecrypt(char value, char key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_Char_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00004FE0 File Offset: 0x000031E0
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00005014 File Offset: 0x00003214
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00005048 File Offset: 0x00003248
		[CallerCount(0)]
		public unsafe char GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_GetEncrypted_Public_Char_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x0000508C File Offset: 0x0000328C
		[CallerCount(0)]
		public unsafe void SetEncrypted(char encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_SetEncrypted_Public_Void_Char_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x000050D4 File Offset: 0x000032D4
		[CallerCount(0)]
		public unsafe char GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_GetDecrypted_Public_Char_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00005118 File Offset: 0x00003318
		[CallerCount(0)]
		public unsafe char InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_InternalDecrypt_Private_Char_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000515C File Offset: 0x0000335C
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredChar(char value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredChar_Char_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x000051B0 File Offset: 0x000033B0
		[CallerCount(0)]
		public unsafe static implicit operator char(ObscuredChar value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_op_Implicit_Public_Static_Char_ObscuredChar_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00005204 File Offset: 0x00003404
		[CallerCount(0)]
		public unsafe static ObscuredChar operator ++(ObscuredChar input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredChar_ObscuredChar_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00005258 File Offset: 0x00003458
		[CallerCount(0)]
		public unsafe static ObscuredChar operator --(ObscuredChar input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredChar_ObscuredChar_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x000052AC File Offset: 0x000034AC
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00005304 File Offset: 0x00003504
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredChar obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredChar_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00005358 File Offset: 0x00003558
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00005394 File Offset: 0x00003594
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000BB RID: 187 RVA: 0x000053E8 File Offset: 0x000035E8
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredChar.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000BC RID: 188 RVA: 0x0000542C File Offset: 0x0000362C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredChar()
		{
			Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredChar");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr);
			ObscuredChar.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, "cryptoKey");
			ObscuredChar.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, "currentCryptoKey");
			ObscuredChar.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, "hiddenValue");
			ObscuredChar.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, "fakeValue");
			ObscuredChar.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, "inited");
			ObscuredChar.NativeMethodInfoPtr__ctor_Private_Void_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663387);
			ObscuredChar.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663388);
			ObscuredChar.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663389);
			ObscuredChar.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663390);
			ObscuredChar.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663391);
			ObscuredChar.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663392);
			ObscuredChar.NativeMethodInfoPtr_GetEncrypted_Public_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663393);
			ObscuredChar.NativeMethodInfoPtr_SetEncrypted_Public_Void_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663394);
			ObscuredChar.NativeMethodInfoPtr_GetDecrypted_Public_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663395);
			ObscuredChar.NativeMethodInfoPtr_InternalDecrypt_Private_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663396);
			ObscuredChar.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredChar_Char_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663397);
			ObscuredChar.NativeMethodInfoPtr_op_Implicit_Public_Static_Char_ObscuredChar_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663398);
			ObscuredChar.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredChar_ObscuredChar_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663399);
			ObscuredChar.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredChar_ObscuredChar_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663400);
			ObscuredChar.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663401);
			ObscuredChar.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredChar_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663402);
			ObscuredChar.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663403);
			ObscuredChar.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663404);
			ObscuredChar.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, 100663405);
		}

		// Token: 0x060000BD RID: 189 RVA: 0x0000563C File Offset: 0x0000383C
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr, ref this));
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000BE RID: 190 RVA: 0x0000564E File Offset: 0x0000384E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredChar>.NativeClassPtr));
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00005660 File Offset: 0x00003860
		// (set) Token: 0x060000C0 RID: 192 RVA: 0x0000567E File Offset: 0x0000387E
		public unsafe static char cryptoKey
		{
			get
			{
				char result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredChar.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredChar.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400008D RID: 141
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400008E RID: 142
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x0400008F RID: 143
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000090 RID: 144
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000091 RID: 145
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000092 RID: 146
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Char_0;

		// Token: 0x04000093 RID: 147
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Char_0;

		// Token: 0x04000094 RID: 148
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_0;

		// Token: 0x04000095 RID: 149
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Char_Char_Char_0;

		// Token: 0x04000096 RID: 150
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000097 RID: 151
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x04000098 RID: 152
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Char_0;

		// Token: 0x04000099 RID: 153
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Char_0;

		// Token: 0x0400009A RID: 154
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Char_0;

		// Token: 0x0400009B RID: 155
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Char_0;

		// Token: 0x0400009C RID: 156
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredChar_Char_0;

		// Token: 0x0400009D RID: 157
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Char_ObscuredChar_0;

		// Token: 0x0400009E RID: 158
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredChar_ObscuredChar_0;

		// Token: 0x0400009F RID: 159
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredChar_ObscuredChar_0;

		// Token: 0x040000A0 RID: 160
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040000A1 RID: 161
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredChar_0;

		// Token: 0x040000A2 RID: 162
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040000A3 RID: 163
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x040000A4 RID: 164
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040000A5 RID: 165
		[FieldOffset(0)]
		public char currentCryptoKey;

		// Token: 0x040000A6 RID: 166
		[FieldOffset(2)]
		public char hiddenValue;

		// Token: 0x040000A7 RID: 167
		[FieldOffset(4)]
		public char fakeValue;

		// Token: 0x040000A8 RID: 168
		[FieldOffset(6)]
		public bool inited;
	}
}
