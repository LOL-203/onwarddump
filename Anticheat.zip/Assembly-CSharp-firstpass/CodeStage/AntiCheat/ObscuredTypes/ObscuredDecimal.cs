﻿using System;
using System.Runtime.InteropServices;
using CodeStage.AntiCheat.Common;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000010 RID: 16
	[Serializable]
	[StructLayout(0)]
	public sealed class ObscuredDecimal : ValueType
	{
		// Token: 0x060000C1 RID: 193 RVA: 0x00005690 File Offset: 0x00003890
		[CallerCount(0)]
		public unsafe ObscuredDecimal(ACTkByte16 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte16_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x000056E4 File Offset: 0x000038E4
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(long newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000572C File Offset: 0x0000392C
		[CallerCount(0)]
		public unsafe static Decimal Encrypt(Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x00005780 File Offset: 0x00003980
		[CallerCount(0)]
		public unsafe static Decimal Encrypt(Decimal value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x000057E8 File Offset: 0x000039E8
		[CallerCount(0)]
		public unsafe static ACTkByte16 InternalEncrypt(Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0000583C File Offset: 0x00003A3C
		[CallerCount(0)]
		public unsafe static ACTkByte16 InternalEncrypt(Decimal value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000058A4 File Offset: 0x00003AA4
		[CallerCount(0)]
		public unsafe static Decimal Decrypt(Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x000058F8 File Offset: 0x00003AF8
		[CallerCount(0)]
		public unsafe static Decimal Decrypt(Decimal value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00005960 File Offset: 0x00003B60
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000059A0 File Offset: 0x00003BA0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000059E0 File Offset: 0x00003BE0
		[CallerCount(0)]
		public unsafe Decimal GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_GetEncrypted_Public_Decimal_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00005A30 File Offset: 0x00003C30
		[CallerCount(0)]
		public unsafe void SetEncrypted(Decimal encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_SetEncrypted_Public_Void_Decimal_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00005A84 File Offset: 0x00003C84
		[CallerCount(0)]
		public unsafe Decimal GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_GetDecrypted_Public_Decimal_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00005AD4 File Offset: 0x00003CD4
		[CallerCount(0)]
		public unsafe Decimal InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_InternalDecrypt_Private_Decimal_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00005B24 File Offset: 0x00003D24
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredDecimal(Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDecimal_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDecimal(intPtr);
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00005B74 File Offset: 0x00003D74
		[CallerCount(0)]
		public unsafe static implicit operator Decimal(ObscuredDecimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(value));
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_op_Implicit_Public_Static_Decimal_ObscuredDecimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00005BD4 File Offset: 0x00003DD4
		[CallerCount(0)]
		public unsafe static explicit operator ObscuredDecimal(ObscuredFloat f)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(f));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredDecimal_ObscuredFloat_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDecimal(intPtr);
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00005C2C File Offset: 0x00003E2C
		[CallerCount(0)]
		public unsafe static ObscuredDecimal operator ++(ObscuredDecimal input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDecimal_ObscuredDecimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDecimal(intPtr);
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00005C84 File Offset: 0x00003E84
		[CallerCount(0)]
		public unsafe static ObscuredDecimal operator --(ObscuredDecimal input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDecimal_ObscuredDecimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDecimal(intPtr);
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00005CDC File Offset: 0x00003EDC
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00005D28 File Offset: 0x00003F28
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_String_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00005D88 File Offset: 0x00003F88
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00005DE8 File Offset: 0x00003FE8
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00005E60 File Offset: 0x00004060
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00005EC8 File Offset: 0x000040C8
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredDecimal obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(obj));
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDecimal_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00005F34 File Offset: 0x00004134
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDecimal.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00005F84 File Offset: 0x00004184
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredDecimal()
		{
			Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredDecimal");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr);
			ObscuredDecimal.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "cryptoKey");
			ObscuredDecimal.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "currentCryptoKey");
			ObscuredDecimal.NativeFieldInfoPtr_hiddenValueOld = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "hiddenValueOld");
			ObscuredDecimal.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "hiddenValue");
			ObscuredDecimal.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "fakeValue");
			ObscuredDecimal.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "inited");
			ObscuredDecimal.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663407);
			ObscuredDecimal.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663408);
			ObscuredDecimal.NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663409);
			ObscuredDecimal.NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663410);
			ObscuredDecimal.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663411);
			ObscuredDecimal.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663412);
			ObscuredDecimal.NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663413);
			ObscuredDecimal.NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663414);
			ObscuredDecimal.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663415);
			ObscuredDecimal.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663416);
			ObscuredDecimal.NativeMethodInfoPtr_GetEncrypted_Public_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663417);
			ObscuredDecimal.NativeMethodInfoPtr_SetEncrypted_Public_Void_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663418);
			ObscuredDecimal.NativeMethodInfoPtr_GetDecrypted_Public_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663419);
			ObscuredDecimal.NativeMethodInfoPtr_InternalDecrypt_Private_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663420);
			ObscuredDecimal.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDecimal_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663421);
			ObscuredDecimal.NativeMethodInfoPtr_op_Implicit_Public_Static_Decimal_ObscuredDecimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663422);
			ObscuredDecimal.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredDecimal_ObscuredFloat_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663423);
			ObscuredDecimal.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDecimal_ObscuredDecimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663424);
			ObscuredDecimal.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDecimal_ObscuredDecimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663425);
			ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663426);
			ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663427);
			ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663428);
			ObscuredDecimal.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663429);
			ObscuredDecimal.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663430);
			ObscuredDecimal.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDecimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663431);
			ObscuredDecimal.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, 100663432);
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00006234 File Offset: 0x00004434
		public ObscuredDecimal(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060000DD RID: 221 RVA: 0x0000623D File Offset: 0x0000443D
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr));
			}
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00006250 File Offset: 0x00004450
		public unsafe ObscuredDecimal()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, data));
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000DF RID: 223 RVA: 0x00006280 File Offset: 0x00004480
		// (set) Token: 0x060000E0 RID: 224 RVA: 0x0000629E File Offset: 0x0000449E
		public unsafe static long cryptoKey
		{
			get
			{
				long result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredDecimal.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredDecimal.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x000062B0 File Offset: 0x000044B0
		// (set) Token: 0x060000E2 RID: 226 RVA: 0x000062D8 File Offset: 0x000044D8
		public unsafe long currentCryptoKey
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_currentCryptoKey);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_currentCryptoKey)) = value;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x000062FC File Offset: 0x000044FC
		// (set) Token: 0x060000E4 RID: 228 RVA: 0x00006330 File Offset: 0x00004530
		public unsafe Il2CppStructArray<byte> hiddenValueOld
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_hiddenValueOld);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_hiddenValueOld), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x00006358 File Offset: 0x00004558
		// (set) Token: 0x060000E6 RID: 230 RVA: 0x00006380 File Offset: 0x00004580
		public unsafe ACTkByte16 hiddenValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_hiddenValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_hiddenValue)) = value;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000E7 RID: 231 RVA: 0x000063A4 File Offset: 0x000045A4
		// (set) Token: 0x060000E8 RID: 232 RVA: 0x000063CC File Offset: 0x000045CC
		public unsafe Decimal fakeValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_fakeValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_fakeValue)) = value;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x000063F0 File Offset: 0x000045F0
		// (set) Token: 0x060000EA RID: 234 RVA: 0x00006418 File Offset: 0x00004618
		public unsafe bool inited
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_inited);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDecimal.NativeFieldInfoPtr_inited)) = value;
			}
		}

		// Token: 0x040000A9 RID: 169
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040000AA RID: 170
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040000AB RID: 171
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValueOld;

		// Token: 0x040000AC RID: 172
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040000AD RID: 173
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040000AE RID: 174
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040000AF RID: 175
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_ACTkByte16_0;

		// Token: 0x040000B0 RID: 176
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0;

		// Token: 0x040000B1 RID: 177
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_0;

		// Token: 0x040000B2 RID: 178
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Decimal_Decimal_Int64_0;

		// Token: 0x040000B3 RID: 179
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_0;

		// Token: 0x040000B4 RID: 180
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte16_Decimal_Int64_0;

		// Token: 0x040000B5 RID: 181
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_0;

		// Token: 0x040000B6 RID: 182
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Decimal_Decimal_Int64_0;

		// Token: 0x040000B7 RID: 183
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x040000B8 RID: 184
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x040000B9 RID: 185
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Decimal_0;

		// Token: 0x040000BA RID: 186
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Decimal_0;

		// Token: 0x040000BB RID: 187
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Decimal_0;

		// Token: 0x040000BC RID: 188
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Decimal_0;

		// Token: 0x040000BD RID: 189
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDecimal_Decimal_0;

		// Token: 0x040000BE RID: 190
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Decimal_ObscuredDecimal_0;

		// Token: 0x040000BF RID: 191
		private static readonly IntPtr NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredDecimal_ObscuredFloat_0;

		// Token: 0x040000C0 RID: 192
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDecimal_ObscuredDecimal_0;

		// Token: 0x040000C1 RID: 193
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDecimal_ObscuredDecimal_0;

		// Token: 0x040000C2 RID: 194
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040000C3 RID: 195
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040000C4 RID: 196
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x040000C5 RID: 197
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x040000C6 RID: 198
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040000C7 RID: 199
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDecimal_0;

		// Token: 0x040000C8 RID: 200
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x02000011 RID: 17
		[StructLayout(2)]
		public struct DecimalLongBytesUnion
		{
			// Token: 0x060000EB RID: 235 RVA: 0x0000643C File Offset: 0x0000463C
			// Note: this type is marked as 'beforefieldinit'.
			static DecimalLongBytesUnion()
			{
				Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredDecimal>.NativeClassPtr, "DecimalLongBytesUnion");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr);
				ObscuredDecimal.DecimalLongBytesUnion.NativeFieldInfoPtr_d = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr, "d");
				ObscuredDecimal.DecimalLongBytesUnion.NativeFieldInfoPtr_l1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr, "l1");
				ObscuredDecimal.DecimalLongBytesUnion.NativeFieldInfoPtr_l2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr, "l2");
				ObscuredDecimal.DecimalLongBytesUnion.NativeFieldInfoPtr_b16 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr, "b16");
			}

			// Token: 0x060000EC RID: 236 RVA: 0x000064B7 File Offset: 0x000046B7
			public Object BoxIl2CppObject()
			{
				return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr, ref this));
			}

			// Token: 0x17000036 RID: 54
			// (get) Token: 0x060000ED RID: 237 RVA: 0x000064C9 File Offset: 0x000046C9
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredDecimal.DecimalLongBytesUnion>.NativeClassPtr));
				}
			}

			// Token: 0x040000C9 RID: 201
			private static readonly IntPtr NativeFieldInfoPtr_d;

			// Token: 0x040000CA RID: 202
			private static readonly IntPtr NativeFieldInfoPtr_l1;

			// Token: 0x040000CB RID: 203
			private static readonly IntPtr NativeFieldInfoPtr_l2;

			// Token: 0x040000CC RID: 204
			private static readonly IntPtr NativeFieldInfoPtr_b16;

			// Token: 0x040000CD RID: 205
			[FieldOffset(0)]
			public Decimal d;

			// Token: 0x040000CE RID: 206
			[FieldOffset(0)]
			public long l1;

			// Token: 0x040000CF RID: 207
			[FieldOffset(8)]
			public long l2;

			// Token: 0x040000D0 RID: 208
			[FieldOffset(0)]
			public ACTkByte16 b16;
		}
	}
}
