﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000017 RID: 23
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredLong
	{
		// Token: 0x06000165 RID: 357 RVA: 0x00008B5C File Offset: 0x00006D5C
		[CallerCount(0)]
		public unsafe ObscuredLong(long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr__ctor_Private_Void_Int64_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00008BA4 File Offset: 0x00006DA4
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(long newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00008BEC File Offset: 0x00006DEC
		[CallerCount(0)]
		public unsafe static long Encrypt(long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00008C40 File Offset: 0x00006E40
		[CallerCount(0)]
		public unsafe static long Decrypt(long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00008C94 File Offset: 0x00006E94
		[CallerCount(0)]
		public unsafe static long Encrypt(long value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00008CFC File Offset: 0x00006EFC
		[CallerCount(0)]
		public unsafe static long Decrypt(long value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00008D64 File Offset: 0x00006F64
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00008D98 File Offset: 0x00006F98
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00008DCC File Offset: 0x00006FCC
		[CallerCount(0)]
		public unsafe long GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_GetEncrypted_Public_Int64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00008E10 File Offset: 0x00007010
		[CallerCount(0)]
		public unsafe void SetEncrypted(long encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600016F RID: 367 RVA: 0x00008E58 File Offset: 0x00007058
		[CallerCount(0)]
		public unsafe long GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_GetDecrypted_Public_Int64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000170 RID: 368 RVA: 0x00008E9C File Offset: 0x0000709C
		[CallerCount(0)]
		public unsafe long InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_InternalDecrypt_Private_Int64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000171 RID: 369 RVA: 0x00008EE0 File Offset: 0x000070E0
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredLong(long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredLong_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x00008F34 File Offset: 0x00007134
		[CallerCount(0)]
		public unsafe static implicit operator long(ObscuredLong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_op_Implicit_Public_Static_Int64_ObscuredLong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000173 RID: 371 RVA: 0x00008F88 File Offset: 0x00007188
		[CallerCount(0)]
		public unsafe static ObscuredLong operator ++(ObscuredLong input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredLong_ObscuredLong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000174 RID: 372 RVA: 0x00008FDC File Offset: 0x000071DC
		[CallerCount(0)]
		public unsafe static ObscuredLong operator --(ObscuredLong input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredLong_ObscuredLong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000175 RID: 373 RVA: 0x00009030 File Offset: 0x00007230
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000176 RID: 374 RVA: 0x00009088 File Offset: 0x00007288
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredLong obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredLong_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000177 RID: 375 RVA: 0x000090DC File Offset: 0x000072DC
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000178 RID: 376 RVA: 0x00009120 File Offset: 0x00007320
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000915C File Offset: 0x0000735C
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600017A RID: 378 RVA: 0x000091B0 File Offset: 0x000073B0
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600017B RID: 379 RVA: 0x00009204 File Offset: 0x00007404
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredLong.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600017C RID: 380 RVA: 0x00009270 File Offset: 0x00007470
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredLong()
		{
			Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredLong");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr);
			ObscuredLong.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, "cryptoKey");
			ObscuredLong.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, "currentCryptoKey");
			ObscuredLong.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, "hiddenValue");
			ObscuredLong.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, "fakeValue");
			ObscuredLong.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, "inited");
			ObscuredLong.NativeMethodInfoPtr__ctor_Private_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663513);
			ObscuredLong.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663514);
			ObscuredLong.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663515);
			ObscuredLong.NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663516);
			ObscuredLong.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663517);
			ObscuredLong.NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663518);
			ObscuredLong.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663519);
			ObscuredLong.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663520);
			ObscuredLong.NativeMethodInfoPtr_GetEncrypted_Public_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663521);
			ObscuredLong.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663522);
			ObscuredLong.NativeMethodInfoPtr_GetDecrypted_Public_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663523);
			ObscuredLong.NativeMethodInfoPtr_InternalDecrypt_Private_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663524);
			ObscuredLong.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredLong_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663525);
			ObscuredLong.NativeMethodInfoPtr_op_Implicit_Public_Static_Int64_ObscuredLong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663526);
			ObscuredLong.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredLong_ObscuredLong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663527);
			ObscuredLong.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredLong_ObscuredLong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663528);
			ObscuredLong.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663529);
			ObscuredLong.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredLong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663530);
			ObscuredLong.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663531);
			ObscuredLong.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663532);
			ObscuredLong.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663533);
			ObscuredLong.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663534);
			ObscuredLong.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, 100663535);
		}

		// Token: 0x0600017D RID: 381 RVA: 0x000094D0 File Offset: 0x000076D0
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr, ref this));
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600017E RID: 382 RVA: 0x000094E2 File Offset: 0x000076E2
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredLong>.NativeClassPtr));
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600017F RID: 383 RVA: 0x000094F4 File Offset: 0x000076F4
		// (set) Token: 0x06000180 RID: 384 RVA: 0x00009512 File Offset: 0x00007712
		public unsafe static long cryptoKey
		{
			get
			{
				long result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredLong.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredLong.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400013E RID: 318
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400013F RID: 319
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000140 RID: 320
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000141 RID: 321
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000142 RID: 322
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000143 RID: 323
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Int64_0;

		// Token: 0x04000144 RID: 324
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0;

		// Token: 0x04000145 RID: 325
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_0;

		// Token: 0x04000146 RID: 326
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_0;

		// Token: 0x04000147 RID: 327
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Int64_Int64_0;

		// Token: 0x04000148 RID: 328
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Int64_Int64_Int64_0;

		// Token: 0x04000149 RID: 329
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400014A RID: 330
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400014B RID: 331
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int64_0;

		// Token: 0x0400014C RID: 332
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0;

		// Token: 0x0400014D RID: 333
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Int64_0;

		// Token: 0x0400014E RID: 334
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Int64_0;

		// Token: 0x0400014F RID: 335
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredLong_Int64_0;

		// Token: 0x04000150 RID: 336
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Int64_ObscuredLong_0;

		// Token: 0x04000151 RID: 337
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredLong_ObscuredLong_0;

		// Token: 0x04000152 RID: 338
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredLong_ObscuredLong_0;

		// Token: 0x04000153 RID: 339
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000154 RID: 340
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredLong_0;

		// Token: 0x04000155 RID: 341
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000156 RID: 342
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000157 RID: 343
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000158 RID: 344
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000159 RID: 345
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x0400015A RID: 346
		[FieldOffset(0)]
		public long currentCryptoKey;

		// Token: 0x0400015B RID: 347
		[FieldOffset(8)]
		public long hiddenValue;

		// Token: 0x0400015C RID: 348
		[FieldOffset(16)]
		public long fakeValue;

		// Token: 0x0400015D RID: 349
		[FieldOffset(24)]
		public bool inited;
	}
}
