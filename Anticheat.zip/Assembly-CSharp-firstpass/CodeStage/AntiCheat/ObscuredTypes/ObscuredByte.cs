﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200000E RID: 14
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredByte
	{
		// Token: 0x0600008F RID: 143 RVA: 0x000045B0 File Offset: 0x000027B0
		[CallerCount(0)]
		public unsafe ObscuredByte(byte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr__ctor_Private_Void_Byte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000090 RID: 144 RVA: 0x000045F8 File Offset: 0x000027F8
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(byte newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00004640 File Offset: 0x00002840
		[CallerCount(0)]
		public unsafe static byte EncryptDecrypt(byte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00004694 File Offset: 0x00002894
		[CallerCount(0)]
		public unsafe static byte EncryptDecrypt(byte value, byte key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000093 RID: 147 RVA: 0x000046FC File Offset: 0x000028FC
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00004730 File Offset: 0x00002930
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00004764 File Offset: 0x00002964
		[CallerCount(0)]
		public unsafe byte GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_GetEncrypted_Public_Byte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000047A8 File Offset: 0x000029A8
		[CallerCount(0)]
		public unsafe void SetEncrypted(byte encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_SetEncrypted_Public_Void_Byte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000097 RID: 151 RVA: 0x000047F0 File Offset: 0x000029F0
		[CallerCount(0)]
		public unsafe byte GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_GetDecrypted_Public_Byte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00004834 File Offset: 0x00002A34
		[CallerCount(0)]
		public unsafe byte InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_InternalDecrypt_Private_Byte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00004878 File Offset: 0x00002A78
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredByte(byte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredByte_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x000048CC File Offset: 0x00002ACC
		[CallerCount(0)]
		public unsafe static implicit operator byte(ObscuredByte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_op_Implicit_Public_Static_Byte_ObscuredByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00004920 File Offset: 0x00002B20
		[CallerCount(0)]
		public unsafe static ObscuredByte operator ++(ObscuredByte input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredByte_ObscuredByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00004974 File Offset: 0x00002B74
		[CallerCount(0)]
		public unsafe static ObscuredByte operator --(ObscuredByte input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredByte_ObscuredByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600009D RID: 157 RVA: 0x000049C8 File Offset: 0x00002BC8
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00004A20 File Offset: 0x00002C20
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredByte obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredByte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00004A74 File Offset: 0x00002C74
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00004AB0 File Offset: 0x00002CB0
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00004B04 File Offset: 0x00002D04
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00004B48 File Offset: 0x00002D48
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x00004B9C File Offset: 0x00002D9C
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredByte.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00004C08 File Offset: 0x00002E08
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredByte()
		{
			Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredByte");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr);
			ObscuredByte.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, "cryptoKey");
			ObscuredByte.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, "currentCryptoKey");
			ObscuredByte.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, "hiddenValue");
			ObscuredByte.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, "fakeValue");
			ObscuredByte.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, "inited");
			ObscuredByte.NativeMethodInfoPtr__ctor_Private_Void_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663365);
			ObscuredByte.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663366);
			ObscuredByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663367);
			ObscuredByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663368);
			ObscuredByte.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663369);
			ObscuredByte.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663370);
			ObscuredByte.NativeMethodInfoPtr_GetEncrypted_Public_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663371);
			ObscuredByte.NativeMethodInfoPtr_SetEncrypted_Public_Void_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663372);
			ObscuredByte.NativeMethodInfoPtr_GetDecrypted_Public_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663373);
			ObscuredByte.NativeMethodInfoPtr_InternalDecrypt_Private_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663374);
			ObscuredByte.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredByte_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663375);
			ObscuredByte.NativeMethodInfoPtr_op_Implicit_Public_Static_Byte_ObscuredByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663376);
			ObscuredByte.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredByte_ObscuredByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663377);
			ObscuredByte.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredByte_ObscuredByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663378);
			ObscuredByte.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663379);
			ObscuredByte.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663380);
			ObscuredByte.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663381);
			ObscuredByte.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663382);
			ObscuredByte.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663383);
			ObscuredByte.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663384);
			ObscuredByte.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, 100663385);
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00004E40 File Offset: 0x00003040
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr, ref this));
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000A6 RID: 166 RVA: 0x00004E52 File Offset: 0x00003052
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredByte>.NativeClassPtr));
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x00004E64 File Offset: 0x00003064
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x00004E82 File Offset: 0x00003082
		public unsafe static byte cryptoKey
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredByte.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredByte.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400006F RID: 111
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x04000070 RID: 112
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000071 RID: 113
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000072 RID: 114
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000073 RID: 115
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000074 RID: 116
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Byte_0;

		// Token: 0x04000075 RID: 117
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0;

		// Token: 0x04000076 RID: 118
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_0;

		// Token: 0x04000077 RID: 119
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Byte_Byte_Byte_0;

		// Token: 0x04000078 RID: 120
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000079 RID: 121
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400007A RID: 122
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Byte_0;

		// Token: 0x0400007B RID: 123
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Byte_0;

		// Token: 0x0400007C RID: 124
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Byte_0;

		// Token: 0x0400007D RID: 125
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Byte_0;

		// Token: 0x0400007E RID: 126
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredByte_Byte_0;

		// Token: 0x0400007F RID: 127
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Byte_ObscuredByte_0;

		// Token: 0x04000080 RID: 128
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredByte_ObscuredByte_0;

		// Token: 0x04000081 RID: 129
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredByte_ObscuredByte_0;

		// Token: 0x04000082 RID: 130
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000083 RID: 131
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredByte_0;

		// Token: 0x04000084 RID: 132
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000085 RID: 133
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000086 RID: 134
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000087 RID: 135
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000088 RID: 136
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x04000089 RID: 137
		[FieldOffset(0)]
		public byte currentCryptoKey;

		// Token: 0x0400008A RID: 138
		[FieldOffset(1)]
		public byte hiddenValue;

		// Token: 0x0400008B RID: 139
		[FieldOffset(2)]
		public byte fakeValue;

		// Token: 0x0400008C RID: 140
		[FieldOffset(3)]
		public bool inited;
	}
}
