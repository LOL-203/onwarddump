﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000024 RID: 36
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredVector2
	{
		// Token: 0x060002DF RID: 735 RVA: 0x00011140 File Offset: 0x0000F340
		[CallerCount(0)]
		public unsafe ObscuredVector2(ObscuredVector2.RawEncryptedVector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector2_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x00011188 File Offset: 0x0000F388
		[CallerCount(0)]
		public unsafe ObscuredVector2(float x, float y)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060002E1 RID: 737 RVA: 0x000111E0 File Offset: 0x0000F3E0
		// (set) Token: 0x060002E2 RID: 738 RVA: 0x00011224 File Offset: 0x0000F424
		public unsafe float x
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_get_x_Public_get_Single_0, ref this, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_set_x_Public_set_Void_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060002E3 RID: 739 RVA: 0x0001126C File Offset: 0x0000F46C
		// (set) Token: 0x060002E4 RID: 740 RVA: 0x000112B0 File Offset: 0x0000F4B0
		public unsafe float y
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_get_y_Public_get_Single_0, ref this, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_set_y_Public_set_Void_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700007D RID: 125
		public unsafe float this[int index]
		{
			[CallerCount(0)]
			get
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref index;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref index;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x000113A4 File Offset: 0x0000F5A4
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(int newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x000113EC File Offset: 0x0000F5EC
		[CallerCount(0)]
		public unsafe static ObscuredVector2.RawEncryptedVector2 Encrypt(Vector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x00011440 File Offset: 0x0000F640
		[CallerCount(0)]
		public unsafe static ObscuredVector2.RawEncryptedVector2 Encrypt(Vector2 value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002EA RID: 746 RVA: 0x000114A8 File Offset: 0x0000F6A8
		[CallerCount(0)]
		public unsafe static ObscuredVector2.RawEncryptedVector2 Encrypt(float x, float y, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Single_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00011524 File Offset: 0x0000F724
		[CallerCount(0)]
		public unsafe static Vector2 Decrypt(ObscuredVector2.RawEncryptedVector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00011578 File Offset: 0x0000F778
		[CallerCount(0)]
		public unsafe static Vector2 Decrypt(ObscuredVector2.RawEncryptedVector2 value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002ED RID: 749 RVA: 0x000115E0 File Offset: 0x0000F7E0
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002EE RID: 750 RVA: 0x00011614 File Offset: 0x0000F814
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00011648 File Offset: 0x0000F848
		[CallerCount(0)]
		public unsafe ObscuredVector2.RawEncryptedVector2 GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector2_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x0001168C File Offset: 0x0000F88C
		[CallerCount(0)]
		public unsafe void SetEncrypted(ObscuredVector2.RawEncryptedVector2 encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector2_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x000116D4 File Offset: 0x0000F8D4
		[CallerCount(0)]
		public unsafe Vector2 GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_GetDecrypted_Public_Vector2_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x00011718 File Offset: 0x0000F918
		[CallerCount(0)]
		public unsafe Vector2 InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_InternalDecrypt_Private_Vector2_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x0001175C File Offset: 0x0000F95C
		[CallerCount(0)]
		public unsafe bool CompareVectorsWithTolerance(Vector2 vector1, Vector2 vector2)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref vector1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vector2;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector2_Vector2_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x000117C4 File Offset: 0x0000F9C4
		[CallerCount(0)]
		public unsafe float InternalDecryptField(int encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00011818 File Offset: 0x0000FA18
		[CallerCount(0)]
		public unsafe int InternalEncryptField(float encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x0001186C File Offset: 0x0000FA6C
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredVector2(Vector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector2_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x000118C0 File Offset: 0x0000FAC0
		[CallerCount(0)]
		public unsafe static implicit operator Vector2(ObscuredVector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector2_ObscuredVector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x00011914 File Offset: 0x0000FB14
		[CallerCount(0)]
		public unsafe static implicit operator Vector3(ObscuredVector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00011968 File Offset: 0x0000FB68
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002FA RID: 762 RVA: 0x000119AC File Offset: 0x0000FBAC
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002FB RID: 763 RVA: 0x000119E8 File Offset: 0x0000FBE8
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredVector2.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00011A3C File Offset: 0x0000FC3C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredVector2()
		{
			Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredVector2");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr);
			ObscuredVector2.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "cryptoKey");
			ObscuredVector2.NativeFieldInfoPtr_initialFakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "initialFakeValue");
			ObscuredVector2.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "currentCryptoKey");
			ObscuredVector2.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "hiddenValue");
			ObscuredVector2.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "fakeValue");
			ObscuredVector2.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "inited");
			ObscuredVector2.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663807);
			ObscuredVector2.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663808);
			ObscuredVector2.NativeMethodInfoPtr_get_x_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663809);
			ObscuredVector2.NativeMethodInfoPtr_set_x_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663810);
			ObscuredVector2.NativeMethodInfoPtr_get_y_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663811);
			ObscuredVector2.NativeMethodInfoPtr_set_y_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663812);
			ObscuredVector2.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663813);
			ObscuredVector2.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663814);
			ObscuredVector2.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663815);
			ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663816);
			ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663817);
			ObscuredVector2.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663818);
			ObscuredVector2.NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663819);
			ObscuredVector2.NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663820);
			ObscuredVector2.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663821);
			ObscuredVector2.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663822);
			ObscuredVector2.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663823);
			ObscuredVector2.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663824);
			ObscuredVector2.NativeMethodInfoPtr_GetDecrypted_Public_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663825);
			ObscuredVector2.NativeMethodInfoPtr_InternalDecrypt_Private_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663826);
			ObscuredVector2.NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663827);
			ObscuredVector2.NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663828);
			ObscuredVector2.NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663829);
			ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector2_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663830);
			ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector2_ObscuredVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663831);
			ObscuredVector2.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663832);
			ObscuredVector2.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663833);
			ObscuredVector2.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663834);
			ObscuredVector2.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, 100663835);
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00011D28 File Offset: 0x0000FF28
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, ref this));
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060002FE RID: 766 RVA: 0x00011D3A File Offset: 0x0000FF3A
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr));
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060002FF RID: 767 RVA: 0x00011D4C File Offset: 0x0000FF4C
		// (set) Token: 0x06000300 RID: 768 RVA: 0x00011D6A File Offset: 0x0000FF6A
		public unsafe static int cryptoKey
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredVector2.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredVector2.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000301 RID: 769 RVA: 0x00011D7C File Offset: 0x0000FF7C
		// (set) Token: 0x06000302 RID: 770 RVA: 0x00011D9A File Offset: 0x0000FF9A
		public unsafe static Vector2 initialFakeValue
		{
			get
			{
				Vector2 result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredVector2.NativeFieldInfoPtr_initialFakeValue, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredVector2.NativeFieldInfoPtr_initialFakeValue, (void*)(&value));
			}
		}

		// Token: 0x040002CC RID: 716
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040002CD RID: 717
		private static readonly IntPtr NativeFieldInfoPtr_initialFakeValue;

		// Token: 0x040002CE RID: 718
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040002CF RID: 719
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040002D0 RID: 720
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040002D1 RID: 721
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040002D2 RID: 722
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector2_0;

		// Token: 0x040002D3 RID: 723
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Single_Single_0;

		// Token: 0x040002D4 RID: 724
		private static readonly IntPtr NativeMethodInfoPtr_get_x_Public_get_Single_0;

		// Token: 0x040002D5 RID: 725
		private static readonly IntPtr NativeMethodInfoPtr_set_x_Public_set_Void_Single_0;

		// Token: 0x040002D6 RID: 726
		private static readonly IntPtr NativeMethodInfoPtr_get_y_Public_get_Single_0;

		// Token: 0x040002D7 RID: 727
		private static readonly IntPtr NativeMethodInfoPtr_set_y_Public_set_Void_Single_0;

		// Token: 0x040002D8 RID: 728
		private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0;

		// Token: 0x040002D9 RID: 729
		private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0;

		// Token: 0x040002DA RID: 730
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0;

		// Token: 0x040002DB RID: 731
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_0;

		// Token: 0x040002DC RID: 732
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Vector2_Int32_0;

		// Token: 0x040002DD RID: 733
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector2_Single_Single_Int32_0;

		// Token: 0x040002DE RID: 734
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_0;

		// Token: 0x040002DF RID: 735
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Vector2_RawEncryptedVector2_Int32_0;

		// Token: 0x040002E0 RID: 736
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x040002E1 RID: 737
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x040002E2 RID: 738
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector2_0;

		// Token: 0x040002E3 RID: 739
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector2_0;

		// Token: 0x040002E4 RID: 740
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Vector2_0;

		// Token: 0x040002E5 RID: 741
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Vector2_0;

		// Token: 0x040002E6 RID: 742
		private static readonly IntPtr NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector2_Vector2_0;

		// Token: 0x040002E7 RID: 743
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0;

		// Token: 0x040002E8 RID: 744
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0;

		// Token: 0x040002E9 RID: 745
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector2_Vector2_0;

		// Token: 0x040002EA RID: 746
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Vector2_ObscuredVector2_0;

		// Token: 0x040002EB RID: 747
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector2_0;

		// Token: 0x040002EC RID: 748
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040002ED RID: 749
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040002EE RID: 750
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040002EF RID: 751
		[FieldOffset(0)]
		public int currentCryptoKey;

		// Token: 0x040002F0 RID: 752
		[FieldOffset(4)]
		public ObscuredVector2.RawEncryptedVector2 hiddenValue;

		// Token: 0x040002F1 RID: 753
		[FieldOffset(12)]
		public Vector2 fakeValue;

		// Token: 0x040002F2 RID: 754
		[FieldOffset(20)]
		public bool inited;

		// Token: 0x02000025 RID: 37
		[Serializable]
		[StructLayout(2)]
		public struct RawEncryptedVector2
		{
			// Token: 0x06000303 RID: 771 RVA: 0x00011DAC File Offset: 0x0000FFAC
			// Note: this type is marked as 'beforefieldinit'.
			static RawEncryptedVector2()
			{
				Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredVector2>.NativeClassPtr, "RawEncryptedVector2");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr);
				ObscuredVector2.RawEncryptedVector2.NativeFieldInfoPtr_x = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr, "x");
				ObscuredVector2.RawEncryptedVector2.NativeFieldInfoPtr_y = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr, "y");
			}

			// Token: 0x06000304 RID: 772 RVA: 0x00011DFF File Offset: 0x0000FFFF
			public Il2CppSystem.Object BoxIl2CppObject()
			{
				return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr, ref this));
			}

			// Token: 0x1700007E RID: 126
			// (get) Token: 0x06000305 RID: 773 RVA: 0x00011E11 File Offset: 0x00010011
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredVector2.RawEncryptedVector2>.NativeClassPtr));
				}
			}

			// Token: 0x040002F3 RID: 755
			private static readonly IntPtr NativeFieldInfoPtr_x;

			// Token: 0x040002F4 RID: 756
			private static readonly IntPtr NativeFieldInfoPtr_y;

			// Token: 0x040002F5 RID: 757
			[FieldOffset(0)]
			public int x;

			// Token: 0x040002F6 RID: 758
			[FieldOffset(4)]
			public int y;
		}
	}
}
