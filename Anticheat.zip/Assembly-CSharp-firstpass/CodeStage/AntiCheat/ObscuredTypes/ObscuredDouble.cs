﻿using System;
using System.Runtime.InteropServices;
using CodeStage.AntiCheat.Common;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000012 RID: 18
	[Serializable]
	[StructLayout(0)]
	public sealed class ObscuredDouble : ValueType
	{
		// Token: 0x060000EE RID: 238 RVA: 0x000064DC File Offset: 0x000046DC
		[CallerCount(0)]
		public unsafe ObscuredDouble(ACTkByte8 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte8_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00006530 File Offset: 0x00004730
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(long newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00006578 File Offset: 0x00004778
		[CallerCount(0)]
		public unsafe static long Encrypt(double value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x000065CC File Offset: 0x000047CC
		[CallerCount(0)]
		public unsafe static long Encrypt(double value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00006634 File Offset: 0x00004834
		[CallerCount(0)]
		public unsafe static ACTkByte8 InternalEncrypt(double value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x00006688 File Offset: 0x00004888
		[CallerCount(0)]
		public unsafe static ACTkByte8 InternalEncrypt(double value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x000066F0 File Offset: 0x000048F0
		[CallerCount(0)]
		public unsafe static double Decrypt(long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x00006744 File Offset: 0x00004944
		[CallerCount(0)]
		public unsafe static double Decrypt(long value, long key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x000067AC File Offset: 0x000049AC
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x000067EC File Offset: 0x000049EC
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000682C File Offset: 0x00004A2C
		[CallerCount(0)]
		public unsafe long GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_GetEncrypted_Public_Int64_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000687C File Offset: 0x00004A7C
		[CallerCount(0)]
		public unsafe void SetEncrypted(long encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060000FA RID: 250 RVA: 0x000068D0 File Offset: 0x00004AD0
		[CallerCount(0)]
		public unsafe double GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_GetDecrypted_Public_Double_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000FB RID: 251 RVA: 0x00006920 File Offset: 0x00004B20
		[CallerCount(0)]
		public unsafe double InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_InternalDecrypt_Private_Double_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000FC RID: 252 RVA: 0x00006970 File Offset: 0x00004B70
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredDouble(double value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDouble(intPtr);
		}

		// Token: 0x060000FD RID: 253 RVA: 0x000069C0 File Offset: 0x00004BC0
		[CallerCount(0)]
		public unsafe static implicit operator double(ObscuredDouble value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(value));
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_op_Implicit_Public_Static_Double_ObscuredDouble_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060000FE RID: 254 RVA: 0x00006A20 File Offset: 0x00004C20
		[CallerCount(0)]
		public unsafe static ObscuredDouble operator ++(ObscuredDouble input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDouble_ObscuredDouble_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDouble(intPtr);
		}

		// Token: 0x060000FF RID: 255 RVA: 0x00006A78 File Offset: 0x00004C78
		[CallerCount(0)]
		public unsafe static ObscuredDouble operator --(ObscuredDouble input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(input));
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDouble_ObscuredDouble_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDouble(intPtr);
		}

		// Token: 0x06000100 RID: 256 RVA: 0x00006AD0 File Offset: 0x00004CD0
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000101 RID: 257 RVA: 0x00006B1C File Offset: 0x00004D1C
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_ToString_Public_String_String_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00006B7C File Offset: 0x00004D7C
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00006BDC File Offset: 0x00004DDC
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000104 RID: 260 RVA: 0x00006C54 File Offset: 0x00004E54
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000105 RID: 261 RVA: 0x00006CBC File Offset: 0x00004EBC
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredDouble obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(obj));
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDouble_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00006D28 File Offset: 0x00004F28
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredDouble.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, IL2CPP.il2cpp_object_unbox(IL2CPP.Il2CppObjectBaseToPtrNotNull(this)), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000107 RID: 263 RVA: 0x00006D78 File Offset: 0x00004F78
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredDouble()
		{
			Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredDouble");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr);
			ObscuredDouble.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "cryptoKey");
			ObscuredDouble.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "currentCryptoKey");
			ObscuredDouble.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "hiddenValue");
			ObscuredDouble.NativeFieldInfoPtr_hiddenValueOld = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "hiddenValueOld");
			ObscuredDouble.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "fakeValue");
			ObscuredDouble.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "inited");
			ObscuredDouble.NativeMethodInfoPtr__ctor_Private_Void_ACTkByte8_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663434);
			ObscuredDouble.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663435);
			ObscuredDouble.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663436);
			ObscuredDouble.NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663437);
			ObscuredDouble.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663438);
			ObscuredDouble.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663439);
			ObscuredDouble.NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663440);
			ObscuredDouble.NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663441);
			ObscuredDouble.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663442);
			ObscuredDouble.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663443);
			ObscuredDouble.NativeMethodInfoPtr_GetEncrypted_Public_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663444);
			ObscuredDouble.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663445);
			ObscuredDouble.NativeMethodInfoPtr_GetDecrypted_Public_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663446);
			ObscuredDouble.NativeMethodInfoPtr_InternalDecrypt_Private_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663447);
			ObscuredDouble.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663448);
			ObscuredDouble.NativeMethodInfoPtr_op_Implicit_Public_Static_Double_ObscuredDouble_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663449);
			ObscuredDouble.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDouble_ObscuredDouble_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663450);
			ObscuredDouble.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDouble_ObscuredDouble_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663451);
			ObscuredDouble.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663452);
			ObscuredDouble.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663453);
			ObscuredDouble.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663454);
			ObscuredDouble.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663455);
			ObscuredDouble.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663456);
			ObscuredDouble.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDouble_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663457);
			ObscuredDouble.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, 100663458);
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00006234 File Offset: 0x00004434
		public ObscuredDouble(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x06000109 RID: 265 RVA: 0x00007014 File Offset: 0x00005214
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr));
			}
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00007028 File Offset: 0x00005228
		public unsafe ObscuredDouble()
		{
			IntPtr data = stackalloc byte[(UIntPtr)IL2CPP.il2cpp_class_value_size(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, (UIntPtr)0)];
			base..ctor(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, data));
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600010B RID: 267 RVA: 0x00007058 File Offset: 0x00005258
		// (set) Token: 0x0600010C RID: 268 RVA: 0x00007076 File Offset: 0x00005276
		public unsafe static long cryptoKey
		{
			get
			{
				long result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredDouble.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredDouble.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600010D RID: 269 RVA: 0x00007088 File Offset: 0x00005288
		// (set) Token: 0x0600010E RID: 270 RVA: 0x000070B0 File Offset: 0x000052B0
		public unsafe long currentCryptoKey
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_currentCryptoKey);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_currentCryptoKey)) = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x0600010F RID: 271 RVA: 0x000070D4 File Offset: 0x000052D4
		// (set) Token: 0x06000110 RID: 272 RVA: 0x000070FC File Offset: 0x000052FC
		public unsafe ACTkByte8 hiddenValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_hiddenValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_hiddenValue)) = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000111 RID: 273 RVA: 0x00007120 File Offset: 0x00005320
		// (set) Token: 0x06000112 RID: 274 RVA: 0x00007154 File Offset: 0x00005354
		public unsafe Il2CppStructArray<byte> hiddenValueOld
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_hiddenValueOld);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_hiddenValueOld), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000113 RID: 275 RVA: 0x0000717C File Offset: 0x0000537C
		// (set) Token: 0x06000114 RID: 276 RVA: 0x000071A4 File Offset: 0x000053A4
		public unsafe double fakeValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_fakeValue);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_fakeValue)) = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000115 RID: 277 RVA: 0x000071C8 File Offset: 0x000053C8
		// (set) Token: 0x06000116 RID: 278 RVA: 0x000071F0 File Offset: 0x000053F0
		public unsafe bool inited
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_inited);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredDouble.NativeFieldInfoPtr_inited)) = value;
			}
		}

		// Token: 0x040000D1 RID: 209
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040000D2 RID: 210
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040000D3 RID: 211
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040000D4 RID: 212
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValueOld;

		// Token: 0x040000D5 RID: 213
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040000D6 RID: 214
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040000D7 RID: 215
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_ACTkByte8_0;

		// Token: 0x040000D8 RID: 216
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int64_0;

		// Token: 0x040000D9 RID: 217
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_0;

		// Token: 0x040000DA RID: 218
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int64_Double_Int64_0;

		// Token: 0x040000DB RID: 219
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_0;

		// Token: 0x040000DC RID: 220
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ACTkByte8_Double_Int64_0;

		// Token: 0x040000DD RID: 221
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_0;

		// Token: 0x040000DE RID: 222
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Double_Int64_Int64_0;

		// Token: 0x040000DF RID: 223
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x040000E0 RID: 224
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x040000E1 RID: 225
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int64_0;

		// Token: 0x040000E2 RID: 226
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int64_0;

		// Token: 0x040000E3 RID: 227
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Double_0;

		// Token: 0x040000E4 RID: 228
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Double_0;

		// Token: 0x040000E5 RID: 229
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_Double_0;

		// Token: 0x040000E6 RID: 230
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Double_ObscuredDouble_0;

		// Token: 0x040000E7 RID: 231
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredDouble_ObscuredDouble_0;

		// Token: 0x040000E8 RID: 232
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredDouble_ObscuredDouble_0;

		// Token: 0x040000E9 RID: 233
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040000EA RID: 234
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040000EB RID: 235
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x040000EC RID: 236
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x040000ED RID: 237
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040000EE RID: 238
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredDouble_0;

		// Token: 0x040000EF RID: 239
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x02000013 RID: 19
		[StructLayout(2)]
		public struct DoubleLongBytesUnion
		{
			// Token: 0x06000117 RID: 279 RVA: 0x00007214 File Offset: 0x00005414
			// Note: this type is marked as 'beforefieldinit'.
			static DoubleLongBytesUnion()
			{
				Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredDouble>.NativeClassPtr, "DoubleLongBytesUnion");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr);
				ObscuredDouble.DoubleLongBytesUnion.NativeFieldInfoPtr_d = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr, "d");
				ObscuredDouble.DoubleLongBytesUnion.NativeFieldInfoPtr_l = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr, "l");
				ObscuredDouble.DoubleLongBytesUnion.NativeFieldInfoPtr_b8 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr, "b8");
			}

			// Token: 0x06000118 RID: 280 RVA: 0x0000727B File Offset: 0x0000547B
			public Object BoxIl2CppObject()
			{
				return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr, ref this));
			}

			// Token: 0x1700003E RID: 62
			// (get) Token: 0x06000119 RID: 281 RVA: 0x0000728D File Offset: 0x0000548D
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredDouble.DoubleLongBytesUnion>.NativeClassPtr));
				}
			}

			// Token: 0x040000F0 RID: 240
			private static readonly IntPtr NativeFieldInfoPtr_d;

			// Token: 0x040000F1 RID: 241
			private static readonly IntPtr NativeFieldInfoPtr_l;

			// Token: 0x040000F2 RID: 242
			private static readonly IntPtr NativeFieldInfoPtr_b8;

			// Token: 0x040000F3 RID: 243
			[FieldOffset(0)]
			public double d;

			// Token: 0x040000F4 RID: 244
			[FieldOffset(0)]
			public long l;

			// Token: 0x040000F5 RID: 245
			[FieldOffset(0)]
			public ACTkByte8 b8;
		}
	}
}
