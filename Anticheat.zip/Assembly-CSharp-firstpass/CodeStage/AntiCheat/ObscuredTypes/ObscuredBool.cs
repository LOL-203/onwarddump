﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200000D RID: 13
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredBool
	{
		// Token: 0x06000078 RID: 120 RVA: 0x00003DF4 File Offset: 0x00001FF4
		[CallerCount(0)]
		public unsafe ObscuredBool(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr__ctor_Private_Void_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00003E3C File Offset: 0x0000203C
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(byte newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00003E84 File Offset: 0x00002084
		[CallerCount(0)]
		public unsafe static int Encrypt(bool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00003ED8 File Offset: 0x000020D8
		[CallerCount(0)]
		public unsafe static int Encrypt(bool value, byte key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00003F40 File Offset: 0x00002140
		[CallerCount(0)]
		public unsafe static bool Decrypt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00003F94 File Offset: 0x00002194
		[CallerCount(0)]
		public unsafe static bool Decrypt(int value, byte key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00003FFC File Offset: 0x000021FC
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004030 File Offset: 0x00002230
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00004064 File Offset: 0x00002264
		[CallerCount(0)]
		public unsafe int GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000040A8 File Offset: 0x000022A8
		[CallerCount(0)]
		public unsafe void SetEncrypted(int encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000082 RID: 130 RVA: 0x000040F0 File Offset: 0x000022F0
		[CallerCount(0)]
		public unsafe bool GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_GetDecrypted_Public_Boolean_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00004134 File Offset: 0x00002334
		[CallerCount(0)]
		public unsafe bool InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_InternalDecrypt_Private_Boolean_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00004178 File Offset: 0x00002378
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredBool(bool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredBool_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000085 RID: 133 RVA: 0x000041CC File Offset: 0x000023CC
		[CallerCount(0)]
		public unsafe static implicit operator bool(ObscuredBool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_op_Implicit_Public_Static_Boolean_ObscuredBool_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00004220 File Offset: 0x00002420
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00004278 File Offset: 0x00002478
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredBool obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredBool_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x000042CC File Offset: 0x000024CC
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00004310 File Offset: 0x00002510
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredBool.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x0000434C File Offset: 0x0000254C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredBool()
		{
			Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredBool");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr);
			ObscuredBool.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "cryptoKey");
			ObscuredBool.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "currentCryptoKey");
			ObscuredBool.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "hiddenValue");
			ObscuredBool.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "fakeValue");
			ObscuredBool.NativeFieldInfoPtr_fakeValueChanged = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "fakeValueChanged");
			ObscuredBool.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, "inited");
			ObscuredBool.NativeMethodInfoPtr__ctor_Private_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663346);
			ObscuredBool.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663347);
			ObscuredBool.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663348);
			ObscuredBool.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663349);
			ObscuredBool.NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663350);
			ObscuredBool.NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663351);
			ObscuredBool.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663352);
			ObscuredBool.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663353);
			ObscuredBool.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663354);
			ObscuredBool.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663355);
			ObscuredBool.NativeMethodInfoPtr_GetDecrypted_Public_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663356);
			ObscuredBool.NativeMethodInfoPtr_InternalDecrypt_Private_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663357);
			ObscuredBool.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredBool_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663358);
			ObscuredBool.NativeMethodInfoPtr_op_Implicit_Public_Static_Boolean_ObscuredBool_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663359);
			ObscuredBool.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663360);
			ObscuredBool.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredBool_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663361);
			ObscuredBool.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663362);
			ObscuredBool.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, 100663363);
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0000455C File Offset: 0x0000275C
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr, ref this));
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x0600008C RID: 140 RVA: 0x0000456E File Offset: 0x0000276E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredBool>.NativeClassPtr));
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600008D RID: 141 RVA: 0x00004580 File Offset: 0x00002780
		// (set) Token: 0x0600008E RID: 142 RVA: 0x0000459E File Offset: 0x0000279E
		public unsafe static byte cryptoKey
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredBool.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredBool.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x04000052 RID: 82
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x04000053 RID: 83
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000054 RID: 84
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000055 RID: 85
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000056 RID: 86
		private static readonly IntPtr NativeFieldInfoPtr_fakeValueChanged;

		// Token: 0x04000057 RID: 87
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000058 RID: 88
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Int32_0;

		// Token: 0x04000059 RID: 89
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Byte_0;

		// Token: 0x0400005A RID: 90
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_0;

		// Token: 0x0400005B RID: 91
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Boolean_Byte_0;

		// Token: 0x0400005C RID: 92
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_0;

		// Token: 0x0400005D RID: 93
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Boolean_Int32_Byte_0;

		// Token: 0x0400005E RID: 94
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400005F RID: 95
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x04000060 RID: 96
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int32_0;

		// Token: 0x04000061 RID: 97
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0;

		// Token: 0x04000062 RID: 98
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Boolean_0;

		// Token: 0x04000063 RID: 99
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Boolean_0;

		// Token: 0x04000064 RID: 100
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredBool_Boolean_0;

		// Token: 0x04000065 RID: 101
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Boolean_ObscuredBool_0;

		// Token: 0x04000066 RID: 102
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000067 RID: 103
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredBool_0;

		// Token: 0x04000068 RID: 104
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000069 RID: 105
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x0400006A RID: 106
		[FieldOffset(0)]
		public byte currentCryptoKey;

		// Token: 0x0400006B RID: 107
		[FieldOffset(4)]
		public int hiddenValue;

		// Token: 0x0400006C RID: 108
		[FieldOffset(8)]
		public bool fakeValue;

		// Token: 0x0400006D RID: 109
		[FieldOffset(9)]
		public bool fakeValueChanged;

		// Token: 0x0400006E RID: 110
		[FieldOffset(10)]
		public bool inited;
	}
}
