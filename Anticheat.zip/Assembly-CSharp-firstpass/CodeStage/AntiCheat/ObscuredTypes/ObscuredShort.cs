﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200001F RID: 31
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredShort
	{
		// Token: 0x0600024B RID: 587 RVA: 0x0000DE04 File Offset: 0x0000C004
		[CallerCount(0)]
		public unsafe ObscuredShort(short value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr__ctor_Private_Void_Int16_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600024C RID: 588 RVA: 0x0000DE4C File Offset: 0x0000C04C
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(short newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600024D RID: 589 RVA: 0x0000DE94 File Offset: 0x0000C094
		[CallerCount(0)]
		public unsafe static short EncryptDecrypt(short value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600024E RID: 590 RVA: 0x0000DEE8 File Offset: 0x0000C0E8
		[CallerCount(0)]
		public unsafe static short EncryptDecrypt(short value, short key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_Int16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600024F RID: 591 RVA: 0x0000DF50 File Offset: 0x0000C150
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000250 RID: 592 RVA: 0x0000DF84 File Offset: 0x0000C184
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000251 RID: 593 RVA: 0x0000DFB8 File Offset: 0x0000C1B8
		[CallerCount(0)]
		public unsafe short GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_GetEncrypted_Public_Int16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000252 RID: 594 RVA: 0x0000DFFC File Offset: 0x0000C1FC
		[CallerCount(0)]
		public unsafe void SetEncrypted(short encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int16_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000253 RID: 595 RVA: 0x0000E044 File Offset: 0x0000C244
		[CallerCount(0)]
		public unsafe short GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_GetDecrypted_Public_Int16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000254 RID: 596 RVA: 0x0000E088 File Offset: 0x0000C288
		[CallerCount(0)]
		public unsafe short InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_InternalDecrypt_Private_Int16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000255 RID: 597 RVA: 0x0000E0CC File Offset: 0x0000C2CC
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredShort(short value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredShort_Int16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0000E120 File Offset: 0x0000C320
		[CallerCount(0)]
		public unsafe static implicit operator short(ObscuredShort value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_op_Implicit_Public_Static_Int16_ObscuredShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0000E174 File Offset: 0x0000C374
		[CallerCount(0)]
		public unsafe static ObscuredShort operator ++(ObscuredShort input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredShort_ObscuredShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0000E1C8 File Offset: 0x0000C3C8
		[CallerCount(0)]
		public unsafe static ObscuredShort operator --(ObscuredShort input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredShort_ObscuredShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000E21C File Offset: 0x0000C41C
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000E274 File Offset: 0x0000C474
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredShort obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredShort_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0000E2C8 File Offset: 0x0000C4C8
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600025C RID: 604 RVA: 0x0000E304 File Offset: 0x0000C504
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600025D RID: 605 RVA: 0x0000E358 File Offset: 0x0000C558
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600025E RID: 606 RVA: 0x0000E39C File Offset: 0x0000C59C
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0000E3F0 File Offset: 0x0000C5F0
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredShort.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0000E45C File Offset: 0x0000C65C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredShort()
		{
			Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredShort");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr);
			ObscuredShort.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, "cryptoKey");
			ObscuredShort.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, "currentCryptoKey");
			ObscuredShort.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, "hiddenValue");
			ObscuredShort.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, "fakeValue");
			ObscuredShort.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, "inited");
			ObscuredShort.NativeMethodInfoPtr__ctor_Private_Void_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663687);
			ObscuredShort.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663688);
			ObscuredShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663689);
			ObscuredShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663690);
			ObscuredShort.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663691);
			ObscuredShort.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663692);
			ObscuredShort.NativeMethodInfoPtr_GetEncrypted_Public_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663693);
			ObscuredShort.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663694);
			ObscuredShort.NativeMethodInfoPtr_GetDecrypted_Public_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663695);
			ObscuredShort.NativeMethodInfoPtr_InternalDecrypt_Private_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663696);
			ObscuredShort.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredShort_Int16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663697);
			ObscuredShort.NativeMethodInfoPtr_op_Implicit_Public_Static_Int16_ObscuredShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663698);
			ObscuredShort.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredShort_ObscuredShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663699);
			ObscuredShort.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredShort_ObscuredShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663700);
			ObscuredShort.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663701);
			ObscuredShort.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663702);
			ObscuredShort.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663703);
			ObscuredShort.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663704);
			ObscuredShort.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663705);
			ObscuredShort.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663706);
			ObscuredShort.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, 100663707);
		}

		// Token: 0x06000261 RID: 609 RVA: 0x0000E694 File Offset: 0x0000C894
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr, ref this));
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000262 RID: 610 RVA: 0x0000E6A6 File Offset: 0x0000C8A6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredShort>.NativeClassPtr));
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000263 RID: 611 RVA: 0x0000E6B8 File Offset: 0x0000C8B8
		// (set) Token: 0x06000264 RID: 612 RVA: 0x0000E6D6 File Offset: 0x0000C8D6
		public unsafe static short cryptoKey
		{
			get
			{
				short result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredShort.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredShort.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x04000230 RID: 560
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x04000231 RID: 561
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000232 RID: 562
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000233 RID: 563
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000234 RID: 564
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000235 RID: 565
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Int16_0;

		// Token: 0x04000236 RID: 566
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int16_0;

		// Token: 0x04000237 RID: 567
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_0;

		// Token: 0x04000238 RID: 568
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_Int16_Int16_Int16_0;

		// Token: 0x04000239 RID: 569
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400023A RID: 570
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400023B RID: 571
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int16_0;

		// Token: 0x0400023C RID: 572
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int16_0;

		// Token: 0x0400023D RID: 573
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Int16_0;

		// Token: 0x0400023E RID: 574
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Int16_0;

		// Token: 0x0400023F RID: 575
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredShort_Int16_0;

		// Token: 0x04000240 RID: 576
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Int16_ObscuredShort_0;

		// Token: 0x04000241 RID: 577
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredShort_ObscuredShort_0;

		// Token: 0x04000242 RID: 578
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredShort_ObscuredShort_0;

		// Token: 0x04000243 RID: 579
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000244 RID: 580
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredShort_0;

		// Token: 0x04000245 RID: 581
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000246 RID: 582
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000247 RID: 583
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000248 RID: 584
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000249 RID: 585
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x0400024A RID: 586
		[FieldOffset(0)]
		public short currentCryptoKey;

		// Token: 0x0400024B RID: 587
		[FieldOffset(2)]
		public short hiddenValue;

		// Token: 0x0400024C RID: 588
		[FieldOffset(4)]
		public short fakeValue;

		// Token: 0x0400024D RID: 589
		[FieldOffset(6)]
		public bool inited;
	}
}
