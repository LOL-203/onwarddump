﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200001C RID: 28
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredQuaternion
	{
		// Token: 0x06000213 RID: 531 RVA: 0x0000CB3C File Offset: 0x0000AD3C
		[CallerCount(0)]
		public unsafe ObscuredQuaternion(ObscuredQuaternion.RawEncryptedQuaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedQuaternion_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000214 RID: 532 RVA: 0x0000CB84 File Offset: 0x0000AD84
		[CallerCount(0)]
		public unsafe ObscuredQuaternion(float x, float y, float z, float w)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref z;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref w;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000CC04 File Offset: 0x0000AE04
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(int newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0000CC4C File Offset: 0x0000AE4C
		[CallerCount(0)]
		public unsafe static ObscuredQuaternion.RawEncryptedQuaternion Encrypt(Quaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000217 RID: 535 RVA: 0x0000CCA0 File Offset: 0x0000AEA0
		[CallerCount(0)]
		public unsafe static ObscuredQuaternion.RawEncryptedQuaternion Encrypt(Quaternion value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000218 RID: 536 RVA: 0x0000CD08 File Offset: 0x0000AF08
		[CallerCount(0)]
		public unsafe static ObscuredQuaternion.RawEncryptedQuaternion Encrypt(float x, float y, float z, float w, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)5) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref z;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref w;
			ptr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Single_Single_Single_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0000CDA8 File Offset: 0x0000AFA8
		[CallerCount(0)]
		public unsafe static Quaternion Decrypt(ObscuredQuaternion.RawEncryptedQuaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600021A RID: 538 RVA: 0x0000CDFC File Offset: 0x0000AFFC
		[CallerCount(0)]
		public unsafe static Quaternion Decrypt(ObscuredQuaternion.RawEncryptedQuaternion value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000CE64 File Offset: 0x0000B064
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000CE98 File Offset: 0x0000B098
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600021D RID: 541 RVA: 0x0000CECC File Offset: 0x0000B0CC
		[CallerCount(0)]
		public unsafe ObscuredQuaternion.RawEncryptedQuaternion GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedQuaternion_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0000CF10 File Offset: 0x0000B110
		[CallerCount(0)]
		public unsafe void SetEncrypted(ObscuredQuaternion.RawEncryptedQuaternion encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedQuaternion_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0000CF58 File Offset: 0x0000B158
		[CallerCount(0)]
		public unsafe Quaternion GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_GetDecrypted_Public_Quaternion_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000CF9C File Offset: 0x0000B19C
		[CallerCount(0)]
		public unsafe Quaternion InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_InternalDecrypt_Private_Quaternion_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000CFE0 File Offset: 0x0000B1E0
		[CallerCount(0)]
		public unsafe bool CompareQuaternionsWithTolerance(Quaternion q1, Quaternion q2)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref q1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref q2;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_CompareQuaternionsWithTolerance_Private_Boolean_Quaternion_Quaternion_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000D048 File Offset: 0x0000B248
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredQuaternion(Quaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredQuaternion_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000D09C File Offset: 0x0000B29C
		[CallerCount(0)]
		public unsafe static implicit operator Quaternion(ObscuredQuaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_op_Implicit_Public_Static_Quaternion_ObscuredQuaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000D0F0 File Offset: 0x0000B2F0
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000D134 File Offset: 0x0000B334
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000D170 File Offset: 0x0000B370
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredQuaternion.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000D1C4 File Offset: 0x0000B3C4
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredQuaternion()
		{
			Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredQuaternion");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr);
			ObscuredQuaternion.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "cryptoKey");
			ObscuredQuaternion.NativeFieldInfoPtr_initialFakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "initialFakeValue");
			ObscuredQuaternion.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "currentCryptoKey");
			ObscuredQuaternion.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "hiddenValue");
			ObscuredQuaternion.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "fakeValue");
			ObscuredQuaternion.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "inited");
			ObscuredQuaternion.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedQuaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663644);
			ObscuredQuaternion.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663645);
			ObscuredQuaternion.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663646);
			ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663647);
			ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663648);
			ObscuredQuaternion.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Single_Single_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663649);
			ObscuredQuaternion.NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663650);
			ObscuredQuaternion.NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663651);
			ObscuredQuaternion.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663652);
			ObscuredQuaternion.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663653);
			ObscuredQuaternion.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedQuaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663654);
			ObscuredQuaternion.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedQuaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663655);
			ObscuredQuaternion.NativeMethodInfoPtr_GetDecrypted_Public_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663656);
			ObscuredQuaternion.NativeMethodInfoPtr_InternalDecrypt_Private_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663657);
			ObscuredQuaternion.NativeMethodInfoPtr_CompareQuaternionsWithTolerance_Private_Boolean_Quaternion_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663658);
			ObscuredQuaternion.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredQuaternion_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663659);
			ObscuredQuaternion.NativeMethodInfoPtr_op_Implicit_Public_Static_Quaternion_ObscuredQuaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663660);
			ObscuredQuaternion.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663661);
			ObscuredQuaternion.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663662);
			ObscuredQuaternion.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, 100663663);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000D3FC File Offset: 0x0000B5FC
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, ref this));
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000229 RID: 553 RVA: 0x0000D40E File Offset: 0x0000B60E
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr));
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600022A RID: 554 RVA: 0x0000D420 File Offset: 0x0000B620
		// (set) Token: 0x0600022B RID: 555 RVA: 0x0000D43E File Offset: 0x0000B63E
		public unsafe static int cryptoKey
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredQuaternion.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredQuaternion.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600022C RID: 556 RVA: 0x0000D450 File Offset: 0x0000B650
		// (set) Token: 0x0600022D RID: 557 RVA: 0x0000D46E File Offset: 0x0000B66E
		public unsafe static Quaternion initialFakeValue
		{
			get
			{
				Quaternion result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredQuaternion.NativeFieldInfoPtr_initialFakeValue, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredQuaternion.NativeFieldInfoPtr_initialFakeValue, (void*)(&value));
			}
		}

		// Token: 0x040001EC RID: 492
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040001ED RID: 493
		private static readonly IntPtr NativeFieldInfoPtr_initialFakeValue;

		// Token: 0x040001EE RID: 494
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040001EF RID: 495
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040001F0 RID: 496
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040001F1 RID: 497
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040001F2 RID: 498
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedQuaternion_0;

		// Token: 0x040001F3 RID: 499
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_Single_0;

		// Token: 0x040001F4 RID: 500
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0;

		// Token: 0x040001F5 RID: 501
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_0;

		// Token: 0x040001F6 RID: 502
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Quaternion_Int32_0;

		// Token: 0x040001F7 RID: 503
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedQuaternion_Single_Single_Single_Single_Int32_0;

		// Token: 0x040001F8 RID: 504
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_0;

		// Token: 0x040001F9 RID: 505
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Quaternion_RawEncryptedQuaternion_Int32_0;

		// Token: 0x040001FA RID: 506
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x040001FB RID: 507
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x040001FC RID: 508
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedQuaternion_0;

		// Token: 0x040001FD RID: 509
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedQuaternion_0;

		// Token: 0x040001FE RID: 510
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Quaternion_0;

		// Token: 0x040001FF RID: 511
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Quaternion_0;

		// Token: 0x04000200 RID: 512
		private static readonly IntPtr NativeMethodInfoPtr_CompareQuaternionsWithTolerance_Private_Boolean_Quaternion_Quaternion_0;

		// Token: 0x04000201 RID: 513
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredQuaternion_Quaternion_0;

		// Token: 0x04000202 RID: 514
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Quaternion_ObscuredQuaternion_0;

		// Token: 0x04000203 RID: 515
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000204 RID: 516
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000205 RID: 517
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000206 RID: 518
		[FieldOffset(0)]
		public int currentCryptoKey;

		// Token: 0x04000207 RID: 519
		[FieldOffset(4)]
		public ObscuredQuaternion.RawEncryptedQuaternion hiddenValue;

		// Token: 0x04000208 RID: 520
		[FieldOffset(20)]
		public Quaternion fakeValue;

		// Token: 0x04000209 RID: 521
		[FieldOffset(36)]
		public bool inited;

		// Token: 0x0200001D RID: 29
		[Serializable]
		[StructLayout(2)]
		public struct RawEncryptedQuaternion
		{
			// Token: 0x0600022E RID: 558 RVA: 0x0000D480 File Offset: 0x0000B680
			// Note: this type is marked as 'beforefieldinit'.
			static RawEncryptedQuaternion()
			{
				Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredQuaternion>.NativeClassPtr, "RawEncryptedQuaternion");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr);
				ObscuredQuaternion.RawEncryptedQuaternion.NativeFieldInfoPtr_x = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr, "x");
				ObscuredQuaternion.RawEncryptedQuaternion.NativeFieldInfoPtr_y = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr, "y");
				ObscuredQuaternion.RawEncryptedQuaternion.NativeFieldInfoPtr_z = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr, "z");
				ObscuredQuaternion.RawEncryptedQuaternion.NativeFieldInfoPtr_w = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr, "w");
			}

			// Token: 0x0600022F RID: 559 RVA: 0x0000D4FB File Offset: 0x0000B6FB
			public Il2CppSystem.Object BoxIl2CppObject()
			{
				return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr, ref this));
			}

			// Token: 0x17000066 RID: 102
			// (get) Token: 0x06000230 RID: 560 RVA: 0x0000D50D File Offset: 0x0000B70D
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredQuaternion.RawEncryptedQuaternion>.NativeClassPtr));
				}
			}

			// Token: 0x0400020A RID: 522
			private static readonly IntPtr NativeFieldInfoPtr_x;

			// Token: 0x0400020B RID: 523
			private static readonly IntPtr NativeFieldInfoPtr_y;

			// Token: 0x0400020C RID: 524
			private static readonly IntPtr NativeFieldInfoPtr_z;

			// Token: 0x0400020D RID: 525
			private static readonly IntPtr NativeFieldInfoPtr_w;

			// Token: 0x0400020E RID: 526
			[FieldOffset(0)]
			public int x;

			// Token: 0x0400020F RID: 527
			[FieldOffset(4)]
			public int y;

			// Token: 0x04000210 RID: 528
			[FieldOffset(8)]
			public int z;

			// Token: 0x04000211 RID: 529
			[FieldOffset(12)]
			public int w;
		}
	}
}
