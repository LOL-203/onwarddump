﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000023 RID: 35
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredUShort
	{
		// Token: 0x060002C5 RID: 709 RVA: 0x0001085C File Offset: 0x0000EA5C
		[CallerCount(0)]
		public unsafe ObscuredUShort(ushort value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr__ctor_Private_Void_UInt16_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x000108A4 File Offset: 0x0000EAA4
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(ushort newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x000108EC File Offset: 0x0000EAEC
		[CallerCount(0)]
		public unsafe static ushort EncryptDecrypt(ushort value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x00010940 File Offset: 0x0000EB40
		[CallerCount(0)]
		public unsafe static ushort EncryptDecrypt(ushort value, ushort key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_UInt16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x000109A8 File Offset: 0x0000EBA8
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002CA RID: 714 RVA: 0x000109DC File Offset: 0x0000EBDC
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00010A10 File Offset: 0x0000EC10
		[CallerCount(0)]
		public unsafe ushort GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_GetEncrypted_Public_UInt16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00010A54 File Offset: 0x0000EC54
		[CallerCount(0)]
		public unsafe void SetEncrypted(ushort encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt16_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00010A9C File Offset: 0x0000EC9C
		[CallerCount(0)]
		public unsafe ushort GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_GetDecrypted_Public_UInt16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00010AE0 File Offset: 0x0000ECE0
		[CallerCount(0)]
		public unsafe ushort InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_InternalDecrypt_Private_UInt16_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00010B24 File Offset: 0x0000ED24
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredUShort(ushort value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUShort_UInt16_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x00010B78 File Offset: 0x0000ED78
		[CallerCount(0)]
		public unsafe static implicit operator ushort(ObscuredUShort value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt16_ObscuredUShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00010BCC File Offset: 0x0000EDCC
		[CallerCount(0)]
		public unsafe static ObscuredUShort operator ++(ObscuredUShort input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUShort_ObscuredUShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00010C20 File Offset: 0x0000EE20
		[CallerCount(0)]
		public unsafe static ObscuredUShort operator --(ObscuredUShort input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUShort_ObscuredUShort_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00010C74 File Offset: 0x0000EE74
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00010CCC File Offset: 0x0000EECC
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredUShort obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUShort_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00010D20 File Offset: 0x0000EF20
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00010D5C File Offset: 0x0000EF5C
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x00010DB0 File Offset: 0x0000EFB0
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00010DF4 File Offset: 0x0000EFF4
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x00010E48 File Offset: 0x0000F048
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredUShort.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002DA RID: 730 RVA: 0x00010EB4 File Offset: 0x0000F0B4
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredUShort()
		{
			Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredUShort");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr);
			ObscuredUShort.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, "cryptoKey");
			ObscuredUShort.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, "currentCryptoKey");
			ObscuredUShort.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, "hiddenValue");
			ObscuredUShort.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, "fakeValue");
			ObscuredUShort.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, "inited");
			ObscuredUShort.NativeMethodInfoPtr__ctor_Private_Void_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663785);
			ObscuredUShort.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663786);
			ObscuredUShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663787);
			ObscuredUShort.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663788);
			ObscuredUShort.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663789);
			ObscuredUShort.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663790);
			ObscuredUShort.NativeMethodInfoPtr_GetEncrypted_Public_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663791);
			ObscuredUShort.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663792);
			ObscuredUShort.NativeMethodInfoPtr_GetDecrypted_Public_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663793);
			ObscuredUShort.NativeMethodInfoPtr_InternalDecrypt_Private_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663794);
			ObscuredUShort.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUShort_UInt16_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663795);
			ObscuredUShort.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt16_ObscuredUShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663796);
			ObscuredUShort.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUShort_ObscuredUShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663797);
			ObscuredUShort.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUShort_ObscuredUShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663798);
			ObscuredUShort.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663799);
			ObscuredUShort.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUShort_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663800);
			ObscuredUShort.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663801);
			ObscuredUShort.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663802);
			ObscuredUShort.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663803);
			ObscuredUShort.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663804);
			ObscuredUShort.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, 100663805);
		}

		// Token: 0x060002DB RID: 731 RVA: 0x000110EC File Offset: 0x0000F2EC
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr, ref this));
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060002DC RID: 732 RVA: 0x000110FE File Offset: 0x0000F2FE
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredUShort>.NativeClassPtr));
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060002DD RID: 733 RVA: 0x00011110 File Offset: 0x0000F310
		// (set) Token: 0x060002DE RID: 734 RVA: 0x0001112E File Offset: 0x0000F32E
		public unsafe static ushort cryptoKey
		{
			get
			{
				ushort result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredUShort.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredUShort.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x040002AE RID: 686
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040002AF RID: 687
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040002B0 RID: 688
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040002B1 RID: 689
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040002B2 RID: 690
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040002B3 RID: 691
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_UInt16_0;

		// Token: 0x040002B4 RID: 692
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt16_0;

		// Token: 0x040002B5 RID: 693
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_0;

		// Token: 0x040002B6 RID: 694
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_UInt16_UInt16_UInt16_0;

		// Token: 0x040002B7 RID: 695
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x040002B8 RID: 696
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x040002B9 RID: 697
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_UInt16_0;

		// Token: 0x040002BA RID: 698
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt16_0;

		// Token: 0x040002BB RID: 699
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_UInt16_0;

		// Token: 0x040002BC RID: 700
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_UInt16_0;

		// Token: 0x040002BD RID: 701
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredUShort_UInt16_0;

		// Token: 0x040002BE RID: 702
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_UInt16_ObscuredUShort_0;

		// Token: 0x040002BF RID: 703
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredUShort_ObscuredUShort_0;

		// Token: 0x040002C0 RID: 704
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredUShort_ObscuredUShort_0;

		// Token: 0x040002C1 RID: 705
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040002C2 RID: 706
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredUShort_0;

		// Token: 0x040002C3 RID: 707
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040002C4 RID: 708
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040002C5 RID: 709
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040002C6 RID: 710
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x040002C7 RID: 711
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x040002C8 RID: 712
		[FieldOffset(0)]
		public ushort currentCryptoKey;

		// Token: 0x040002C9 RID: 713
		[FieldOffset(2)]
		public ushort hiddenValue;

		// Token: 0x040002CA RID: 714
		[FieldOffset(4)]
		public ushort fakeValue;

		// Token: 0x040002CB RID: 715
		[FieldOffset(6)]
		public bool inited;
	}
}
