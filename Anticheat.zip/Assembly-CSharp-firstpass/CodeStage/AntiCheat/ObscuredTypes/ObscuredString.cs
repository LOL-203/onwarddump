﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000020 RID: 32
	[Serializable]
	public sealed class ObscuredString : Object
	{
		// Token: 0x06000265 RID: 613 RVA: 0x0000E6E8 File Offset: 0x0000C8E8
		[CallerCount(0)]
		public unsafe ObscuredString() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr__ctor_Private_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000266 RID: 614 RVA: 0x0000E734 File Offset: 0x0000C934
		[CallerCount(0)]
		public unsafe ObscuredString(Il2CppStructArray<byte> value) : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr))
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr__ctor_Private_Void_ArrayOf_Byte_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000267 RID: 615 RVA: 0x0000E798 File Offset: 0x0000C998
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(string newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(newKey);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000268 RID: 616 RVA: 0x0000E7E4 File Offset: 0x0000C9E4
		[CallerCount(0)]
		public unsafe static string EncryptDecrypt(string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0000E838 File Offset: 0x0000CA38
		[CallerCount(0)]
		public unsafe static string EncryptDecrypt(string value, string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0000E8A4 File Offset: 0x0000CAA4
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0000E8E8 File Offset: 0x0000CAE8
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600026C RID: 620 RVA: 0x0000E92C File Offset: 0x0000CB2C
		[CallerCount(0)]
		public unsafe string GetEncrypted()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_GetEncrypted_Public_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600026D RID: 621 RVA: 0x0000E978 File Offset: 0x0000CB78
		[CallerCount(0)]
		public unsafe void SetEncrypted(string encrypted)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(encrypted);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_SetEncrypted_Public_Void_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600026E RID: 622 RVA: 0x0000E9D4 File Offset: 0x0000CBD4
		[CallerCount(0)]
		public unsafe string GetDecrypted()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_GetDecrypted_Public_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600026F RID: 623 RVA: 0x0000EA20 File Offset: 0x0000CC20
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> InternalEncrypt(string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x06000270 RID: 624 RVA: 0x0000EA80 File Offset: 0x0000CC80
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> InternalEncrypt(string value, string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x06000271 RID: 625 RVA: 0x0000EAF8 File Offset: 0x0000CCF8
		[CallerCount(0)]
		public unsafe string InternalDecrypt()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_InternalDecrypt_Private_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000272 RID: 626 RVA: 0x0000EB44 File Offset: 0x0000CD44
		public unsafe int Length
		{
			[CallerCount(0)]
			get
			{
				IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_get_Length_Public_get_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06000273 RID: 627 RVA: 0x0000EB94 File Offset: 0x0000CD94
		[CallerCount(0)]
		public new unsafe static implicit operator ObscuredString(string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredString_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new ObscuredString(intPtr2) : null;
		}

		// Token: 0x06000274 RID: 628 RVA: 0x0000EBF4 File Offset: 0x0000CDF4
		[CallerCount(0)]
		public unsafe static implicit operator string(ObscuredString value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_op_Implicit_Public_Static_String_ObscuredString_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0000EC48 File Offset: 0x0000CE48
		[CallerCount(0)]
		public new unsafe string ToString()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000276 RID: 630 RVA: 0x0000EC94 File Offset: 0x0000CE94
		[CallerCount(0)]
		public unsafe static bool operator ==(ObscuredString a, ObscuredString b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredString_ObscuredString_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000277 RID: 631 RVA: 0x0000ED04 File Offset: 0x0000CF04
		[CallerCount(0)]
		public unsafe static bool operator !=(ObscuredString a, ObscuredString b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(b);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredString_ObscuredString_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000278 RID: 632 RVA: 0x0000ED74 File Offset: 0x0000CF74
		[CallerCount(0)]
		public new unsafe bool Equals(Object obj)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0000EDDC File Offset: 0x0000CFDC
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredString value)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600027A RID: 634 RVA: 0x0000EE44 File Offset: 0x0000D044
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredString value, StringComparison comparisonType)
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(value);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref comparisonType;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_StringComparison_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600027B RID: 635 RVA: 0x0000EEC0 File Offset: 0x0000D0C0
		[CallerCount(0)]
		public new unsafe int GetHashCode()
		{
			IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600027C RID: 636 RVA: 0x0000EF10 File Offset: 0x0000D110
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> GetBytes(string str)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(str);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_GetBytes_Private_Static_ArrayOf_Byte_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000EF70 File Offset: 0x0000D170
		[CallerCount(0)]
		public unsafe static string GetString(Il2CppStructArray<byte> bytes)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bytes);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_GetString_Private_Static_String_ArrayOf_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600027E RID: 638 RVA: 0x0000EFC4 File Offset: 0x0000D1C4
		[CallerCount(0)]
		public unsafe static bool ArraysEquals(Il2CppStructArray<byte> a1, Il2CppStructArray<byte> a2)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(a1);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(a2);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredString.NativeMethodInfoPtr_ArraysEquals_Private_Static_Boolean_ArrayOf_Byte_ArrayOf_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0000F034 File Offset: 0x0000D234
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredString()
		{
			Il2CppClassPointerStore<ObscuredString>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredString");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr);
			ObscuredString.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, "cryptoKey");
			ObscuredString.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, "currentCryptoKey");
			ObscuredString.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, "hiddenValue");
			ObscuredString.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, "fakeValue");
			ObscuredString.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, "inited");
			ObscuredString.NativeMethodInfoPtr__ctor_Private_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663709);
			ObscuredString.NativeMethodInfoPtr__ctor_Private_Void_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663710);
			ObscuredString.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663711);
			ObscuredString.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663712);
			ObscuredString.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663713);
			ObscuredString.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663714);
			ObscuredString.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663715);
			ObscuredString.NativeMethodInfoPtr_GetEncrypted_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663716);
			ObscuredString.NativeMethodInfoPtr_SetEncrypted_Public_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663717);
			ObscuredString.NativeMethodInfoPtr_GetDecrypted_Public_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663718);
			ObscuredString.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663719);
			ObscuredString.NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663720);
			ObscuredString.NativeMethodInfoPtr_InternalDecrypt_Private_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663721);
			ObscuredString.NativeMethodInfoPtr_get_Length_Public_get_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663722);
			ObscuredString.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredString_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663723);
			ObscuredString.NativeMethodInfoPtr_op_Implicit_Public_Static_String_ObscuredString_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663724);
			ObscuredString.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663725);
			ObscuredString.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredString_ObscuredString_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663726);
			ObscuredString.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredString_ObscuredString_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663727);
			ObscuredString.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663728);
			ObscuredString.NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663729);
			ObscuredString.NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_StringComparison_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663730);
			ObscuredString.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663731);
			ObscuredString.NativeMethodInfoPtr_GetBytes_Private_Static_ArrayOf_Byte_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663732);
			ObscuredString.NativeMethodInfoPtr_GetString_Private_Static_String_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663733);
			ObscuredString.NativeMethodInfoPtr_ArraysEquals_Private_Static_Boolean_ArrayOf_Byte_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr, 100663734);
		}

		// Token: 0x06000280 RID: 640 RVA: 0x00002580 File Offset: 0x00000780
		public ObscuredString(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000281 RID: 641 RVA: 0x0000F2D0 File Offset: 0x0000D4D0
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredString>.NativeClassPtr));
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000282 RID: 642 RVA: 0x0000F2E4 File Offset: 0x0000D4E4
		// (set) Token: 0x06000283 RID: 643 RVA: 0x0000F304 File Offset: 0x0000D504
		public unsafe static string cryptoKey
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredString.NativeFieldInfoPtr_cryptoKey, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredString.NativeFieldInfoPtr_cryptoKey, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000284 RID: 644 RVA: 0x0000F31C File Offset: 0x0000D51C
		// (set) Token: 0x06000285 RID: 645 RVA: 0x0000F345 File Offset: 0x0000D545
		public unsafe string currentCryptoKey
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_currentCryptoKey);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_currentCryptoKey), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000286 RID: 646 RVA: 0x0000F36C File Offset: 0x0000D56C
		// (set) Token: 0x06000287 RID: 647 RVA: 0x0000F3A0 File Offset: 0x0000D5A0
		public unsafe Il2CppStructArray<byte> hiddenValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_hiddenValue);
				IntPtr intPtr2 = *intPtr;
				return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_hiddenValue), IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000288 RID: 648 RVA: 0x0000F3C8 File Offset: 0x0000D5C8
		// (set) Token: 0x06000289 RID: 649 RVA: 0x0000F3F1 File Offset: 0x0000D5F1
		public unsafe string fakeValue
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_fakeValue);
				return IL2CPP.Il2CppStringToManaged(*intPtr);
			}
			set
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this);
				IL2CPP.FieldWriteWbarrierStub(intPtr, intPtr + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_fakeValue), IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x0600028A RID: 650 RVA: 0x0000F418 File Offset: 0x0000D618
		// (set) Token: 0x0600028B RID: 651 RVA: 0x0000F440 File Offset: 0x0000D640
		public unsafe bool inited
		{
			get
			{
				IntPtr intPtr = IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_inited);
				return *intPtr;
			}
			set
			{
				*(IL2CPP.Il2CppObjectBaseToPtrNotNull(this) + (IntPtr)IL2CPP.il2cpp_field_get_offset(ObscuredString.NativeFieldInfoPtr_inited)) = value;
			}
		}

		// Token: 0x0400024E RID: 590
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400024F RID: 591
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000250 RID: 592
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000251 RID: 593
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000252 RID: 594
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000253 RID: 595
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_0;

		// Token: 0x04000254 RID: 596
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_ArrayOf_Byte_0;

		// Token: 0x04000255 RID: 597
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_String_0;

		// Token: 0x04000256 RID: 598
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_0;

		// Token: 0x04000257 RID: 599
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_String_String_String_0;

		// Token: 0x04000258 RID: 600
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000259 RID: 601
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400025A RID: 602
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_String_0;

		// Token: 0x0400025B RID: 603
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_String_0;

		// Token: 0x0400025C RID: 604
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_String_0;

		// Token: 0x0400025D RID: 605
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_0;

		// Token: 0x0400025E RID: 606
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncrypt_Private_Static_ArrayOf_Byte_String_String_0;

		// Token: 0x0400025F RID: 607
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_String_0;

		// Token: 0x04000260 RID: 608
		private static readonly IntPtr NativeMethodInfoPtr_get_Length_Public_get_Int32_0;

		// Token: 0x04000261 RID: 609
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredString_String_0;

		// Token: 0x04000262 RID: 610
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_String_ObscuredString_0;

		// Token: 0x04000263 RID: 611
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000264 RID: 612
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredString_ObscuredString_0;

		// Token: 0x04000265 RID: 613
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredString_ObscuredString_0;

		// Token: 0x04000266 RID: 614
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000267 RID: 615
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_0;

		// Token: 0x04000268 RID: 616
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Boolean_ObscuredString_StringComparison_0;

		// Token: 0x04000269 RID: 617
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x0400026A RID: 618
		private static readonly IntPtr NativeMethodInfoPtr_GetBytes_Private_Static_ArrayOf_Byte_String_0;

		// Token: 0x0400026B RID: 619
		private static readonly IntPtr NativeMethodInfoPtr_GetString_Private_Static_String_ArrayOf_Byte_0;

		// Token: 0x0400026C RID: 620
		private static readonly IntPtr NativeMethodInfoPtr_ArraysEquals_Private_Static_Boolean_ArrayOf_Byte_ArrayOf_Byte_0;
	}
}
