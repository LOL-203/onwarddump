﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200001E RID: 30
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredSByte
	{
		// Token: 0x06000231 RID: 561 RVA: 0x0000D520 File Offset: 0x0000B720
		[CallerCount(0)]
		public unsafe ObscuredSByte(sbyte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr__ctor_Private_Void_SByte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0000D568 File Offset: 0x0000B768
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(sbyte newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_SByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000D5B0 File Offset: 0x0000B7B0
		[CallerCount(0)]
		public unsafe static sbyte EncryptDecrypt(sbyte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0000D604 File Offset: 0x0000B804
		[CallerCount(0)]
		public unsafe static sbyte EncryptDecrypt(sbyte value, sbyte key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_SByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000D66C File Offset: 0x0000B86C
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000D6A0 File Offset: 0x0000B8A0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0000D6D4 File Offset: 0x0000B8D4
		[CallerCount(0)]
		public unsafe sbyte GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_GetEncrypted_Public_SByte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000238 RID: 568 RVA: 0x0000D718 File Offset: 0x0000B918
		[CallerCount(0)]
		public unsafe void SetEncrypted(sbyte encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_SetEncrypted_Public_Void_SByte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000D760 File Offset: 0x0000B960
		[CallerCount(0)]
		public unsafe sbyte GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_GetDecrypted_Public_SByte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023A RID: 570 RVA: 0x0000D7A4 File Offset: 0x0000B9A4
		[CallerCount(0)]
		public unsafe sbyte InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_InternalDecrypt_Private_SByte_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023B RID: 571 RVA: 0x0000D7E8 File Offset: 0x0000B9E8
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredSByte(sbyte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredSByte_SByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023C RID: 572 RVA: 0x0000D83C File Offset: 0x0000BA3C
		[CallerCount(0)]
		public unsafe static implicit operator sbyte(ObscuredSByte value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_op_Implicit_Public_Static_SByte_ObscuredSByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023D RID: 573 RVA: 0x0000D890 File Offset: 0x0000BA90
		[CallerCount(0)]
		public unsafe static ObscuredSByte operator ++(ObscuredSByte input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredSByte_ObscuredSByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0000D8E4 File Offset: 0x0000BAE4
		[CallerCount(0)]
		public unsafe static ObscuredSByte operator --(ObscuredSByte input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredSByte_ObscuredSByte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0000D938 File Offset: 0x0000BB38
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000240 RID: 576 RVA: 0x0000D990 File Offset: 0x0000BB90
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredSByte obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredSByte_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x06000241 RID: 577 RVA: 0x0000D9E4 File Offset: 0x0000BBE4
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0000DA20 File Offset: 0x0000BC20
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000243 RID: 579 RVA: 0x0000DA74 File Offset: 0x0000BC74
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000244 RID: 580 RVA: 0x0000DAB8 File Offset: 0x0000BCB8
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000245 RID: 581 RVA: 0x0000DB0C File Offset: 0x0000BD0C
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredSByte.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000246 RID: 582 RVA: 0x0000DB78 File Offset: 0x0000BD78
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredSByte()
		{
			Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredSByte");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr);
			ObscuredSByte.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, "cryptoKey");
			ObscuredSByte.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, "currentCryptoKey");
			ObscuredSByte.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, "hiddenValue");
			ObscuredSByte.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, "fakeValue");
			ObscuredSByte.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, "inited");
			ObscuredSByte.NativeMethodInfoPtr__ctor_Private_Void_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663665);
			ObscuredSByte.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663666);
			ObscuredSByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663667);
			ObscuredSByte.NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663668);
			ObscuredSByte.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663669);
			ObscuredSByte.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663670);
			ObscuredSByte.NativeMethodInfoPtr_GetEncrypted_Public_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663671);
			ObscuredSByte.NativeMethodInfoPtr_SetEncrypted_Public_Void_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663672);
			ObscuredSByte.NativeMethodInfoPtr_GetDecrypted_Public_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663673);
			ObscuredSByte.NativeMethodInfoPtr_InternalDecrypt_Private_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663674);
			ObscuredSByte.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredSByte_SByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663675);
			ObscuredSByte.NativeMethodInfoPtr_op_Implicit_Public_Static_SByte_ObscuredSByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663676);
			ObscuredSByte.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredSByte_ObscuredSByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663677);
			ObscuredSByte.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredSByte_ObscuredSByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663678);
			ObscuredSByte.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663679);
			ObscuredSByte.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredSByte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663680);
			ObscuredSByte.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663681);
			ObscuredSByte.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663682);
			ObscuredSByte.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663683);
			ObscuredSByte.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663684);
			ObscuredSByte.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, 100663685);
		}

		// Token: 0x06000247 RID: 583 RVA: 0x0000DDB0 File Offset: 0x0000BFB0
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr, ref this));
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000248 RID: 584 RVA: 0x0000DDC2 File Offset: 0x0000BFC2
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredSByte>.NativeClassPtr));
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000249 RID: 585 RVA: 0x0000DDD4 File Offset: 0x0000BFD4
		// (set) Token: 0x0600024A RID: 586 RVA: 0x0000DDF2 File Offset: 0x0000BFF2
		public unsafe static sbyte cryptoKey
		{
			get
			{
				sbyte result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredSByte.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredSByte.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x04000212 RID: 530
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x04000213 RID: 531
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000214 RID: 532
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000215 RID: 533
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000216 RID: 534
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000217 RID: 535
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_SByte_0;

		// Token: 0x04000218 RID: 536
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_SByte_0;

		// Token: 0x04000219 RID: 537
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_0;

		// Token: 0x0400021A RID: 538
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecrypt_Public_Static_SByte_SByte_SByte_0;

		// Token: 0x0400021B RID: 539
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400021C RID: 540
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400021D RID: 541
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_SByte_0;

		// Token: 0x0400021E RID: 542
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_SByte_0;

		// Token: 0x0400021F RID: 543
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_SByte_0;

		// Token: 0x04000220 RID: 544
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_SByte_0;

		// Token: 0x04000221 RID: 545
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredSByte_SByte_0;

		// Token: 0x04000222 RID: 546
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_SByte_ObscuredSByte_0;

		// Token: 0x04000223 RID: 547
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredSByte_ObscuredSByte_0;

		// Token: 0x04000224 RID: 548
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredSByte_ObscuredSByte_0;

		// Token: 0x04000225 RID: 549
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000226 RID: 550
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredSByte_0;

		// Token: 0x04000227 RID: 551
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000228 RID: 552
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000229 RID: 553
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x0400022A RID: 554
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x0400022B RID: 555
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x0400022C RID: 556
		[FieldOffset(0)]
		public sbyte currentCryptoKey;

		// Token: 0x0400022D RID: 557
		[FieldOffset(1)]
		public sbyte hiddenValue;

		// Token: 0x0400022E RID: 558
		[FieldOffset(2)]
		public sbyte fakeValue;

		// Token: 0x0400022F RID: 559
		[FieldOffset(3)]
		public bool inited;
	}
}
