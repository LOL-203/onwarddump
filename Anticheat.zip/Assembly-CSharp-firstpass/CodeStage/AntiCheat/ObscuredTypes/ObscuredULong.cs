﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000022 RID: 34
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredULong
	{
		// Token: 0x060002A9 RID: 681 RVA: 0x0000FE94 File Offset: 0x0000E094
		[CallerCount(0)]
		public unsafe ObscuredULong(ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr__ctor_Private_Void_UInt64_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002AA RID: 682 RVA: 0x0000FEDC File Offset: 0x0000E0DC
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(ulong newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0000FF24 File Offset: 0x0000E124
		[CallerCount(0)]
		public unsafe static ulong Encrypt(ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002AC RID: 684 RVA: 0x0000FF78 File Offset: 0x0000E178
		[CallerCount(0)]
		public unsafe static ulong Decrypt(ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002AD RID: 685 RVA: 0x0000FFCC File Offset: 0x0000E1CC
		[CallerCount(0)]
		public unsafe static ulong Encrypt(ulong value, ulong key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002AE RID: 686 RVA: 0x00010034 File Offset: 0x0000E234
		[CallerCount(0)]
		public unsafe static ulong Decrypt(ulong value, ulong key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002AF RID: 687 RVA: 0x0001009C File Offset: 0x0000E29C
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000100D0 File Offset: 0x0000E2D0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00010104 File Offset: 0x0000E304
		[CallerCount(0)]
		public unsafe ulong GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_GetEncrypted_Public_UInt64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00010148 File Offset: 0x0000E348
		[CallerCount(0)]
		public unsafe void SetEncrypted(ulong encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt64_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00010190 File Offset: 0x0000E390
		[CallerCount(0)]
		public unsafe ulong GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_GetDecrypted_Public_UInt64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x000101D4 File Offset: 0x0000E3D4
		[CallerCount(0)]
		public unsafe ulong InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_InternalDecrypt_Private_UInt64_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x00010218 File Offset: 0x0000E418
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredULong(ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredULong_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x0001026C File Offset: 0x0000E46C
		[CallerCount(0)]
		public unsafe static implicit operator ulong(ObscuredULong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt64_ObscuredULong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x000102C0 File Offset: 0x0000E4C0
		[CallerCount(0)]
		public unsafe static ObscuredULong operator ++(ObscuredULong input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredULong_ObscuredULong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00010314 File Offset: 0x0000E514
		[CallerCount(0)]
		public unsafe static ObscuredULong operator --(ObscuredULong input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredULong_ObscuredULong_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00010368 File Offset: 0x0000E568
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060002BA RID: 698 RVA: 0x000103C0 File Offset: 0x0000E5C0
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredULong obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredULong_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00010414 File Offset: 0x0000E614
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00010458 File Offset: 0x0000E658
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00010494 File Offset: 0x0000E694
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002BE RID: 702 RVA: 0x000104E8 File Offset: 0x0000E6E8
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002BF RID: 703 RVA: 0x0001053C File Offset: 0x0000E73C
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredULong.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000105A8 File Offset: 0x0000E7A8
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredULong()
		{
			Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredULong");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr);
			ObscuredULong.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, "cryptoKey");
			ObscuredULong.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, "currentCryptoKey");
			ObscuredULong.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, "hiddenValue");
			ObscuredULong.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, "fakeValue");
			ObscuredULong.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, "inited");
			ObscuredULong.NativeMethodInfoPtr__ctor_Private_Void_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663761);
			ObscuredULong.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663762);
			ObscuredULong.NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663763);
			ObscuredULong.NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663764);
			ObscuredULong.NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663765);
			ObscuredULong.NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663766);
			ObscuredULong.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663767);
			ObscuredULong.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663768);
			ObscuredULong.NativeMethodInfoPtr_GetEncrypted_Public_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663769);
			ObscuredULong.NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663770);
			ObscuredULong.NativeMethodInfoPtr_GetDecrypted_Public_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663771);
			ObscuredULong.NativeMethodInfoPtr_InternalDecrypt_Private_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663772);
			ObscuredULong.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredULong_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663773);
			ObscuredULong.NativeMethodInfoPtr_op_Implicit_Public_Static_UInt64_ObscuredULong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663774);
			ObscuredULong.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredULong_ObscuredULong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663775);
			ObscuredULong.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredULong_ObscuredULong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663776);
			ObscuredULong.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663777);
			ObscuredULong.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredULong_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663778);
			ObscuredULong.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663779);
			ObscuredULong.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663780);
			ObscuredULong.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663781);
			ObscuredULong.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663782);
			ObscuredULong.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, 100663783);
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00010808 File Offset: 0x0000EA08
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr, ref this));
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060002C2 RID: 706 RVA: 0x0001081A File Offset: 0x0000EA1A
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredULong>.NativeClassPtr));
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x0001082C File Offset: 0x0000EA2C
		// (set) Token: 0x060002C4 RID: 708 RVA: 0x0001084A File Offset: 0x0000EA4A
		public unsafe static ulong cryptoKey
		{
			get
			{
				ulong result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredULong.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredULong.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400028E RID: 654
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400028F RID: 655
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x04000290 RID: 656
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x04000291 RID: 657
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x04000292 RID: 658
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000293 RID: 659
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_UInt64_0;

		// Token: 0x04000294 RID: 660
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_UInt64_0;

		// Token: 0x04000295 RID: 661
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_0;

		// Token: 0x04000296 RID: 662
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_0;

		// Token: 0x04000297 RID: 663
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_UInt64_UInt64_UInt64_0;

		// Token: 0x04000298 RID: 664
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_UInt64_UInt64_UInt64_0;

		// Token: 0x04000299 RID: 665
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400029A RID: 666
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400029B RID: 667
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_UInt64_0;

		// Token: 0x0400029C RID: 668
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_UInt64_0;

		// Token: 0x0400029D RID: 669
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_UInt64_0;

		// Token: 0x0400029E RID: 670
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_UInt64_0;

		// Token: 0x0400029F RID: 671
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredULong_UInt64_0;

		// Token: 0x040002A0 RID: 672
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_UInt64_ObscuredULong_0;

		// Token: 0x040002A1 RID: 673
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredULong_ObscuredULong_0;

		// Token: 0x040002A2 RID: 674
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredULong_ObscuredULong_0;

		// Token: 0x040002A3 RID: 675
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x040002A4 RID: 676
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredULong_0;

		// Token: 0x040002A5 RID: 677
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x040002A6 RID: 678
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x040002A7 RID: 679
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x040002A8 RID: 680
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x040002A9 RID: 681
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x040002AA RID: 682
		[FieldOffset(0)]
		public ulong currentCryptoKey;

		// Token: 0x040002AB RID: 683
		[FieldOffset(8)]
		public ulong hiddenValue;

		// Token: 0x040002AC RID: 684
		[FieldOffset(16)]
		public ulong fakeValue;

		// Token: 0x040002AD RID: 685
		[FieldOffset(24)]
		public bool inited;
	}
}
