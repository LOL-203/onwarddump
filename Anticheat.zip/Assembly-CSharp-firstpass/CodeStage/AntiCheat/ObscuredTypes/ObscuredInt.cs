﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000016 RID: 22
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredInt
	{
		// Token: 0x06000146 RID: 326 RVA: 0x00008064 File Offset: 0x00006264
		[CallerCount(0)]
		public unsafe ObscuredInt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr__ctor_Private_Void_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000147 RID: 327 RVA: 0x000080AC File Offset: 0x000062AC
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(int newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000148 RID: 328 RVA: 0x000080F4 File Offset: 0x000062F4
		[CallerCount(0)]
		public unsafe static int Encrypt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00008148 File Offset: 0x00006348
		[CallerCount(0)]
		public unsafe static int Encrypt(int value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600014A RID: 330 RVA: 0x000081B0 File Offset: 0x000063B0
		[CallerCount(0)]
		public unsafe static int Decrypt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600014B RID: 331 RVA: 0x00008204 File Offset: 0x00006404
		[CallerCount(0)]
		public unsafe static int Decrypt(int value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000826C File Offset: 0x0000646C
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600014D RID: 333 RVA: 0x000082A0 File Offset: 0x000064A0
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600014E RID: 334 RVA: 0x000082D4 File Offset: 0x000064D4
		[CallerCount(0)]
		public unsafe int GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00008318 File Offset: 0x00006518
		[CallerCount(0)]
		public unsafe void SetEncrypted(int encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00008360 File Offset: 0x00006560
		[CallerCount(0)]
		public unsafe int GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_GetDecrypted_Public_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000151 RID: 337 RVA: 0x000083A4 File Offset: 0x000065A4
		[CallerCount(0)]
		public unsafe int InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_InternalDecrypt_Private_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000152 RID: 338 RVA: 0x000083E8 File Offset: 0x000065E8
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredInt(int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredInt_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0000843C File Offset: 0x0000663C
		[CallerCount(0)]
		public unsafe static implicit operator int(ObscuredInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_Int32_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00008490 File Offset: 0x00006690
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredFloat(ObscuredInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredFloat(intPtr);
		}

		// Token: 0x06000155 RID: 341 RVA: 0x000084E0 File Offset: 0x000066E0
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredDouble(ObscuredInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return new ObscuredDouble(intPtr);
		}

		// Token: 0x06000156 RID: 342 RVA: 0x00008530 File Offset: 0x00006730
		[CallerCount(0)]
		public unsafe static explicit operator ObscuredUInt(ObscuredInt value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredUInt_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00008584 File Offset: 0x00006784
		[CallerCount(0)]
		public unsafe static ObscuredInt operator ++(ObscuredInt input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredInt_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000158 RID: 344 RVA: 0x000085D8 File Offset: 0x000067D8
		[CallerCount(0)]
		public unsafe static ObscuredInt operator --(ObscuredInt input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref input;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredInt_ObscuredInt_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000862C File Offset: 0x0000682C
		[CallerCount(0)]
		public unsafe bool Equals(Object obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(obj);
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600015A RID: 346 RVA: 0x00008684 File Offset: 0x00006884
		[CallerCount(0)]
		public unsafe bool Equals(ObscuredInt obj)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref obj;
			IntPtr returnedException;
			IntPtr obj2 = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredInt_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj2);
		}

		// Token: 0x0600015B RID: 347 RVA: 0x000086D8 File Offset: 0x000068D8
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000871C File Offset: 0x0000691C
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00008758 File Offset: 0x00006958
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600015E RID: 350 RVA: 0x000087AC File Offset: 0x000069AC
		[CallerCount(0)]
		public unsafe string ToString(IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00008800 File Offset: 0x00006A00
		[CallerCount(0)]
		public unsafe string ToString(string format, IFormatProvider provider)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(provider);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredInt.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000886C File Offset: 0x00006A6C
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredInt()
		{
			Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredInt");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr);
			ObscuredInt.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, "cryptoKey");
			ObscuredInt.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, "currentCryptoKey");
			ObscuredInt.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, "hiddenValue");
			ObscuredInt.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, "fakeValue");
			ObscuredInt.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, "inited");
			ObscuredInt.NativeMethodInfoPtr__ctor_Private_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663486);
			ObscuredInt.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663487);
			ObscuredInt.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663488);
			ObscuredInt.NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663489);
			ObscuredInt.NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663490);
			ObscuredInt.NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663491);
			ObscuredInt.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663492);
			ObscuredInt.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663493);
			ObscuredInt.NativeMethodInfoPtr_GetEncrypted_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663494);
			ObscuredInt.NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663495);
			ObscuredInt.NativeMethodInfoPtr_GetDecrypted_Public_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663496);
			ObscuredInt.NativeMethodInfoPtr_InternalDecrypt_Private_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663497);
			ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredInt_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663498);
			ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_Int32_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663499);
			ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663500);
			ObscuredInt.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663501);
			ObscuredInt.NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredUInt_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663502);
			ObscuredInt.NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredInt_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663503);
			ObscuredInt.NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredInt_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663504);
			ObscuredInt.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663505);
			ObscuredInt.NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredInt_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663506);
			ObscuredInt.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663507);
			ObscuredInt.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663508);
			ObscuredInt.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663509);
			ObscuredInt.NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663510);
			ObscuredInt.NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, 100663511);
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00008B08 File Offset: 0x00006D08
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr, ref this));
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000162 RID: 354 RVA: 0x00008B1A File Offset: 0x00006D1A
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredInt>.NativeClassPtr));
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000163 RID: 355 RVA: 0x00008B2C File Offset: 0x00006D2C
		// (set) Token: 0x06000164 RID: 356 RVA: 0x00008B4A File Offset: 0x00006D4A
		public unsafe static int cryptoKey
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredInt.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredInt.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x0400011B RID: 283
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x0400011C RID: 284
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x0400011D RID: 285
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x0400011E RID: 286
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x0400011F RID: 287
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x04000120 RID: 288
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_Int32_0;

		// Token: 0x04000121 RID: 289
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0;

		// Token: 0x04000122 RID: 290
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_0;

		// Token: 0x04000123 RID: 291
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_Int32_Int32_Int32_0;

		// Token: 0x04000124 RID: 292
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_0;

		// Token: 0x04000125 RID: 293
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Int32_Int32_Int32_0;

		// Token: 0x04000126 RID: 294
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x04000127 RID: 295
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x04000128 RID: 296
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_Int32_0;

		// Token: 0x04000129 RID: 297
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_Int32_0;

		// Token: 0x0400012A RID: 298
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Int32_0;

		// Token: 0x0400012B RID: 299
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Int32_0;

		// Token: 0x0400012C RID: 300
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredInt_Int32_0;

		// Token: 0x0400012D RID: 301
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Int32_ObscuredInt_0;

		// Token: 0x0400012E RID: 302
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredFloat_ObscuredInt_0;

		// Token: 0x0400012F RID: 303
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredDouble_ObscuredInt_0;

		// Token: 0x04000130 RID: 304
		private static readonly IntPtr NativeMethodInfoPtr_op_Explicit_Public_Static_ObscuredUInt_ObscuredInt_0;

		// Token: 0x04000131 RID: 305
		private static readonly IntPtr NativeMethodInfoPtr_op_Increment_Public_Static_ObscuredInt_ObscuredInt_0;

		// Token: 0x04000132 RID: 306
		private static readonly IntPtr NativeMethodInfoPtr_op_Decrement_Public_Static_ObscuredInt_ObscuredInt_0;

		// Token: 0x04000133 RID: 307
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000134 RID: 308
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Final_New_Boolean_ObscuredInt_0;

		// Token: 0x04000135 RID: 309
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x04000136 RID: 310
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x04000137 RID: 311
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x04000138 RID: 312
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_IFormatProvider_0;

		// Token: 0x04000139 RID: 313
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_Final_New_String_String_IFormatProvider_0;

		// Token: 0x0400013A RID: 314
		[FieldOffset(0)]
		public int currentCryptoKey;

		// Token: 0x0400013B RID: 315
		[FieldOffset(4)]
		public int hiddenValue;

		// Token: 0x0400013C RID: 316
		[FieldOffset(8)]
		public int fakeValue;

		// Token: 0x0400013D RID: 317
		[FieldOffset(12)]
		public bool inited;
	}
}
