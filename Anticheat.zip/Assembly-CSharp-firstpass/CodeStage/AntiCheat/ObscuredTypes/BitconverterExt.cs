﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x0200001B RID: 27
	public class BitconverterExt : Object
	{
		// Token: 0x0600020D RID: 525 RVA: 0x0000C9BC File Offset: 0x0000ABBC
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> GetBytes(Decimal dec)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref dec;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BitconverterExt.NativeMethodInfoPtr_GetBytes_Public_Static_ArrayOf_Byte_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x0600020E RID: 526 RVA: 0x0000CA18 File Offset: 0x0000AC18
		[CallerCount(0)]
		public unsafe static Decimal ToDecimal(Il2CppStructArray<byte> bytes)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bytes);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(BitconverterExt.NativeMethodInfoPtr_ToDecimal_Public_Static_Decimal_ArrayOf_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600020F RID: 527 RVA: 0x0000CA70 File Offset: 0x0000AC70
		[CallerCount(0)]
		public unsafe BitconverterExt() : this(IL2CPP.il2cpp_object_new(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr))
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(BitconverterExt.NativeMethodInfoPtr__ctor_Public_Void_0, IL2CPP.Il2CppObjectBaseToPtrNotNull(this), (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000210 RID: 528 RVA: 0x0000CABC File Offset: 0x0000ACBC
		// Note: this type is marked as 'beforefieldinit'.
		static BitconverterExt()
		{
			Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "BitconverterExt");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr);
			BitconverterExt.NativeMethodInfoPtr_GetBytes_Public_Static_ArrayOf_Byte_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr, 100663641);
			BitconverterExt.NativeMethodInfoPtr_ToDecimal_Public_Static_Decimal_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr, 100663642);
			BitconverterExt.NativeMethodInfoPtr__ctor_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr, 100663643);
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00002580 File Offset: 0x00000780
		public BitconverterExt(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000212 RID: 530 RVA: 0x0000CB28 File Offset: 0x0000AD28
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<BitconverterExt>.NativeClassPtr));
			}
		}

		// Token: 0x040001E9 RID: 489
		private static readonly IntPtr NativeMethodInfoPtr_GetBytes_Public_Static_ArrayOf_Byte_Decimal_0;

		// Token: 0x040001EA RID: 490
		private static readonly IntPtr NativeMethodInfoPtr_ToDecimal_Public_Static_Decimal_ArrayOf_Byte_0;

		// Token: 0x040001EB RID: 491
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_0;
	}
}
