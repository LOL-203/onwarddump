﻿using System;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000018 RID: 24
	public static class ObscuredPrefs : Il2CppSystem.Object
	{
		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00009570 File Offset: 0x00007770
		// (set) Token: 0x06000181 RID: 385 RVA: 0x00009524 File Offset: 0x00007724
		public unsafe static string CryptoKey
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_get_CryptoKey_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_set_CryptoKey_Public_Static_set_Void_String_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000183 RID: 387 RVA: 0x000095AC File Offset: 0x000077AC
		// (set) Token: 0x06000184 RID: 388 RVA: 0x000095E8 File Offset: 0x000077E8
		public unsafe static string DeviceId
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_get_DeviceId_Public_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_set_DeviceId_Public_Static_set_Void_String_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000185 RID: 389 RVA: 0x00009634 File Offset: 0x00007834
		// (set) Token: 0x06000186 RID: 390 RVA: 0x00009670 File Offset: 0x00007870
		public unsafe static string DeviceID
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_get_DeviceID_Internal_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_set_DeviceID_Internal_Static_set_Void_String_0, 0, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000187 RID: 391 RVA: 0x000096BC File Offset: 0x000078BC
		public unsafe static uint DeviceIdHash
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_get_DeviceIdHash_Private_Static_get_UInt32_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00009700 File Offset: 0x00007900
		[CallerCount(0)]
		public unsafe static void ForceLockToDeviceInit()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_ForceLockToDeviceInit_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00009734 File Offset: 0x00007934
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(string newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(newKey);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetNewCryptoKey_Internal_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00009780 File Offset: 0x00007980
		[CallerCount(0)]
		public unsafe static void SetInt(string key, int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetInt_Public_Static_Void_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600018B RID: 395 RVA: 0x000097E0 File Offset: 0x000079E0
		[CallerCount(0)]
		public unsafe static int GetInt(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600018C RID: 396 RVA: 0x00009838 File Offset: 0x00007A38
		[CallerCount(0)]
		public unsafe static int GetInt(string key, int defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600018D RID: 397 RVA: 0x000098A4 File Offset: 0x00007AA4
		[CallerCount(0)]
		public unsafe static string EncryptIntValue(string key, int value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptIntValue_Internal_Static_String_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600018E RID: 398 RVA: 0x0000990C File Offset: 0x00007B0C
		[CallerCount(0)]
		public unsafe static int DecryptIntValue(string key, string encryptedInput, int defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptIntValue_Internal_Static_Int32_String_String_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00009990 File Offset: 0x00007B90
		[CallerCount(0)]
		public unsafe static void SetUInt(string key, uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetUInt_Public_Static_Void_String_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000190 RID: 400 RVA: 0x000099F0 File Offset: 0x00007BF0
		[CallerCount(0)]
		public unsafe static uint GetUInt(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00009A48 File Offset: 0x00007C48
		[CallerCount(0)]
		public unsafe static uint GetUInt(string key, uint defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00009AB4 File Offset: 0x00007CB4
		[CallerCount(0)]
		public unsafe static string EncryptUIntValue(string key, uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptUIntValue_Private_Static_String_String_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00009B1C File Offset: 0x00007D1C
		[CallerCount(0)]
		public unsafe static uint DecryptUIntValue(string key, string encryptedInput, uint defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptUIntValue_Private_Static_UInt32_String_String_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00009BA0 File Offset: 0x00007DA0
		[CallerCount(0)]
		public unsafe static void SetString(string key, string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetString_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00009C04 File Offset: 0x00007E04
		[CallerCount(0)]
		public unsafe static string GetString(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetString_Public_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000196 RID: 406 RVA: 0x00009C58 File Offset: 0x00007E58
		[CallerCount(0)]
		public unsafe static string GetString(string key, string defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(defaultValue);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetString_Public_Static_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00009CC4 File Offset: 0x00007EC4
		[CallerCount(0)]
		public unsafe static string EncryptStringValue(string key, string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptStringValue_Internal_Static_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000198 RID: 408 RVA: 0x00009D30 File Offset: 0x00007F30
		[CallerCount(0)]
		public unsafe static string DecryptStringValue(string key, string encryptedInput, string defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(defaultValue);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptStringValue_Internal_Static_String_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000199 RID: 409 RVA: 0x00009DB4 File Offset: 0x00007FB4
		[CallerCount(0)]
		public unsafe static void SetFloat(string key, float value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetFloat_Public_Static_Void_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600019A RID: 410 RVA: 0x00009E14 File Offset: 0x00008014
		[CallerCount(0)]
		public unsafe static float GetFloat(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600019B RID: 411 RVA: 0x00009E6C File Offset: 0x0000806C
		[CallerCount(0)]
		public unsafe static float GetFloat(string key, float defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600019C RID: 412 RVA: 0x00009ED8 File Offset: 0x000080D8
		[CallerCount(0)]
		public unsafe static string EncryptFloatValue(string key, float value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptFloatValue_Internal_Static_String_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x0600019D RID: 413 RVA: 0x00009F40 File Offset: 0x00008140
		[CallerCount(0)]
		public unsafe static float DecryptFloatValue(string key, string encryptedInput, float defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptFloatValue_Internal_Static_Single_String_String_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600019E RID: 414 RVA: 0x00009FC4 File Offset: 0x000081C4
		[CallerCount(0)]
		public unsafe static void SetDouble(string key, double value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetDouble_Public_Static_Void_String_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600019F RID: 415 RVA: 0x0000A024 File Offset: 0x00008224
		[CallerCount(0)]
		public unsafe static double GetDouble(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x0000A07C File Offset: 0x0000827C
		[CallerCount(0)]
		public unsafe static double GetDouble(string key, double defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x0000A0E8 File Offset: 0x000082E8
		[CallerCount(0)]
		public unsafe static string EncryptDoubleValue(string key, double value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptDoubleValue_Private_Static_String_String_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x0000A150 File Offset: 0x00008350
		[CallerCount(0)]
		public unsafe static double DecryptDoubleValue(string key, string encryptedInput, double defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptDoubleValue_Private_Static_Double_String_String_Double_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x0000A1D4 File Offset: 0x000083D4
		[CallerCount(0)]
		public unsafe static void SetDecimal(string key, Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetDecimal_Public_Static_Void_String_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0000A234 File Offset: 0x00008434
		[CallerCount(0)]
		public unsafe static Decimal GetDecimal(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A5 RID: 421 RVA: 0x0000A28C File Offset: 0x0000848C
		[CallerCount(0)]
		public unsafe static Decimal GetDecimal(string key, Decimal defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x0000A2F8 File Offset: 0x000084F8
		[CallerCount(0)]
		public unsafe static string EncryptDecimalValue(string key, Decimal value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptDecimalValue_Private_Static_String_String_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x0000A360 File Offset: 0x00008560
		[CallerCount(0)]
		public unsafe static Decimal DecryptDecimalValue(string key, string encryptedInput, Decimal defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptDecimalValue_Private_Static_Decimal_String_String_Decimal_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000A3E4 File Offset: 0x000085E4
		[CallerCount(0)]
		public unsafe static void SetLong(string key, long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetLong_Public_Static_Void_String_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0000A444 File Offset: 0x00008644
		[CallerCount(0)]
		public unsafe static long GetLong(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001AA RID: 426 RVA: 0x0000A49C File Offset: 0x0000869C
		[CallerCount(0)]
		public unsafe static long GetLong(string key, long defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001AB RID: 427 RVA: 0x0000A508 File Offset: 0x00008708
		[CallerCount(0)]
		public unsafe static string EncryptLongValue(string key, long value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptLongValue_Private_Static_String_String_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001AC RID: 428 RVA: 0x0000A570 File Offset: 0x00008770
		[CallerCount(0)]
		public unsafe static long DecryptLongValue(string key, string encryptedInput, long defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptLongValue_Private_Static_Int64_String_String_Int64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001AD RID: 429 RVA: 0x0000A5F4 File Offset: 0x000087F4
		[CallerCount(0)]
		public unsafe static void SetULong(string key, ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetULong_Public_Static_Void_String_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001AE RID: 430 RVA: 0x0000A654 File Offset: 0x00008854
		[CallerCount(0)]
		public unsafe static ulong GetULong(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001AF RID: 431 RVA: 0x0000A6AC File Offset: 0x000088AC
		[CallerCount(0)]
		public unsafe static ulong GetULong(string key, ulong defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x0000A718 File Offset: 0x00008918
		[CallerCount(0)]
		public unsafe static string EncryptULongValue(string key, ulong value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptULongValue_Private_Static_String_String_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x0000A780 File Offset: 0x00008980
		[CallerCount(0)]
		public unsafe static ulong DecryptULongValue(string key, string encryptedInput, ulong defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptULongValue_Private_Static_UInt64_String_String_UInt64_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x0000A804 File Offset: 0x00008A04
		[CallerCount(0)]
		public unsafe static void SetBool(string key, bool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetBool_Public_Static_Void_String_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000A864 File Offset: 0x00008A64
		[CallerCount(0)]
		public unsafe static bool GetBool(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000A8BC File Offset: 0x00008ABC
		[CallerCount(0)]
		public unsafe static bool GetBool(string key, bool defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0000A928 File Offset: 0x00008B28
		[CallerCount(0)]
		public unsafe static string EncryptBoolValue(string key, bool value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptBoolValue_Private_Static_String_String_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000A990 File Offset: 0x00008B90
		[CallerCount(0)]
		public unsafe static bool DecryptBoolValue(string key, string encryptedInput, bool defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptBoolValue_Private_Static_Boolean_String_String_Boolean_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000AA14 File Offset: 0x00008C14
		[CallerCount(0)]
		public unsafe static void SetByteArray(string key, Il2CppStructArray<byte> value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetByteArray_Public_Static_Void_String_ArrayOf_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000AA78 File Offset: 0x00008C78
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> GetByteArray(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x0000AAD8 File Offset: 0x00008CD8
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> GetByteArray(string key, byte defaultValue, int defaultLength)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultLength;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_Byte_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001BA RID: 442 RVA: 0x0000AB5C File Offset: 0x00008D5C
		[CallerCount(0)]
		public unsafe static string EncryptByteArrayValue(string key, Il2CppStructArray<byte> value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(value);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptByteArrayValue_Private_Static_String_String_ArrayOf_Byte_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000ABC8 File Offset: 0x00008DC8
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> DecryptByteArrayValue(string key, string encryptedInput, byte defaultValue, int defaultLength)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultLength;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptByteArrayValue_Private_Static_ArrayOf_Byte_String_String_Byte_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000AC64 File Offset: 0x00008E64
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> ConstructByteArray(byte value, int length)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref length;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_ConstructByteArray_Private_Static_ArrayOf_Byte_Byte_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001BD RID: 445 RVA: 0x0000ACD0 File Offset: 0x00008ED0
		[CallerCount(0)]
		public unsafe static void SetVector2(string key, Vector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetVector2_Public_Static_Void_String_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0000AD30 File Offset: 0x00008F30
		[CallerCount(0)]
		public unsafe static Vector2 GetVector2(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000AD88 File Offset: 0x00008F88
		[CallerCount(0)]
		public unsafe static Vector2 GetVector2(string key, Vector2 defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000ADF4 File Offset: 0x00008FF4
		[CallerCount(0)]
		public unsafe static string EncryptVector2Value(string key, Vector2 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptVector2Value_Private_Static_String_String_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0000AE5C File Offset: 0x0000905C
		[CallerCount(0)]
		public unsafe static Vector2 DecryptVector2Value(string key, string encryptedInput, Vector2 defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptVector2Value_Private_Static_Vector2_String_String_Vector2_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x0000AEE0 File Offset: 0x000090E0
		[CallerCount(0)]
		public unsafe static void SetVector3(string key, Vector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetVector3_Public_Static_Void_String_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x0000AF40 File Offset: 0x00009140
		[CallerCount(0)]
		public unsafe static Vector3 GetVector3(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x0000AF98 File Offset: 0x00009198
		[CallerCount(0)]
		public unsafe static Vector3 GetVector3(string key, Vector3 defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x0000B004 File Offset: 0x00009204
		[CallerCount(0)]
		public unsafe static string EncryptVector3Value(string key, Vector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptVector3Value_Private_Static_String_String_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x0000B06C File Offset: 0x0000926C
		[CallerCount(0)]
		public unsafe static Vector3 DecryptVector3Value(string key, string encryptedInput, Vector3 defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptVector3Value_Private_Static_Vector3_String_String_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0000B0F0 File Offset: 0x000092F0
		[CallerCount(0)]
		public unsafe static void SetQuaternion(string key, Quaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetQuaternion_Public_Static_Void_String_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0000B150 File Offset: 0x00009350
		[CallerCount(0)]
		public unsafe static Quaternion GetQuaternion(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0000B1A8 File Offset: 0x000093A8
		[CallerCount(0)]
		public unsafe static Quaternion GetQuaternion(string key, Quaternion defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0000B214 File Offset: 0x00009414
		[CallerCount(0)]
		public unsafe static string EncryptQuaternionValue(string key, Quaternion value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptQuaternionValue_Private_Static_String_String_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000B27C File Offset: 0x0000947C
		[CallerCount(0)]
		public unsafe static Quaternion DecryptQuaternionValue(string key, string encryptedInput, Quaternion defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptQuaternionValue_Private_Static_Quaternion_String_String_Quaternion_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000B300 File Offset: 0x00009500
		[CallerCount(0)]
		public unsafe static void SetColor(string key, Color32 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetColor_Public_Static_Void_String_Color32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001CD RID: 461 RVA: 0x0000B360 File Offset: 0x00009560
		[CallerCount(0)]
		public unsafe static Color32 GetColor(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000B3B8 File Offset: 0x000095B8
		[CallerCount(0)]
		public unsafe static Color32 GetColor(string key, Color32 defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_Color32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000B424 File Offset: 0x00009624
		[CallerCount(0)]
		public unsafe static string EncryptColorValue(string key, uint value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptColorValue_Private_Static_String_String_UInt32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000B48C File Offset: 0x0000968C
		[CallerCount(0)]
		public unsafe static void SetRect(string key, Rect value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetRect_Public_Static_Void_String_Rect_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000B4EC File Offset: 0x000096EC
		[CallerCount(0)]
		public unsafe static Rect GetRect(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000B544 File Offset: 0x00009744
		[CallerCount(0)]
		public unsafe static Rect GetRect(string key, Rect defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_Rect_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000B5B0 File Offset: 0x000097B0
		[CallerCount(0)]
		public unsafe static string EncryptRectValue(string key, Rect value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptRectValue_Private_Static_String_String_Rect_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000B618 File Offset: 0x00009818
		[CallerCount(0)]
		public unsafe static Rect DecryptRectValue(string key, string encryptedInput, Rect defaultValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref defaultValue;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptRectValue_Private_Static_Rect_String_String_Rect_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000B69C File Offset: 0x0000989C
		[CallerCount(0)]
		public unsafe static void SetRawValue(string key, string encryptedValue)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedValue);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SetRawValue_Public_Static_Void_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000B700 File Offset: 0x00009900
		[CallerCount(0)]
		public unsafe static string GetRawValue(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetRawValue_Public_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000B754 File Offset: 0x00009954
		[CallerCount(0)]
		public unsafe static ObscuredPrefs.DataType GetRawValueType(string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetRawValueType_Internal_Static_DataType_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000B7AC File Offset: 0x000099AC
		[CallerCount(0)]
		public unsafe static string EncryptKey(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptKey_Internal_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000B800 File Offset: 0x00009A00
		[CallerCount(0)]
		public unsafe static bool HasKey(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_HasKey_Public_Static_Boolean_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000B858 File Offset: 0x00009A58
		[CallerCount(0)]
		public unsafe static void DeleteKey(string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DeleteKey_Public_Static_Void_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000B8A4 File Offset: 0x00009AA4
		[CallerCount(0)]
		public unsafe static void DeleteAll()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DeleteAll_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000B8D8 File Offset: 0x00009AD8
		[CallerCount(0)]
		public unsafe static void Save()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_Save_Public_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000B90C File Offset: 0x00009B0C
		[CallerCount(0)]
		public unsafe static string GetEncryptedPrefsString(string key, string encryptedKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedKey);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetEncryptedPrefsString_Private_Static_String_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000B978 File Offset: 0x00009B78
		[CallerCount(0)]
		public unsafe static string EncryptData(string key, Il2CppStructArray<byte> cleanBytes, ObscuredPrefs.DataType type)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.Il2CppObjectBaseToPtr(cleanBytes);
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref type;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptData_Private_Static_String_String_ArrayOf_Byte_DataType_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000B9F8 File Offset: 0x00009BF8
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> DecryptData(string key, string encryptedInput)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(key);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(encryptedInput);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DecryptData_Internal_Static_ArrayOf_Byte_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x0000BA70 File Offset: 0x00009C70
		[CallerCount(0)]
		public unsafe static uint CalculateChecksum(string input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(input);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_CalculateChecksum_Private_Static_UInt32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x0000BAC8 File Offset: 0x00009CC8
		[CallerCount(0)]
		public unsafe static void SavesTampered()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_SavesTampered_Private_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x0000BAFC File Offset: 0x00009CFC
		[CallerCount(0)]
		public unsafe static void PossibleForeignSavesDetected()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_PossibleForeignSavesDetected_Private_Static_Void_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000BB30 File Offset: 0x00009D30
		[CallerCount(0)]
		public unsafe static string GetDeviceId()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_GetDeviceId_Private_Static_String_0, 0, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x0000BB6C File Offset: 0x00009D6C
		[CallerCount(0)]
		public unsafe static Il2CppStructArray<byte> EncryptDecryptBytes(Il2CppStructArray<byte> bytes, int dataLength, string key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(bytes);
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref dataLength;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = IL2CPP.ManagedStringToIl2Cpp(key);
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_EncryptDecryptBytes_Private_Static_ArrayOf_Byte_ArrayOf_Byte_Int32_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			IntPtr intPtr2 = intPtr;
			return (intPtr2 != 0) ? new Il2CppStructArray<byte>(intPtr2) : null;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0000BBF8 File Offset: 0x00009DF8
		[CallerCount(0)]
		public unsafe static string DeprecatedDecryptValue(string value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(value);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DeprecatedDecryptValue_Private_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x0000BC4C File Offset: 0x00009E4C
		[CallerCount(0)]
		public unsafe static string DeprecatedCalculateChecksum(string input)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(input);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_DeprecatedCalculateChecksum_Private_Static_String_String_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060001E7 RID: 487 RVA: 0x0000BCA0 File Offset: 0x00009EA0
		public unsafe static string DeprecatedDeviceId
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredPrefs.NativeMethodInfoPtr_get_DeprecatedDeviceId_Private_Static_get_String_0, 0, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x0000BCDC File Offset: 0x00009EDC
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredPrefs()
		{
			Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredPrefs");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr);
			ObscuredPrefs.NativeFieldInfoPtr_VERSION = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "VERSION");
			ObscuredPrefs.NativeFieldInfoPtr_RAW_NOT_FOUND = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "RAW_NOT_FOUND");
			ObscuredPrefs.NativeFieldInfoPtr_DATA_SEPARATOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "DATA_SEPARATOR");
			ObscuredPrefs.NativeFieldInfoPtr_foreignSavesReported = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "foreignSavesReported");
			ObscuredPrefs.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "cryptoKey");
			ObscuredPrefs.NativeFieldInfoPtr_deviceId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "deviceId");
			ObscuredPrefs.NativeFieldInfoPtr_deviceIdHash = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "deviceIdHash");
			ObscuredPrefs.NativeFieldInfoPtr_onAlterationDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "onAlterationDetected");
			ObscuredPrefs.NativeFieldInfoPtr_preservePlayerPrefs = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "preservePlayerPrefs");
			ObscuredPrefs.NativeFieldInfoPtr_onPossibleForeignSavesDetected = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "onPossibleForeignSavesDetected");
			ObscuredPrefs.NativeFieldInfoPtr_lockToDevice = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "lockToDevice");
			ObscuredPrefs.NativeFieldInfoPtr_readForeignSaves = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "readForeignSaves");
			ObscuredPrefs.NativeFieldInfoPtr_emergencyMode = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "emergencyMode");
			ObscuredPrefs.NativeFieldInfoPtr_DEPRECATED_RAW_SEPARATOR = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "DEPRECATED_RAW_SEPARATOR");
			ObscuredPrefs.NativeFieldInfoPtr_deprecatedDeviceId = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, "deprecatedDeviceId");
			ObscuredPrefs.NativeMethodInfoPtr_set_CryptoKey_Public_Static_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663537);
			ObscuredPrefs.NativeMethodInfoPtr_get_CryptoKey_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663538);
			ObscuredPrefs.NativeMethodInfoPtr_get_DeviceId_Public_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663539);
			ObscuredPrefs.NativeMethodInfoPtr_set_DeviceId_Public_Static_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663540);
			ObscuredPrefs.NativeMethodInfoPtr_get_DeviceID_Internal_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663541);
			ObscuredPrefs.NativeMethodInfoPtr_set_DeviceID_Internal_Static_set_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663542);
			ObscuredPrefs.NativeMethodInfoPtr_get_DeviceIdHash_Private_Static_get_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663543);
			ObscuredPrefs.NativeMethodInfoPtr_ForceLockToDeviceInit_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663544);
			ObscuredPrefs.NativeMethodInfoPtr_SetNewCryptoKey_Internal_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663545);
			ObscuredPrefs.NativeMethodInfoPtr_SetInt_Public_Static_Void_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663546);
			ObscuredPrefs.NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663547);
			ObscuredPrefs.NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663548);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptIntValue_Internal_Static_String_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663549);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptIntValue_Internal_Static_Int32_String_String_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663550);
			ObscuredPrefs.NativeMethodInfoPtr_SetUInt_Public_Static_Void_String_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663551);
			ObscuredPrefs.NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663552);
			ObscuredPrefs.NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663553);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptUIntValue_Private_Static_String_String_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663554);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptUIntValue_Private_Static_UInt32_String_String_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663555);
			ObscuredPrefs.NativeMethodInfoPtr_SetString_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663556);
			ObscuredPrefs.NativeMethodInfoPtr_GetString_Public_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663557);
			ObscuredPrefs.NativeMethodInfoPtr_GetString_Public_Static_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663558);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptStringValue_Internal_Static_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663559);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptStringValue_Internal_Static_String_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663560);
			ObscuredPrefs.NativeMethodInfoPtr_SetFloat_Public_Static_Void_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663561);
			ObscuredPrefs.NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663562);
			ObscuredPrefs.NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663563);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptFloatValue_Internal_Static_String_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663564);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptFloatValue_Internal_Static_Single_String_String_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663565);
			ObscuredPrefs.NativeMethodInfoPtr_SetDouble_Public_Static_Void_String_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663566);
			ObscuredPrefs.NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663567);
			ObscuredPrefs.NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663568);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptDoubleValue_Private_Static_String_String_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663569);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptDoubleValue_Private_Static_Double_String_String_Double_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663570);
			ObscuredPrefs.NativeMethodInfoPtr_SetDecimal_Public_Static_Void_String_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663571);
			ObscuredPrefs.NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663572);
			ObscuredPrefs.NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663573);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptDecimalValue_Private_Static_String_String_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663574);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptDecimalValue_Private_Static_Decimal_String_String_Decimal_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663575);
			ObscuredPrefs.NativeMethodInfoPtr_SetLong_Public_Static_Void_String_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663576);
			ObscuredPrefs.NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663577);
			ObscuredPrefs.NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663578);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptLongValue_Private_Static_String_String_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663579);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptLongValue_Private_Static_Int64_String_String_Int64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663580);
			ObscuredPrefs.NativeMethodInfoPtr_SetULong_Public_Static_Void_String_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663581);
			ObscuredPrefs.NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663582);
			ObscuredPrefs.NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663583);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptULongValue_Private_Static_String_String_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663584);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptULongValue_Private_Static_UInt64_String_String_UInt64_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663585);
			ObscuredPrefs.NativeMethodInfoPtr_SetBool_Public_Static_Void_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663586);
			ObscuredPrefs.NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663587);
			ObscuredPrefs.NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663588);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptBoolValue_Private_Static_String_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663589);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptBoolValue_Private_Static_Boolean_String_String_Boolean_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663590);
			ObscuredPrefs.NativeMethodInfoPtr_SetByteArray_Public_Static_Void_String_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663591);
			ObscuredPrefs.NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663592);
			ObscuredPrefs.NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_Byte_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663593);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptByteArrayValue_Private_Static_String_String_ArrayOf_Byte_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663594);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptByteArrayValue_Private_Static_ArrayOf_Byte_String_String_Byte_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663595);
			ObscuredPrefs.NativeMethodInfoPtr_ConstructByteArray_Private_Static_ArrayOf_Byte_Byte_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663596);
			ObscuredPrefs.NativeMethodInfoPtr_SetVector2_Public_Static_Void_String_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663597);
			ObscuredPrefs.NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663598);
			ObscuredPrefs.NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663599);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptVector2Value_Private_Static_String_String_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663600);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptVector2Value_Private_Static_Vector2_String_String_Vector2_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663601);
			ObscuredPrefs.NativeMethodInfoPtr_SetVector3_Public_Static_Void_String_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663602);
			ObscuredPrefs.NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663603);
			ObscuredPrefs.NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663604);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptVector3Value_Private_Static_String_String_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663605);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptVector3Value_Private_Static_Vector3_String_String_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663606);
			ObscuredPrefs.NativeMethodInfoPtr_SetQuaternion_Public_Static_Void_String_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663607);
			ObscuredPrefs.NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663608);
			ObscuredPrefs.NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663609);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptQuaternionValue_Private_Static_String_String_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663610);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptQuaternionValue_Private_Static_Quaternion_String_String_Quaternion_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663611);
			ObscuredPrefs.NativeMethodInfoPtr_SetColor_Public_Static_Void_String_Color32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663612);
			ObscuredPrefs.NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663613);
			ObscuredPrefs.NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_Color32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663614);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptColorValue_Private_Static_String_String_UInt32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663615);
			ObscuredPrefs.NativeMethodInfoPtr_SetRect_Public_Static_Void_String_Rect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663616);
			ObscuredPrefs.NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663617);
			ObscuredPrefs.NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_Rect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663618);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptRectValue_Private_Static_String_String_Rect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663619);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptRectValue_Private_Static_Rect_String_String_Rect_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663620);
			ObscuredPrefs.NativeMethodInfoPtr_SetRawValue_Public_Static_Void_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663621);
			ObscuredPrefs.NativeMethodInfoPtr_GetRawValue_Public_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663622);
			ObscuredPrefs.NativeMethodInfoPtr_GetRawValueType_Internal_Static_DataType_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663623);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptKey_Internal_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663624);
			ObscuredPrefs.NativeMethodInfoPtr_HasKey_Public_Static_Boolean_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663625);
			ObscuredPrefs.NativeMethodInfoPtr_DeleteKey_Public_Static_Void_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663626);
			ObscuredPrefs.NativeMethodInfoPtr_DeleteAll_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663627);
			ObscuredPrefs.NativeMethodInfoPtr_Save_Public_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663628);
			ObscuredPrefs.NativeMethodInfoPtr_GetEncryptedPrefsString_Private_Static_String_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663629);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptData_Private_Static_String_String_ArrayOf_Byte_DataType_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663630);
			ObscuredPrefs.NativeMethodInfoPtr_DecryptData_Internal_Static_ArrayOf_Byte_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663631);
			ObscuredPrefs.NativeMethodInfoPtr_CalculateChecksum_Private_Static_UInt32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663632);
			ObscuredPrefs.NativeMethodInfoPtr_SavesTampered_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663633);
			ObscuredPrefs.NativeMethodInfoPtr_PossibleForeignSavesDetected_Private_Static_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663634);
			ObscuredPrefs.NativeMethodInfoPtr_GetDeviceId_Private_Static_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663635);
			ObscuredPrefs.NativeMethodInfoPtr_EncryptDecryptBytes_Private_Static_ArrayOf_Byte_ArrayOf_Byte_Int32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663636);
			ObscuredPrefs.NativeMethodInfoPtr_DeprecatedDecryptValue_Private_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663637);
			ObscuredPrefs.NativeMethodInfoPtr_DeprecatedCalculateChecksum_Private_Static_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663638);
			ObscuredPrefs.NativeMethodInfoPtr_get_DeprecatedDeviceId_Private_Static_get_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr, 100663639);
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00002580 File Offset: 0x00000780
		public ObscuredPrefs(IntPtr A_1) : base(A_1)
		{
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060001EA RID: 490 RVA: 0x0000C644 File Offset: 0x0000A844
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public new static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredPrefs>.NativeClassPtr));
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060001EB RID: 491 RVA: 0x0000C658 File Offset: 0x0000A858
		// (set) Token: 0x060001EC RID: 492 RVA: 0x0000C676 File Offset: 0x0000A876
		public unsafe static byte VERSION
		{
			get
			{
				byte result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_VERSION, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_VERSION, (void*)(&value));
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060001ED RID: 493 RVA: 0x0000C688 File Offset: 0x0000A888
		// (set) Token: 0x060001EE RID: 494 RVA: 0x0000C6A8 File Offset: 0x0000A8A8
		public unsafe static string RAW_NOT_FOUND
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_RAW_NOT_FOUND, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_RAW_NOT_FOUND, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060001EF RID: 495 RVA: 0x0000C6C0 File Offset: 0x0000A8C0
		// (set) Token: 0x060001F0 RID: 496 RVA: 0x0000C6E0 File Offset: 0x0000A8E0
		public unsafe static string DATA_SEPARATOR
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_DATA_SEPARATOR, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_DATA_SEPARATOR, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060001F1 RID: 497 RVA: 0x0000C6F8 File Offset: 0x0000A8F8
		// (set) Token: 0x060001F2 RID: 498 RVA: 0x0000C716 File Offset: 0x0000A916
		public unsafe static bool foreignSavesReported
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_foreignSavesReported, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_foreignSavesReported, (void*)(&value));
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060001F3 RID: 499 RVA: 0x0000C728 File Offset: 0x0000A928
		// (set) Token: 0x060001F4 RID: 500 RVA: 0x0000C748 File Offset: 0x0000A948
		public unsafe static string cryptoKey
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_cryptoKey, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_cryptoKey, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060001F5 RID: 501 RVA: 0x0000C760 File Offset: 0x0000A960
		// (set) Token: 0x060001F6 RID: 502 RVA: 0x0000C780 File Offset: 0x0000A980
		public unsafe static string deviceId
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_deviceId, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_deviceId, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060001F7 RID: 503 RVA: 0x0000C798 File Offset: 0x0000A998
		// (set) Token: 0x060001F8 RID: 504 RVA: 0x0000C7B6 File Offset: 0x0000A9B6
		public unsafe static uint deviceIdHash
		{
			get
			{
				uint result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_deviceIdHash, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_deviceIdHash, (void*)(&value));
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060001F9 RID: 505 RVA: 0x0000C7C8 File Offset: 0x0000A9C8
		// (set) Token: 0x060001FA RID: 506 RVA: 0x0000C7F3 File Offset: 0x0000A9F3
		public unsafe static Action onAlterationDetected
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_onAlterationDetected, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_onAlterationDetected, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060001FB RID: 507 RVA: 0x0000C808 File Offset: 0x0000AA08
		// (set) Token: 0x060001FC RID: 508 RVA: 0x0000C826 File Offset: 0x0000AA26
		public unsafe static bool preservePlayerPrefs
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_preservePlayerPrefs, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_preservePlayerPrefs, (void*)(&value));
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060001FD RID: 509 RVA: 0x0000C838 File Offset: 0x0000AA38
		// (set) Token: 0x060001FE RID: 510 RVA: 0x0000C863 File Offset: 0x0000AA63
		public unsafe static Action onPossibleForeignSavesDetected
		{
			get
			{
				IntPtr intPtr;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_onPossibleForeignSavesDetected, (void*)(&intPtr));
				IntPtr intPtr2 = intPtr;
				return (intPtr2 != 0) ? new Action(intPtr2) : null;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_onPossibleForeignSavesDetected, IL2CPP.Il2CppObjectBaseToPtr(value));
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060001FF RID: 511 RVA: 0x0000C878 File Offset: 0x0000AA78
		// (set) Token: 0x06000200 RID: 512 RVA: 0x0000C896 File Offset: 0x0000AA96
		public unsafe static ObscuredPrefs.DeviceLockLevel lockToDevice
		{
			get
			{
				ObscuredPrefs.DeviceLockLevel result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_lockToDevice, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_lockToDevice, (void*)(&value));
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000201 RID: 513 RVA: 0x0000C8A8 File Offset: 0x0000AAA8
		// (set) Token: 0x06000202 RID: 514 RVA: 0x0000C8C6 File Offset: 0x0000AAC6
		public unsafe static bool readForeignSaves
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_readForeignSaves, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_readForeignSaves, (void*)(&value));
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000203 RID: 515 RVA: 0x0000C8D8 File Offset: 0x0000AAD8
		// (set) Token: 0x06000204 RID: 516 RVA: 0x0000C8F6 File Offset: 0x0000AAF6
		public unsafe static bool emergencyMode
		{
			get
			{
				bool result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_emergencyMode, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_emergencyMode, (void*)(&value));
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000205 RID: 517 RVA: 0x0000C908 File Offset: 0x0000AB08
		// (set) Token: 0x06000206 RID: 518 RVA: 0x0000C926 File Offset: 0x0000AB26
		public unsafe static char DEPRECATED_RAW_SEPARATOR
		{
			get
			{
				char result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_DEPRECATED_RAW_SEPARATOR, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_DEPRECATED_RAW_SEPARATOR, (void*)(&value));
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000207 RID: 519 RVA: 0x0000C938 File Offset: 0x0000AB38
		// (set) Token: 0x06000208 RID: 520 RVA: 0x0000C958 File Offset: 0x0000AB58
		public unsafe static string deprecatedDeviceId
		{
			get
			{
				IntPtr il2CppString;
				IL2CPP.il2cpp_field_static_get_value(ObscuredPrefs.NativeFieldInfoPtr_deprecatedDeviceId, (void*)(&il2CppString));
				return IL2CPP.Il2CppStringToManaged(il2CppString);
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredPrefs.NativeFieldInfoPtr_deprecatedDeviceId, IL2CPP.ManagedStringToIl2Cpp(value));
			}
		}

		// Token: 0x0400015E RID: 350
		private static readonly IntPtr NativeFieldInfoPtr_VERSION;

		// Token: 0x0400015F RID: 351
		private static readonly IntPtr NativeFieldInfoPtr_RAW_NOT_FOUND;

		// Token: 0x04000160 RID: 352
		private static readonly IntPtr NativeFieldInfoPtr_DATA_SEPARATOR;

		// Token: 0x04000161 RID: 353
		private static readonly IntPtr NativeFieldInfoPtr_foreignSavesReported;

		// Token: 0x04000162 RID: 354
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x04000163 RID: 355
		private static readonly IntPtr NativeFieldInfoPtr_deviceId;

		// Token: 0x04000164 RID: 356
		private static readonly IntPtr NativeFieldInfoPtr_deviceIdHash;

		// Token: 0x04000165 RID: 357
		private static readonly IntPtr NativeFieldInfoPtr_onAlterationDetected;

		// Token: 0x04000166 RID: 358
		private static readonly IntPtr NativeFieldInfoPtr_preservePlayerPrefs;

		// Token: 0x04000167 RID: 359
		private static readonly IntPtr NativeFieldInfoPtr_onPossibleForeignSavesDetected;

		// Token: 0x04000168 RID: 360
		private static readonly IntPtr NativeFieldInfoPtr_lockToDevice;

		// Token: 0x04000169 RID: 361
		private static readonly IntPtr NativeFieldInfoPtr_readForeignSaves;

		// Token: 0x0400016A RID: 362
		private static readonly IntPtr NativeFieldInfoPtr_emergencyMode;

		// Token: 0x0400016B RID: 363
		private static readonly IntPtr NativeFieldInfoPtr_DEPRECATED_RAW_SEPARATOR;

		// Token: 0x0400016C RID: 364
		private static readonly IntPtr NativeFieldInfoPtr_deprecatedDeviceId;

		// Token: 0x0400016D RID: 365
		private static readonly IntPtr NativeMethodInfoPtr_set_CryptoKey_Public_Static_set_Void_String_0;

		// Token: 0x0400016E RID: 366
		private static readonly IntPtr NativeMethodInfoPtr_get_CryptoKey_Public_Static_get_String_0;

		// Token: 0x0400016F RID: 367
		private static readonly IntPtr NativeMethodInfoPtr_get_DeviceId_Public_Static_get_String_0;

		// Token: 0x04000170 RID: 368
		private static readonly IntPtr NativeMethodInfoPtr_set_DeviceId_Public_Static_set_Void_String_0;

		// Token: 0x04000171 RID: 369
		private static readonly IntPtr NativeMethodInfoPtr_get_DeviceID_Internal_Static_get_String_0;

		// Token: 0x04000172 RID: 370
		private static readonly IntPtr NativeMethodInfoPtr_set_DeviceID_Internal_Static_set_Void_String_0;

		// Token: 0x04000173 RID: 371
		private static readonly IntPtr NativeMethodInfoPtr_get_DeviceIdHash_Private_Static_get_UInt32_0;

		// Token: 0x04000174 RID: 372
		private static readonly IntPtr NativeMethodInfoPtr_ForceLockToDeviceInit_Public_Static_Void_0;

		// Token: 0x04000175 RID: 373
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Internal_Static_Void_String_0;

		// Token: 0x04000176 RID: 374
		private static readonly IntPtr NativeMethodInfoPtr_SetInt_Public_Static_Void_String_Int32_0;

		// Token: 0x04000177 RID: 375
		private static readonly IntPtr NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_0;

		// Token: 0x04000178 RID: 376
		private static readonly IntPtr NativeMethodInfoPtr_GetInt_Public_Static_Int32_String_Int32_0;

		// Token: 0x04000179 RID: 377
		private static readonly IntPtr NativeMethodInfoPtr_EncryptIntValue_Internal_Static_String_String_Int32_0;

		// Token: 0x0400017A RID: 378
		private static readonly IntPtr NativeMethodInfoPtr_DecryptIntValue_Internal_Static_Int32_String_String_Int32_0;

		// Token: 0x0400017B RID: 379
		private static readonly IntPtr NativeMethodInfoPtr_SetUInt_Public_Static_Void_String_UInt32_0;

		// Token: 0x0400017C RID: 380
		private static readonly IntPtr NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_0;

		// Token: 0x0400017D RID: 381
		private static readonly IntPtr NativeMethodInfoPtr_GetUInt_Public_Static_UInt32_String_UInt32_0;

		// Token: 0x0400017E RID: 382
		private static readonly IntPtr NativeMethodInfoPtr_EncryptUIntValue_Private_Static_String_String_UInt32_0;

		// Token: 0x0400017F RID: 383
		private static readonly IntPtr NativeMethodInfoPtr_DecryptUIntValue_Private_Static_UInt32_String_String_UInt32_0;

		// Token: 0x04000180 RID: 384
		private static readonly IntPtr NativeMethodInfoPtr_SetString_Public_Static_Void_String_String_0;

		// Token: 0x04000181 RID: 385
		private static readonly IntPtr NativeMethodInfoPtr_GetString_Public_Static_String_String_0;

		// Token: 0x04000182 RID: 386
		private static readonly IntPtr NativeMethodInfoPtr_GetString_Public_Static_String_String_String_0;

		// Token: 0x04000183 RID: 387
		private static readonly IntPtr NativeMethodInfoPtr_EncryptStringValue_Internal_Static_String_String_String_0;

		// Token: 0x04000184 RID: 388
		private static readonly IntPtr NativeMethodInfoPtr_DecryptStringValue_Internal_Static_String_String_String_String_0;

		// Token: 0x04000185 RID: 389
		private static readonly IntPtr NativeMethodInfoPtr_SetFloat_Public_Static_Void_String_Single_0;

		// Token: 0x04000186 RID: 390
		private static readonly IntPtr NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_0;

		// Token: 0x04000187 RID: 391
		private static readonly IntPtr NativeMethodInfoPtr_GetFloat_Public_Static_Single_String_Single_0;

		// Token: 0x04000188 RID: 392
		private static readonly IntPtr NativeMethodInfoPtr_EncryptFloatValue_Internal_Static_String_String_Single_0;

		// Token: 0x04000189 RID: 393
		private static readonly IntPtr NativeMethodInfoPtr_DecryptFloatValue_Internal_Static_Single_String_String_Single_0;

		// Token: 0x0400018A RID: 394
		private static readonly IntPtr NativeMethodInfoPtr_SetDouble_Public_Static_Void_String_Double_0;

		// Token: 0x0400018B RID: 395
		private static readonly IntPtr NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_0;

		// Token: 0x0400018C RID: 396
		private static readonly IntPtr NativeMethodInfoPtr_GetDouble_Public_Static_Double_String_Double_0;

		// Token: 0x0400018D RID: 397
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDoubleValue_Private_Static_String_String_Double_0;

		// Token: 0x0400018E RID: 398
		private static readonly IntPtr NativeMethodInfoPtr_DecryptDoubleValue_Private_Static_Double_String_String_Double_0;

		// Token: 0x0400018F RID: 399
		private static readonly IntPtr NativeMethodInfoPtr_SetDecimal_Public_Static_Void_String_Decimal_0;

		// Token: 0x04000190 RID: 400
		private static readonly IntPtr NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_0;

		// Token: 0x04000191 RID: 401
		private static readonly IntPtr NativeMethodInfoPtr_GetDecimal_Public_Static_Decimal_String_Decimal_0;

		// Token: 0x04000192 RID: 402
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecimalValue_Private_Static_String_String_Decimal_0;

		// Token: 0x04000193 RID: 403
		private static readonly IntPtr NativeMethodInfoPtr_DecryptDecimalValue_Private_Static_Decimal_String_String_Decimal_0;

		// Token: 0x04000194 RID: 404
		private static readonly IntPtr NativeMethodInfoPtr_SetLong_Public_Static_Void_String_Int64_0;

		// Token: 0x04000195 RID: 405
		private static readonly IntPtr NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_0;

		// Token: 0x04000196 RID: 406
		private static readonly IntPtr NativeMethodInfoPtr_GetLong_Public_Static_Int64_String_Int64_0;

		// Token: 0x04000197 RID: 407
		private static readonly IntPtr NativeMethodInfoPtr_EncryptLongValue_Private_Static_String_String_Int64_0;

		// Token: 0x04000198 RID: 408
		private static readonly IntPtr NativeMethodInfoPtr_DecryptLongValue_Private_Static_Int64_String_String_Int64_0;

		// Token: 0x04000199 RID: 409
		private static readonly IntPtr NativeMethodInfoPtr_SetULong_Public_Static_Void_String_UInt64_0;

		// Token: 0x0400019A RID: 410
		private static readonly IntPtr NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_0;

		// Token: 0x0400019B RID: 411
		private static readonly IntPtr NativeMethodInfoPtr_GetULong_Public_Static_UInt64_String_UInt64_0;

		// Token: 0x0400019C RID: 412
		private static readonly IntPtr NativeMethodInfoPtr_EncryptULongValue_Private_Static_String_String_UInt64_0;

		// Token: 0x0400019D RID: 413
		private static readonly IntPtr NativeMethodInfoPtr_DecryptULongValue_Private_Static_UInt64_String_String_UInt64_0;

		// Token: 0x0400019E RID: 414
		private static readonly IntPtr NativeMethodInfoPtr_SetBool_Public_Static_Void_String_Boolean_0;

		// Token: 0x0400019F RID: 415
		private static readonly IntPtr NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_0;

		// Token: 0x040001A0 RID: 416
		private static readonly IntPtr NativeMethodInfoPtr_GetBool_Public_Static_Boolean_String_Boolean_0;

		// Token: 0x040001A1 RID: 417
		private static readonly IntPtr NativeMethodInfoPtr_EncryptBoolValue_Private_Static_String_String_Boolean_0;

		// Token: 0x040001A2 RID: 418
		private static readonly IntPtr NativeMethodInfoPtr_DecryptBoolValue_Private_Static_Boolean_String_String_Boolean_0;

		// Token: 0x040001A3 RID: 419
		private static readonly IntPtr NativeMethodInfoPtr_SetByteArray_Public_Static_Void_String_ArrayOf_Byte_0;

		// Token: 0x040001A4 RID: 420
		private static readonly IntPtr NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_0;

		// Token: 0x040001A5 RID: 421
		private static readonly IntPtr NativeMethodInfoPtr_GetByteArray_Public_Static_ArrayOf_Byte_String_Byte_Int32_0;

		// Token: 0x040001A6 RID: 422
		private static readonly IntPtr NativeMethodInfoPtr_EncryptByteArrayValue_Private_Static_String_String_ArrayOf_Byte_0;

		// Token: 0x040001A7 RID: 423
		private static readonly IntPtr NativeMethodInfoPtr_DecryptByteArrayValue_Private_Static_ArrayOf_Byte_String_String_Byte_Int32_0;

		// Token: 0x040001A8 RID: 424
		private static readonly IntPtr NativeMethodInfoPtr_ConstructByteArray_Private_Static_ArrayOf_Byte_Byte_Int32_0;

		// Token: 0x040001A9 RID: 425
		private static readonly IntPtr NativeMethodInfoPtr_SetVector2_Public_Static_Void_String_Vector2_0;

		// Token: 0x040001AA RID: 426
		private static readonly IntPtr NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_0;

		// Token: 0x040001AB RID: 427
		private static readonly IntPtr NativeMethodInfoPtr_GetVector2_Public_Static_Vector2_String_Vector2_0;

		// Token: 0x040001AC RID: 428
		private static readonly IntPtr NativeMethodInfoPtr_EncryptVector2Value_Private_Static_String_String_Vector2_0;

		// Token: 0x040001AD RID: 429
		private static readonly IntPtr NativeMethodInfoPtr_DecryptVector2Value_Private_Static_Vector2_String_String_Vector2_0;

		// Token: 0x040001AE RID: 430
		private static readonly IntPtr NativeMethodInfoPtr_SetVector3_Public_Static_Void_String_Vector3_0;

		// Token: 0x040001AF RID: 431
		private static readonly IntPtr NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_0;

		// Token: 0x040001B0 RID: 432
		private static readonly IntPtr NativeMethodInfoPtr_GetVector3_Public_Static_Vector3_String_Vector3_0;

		// Token: 0x040001B1 RID: 433
		private static readonly IntPtr NativeMethodInfoPtr_EncryptVector3Value_Private_Static_String_String_Vector3_0;

		// Token: 0x040001B2 RID: 434
		private static readonly IntPtr NativeMethodInfoPtr_DecryptVector3Value_Private_Static_Vector3_String_String_Vector3_0;

		// Token: 0x040001B3 RID: 435
		private static readonly IntPtr NativeMethodInfoPtr_SetQuaternion_Public_Static_Void_String_Quaternion_0;

		// Token: 0x040001B4 RID: 436
		private static readonly IntPtr NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_0;

		// Token: 0x040001B5 RID: 437
		private static readonly IntPtr NativeMethodInfoPtr_GetQuaternion_Public_Static_Quaternion_String_Quaternion_0;

		// Token: 0x040001B6 RID: 438
		private static readonly IntPtr NativeMethodInfoPtr_EncryptQuaternionValue_Private_Static_String_String_Quaternion_0;

		// Token: 0x040001B7 RID: 439
		private static readonly IntPtr NativeMethodInfoPtr_DecryptQuaternionValue_Private_Static_Quaternion_String_String_Quaternion_0;

		// Token: 0x040001B8 RID: 440
		private static readonly IntPtr NativeMethodInfoPtr_SetColor_Public_Static_Void_String_Color32_0;

		// Token: 0x040001B9 RID: 441
		private static readonly IntPtr NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_0;

		// Token: 0x040001BA RID: 442
		private static readonly IntPtr NativeMethodInfoPtr_GetColor_Public_Static_Color32_String_Color32_0;

		// Token: 0x040001BB RID: 443
		private static readonly IntPtr NativeMethodInfoPtr_EncryptColorValue_Private_Static_String_String_UInt32_0;

		// Token: 0x040001BC RID: 444
		private static readonly IntPtr NativeMethodInfoPtr_SetRect_Public_Static_Void_String_Rect_0;

		// Token: 0x040001BD RID: 445
		private static readonly IntPtr NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_0;

		// Token: 0x040001BE RID: 446
		private static readonly IntPtr NativeMethodInfoPtr_GetRect_Public_Static_Rect_String_Rect_0;

		// Token: 0x040001BF RID: 447
		private static readonly IntPtr NativeMethodInfoPtr_EncryptRectValue_Private_Static_String_String_Rect_0;

		// Token: 0x040001C0 RID: 448
		private static readonly IntPtr NativeMethodInfoPtr_DecryptRectValue_Private_Static_Rect_String_String_Rect_0;

		// Token: 0x040001C1 RID: 449
		private static readonly IntPtr NativeMethodInfoPtr_SetRawValue_Public_Static_Void_String_String_0;

		// Token: 0x040001C2 RID: 450
		private static readonly IntPtr NativeMethodInfoPtr_GetRawValue_Public_Static_String_String_0;

		// Token: 0x040001C3 RID: 451
		private static readonly IntPtr NativeMethodInfoPtr_GetRawValueType_Internal_Static_DataType_String_0;

		// Token: 0x040001C4 RID: 452
		private static readonly IntPtr NativeMethodInfoPtr_EncryptKey_Internal_Static_String_String_0;

		// Token: 0x040001C5 RID: 453
		private static readonly IntPtr NativeMethodInfoPtr_HasKey_Public_Static_Boolean_String_0;

		// Token: 0x040001C6 RID: 454
		private static readonly IntPtr NativeMethodInfoPtr_DeleteKey_Public_Static_Void_String_0;

		// Token: 0x040001C7 RID: 455
		private static readonly IntPtr NativeMethodInfoPtr_DeleteAll_Public_Static_Void_0;

		// Token: 0x040001C8 RID: 456
		private static readonly IntPtr NativeMethodInfoPtr_Save_Public_Static_Void_0;

		// Token: 0x040001C9 RID: 457
		private static readonly IntPtr NativeMethodInfoPtr_GetEncryptedPrefsString_Private_Static_String_String_String_0;

		// Token: 0x040001CA RID: 458
		private static readonly IntPtr NativeMethodInfoPtr_EncryptData_Private_Static_String_String_ArrayOf_Byte_DataType_0;

		// Token: 0x040001CB RID: 459
		private static readonly IntPtr NativeMethodInfoPtr_DecryptData_Internal_Static_ArrayOf_Byte_String_String_0;

		// Token: 0x040001CC RID: 460
		private static readonly IntPtr NativeMethodInfoPtr_CalculateChecksum_Private_Static_UInt32_String_0;

		// Token: 0x040001CD RID: 461
		private static readonly IntPtr NativeMethodInfoPtr_SavesTampered_Private_Static_Void_0;

		// Token: 0x040001CE RID: 462
		private static readonly IntPtr NativeMethodInfoPtr_PossibleForeignSavesDetected_Private_Static_Void_0;

		// Token: 0x040001CF RID: 463
		private static readonly IntPtr NativeMethodInfoPtr_GetDeviceId_Private_Static_String_0;

		// Token: 0x040001D0 RID: 464
		private static readonly IntPtr NativeMethodInfoPtr_EncryptDecryptBytes_Private_Static_ArrayOf_Byte_ArrayOf_Byte_Int32_String_0;

		// Token: 0x040001D1 RID: 465
		private static readonly IntPtr NativeMethodInfoPtr_DeprecatedDecryptValue_Private_Static_String_String_0;

		// Token: 0x040001D2 RID: 466
		private static readonly IntPtr NativeMethodInfoPtr_DeprecatedCalculateChecksum_Private_Static_String_String_0;

		// Token: 0x040001D3 RID: 467
		private static readonly IntPtr NativeMethodInfoPtr_get_DeprecatedDeviceId_Private_Static_get_String_0;

		// Token: 0x02000019 RID: 25
		public enum DataType : byte
		{
			// Token: 0x040001D5 RID: 469
			Unknown,
			// Token: 0x040001D6 RID: 470
			Int = 5,
			// Token: 0x040001D7 RID: 471
			UInt = 10,
			// Token: 0x040001D8 RID: 472
			String = 15,
			// Token: 0x040001D9 RID: 473
			Float = 20,
			// Token: 0x040001DA RID: 474
			Double = 25,
			// Token: 0x040001DB RID: 475
			Decimal = 27,
			// Token: 0x040001DC RID: 476
			Long = 30,
			// Token: 0x040001DD RID: 477
			ULong = 32,
			// Token: 0x040001DE RID: 478
			Bool = 35,
			// Token: 0x040001DF RID: 479
			ByteArray = 40,
			// Token: 0x040001E0 RID: 480
			Vector2 = 45,
			// Token: 0x040001E1 RID: 481
			Vector3 = 50,
			// Token: 0x040001E2 RID: 482
			Quaternion = 55,
			// Token: 0x040001E3 RID: 483
			Color = 60,
			// Token: 0x040001E4 RID: 484
			Rect = 65
		}

		// Token: 0x0200001A RID: 26
		public enum DeviceLockLevel : byte
		{
			// Token: 0x040001E6 RID: 486
			None,
			// Token: 0x040001E7 RID: 487
			Soft,
			// Token: 0x040001E8 RID: 488
			Strict
		}
	}
}
