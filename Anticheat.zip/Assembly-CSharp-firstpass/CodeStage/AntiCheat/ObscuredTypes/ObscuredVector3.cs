﻿using System;
using System.Runtime.InteropServices;
using Il2CppSystem;
using UnhollowerBaseLib;
using UnhollowerBaseLib.Attributes;
using UnityEngine;

namespace CodeStage.AntiCheat.ObscuredTypes
{
	// Token: 0x02000026 RID: 38
	[Serializable]
	[StructLayout(2)]
	public struct ObscuredVector3
	{
		// Token: 0x06000306 RID: 774 RVA: 0x00011E24 File Offset: 0x00010024
		[CallerCount(0)]
		public unsafe ObscuredVector3(ObscuredVector3.RawEncryptedVector3 encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector3_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000307 RID: 775 RVA: 0x00011E6C File Offset: 0x0001006C
		[CallerCount(0)]
		public unsafe ObscuredVector3(float x, float y, float z)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref z;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000308 RID: 776 RVA: 0x00011ED8 File Offset: 0x000100D8
		// (set) Token: 0x06000309 RID: 777 RVA: 0x00011F1C File Offset: 0x0001011C
		public unsafe float x
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_get_x_Public_get_Single_0, ref this, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_set_x_Public_set_Void_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600030A RID: 778 RVA: 0x00011F64 File Offset: 0x00010164
		// (set) Token: 0x0600030B RID: 779 RVA: 0x00011FA8 File Offset: 0x000101A8
		public unsafe float y
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_get_y_Public_get_Single_0, ref this, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_set_y_Public_set_Void_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600030C RID: 780 RVA: 0x00011FF0 File Offset: 0x000101F0
		// (set) Token: 0x0600030D RID: 781 RVA: 0x00012034 File Offset: 0x00010234
		public unsafe float z
		{
			[CallerCount(0)]
			get
			{
				IntPtr* param = null;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_get_z_Public_get_Single_0, ref this, (void**)param, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_set_z_Public_set_Void_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x17000085 RID: 133
		public unsafe float this[int index]
		{
			[CallerCount(0)]
			get
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref index;
				IntPtr returnedException;
				IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
				return *IL2CPP.il2cpp_object_unbox(obj);
			}
			[CallerCount(0)]
			set
			{
				IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
				*ptr = ref index;
				ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref value;
				IntPtr returnedException;
				IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0, ref this, (void**)ptr, ref returnedException);
				Il2CppException.RaiseExceptionIfNecessary(returnedException);
			}
		}

		// Token: 0x06000310 RID: 784 RVA: 0x00012128 File Offset: 0x00010328
		[CallerCount(0)]
		public unsafe static void SetNewCryptoKey(int newKey)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref newKey;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00012170 File Offset: 0x00010370
		[CallerCount(0)]
		public unsafe static ObscuredVector3.RawEncryptedVector3 Encrypt(Vector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000312 RID: 786 RVA: 0x000121C4 File Offset: 0x000103C4
		[CallerCount(0)]
		public unsafe static ObscuredVector3.RawEncryptedVector3 Encrypt(Vector3 value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0001222C File Offset: 0x0001042C
		[CallerCount(0)]
		public unsafe static ObscuredVector3.RawEncryptedVector3 Encrypt(float x, float y, float z, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)4) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref x;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref y;
			ptr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref z;
			ptr[checked(unchecked((UIntPtr)3) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Single_Single_Single_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000314 RID: 788 RVA: 0x000122B8 File Offset: 0x000104B8
		[CallerCount(0)]
		public unsafe static Vector3 Decrypt(ObscuredVector3.RawEncryptedVector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0001230C File Offset: 0x0001050C
		[CallerCount(0)]
		public unsafe static Vector3 Decrypt(ObscuredVector3.RawEncryptedVector3 value, int key)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref key;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_Int32_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000316 RID: 790 RVA: 0x00012374 File Offset: 0x00010574
		[CallerCount(0)]
		public unsafe void ApplyNewCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000317 RID: 791 RVA: 0x000123A8 File Offset: 0x000105A8
		[CallerCount(0)]
		public unsafe void RandomizeCryptoKey()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x06000318 RID: 792 RVA: 0x000123DC File Offset: 0x000105DC
		[CallerCount(0)]
		public unsafe ObscuredVector3.RawEncryptedVector3 GetEncrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector3_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000319 RID: 793 RVA: 0x00012420 File Offset: 0x00010620
		[CallerCount(0)]
		public unsafe void SetEncrypted(ObscuredVector3.RawEncryptedVector3 encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector3_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00012468 File Offset: 0x00010668
		[CallerCount(0)]
		public unsafe Vector3 GetDecrypted()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_GetDecrypted_Public_Vector3_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600031B RID: 795 RVA: 0x000124AC File Offset: 0x000106AC
		[CallerCount(0)]
		public unsafe Vector3 InternalDecrypt()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_InternalDecrypt_Private_Vector3_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600031C RID: 796 RVA: 0x000124F0 File Offset: 0x000106F0
		[CallerCount(0)]
		public unsafe bool CompareVectorsWithTolerance(Vector3 vector1, Vector3 vector2)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref vector1;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref vector2;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector3_Vector3_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00012558 File Offset: 0x00010758
		[CallerCount(0)]
		public unsafe float InternalDecryptField(int encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600031E RID: 798 RVA: 0x000125AC File Offset: 0x000107AC
		[CallerCount(0)]
		public unsafe int InternalEncryptField(float encrypted)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref encrypted;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600031F RID: 799 RVA: 0x00012600 File Offset: 0x00010800
		[CallerCount(0)]
		public unsafe static implicit operator ObscuredVector3(Vector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000320 RID: 800 RVA: 0x00012654 File Offset: 0x00010854
		[CallerCount(0)]
		public unsafe static implicit operator Vector3(ObscuredVector3 value)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref value;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000321 RID: 801 RVA: 0x000126A8 File Offset: 0x000108A8
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator +(ObscuredVector3 a, ObscuredVector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000322 RID: 802 RVA: 0x00012710 File Offset: 0x00010910
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator +(Vector3 a, ObscuredVector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000323 RID: 803 RVA: 0x00012778 File Offset: 0x00010978
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator +(ObscuredVector3 a, Vector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000324 RID: 804 RVA: 0x000127E0 File Offset: 0x000109E0
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator -(ObscuredVector3 a, ObscuredVector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000325 RID: 805 RVA: 0x00012848 File Offset: 0x00010A48
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator -(Vector3 a, ObscuredVector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000326 RID: 806 RVA: 0x000128B0 File Offset: 0x00010AB0
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator -(ObscuredVector3 a, Vector3 b)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref b;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00012918 File Offset: 0x00010B18
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator -(ObscuredVector3 a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_ObscuredVector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000328 RID: 808 RVA: 0x0001296C File Offset: 0x00010B6C
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator *(ObscuredVector3 a, float d)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref d;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_ObscuredVector3_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000329 RID: 809 RVA: 0x000129D4 File Offset: 0x00010BD4
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator *(float d, ObscuredVector3 a)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref d;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref a;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_Single_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032A RID: 810 RVA: 0x00012A3C File Offset: 0x00010C3C
		[CallerCount(0)]
		public unsafe static ObscuredVector3 operator /(ObscuredVector3 a, float d)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref a;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref d;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Division_Public_Static_ObscuredVector3_ObscuredVector3_Single_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032B RID: 811 RVA: 0x00012AA4 File Offset: 0x00010CA4
		[CallerCount(0)]
		public unsafe static bool operator ==(ObscuredVector3 lhs, ObscuredVector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00012B0C File Offset: 0x00010D0C
		[CallerCount(0)]
		public unsafe static bool operator ==(Vector3 lhs, ObscuredVector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Vector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x00012B74 File Offset: 0x00010D74
		[CallerCount(0)]
		public unsafe static bool operator ==(ObscuredVector3 lhs, Vector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x00012BDC File Offset: 0x00010DDC
		[CallerCount(0)]
		public unsafe static bool operator !=(ObscuredVector3 lhs, ObscuredVector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x0600032F RID: 815 RVA: 0x00012C44 File Offset: 0x00010E44
		[CallerCount(0)]
		public unsafe static bool operator !=(Vector3 lhs, ObscuredVector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Vector3_ObscuredVector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00012CAC File Offset: 0x00010EAC
		[CallerCount(0)]
		public unsafe static bool operator !=(ObscuredVector3 lhs, Vector3 rhs)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)2) * (UIntPtr)sizeof(IntPtr))];
			*ptr = ref lhs;
			ptr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)) / (UIntPtr)sizeof(IntPtr)] = ref rhs;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_Vector3_0, 0, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000331 RID: 817 RVA: 0x00012D14 File Offset: 0x00010F14
		[CallerCount(0)]
		public unsafe bool Equals(Il2CppSystem.Object other)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.Il2CppObjectBaseToPtr(other);
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000332 RID: 818 RVA: 0x00012D6C File Offset: 0x00010F6C
		[CallerCount(0)]
		public unsafe int GetHashCode()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr obj = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return *IL2CPP.il2cpp_object_unbox(obj);
		}

		// Token: 0x06000333 RID: 819 RVA: 0x00012DB0 File Offset: 0x00010FB0
		[CallerCount(0)]
		public unsafe string ToString()
		{
			IntPtr* param = null;
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_ToString_Public_Virtual_String_0, ref this, (void**)param, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000334 RID: 820 RVA: 0x00012DEC File Offset: 0x00010FEC
		[CallerCount(0)]
		public unsafe string ToString(string format)
		{
			IntPtr* ptr = stackalloc IntPtr[checked(unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr))];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(format);
			IntPtr returnedException;
			IntPtr il2CppString = IL2CPP.il2cpp_runtime_invoke(ObscuredVector3.NativeMethodInfoPtr_ToString_Public_String_String_0, ref this, (void**)ptr, ref returnedException);
			Il2CppException.RaiseExceptionIfNecessary(returnedException);
			return IL2CPP.Il2CppStringToManaged(il2CppString);
		}

		// Token: 0x06000335 RID: 821 RVA: 0x00012E40 File Offset: 0x00011040
		// Note: this type is marked as 'beforefieldinit'.
		static ObscuredVector3()
		{
			Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp-firstpass.dll", "CodeStage.AntiCheat.ObscuredTypes", "ObscuredVector3");
			IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr);
			ObscuredVector3.NativeFieldInfoPtr_cryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "cryptoKey");
			ObscuredVector3.NativeFieldInfoPtr_initialFakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "initialFakeValue");
			ObscuredVector3.NativeFieldInfoPtr_currentCryptoKey = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "currentCryptoKey");
			ObscuredVector3.NativeFieldInfoPtr_hiddenValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "hiddenValue");
			ObscuredVector3.NativeFieldInfoPtr_fakeValue = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "fakeValue");
			ObscuredVector3.NativeFieldInfoPtr_inited = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "inited");
			ObscuredVector3.NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663837);
			ObscuredVector3.NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663838);
			ObscuredVector3.NativeMethodInfoPtr_get_x_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663839);
			ObscuredVector3.NativeMethodInfoPtr_set_x_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663840);
			ObscuredVector3.NativeMethodInfoPtr_get_y_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663841);
			ObscuredVector3.NativeMethodInfoPtr_set_y_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663842);
			ObscuredVector3.NativeMethodInfoPtr_get_z_Public_get_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663843);
			ObscuredVector3.NativeMethodInfoPtr_set_z_Public_set_Void_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663844);
			ObscuredVector3.NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663845);
			ObscuredVector3.NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663846);
			ObscuredVector3.NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663847);
			ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663848);
			ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663849);
			ObscuredVector3.NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Single_Single_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663850);
			ObscuredVector3.NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663851);
			ObscuredVector3.NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663852);
			ObscuredVector3.NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663853);
			ObscuredVector3.NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663854);
			ObscuredVector3.NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663855);
			ObscuredVector3.NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663856);
			ObscuredVector3.NativeMethodInfoPtr_GetDecrypted_Public_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663857);
			ObscuredVector3.NativeMethodInfoPtr_InternalDecrypt_Private_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663858);
			ObscuredVector3.NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663859);
			ObscuredVector3.NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663860);
			ObscuredVector3.NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663861);
			ObscuredVector3.NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663862);
			ObscuredVector3.NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663863);
			ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663864);
			ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663865);
			ObscuredVector3.NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663866);
			ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663867);
			ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663868);
			ObscuredVector3.NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663869);
			ObscuredVector3.NativeMethodInfoPtr_op_UnaryNegation_Public_Static_ObscuredVector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663870);
			ObscuredVector3.NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_ObscuredVector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663871);
			ObscuredVector3.NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_Single_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663872);
			ObscuredVector3.NativeMethodInfoPtr_op_Division_Public_Static_ObscuredVector3_ObscuredVector3_Single_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663873);
			ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663874);
			ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Vector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663875);
			ObscuredVector3.NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663876);
			ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663877);
			ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Vector3_ObscuredVector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663878);
			ObscuredVector3.NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_Vector3_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663879);
			ObscuredVector3.NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663880);
			ObscuredVector3.NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663881);
			ObscuredVector3.NativeMethodInfoPtr_ToString_Public_Virtual_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663882);
			ObscuredVector3.NativeMethodInfoPtr_ToString_Public_String_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, 100663883);
		}

		// Token: 0x06000336 RID: 822 RVA: 0x00013294 File Offset: 0x00011494
		public Il2CppSystem.Object BoxIl2CppObject()
		{
			return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, ref this));
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000337 RID: 823 RVA: 0x000132A6 File Offset: 0x000114A6
		[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
		public static Type Il2CppType
		{
			get
			{
				return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr));
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000338 RID: 824 RVA: 0x000132B8 File Offset: 0x000114B8
		// (set) Token: 0x06000339 RID: 825 RVA: 0x000132D6 File Offset: 0x000114D6
		public unsafe static int cryptoKey
		{
			get
			{
				int result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredVector3.NativeFieldInfoPtr_cryptoKey, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredVector3.NativeFieldInfoPtr_cryptoKey, (void*)(&value));
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x0600033A RID: 826 RVA: 0x000132E8 File Offset: 0x000114E8
		// (set) Token: 0x0600033B RID: 827 RVA: 0x00013306 File Offset: 0x00011506
		public unsafe static Vector3 initialFakeValue
		{
			get
			{
				Vector3 result;
				IL2CPP.il2cpp_field_static_get_value(ObscuredVector3.NativeFieldInfoPtr_initialFakeValue, (void*)(&result));
				return result;
			}
			set
			{
				IL2CPP.il2cpp_field_static_set_value(ObscuredVector3.NativeFieldInfoPtr_initialFakeValue, (void*)(&value));
			}
		}

		// Token: 0x040002F7 RID: 759
		private static readonly IntPtr NativeFieldInfoPtr_cryptoKey;

		// Token: 0x040002F8 RID: 760
		private static readonly IntPtr NativeFieldInfoPtr_initialFakeValue;

		// Token: 0x040002F9 RID: 761
		private static readonly IntPtr NativeFieldInfoPtr_currentCryptoKey;

		// Token: 0x040002FA RID: 762
		private static readonly IntPtr NativeFieldInfoPtr_hiddenValue;

		// Token: 0x040002FB RID: 763
		private static readonly IntPtr NativeFieldInfoPtr_fakeValue;

		// Token: 0x040002FC RID: 764
		private static readonly IntPtr NativeFieldInfoPtr_inited;

		// Token: 0x040002FD RID: 765
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Private_Void_RawEncryptedVector3_0;

		// Token: 0x040002FE RID: 766
		private static readonly IntPtr NativeMethodInfoPtr__ctor_Public_Void_Single_Single_Single_0;

		// Token: 0x040002FF RID: 767
		private static readonly IntPtr NativeMethodInfoPtr_get_x_Public_get_Single_0;

		// Token: 0x04000300 RID: 768
		private static readonly IntPtr NativeMethodInfoPtr_set_x_Public_set_Void_Single_0;

		// Token: 0x04000301 RID: 769
		private static readonly IntPtr NativeMethodInfoPtr_get_y_Public_get_Single_0;

		// Token: 0x04000302 RID: 770
		private static readonly IntPtr NativeMethodInfoPtr_set_y_Public_set_Void_Single_0;

		// Token: 0x04000303 RID: 771
		private static readonly IntPtr NativeMethodInfoPtr_get_z_Public_get_Single_0;

		// Token: 0x04000304 RID: 772
		private static readonly IntPtr NativeMethodInfoPtr_set_z_Public_set_Void_Single_0;

		// Token: 0x04000305 RID: 773
		private static readonly IntPtr NativeMethodInfoPtr_get_Item_Public_get_Single_Int32_0;

		// Token: 0x04000306 RID: 774
		private static readonly IntPtr NativeMethodInfoPtr_set_Item_Public_set_Void_Int32_Single_0;

		// Token: 0x04000307 RID: 775
		private static readonly IntPtr NativeMethodInfoPtr_SetNewCryptoKey_Public_Static_Void_Int32_0;

		// Token: 0x04000308 RID: 776
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_0;

		// Token: 0x04000309 RID: 777
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Vector3_Int32_0;

		// Token: 0x0400030A RID: 778
		private static readonly IntPtr NativeMethodInfoPtr_Encrypt_Public_Static_RawEncryptedVector3_Single_Single_Single_Int32_0;

		// Token: 0x0400030B RID: 779
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_0;

		// Token: 0x0400030C RID: 780
		private static readonly IntPtr NativeMethodInfoPtr_Decrypt_Public_Static_Vector3_RawEncryptedVector3_Int32_0;

		// Token: 0x0400030D RID: 781
		private static readonly IntPtr NativeMethodInfoPtr_ApplyNewCryptoKey_Public_Void_0;

		// Token: 0x0400030E RID: 782
		private static readonly IntPtr NativeMethodInfoPtr_RandomizeCryptoKey_Public_Void_0;

		// Token: 0x0400030F RID: 783
		private static readonly IntPtr NativeMethodInfoPtr_GetEncrypted_Public_RawEncryptedVector3_0;

		// Token: 0x04000310 RID: 784
		private static readonly IntPtr NativeMethodInfoPtr_SetEncrypted_Public_Void_RawEncryptedVector3_0;

		// Token: 0x04000311 RID: 785
		private static readonly IntPtr NativeMethodInfoPtr_GetDecrypted_Public_Vector3_0;

		// Token: 0x04000312 RID: 786
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecrypt_Private_Vector3_0;

		// Token: 0x04000313 RID: 787
		private static readonly IntPtr NativeMethodInfoPtr_CompareVectorsWithTolerance_Private_Boolean_Vector3_Vector3_0;

		// Token: 0x04000314 RID: 788
		private static readonly IntPtr NativeMethodInfoPtr_InternalDecryptField_Private_Single_Int32_0;

		// Token: 0x04000315 RID: 789
		private static readonly IntPtr NativeMethodInfoPtr_InternalEncryptField_Private_Int32_Single_0;

		// Token: 0x04000316 RID: 790
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_ObscuredVector3_Vector3_0;

		// Token: 0x04000317 RID: 791
		private static readonly IntPtr NativeMethodInfoPtr_op_Implicit_Public_Static_Vector3_ObscuredVector3_0;

		// Token: 0x04000318 RID: 792
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0;

		// Token: 0x04000319 RID: 793
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0;

		// Token: 0x0400031A RID: 794
		private static readonly IntPtr NativeMethodInfoPtr_op_Addition_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0;

		// Token: 0x0400031B RID: 795
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_ObscuredVector3_0;

		// Token: 0x0400031C RID: 796
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_Vector3_ObscuredVector3_0;

		// Token: 0x0400031D RID: 797
		private static readonly IntPtr NativeMethodInfoPtr_op_Subtraction_Public_Static_ObscuredVector3_ObscuredVector3_Vector3_0;

		// Token: 0x0400031E RID: 798
		private static readonly IntPtr NativeMethodInfoPtr_op_UnaryNegation_Public_Static_ObscuredVector3_ObscuredVector3_0;

		// Token: 0x0400031F RID: 799
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_ObscuredVector3_Single_0;

		// Token: 0x04000320 RID: 800
		private static readonly IntPtr NativeMethodInfoPtr_op_Multiply_Public_Static_ObscuredVector3_Single_ObscuredVector3_0;

		// Token: 0x04000321 RID: 801
		private static readonly IntPtr NativeMethodInfoPtr_op_Division_Public_Static_ObscuredVector3_ObscuredVector3_Single_0;

		// Token: 0x04000322 RID: 802
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0;

		// Token: 0x04000323 RID: 803
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_Vector3_ObscuredVector3_0;

		// Token: 0x04000324 RID: 804
		private static readonly IntPtr NativeMethodInfoPtr_op_Equality_Public_Static_Boolean_ObscuredVector3_Vector3_0;

		// Token: 0x04000325 RID: 805
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_ObscuredVector3_0;

		// Token: 0x04000326 RID: 806
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_Vector3_ObscuredVector3_0;

		// Token: 0x04000327 RID: 807
		private static readonly IntPtr NativeMethodInfoPtr_op_Inequality_Public_Static_Boolean_ObscuredVector3_Vector3_0;

		// Token: 0x04000328 RID: 808
		private static readonly IntPtr NativeMethodInfoPtr_Equals_Public_Virtual_Boolean_Object_0;

		// Token: 0x04000329 RID: 809
		private static readonly IntPtr NativeMethodInfoPtr_GetHashCode_Public_Virtual_Int32_0;

		// Token: 0x0400032A RID: 810
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_Virtual_String_0;

		// Token: 0x0400032B RID: 811
		private static readonly IntPtr NativeMethodInfoPtr_ToString_Public_String_String_0;

		// Token: 0x0400032C RID: 812
		[FieldOffset(0)]
		public int currentCryptoKey;

		// Token: 0x0400032D RID: 813
		[FieldOffset(4)]
		public ObscuredVector3.RawEncryptedVector3 hiddenValue;

		// Token: 0x0400032E RID: 814
		[FieldOffset(16)]
		public Vector3 fakeValue;

		// Token: 0x0400032F RID: 815
		[FieldOffset(28)]
		public bool inited;

		// Token: 0x02000027 RID: 39
		[Serializable]
		[StructLayout(2)]
		public struct RawEncryptedVector3
		{
			// Token: 0x0600033C RID: 828 RVA: 0x00013318 File Offset: 0x00011518
			// Note: this type is marked as 'beforefieldinit'.
			static RawEncryptedVector3()
			{
				Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<ObscuredVector3>.NativeClassPtr, "RawEncryptedVector3");
				IL2CPP.il2cpp_runtime_class_init(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr);
				ObscuredVector3.RawEncryptedVector3.NativeFieldInfoPtr_x = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr, "x");
				ObscuredVector3.RawEncryptedVector3.NativeFieldInfoPtr_y = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr, "y");
				ObscuredVector3.RawEncryptedVector3.NativeFieldInfoPtr_z = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr, "z");
			}

			// Token: 0x0600033D RID: 829 RVA: 0x0001337F File Offset: 0x0001157F
			public Il2CppSystem.Object BoxIl2CppObject()
			{
				return new Il2CppSystem.Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr, ref this));
			}

			// Token: 0x17000086 RID: 134
			// (get) Token: 0x0600033E RID: 830 RVA: 0x00013391 File Offset: 0x00011591
			[Obsolete("Use Il2CppType.Of<T>() instead. This will be removed in a future version of unhollower.")]
			public static Type Il2CppType
			{
				get
				{
					return Type.internal_from_handle(IL2CPP.il2cpp_class_get_type(Il2CppClassPointerStore<ObscuredVector3.RawEncryptedVector3>.NativeClassPtr));
				}
			}

			// Token: 0x04000330 RID: 816
			private static readonly IntPtr NativeFieldInfoPtr_x;

			// Token: 0x04000331 RID: 817
			private static readonly IntPtr NativeFieldInfoPtr_y;

			// Token: 0x04000332 RID: 818
			private static readonly IntPtr NativeFieldInfoPtr_z;

			// Token: 0x04000333 RID: 819
			[FieldOffset(0)]
			public int x;

			// Token: 0x04000334 RID: 820
			[FieldOffset(4)]
			public int y;

			// Token: 0x04000335 RID: 821
			[FieldOffset(8)]
			public int z;
		}
	}
}
